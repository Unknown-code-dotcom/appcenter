package android.os;

import androidx.annotation.Keep;

@Keep
public class SystemProperties {

    public static String get(String key) {
        return null;
    }

    public static String get(String key, String def) {
        return null;
    }

    public static boolean getBoolean(String key, boolean def) {
        return false;
    }

    public static int getInt(String key, int def) {
        return -1;
    }
}
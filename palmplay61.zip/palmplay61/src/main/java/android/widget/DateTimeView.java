package android.widget;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.Keep;
import androidx.annotation.Nullable;

@Keep
public class DateTimeView extends TextView{

    public DateTimeView(Context context) {
        super(context);
    }

    public DateTimeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

}

/* Transsion Top Secret */
/*
 * Copyright(C) 2017 Transsion Inc.
 *
 */

package com.afmobi.apk;


import android.annotation.TargetApi;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.SimpleDataMap;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.HiManagerHelper;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.util.Constant;
import com.afmobi.util.PhoneDeviceInfo;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.ApiUExtKt;
import com.transsion.palmstorecore.util.SystemUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.xapk.XapkUtils;
import com.transsion.xapk.installs.XapkInstallReceiver;
import com.transsion.xapk.utils.InstallerTypeUtil;
import com.transsion.xapk.utils.Installs;
import com.transsnet.store.BuildConfig;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 * liuzhi 　20190411
 * 增加辅助编译系统类:
 *        android.content.pm.PackageParser
 */
public class InstallUtil {
    private static final String TAG = "InstallUtil";
    public static final int IGNORE_REQUEST_CODE = 1;
    private static int REQUEST_CODE = IGNORE_REQUEST_CODE + 1;
    private static InstallReceiver sInstallReceiver = null;
    public static final String VER_NAME = "verName";
    public static final String VER_CODE = "verCode";
    public static final String MD5 = "md5";
    public static final String APP_FROM = "appFrom";
    public static final String PARAM_CONTINUOUS_INSTALL = "continuous_install";
    public static final String PARAM_CURRENT_INDEX = "param_current_index";
    public static final String IS_INSTALL_SMALL_PKG = "is_small_pkg";
    public static final String SMALL_APK_PACKAGE = "small_apk_package";
    public static final int INSTALL_INTERNAL = 0x00000010;
    public static final int INSTALL_REPLACE_EXISTING = 0x00000002;
    public static final int INSTALL_ALL_WHITELIST_RESTRICTED_PERMISSIONS = 0x00400000;
    public static final String INSTALL_TYPE = "InstallerType";
    public static final String UPDATE_TYPE = "update_type";
    public static final String IS_SUB_PACKAGE = "isSubPackage";
    public static final String FROM_PAGE = "fromPage";
    public static final String DOWNLOAD_APK_PATH = "download_apk_path";
    public static final String PRE_AUTH_TOKEN = "pre_auth_token";
    public static final String IS_MULTI_PACKAGE = "is_multi_pkg";

    public static final String NATIVEID = "nativeId";
    public static void init() {
        if (sInstallReceiver != null) {
            return;
        }
        synchronized (InstallUtil.class) {
            if (sInstallReceiver != null) {
                return;
            }
            sInstallReceiver = new InstallReceiver();
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(InstallReceiver.PALMSTORE_SLIENT_INSTALL_ACTION);
            ApiUExtKt.registerReceiverExported(sInstallReceiver, PalmplayApplication.getAppInstance(), intentFilter);
        }
    }

    public static void clear() {
        if (sInstallReceiver == null) {
            return;
        }
        synchronized (InstallUtil.class) {
            if (sInstallReceiver == null) {
                return;
            }
            InstallReceiver receiver = sInstallReceiver;
            sInstallReceiver = null;
            PalmplayApplication.getAppInstance().unregisterReceiver(receiver);
        }
    }

    private static Object getFieldValue(Object obj, Class<?> c, String name, Object defaultValue) {
        Object o;
        try {
            Field f = c.getField(name);
            o = f.get(obj);
        } catch (NoSuchFieldException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return defaultValue;
        } catch (IllegalAccessException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return defaultValue;
        }
        return o;
    }

    private static void setFieldValue(Class clz, String fieldName, Object obj, Object value) {
        Field f;
        try {
            f = clz.getField(fieldName);
        } catch (NoSuchFieldException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return;

        }
        try {
            f.setAccessible(true);
            f.set(obj, value);
        } catch (IllegalAccessException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }


    @TargetApi(21)
    public static void tryInstall(final String apkPath, final InstallCallback callback, final String pkg, final boolean isSubPackage, final Map<String, String> preAuthTokens, boolean isMultiPackage) {
        if (ThreadHelper.isUiThread()) {

            ThreadHelper.runOnWorkThread(new Runnable() {

                @Override
                public void run() {
                    // Android14+ UpdateOwnership 抹除（不论结果继续安装）
                    Context appCtx = PalmplayApplication.getPalmplayApplicationInstance();
                    if (ConfigManager.isUpdateOwnershipClearEnable()
                            && HiManagerHelper.needsClearOwnership(appCtx, pkg)) {
                        HiManagerHelper.clearUpdateOwnership(appCtx, pkg);
                    }
                    boolean success = InstallUtil.pmInstall(PalmplayApplication.getPalmplayApplicationInstance(), apkPath, pkg, isSubPackage, preAuthTokens, isMultiPackage);
                    if (callback != null) {
                        callback.onResult(success);
                    }

                }
            });

        } else {

            // Android14+ UpdateOwnership 抹除（不论结果继续安装）
            Context appCtx = PalmplayApplication.getPalmplayApplicationInstance();
            if (ConfigManager.isUpdateOwnershipClearEnable()
                    && HiManagerHelper.needsClearOwnership(appCtx, pkg)) {
                HiManagerHelper.clearUpdateOwnership(appCtx, pkg);
            }
            boolean result = InstallUtil.pmInstall(PalmplayApplication.getPalmplayApplicationInstance(), apkPath, pkg, isSubPackage, preAuthTokens, isMultiPackage);
            if (callback != null) {
                callback.onResult(result);
            }
        }


    }

    @TargetApi(21)
    public static boolean pmInstall(Context ctx, String apkPath, boolean isSmallPkg, Map<String, String> preAuthTokens) {

        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw new RuntimeException("func must not run in main thread");
        }

        boolean result = true;
        PackageInstaller.Session session = null;
        PackageManager pm = ctx.getPackageManager();
        PackageInstaller installer = pm.getPackageInstaller();
        int sessionId = 0;
        String pkgName = "";
        String versionName = "";
        String appFrom = "palmstore";
        int versionCode = 0;
        String errorMsg = "";
        String md5 = "";
        String update_type="def";
        String palmsVersion = "";
        String nativeId = "";
        long time = 0;
        File file = new File(apkPath);
        if (!file.exists()) {
            return false;
        }
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int installFullApp = (int) getFieldValue(null, PackageManager.class, "INSTALL_FULL_APP", 0);
        int installReplaceExisting = (int) getFieldValue(null, PackageManager.class, "INSTALL_REPLACE_EXISTING", 0);
        int flags = installFullApp | installReplaceExisting;

        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
            int install_internal = 0;
            int whitelistFlag = 0;
            install_internal = (int) getFieldValue(null, PackageManager.class, "INSTALL_INTERNAL",INSTALL_INTERNAL );
            whitelistFlag = (int) getFieldValue(null,PackageManager.class,"INSTALL_ALL_WHITELIST_RESTRICTED_PERMISSIONS",INSTALL_ALL_WHITELIST_RESTRICTED_PERMISSIONS);
            flags |=  whitelistFlag | install_internal;
        }

        if (flags != 0) {
            setFieldValue(PackageInstaller.SessionParams.class, "installFlags", params, flags);
        }

        PackageInfo apkPackageInfo = pm.getPackageArchiveInfo(apkPath, 0);
        if (apkPackageInfo == null) {
            return false;
        }
        pkgName = apkPackageInfo.packageName;
        versionName = apkPackageInfo.versionName;
        versionCode = apkPackageInfo.versionCode;
        FileDownloadInfo fileInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(pkgName);
        //String downloadedApkFilePath = FilePathManager.getDownloadedApkFilePath(fileInfo);
        //LogUtils.d(TAG, "pmInstall: downloadedApkFilePath " + downloadedApkFilePath);

        boolean continuousInstall = false;
        int currentIndex = -1;
        String fromPage = SimpleDataMap.INSTANCE.getInstallSourceMap().remove(apkPath);
        if(fileInfo!=null) {
            continuousInstall = fileInfo.continuousInstall;
            currentIndex = fileInfo.currentIndex;
            fromPage = fileInfo.fromPage;
            if(!TextUtils.isEmpty(fileInfo.downloadUrl) && fileInfo.downloadUrl.contains("aptoide.com")) {
                appFrom = "Aptoide";
            }
            time = fileInfo.extraInfo!=null ? fileInfo.extraInfo.time : 0;
            palmsVersion = fileInfo.extraInfo!=null ? fileInfo.extraInfo.dlVer : "";
            update_type = fileInfo.getUpdateType();
            nativeId = fileInfo.extraInfo!=null ? fileInfo.extraInfo.nativeId : "";
        }
        md5 = SystemUtils.getFileMD5(new File(apkPath));
        params.setAppPackageName(apkPackageInfo.packageName);
        params.setInstallLocation(apkPackageInfo.installLocation);
        params.setSize(file.length());

        InputStream in = null;
        OutputStream out = null;
        //ADV 二期：取 advDetails 中第一个 token 传给 SDK（多 token 待 Google SDK 支持后适配）
        String firstToken = (preAuthTokens != null && !preAuthTokens.isEmpty())
                ? preAuthTokens.values().iterator().next() : null;

        try {

            sessionId = Installs.createSessionWithAdvIfNeeded(ctx, installer, params, firstToken);

            session = installer.openSession(sessionId);
            in = new FileInputStream(file);
            long sizeBytes = file.length();

            out = session.openWrite("PackageInstaller", 0, sizeBytes);

            byte[] buffer = new byte[1024 * 1024];
            while (true) {
                int numRead = in.read(buffer);

                if (numRead == -1) {
                    session.fsync(out);
                    break;
                }
                out.write(buffer, 0, numRead);
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            errorMsg = e.getMessage();

            List<String> list = (preAuthTokens != null && !preAuthTokens.isEmpty())? new ArrayList<>(preAuthTokens.values()) : null;
            TRAnalysticsUtil.trackInstallError(pkgName,errorMsg,versionName,versionCode,md5,appFrom,
                    update_type,fromPage,apkPath,palmsVersion,time,nativeId, PhoneDeviceInfo.getCountryCode(), list, false);
            result = false;
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        if (session != null) {
            Intent intent = new Intent(InstallReceiver.PALMSTORE_SLIENT_INSTALL_ACTION);
            intent.setFlags(Intent.FLAG_RECEIVER_FOREGROUND);
            intent.putExtra(VER_NAME,versionName);
            intent.putExtra(VER_CODE,versionCode);
            intent.putExtra(MD5,md5);
            intent.putExtra(FROM_PAGE,fromPage);
            intent.putExtra(APP_FROM,appFrom);
            intent.putExtra(Constant.KEY_PACKAGE_NAME,pkgName);
            intent.putExtra(PARAM_CONTINUOUS_INSTALL, continuousInstall);
            intent.putExtra(PARAM_CURRENT_INDEX, currentIndex);
            intent.putExtra(UPDATE_TYPE, update_type);
            intent.putExtra(UPDATE_TYPE, update_type);
            intent.putExtra(NATIVEID, nativeId);

            if (isSmallPkg) {
                intent.putExtra(DOWNLOAD_APK_PATH, apkPath);
            } else {
                intent.putExtra(DOWNLOAD_APK_PATH, apkPath);
            }
            intent.putExtra(IS_INSTALL_SMALL_PKG, isSmallPkg);
            intent.putExtra(TRAnalyticsConstant.APP_VERSION,palmsVersion);
            intent.putExtra(TRAnalyticsConstant.TIME,time);
            ArrayList<String> tokenList = null;
            if (preAuthTokens != null && !preAuthTokens.isEmpty()) {
                tokenList = new ArrayList<>(preAuthTokens.values());
                intent.putStringArrayListExtra(PRE_AUTH_TOKEN, tokenList);
            }

            intent.setPackage(ctx.getPackageName());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    ctx,
                    IGNORE_REQUEST_CODE,
                    intent,
                    TRApplicationContextUtil.getPendingIntentFlag());
            try {
                session.commit(pendingIntent.getIntentSender());
            } catch (Throwable t) {
                // commit 可能抛 SecurityException / IllegalStateException / IOException 等
                if (BuildConfig.DEBUG) t.printStackTrace();
                errorMsg = t.getMessage();

                TRAnalysticsUtil.trackInstallError(pkgName,errorMsg,versionName,versionCode,md5,appFrom,
                        update_type,fromPage,apkPath,palmsVersion,time,nativeId, PhoneDeviceInfo.getCountryCode(), tokenList, false);
                result = false;
            } finally {
                session.close();
            }
        }

//        if (sessionId != 0) {
//            try {
//                installer.abandonSession(sessionId);
//            } catch (SecurityException ignore) {
//            }
//        }
        return result;
    }




    /**
     * 构建 intent
     *
     * @param ctx
     * @param apkPath
     * @param pkgName
     * @return
     */
    public static Intent getIntent(Context ctx, String apkPath, String pkgName, boolean isSubPackage, Map<String, String> preAuthTokens, boolean isMultiPackage) {
        FileDownloadInfo fileInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(pkgName);
        boolean continuousInstall = false;
        int currentIndex = -1;
        String appFrom = "palmstore";
        String versionName = "";
        String fromPage = SimpleDataMap.INSTANCE.getInstallSourceMap().remove(apkPath);
        int versionCode = 0;
        if (fileInfo != null) {
            fromPage = fileInfo.fromPage;
            continuousInstall = fileInfo.continuousInstall;
            currentIndex = fileInfo.currentIndex;
            versionName = fileInfo.versionName;
            versionCode = fileInfo.version;
            if (!TextUtils.isEmpty(fileInfo.downloadUrl)
                    && fileInfo.downloadUrl.contains("aptoide.com")) {
                appFrom = "Aptoide";
            }
        }
        Intent intent = new Intent(XapkInstallReceiver.getActions(ctx));
        intent.putExtra(InstallUtil.VER_NAME, versionName);
        intent.putExtra(InstallUtil.VER_CODE, versionCode);
        intent.putExtra(FROM_PAGE,fromPage);
        //intent.putExtra(InstallUtil.MD5, SystemUtils.getFileMD5(new File(apkPath)));
        intent.putExtra(InstallUtil.APP_FROM, appFrom);
        intent.putExtra(Constant.KEY_PACKAGE_NAME, pkgName);
        intent.putExtra(InstallUtil.PARAM_CONTINUOUS_INSTALL, continuousInstall);
        intent.putExtra(InstallUtil.PARAM_CURRENT_INDEX, currentIndex);
        intent.putExtra(InstallUtil.IS_SUB_PACKAGE, isSubPackage);
        if (preAuthTokens != null && !preAuthTokens.isEmpty()) {
            intent.putStringArrayListExtra(InstallUtil.PRE_AUTH_TOKEN, new ArrayList<>(preAuthTokens.values()));
        }
        intent.putExtra(InstallUtil.DOWNLOAD_APK_PATH, apkPath);
        intent.putExtra(InstallUtil.IS_MULTI_PACKAGE, isMultiPackage);

        return intent;
    }

    private static boolean pmInstall(Context ctx, String apkPath, String pkg, boolean isSubPackage, Map<String, String> preAuthTokens, boolean isMultiPackage) {
        Log.d("AFMOBI","ISTAL" + pkg + (isSubPackage ?1: 0));
        boolean reuslt = false;
        if(!isSubPackage && !isMultiPackage) {
            reuslt = pmInstall(ctx, apkPath, false, preAuthTokens);
        } else {
            Intent intent = getIntent(ctx, apkPath, pkg,isSubPackage, preAuthTokens, isMultiPackage);
            InstallerTypeUtil.InstallType installType = InstallerTypeUtil.InstallType.APK;
            if(isSubPackage || isMultiPackage){
                installType = InstallerTypeUtil.InstallType.Xapk;
            }
            reuslt = XapkUtils.silentInstallPackage(apkPath, ctx, intent, installType, preAuthTokens, isMultiPackage);
        }
        return reuslt;
    }


    public interface InstallCallback {
        void onResult(boolean result);
    }


}


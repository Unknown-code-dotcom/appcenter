package com.afmobi.apk.installresult;

import android.view.View;

import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.transsnet.store.R;

/****
 * apk无法解释问题导致的失败
 */
public class ApkIssuesInstallFail extends BaseInstallFail {

    public ApkIssuesInstallFail() {
        super(TYPE_INSTALL_APK_ISSUES_FAIL, INSTALL_APK_ISSUES_FAIL);
    }

    @Override
    int getMsgStrID() {
        return R.string.txt_apk_issues_install_failed;
    }

    @Override
    int getBtnConfirmStr() {
        return R.string.txt_re_downlaod;
    }

    @Override
    public void onInstallFail(int errorCode, String errorMsg, String appPackageName) {
        super.onInstallFail(errorCode, errorMsg, appPackageName);

        //不需要重新检查安装
        FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(appPackageName);
        if(fileDownloadInfo != null && fileDownloadInfo.extraInfo != null){
            fileDownloadInfo.extraInfo.noNeedRetry = true;
        }
        DownloadManager.getInstance().updateDownloadedInfotoDB(fileDownloadInfo);
    }

    @Override
    View.OnClickListener getPositiveBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(mPackageName);
                if(fileDownloadInfo != null){
                    DownloadManager.getInstance().removeDownloadedInfo(fileDownloadInfo.packageName);
                    fileDownloadInfo.downloadedSize=0;
                    DownloadManager.getInstance().addDownloadingInfo(fileDownloadInfo);
                }
            }
        };
    }

    @Override
    View.OnClickListener getNegativeBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (isLimitExpireValid) {
//                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_CLOSE, null);
//                }
            }
        };
    }

    @Override
    boolean checkLimitExpireValid() {
        boolean isValid = true;
        return isValid;
    }
}

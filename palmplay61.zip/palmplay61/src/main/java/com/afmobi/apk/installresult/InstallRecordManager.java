package com.afmobi.apk.installresult;

import com.afmobi.apk.ApkInstallUtils;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.keeptojosn.InstallRecordCache;
import com.afmobi.palmplay.model.keeptojosn.InstallRecordInfo;
import com.afmobi.util.CommonUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.log.LogUtils;

import java.util.Map;

public class InstallRecordManager implements LocalCache {
    private final static String FILE_NAME = "installRecordCache";
    private InstallRecordCache installRecordCache;
    private static InstallRecordManager instance = new InstallRecordManager();
    private boolean isInstallFailedPoping;

    private InstallRecordManager(){
        loadFromCache();
    }

    public static InstallRecordManager getInstance() {
        return instance;
    }

    public void addIntallingrecord(String packageName, boolean isAuto){
        installRecordCache.addIntallingrecord(packageName, isAuto);
//        saveToCacheFile();
    }

    public void addIntalledFialrecord(int type, String packageName, int errorCode, String errorMsg){
        installRecordCache.addIntalledFialrecord(type, packageName, errorCode, errorMsg);
        saveToCacheFile();
    }

    public void addShowTipsRecord(int type, String packageName, int errorCode, String errorMsg){
        removeInstallingRecordInfo(packageName);
        installRecordCache.addShowTipsRecord(type, packageName, errorCode, errorMsg);
        saveToCacheFile();
    }

    /**
     * 卸载完成，检查是否在卸载再重新安装的逻辑中
     * @param packageName
     */
    public void checkUninstallAndReInstall(String packageName) {
        InstallRecordInfo installRecordInfo = installRecordCache.getInstallFailedRecordInfo(packageName);
        if(installRecordInfo != null){
            if(installRecordInfo.getType() == BaseInstallFail.TYPE_INSTALL_UDPATE_SIGNATURES_FAIL
                    && installRecordInfo.getTipsTime() != 0){
                FileDownloadInfo retryFileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(packageName);
                if(retryFileDownloadInfo != null){

                    String filePath = FilePathManager.getDownloadedFilePath(retryFileDownloadInfo);
                    Map<String, String> preAuthTokens = (retryFileDownloadInfo.extraInfo != null) ? CommonUtils.getPreAuthTokens(retryFileDownloadInfo.extraInfo.advDetails) : null;
                    boolean isMultiPackage = retryFileDownloadInfo.extraInfo != null && retryFileDownloadInfo.extraInfo.isMultiPackage;
                    ApkInstallUtils.installSilentWithReflection(PalmplayApplication.getAppInstance(), filePath, packageName, true, false, preAuthTokens, isMultiPackage);

                }
            }
        }
    }

    public boolean checkIsAutoInstalling(String mPackageName) {
        InstallRecordInfo installingRecordInfo = installRecordCache.getInstallingRecordInfo(mPackageName);
        if(installingRecordInfo != null){
            return installingRecordInfo.isAuto();
        }
        return true;
    }



    public boolean isInstallFailedPoping() {
        return isInstallFailedPoping;
    }

    public void setInstallFailedPoping(boolean installFailedPoping) {
        isInstallFailedPoping = installFailedPoping;
    }

    public void removeInstallRecordAfterInstallSuceess(String packageName){
        installRecordCache.removeInstallingRecordInfo(packageName);
        installRecordCache.removeInstallFailedRecordInfo(packageName);
    }

    public void removeInstallingRecordInfo(String packageName){
        installRecordCache.removeInstallingRecordInfo(packageName);

    }

    public void removeInstallFailedRecordInfo(String packageName){
        installRecordCache.removeInstallFailedRecordInfo(packageName);
    }
    public InstallRecordInfo getInstallingRecordInfo(String mPackageName) {
        return installRecordCache.getInstallingRecordInfo(mPackageName);
    }

    public void onResumePopInstallFialTips() {
        InstallRecordInfo installRecordInfo = installRecordCache.getTopInstallFialRecordInfo();
        if(installRecordInfo != null){
            FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(installRecordInfo.getPackageName());
            boolean hasNoInstall = true;
            if(fileDownloadInfo != null){
                //已经安装检查版本
                InstalledAppInfo installedAppInfo = InstalledAppManager.getInstance().get(installRecordInfo.getPackageName());
                if(installedAppInfo != null){
                    if(installedAppInfo.versionCode >= fileDownloadInfo.version){
                        hasNoInstall = false;
                    }
                }
            }else {
                hasNoInstall = false;
            }

            if(hasNoInstall){
                InstallFailEngine.onInstallFailProcess(installRecordInfo.getErrorCode(), installRecordInfo.getFialedMsg(), installRecordInfo.getPackageName());
            }else {
                removeInstallFailedRecordInfo(installRecordInfo.getPackageName());
            }
        }
    }

    public void saveToCacheFile() {
        if (null != installRecordCache) {
            String strbuffer = "";
            Gson gson = new Gson();
            strbuffer = gson.toJson(installRecordCache, InstallRecordCache.class);
            saveToCache(strbuffer);
        }
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
        FilePathManager.jsonToFile(jsonBuffer, getFileName());
    }

    @Override
    public void loadFromCache(Object... objects) {
        try {
            JsonObject jsonObject = (JsonObject) FilePathManager.fileToJson(getFileName());
            if (jsonObject != null) {
                Gson gson = new Gson();
                installRecordCache = gson.fromJson(jsonObject, InstallRecordCache.class);
            }
        } catch (Exception e) {
            // TODO: handle exception
            LogUtils.e(e);
        }
        if (null == installRecordCache){
            installRecordCache = new InstallRecordCache();
        }
    }

    @Override
    public String getFileName(Object... objects) {
        return FILE_NAME;
    }

}

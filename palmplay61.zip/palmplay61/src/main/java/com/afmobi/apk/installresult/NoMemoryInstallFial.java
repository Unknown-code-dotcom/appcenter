package com.afmobi.apk.installresult;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.clean.CleanMemoryActivity;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.Constant;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsnet.store.R;

/***
 * 手机内存RAM不足
 */
public class NoMemoryInstallFial extends BaseInstallFail {
    protected NoMemoryInstallFial() {
        super(TYPE_INSTALL_MEMORY_ALLOC_FAIL,INSTALL_MEMORY_ALLOC_FAIL);
    }

    @Override
    int getMsgStrID() {
        return R.string.txt_memory_low_to_clean;
    }


    @Override
    int getBtnConfirmStr() {
        if (isLimitExpireValid) {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_SHOW, null);
            return R.string.txt_boost_now;
        } else {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_OUT_MEMORY_SHOW, null);
            return R.string.txt_i_known;
        }
    }


    @Override
    View.OnClickListener getPositiveBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLimitExpireValid) {
                    //to boost
                    Context ctx = PalmplayApplication.getAppInstance().getApplicationContext();
                    Intent intent = new Intent(ctx, CleanMemoryActivity.class);
                    intent.putExtra(PageParamInfo.class.getSimpleName(), new PageParamInfo(PageConstants.None, PageConstants.SILENCE_INSTALL_FAIL_TIPS));
                    intent.putExtra(Constant.KEY_PACKAGE_NAME, mPackageName);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(intent);

                    SPManager.putLong(Constant.LAST_LOW_MEMORY_CLEAN, System.currentTimeMillis());

                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_CLICK, null);
                } else {

                }
            }
        };
    }

    @Override
    View.OnClickListener getNegativeBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLimitExpireValid) {
                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_CLOSE, null);
                }
            }
        };
    }

    @Override
    boolean checkLimitExpireValid() {
        boolean isValid = false;
        long lastInterval = SPManager.getLong(Constant.LAST_LOW_MEMORY_CLEAN, 0);
        long currInterval = System.currentTimeMillis();
        if (Math.abs(currInterval - lastInterval) >= INSTALL_TO_CLEAN_INTERVAL) {
            isValid = true;
        }
        return isValid;
    }
}

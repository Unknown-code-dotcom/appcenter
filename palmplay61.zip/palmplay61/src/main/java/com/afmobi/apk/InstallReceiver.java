package com.afmobi.apk;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.clean.CleanMemoryActivity;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.download.DownloadHandler;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.slient.SlientDownloadManager;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.main.utils.NotificationLayoutManager;
import com.afmobi.palmplay.main.utils.PSNotificationManager;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.push.TRPushMsgsManager;
import com.afmobi.palmplay.service.dispatch.PalmstoreDownloadHandler;
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler;
import com.afmobi.palmplay.smallpkg.packet.PackedDownloadInfo;
import com.afmobi.palmplay.smallpkg.packet.PackedDownloadManager;
import com.afmobi.palmplay.smallpkg.packet.PackedInterfaceStatusChange;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.afmobi.util.FileUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRReflectConstants;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * 应用静默安装完成广播
 */
public class InstallReceiver extends BroadcastReceiver {

    public static final String SILENT_INSTALL_SUCCEEDED_MSG = "INSTALL_SUCCEEDED";
    public static final String PALMSTORE_SLIENT_INSTALL_ACTION = "com.transsnet.store.action.install";

    public static final long INSTALL_GAP_TIME = 24 * 60 * 60 * 1000;
    public static final String INSTALL_MEMORY_ALLOC_FAIL = "Failed to allocate";
    public static final String INSTALL_SPACE_FAIL = "Not enough space";
    public static final String INSTALL_INCOMPATIBLE_FAIL = "INSTALL_FAILED_UPDATE_INCOMPATIBLE";
    public static final long INSTALL_TO_CLEAN_INTERVAL = 1 * 60 * 60 * 1000;
    public static List<String> uninstallPkgList = new ArrayList<>();
    private static final ConcurrentHashMap<String, Integer> sPendingUserActionCount = new ConcurrentHashMap<>();
    public static final String PA_PACKAGENAME = "com.transsion.plat.appupdate";
    public static final String GP_PACKAGENAME = "com.android.vending";

    @Override
    public void onReceive(Context context, Intent intent) {
        onInstallReceiver(context, intent);
    }

    public static boolean onInstallReceiver(Context context, Intent intent) {
        boolean result = false;
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.LOLLIPOP) {
            return result;
        }
        String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        String pkg = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME);
        String verName = intent.getStringExtra(InstallUtil.VER_NAME);
        int verCode = intent.getIntExtra(InstallUtil.VER_CODE,0);
        String md5 = intent.getStringExtra(InstallUtil.MD5);
        String appFrom = intent.getStringExtra(InstallUtil.APP_FROM);
        String updateType = intent.getStringExtra(InstallUtil.UPDATE_TYPE);
        String fromPage = intent.getStringExtra(InstallUtil.FROM_PAGE);
        boolean isSmallPkg = intent.getBooleanExtra(InstallUtil.IS_INSTALL_SMALL_PKG, false);
        String smallApkPackage = intent.getStringExtra(InstallUtil.SMALL_APK_PACKAGE);
        String downloadedApkFilePath = intent.getStringExtra(InstallUtil.DOWNLOAD_APK_PATH);
        String palmsVersion = intent.getStringExtra(TRAnalyticsConstant.APP_VERSION);
        long orgTime = intent.getLongExtra(TRAnalyticsConstant.TIME,0);
            int statusCode = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_SUCCESS);
        boolean continuousInstall = intent.getBooleanExtra(InstallUtil.PARAM_CONTINUOUS_INSTALL, false);
        int currentIndex = intent.getIntExtra(InstallUtil.PARAM_CURRENT_INDEX, -1);
        String nativeId = intent.getStringExtra(InstallUtil.NATIVEID);
        boolean isMultiPkg = intent.getBooleanExtra(InstallUtil.IS_MULTI_PACKAGE, false);
        // pkg 从多个 extra 中取，提前补全，确保后续所有分支（含 PENDING）都能拿到完整包名
        if (TextUtils.isEmpty(pkg)) {
            pkg = isSmallPkg
                    ? intent.getStringExtra(InstallUtil.SMALL_APK_PACKAGE)
                    : intent.getStringExtra(Constant.KEY_PACKAGE_NAME);
        }

        // Android14+ GP安装保护：弹出系统授权确认弹窗（静默场景不弹窗）
        if (statusCode == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            if (!SlientDownloadManager.FROM_PAGE.equals(fromPage)) {
                Intent confirmIntent;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    confirmIntent = intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class);
                } else {
                    //noinspection deprecation
                    confirmIntent = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                }
                if (confirmIntent != null) {
                    confirmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        context.startActivity(confirmIntent);
                        if (!TextUtils.isEmpty(pkg)) {
                            sPendingUserActionCount.merge(pkg, 1, Integer::sum);
                        }
                    } catch (Exception e) {
                        LogUtils.e("InstallReceiver", "start pending user action failed: " + e.getMessage());
                    }
                }
            } else {
                LogUtils.e("InstallReceiver", "STATUS_PENDING_USER_ACTION in silent mode, pkg=" + pkg + ", skip");
            }
            return false; // 安装尚未完成，等待用户确认后系统重新回调
        }

        ComponentName cp =intent.getComponent();
        if(cp ==null) {
            return result;
        }
        if (TextUtils.isEmpty(pkg)) {
            return result;
        }
        // 用户在 GP 安装保护弹窗中做出了选择（仅非静默场景才写入计数）
        Integer pendingCount = sPendingUserActionCount.get(pkg);
        if (pendingCount != null && pendingCount > 0) {
            if (pendingCount == 1) {
                sPendingUserActionCount.remove(pkg);
            } else {
                sPendingUserActionCount.put(pkg, pendingCount - 1);
            }
            String btnType = (statusCode == PackageInstaller.STATUS_SUCCESS)
                    ? TRAnalyticsConstant.OK
                    : TRAnalyticsConstant.CANCEL;
            trackPendingUserActionClick(pkg, btnType);
        }
        if (VaStaticProxy.isInstantPluginApp(pkg)) {
            // 仅仅通知盒子
            VaStaticProxy.publishHostInstallResult(context, intent);
        }
        result = true;
        String name = TextUtils.isEmpty(smallApkPackage) ? "": smallApkPackage;
        if (TextUtils.isEmpty(msg) || !msg.contains(SILENT_INSTALL_SUCCEEDED_MSG)) {
            if(TextUtils.isEmpty(appFrom)) {
                appFrom = "palmstore";
            }
            try {
                //只用在update情况-记录是否安装失败-failList
                if (Constants.failList != null && !Constants.failList.contains(pkg)) {
                    Constants.failList.add(pkg);
                }
            } catch (Exception e) {
            }
            if(isSmallPkg) {
                //小包体安装失败
                onSmallInstallFailed(context, intent, pkg, msg, name);
            } else {
                updateInstallFailsList(pkg, statusCode);
                FileDownloadInfo info = DownloadManager.getInstance().getDownloadedInfo(pkg);
                Map<String, String> preAuthTokens = (info != null && info.extraInfo != null) ? CommonUtils.getPreAuthTokens(info.extraInfo.advDetails) : null;
                List<String> preAuthTokenList = (preAuthTokens != null && !preAuthTokens.isEmpty())
                        ? new ArrayList<>(preAuthTokens.values()) : null;
                if (preAuthTokenList == null || preAuthTokenList.isEmpty()) {
                    preAuthTokenList = intent.getStringArrayListExtra(InstallUtil.PRE_AUTH_TOKEN);
                }
                TRAnalysticsUtil.trackInstallError(pkg, msg + "_statusCode=" + statusCode, verName, verCode,
                        md5, appFrom,updateType,fromPage,downloadedApkFilePath,palmsVersion,orgTime,nativeId, PhoneDeviceInfo.getCountryCode(), preAuthTokenList, isMultiPkg);
                DownloadStatusManager.getInstance().onAppPackageRemoved(pkg, verCode, FileDownloadInfo.MODIFY_STATUS_FROM_INSTALL_FAILS);
                boolean isCanToast = true;
                FileDownloadInfo currFileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(pkg);
                if (currFileDownloadInfo != null && currFileDownloadInfo.extraInfo != null && currFileDownloadInfo.extraInfo.isInstallFail) {
                    isCanToast = false;
                }
                if (isCanToast) {
                    int msgId = TextUtils.equals(pkg, com.afmobi.palmplay.manager.PalmPlayVersionManager.getMyPackageName()) ? R.string.text_update_failed_status : R.string.silent_install_failed_tips;
                    ToastManager.getInstance().show(context, context.getString(msgId));
                }
                onInstallFailed(context, intent, pkg, msg);
//                deleteInstallFailedApk(pkg, statusCode, msg);

                Uri uri = Uri.parse("package://" + pkg); //no used, only for IntentFilter.addDataScheme()
                Intent i = new Intent(TRReflectConstants.APP_INSTALL_FAILED_ACTION, uri);
                i.putExtra("packageName", pkg);
                try {
                    PalmplayApplication.getAppInstance().sendBroadcast(i);
                } catch (Exception e) {
                    try {
                        i.setPackage(PalmplayApplication.getAppInstance().getPackageName());
                        PalmplayApplication.getAppInstance().sendBroadcast(i);
                    } catch (Exception ignored) {
                    }
                }
                //安装失败-通知
                PalmstoreSysHandler.checkAppDownloadedNotification(PalmplayApplication.getAppInstance());
            }
        } else {
            if(isSmallPkg) {
                //小包体安装成功
                if (pkg.equals("com.android.settings")) {
                    //如果安装的是settings,下一步安装systemUpdate
                    PackedDownloadManager.getInstance().nextSystemUpdateApk(name);
                } else if (pkg.equals("com.transsion.systemupdate")) {
                    //如果安装的是systemupdate，下一步安装其他小包体apk
                    PackedDownloadManager.getInstance().installSmallApkFileList(name, true);
                } else {
                    //安装完成删除apk，进行安装下一个
                    PackedDownloadManager.getInstance().installSmallApkFileList(name, false);
                }
            } else {
                DownloadStatusManager.getInstance().onAppPackageAdded(pkg, verCode);
                // 删除失败列表里的记录
                removePkgFromList(pkg);

                List<FileDownloadInfo> list = DownloadManager.getInstance().getInstalledInfoList();
                if (list != null && list.size() > 0) {
                    for (FileDownloadInfo item : list) {
                        if (item != null && !TextUtils.isEmpty(item.packageName) && TextUtils.equals(item.packageName, pkg)) {
                            if (item.extraInfo != null) {
                                item.extraInfo.isSpaceLimit = false;
                            }
                        }
                    }
                }
            }
        }
        return result;
//        if(continuousInstall){
//            continuousInstallFailedApk(pkg, currentIndex);
//        }
    }

    /**
     * 删除安装失败的apk包，空间不足情况除外
     */
    private static void deleteInstallFailedApk(String pkgName, int statusCode, String msg) {
        if(PackageInstaller.STATUS_FAILURE_STORAGE != statusCode && PackageInstaller.STATUS_FAILURE_CONFLICT != statusCode) {
            FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfo(pkgName);
            if (fileDownloadInfo != null) {
                try {
                    File delFile = new File(FilePathManager.getDownloadedFilePath(fileDownloadInfo));
                    if (delFile.isDirectory()) {
                        FileUtils.deleteAllFiles(delFile);
                    } else {
                        delFile.delete();
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }

                if (PackageInstaller.STATUS_FAILURE_ABORTED == statusCode
                || PackageInstaller.STATUS_FAILURE_BLOCKED == statusCode
                && (TextUtils.isEmpty(msg) || !msg.toLowerCase().contains(INSTALL_SPACE_FAIL.toLowerCase())
                    && msg.toLowerCase().contains(INSTALL_MEMORY_ALLOC_FAIL.toLowerCase())
                    && msg.toLowerCase().contains(INSTALL_INCOMPATIBLE_FAIL.toLowerCase())) ) {

                    DownloadManager.getInstance().removeDownloadedInfo(pkgName);
                }else {
                    fileDownloadInfo.downloadUrl = "";
                    DownloadManager.getInstance().updateDownloadedInfotoDB(fileDownloadInfo);
                }


            }
        }
    }

    /**
     * 循环检查安装之前安装失败的应用
     */
    private static void continuousInstallFailedApk(String currentPackage, int currentIndex) {
        //一次只补装一个包（顺序安装）
        List<FileDownloadInfo> downloadedlist = DownloadManager.getInstance().getShadowDownloadedInfoList();
        String installFailList = InstallReceiver.getInstallFailsList();
        if(TextUtils.isEmpty(installFailList)){
            return;
        }
        if(downloadedlist == null || downloadedlist.size() <= 0) {
            return;
        }
        int index = -1;
        for(int i = 0; i < downloadedlist.size(); i++){
            if(currentPackage.equals(downloadedlist.get(i).packageName)){
                index = i;
                break;
            }
        }
        if(index == -1){//当前应用安装成功
            if(currentIndex == -1){
                return;
            }
            if(currentIndex < downloadedlist.size()){
                realInstall(currentIndex, downloadedlist, installFailList);
            }
        } else { //当前应用安装失败，继续下一个
            if(index + 1 < downloadedlist.size()){
                realInstall(index + 1, downloadedlist, installFailList);
            }
        }

    }

    private static void realInstall(int startIndex, List<FileDownloadInfo> downloadedlist, String installFailList){
        FileDownloadInfo downloadInfo;
        for(int j = startIndex; j < downloadedlist.size(); j++) {
            downloadInfo = downloadedlist.get(j);
            //xx.xx.xx@2,xx.xx.xx@2,
            if(installFailList.contains(downloadInfo.packageName)){
                //只有签名出现冲突和apk损坏的情况才跳过，其他情况仍然尝试重新安装
                if(downloadInfo.extraInfo == null || downloadInfo.extraInfo.noNeedRetry){
                    continue;
                }
                downloadInfo.continuousInstall = true;
                downloadInfo.currentIndex = j;
                DownloadManager.installAfterActive(downloadInfo);
                return;
            }
        }
    }

    public static void handleInstallReceiver(Context context, String pkg, String message, int statusCode) {
        LogUtils.d(LogUtils.TAG_PLUTO, "handleInstallReceiver pkg=" + pkg + " msg=" + message + " statusCode=" + statusCode);
        if (!SILENT_INSTALL_SUCCEEDED_MSG.equals(message)) {
            updateInstallFailsList(pkg, statusCode);
            // 安装时保证Service启动了
            CommonUtils.updateDownloadServiceStatus();
            Message msg = DownloadHandler.getInstance().getHandler().obtainMessage();
            msg.what = PalmstoreDownloadHandler.MSG_APP_SILENT_INSTALL_FINISHED;
            msg.obj = pkg;
            msg.arg1 = 0;
            msg.arg2 = 1;
            DownloadHandler.getInstance().getHandler().sendMessage(msg);
        } else {
            // 删除失败列表里的记录
            removePkgFromList(pkg);
        }
    }
    public static String getInstallFailsList() {
        Object param = TRSharedPreferenceUtils.getParam(TRSharedPreferenceUtils.INSTALL_FAILS_FILE_NAME, TRSharedPreferenceUtils.INSTALL_FAILS_KEY, "");
        String listPkg = "";
        if(param != null) {
            listPkg = (String) param;
        }
        return listPkg;
    }

    public static void removePkgFromList(String pkg) {
        try {
            //只用在update情况-记录是否安装失败的场景-安装成功从failList删除
            if (Constants.failList != null && Constants.failList.contains(pkg)) {
                Constants.failList.remove(pkg);
            }
        } catch (Exception e) {
        }
        String failList = getInstallFailsList();
        if(TextUtils.isEmpty(failList))
            return;
        if(failList.contains(pkg)) {
            String[] failArrays = failList.split(",");
            int size = failArrays.length;
            String[] infoArrs;
            for(int i = 0; i < size; i++) {
                infoArrs = failArrays[i].split("@");
                if(infoArrs[0].equals(pkg)){
                    //xx.xx.xx@2,xx.xx.xx@2,
                    failList.replace(failArrays[i] + ",", "");
                    TRSharedPreferenceUtils.setParam(TRSharedPreferenceUtils.INSTALL_FAILS_FILE_NAME,TRSharedPreferenceUtils.INSTALL_FAILS_KEY, failList);
                    return;
                }
            }
        }
    }

    /**
     * 存储或更新安装失败的包信息
     * @param pkg
     * @param statusCode
     */
    public static void updateInstallFailsList(String pkg, int statusCode) {
        //安装空间时不足的case才记录数据
        if(PackageInstaller.STATUS_FAILURE_STORAGE!=statusCode) {
            return;
        }
        String failList = getInstallFailsList();
        if(TextUtils.isEmpty(failList)) {
            failList = pkg + "@0,";
        } else {
            // 如果安装失败次数超过3次不再发起安装
            String[] failArrays = failList.split(",");
            int size = failArrays.length;
            String[] infoArrs;
            for(int i = 0; i < size; i++) {
                infoArrs = failArrays[i].split("@");
                if(infoArrs[0].equals(pkg)){
                    try {
                        //xx.xx.xx@2,
                        int ret = infoArrs[1].indexOf(",");
                        int end = (ret == -1) ?  (infoArrs[1].length()) : ret;
                        int retryCount = Integer.parseInt(infoArrs[1].substring(0, end));
                        retryCount++;
                        if(retryCount >= 3){
                            //xx.xx.xx@2,xx.xx.xx@2,
                            failList.replace(failArrays[i] + ",", "");
                        } else {
                            failList.replace(failArrays[i], pkg + "@" + retryCount);
                        }
                        TRSharedPreferenceUtils.setParam(TRSharedPreferenceUtils.INSTALL_FAILS_FILE_NAME,TRSharedPreferenceUtils.INSTALL_FAILS_KEY, failList);
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                    return;
                }
            }
            failList = failList + pkg + "@0,";
        }
        TRSharedPreferenceUtils.setParam(TRSharedPreferenceUtils.INSTALL_FAILS_FILE_NAME,TRSharedPreferenceUtils.INSTALL_FAILS_KEY, failList);
    }

    private static void onSmallInstallFailed(Context context, Intent intent, String pkg, String msg, String smallApkName) {
        if(intent == null) {
            LogUtils.d("After silience install catch exception, intent is null,will not show dialog for clean.");
            return;
        }

        int statusCode = intent.getIntExtra(PackageInstaller.EXTRA_STATUS,-1);
        if(PackageInstaller.STATUS_FAILURE_STORAGE == statusCode
                || (!TextUtils.isEmpty(msg) && msg.toLowerCase().contains(INSTALL_SPACE_FAIL.toLowerCase()))) {
            //TODO:存储空间不足 安装失败，显示重试
            ToastManager.getInstance().show(TRApplicationContextUtil.getInstance(), context.getResources().getString(R.string.not_enough_space));

            PackedDownloadManager.getInstance().installFailed(PackedInterfaceStatusChange.SMALLPKG_DOWNLOAD_STATUS_INTALL_RETRY, PackedDownloadManager.INSTALL_FAILED_REASON_1, smallApkName);
        } else if(!TextUtils.isEmpty(msg) && msg.toLowerCase().contains(INSTALL_MEMORY_ALLOC_FAIL.toLowerCase())) {
            //TODO:内存空间不足 安装失败，显示重试
            ToastManager.getInstance().show(TRApplicationContextUtil.getInstance(), context.getResources().getString(R.string.not_enough_space));

            PackedDownloadManager.getInstance().installFailed(PackedInterfaceStatusChange.SMALLPKG_DOWNLOAD_STATUS_INTALL_RETRY, PackedDownloadManager.INSTALL_FAILED_REASON_2, smallApkName);
        } else {
            //如果settings，systemupdate安装失败，删除所有包，直接显示不可更新
            if (pkg.equals("com.android.settings") || pkg.equals("com.transsion.systemupdate")) {
                LogUtils.d("install setting.apk,systemupdate.apk failed");
                PackedDownloadManager.getInstance().deleteCache();
                PackedDownloadManager.getInstance().installFailed(PackedInterfaceStatusChange.SMALLPKG_DOWNLOAD_STATUS_NOT_SUPPORTED_UPDATE, PackedDownloadManager.INSTALL_FAILED_REASON_3, smallApkName);
            } else {
                //安装失败记录
                PackedDownloadInfo downloadTask = PackedDownloadManager.getInstance().getDownloadTask();
                PackedDownloadManager.getInstance().addInstallFailedList(downloadTask.osZipMd5, smallApkName);

                //进行安装下一个apk
                PackedDownloadManager.getInstance().installSmallApkFileList(smallApkName, false);
            }
        }
    }

    private static void onInstallFailed(Context context, Intent intent, final String pkg, String msg) {
        final Activity activity = AtyManager.getAtyManager().getCurrentActivity();
        if(intent == null) {
            LogUtils.d("After silience install catch exception, intent is null,will not show dialog for clean.");
            TRPushMsgsManager.getInstance().trackPushTechUV("InstallFailed", "1", "", "",1, "1");
            return;
        }

        int statusCode = intent.getIntExtra(PackageInstaller.EXTRA_STATUS,-1);
        if(PackageInstaller.STATUS_FAILURE_STORAGE == statusCode
        || (!TextUtils.isEmpty(msg) && msg.toLowerCase().contains(INSTALL_SPACE_FAIL.toLowerCase()))) {
            //TODO:存储空间不足
            CommonUtils.onHandlerDiskSpaceLimit(pkg, Constant.SPACE_LIMIT_INSTALLIING);

        } else if(!TextUtils.isEmpty(msg) && msg.toLowerCase().contains(INSTALL_MEMORY_ALLOC_FAIL.toLowerCase())) {
            //TODO:内存空间不足
            if(activity == null || PhoneDeviceInfo.isBackgrounder()) {
                LogUtils.d("After silience install catch exception, activity is null or is on background,will not show dialog for clean.");
                return;
            }

            String txt_cancel = activity.getString(R.string.text_cancel);
            String txt_title = activity.getString(R.string.txt_install_failed);
            String txt_msg = activity.getString(R.string.txt_memory_low_to_clean);
            String txt_btn = null;
            boolean isFirst = false;
            long lastInterval = SPManager.getLong(Constant.LAST_LOW_MEMORY_CLEAN, 0);
            long currInterval = System.currentTimeMillis();
            if(Math.abs(currInterval - lastInterval) >= INSTALL_TO_CLEAN_INTERVAL) {
                txt_btn = activity.getString(R.string.txt_boost_now);
                isFirst = true;

                FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_SHOW, null);
            }else {
                txt_btn = activity.getString(R.string.txt_i_known);
                isFirst = false;

                FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_OUT_MEMORY_SHOW, null);
            }

            final boolean isNeedClean = isFirst;
            final CustomDialog dialog = new CustomDialog(activity);
            dialog.showOneButtonDialog(
                    new DialogBuilder()
                            .setTitle(txt_title)
                            .setMessage(txt_msg)
                            .setNegativeBtnText(txt_cancel)
                            .setPositiveBtnText(txt_btn)
                            .setPositiveBtnOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    if(isNeedClean) {
                                        //to boost
                                        Context ctx = PalmplayApplication.getAppInstance().getApplicationContext();
                                        Intent intent = new Intent(ctx, CleanMemoryActivity.class);
                                        intent.putExtra(PageParamInfo.class.getSimpleName(), new PageParamInfo(PageConstants.None, PageConstants.SILENCE_INSTALL_FAIL_TIPS));
                                        intent.putExtra(Constant.KEY_PACKAGE_NAME, pkg);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        ctx.startActivity(intent);

                                        SPManager.putLong(Constant.LAST_LOW_MEMORY_CLEAN, System.currentTimeMillis());

                                        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_CLICK, null);
                                    }else {

                                    }

                                }
                            })
                            .setNegativeBtnOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (isNeedClean) {
                                        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_CLOSE, null);
                                    }
                                }
                            })
            );
        } else if(PackageInstaller.STATUS_FAILURE_CONFLICT == statusCode
                || (!TextUtils.isEmpty(msg) && msg.toLowerCase().contains(INSTALL_INCOMPATIBLE_FAIL.toLowerCase()))) {
            //签名冲突，安装失败
            String iconUrl = "";
            FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(pkg);
            if (downloadInfo != null) {
                iconUrl = downloadInfo.iconUrl;
            }
            if(activity == null || PhoneDeviceInfo.isBackgrounder() && !CommonUtils.isNewUser()
                    && NotificationExtKt.isSwitchOpen(TRSharedPreferenceUtils.KV_CONFLICT_SWITCH)) {

                LogUtils.d("After silience install catch exception, activity is null or is on background,will not show dialog for clean.");
                PSNotificationManager.checkCondition(() ->{
                    NotificationLayoutManager.INSTANCE.initNotification(context,NotificationExtKt.getNOTIFY_ID_CONFLICT()).notifyConflict(context,downloadInfo,pkg);
                });
                return;
            } else {
                String error1 = !PhoneDeviceInfo.isBackgrounder() ? "1" : "X";
                String error2 = CommonUtils.isNewUser() ? "1" : "X";
                String error3 = !NotificationExtKt.isSwitchOpen(TRSharedPreferenceUtils.KV_CONFLICT_SWITCH) ? "1" : "X";
                TRPushMsgsManager.getInstance().trackPushTechUV("InstallFailed", "1", "", "",1, error1 + "_" + error2 + "_" + error3);
            }
            showInstallConflictDialog(activity, pkg, iconUrl);
        } else {
            CommonUtils.handleFailedInstallation(pkg, statusCode);
        }
    }

    /**
     * 是否联运游戏
     * */
    private static boolean isCombinedGame(String pkg) {

        boolean result = false;

        if (TextUtils.isEmpty(pkg)) {
            return result;
        }

        try {
            PackageManager pm = PalmplayApplication.getAppInstance().getPackageManager();
            ApplicationInfo info = (pm != null) ? pm.getApplicationInfo(pkg, PackageManager.GET_META_DATA) : null;
            if (info != null && info.metaData != null) {
                String value = info.metaData.getString("game_ad_version");
                if (!TextUtils.isEmpty(value) && value.length() > 0) {
                    result = true;
                }
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return result;
    }

    public static void showInstallConflictDialog(Activity activity, String pkg , String iconUrl) {
        if (activity == null) {
            activity = AtyManager.getAtyManager().getActivity(MainActivity.class);
        }
        if (activity == null || TextUtils.isEmpty(pkg)) {
            return;
        }

        String installerPkg = CommonUtils.getInstalledSourcePackageName(pkg);
        if (TextUtils.equals(installerPkg, PalmplayApplication.getAppInstance().getPackageName())
            || TextUtils.equals(installerPkg, GP_PACKAGENAME)
            || TextUtils.equals(installerPkg, PA_PACKAGENAME)
            || isCombinedGame(pkg)) {
            LogUtils.d("After silience install catch exception, signature is not match, and the apk is combined game or installer is from:" + installerPkg);
            return;
        }

        String txt_cancel = activity.getString(R.string.text_cancel);
        String txt_title = activity.getString(R.string.txt_install_failed_conflict);
        String txt_msg = activity.getString(R.string.txt_conflict_to_reinstall);
        String txt_btn = activity.getString(R.string.text_ok);

        String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.NOTIFICATION_MODULE_CONFLICT, "",  "");
        ComponentExposureBuilder builder = new ComponentExposureBuilder();
        builder.setValue(value)
                .setFrom("")
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackExposure(builder);

        final CustomDialog dialog = new CustomDialog(activity);
        Activity finalActivity = activity;
        dialog.showApkConflictDialog(
                new DialogBuilder()
                        .setTitle(txt_title)
                        .setIconUrl(iconUrl)
                        .setMessage(txt_msg)
                        .setNegativeBtnText(txt_cancel)
                        .setPositiveBtnText(txt_btn)
                        .setPositiveBtnOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                onConflictButtonClick("1");
                                Uri uri = Uri.fromParts("package", pkg, null);
                                Intent intent = new Intent(Intent.ACTION_DELETE, uri);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                try {
                                    finalActivity.startActivity(intent);
                                } catch (Exception e) {
                                    try {
                                        intent.setPackage(pkg);
                                        finalActivity.startActivity(intent);
                                    } catch (Exception ex) {
                                        if (BuildConfig.DEBUG) e.printStackTrace();
                                    }
                                }
                                uninstallPkgList.add(pkg);
                            }
                        })
                        .setNegativeBtnOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                onConflictButtonClick("0");
                            }
                        })
        );
    }

    private static void trackPendingUserActionClick(String pkg, String buttonType) {
        String value = TRStringUtil.generateString(
                TRAnalyticsConstant.HOME_A,
                TRAnalyticsConstant.NOTIFICATION_MODULE_UPDATE,
                "", "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom("")
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(buttonType)
                .setItemValue(pkg)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private static void onConflictButtonClick(String extraValue) {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.NOTIFICATION_MODULE_CONFLICT, "",  "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom("")
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setItemValue("")
                .setExtraValue(extraValue);
        TRAnalysticsUtil.trackClick(builder);
    }

}


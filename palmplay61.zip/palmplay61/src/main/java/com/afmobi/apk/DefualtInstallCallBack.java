package com.afmobi.apk;

import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import com.afmobi.palmplay.download.DownloadHandler;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.service.dispatch.PalmstoreDownloadHandler;
import com.afmobi.util.CommonUtils;
import com.transsion.palmstorecore.log.LogUtils;


public class DefualtInstallCallBack implements InstallUtil.InstallCallback {
    private static final String TAG = "DefualtInstallCallBack";
    static long preTimeMillis = System.currentTimeMillis();
    private String mPackageName;

    public DefualtInstallCallBack(String packageName) {
        this.mPackageName = packageName;
    }

    @Override
    public void onResult(boolean result) {
        if (TextUtils.isEmpty(mPackageName)) {
            return;
        }
        int resultCode = result ? 1 : 0;
        LogUtils.e(TAG, "packageInstalled = " + mPackageName + "; result = " + resultCode);
        long spaceTimeMillis = System.currentTimeMillis() - preTimeMillis;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            DownloadStatusManager.getInstance().onAppSilentInstallFinished(mPackageName, resultCode);
            LogUtils.e(TAG, "回调：主线程调用:" + spaceTimeMillis + ",  时间=" + System.currentTimeMillis());
        } else {
            // 安装时保证Service启动了
            CommonUtils.updateDownloadServiceStatus();

            Message msg = new Message();
            msg.what = PalmstoreDownloadHandler.MSG_APP_SILENT_INSTALL_FINISHED;
            msg.obj = mPackageName;
            msg.arg1 = resultCode;
            DownloadHandler.getInstance().getHandler().sendMessage(msg);
            LogUtils.e(TAG, "回调：子线程调用:" + spaceTimeMillis + ",  时间=" + System.currentTimeMillis());
        }

        if (!TextUtils.isEmpty(mPackageName) && TextUtils.equals(mPackageName, PalmPlayVersionManager.getMyPackageName())) {
            PalmPlayVersionManager.getInstance().setInstalling(false);
        }
    }
}

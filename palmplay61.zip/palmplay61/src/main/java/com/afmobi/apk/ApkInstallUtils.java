package com.afmobi.apk;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import com.afmobi.apk.installresult.InstallRecordManager;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.SimpleDataMap;
import com.afmobi.palmplay.download.DownloadHandler;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.pluto.PlutoCommonConfig;
import com.afmobi.palmplay.service.dispatch.PalmstoreDownloadHandler;
import com.afmobi.palmplay.smallpkg.packet.PackedDownloadInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.PhoneDeviceInfo;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.xapk.XapkUtils;
import com.transsion.xapk.utils.XapkInstaller;
import com.transsnet.store.BuildConfig;

import java.io.File;
import java.util.Map;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

/**
 * Created by liuzhi on 18-1-8.
 */

public class ApkInstallUtils {
    private static final String TAG = "ApkInstallUtils";
    static long preTimeMillis = System.currentTimeMillis();


    //预装渠道不使用辅助功能自动安装
    public static boolean usingSmartInstall(){
        return !CommonUtils.isPreInstalledChannel();
    }

    public static boolean installAppFileCommon(String filePath) {
        boolean ret = false;
        if (filePath != null) {
            File file = new File(filePath);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Uri contentUri = null;
                try {
                    contentUri = FileProvider.getUriForFile(PalmplayApplication.getAppInstance(), Constant.PALMSTORE_FILEPROVIDER, file);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                if (contentUri == null) {
                    return ret;
                }
                intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
            } else {
                intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
            }

            if (PalmplayApplication.getAppInstance().getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                Activity activity = AtyManager.getAtyManager().getCurrentActivity();
                if (activity != null && !activity.isFinishing()) {
                    try {
                        activity.startActivity(intent);
                        ret = true;
                    } catch (Exception e) {
                        LogUtils.e(TAG, e.getMessage());
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                } else {
                    try {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        PalmplayApplication.getAppInstance().startActivity(intent);
                        ret = true;
                    }catch(Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
            }
        }

        return ret;
    }


    public static void updateStatusInfo(String packageName,boolean sendMsg) {

        if (Looper.myLooper() == Looper.getMainLooper() && !sendMsg) {
            DownloadStatusManager.getInstance().onAppSilentInstalling(packageName);
            LogUtils.e(TAG, "主线程调用:" + preTimeMillis);
        } else {
            Message msg = DownloadHandler.getInstance().getHandler().obtainMessage();
            msg.what = PalmstoreDownloadHandler.MSG_APP_SILENT_INSTALLING;
            msg.obj = packageName;
            DownloadHandler.getInstance().getHandler().sendMessage(msg);
            LogUtils.e(TAG, "子线程调用" + preTimeMillis);
        }

        if(!TextUtils.isEmpty(packageName) && TextUtils.equals(packageName, PalmPlayVersionManager.getMyPackageName())){
            PalmPlayVersionManager.getInstance().setInstalling(true);
        }
    }

    public static void installSmallPkg(Context context, String apkPath, final Map<String, String> preAuthTokens) {
        boolean silentInstlling = isUsingSilentInstall();
        if (silentInstlling) {
            if (ThreadHelper.isUiThread()) {
                ThreadHelper.runOnWorkThread(new Runnable() {
                    @Override
                    public void run() {
                        boolean success = InstallUtil.pmInstall(PalmplayApplication.getPalmplayApplicationInstance(), apkPath, true, preAuthTokens);

                    }
                });
            } else {
                boolean result = InstallUtil.pmInstall(PalmplayApplication.getPalmplayApplicationInstance(), apkPath, true, preAuthTokens);
//                if (callback != null) {
//                    callback.onResult(result);
//                }
            }
        } else {
            //没有静默安装权限，显示暂不支持更新

        }
    }

    public static boolean pmInstallSmallPkg(Context ctx, PackedDownloadInfo info, String zipFilePath, String md5, int installType) {
        return XapkInstaller.installSmallPkgApk(ctx, zipFilePath, md5, installType);
    }

    public static boolean installSilentWithReflection(Context context, String filePath, final String packageName, boolean isPlutoOffer, boolean isSubPakcage, Map<String, String> preAuthTokens, boolean isMultiPackage) {
        return installSilentWithReflection(context, filePath, packageName, false, isPlutoOffer, isSubPakcage, preAuthTokens, isMultiPackage);
    }


    public static boolean installSilentWithReflection(Context context, String filePath, final String packageName, boolean isAuto, boolean isPlutoOffer, boolean isSubPackage, Map<String, String> preAuthTokens, boolean isMultiPackage) {
        boolean silentInstlling = false;
        boolean needCallInstall = false;
        preTimeMillis = System.currentTimeMillis();
        // 安装时保证Service启动了
        if (!PalmPlayVersionManager.getMyPackageName().equals(packageName)) {
            CommonUtils.updateDownloadServiceStatus();
        }

        silentInstlling = isUsingSilentInstall();

        InstallRecordManager.getInstance().addIntallingrecord(packageName, isAuto);

        FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(packageName);
        String fromPage = SimpleDataMap.KEY_INSTALL_SOURCE_AUTO;
        if(downloadInfo!=null) {
            fromPage = downloadInfo.fromPage;
            String versionName = downloadInfo.extraInfo!=null ? downloadInfo.extraInfo.dlVer : "";
            long time = downloadInfo.extraInfo!=null ? downloadInfo.extraInfo.time : 0;
            TRAnalysticsUtil.trackInstallAndDownloadStatus(TRAnalyticsConstant.REPORT_SCENE_5,downloadInfo.fromPage,
                    packageName,downloadInfo.itemID, downloadInfo.version,versionName,""+time, PhoneDeviceInfo.getCountryCode());
        }


        if (!TextUtils.isEmpty(filePath)) {
            SimpleDataMap.INSTANCE.getInstallSourceMap().put(filePath, fromPage);
        }
        if(silentInstlling){
            InstallUtil.tryInstall(filePath, new DefualtInstallCallBack(packageName), packageName, isSubPackage, preAuthTokens, isMultiPackage);
            updateStatusInfo(packageName,true);
        } else if(AppDataManager.canUsedPluto4Features() && isPlutoOffer && PlutoCommonConfig.getInstance().canCallExternalInstall()) {
            // todo 开始告知AppUpdate协助静默安装
            File file = new File(filePath);
            LogUtils.d(LogUtils.TAG_PLUTO,"isPlutoOffer="+isPlutoOffer + " filePath: "+filePath);
            if(!file.exists()) {
                return silentInstlling;
            }
            String pkg = PalmIpcServiceManager.getBindServicePakcage(PalmplayApplication.getAppInstance());

            if(TextUtils.isEmpty(pkg)) {
                needCallInstall = true;
//                installAppFileCommon(filePath);
            } else {

                Uri contentUri = null;
                try {
                    contentUri = FileProvider.getUriForFile(PalmplayApplication.getAppInstance(), Constant.PALMSTORE_FILEPROVIDER, file);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                if (contentUri == null) {
                    return silentInstlling;
                }

                PalmplayApplication.getAppInstance().grantUriPermission(pkg,contentUri,Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                updateStatusInfo(packageName,true);
                if(PalmIpcServiceManager.getInstance().callPalmSInstall(contentUri.toString(),filePath,packageName)) {

                } else {
                    DownloadStatusManager.getInstance().palmAinstallFinished(packageName,0);
                    needCallInstall = true;
//                    installAppFileCommon(filePath);
                }
            }
        } else{
//            installAppFileCommon(filePath);
            needCallInstall = true;
        }

        if(needCallInstall) {
            Intent intent = InstallUtil.getIntent(context, filePath, packageName,isSubPackage, preAuthTokens, isMultiPackage);
            XapkUtils.installAppPackage(context, filePath, isSubPackage, PalmplayApplication.mHasSlientPermission, intent, preAuthTokens, isMultiPackage);
        }
        //20180803 6.8.1统计客户端升级来源
        if(!TextUtils.isEmpty(packageName) && TextUtils.equals(packageName, PalmPlayVersionManager.getMyPackageName())){
            SPManager.putString(Constant.preferences_key_oldclient_update_from, Constant.UPDATE_FROM_ITEMUPDATE);
        }
        return silentInstlling;
    }


    public static boolean isUsingSilentInstall(){
        boolean usingSilentInstall = PalmplayApplication.mHasSlientPermission;//hasSilenceInstallPermission(PalmplayApplication.getAppInstance());

        return usingSilentInstall;
    }

    public static boolean isSystemApp(Context context){
        if ((context.getApplicationInfo().flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
            if (LogUtils.debug) {
                LogUtils.d(TAG, "是系统应用");
            }
            return true;
        }

        if (LogUtils.debug) {
            LogUtils.d(TAG, "非系统应用");
        }
        return false;
    }


    public static boolean hasSilenceInstallPermission(Context context){
        if(isSystemApp(context)){
            boolean has = (ContextCompat.checkSelfPermission(context,  Manifest.permission.INSTALL_PACKAGES) == PackageManager.PERMISSION_GRANTED);
            if (LogUtils.debug) {
                if (has) {
                    LogUtils.d(TAG, "具备静默安装能力");
                }
            }
            return has;
        }else{
            return false;
        }
    }

    public static void onTryInstallApkByPackageName(String pkgName) {
        if(!TextUtils.isEmpty(pkgName)) {
            FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(pkgName);
            if(downloadInfo == null) {
                return;
            }

            String filePath = FilePathManager.getDownloadedFilePath(downloadInfo);
            File file = new File(filePath);
            if(file!=null && !file.exists()) {
                filePath = FilePathManager.getDownloadedFilePathForOldVersion(downloadInfo);
                File oldPathFile = new File(filePath);
                if(!oldPathFile.exists()) {
                    filePath = FilePathManager.getDownloadingTempFilePath(downloadInfo);
                    File tempPathFile = new File(filePath);
                    if(!tempPathFile.exists()) {
                        return;
                    }
                }
            }
            boolean isSubPackage = false;
            Map<String, String> preAuthTokens = null;
            boolean isMultiPackage = false;
            if(downloadInfo.extraInfo!=null) {
                isSubPackage = downloadInfo.extraInfo.isSubPackage;
                preAuthTokens = CommonUtils.getPreAuthTokens(downloadInfo.extraInfo.advDetails);
                isMultiPackage = downloadInfo.extraInfo.isMultiPackage;
            }
            ApkInstallUtils.installSilentWithReflection(PalmplayApplication.getAppInstance().getApplicationContext(), filePath, downloadInfo.packageName, false, isSubPackage, preAuthTokens, isMultiPackage);
        }
    }
}

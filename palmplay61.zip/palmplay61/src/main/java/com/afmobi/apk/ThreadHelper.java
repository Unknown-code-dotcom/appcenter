package com.afmobi.apk;


import android.os.Looper;


import com.store.component.thread.PsSchedulers;
import com.transsnet.store.BuildConfig;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Scheduler;

public class ThreadHelper {

    public static boolean isUiThread() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    public static void runOnWorkThread(Runnable runnable) {
        Observable.fromCallable(() -> {
                    runnable.run();
                    return 0;
                }).subscribeOn(PsSchedulers.io())
                .doOnError(throwable -> {
                    if (BuildConfig.DEBUG) {
                        throwable.printStackTrace();
                    }
                }).onErrorComplete()
                .subscribe();
    }

    public static void runOnWorkThread(Runnable runnable, Scheduler scheduler) {
        Observable.fromCallable(() -> {
                    runnable.run();
                    return 0;
                }).subscribeOn(scheduler)
                .doOnError(throwable -> {
                    if (BuildConfig.DEBUG) {
                        throwable.printStackTrace();
                    }
                })
                .subscribe();
    }

}

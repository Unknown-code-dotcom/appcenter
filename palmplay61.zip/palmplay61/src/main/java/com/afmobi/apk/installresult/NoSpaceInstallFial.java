package com.afmobi.apk.installresult;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.clean.CleanNativeMemoryActivity;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.Constant;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsnet.store.R;

/***
 * 手机存储空间不足
 */
public class NoSpaceInstallFial extends BaseInstallFail {
    public NoSpaceInstallFial(int errorCode) {
        super(TYPE_INSTALL_SPACE_FAIL, INSTALL_SPACE_FAIL, errorCode);
    }

    @Override
    int getMsgStrID() {
        return R.string.txt_space_low_to_clean;
    }

    @Override
    int getBtnConfirmStr() {
        if (isLimitExpireValid) {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_CLEAN_GUIDE_SHOW, null);
            return R.string.txt_clean_now;
        } else {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_NO_ENOUGH_SPACE_SHOW, null);
            return R.string.txt_i_known;
        }
    }

    @Override
    View.OnClickListener getPositiveBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLimitExpireValid) {
                    //to clean
                    Context ctx = PalmplayApplication.getAppInstance().getApplicationContext();
                    Intent intent = new Intent(ctx, CleanNativeMemoryActivity.class);
                    intent.putExtra(PageParamInfo.class.getSimpleName(), new PageParamInfo(PageConstants.None, PageConstants.SILENCE_INSTALL_FAIL_TIPS));
                    intent.putExtra(Constant.KEY_PACKAGE_NAME, mPackageName);
                    Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                    if (null != mainActivity) {
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivity(intent);
                    } else {
                        Intent firstIntent = new Intent(ctx, MainActivity.class);
                        firstIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivities(new Intent[]{firstIntent, intent});
                    }

                    SPManager.putLong(Constant.LAST_LOW_SPACE_CLEAN, System.currentTimeMillis());

                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_CLEAN_GUIDE_CLICK, null);
                } else {

                }
            }
        };
    }

    @Override
    View.OnClickListener getNegativeBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLimitExpireValid) {
                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_CLEAN_GUIDE_CLOSE, null);
                }
            }
        };
    }

    @Override
    boolean checkLimitExpireValid() {
        boolean isValid = false;
        long lastInterval = SPManager.getLong(Constant.LAST_LOW_SPACE_CLEAN, 0);
        long currInterval = System.currentTimeMillis();
        if (Math.abs(currInterval - lastInterval) >= INSTALL_TO_CLEAN_INTERVAL) {
            isValid = true;
        }
        return isValid;
    }
}

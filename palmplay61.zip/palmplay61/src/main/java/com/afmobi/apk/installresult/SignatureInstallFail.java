package com.afmobi.apk.installresult;

import android.view.View;

import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.transsnet.store.R;
/***
 * 安装签名问题导致失败
 */
public class SignatureInstallFail extends BaseInstallFail {
    public SignatureInstallFail() {
        super(TYPE_INSTALL_UDPATE_SIGNATURES_FAIL, INSTALL_UDPATE_SIGNATURES_FAIL);
    }

    @Override
    int getMsgStrID() {
        return R.string.txt_signature_install_failed;
    }

    @Override
    int getBtnConfirmStr() {
        return R.string.txt_uninstall_reinstall;
    }

    @Override
    public void onInstallFail(int errorCode, String errorMsg, String appPackageName) {
//        super.onInstallFail(errorCode, errorMsg, appPackageName);
        InstalledAppInfo installedAppInfo = InstalledAppManager.getInstance().getInstalledAppInfoByKey(appPackageName);
        if(installedAppInfo != null && installedAppInfo.isSystemApp){
            //系统应用不需要处理失败
        }else {
            super.onInstallFail(errorCode, errorMsg, appPackageName);
        }

        //不需要重新检查安装
        FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(appPackageName);
        if(fileDownloadInfo != null && fileDownloadInfo.extraInfo != null){
            fileDownloadInfo.extraInfo.noNeedRetry = true;
        }
        DownloadManager.getInstance().updateDownloadedInfotoDB(fileDownloadInfo);
    }

    @Override
    View.OnClickListener getPositiveBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadDecorator.uninstallApp(mPackageName);
            }
        };
    }

    @Override
    View.OnClickListener getNegativeBtnOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLimitExpireValid) {
//                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_BOOST_GUIDE_CLOSE, null);
                }
            }
        };
    }

    @Override
    boolean checkLimitExpireValid() {
        return false;
    }
}

package com.afmobi.apk.installresult;

import android.app.Activity;
import android.content.DialogInterface;
import android.view.View;

import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.util.PhoneDeviceInfo;
import com.transsion.palmstorecore.log.LogUtils;

public class InstallFialDialogBuilder {
    private String mStrCancel;
    private String mStrTitle;
    private String mStrMsg;
    private String mStrConfirm;
    private View.OnClickListener mPositiveBtnOnClickListener;
    private View.OnClickListener mNegativeBtnOnClickListener;

    public InstallFialDialogBuilder setStrCancel(String strCancel) {
        this.mStrCancel = strCancel;
        return this;
    }

    public InstallFialDialogBuilder setStrTitle(String strTitle) {
        this.mStrTitle = strTitle;
        return this;
    }

    public InstallFialDialogBuilder setStrMsg(String trMsg) {
        this.mStrMsg = trMsg;
        return this;
    }

    public InstallFialDialogBuilder setStrConfirm(String strConfirm) {
        this.mStrConfirm = strConfirm;
        return this;
    }

    public InstallFialDialogBuilder setPositiveBtnOnClickListener(View.OnClickListener positiveBtnOnClickListener) {
        this.mPositiveBtnOnClickListener = positiveBtnOnClickListener;
        return this;
    }

    public InstallFialDialogBuilder setNegativeBtnOnClickListener(View.OnClickListener negativeBtnOnClickListener) {
        this.mNegativeBtnOnClickListener = negativeBtnOnClickListener;
        return this;
    }

    public void showInstallFialDialog() {
        final Activity activity = AtyManager.getAtyManager().getCurrentActivity();
        if (activity == null || PhoneDeviceInfo.isBackgrounder()) {
            LogUtils.d("After silience install catch exception, activity is null or is on background,will not show dialog for clean.");
            return;
        }
        InstallRecordManager.getInstance().setInstallFailedPoping(true);
        final CustomDialog dialog = new CustomDialog(activity);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                InstallRecordManager.getInstance().setInstallFailedPoping(false);
            }
        });
        dialog.showOneButtonDialog(
                new DialogBuilder()
                        .setTitle(mStrTitle)
                        .setMessage(mStrMsg)
                        .setNegativeBtnText(mStrCancel)
                        .setPositiveBtnText(mStrConfirm)
                        .setPositiveBtnOnClickListener(mPositiveBtnOnClickListener)
                        .setNegativeBtnOnClickListener(mNegativeBtnOnClickListener)
        );
    }

//    private abstract
}

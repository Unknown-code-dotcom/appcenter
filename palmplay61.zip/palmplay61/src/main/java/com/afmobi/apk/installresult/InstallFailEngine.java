package com.afmobi.apk.installresult;

import android.content.pm.PackageInstaller;

import java.util.ArrayList;
import java.util.List;

public class InstallFailEngine implements InstallFailCallBack {
    private List<BaseInstallFail> mInstallFialList;

    public static void onInstallFailProcess(int errorCode, String errorMsg, String appPackageName){
        new InstallFailEngine().onInstallFail(errorCode, errorMsg, appPackageName);
    }

    private InstallFailEngine() {
        this.mInstallFialList = new ArrayList<>();
        mInstallFialList.add(new NoSpaceInstallFial(PackageInstaller.STATUS_FAILURE_STORAGE));
        mInstallFialList.add(new NoMemoryInstallFial());
        mInstallFialList.add(new ApkIssuesInstallFail());
        mInstallFialList.add(new SignatureInstallFail());
    }

    @Override
    public void onInstallFail(int errorCode, String errorMsg, String appPackageName) {
        for (BaseInstallFail baseInstallFail : mInstallFialList) {
            if (baseInstallFail.isConditionMatch(errorCode, errorMsg, appPackageName)) {
                baseInstallFail.onInstallFail(errorCode, errorMsg, appPackageName);
                break;
            }
        }
    }
}

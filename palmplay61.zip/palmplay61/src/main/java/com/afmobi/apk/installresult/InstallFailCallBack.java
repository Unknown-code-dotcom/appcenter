package com.afmobi.apk.installresult;

public interface InstallFailCallBack {
    void onInstallFail(int errorCode, String errorMsg, String appPackageName);
}

package com.afmobi.apk.installresult;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.appmanage.ManageDownloadActivity;
import com.afmobi.palmplay.appmanage.ManageUpdateActivity;
import com.afmobi.palmplay.appmanage.v2.ManageDownloadV2Activity;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.offer.TROfferListsManager;
import com.afmobi.palmplay.setting.UpdateActivity;
import com.afmobi.util.PhoneDeviceInfo;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.R;


public abstract class BaseInstallFail implements InstallFailCallBack {
    public static final int TYPE_INSTALL_MEMORY_ALLOC_FAIL = 1;
    public static final int TYPE_INSTALL_SPACE_FAIL = 2;
    public static final int TYPE_INSTALL_UDPATE_SIGNATURES_FAIL = 3;
    public static final int TYPE_INSTALL_APK_ISSUES_FAIL = 4;

    public static final long INSTALL_TO_CLEAN_INTERVAL = 1 * 60 * 60 * 1000;
    public static final String INSTALL_MEMORY_ALLOC_FAIL = "Failed to allocate";
    public static final String INSTALL_SPACE_FAIL = "Not enough space";
    public static final String INSTALL_UDPATE_SIGNATURES_FAIL = "signatures do not match";
    public static final String INSTALL_APK_ISSUES_FAIL = "apk file parse error";
    public static final int INVALID_ERRORCODE = 0;
    private int mErrorCode;
    private String mKeyMsg;
    protected boolean isLimitExpireValid = true;
    protected String mPackageName;
    protected int installFailType;

    protected BaseInstallFail(int failType,String keyMsg) {
        this.installFailType = failType;
        this.mKeyMsg = keyMsg;
        this.mErrorCode = INVALID_ERRORCODE;
    }

    protected BaseInstallFail(int failType,String keyMsg, int errorCode) {
        this.installFailType = failType;
        this.mKeyMsg = keyMsg;
        this.mErrorCode = errorCode;
    }

    public boolean isConditionMatch(int errorCode, String errorMsg, String appPackageName) {
        if ((errorCode != INVALID_ERRORCODE && mErrorCode == errorCode)
                || (!TextUtils.isEmpty(errorMsg) && !TextUtils.isEmpty(mKeyMsg) && errorMsg.toLowerCase().contains(mKeyMsg.toLowerCase()))) {
            return true;
        }
        return false;
    }

    @Override
    public void onInstallFail(int errorCode, String errorMsg, String appPackageName) {
        mPackageName = appPackageName;
        if(TextUtils.isEmpty(mPackageName)){
            return;
        }

        final Activity activity = AtyManager.getAtyManager().getCurrentActivity();
        //下载管理页面和更新管理也才会弹框
        boolean isValid = false;
        //是否手动点击, 手动安装：任何界面都可以弹框； 自动安装只能在更新管理页面和下载管理页面才能安装
        boolean isAuto = InstallRecordManager.getInstance().checkIsAutoInstalling(mPackageName);
        if(activity != null && !PhoneDeviceInfo.isBackgrounder()){
            if (isAuto){
                // 下载管理页重构后需要加入ManageDownloadV2Activity
                if (activity instanceof ManageUpdateActivity
                        || activity instanceof ManageDownloadActivity
                        || activity instanceof ManageDownloadV2Activity) {
                    isValid = true;
                }
            }else {
                isValid = true;
            }
        }
        //是否正在弹框中，正在弹框中或者不满足条件加入失败队里，后续处理
        boolean isInstallFailedPoping = InstallRecordManager.getInstance().isInstallFailedPoping();
        boolean isNoticeDialogShowing = TROfferListsManager.isNoticeDialogShowing();
        boolean isPalmstoreUpdateShowing = activity instanceof UpdateActivity;

        if (!isValid || isInstallFailedPoping || isNoticeDialogShowing || isPalmstoreUpdateShowing/*activity == null || PhoneDeviceInfo.isBackgrounder()*/) {
            LogUtils.d(LogUtils.TAG_INSTALL, "After silience install catch exception, activity is null or is on background,will not show dialog for clean.");
            if(installFailType == TYPE_INSTALL_APK_ISSUES_FAIL || installFailType == TYPE_INSTALL_UDPATE_SIGNATURES_FAIL){
                InstallRecordManager.getInstance().addIntalledFialrecord(installFailType, mPackageName, mErrorCode, mKeyMsg);
            }
            return;
        }

        if(installFailType == TYPE_INSTALL_APK_ISSUES_FAIL || installFailType == TYPE_INSTALL_UDPATE_SIGNATURES_FAIL){
            InstallRecordManager.getInstance().addShowTipsRecord(installFailType,mPackageName, mErrorCode, mKeyMsg);
        }

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(appPackageName);
                if (fileDownloadInfo != null && fileDownloadInfo.extraInfo != null && !fileDownloadInfo.extraInfo.blockPop) {
                    showPopTipsDialog(activity);
                }
            }
        },1000L);

    }

    private void showPopTipsDialog(Activity curActivity) {


        isLimitExpireValid = checkLimitExpireValid();

        InstallFialDialogBuilder installFialDialogBuilder = new InstallFialDialogBuilder()
                .setStrTitle(getTitleStr(curActivity))
                .setStrMsg(curActivity.getString(getMsgStrID()))
                .setStrCancel(getBtnCancelStr(curActivity))
                .setStrConfirm(curActivity.getString(getBtnConfirmStr()))
                .setPositiveBtnOnClickListener(getPositiveBtnOnClickListener())
                .setNegativeBtnOnClickListener(getNegativeBtnOnClickListener());

        installFialDialogBuilder.showInstallFialDialog();
    }


    String getTitleStr(Context context) {
        return context.getString(R.string.txt_install_failed);
    }

    String getBtnCancelStr(Context context) {
        return context.getString(R.string.text_cancel);
    }


    abstract int getMsgStrID();

    abstract int getBtnConfirmStr();

    abstract View.OnClickListener getPositiveBtnOnClickListener();

    abstract View.OnClickListener getNegativeBtnOnClickListener();

    abstract boolean checkLimitExpireValid();
}

package com.afmobi.apk;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.text.TextUtils;

import com.afmobi.apk.installresult.InstallFailEngine;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.download.DownloadHandler;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.service.dispatch.PalmstoreDownloadHandler;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.transsion.appupdate.ipc.IInstallFinishListener;
import com.transsion.appupdate.ipc.IPalmIpcAidlInterface;
import com.transsion.dialog.service.*;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

/**
 * PalmS与其他产品IPC通讯管理类
 */
public class PalmIpcServiceManager {

    private static final String TAG = PalmIpcServiceManager.class.getSimpleName();

    private IPalmIpcAidlInterface mPalmIpcService = null;

    public static volatile PalmIpcServiceManager mInstance;

    private static volatile String BIND_SERVICE_NAME = "";

    private static final String CHANNEL = "palmstore";

    private static final int PALMA_BASE_4X_VER = 452300;

    private static final int PALMA_BASE_3X_VER = 320;
    private static final String PACKAGE_NAME_4X =  "com.transsion.plat.appupdate";
    private static final String PACKAGE_NAME_3X =  "com.transsion.appupdate";
    public static final String[] GRANT_URI_PACKAGES ={PACKAGE_NAME_4X ,PACKAGE_NAME_3X};

    private volatile boolean isBinding = false;

    private volatile boolean isPlutoBinding = false;
    private IDialogStatusAidl mPalmPlutoService = null;  // bind PalmA for pluto
    private static final String CLASS_NAME_FOR_PLUTO = "com.transsion.commonlib.dialogstatus.DialogStatusService";

    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LogUtils.d(LogUtils.TAG_PLUTO,"service connected");
            try {
                //设置死亡代理
                service.linkToDeath(mDeathRecipient, 0);
            } catch (RemoteException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            mPalmIpcService = IPalmIpcAidlInterface.Stub.asInterface(service);
        }

        @Override
        public void onBindingDied(ComponentName name) {

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            LogUtils.d(LogUtils.TAG_PLUTO,"service disconnected");
            mPalmIpcService = null;
        }
    };

    private IBinder.DeathRecipient mDeathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
            LogUtils.d(LogUtils.TAG_PLUTO,"service binderDied");
            //解绑
            if (mPalmIpcService != null) {
                mPalmIpcService.asBinder().unlinkToDeath(mDeathRecipient, 0);
                mPalmIpcService = null;
            }
            attemptToBindService(PalmplayApplication.getAppInstance());
        }
    };

    private ServiceConnection mPlutoServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LogUtils.d(LogUtils.TAG_PLUTO,"pluto service connected");
            try {
                //设置死亡代理
                service.linkToDeath(mPlutoDeathRecipient, 0);
            } catch (RemoteException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            mPalmPlutoService = IDialogStatusAidl.Stub.asInterface(service);
        }

        @Override
        public void onBindingDied(ComponentName name) {

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            LogUtils.d(LogUtils.TAG_PLUTO,"pluto service disconnected");
            mPalmPlutoService = null;
        }
    };

    private IBinder.DeathRecipient mPlutoDeathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
            LogUtils.d(LogUtils.TAG_PLUTO,"pluto service binderDied");
            //解绑
            if (mPalmPlutoService != null) {
                mPalmPlutoService.asBinder().unlinkToDeath(mPlutoDeathRecipient, 0);
                mPalmPlutoService = null;
            }
            bindPlutoService(PalmplayApplication.getAppInstance());
        }
    };



    public static PalmIpcServiceManager getInstance() {
        if (mInstance == null) {
            synchronized (PalmIpcServiceManager.class) {
                if (mInstance == null) {
                    mInstance = new PalmIpcServiceManager();
                }
            }
        }
        return mInstance;
    }

    public PalmIpcServiceManager() {
        init();
    }

    private void init() {

    }

    /**
     * 通知palmA更新监听状态
     * @param enable
     */
    public void updateMonitorInfo(boolean enable,long curTime,long gap) {
        if(PalmplayApplication.mHasSlientPermission) {
            return;
        }
        LogUtils.d(LogUtils.TAG_PLUTO,"updateMonitorInfo enable="+enable + " curTime: "+curTime+" gap="+gap);
        if(mPalmIpcService!=null) {
            try {
                mPalmIpcService.startMonitoringScreenOn(enable,curTime,gap,CHANNEL);
                TRAnalysticsUtil.plutoFourDev(TRAnalyticsConstant.EVENT_REQUEST_CHECK,null);
            } catch (RemoteException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        } else {
            LogUtils.d(LogUtils.TAG_PLUTO,"mPalmIpcService is null");
            reBindServiceAndDoRunUpdateMonitor(enable,curTime,gap);
        }
    }

    public boolean callPalmSInstall(String uri,String apkPath,String pkg) {
        boolean result = false;
        if(PalmplayApplication.mHasSlientPermission) {
            return result;
        }
        LogUtils.d(LogUtils.TAG_PLUTO,"callPalmSInstall pkg="+pkg + " uri: "+uri+" mPalmIpcService="+mPalmIpcService);
        if(mPalmIpcService!=null) {
            try {
                result = true;
                TRAnalysticsUtil.plutoFourDev(TRAnalyticsConstant.EVENT_REQUEST_INSTALL,pkg);

                mPalmIpcService.startInstallPalmSApk(uri,apkPath,pkg,CHANNEL,new InstallCallBackFromPalmA(pkg));

            } catch (RemoteException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
                result = false;
            } catch (Exception e) {
                result = false;
            }
        } else {
            reBindServiceAndDoRunInstall(uri,apkPath,pkg);
        }
        return result;
    }

    /**
     * 获取PalmA包名，用于静默安装服务
     * @param context
     * @return
     */
    public static String getBindServicePakcage(Context context) {
        if(!TextUtils.isEmpty(BIND_SERVICE_NAME)) {
            return BIND_SERVICE_NAME;
        }
        // 4期开关控制
        if(!AppDataManager.canUsedPluto4Features()) {
            LogUtils.d(LogUtils.TAG_PLUTO,"Pluto 4 is closed");
            return BIND_SERVICE_NAME;
        }
        for(String pkg:GRANT_URI_PACKAGES) {
            PackageInfo pm = InstalledAppManager.getInstance().getPackageInfo(context, pkg);
            if(pm!=null) {
                LogUtils.d(LogUtils.TAG_PLUTO,"PalmA version is: "+pm.versionName+" code="+pm.versionCode);
                if(TextUtils.equals(pkg,PACKAGE_NAME_4X) && pm.versionCode<PALMA_BASE_4X_VER) {
                    return null;
                } else if(TextUtils.equals(pkg,PACKAGE_NAME_3X) && pm.versionCode<PALMA_BASE_3X_VER) {
                    return null;
                }
                BIND_SERVICE_NAME = pkg;
                break;
            }
        }
        return BIND_SERVICE_NAME;

    }

    /**
     * 尝试与服务端建立连接 For静默安装
     */
    public boolean attemptToBindService(Context context) {
        boolean status = false;
        if(isBinding == true) {
            LogUtils.d(LogUtils.TAG_PLUTO,"is binding now");
            return false;
        }
        if(PalmplayApplication.mHasSlientPermission) {
            LogUtils.d(LogUtils.TAG_PLUTO,"has slientpermission not must connect");
            return false;
        }
        Intent intent = new Intent();
        intent.setAction("com.transsion.palmipcservice");
        isBinding = true;
        String packageName = getBindServicePakcage(context);
        if(TextUtils.isEmpty(packageName)) {
            LogUtils.d(LogUtils.TAG_PLUTO,"mPalmIpcService no connect");
            isBinding = false;
            return false;
        }

        try {
            status = context.bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
        } catch (Exception e) {
            try {
                intent.setPackage(packageName);
                status = context.bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
            } catch (Exception ignored) {
            }
        }
        LogUtils.d(LogUtils.TAG_PLUTO,"mPalmIpcService connect status="+status);
        isBinding = false;
        return status;
    }

    private void reBindServiceAndDoRunUpdateMonitor(final boolean enable,final long curTime,final long gap) {
        boolean bindSuccessed = attemptToBindService(PalmplayApplication.getAppInstance());
        if(!bindSuccessed) {
            LogUtils.d(LogUtils.TAG_PLUTO,"reBindServiceAndDoRunUpdateMonitor connect status="+bindSuccessed);
            return ;
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //断开重新绑定
                updateMonitorInfo(enable,curTime,gap);
            }
        },500);
    }

    private void reBindServiceAndDoRunInstall(final String uri,final String apkPath,final String pkg) {
        attemptToBindService(PalmplayApplication.getAppInstance());
    }

    public boolean isIpcServiceLive() {
        return mPalmIpcService==null ? false : true;
    }

    public void attemptToUnbindService(Context context) {
        if (mServiceConnection != null) {
            context.unbindService(mServiceConnection);
        }
    }

    /**
     * 查询PalmA是否可弹窗
     * @return
     */
    public boolean isCanShowPlutoDialog() {
        boolean isCanShow = true;
        boolean bindStatus = false;
        if(!isPlutoServiceLive()) {
            // 服务没绑定，尝试1次绑定
            bindStatus = bindPlutoService(PalmplayApplication.getAppInstance());
            if(!bindStatus) {
                // todo 绑定失败可能PalmA版本不支持交互，默认支持可弹窗。目前PalmA不能给出支持交互的版本，只能通过绑定判断
                LogUtils.d(LogUtils.TAG_PLUTO,"bind service fails. isCanShow="+isCanShow);
                return isCanShow;
            }
        }
        if(mPalmPlutoService!=null) {
            try {
                isCanShow = mPalmPlutoService.isCanShowDialog(new Binder());
                LogUtils.d(LogUtils.TAG_PLUTO,"isCanShow="+isCanShow);
            } catch (RemoteException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
        return isCanShow;
    }

    /**
     *  通知PalmA弹窗结束
     */
    public void updatePalmAShowDialogStatus() {
        if(mPalmPlutoService!=null) {
            try {
                LogUtils.d(LogUtils.TAG_PLUTO,"updatePalmAShowDialogStatus");
                mPalmPlutoService.setDialogStatus(0);
            } catch (RemoteException e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
        LogUtils.d(LogUtils.TAG_PLUTO,"updatePalmAShowDialogStatus finish");
    }
    /**
     * 判断服务是否活着
     * @return
     */
    public boolean isPlutoServiceLive() {
        return mPalmPlutoService==null ? false : true;
    }

    /**
     * 解绑Pluto服务
     * @param context
     */
    public void unbindPlutoService(Context context) {
        if (mPlutoServiceConnection != null) {
            context.unbindService(mPlutoServiceConnection);
        }
    }
    /**
     * 绑定PlutoService用于判断弹窗互斥
     * @param context
     * @return
     */
    public boolean bindPlutoService(Context context) {
        boolean status = false;
        if(isPlutoBinding == true) {
            LogUtils.d(LogUtils.TAG_PLUTO,"is pluto binding now");
            return false;
        }
        Intent intent = new Intent();
        ComponentName componentName = new ComponentName(PACKAGE_NAME_4X,CLASS_NAME_FOR_PLUTO);
        intent.setComponent(componentName);
        isPlutoBinding = true;
        try {
            status = context.bindService(intent, mPlutoServiceConnection, Context.BIND_AUTO_CREATE);
            LogUtils.d(LogUtils.TAG_PLUTO, "mPalmPlutoService connect status=" + status);
            isPlutoBinding = false;
        } catch (Exception e) {
            try {
                intent.setPackage(PACKAGE_NAME_4X);
                status = context.bindService(intent, mPlutoServiceConnection, Context.BIND_AUTO_CREATE);
                LogUtils.d(LogUtils.TAG_PLUTO, "mPalmPlutoService connect status=" + status);
                isPlutoBinding = false;
            } catch (Exception ignored) {
            }
        }
        return status;
    }

    static class InstallCallBackFromPalmA extends IInstallFinishListener.Stub {
        private String mPackageName;
        public InstallCallBackFromPalmA(String pkg) {
            mPackageName = pkg;
        }
        @Override
        public void installFinishListener(String result) throws RemoteException {
            if (TextUtils.isEmpty(mPackageName)) {
                return;
            }
            TRAnalysticsUtil.plutoFourDev(TRAnalyticsConstant.EVENT_RESPONSE_INSTALL,mPackageName);
            int resultCode = TextUtils.equals("successed",result) ? 1 : 0;
            LogUtils.e(LogUtils.TAG_PLUTO, "packageInstalled = " + mPackageName + "; result = " + result);
            // 安装时保证Service启动了
            CommonUtils.updateDownloadServiceStatus();
            Message msg = DownloadHandler.getInstance().getHandler().obtainMessage();
            msg.what = PalmstoreDownloadHandler.MSG_APP_SILENT_INSTALL_FINISHED;
            msg.obj = mPackageName;
            msg.arg1 = resultCode;
            DownloadHandler.getInstance().getHandler().sendMessage(msg);
            if(resultCode != 1) {
                InstallFailEngine.onInstallFailProcess(0, result, mPackageName);
            }
            if (!TextUtils.isEmpty(mPackageName) && TextUtils.equals(mPackageName, PalmPlayVersionManager.getMyPackageName())) {
                PalmPlayVersionManager.getInstance().setInstalling(false);
            }
        }
    }
}

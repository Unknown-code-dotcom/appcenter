package com.afmobi.apk;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.text.TextUtils;

import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * APK 签名工具
 * 用于安装失败上报时获取失败包的签名 SHA-256 指纹
 */
public final class ApkSignUtils {

    private static final String TAG = "ApkSignUtils";


    /**
     * 获取 APK 签名证书的 SHA-256 指纹（支持多签名）；多签名场景下，多个指纹以英文逗号分隔，例如 "abcd...,ef01..."。
     *
     * 注意事项：
     * 1. 包含文件 I/O 和证书解析操作，调用方应在工作线程执行，避免阻塞主线程；
     * 2. 安装失败回调运行在主线程，建议外层进行异步包装；
     * 3. 若 APK 文件已被删除或不可读，返回空字符串，调用方需做空判断。
     *
     * @param ctx     任意 Context（仅用于获取 PackageManager）
     * @param apkPath 本地 APK 文件的绝对路径
     * @return SHA-256 十六进制字符串（多个签名以英文逗号分隔）； 任意环节失败返回空字符串 ""，不抛出异常
     */
    public static String getApkSignSha256 (Context ctx, String apkPath){
        if (ctx == null || TextUtils.isEmpty(apkPath)) {
            return "";
        }

        File apkFile = new File(apkPath);
        if (!apkFile.exists() || !apkFile.canRead() || apkFile.length() == 0) {
            return "";
        }

        try {
            PackageManager pm = ctx.getPackageManager();
            int flags;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                flags = PackageManager.GET_SIGNING_CERTIFICATES;
            } else {
                //noinspection deprecation
                flags = PackageManager.GET_SIGNATURES;
            }
            PackageInfo pi = pm.getPackageArchiveInfo(apkPath, flags);
            if (pi == null) {
                return "";
            }

            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                SigningInfo si = pi.signingInfo;
                if (si == null) {
                    return "";
                }
                // 多签名取当前签名集合；单签名取历史链（含轮换前证书）
                sigs = si.hasMultipleSigners() ? si.getApkContentsSigners() : si.getSigningCertificateHistory();
            } else {
                //noinspection deprecation
                sigs = pi.signatures;
            }
            if (sigs == null || sigs.length == 0) {
                return "";
            }

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            CertificateFactory cf = CertificateFactory.getInstance("X.509");

            StringBuilder result = new StringBuilder();
            for (Signature sig : sigs) {
                if (sig == null) {
                    continue;
                }
                md.reset();

                X509Certificate cert = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(sig.toByteArray()));
                byte[] digest = md.digest(cert.getEncoded());

                if (result.length() > 0) {
                    result.append(',');
                }
                for (byte b : digest) {
                    result.append(String.format("%02x", b));
                }
            }

            return result.toString();
        } catch (Exception e) {
            LogUtils.e(TAG, "getApkSignSha256 failed: " + e.getMessage());
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
            return "";
        }
    }


    /**
     * 获取 APK 签名证书的 SHA-256 指纹（支持多签名）
     *
     * @param ctx     任意 Context（仅用于获取 PackageManager）
     * @param packageName 安装包的包名
     * @return SHA-256 十六进制字符串列表，可能多个
     */
    public static List<String> getAppSignSha256 (Context ctx, String packageName){
        if (ctx == null || TextUtils.isEmpty(packageName)) {
            return null;
        }

        try {
            PackageManager pm = ctx.getPackageManager();
            int flags;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                flags = PackageManager.GET_SIGNING_CERTIFICATES;
            } else {
                //noinspection deprecation
                flags = PackageManager.GET_SIGNATURES;
            }
            PackageInfo pi = pm.getPackageInfo(packageName, flags);
            if (pi == null) {
                return null;
            }

            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                SigningInfo si = pi.signingInfo;
                if (si == null) {
                    return null;
                }
                // 多签名取当前签名集合；单签名取历史链（含轮换前证书）
                sigs = si.hasMultipleSigners() ? si.getApkContentsSigners() : si.getSigningCertificateHistory();
            } else {
                //noinspection deprecation
                sigs = pi.signatures;
            }
            if (sigs == null || sigs.length == 0) {
                return null;
            }

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            CertificateFactory cf = CertificateFactory.getInstance("X.509");

            List<String> result = new ArrayList<>();
            for (Signature sig : sigs) {
                if (sig == null) {
                    continue;
                }
                md.reset();

                X509Certificate cert = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(sig.toByteArray()));
                byte[] digest = md.digest(cert.getEncoded());
                StringBuilder sb = new StringBuilder();

                for (byte b : digest) {
                    sb.append(String.format("%02x", b).toUpperCase(Locale.ROOT));
                }

                if (sb.length() > 1) {
                    result.add(sb.toString());
                }
            }

            return result;
        } catch (Exception e) {
            LogUtils.e(TAG, "getApkSignSha256 failed: " + e.getMessage());
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
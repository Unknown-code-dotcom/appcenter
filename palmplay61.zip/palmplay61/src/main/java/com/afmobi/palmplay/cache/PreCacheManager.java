package com.afmobi.palmplay.cache;

import android.annotation.SuppressLint;
import android.os.Looper;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.configs.v6_3.FeaturedType;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.manager.HttpRequestTracerManager;
import com.afmobi.palmplay.model.FeatureSinglePageData;
import com.afmobi.palmplay.model.FeatureTabInfo;
import com.afmobi.palmplay.model.FindListData;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.PreCacheInfo;
import com.afmobi.palmplay.model.keeptojosn.FindDetailData;
import com.afmobi.palmplay.model.keeptojosn.FindDetailInfo;
import com.afmobi.palmplay.model.v6_3.FeatureResponse;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.optimize.HomeTabDefault;
import com.afmobi.palmplay.smallpkg.utils.SmallPkgUtils;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.trans.common.async.thread.ThreadUtils;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsnet.store.BuildConfig;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static com.transsion.palmstorecore.thread.TRThreadPool.PRIORITY_MEDIUM;

import androidx.collection.LruCache;

/**
 * @author suijiang.du
 * <p>
 * app game findList rankList findDetail
 */
public class PreCacheManager {
    private static final String TAG = "PreCacheManager";

    private static class Holder {
        private static PreCacheManager instance = new PreCacheManager();
    }

    private boolean preCache = true;
    private int mRankIndex = 0;
    private int mFindDetailIndex = 0;

    public static PreCacheManager getInstance() {
        return Holder.instance;
    }

    private static final int MAX_CACHE_SIZE = 5;
    private LruCache<String, String> mHomeFeatureCache;

    PreCacheInfo.PreCacheParameterValue preCacheInfo;

    public PreCacheManager() {
        String cacheInfo = MMKVUtils.getMMKV().getString(Constant.KV_HOME_FEATURE_CACHE, null);
        try {
            if (!TextUtils.isEmpty(cacheInfo)) {
                mHomeFeatureCache = new Gson().fromJson(cacheInfo, new TypeToken<LruCache<String, String>>() {
                }.getType());
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        if (mHomeFeatureCache == null) {
            mHomeFeatureCache = new LruCache<>(MAX_CACHE_SIZE);
        }
        LogUtils.d(LogUtils.TAG_HOME_CACHE, " init mHomeFeatureCache = " + mHomeFeatureCache.size());

    }

    public void saveHomeCacheInfo(String featuredType, String tabId, String cacheFileName) {
        if (mHomeFeatureCache != null) {
            mHomeFeatureCache.put(getHomeCacheKey(featuredType, tabId), cacheFileName);
            String temp = new Gson().toJson(mHomeFeatureCache);
            MMKVUtils.getMMKV().putString(Constant.KV_HOME_FEATURE_CACHE, temp);
            LogUtils.d(LogUtils.TAG_HOME_CACHE, " saveHomeCacheInfo = " + temp);
        }
    }


    public String getHomeCacheKey(String featuredType, String tabId) {
        return featuredType + tabId + "_" + getCountryCode();
    }

    public String getCountryCode() {
        String countryCode = PhoneDeviceInfo.getCountryCode();
        if (TextUtils.isEmpty(countryCode)) {
            countryCode = "NULL";
        }
        return countryCode;
    }

    public void preRequestHomeCacheTab() {
        PreCacheManager.getInstance().preRequestRankingAppPage(Constant.SOFTTYPE_APP);
        PreCacheManager.getInstance().preRequestRankingAppPage(Constant.SOFTTYPE_GAME);
        PreCacheManager.getInstance().preRequestHomeDataByTabId();
        PreCacheManager.getInstance().preRequestCollectionDataByTabId();
        PreCacheManager.getInstance().preRequestMeShortBannerData();
    }

    //获取已经缓存过的tabId文件名称
    public Set<String> getCacheFileNameList() {
        return MMKVUtils.getMMKV().getStringSet(Constant.KV_CACHE_FILE_NAME, null);
    }

    private List<String> getCacheTabIdList() {
        FeatureTabInfo info = null;  //首页for you
        List<String> cacheTabList = new ArrayList<>(); //需要缓存的页面tabid

        List<FeatureTabInfo> list = NavTabManager.getInstance().getFeatureTabByKey(FeaturedType.HOME);
        if (list == null || list.size() <= 0) {
            //startup接口下发tab为空时，获取预置asset下的tab数据
            list = HomeTabDefault.INSTANCE.initDefaultTab();
        }
        List<FeatureTabInfo> homeTabList = new ArrayList<>();
        Set<String> newFileNameSet = new HashSet<>();
        if (list != null && list.size() > 0) {
            for (FeatureTabInfo featureTabInfo : list) {
                if (featureTabInfo.getTabType().equals(Constant.TAB_TYPE_FEATURE)) {
                    String fileName = TRHomeUtil.getFileName(FeaturedType.HOME, String.valueOf(featureTabInfo.getId()));
                    newFileNameSet.add(fileName);
                    homeTabList.add(featureTabInfo);
                    if (featureTabInfo.isDefault()) {
                        info = featureTabInfo;
                    }
                }
            }
        }

        //删除已经不存在的tabid缓存数据
        Set<String> stringSet = getCacheFileNameList();
        if (stringSet != null && stringSet.size() > 0) {
            LogUtils.i(TAG, "stringSet = " + stringSet.size());
            for (String newName : newFileNameSet) {
                if (stringSet.contains(newName)) {
                    stringSet.remove(newName);
                }
            }

            for (String fileName : stringSet) {
                LogUtils.i(TAG, "remove = " + fileName);
                TRHomeUtil.removeCache(fileName);
            }
        }

        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_TAB_CACHE_PAGE_CONFIG_INFO, null);
        if (set != null && set.size() > 0) {
            List<String> tabList = new ArrayList<>(set);

            if (homeTabList != null && homeTabList.size() > 0) {
                for (FeatureTabInfo featureTabInfo : homeTabList) {
                    if (tabList.contains(String.valueOf(featureTabInfo.getId()))) {
                        cacheTabList.add(String.valueOf(featureTabInfo.getId()));
                    }
                }
            }
        }
        //如果没有配置首页for you，则默认添加
        if (!cacheTabList.contains(info.getId())) {
            cacheTabList.add(0, String.valueOf(info.getId()));
        }
        return cacheTabList;
    }

    public void preRequestHomeDataByTabId() {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                try {
                    List<String> cacheTabIdList = getCacheTabIdList();
                    if (cacheTabIdList != null && cacheTabIdList.size() > 0) {
                        for (String s : cacheTabIdList) {
                            preRequestHomeData(s);
                        }
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }));
    }

    /**
     * 缓存推荐合集页的数据
     */
    public void preRequestCollectionDataByTabId() {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                try {
                    Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_COLLECTION_IDS, null);
                    List<String> cacheTabIdList = set == null ? new ArrayList<>() : new ArrayList<>(set);
                    if (!cacheTabIdList.isEmpty()) {
                        for (String s : cacheTabIdList) {
                            preRequestCollectionData(s);
                        }
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }));

    }


    public void preRequestMeShortBannerData() {

        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                try {
                    LogUtils.e(LogUtils.TAG_TOOL_BANNER, "preRequestMeShortBannerData is running...");
                    preRequestToolBannerData();
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }));

    }

    /**
     * 缓存Tool页面Banner的数据
     */
    public void preRequestToolBannerData() {
        //  检查网络连接
        if (!com.transsion.palmstorecore.util.NetworkUtils.sNetworkConnected) {
            LogUtils.d(LogUtils.TAG_TOOL_BANNER, "preRequestToolBannerData, no net");
            return;
        }

        //检查请求时间是否满足间隔要求
        long requestPeriod;
        int loadMeTimeInterval = MMKVUtils.getMMKV().getInt(Constant.KV_SINGLE_ME_CONFIG_LOAD_TIME, 0);
        long lastRequestTime = MMKVUtils.getMMKV().getLong(Constant.KV_CACHE_TOOL_BANNER_LOAD_TIME , 0);

        if (loadMeTimeInterval <= 0) {
            requestPeriod = Constants.TIME_DAY_UNIT;
        } else {
            requestPeriod = loadMeTimeInterval * Constants.TIME_HOUR_UNIT;
        }

        if (System.currentTimeMillis() - lastRequestTime < requestPeriod) {
            LogUtils.d(LogUtils.TAG_TOOL_BANNER, "ps --> new preRequestToolBannerData is too short......");
            return;
        }
        MMKVUtils.getMMKV().putLong(Constant.KV_CACHE_TOOL_BANNER_LOAD_TIME, System.currentTimeMillis());

        NetworkClient.toolBannerItemHttpRequest(0, 1, "ME", null, new AbsRequestListener<FeatureResponse>() {
            @Override
            public void onResponse(FeatureResponse response) {
                super.onResponse(response);
                LogUtils.d(LogUtils.TAG_TOOL_BANNER, "preRequestToolBannerData --> response = " + response);
                if (response != null && response.data != null) {
                    FeaturedModel rspFeatureModel = response.data;
                    rspFeatureModel = TRHomeUtil.transformAndSortData(rspFeatureModel);//做完了数据解析

                    if (rspFeatureModel.featureList != null) {
                        Iterator<FeatureBean> featureBeanIterator = rspFeatureModel.featureList.iterator();
                        while (featureBeanIterator.hasNext()) {
                            FeatureBean featureBean = featureBeanIterator.next();
                            if (!TRHomeUtil.FEATURE_TYPE_SHORT_BANNER.equalsIgnoreCase(featureBean.featureType)) {
                                featureBeanIterator.remove();
                            }
                        }
                        if (!rspFeatureModel.featureList.isEmpty()) {
                            LogUtils.d(LogUtils.TAG_TOOL_BANNER, "preRequestToolBannerData --> saveToCache rspFeatureModel after filter by SHORT_BANNER " + rspFeatureModel);
                            TRHomeUtil.saveToCache(rspFeatureModel, FeaturedType.TOOL, "Banner");
                        }
                    }
                }

            }

                @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(LogUtils.TAG_TOOL_BANNER, "preRequestToolBannerData onError " + anError);
            }
        }, null, CommonUtils.generateSerialNum(), SmallPkgUtils.getFullOsVersionStr(), SmallPkgUtils.getFullOsSmallVersionStr());
    }

    /**
     * 缓存推荐合集页的数据
     */
    public void preRequestCollectionData(String tabId) {
        String tag = LogUtils.TAG_COLLECTION + TAG;
        LogUtils.i(tag, "preRequestCollectionData = " + tabId);
        if (!com.transsion.palmstorecore.util.NetworkUtils.sNetworkConnected) {
            LogUtils.d(tag, "preRequestCollectionData, no net");
            return;
        }

//        FeaturedModel featuredModel = TRHomeUtil.loadFromCache(FeaturedType.COLLECTION, tabId);
//        if (featuredModel != null) {
//            //是否已经展示.上次缓存的没有展示过，则不再请求
//            boolean isShow = MMKVUtils.getMMKV().getBoolean(Constant.KV_CACHE_HOME_IS_SHOW + tabId, true);
//            LogUtils.i(tag, tabId + " home isShow = " + isShow);
//            if (!isShow) {
//                return;
//            }
//        }

        long requestPeriod;
        int loadTimeInterval = MMKVUtils.getMMKV().getInt(Constant.KV_SINGLE_RANK_CONFIG_LOAD_TIME, 0);
        long lastRequestTime = MMKVUtils.getMMKV().getLong(Constant.KV_LAST_COLLECTION_LOAD_TIME + tabId, 0);

        if (loadTimeInterval <= 0) {
            requestPeriod = Constants.TIME_DAY_UNIT;
        } else {
            requestPeriod = loadTimeInterval * Constants.TIME_HOUR_UNIT;
        }
        if (System.currentTimeMillis() - lastRequestTime < requestPeriod) {
            LogUtils.e(tag, "ps --> new preRequestCollectionData is too short......");
            return;
        }

        MMKVUtils.getMMKV().putLong(Constant.KV_LAST_COLLECTION_LOAD_TIME + tabId, System.currentTimeMillis());
        NetworkClient.fetchCollectionListHttpRequest(tabId, true, new AbsRequestListener<FeatureResponse>() {
            @Override
            public void onResponse(FeatureResponse response) {
                LogUtils.d(tag, "preRequestCollectionData onResponse" + response);
                if (response != null && response.data != null) {
                    FeaturedModel rspFeatureModel = response.data;
                    rspFeatureModel.isCache = true;
                    // 缓存banner 图片
                    String bannerUrl = "";
                    if (rspFeatureModel.currentTabConfig != null && rspFeatureModel.currentTabConfig.bgImageUrl != null) {
                        String bgImageUrl = rspFeatureModel.currentTabConfig.bgImageUrl;
                        if (bgImageUrl != null && !bgImageUrl.startsWith("http")) {
                            bannerUrl = rspFeatureModel.iconUrlPre + bgImageUrl;
                        } else {
                            bannerUrl = bgImageUrl;
                        }
                    }
                    if (!TextUtils.isEmpty(bannerUrl)) {
                        TRBitmapManager.prefetchToBitmapCacheByFresco(bannerUrl, 0, 0);
                    }
                    LogUtils.d(tag, "preRequestCollectionData saveToCache " + FeaturedType.COLLECTION + " " +tabId);
                    TRHomeUtil.saveToCache(rspFeatureModel, FeaturedType.COLLECTION, tabId);
                    MMKVUtils.getMMKV().putBoolean(Constant.KV_COLLECTION_CACHE_EXIST + tabId, true);
                }
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(tag, "preRequestCollectionData onError " + anError);
            }
        }, PreCacheManager.class.getName() + FeaturedType.COLLECTION + tabId);
    }

    public void preRequestHomeData(String tabId) {
        LogUtils.i(TAG, "preRequestHomeData = " + tabId);
        if (!com.transsion.palmstorecore.util.NetworkUtils.sNetworkConnected) {
            LogUtils.d(TAG, "preRequestHomeData, no net");
            return;
        }

        FeaturedModel featuredModel = TRHomeUtil.loadFromCache(FeaturedType.HOME, tabId);
        if (featuredModel != null) {
            //是否已经展示.上次缓存的没有展示过，则不再请求
            boolean isShow = MMKVUtils.getMMKV().getBoolean(Constant.KV_CACHE_HOME_IS_SHOW + tabId, true);
            LogUtils.i(TAG, tabId + " home isShow = " + isShow);
            if (!isShow) {
                return;
            }
        }

        long requestPeriod;
        int loadTimeInterval = MMKVUtils.getMMKV().getInt(Constant.KV_SINGLE_RANK_CONFIG_LOAD_TIME, 0);
        long lastRequestTime = MMKVUtils.getMMKV().getLong(Constant.KV_LAST_HOME_LOAD_TIME + tabId, 0);

        if (loadTimeInterval <= 0) {
            requestPeriod = Constants.TIME_DAY_UNIT;
        } else {
            requestPeriod = loadTimeInterval * Constants.TIME_HOUR_UNIT;
        }
        if (System.currentTimeMillis() - lastRequestTime < requestPeriod) {
            LogUtils.e(TAG, "ps --> new preRequestHomeData is too short......");
            return;
        }
        MMKVUtils.getMMKV().putLong(Constant.KV_LAST_HOME_LOAD_TIME + tabId, System.currentTimeMillis());
        NetworkClient.homeTypeTabItemHttpRequest_v6_3_withTag(0, FeaturedType.HOME, Constant.ABTEST_A, true, tabId, null, new AbsRequestListener<FeatureResponse>() {
            @Override
            public void onResponse(FeatureResponse response) {
                LogUtils.d(TAG, "preRequestHomeData onResponse" + response);
                if (response != null && response.data != null) {
                    FeaturedModel rspFeatureModel = response.data;
                    rspFeatureModel = TRHomeUtil.transformAndSortData(rspFeatureModel);
                    rspFeatureModel.isCache = true;
                    LogUtils.d(TAG, "preRequestHomeData saveToCache " + FeaturedType.HOME + " " +tabId);
                    TRHomeUtil.saveToCache(rspFeatureModel, FeaturedType.HOME, tabId);

                    MMKVUtils.getMMKV().putBoolean(Constant.KV_CACHE_HOME_IS_SHOW + tabId, false);
                }
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(TAG, "preRequestHomeData onError " + anError);
            }
        }, PreCacheManager.class.getName() + FeaturedType.HOME + tabId, preCache, CommonUtils.generateSerialNum(), SmallPkgUtils.getFullOsVersionStr(), SmallPkgUtils.getFullOsSmallVersionStr(), SceneCode.H_fe);
    }

    public void preRequestHomeDataCountryCode(String ipCountryCode) {
        if (!com.transsion.palmstorecore.util.NetworkUtils.sNetworkConnected) {
            LogUtils.d(TAG, "preRequestHomeDataCountryCode, no net");
            return;
        }

        String mTabId = getTabId();
        NetworkClient.homeTypeTabItemHttpRequest_v6_3_withCountryCode("", 0, 0, FeaturedType.HOME, Constant.ABTEST_A, true, mTabId, null, new AbsRequestListener<FeatureResponse>() {
            @Override
            public void onResponse(FeatureResponse response) {
                LogUtils.d(TAG, "preRequestHomeDataCountryCode onResponse" + response);
                if (response != null && response.data != null) {
                    FeaturedModel rspFeatureModel = response.data;
                    rspFeatureModel = TRHomeUtil.transformAndSortData(rspFeatureModel);
                    rspFeatureModel.isCache = true;
                    LogUtils.d(TAG, "preRequestHomeDataCountryCode saveToCache " + FeaturedType.HOME + mTabId);
                    TRHomeUtil.saveToCache(rspFeatureModel, FeaturedType.HOME, mTabId);
                }
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(TAG, "preRequestHomeDataCountryCode onError " + anError);
            }
        }, PreCacheManager.class.getName() + FeaturedType.HOME, preCache, CommonUtils.generateSerialNum(), SmallPkgUtils.getFullOsVersionStr(), SmallPkgUtils.getFullOsSmallVersionStr(), SceneCode.H_fe, ipCountryCode);
    }

    private String getTabId() {
        String mTabId = null;
        List<FeatureTabInfo> list = NavTabManager.getInstance().getFeatureTabByKey(FeaturedType.HOME);
        if (list == null || list.size() <= 0) {
            //startup接口下发tab为空时，获取预置asset下的tab数据
            list = HomeTabDefault.INSTANCE.initDefaultTab();
//            list = TRHomeUtil.loadFeatureTabData(PalmplayApplication.getAppInstance(), FeaturedType.HOME);
        }
        FeatureTabInfo info = null;
        if (list != null && list.size() > 0) {
            for (FeatureTabInfo featureTabInfo : list) {
                if (featureTabInfo.isDefault() && featureTabInfo.getTabType().equals(Constant.TAB_TYPE_FEATURE)) {
                    info = featureTabInfo;
                    break;
                }
            }
        }
        mTabId = info != null ? String.valueOf(info.getId()) : "";

        return mTabId;

    }

    public void preRequestData() {
        LogUtils.d(TAG, "preRequestData");
        mRankIndex = 0;
        mFindDetailIndex = 0;
        TRThreadPool.getInstance(PRIORITY_MEDIUM).submit(new Runnable() {
            @Override
            public void run() {
                deleteInvalidCache();
                String txt = MMKVUtils.getMMKV().getString(Constant.KV_PRE_CACHE_INFO, null);
                try {
                    if (!TextUtils.isEmpty(txt)) {
                        preCacheInfo = new Gson().fromJson(txt, PreCacheInfo.PreCacheParameterValue.class);
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }

                if (preCacheInfo != null) {
                    preRequestAppFeature();
                }
            }
        });

    }

    /**
     * app frature
     */
    private void preRequestAppFeature() {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }
        if (preCacheInfo != null && !preCacheInfo.appFeatured) {
            preRequestGameFeature();
            return;
        }
        FeaturedModel appFeaturedModel = PsCommonCache.getInstance().loadFromDiskCache(Constant.SOFTTYPE_APP);
        if (appFeaturedModel != null) {
            preRequestGameFeature();
            return;
        }

        NetworkClient.homeTypeTabItemHttpRequest_v6_3(0
                , Constant.SOFTTYPE_APP
                , null
                , null, new AbsRequestListener<FeatureResponse>() {
                    @Override
                    public void onResponse(FeatureResponse response) {
                        LogUtils.d(TAG, "preRequestAppFeature onResponse");
                        if (response != null && response.data != null) {
                            FeaturedModel rspFeatureModel = response.data;
                            rspFeatureModel = TRHomeUtil.transformAndSortData(rspFeatureModel);
                            rspFeatureModel.isCache = true;
                            PsCommonCache.getInstance().saveToDiskCache(rspFeatureModel, Constant.SOFTTYPE_APP);
                            preRequestGameFeature();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        super.onError(anError);
                        LogUtils.d(TAG, "preRequestAppFeature onError " + anError);
                        preRequestGameFeature();
                    }
                }, PreCacheManager.class.getName() + Constant.SOFTTYPE_APP, preCache, CommonUtils.generateSerialNum(), SmallPkgUtils.getFullOsVersionStr(), SmallPkgUtils.getFullOsSmallVersionStr());
    }

    /**
     * game frature
     */
    private void preRequestGameFeature() {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }
        if (preCacheInfo != null && !preCacheInfo.gameFeatured) {
            preRequestFindListData();
            return;
        }
        FeaturedModel gameFeaturedModel = PsCommonCache.getInstance().loadFromDiskCache(Constant.SOFTTYPE_GAME);
        if (gameFeaturedModel != null) {
            preRequestFindListData();
            return;
        }

        NetworkClient.homeTypeTabItemHttpRequest_v6_3(0
                , Constant.SOFTTYPE_GAME
                , null
                , null, new AbsRequestListener<FeatureResponse>() {
                    @Override
                    public void onResponse(FeatureResponse response) {
                        LogUtils.d(TAG, "preRequestGameFeature onResponse");
                        if (response != null && response.data != null) {
                            FeaturedModel rspFeatureModel = response.data;
                            rspFeatureModel = TRHomeUtil.transformAndSortData(rspFeatureModel);
                            rspFeatureModel.isCache = true;
                            PsCommonCache.getInstance().saveToDiskCache(rspFeatureModel, Constant.SOFTTYPE_GAME);

                            preRequestFindListData();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        super.onError(anError);
                        LogUtils.d(TAG, "preRequestGameFeature onError " + anError);
                        preRequestFindListData();

                    }
                }, PreCacheManager.class.getName() + Constant.SOFTTYPE_GAME, preCache, CommonUtils.generateSerialNum(), SmallPkgUtils.getFullOsVersionStr(), SmallPkgUtils.getFullOsSmallVersionStr());
    }

    /**
     * findList
     */
    private void preRequestFindListData() {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }
        if (preCacheInfo != null && !preCacheInfo.findList) {
            mRankIndex = 0;
            if (preCacheInfo.rankList != null && preCacheInfo.rankList.size() > 0) {
                preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
            } else {
                mFindDetailIndex = 0;
                if (preCacheInfo.findIdList != null && preCacheInfo.findIdList.size() > 0) {
                    preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
                }
            }
            return;
        }
        FindListData findListData = PsCommonCache.getInstance().loadFromDiskCache(PsCommonCache.KEY_FIND_LIST, FindListData.class);

        if (findListData != null) {
            if (preCacheInfo != null && preCacheInfo.rankList != null && preCacheInfo.rankList.size() > 0) {
                mRankIndex = 0;
                preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
            }
            return;
        }

        NetworkClient.requestFindListData(new AbsRequestListener<FindListData>() {
            @Override
            public void onResponse(FindListData response) {
                super.onResponse(response);
                LogUtils.d(TAG, "preRequestFindListData onResponse");
                if (response != null && response.data != null) {
                    PsCommonCache.getInstance().saveToDiskCache(PsCommonCache.KEY_FIND_LIST, response, FindListData.class);
                }

                if (preCacheInfo != null && preCacheInfo.rankList != null && preCacheInfo.rankList.size() > 0) {
                    mRankIndex = 0;
                    preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
                }

            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(TAG, "preRequestFindListData onError " + anError);
                if (preCacheInfo != null && preCacheInfo.rankList != null && preCacheInfo.rankList.size() > 0) {
                    mRankIndex = 0;
                    preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
                }
            }
        }, getClass().getSimpleName() + PsCommonCache.KEY_FIND_LIST);
    }

    /**
     * 专题明细
     *
     * @param rankId
     */
    private void preRequestRankSinglePage(String rankId) {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }
        FeatureSinglePageData featureSinglePageData = PsCommonCache.getInstance().loadFromDiskCache(rankId, FeatureSinglePageData.class);
        if (featureSinglePageData != null) {
            if (preCacheInfo != null && preCacheInfo.rankList != null) {
                mRankIndex++;
                if (mRankIndex < preCacheInfo.rankList.size()) {
                    preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
                } else {
                    if (preCacheInfo.findIdList != null && preCacheInfo.findIdList.size() > 0) {
                        mFindDetailIndex = 0;
                        preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
                    }
                }
            }
            return;
        }
        String tag = getClass().getSimpleName() + rankId;
        NetworkClient.requestFeatureSinglePage(Constant.SOURCE_NORMAL, rankId, 0, TRHomeUtil.MAX_PAGE_SIZE, null, null, tag, new AbsRequestListener<GenericResponseInfo<FeatureSinglePageData>>() {
            @Override
            public void onResponse(GenericResponseInfo<FeatureSinglePageData> response) {
                super.onResponse(response);
                if (response != null && response.getData() != null) {
                    FeatureSinglePageData data = response.getData();
                    TRHomeUtil.resetVaStatus4FeatureSinglePageData(data);
                    TRHomeUtil.checkTraceId(data);
                    PsCommonCache.getInstance().saveToDiskCache(rankId, response.data, FeatureSinglePageData.class);
                }
                LogUtils.d(TAG, "preRequestRankSinglePage  onResponse randId: " + rankId + ", mRankIndex: " + mRankIndex);
                mRankIndex++;
                if (preCacheInfo != null && preCacheInfo.rankList != null && mRankIndex < preCacheInfo.rankList.size()) {
                    preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
                } else {
                    if (preCacheInfo != null && preCacheInfo.findIdList != null && preCacheInfo.findIdList.size() > 0) {
                        mFindDetailIndex = 0;
                        preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
                    }
                }
                HttpRequestTracerManager.getInstance().remove(tag);
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(TAG, "preRequestRankSinglePage  onError " + anError + ",rankId: " + rankId + ", mRankIndex: " + mRankIndex);
                mRankIndex++;
                if (preCacheInfo != null && preCacheInfo.rankList != null && mRankIndex < preCacheInfo.rankList.size()) {
                    preRequestRankSinglePage(preCacheInfo.rankList.get(mRankIndex));
                } else {
                    if (preCacheInfo != null && preCacheInfo.findIdList != null && preCacheInfo.findIdList.size() > 0) {
                        mFindDetailIndex = 0;
                        preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
                    }
                }
                HttpRequestTracerManager.getInstance().remove(tag);
            }
        }, preCache);
    }

    /**
     * find详情
     *
     * @param findId
     */
    private void preRequestFindDetailData(String findId) {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }

        FindDetailInfo findDetailInfo = PsCommonCache.getInstance().loadFromDiskCache(findId, FindDetailInfo.class);
        if (findDetailInfo != null) {
            mFindDetailIndex++;
            if (preCacheInfo != null && preCacheInfo.findIdList != null && mFindDetailIndex < preCacheInfo.findIdList.size()) {
                preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
            }
            return;
        }
        NetworkClient.requestFindDetail(findId, null, null, null, new AbsRequestListener<FindDetailData>() {
            @Override
            public void onResponse(FindDetailData response) {
                super.onResponse(response);
                LogUtils.d(TAG, "preRequestFindDetailData  onResponse findId: " + findId + ", mFindDetailIndex: " + mFindDetailIndex);
                if (response != null && response.getCode() == 0 && response.getData() != null) {
                    PsCommonCache.getInstance().saveToDiskCache(response.getData().getId(), response.getData(), FindDetailInfo.class);
                }
                mFindDetailIndex++;
                if (preCacheInfo != null && preCacheInfo.findIdList != null && mFindDetailIndex < preCacheInfo.findIdList.size()) {
                    preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
                }
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(TAG, "preRequestFindDetailData  onError " + anError + ", findId: " + findId + ", mFindDetailIndex: " + mFindDetailIndex);
                mFindDetailIndex++;
                if (preCacheInfo != null && preCacheInfo.findIdList != null && mFindDetailIndex < preCacheInfo.findIdList.size()) {
                    preRequestFindDetailData(preCacheInfo.findIdList.get(mFindDetailIndex));
                }
            }
        }, getClass().getSimpleName() + findId, preCache);
    }

    /**
     * ranking
     *
     * @param tabCategory
     */
    public void preRequestRankingAppPage(String tabCategory) {
        LogUtils.i(TAG, "preRequestRankingAppPage");
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }
        FeatureTabInfo info = null;  //Ranking
        String appRankId = "";
        String gameRankId = "";
        List<FeatureTabInfo> list = NavTabManager.getInstance().getFeatureTabByKey(FeaturedType.HOME);
        if (list == null || list.size() <= 0) {
            //startup接口下发tab为空时，获取预置asset下的tab数据
            list = HomeTabDefault.INSTANCE.initDefaultTab();
        }
        if (list != null && list.size() > 0) {
            for (FeatureTabInfo featureTabInfo : list) {
                if (TextUtils.equals(Constant.TAB_TYPE_RANKING, featureTabInfo.getTabType())) {
                    info = featureTabInfo;
                    FeatureTabInfo.JumpInfo jumpDto = featureTabInfo.getJumpDto();
                    if (jumpDto != null) {
                        List<FeatureTabInfo.JumpListData> jumpUrlList = jumpDto.getJumpUrlList();
                        if (jumpUrlList != null && jumpUrlList.size() > 0) {
                            for (FeatureTabInfo.JumpListData jumpListData : jumpUrlList) {
                                if (TextUtils.equals(jumpListData.getTabCategory(), Constant.SOFTTYPE_APP)) {
                                    appRankId = jumpListData.getJumpUrl();
                                } else if (TextUtils.equals(jumpListData.getTabCategory(), Constant.SOFTTYPE_GAME)) {
                                    gameRankId = jumpListData.getJumpUrl();
                                }
                            }
                        }
                    }
                }
            }
        }
        String rankId = "";
        if (TextUtils.equals(tabCategory, Constant.SOFTTYPE_APP)) {
            rankId = appRankId;
        } else if (TextUtils.equals(tabCategory, Constant.SOFTTYPE_GAME)) {
            rankId = gameRankId;
        }
        //如果没有配置ranking tabid则不请求缓存接口
        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_TAB_CACHE_PAGE_CONFIG_INFO, null);
        if (set != null && set.size() > 0 && info != null) {
            List<String> tabList = new ArrayList<>(set);
            if (!tabList.contains(String.valueOf(info.getId()))) {
                LogUtils.i(TAG, "no config rinking tabid");
                return;
            }
        } else {
            LogUtils.i(TAG, "no config rinking tabid");
            return;
        }

        FeatureSinglePageData featureSinglePageData = PsCommonCache.getInstance().loadFromDiskCache(rankId, FeatureSinglePageData.class);
        if (featureSinglePageData != null) {
            //是否已经展示.上次缓存的没有展示过，则不再请求
            boolean isShow = MMKVUtils.getMMKV().getBoolean(Constant.KV_CACHE_SINGLE_RANK_IS_SHOW + rankId, true);
            LogUtils.i(TAG, "rinking isShow = " + isShow);
            if (!isShow) {
                return;
            }
        }

        long requestPeriod;
        int loadTimeInterval = MMKVUtils.getMMKV().getInt(Constant.KV_SINGLE_RANK_CONFIG_LOAD_TIME, 0);
        long lastRequestTime = MMKVUtils.getMMKV().getLong(Constant.KV_LAST_SINGLE_RANK_LOAD_TIME + rankId, 0);

        if (loadTimeInterval <= 0) {
            requestPeriod = 24* 60 * 60 * 1000;
        } else {
            requestPeriod = loadTimeInterval * 60L * 60L * 1000L;
        }
        if (System.currentTimeMillis() - lastRequestTime < requestPeriod) {
            LogUtils.e(TAG, "ps --> new preRequestRankingAppPage is too short......");
            return;
        }

        String tag = getClass().getSimpleName() + rankId;
        String finalRankId = rankId;
        MMKVUtils.getMMKV().putLong(Constant.KV_LAST_SINGLE_RANK_LOAD_TIME + rankId, System.currentTimeMillis());
        NetworkClient.requestFeatureSinglePage(Constant.SOURCE_NORMAL, rankId, 0, 18, null, null, tag, new AbsRequestListener<GenericResponseInfo<FeatureSinglePageData>>() {
            @Override
            public void onResponse(GenericResponseInfo<FeatureSinglePageData> response) {
                super.onResponse(response);
                if (response != null && response.getData() != null) {
                    FeatureSinglePageData data = response.getData();
                    TRHomeUtil.resetVaStatus4FeatureSinglePageData(data);
                    TRHomeUtil.checkTraceId(data);
                    LogUtils.i(TAG, "finalRankId = " + finalRankId);
                    PsCommonCache.getInstance().saveToDiskCache(finalRankId, response.data, FeatureSinglePageData.class);
                    MMKVUtils.getMMKV().putBoolean(Constant.KV_CACHE_SINGLE_RANK_IS_SHOW + finalRankId, false);
                }
                LogUtils.d(TAG, "preRequestRankingAppPage  onResponse randId: " + finalRankId);
                HttpRequestTracerManager.getInstance().remove(tag);
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                LogUtils.d(TAG, "preRequestRankingAppPage  onError " + anError + ",rankId: " + finalRankId);

                HttpRequestTracerManager.getInstance().remove(tag);
            }
        }, preCache);
    }

    private void deleteInvalidCache() {
        File file = PalmplayApplication.getAppInstance().getFilesDir();
        if (file != null && file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null && files.length > 0) {
                for (File f : files) {
                    if (f != null && f.isFile() && f.getName().contains(TRHomeUtil.HOME_CACHE_URI)) {
                        String key = f.getName().replace(TRHomeUtil.HOME_CACHE_URI, "");
                        String inCacheList = mHomeFeatureCache.get(key);
                        LogUtils.d(LogUtils.TAG_HOME_CACHE, " deleteInvalidCache, in mHomeFeatureCache, don't need delete " + inCacheList);
                        if (TextUtils.isEmpty(inCacheList)) {
                            try {
                                f.delete();
                                LogUtils.d(LogUtils.TAG_HOME_CACHE, " deleteInvalidCache, not in mHomeFeatureCache, delete cache file name = " + f.getName());
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG) e.printStackTrace();
                            }
                        }
                    }

                    if (f != null && f.isFile() && f.getName().contains(PsCommonCache.COMMON_CACHE_URI) && System.currentTimeMillis() - f.lastModified() > PsCommonCache.CACHE_MAX_TIME) {
                        try {
                            f.delete();
                        } catch (Exception e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }
                    }

                }
            }
        }
    }
}

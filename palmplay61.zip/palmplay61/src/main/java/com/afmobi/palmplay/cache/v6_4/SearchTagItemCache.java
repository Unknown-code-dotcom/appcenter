package com.afmobi.palmplay.cache.v6_4;

import android.text.TextUtils;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_0.TagItem;
import com.afmobi.palmplay.network.NetworkActions;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsnet.store.BuildConfig;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by HJG on 2017/3/10.
 */

public class SearchTagItemCache implements LocalCache {

    private final static String CACHE_URL = NetworkActions.ACTION_SEARCH_PAGE_TAG + "_TagPageCache";
    private final static int SEARCH_TAG_MAX = 40;
    public final static String STARTUP_SEARCH_CACHE = "startup_search_cache";

    private static volatile SearchTagItemCache mInstance;

    private HashMap<String, List<TagItem>> mapList;

    private SearchTagItemCache() {
        mapList = new HashMap<>();

        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                try {
                    JsonElement je = FilePathManager.fileToJson(STARTUP_SEARCH_CACHE);
                    if (je != null) {
                        List<TagItem> list = new Gson().fromJson(je, new TypeToken<List<TagItem>>(){}.getType());
                        if (list != null && list.size() > 0) {
                            int detailType = DetailType.getSearchType(TabType.SOFT);
                            initKeywordCache(list, TabType.SOFT, detailType);
                        }
                    }
                }catch(Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }));
    }

    public static SearchTagItemCache getInstance() {
        if (mInstance == null) {
            synchronized (SearchTagItemCache.class) {
                if (mInstance == null) {
                    mInstance = new SearchTagItemCache();
                }
            }
        }

        return mInstance;
    }

    public void releaseAndClear(){
        mapList.clear();
        mInstance = null;
    }

    public void initCache(List<TagItem> tagItemList, String tabType, int detailType) {

        if (tagItemList != null && tagItemList.size() >0) {
            String cacheKey = getCacheKey(tabType, detailType);
            List<TagItem> listTagItem = mapList.get(cacheKey);
            if(listTagItem==null){
                listTagItem = new ArrayList<>();
                mapList.put(cacheKey, listTagItem);
            } else {
                listTagItem.clear();
            }

            int count = Math.min(tagItemList.size(), SEARCH_TAG_MAX);
            for(int i = 0; i < count; i++){
                tagItemList.get(i).tagID = tagItemList.get(i).term;
                tagItemList.get(i).name = tagItemList.get(i).term;
                listTagItem.add(tagItemList.get(i));
            }
        }
        //saveToCache(array.toString());
    }

    public void initKeywordCache(final List<TagItem> list, String tabType, int detailType) {

        if (TextUtils.isEmpty(tabType)) {
            return;
        }

        if (list != null && list.size() >0) {
            String cacheKey = getCacheKey(tabType, detailType);
            List<TagItem> listTagItem = mapList.get(cacheKey);
            if(listTagItem==null){
                listTagItem = new ArrayList<>();
                mapList.put(cacheKey, listTagItem);
            } else {
                listTagItem.clear();
            }

            int count = Math.min(list.size(), SEARCH_TAG_MAX);
            for(int i = 0; i < count; i++){
                list.get(i).tagID = list.get(i).term;
                list.get(i).name = list.get(i).term;
                listTagItem.add(list.get(i));
            }


            TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
                @Override
                public void doRun() {
                    try {
                        String txt = new Gson().toJson(list);
                        if (!TextUtils.isEmpty(txt)) {
                            FilePathManager.jsonToFile(txt, STARTUP_SEARCH_CACHE);
                        }
                    }catch(Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
            }));
        }
    }

    public void initCache(JsonArray array, String tabType, int detailType) {

        if (array == null || TextUtils.isEmpty(tabType)) {
            return;
        }
        Gson gson = new Gson();
        List<TagItem> list = null;
        Type type = new TypeToken<List<TagItem>>() {}.getType();
        try {
            list = gson.fromJson(array, type);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }


        if (list != null && list.size() >0) {
            String cacheKey = getCacheKey(tabType, detailType);
            List<TagItem> listTagItem = mapList.get(cacheKey);
            if(listTagItem==null){
                listTagItem = new ArrayList<>();
                mapList.put(cacheKey, listTagItem);
            } else {
                listTagItem.clear();
            }

            int count = Math.min(list.size(), SEARCH_TAG_MAX);
            for(int i = 0; i < count; i++){
                list.get(i).tagID = list.get(i).term;
                list.get(i).name = list.get(i).term;
                listTagItem.add(list.get(i));
            }
        }
        //saveToCache(array.toString());

    }

    public List<TagItem> getData(String tabType, int detailType) {
        return mapList.get(getCacheKey(tabType, detailType));
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
        String fileName = getFileName(objects);

        if (fileName != null) {
            FilePathManager.jsonToFile(jsonBuffer, fileName);
        }

    }

    @Override
    public void loadFromCache(Object... objects) {
        if(objects!=null && objects.length > 1
                && (objects[0]!=null && objects[0] instanceof String)
                && (objects[1]!=null && objects[1] instanceof Integer)
                ){

            String fileName = getFileName(objects);

            if (fileName != null) {
                JsonArray jsonObject = (JsonArray) FilePathManager.fileToJson(fileName);
                if (jsonObject != null) {
                    initCache(jsonObject, (String) objects[0], (Integer) objects[1]);
                }
            }
        }

    }

    @Override
    public String getFileName(Object... objects) {
        if(objects!=null && objects.length > 1
                && (objects[0]!=null && objects[0] instanceof String)
                && (objects[1]!=null && objects[1] instanceof Integer)){
            return getCacheKey((String)objects[0], (Integer)objects[1]);
        }

        return null;
    }

    public String getCacheKey(String tabType, int detailType){
        if(!TextUtils.isEmpty(tabType)) {
            return CACHE_URL + "_" + tabType +"_" + detailType;
        }
        return "";
    }

}


package com.afmobi.palmplay.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.afmobi.palmplay.main.adapter.viewholder.BaseRecyclerViewAdapter;
import com.afmobi.palmplay.model.NotifyVaInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.FileUtils;
import com.transsion.palmstorecore.glide.GlideApp;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutFinishInstallItemBinding;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public class VaInstallNotifyAdapter extends BaseRecyclerViewAdapter {

    private ConfirmButtonClickListener mListener;
    private Context mContext;
    private List<NotifyVaInfo> mList = new ArrayList<>();

    public VaInstallNotifyAdapter(Context context) {
        mContext = context;
    }

    public void setListener(ConfirmButtonClickListener mListener) {
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VaInstallNotifyViewHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.layout_finish_install_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof VaInstallNotifyViewHolder) {
            LayoutFinishInstallItemBinding itemBinding = ((VaInstallNotifyViewHolder) holder).mBinding;
            NotifyVaInfo notifyVaInfo = mList.get(position);
            itemBinding.tvAppName.setText(notifyVaInfo.appName);
            if (BuildConfig.PROXY_VA) {
                itemBinding.ivAppIcon.setImageDrawable(VaStaticProxy.getGameIcon(notifyVaInfo.pkg));
            } else {
                String vaGameIconUrl = PsVaManager.getInstance().getVaGameIconUrl(notifyVaInfo.pkg);
                if (!TextUtils.isEmpty(vaGameIconUrl)){
                    GlideApp.with(itemBinding.ivAppIcon.getContext())
                            .load(vaGameIconUrl)
                            .apply(GlideUtils.newCommonRequestOptions())
                            .into(itemBinding.ivAppIcon);
                }
            }
            String size = mContext.getString(R.string.txt_apk_size);
            itemBinding.tvAppSize.setText(size + " " + FileUtils.getSizeName(notifyVaInfo.apkLength));
            itemBinding.tvPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mListener != null) {
                        mListener.onConfirmButtonClick(holder.getAbsoluteAdapterPosition(), null);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void setData(List<NotifyVaInfo> notifyVaInfoList) {
        mList = notifyVaInfoList;
        notifyDataSetChanged();
    }

    public class VaInstallNotifyViewHolder extends BaseRecyclerViewHolder {

        private LayoutFinishInstallItemBinding mBinding;

        public VaInstallNotifyViewHolder(ViewDataBinding itemView) {
            super(itemView.getRoot());

            mBinding = (LayoutFinishInstallItemBinding) itemView;
        }
    }

    public interface ConfirmButtonClickListener {
        //点击Play Now
        void onConfirmButtonClick(int position, String pkg);
    }
}

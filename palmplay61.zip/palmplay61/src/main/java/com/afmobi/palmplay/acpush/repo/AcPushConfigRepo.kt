package com.afmobi.palmplay.acpush.repo

import com.tencent.mmkv.MMKV
import com.transsion.palmstorecore.util.MMKVUtils
import org.json.JSONArray
import org.json.JSONObject

/**
 * AC-PUSH 配置仓库。
 *
 * 使用项目共享 MMKV 实例（MMKVUtils.getMMKV()），不创建独立命名空间。
 *
 * 配置字段：
 *   - updateCfg.interval      (Int)     常规拉取间隔，默认 12 小时
 *   - updateCfg.fastInterval  (Int)     S/A 高频拉取间隔，默认 6 小时
 *   - updateCfg.ac_update_enabled (Int) PM 下发 1/0，本地按 Boolean 存储；未下发时为 null
 *   - updateCfg.high_grade_list   (String) PM 下发的 S/A 包名列表 JSON 字符串，供高频请求使用
 *   - updateCfg.expId        (Int/String) PM 实验 id，用于通知曝光/点击埋点
 *   - updateCfg.varId        (Int/String) PM 实验变量 id，用于通知曝光/点击埋点
 *
 * 通过 update_config 由 PM 下发 config_json，AC 解析后落入。
 */
object AcPushConfigRepo {

    const val KEY_ENABLED = "ac_update_enabled"
    const val KEY_HIGH_GRADE_LIST = "high_grade_list"
    const val KEY_EXP_ID = "expId"
    const val KEY_VAR_ID = "varId"
    private const val FIELD_UPDATE_CFG = "updateCfg"
    private const val FIELD_INTERVAL = "interval"
    private const val FIELD_FAST_INTERVAL = "fastInterval"

    private const val KEY_REGULAR_HOUR = "acpush_cfg_regular_interval_hour"
    private const val KEY_HIGH_FREQ_HOUR = "acpush_cfg_high_freq_interval_hour"
    private const val KEY_HIGH_GRADE_LIST_JSON = "acpush_cfg_high_grade_list_json"
    private const val KEY_EXP_ID_VALUE = "acpush_cfg_exp_id"
    private const val KEY_VAR_ID_VALUE = "acpush_cfg_var_id"

    private const val DEFAULT_ENABLED = false
    private const val DEFAULT_REGULAR_HOUR = 12
    private const val DEFAULT_HIGH_FREQ_HOUR = 6

    private fun mmkv(): MMKV = MMKVUtils.getMMKV()

    /**
     * @return true / false 表示 PM 已明确下发开关；null 表示尚未收到 config。
     */
    fun enabledState(): Boolean? {
        val mmkv = mmkv()
        if (!mmkv.containsKey(KEY_ENABLED)) {
            return null
        }
        return mmkv.decodeBool(KEY_ENABLED, DEFAULT_ENABLED)
    }

    fun isEnabled(): Boolean = enabledState() == true

    fun regularHour(): Int =
        mmkv().decodeInt(KEY_REGULAR_HOUR, DEFAULT_REGULAR_HOUR).coerceAtLeast(1)

    fun highFreqHour(): Int =
        mmkv().decodeInt(KEY_HIGH_FREQ_HOUR, DEFAULT_HIGH_FREQ_HOUR).coerceAtLeast(1)

    fun highFreqPackageNames(): Set<String> {
        return parseHighGradeList(mmkv().decodeString(KEY_HIGH_GRADE_LIST_JSON, null))
    }

    fun expId(): String? = mmkv().decodeString(KEY_EXP_ID_VALUE, null)?.takeIf { !it.isNullOrEmpty() }

    fun varId(): String? = mmkv().decodeString(KEY_VAR_ID_VALUE, null)?.takeIf { !it.isNullOrEmpty() }

    /**
     * 应用 PM 通过 update_config 下发的 config_json。
     *
     * 容错策略：缺失字段保留旧值（不会被默认值覆盖）；JSON 完全异常时不写入。
     *
     * @return true 表示有任何字段被写入
     */
    fun applyAll(configJson: String?): Boolean {
        if (configJson.isNullOrBlank()) return false
        return try {
            val obj = JSONObject(configJson)
            val mmkv = mmkv()
            var changed = false
            val updateCfg = obj.optJSONObject(FIELD_UPDATE_CFG)
            if (updateCfg != null) {
                if (updateCfg.has(FIELD_INTERVAL)) {
                    mmkv.encode(KEY_REGULAR_HOUR, updateCfg.getInt(FIELD_INTERVAL))
                    changed = true
                }
                if (updateCfg.has(FIELD_FAST_INTERVAL)) {
                    mmkv.encode(KEY_HIGH_FREQ_HOUR, updateCfg.getInt(FIELD_FAST_INTERVAL))
                    changed = true
                }
                if (updateCfg.has(KEY_ENABLED)) {
                    val enabled = parseEnabled(updateCfg.getInt(KEY_ENABLED))
                    if (enabled != null) {
                        mmkv.encode(KEY_ENABLED, enabled)
                        changed = true
                    }
                }
                if (updateCfg.has(KEY_HIGH_GRADE_LIST)) {
                    mmkv.encode(KEY_HIGH_GRADE_LIST_JSON, updateCfg.optString(KEY_HIGH_GRADE_LIST, ""))
                    changed = true
                }
                if (updateCfg.has(KEY_EXP_ID)) {
                    mmkv.encode(KEY_EXP_ID_VALUE, updateCfg.optString(KEY_EXP_ID, ""))
                    changed = true
                }
                if (updateCfg.has(KEY_VAR_ID)) {
                    mmkv.encode(KEY_VAR_ID_VALUE, updateCfg.optString(KEY_VAR_ID, ""))
                    changed = true
                }
            }
            changed
        } catch (e: Exception) {
            false
        }
    }

    private fun parseHighGradeList(raw: String?): Set<String> {
        if (raw.isNullOrBlank()) return emptySet()
        return try {
            val array = JSONArray(raw)
            val packages = LinkedHashSet<String>()
            for (i in 0 until array.length()) {
                val packageName = array.optString(i)
                if (packageName.isNotBlank()) {
                    packages.add(packageName)
                }
            }
            packages
        } catch (e: Exception) {
            emptySet()
        }
    }

    private fun parseEnabled(value: Int): Boolean? {
        return when (value) {
            1 -> true
            0 -> false
            else -> null
        }
    }
}

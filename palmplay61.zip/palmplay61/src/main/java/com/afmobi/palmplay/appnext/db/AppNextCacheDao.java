package com.afmobi.palmplay.appnext.db;

import androidx.room.Dao;
import androidx.room.Entity;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.PrimaryKey;
import androidx.room.Query;
import androidx.room.Update;

import com.android.remindmessage.database.ApkRetainTable;

import java.util.List;

/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 15:05
 * @Desc: add your description
 */
@Dao
public interface AppNextCacheDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(AppNextCache appNextCache);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<AppNextCache> appNextCacheList);

    @Query("SELECT * FROM AppNextCache")
    List<AppNextCache> getAppNextCacheList();

    @Update
    void update(AppNextCache appNextCache);

    @Query("delete FROM AppNextCache where packageNameWithAction=:packageNameWithAction")
    void deleteByPkg(String packageNameWithAction);

}

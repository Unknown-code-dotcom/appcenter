package com.afmobi.palmplay.cloudfolder.page

import androidx.fragment.app.Fragment
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.transsnet.launcherlib.util.AthenaUtil

abstract class BaseCloudFolderFragment() : Fragment() {

    protected var categoryType: Int = CATEGORY_APP
    private var enterTime: Long = 0

    /**
     * 进入来源：1=点击 tab 进入，2=手势滑动进入
     * 由宿主 Activity 在页面切换时设置
     */
    var enterFrom: Int = CloudFolderTrackUtil.STATUS_ENTER_CLICK

    abstract fun updateDarkUI()

    open fun refreshIconStyle() = Unit

    override fun onResume() {
        super.onResume()
        enterTime = System.currentTimeMillis()
    }

    override fun onPause() {
        super.onPause()
        if (enterTime > 0) {
            val stayTime = System.currentTimeMillis() - enterTime
            AthenaUtil.trackFileFolderV2(AthenaUtil.TRACK_TYPE_CLOUD_FOLDER_SHOW, categoryType, 0,   stayTime.toString())
            enterTime = 0
        }
    }
}

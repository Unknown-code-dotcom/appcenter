package com.afmobi.palmplay.admgr.hisavana_sdk;



/**
 * Created by hexiuhui on 2022/12/12.
 */
public class SceneCode {

    public static final String R_SP = "R_SP";  //开屏页

    public static final String H_ba = "H_ba";  //首页banner

    public static final String H_nba = "H_nba";  //首页banner（新）

    public static final String SSR_hl = "SSR_hl";  //搜索结果长列表
    public static final String SSR_hl2 = "SSR_hl2";

    public static final String SS_X = "SS_X";  //搜索默认页推荐

    public static final String SSR_nl = "SSR_nl";  //搜索无结果

    public static final String SSR_hlre = "SSR_hlre";  //搜索结果推荐

    public static final String A_ho = "A_ho";  //app_hot

    public static final String A_ne = "A_ne";  //app_new

    public static final String A_fe = "A_fe";  //app_featured

    public static final String G_ho = "G_ho";  //game_hot

    public static final String G_ne = "G_ne";  //game_new

    public static final String G_fe = "G_fe";  //game_featured

    public static final String H_fe = "H_fe";  //首页专题

    public static final String AD_de = "AD_de";  //应用详情页底部专题

    public static final String AD_fe = "AD_fe";  //应用详情featured专题

    public static final String D_ym = "D_ym";  //下载管理-底部专题

    public static final String UP_YM = "UP_YM";  //应用升级-底部推荐

    public static final String JF_MR = "JF_MR";  //垃圾清理-底部推荐

    public static final String NR_X = "NR_X";  //新用户装机必备

    public static final String AR_X = "AR_X";  //老用户装机必备

    public static final String PLUTO_X = "PL_X"; //pluto场景

    public static final String OO_X = "OO_X"; //新客提醒场景

    public static final String FLOAT_X = "R_SW"; //悬浮场景

    public static final String INSERT_SCREEN_X = "R_PP";//插屏场景

    public static final String NOTICE_BOARD_X = "B_X"; //常驻通知

    public static final String I_FE = "I_fe"; //Instant页

    public static final String ME_O = "ME_O";

    public static final String RC_X = "RC_X";

    public static final String SSL_X = "SSL_X"; // 搜索联想页

}

package com.afmobi.palmplay.appmanage.holder;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.afmobi.palmplay.appmanage.FileManageDownloadAdapterItem;
import com.afmobi.palmplay.appmanage.adapter.FileManageDownloadAdapter;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.CommonUtils;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 下载中模块的title
 * Created by xiangfei.wei on 2018/12/20.
 */
public class DownloadingTitleViewHolder extends RecyclerView.ViewHolder {
    private Context mContext;
    private PageParamInfo mPageParamInfo;
    private TextView tv_downloading_task;
    private TextView tv_downloading_all;
    private FileManageDownloadAdapter mAdapter;
    /**
     * 新型打点的from值
     */
    public String mFrom;

    public DownloadingTitleViewHolder(@NonNull View itemView) {
        super(itemView);
        tv_downloading_task = itemView.findViewById(R.id.tv_downloading_task);
        tv_downloading_all = itemView.findViewById(R.id.tv_downloading_all);
    }

    public DownloadingTitleViewHolder setContext(Context context) {
        mContext = context;
        return this;
    }

    public DownloadingTitleViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        mPageParamInfo = pageParamInfo;
        return this;
    }

    public DownloadingTitleViewHolder setAdapter(FileManageDownloadAdapter adapter) {
        mAdapter = adapter;
        return this;
    }

    public DownloadingTitleViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public DownloadingTitleViewHolder bind(FileManageDownloadAdapterItem itemData, int position) {
        if (tv_downloading_task != null) {
            String downloading = mContext.getString(R.string.text_installing);
//            int downloadingCount = DownloadManager.getInstance().getShadowDownloadingInfoListSize();
            int downloadingCount = itemData.downloadingCount;
            if (downloadingCount > 99) {
                downloading = downloading + "(99+)";
            } else if (downloadingCount > 0) {
                downloading = downloading + "(" + downloadingCount + ")";
            }
            tv_downloading_task.setText(downloading);
        }

        List<FileDownloadInfo> list = DownloadManager.getInstance().getShadowDownloadingInfoList();
        if (mAdapter.isExistDownloading(list)) {
            tv_downloading_all.setVisibility(View.VISIBLE);
            tv_downloading_all.setText(R.string.pause_all);
        } else if (mAdapter.isExistUnDownload(list)){
            tv_downloading_all.setVisibility(View.VISIBLE);
            tv_downloading_all.setText(R.string.txt_continue_all);
        } else {
            tv_downloading_all.setVisibility(View.GONE);
        }
        tv_downloading_all.setOnClickListener(new View.OnClickListener() {
            @Override
            @SingleClick(800)
            public void onClick(View v) {
                if (mAdapter.getItemCount() > 0) {
                    String buttonType = TRAnalyticsConstant.BUTTON;
                    if (tv_downloading_all.getText().equals(mContext.getResources().getString(R.string.txt_continue_all))) {
                        FirebaseAnalytics.getInstance(mContext.getApplicationContext()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_STARTALL_CLICK, null);

                        //打点
                        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.deliverPageParamInfo(mPageParamInfo, PageConstants.Download_Soft_Allcontinue));
                        resumeDownloadAll();
                        buttonType = TRAnalyticsConstant.BUTTON_START_ALL;

                    } else if (tv_downloading_all.getText().equals(mContext.getResources().getString(R.string.pause_all))) {
                        FirebaseAnalytics.getInstance(mContext.getApplicationContext()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_PAUSEALL_CLICK, null);

                        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.deliverPageParamInfo(mPageParamInfo, PageConstants.Download_Soft_Allpause));
                        pauseAll();
                        buttonType = TRAnalyticsConstant.BUTTON_STOP_ALL;
                        //tv_downloading_all.setText(getResources().getString(R.string.start_all));
                    }
                    //mAdapter.onResume();
                    mAdapter.notifyDataSetChanged();

                    //x	x	D_do_x_x	"点击Downlodaing的Start ALL&Pause All 按钮"
                    String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, TRAnalyticsConstant.MODULE_DOWNLOADING, "", "");
                    ComponentClickBuilder builder = new ComponentClickBuilder();
                    builder.setValue(value)
                            .setFrom(mFrom)
                            .setTopicType("")
                            .setTopicId("")
                            .setItemType("")
                            .setItemId("")
                            .setButtonType(buttonType)
                            .setItemValue("")
                            .setExtraValue("");
                    TRAnalysticsUtil.trackClick(builder);
                }
            }
        });
        return this;
    }

    private void pauseAll() {
        List<FileDownloadInfo> dstList = DownloadManager.getInstance().onDownloadingBatchPause(DownloadManager.getInstance().getShadowDownloadingInfoList());
        CommonUtils.onHandleWiFiRetrieve(dstList,false);
    }

    private void resumeDownloadAll() {
        DownloadUtil.resumeDownload(mContext, DownloadManager.getInstance().getShadowDownloadingInfoListNoVa(), true);
    }
}

package com.afmobi.palmplay.activate;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.ActivityInfoCache;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.cache.v6_0.StartUpTabsCache;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.v7_x.ActivityInfo;
import com.afmobi.palmplay.model.v7_x.NavigationAd;
import com.afmobi.palmplay.model.v7_x.NavigationAdConfig;
import com.afmobi.palmplay.network.NetworkClient;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.NetworkUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.xwebview.preload.PreLoadConstants;
import com.transsion.xwebview.preload.UrlPreLoadProcessor;

import java.util.List;

import static com.afmobi.palmplay.activate.TRActivateConstant.NAV_AD_LOADTIME;
import static com.afmobi.palmplay.cache.ActivityInfoCache.ACTIVITY_INFO_CACHE;

/***
 * 底部tab的中间活动的业务执行者
 */
public class TRNavActivateExecutor extends TRBaseExecutor<ActivityInfo> {
    private static final String NAVIGATION_AD_CONFIG = "navigation_ad_config";
    private static long durationTime = BuildConfig.DEBUG ? 2 * 60 * 1000 : 4 * 60 * 60 * 1000;//定时器的间隔时间
    private static ActivityInfo navBean;//内存缓存
    private static volatile long requestTime;//请求时间存放内存

    private NavigationAdConfig navigationAdConfig;

    public TRNavActivateExecutor() {
        //取一次值，后续判断不需要取，直接拿内存的值使用。提高效率
        requestTime =  SPManager.getLong(NAV_AD_LOADTIME, 0);
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
            @Override
            public void run() {
                navigationAdConfig = (NavigationAdConfig) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(NAVIGATION_AD_CONFIG);
            }
        });
    }

    @Override
    public void loadData() {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {

            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_REQ, TRAnalyticsConstant.NAV_ACTIVATE_REQ_NO_NET, null);
            return;
        }

        long interval = -1;

        if(navigationAdConfig != null) {
            if(navBean == null) {
                interval = navigationAdConfig.loadTimeInterval * 60 * 60 * 1000L;
            } else {
                interval = navigationAdConfig.reloadTimeInterval * 60 * 60 * 1000L;
            }
        }

        if(interval <= 0) {
            interval = durationTime;
        }

        if (System.currentTimeMillis() - requestTime < interval) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_REQ, TRAnalyticsConstant.NAV_ACTIVATE_REQ_INTERVAL,null);
            //不满足间隔时间
            return;
        }

        PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_REQ, TRAnalyticsConstant.NAV_ACTIVATE_REQ_NORMAL,null);

        NetworkClient.pullNanvData(new AbsRequestListener<GenericResponseInfo<NavigationAd>>() {
            @Override
            public void onResponse(GenericResponseInfo<NavigationAd> response) {
                requestTime = System.currentTimeMillis();
                SPManager.putLong(NAV_AD_LOADTIME, requestTime);

                if (response == null || !response.isSuccess() || response.getData() == null) {
                    PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_RES, TRAnalyticsConstant.NAV_ACTIVATE_RES_NO_NAV,null);

                    return;
                }

                navigationAdConfig = response.getData().adConfigDTO;
                ACache.get(PalmplayApplication.getAppInstance()).put(NAVIGATION_AD_CONFIG, navigationAdConfig);

                List<ActivityInfo> list = response.getData().adList;
                ActivityInfo activityInfo = null;
                if(list != null && list.size() > 0) {
                    PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_RES, TRAnalyticsConstant.NAV_ACTIVATE_RES_NAV, null);
                    activityInfo = list.get(0);
                }
                if(activityInfo == null) {
                    PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_RES, TRAnalyticsConstant.NAV_ACTIVATE_RES_DATA_NULL,null);
                    return;
                }

                if(TextUtils.isEmpty(activityInfo.jumpType)){
                    PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_RES, TRAnalyticsConstant.NAV_ACTIVATE_RES_DATA_JUMP_TYPE_ERROR,null);

                    return;
                }
                //url预加载
                UrlPreLoadProcessor.handlePreLoadLogicWithThread(PreLoadConstants.TAB, activityInfo.jumpType, activityInfo.jumpUrl,
                        ConfigManager.isPreLoadOn(), StartUpTabsCache.getInstance().inInUrlWhiteList(activityInfo.jumpUrl));
                parseData(activityInfo);
            }

            @Override
            public void onError(ANError anError) {
                PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_RES, TRAnalyticsConstant.NAV_ACTIVATE_RES_FAIL,null);
                requestTime = System.currentTimeMillis();
                SPManager.putLong(NAV_AD_LOADTIME, requestTime);
            }

        }, TRNavActivateExecutor.class.toString());
    }

    @Override
    public void parseData(ActivityInfo actInfo) {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
            @Override
            public void run() {
                navBean = actInfo;
                if (navBean == null || TextUtils.isEmpty(navBean.jumpType)) {
                    PalmplayApplication.getAppInstance()
                            .getAppDataManager().trackHomeNavActivate(TRAnalyticsConstant.NAV_ACTIVATE_RES, TRAnalyticsConstant.NAV_ACTIVATE_RES_DATA_NULL,null);
                    return;
                }
                if (!TRStringUtil.isBlank(navBean.activityIconUrl)) {
                    //非选中的图片缓存
                    boolean isCached= TRBitmapManager.isImageCachedWithSmallCache(navBean.activityIconUrl);
                    if (!isCached) {//图片缓存
                        TRBitmapManager.preLoadImageWithSmallCache(navBean.activityIconUrl, null, null);
                    }
                }
                if (!TRStringUtil.isBlank(navBean.iconUrlNew)) {
                    //选中的图片缓存
                    boolean isCached= TRBitmapManager.isImageCachedWithSmallCache(navBean.iconUrlNew);
                    if (!isCached) {//图片缓存
                        TRBitmapManager.preLoadImageWithSmallCache(navBean.iconUrlNew, null, null);
                    }
                }
                cacheData(navBean);//持久化

                DetailCacheManager.getInstance().addItemByObject(actInfo);
            }
        });

    }

    @Override
    public void cacheData(ActivityInfo data) {
        if (data != null) {
            ACache.get(PalmplayApplication.getAppInstance()).put(ACTIVITY_INFO_CACHE, data);
        }
    }

    @Override
    public ActivityInfo getData() {
        //先从内存取
        if (navBean == null) {
            navBean = ActivityInfoCache.getInstance().loadFromCache();
        }
        return navBean;
    }


}

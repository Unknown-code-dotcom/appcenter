// TOP SECRET
package com.afmobi.palmplay.category;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.customview.XModeView;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommonInfo;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.VaParseBean;
import com.afmobi.palmplay.model.VaParseData;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.va.LiveDataBus;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.FileUtils;
import com.afmobi.util.IMessenger;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;

public class DetailDownloadButtonListener implements InterfaceStatusChange {

    private Context mContext;
    private TextView mDownloadcountView;
    private CommonInfo mCommonInfo;
    private XFermodeDownloadView mDownloadBtn;
    private OfferInfo mOfferInfo;
    private boolean isCustomized;

    private IMessenger mIMessenger;
    private boolean isIMessengerProgressCallback = false;
    private boolean isVa = false;
    private boolean isVaInstallSuccess = false;

    public void setIMessenger(IMessenger l, boolean isIMessengerProgressCallback) {
        mIMessenger = l;
        this.isIMessengerProgressCallback = isIMessengerProgressCallback;
    }


    public DetailDownloadButtonListener(Context context, XFermodeDownloadView downloadBtn, TextView downloadcountView, CommonInfo dataInfo, boolean isCustomized) {
        mContext = context;
        mDownloadBtn = downloadBtn;
        mDownloadcountView = downloadcountView;
        mCommonInfo = dataInfo;
        this.isCustomized = isCustomized;
        initOfferInfo();
    }

    public void setmDataInfo(CommonInfo dataInfo) {
        this.mCommonInfo = dataInfo;
        initOfferInfo();
    }

    private void initOfferInfo() {
        if (this.mCommonInfo instanceof AppInfo) {
            AppInfo appInfo = (AppInfo) this.mCommonInfo;
            if (mOfferInfo == null) {
                mOfferInfo = new OfferInfo();
            }
            mOfferInfo.convertData(appInfo);
            mOfferInfo.setCustomized(this.isCustomized);
        }
    }

    /**
     * 是否为offer风格
     */
    private boolean isOfferStyle() {
        return (isCustomized);
    }

    public void updateVaUI() {
        updateStatusChanged();
    }
    @SuppressWarnings("deprecation")
    public void updateStatusChanged() {
        // TODO Auto-generated method stub
        DownloadStatusManager.getInstance().registerInfoInstance(mCommonInfo);

        //详情页下载按钮UX不一样，单独处理
        if (mDownloadBtn == null) {
            return;
        }
        //更新应用、state是4、并且不在安装失败集合中-拦截state为4的显示
        if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED) {
            if (!CommonUtils.isPackageInFailList(mCommonInfo.packageName)) {
                FileDownloadInfo downloadInfo1 = DownloadManager.getInstance().getDownloadedInfo(mCommonInfo.packageName);
                if (downloadInfo1 != null && downloadInfo1.extraInfo != null && downloadInfo1.extraInfo.isUpdate.equals("T")) {
                    return;
                }
            }
        }

        if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
            // 文件下载完成，正在进行校验，此时不处理点击事件，页面显示进度100%
            if (BuildConfig.DEBUG) {
                Log.e("checkDownloadInfo", "文件下载完成，校验中...", new Throwable("who call me"));
            }
            return;
        }


        isVa = mCommonInfo.isVa && !DownloadStatusManager.getInstance().isApkVaPackageFlag(mCommonInfo.packageName);
        mDownloadBtn.setOfferInfo(mOfferInfo);

        LogUtils.d(LogUtils.TAG_TR_D_VA_DOWNLOAD,"详情页isVa:"+isVa +",observerStatus:"+mCommonInfo.observerStatus + ",packageName:"+mCommonInfo.packageName);
        XModeView tv_download = mDownloadBtn.getDownloadView();
        ProgressBar progressbar_downloading = mDownloadBtn.getProgressBar();
        View downloadBtnBg = mDownloadBtn.getLayoutDownloadBackground();

        if (tv_download != null) {
            if (isVa) {
                mDownloadBtn.onAppDefault();
                tv_download.setText(R.string.text_play);
                return;
            }

            // 提取变量，统一控制是否显示双尺寸
            boolean shouldShowDualSize = false;
            String baseStatusText = null;
            String dualSizeSuffix = null;
            int crossStart = 0;
            int crossEnd = 0;

            // 差分升级
            if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE
                    && mCommonInfo instanceof AppInfo
                    && ((AppInfo) mCommonInfo).diffSize > 0) {

                long originalSize = mCommonInfo.size;          // 原包大小
                long actualDownloadSize = ((AppInfo) mCommonInfo).diffSize; // 差分包大小


                if (CommonUtils.isShowDualSize(originalSize, actualDownloadSize)) {
                    shouldShowDualSize = true;
                    baseStatusText = mDownloadBtn.getContext().getResources()
                            .getString(isVa ? CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus)
                                    : mCommonInfo.getStatusNameResID());

                    String diffSizeStr = FileUtils.getSizeName(actualDownloadSize);
                    String fullSizeStr = FileUtils.getSizeName(originalSize);

                    Configuration config = mContext.getResources().getConfiguration();
                    if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
                        dualSizeSuffix = " (" + diffSizeStr + " " + fullSizeStr + ")";
                        //使用crossStart，crossEnd统一管理划线位置，使得划线逻辑更清晰
                        crossStart = 3 + diffSizeStr.length();
                        crossEnd = crossStart + fullSizeStr.length();
                    } else {
                        dualSizeSuffix = " (" + fullSizeStr + " " + diffSizeStr + ")";
                        crossStart = dualSizeSuffix.indexOf("(") + 1;
                        crossEnd = crossStart + fullSizeStr.length();
                    }
                }
            }
            //  压缩包
            else if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_NONE
                    && mCommonInfo instanceof AppInfo
                    && ((AppInfo) mCommonInfo).compSourceSize > 0) {

                long originalSize = mCommonInfo.size;               // 原始未压缩大小
                long actualDownloadSize = ((AppInfo) mCommonInfo).compSourceSize; // 压缩后大小

                if (CommonUtils.isShowDualSize(originalSize, actualDownloadSize)) {
                    shouldShowDualSize = true;
                    if(isQuickOpenButton(mDownloadBtn, mCommonInfo)) {
                        baseStatusText = mDownloadBtn.getContext().getResources().getString(R.string.text_open);
                    } else {
                        baseStatusText = mDownloadBtn.getContext().getResources()
                                .getString(isVa ? CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus)
                                        : mCommonInfo.getStatusNameResID());
                    }
                    String compressSizeStr = FileUtils.getSizeName(actualDownloadSize);
                    String fullSizeStr = FileUtils.getSizeName(originalSize);

                    Configuration config = mContext.getResources().getConfiguration();
                    if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
                        dualSizeSuffix = " (" + compressSizeStr + " " + fullSizeStr + ")";
                        crossStart = 3 + compressSizeStr.length();
                        crossEnd = crossStart + fullSizeStr.length();
                    } else {
                        dualSizeSuffix = " (" + fullSizeStr + " " + compressSizeStr + ")";
                        crossStart = dualSizeSuffix.indexOf("(") + 1;
                        crossEnd = crossStart + fullSizeStr.length();
                    }
                }
            }

            // 统一应用结果，避免重复 setText 和 setCrossLine逻辑
            if (shouldShowDualSize) {
                String finalText = baseStatusText + dualSizeSuffix;
                tv_download.setCrossLineText(baseStatusText, dualSizeSuffix);
                tv_download.setCrossLine(crossStart, crossEnd);

                if (isVa) {
                    if (mCommonInfo.observerStatus != FileDownloadInfo.STATUS_DOWNLOADED) {
                        tv_download.setText(finalText);
                    }
                } else {
                    tv_download.setText(finalText);
                }
            } else {
                // 不满足双尺寸条件，清除划线，使用普通状态文本
                tv_download.setCrossLine(0, 0);

                if (isVa) {
                    if (mCommonInfo.observerStatus != FileDownloadInfo.STATUS_DOWNLOADED) {
                        tv_download.setText(mDownloadBtn.getContext().getResources()
                                .getString(CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus)));
                    }
                } else {
                    if(isQuickOpenButton(mDownloadBtn, mCommonInfo)) {
                        tv_download.setText(mDownloadBtn.getContext().getResources().getString(R.string.text_open));
                    } else {
                        tv_download.setText(mDownloadBtn.getContext().getResources()
                                .getString(mCommonInfo.getStatusNameResID()));
                    }
                }
            }
        }


        // 后续 UI 控制（进度条、颜色、背景等）保持完全不变
        if (tv_download == null || progressbar_downloading == null || downloadBtnBg == null) {
            return;
        }

        int observerStatus = mCommonInfo.observerStatus;
        FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadingInfo(mCommonInfo.packageName);
        OfferInfo offerInfo = mOfferInfo;
        int defaultColor = ContextCompat.getColor(mContext, R.color.detail_btn_text_color);
        int normalColor = ContextCompat.getColor(mContext, R.color.detail_btn_normal_text_color);
        int maskingColor = ContextCompat.getColor(mContext, R.color.detail_offer_masking_color);
        int mCorners = mContext.getResources().getDimensionPixelSize(R.dimen.detail_btn_corner);
        int txtBgSpecialDrawableId = mDownloadBtn.getTextSpecialBackgroundId();
        int textSpecialColorId = mDownloadBtn.getTextSpecialColorId();

        if ("T".equals(mCommonInfo.showPlay)) {
            if (isOfferStyle()) {
                progressbar_downloading.setVisibility(View.GONE);
                CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
                downloadBtnBg.setVisibility(View.VISIBLE);
                tv_download.setTextColor(offerInfo.mainColor);
                tv_download.setProgress(0);
            } else {
                progressbar_downloading.setVisibility(View.GONE);
                tv_download.setProgress(0);
                downloadBtnBg.setVisibility(View.VISIBLE);
                tv_download.setTextColor(defaultColor);
            }
            return;
        }
        LogUtils.d(LogUtils.TAG_TR_D_VA_PARSE, "initParseDetailObserver--------0  downloadInfo" +downloadInfo);

        if (downloadInfo != null) {
            float progress = 0;
            if (downloadInfo.sourceSize > 0) {
                progress = downloadInfo.downloadedSize * 100f / downloadInfo.sourceSize;
            }
            if (isVa) {
                progress = PsVaManager.getInstance().getVaDownloadingProgress(progress);
            }
            BigDecimal bd = new BigDecimal(progress);
            float prg = bd.setScale(1, BigDecimal.ROUND_HALF_UP).floatValue();
            progressbar_downloading.setProgress((int) prg);

            if (isVa) {
                if (FileDownloadInfo.isVaDownloading(observerStatus)) {
                    String textProgress = prg + "%";
                    tv_download.setText(textProgress);
                }
                tv_download.setProgress(prg); //设置反色范围

            } else {
                if (FileDownloadInfo.isDownloading(observerStatus)) {
                    String textProgress = prg + "%";
                    tv_download.setText(textProgress);
                }
                tv_download.setProgress(prg); //设置反色范围
            }
        } else {
            if (isVa && observerStatus == FileDownloadInfo.STATUS_DOWNLOADED && PsVaManager.getInstance().isShowParseProgress(mCommonInfo.packageName)) {
                initParseDetailObserver(mDownloadBtn,mCommonInfo.itemID);
                PsVaManager.getInstance().setVaParseProgress(mCommonInfo.itemID);
            }
        }

        if(isVa){
            switch (observerStatus) {
                case FileDownloadInfo.STATUS_DOWNING:
                //case FileDownloadInfo.STATUS_DOWNLOADED:
                case FileDownloadInfo.STATUS_APP_UPDATE:
                    progressbar_downloading.setVisibility(View.VISIBLE);
                    progressbar_downloading.setSelected(false);
                    downloadBtnBg.setVisibility(View.GONE);
                    progressbar_downloading.setProgress(0);
                    tv_download.setProgress(0);
                    tv_download.setTextColor(normalColor);
                    tv_download.setTextBackgroundResource(-1);
                    break;
                case FileDownloadInfo.STATUS_DOWNLOADED:
                    progressbar_downloading.setVisibility(View.GONE);
                    progressbar_downloading.setSelected(false);
                    downloadBtnBg.setVisibility(View.VISIBLE);
                    tv_download.setProgress(0);
                    tv_download.setTextColor(defaultColor);
                    tv_download.setTextBackgroundResource(-1);
                    tv_download.setText(R.string.text_install);
                    break;
                case FileDownloadInfo.STATUS_APP_INSTALLED:
                    progressbar_downloading.setVisibility(View.GONE);
                    tv_download.setProgress(0);
                    downloadBtnBg.setVisibility(View.VISIBLE);
                    tv_download.setTextColor(defaultColor);
                    tv_download.setTextBackgroundResource(-1);
                    isVaInstallSuccess = true;
                    break;
                case FileDownloadInfo.STATUS_WAIT:
                case FileDownloadInfo.STATUS_PAUSE:
                    progressbar_downloading.setVisibility(View.VISIBLE);
                    progressbar_downloading.setSelected(true);
                    downloadBtnBg.setVisibility(View.GONE);
                    tv_download.setTextColor(normalColor);
                    tv_download.setTextBackgroundResource(-1);
                break;
                case FileDownloadInfo.STATUS_NETWORK_ERROR:
                    progressbar_downloading.setVisibility(View.GONE);
                    progressbar_downloading.setSelected(true);
                    downloadBtnBg.setVisibility(View.VISIBLE);
                    tv_download.setProgress(0);
                    tv_download.setTextColor(defaultColor);
                    tv_download.setTextBackgroundResource(-1);
                    break;
                case FileDownloadInfo.STATUS_APP_VA_INSTALLED_FAIL:
                case FileDownloadInfo.STATUS_NONE:
                default:
                    progressbar_downloading.setVisibility(View.GONE);
                    tv_download.setProgress(0);
                    downloadBtnBg.setVisibility(View.VISIBLE);
                    tv_download.setTextColor(defaultColor);
                    tv_download.setTextBackgroundResource(-1);
                    break;
            }
        }else {
            tv_download.clearLeftIcon();
            switch (observerStatus) {
                case FileDownloadInfo.STATUS_WAIT:
                case FileDownloadInfo.STATUS_DOWNING:
                    if (isOfferStyle()) {
                        progressbar_downloading.setVisibility(View.VISIBLE);
                        progressbar_downloading.setSelected(false);
                        CommonUtils.setProgressBarDrawable(progressbar_downloading, offerInfo.pbBgColor, offerInfo.getButtonColor(), mCorners);
                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), maskingColor, mCorners);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(offerInfo.getButtonColor());
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        mDownloadBtn.onAppDownloadingOrWait();
                    } else {

                        progressbar_downloading.setVisibility(View.VISIBLE);
                        progressbar_downloading.setSelected(false);
                        downloadBtnBg.setVisibility(View.GONE);
                        tv_download.setTextColor(normalColor);
                        tv_download.setTextBackgroundResource(-1);
                    }
                    break;

                case FileDownloadInfo.STATUS_PAUSE:
                    if (isOfferStyle()) {
                        progressbar_downloading.setVisibility(View.VISIBLE);
                        progressbar_downloading.setSelected(false);
                        CommonUtils.setProgressBarDrawable(progressbar_downloading, offerInfo.pbBgColor, offerInfo.getButtonColor(), mCorners);
                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), maskingColor, mCorners);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(offerInfo.getButtonColor());
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        mDownloadBtn.onAppPaused();
                    } else {
                        progressbar_downloading.setVisibility(View.VISIBLE);
                        progressbar_downloading.setSelected(true);
                        downloadBtnBg.setVisibility(View.GONE);
                        tv_download.setTextColor(normalColor);
                        tv_download.setTextBackgroundResource(-1);
                    }
                    break;
                case FileDownloadInfo.STATUS_NETWORK_ERROR:
                    if (isOfferStyle()) {
                        progressbar_downloading.setVisibility(View.GONE);
                        progressbar_downloading.setSelected(true);
                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(offerInfo.mainColor);
                        tv_download.setProgress(0);
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        mDownloadBtn.onAppNetworkError();
                    }else {
                        progressbar_downloading.setVisibility(View.GONE);
                        progressbar_downloading.setSelected(true);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setProgress(0);
                        tv_download.setTextColor(defaultColor);
                        tv_download.setTextBackgroundResource(-1);
                    }
                    break;
                case FileDownloadInfo.STATUS_DOWNLOADED:
                    updateUI(tv_download, progressbar_downloading, downloadBtnBg, offerInfo, defaultColor, mCorners);
                    break;
                case FileDownloadInfo.STATUS_APP_UPDATE:
                    if (isOfferStyle()) {
                        progressbar_downloading.setVisibility(View.GONE);
                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(offerInfo.mainColor);
                        tv_download.setProgress(0);
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        mDownloadBtn.onAppUpdate();
                    } else {
                        progressbar_downloading.setVisibility(View.GONE);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setProgress(0);
                        tv_download.setTextColor(defaultColor);
                        tv_download.setTextBackgroundResource(-1);
                    }
                    break;
                case FileDownloadInfo.STATUS_APP_INSTALLED:
                    if (isOfferStyle()) {
                        progressbar_downloading.setVisibility(View.GONE);
                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(offerInfo.mainColor);
                        tv_download.setProgress(0);
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        mDownloadBtn.onAppInstalled();
                        mDownloadBtn.resetDefaultDownloadBg();
                    } else {
                        progressbar_downloading.setVisibility(View.GONE);
                        progressbar_downloading.setSelected(false);
                        progressbar_downloading.setProgress(0);
                        tv_download.setProgress(0);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColorId(textSpecialColorId);
                        tv_download.setTextBackgroundResource(txtBgSpecialDrawableId);
                    }
                    break;
                case FileDownloadInfo.STATUS_INSTALLING:
                    if (isOfferStyle()) {
                        CommonUtils.setProgressBarDrawable(progressbar_downloading, offerInfo.pbBgColor, offerInfo.getButtonColor(), mCorners);
                        progressbar_downloading.setVisibility(View.VISIBLE);
                        progressbar_downloading.setSelected(true);
                        progressbar_downloading.setProgress(100);
                        tv_download.setTextColor(offerInfo.mainColor, true);
                        tv_download.setProgress(100);
                        downloadBtnBg.setVisibility(View.GONE);
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        mDownloadBtn.onAppInstalling();
                    } else {
                        progressbar_downloading.setVisibility(View.VISIBLE);
                        progressbar_downloading.setSelected(true);
                        progressbar_downloading.setProgress(100);
                        tv_download.setProgress(100);
                        downloadBtnBg.setVisibility(View.GONE);
                        tv_download.setTextColor(normalColor);
                        tv_download.setTextBackgroundResource(-1);
                    }
                    break;
                case FileDownloadInfo.STATUS_NONE:
                default:
                    if (isOfferStyle()) {
                        progressbar_downloading.setVisibility(View.GONE);
                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(offerInfo.mainColor);
                        tv_download.setProgress(0);
                        if(mDownloadBtn.isQuickOpenStyle()) {
                            Drawable boltDrawable = AppCompatResources.getDrawable(mDownloadBtn.getContext(), R.drawable.ic_quick_open_bolt_white);
                            if(boltDrawable!=null) {
                                int w=DisplayUtil.dip2px(mDownloadBtn.getContext(),20);
                                tv_download.setLeftIcon(boltDrawable, DisplayUtil.dip2px(mDownloadBtn.getContext(), 1f),w);
                            }
                        }
                    } else if (mDownloadBtn.isQuickOpenStyle()) {
                        progressbar_downloading.setVisibility(View.GONE);
                        tv_download.setProgress(0);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(defaultColor);
                        tv_download.setTextBackgroundResource(-1);
                        downloadBtnBg.setBackgroundResource(R.drawable.bg_quick_install_button_default);
                        Drawable boltDrawable = AppCompatResources.getDrawable(mDownloadBtn.getContext(), R.drawable.ic_quick_open_bolt_white);
                        if(boltDrawable!=null) {
                            int w=DisplayUtil.dip2px(mDownloadBtn.getContext(),20);
                            tv_download.setLeftIcon(boltDrawable, DisplayUtil.dip2px(mDownloadBtn.getContext(), 1f),w);
                        }
                    } else {
                        progressbar_downloading.setVisibility(View.GONE);
                        tv_download.setProgress(0);
                        downloadBtnBg.setVisibility(View.VISIBLE);
                        tv_download.setTextColor(defaultColor);
                        tv_download.setTextBackgroundResource(-1);
                    }
            }
        }
    }

    private boolean isQuickOpenButton(XFermodeDownloadView mDownloadBtn, CommonInfo mCommonInfo) {
        return mDownloadBtn.isQuickOpenStyle() && mCommonInfo.observerStatus == FileDownloadInfo.STATUS_NONE;
    }

    private void updateDownloadButtonText(XModeView tv_download, boolean isVa) {
        if (!(mCommonInfo instanceof AppInfo)) {
            tv_download.setCrossLine(0, 0);
            if (isVa && mCommonInfo.observerStatus != FileDownloadInfo.STATUS_DOWNLOADED) {
                tv_download.setText(CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus));
            } else {
                tv_download.setText(mCommonInfo.getStatusNameResID());
            }
            return;
        }

        AppInfo appInfo = (AppInfo) mCommonInfo;
        long originalSize = appInfo.size;
        long actualDownloadSize = -1;

        boolean isUpdate = (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE);
        boolean isDownload = (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_NONE);

        if (isUpdate && appInfo.diffSize > 0) {
            actualDownloadSize = appInfo.diffSize;
        } else if ((isDownload || isUpdate) && appInfo.compSourceSize > 0) {
            actualDownloadSize = appInfo.compSourceSize;
        }

        String baseText = mContext.getResources().getString(
                isVa ? CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus) : mCommonInfo.getStatusNameResID()
        );

        // 情况1：没有省流/差分信息 → 显示原包大小
        if (actualDownloadSize <= 0) {
            String originalStr = FileUtils.getSizeName(originalSize);
            tv_download.setCrossLine(0, 0);
            tv_download.setText(baseText + " (" + originalStr + ")");
            return;
        }

        boolean shouldShowDualSize = CommonUtils.isShowDualSize(originalSize, actualDownloadSize);

        if (shouldShowDualSize) {
            String originalStr = FileUtils.getSizeName(originalSize);
            String actualStr = FileUtils.getSizeName(actualDownloadSize);
            Configuration config = mContext.getResources().getConfiguration();

            if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
                String newStr = " (" + actualStr + " " + originalStr + ")";
                tv_download.setCrossLineText(baseText, newStr);
                tv_download.setCrossLine(3 + actualStr.length(),
                        4 + actualStr.length() + originalStr.length());
                tv_download.setText(baseText + newStr);
            } else {
                String newStr = " (" + originalStr + " " + actualStr + ")";
                tv_download.setCrossLineText(baseText, newStr);
                int start = newStr.indexOf("(") + 1;
                tv_download.setCrossLine(start, start + originalStr.length());
                tv_download.setText(baseText + newStr);
            }
        } else {
            // 不满足条件：只显示原始包大小（隐藏省流效果）
            String originalStr = FileUtils.getSizeName(originalSize);
            tv_download.setCrossLine(0, 0);
            tv_download.setText(baseText + " (" + originalStr + ")");
        }
    }

    @SuppressWarnings("deprecation")
//    public void updateStatusChanged() {
//        // TODO Auto-generated method stub
//        DownloadStatusManager.getInstance().registerInfoInstance(mCommonInfo);
//
//        //详情页下载按钮UX不一样，单独处理
//        if (mDownloadBtn == null) {
//            return;
//        }
//        //更新应用、state是4、并且不在安装失败集合中-拦截state为4的显示
//        if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED) {
//            if (!CommonUtils.isPackageInFailList(mCommonInfo.packageName)) {
//                FileDownloadInfo downloadInfo1 = DownloadManager.getInstance().getDownloadedInfo(mCommonInfo.packageName);
//                if (downloadInfo1 != null && downloadInfo1.extraInfo != null && downloadInfo1.extraInfo.isUpdate.equals("T")) {
//                    return;
//                }
//            }
//        }
//
//        isVa = mCommonInfo.isVa && !DownloadStatusManager.getInstance().isApkVaPackageFlag(mCommonInfo.packageName);
//        mDownloadBtn.setOfferInfo(mOfferInfo);
//
//        LogUtils.d(LogUtils.TAG_TR_D_VA_DOWNLOAD,"详情页isVa:"+isVa +",observerStatus:"+mCommonInfo.observerStatus + ",packageName:"+mCommonInfo.packageName);
//        XModeView tv_download = mDownloadBtn.getDownloadView();
//        ProgressBar progressbar_downloading = mDownloadBtn.getProgressBar();
//        View downloadBtnBg = mDownloadBtn.getLayoutDownloadBackground();
//
//        if (tv_download != null) {
//
//            if (isVa) {
//                mDownloadBtn.onAppDefault();
//                tv_download.setText(R.string.text_play);
//                return;
//            }
//
//
//            if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE && mCommonInfo instanceof AppInfo && ((AppInfo) mCommonInfo).diffSize > 0) {
//                String str = mDownloadBtn.getContext().getResources().getString(isVa?CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus):mCommonInfo.getStatusNameResID());
//
//                Configuration config = mContext.getResources().getConfiguration();
//                if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
//                    String diffStr = " (" + FileUtils.getSizeName(((AppInfo) mCommonInfo).diffSize) + " " +
//                            FileUtils.getSizeName(mCommonInfo.size) + ")";
//                    tv_download.setCrossLineText(str, diffStr);
//                    str = str + diffStr;
//                    tv_download.setCrossLine(3+ FileUtils.getSizeName(((AppInfo) mCommonInfo).diffSize).length(),
//                            4 + FileUtils.getSizeName(((AppInfo) mCommonInfo).diffSize).length() + FileUtils.getSizeName(mCommonInfo.size).length());
//                } else {
//                    String diffStr = " (" + FileUtils.getSizeName(mCommonInfo.size) + " " +
//                            FileUtils.getSizeName(((AppInfo) mCommonInfo).diffSize) + ")";
//                    tv_download.setCrossLineText(str, diffStr);
//                    str = str + diffStr;
//                    tv_download.setCrossLine(diffStr.indexOf("(") + 1, diffStr.indexOf("(") + 1 + FileUtils.getSizeName(mCommonInfo.size).length());
//                }
//                if(isVa){
//                    if(mCommonInfo.observerStatus != FileDownloadInfo.STATUS_DOWNLOADED){
//                        tv_download.setText(str);
//                    }
//                } else {
//                    tv_download.setText(str);
//                }
//            } else {
//                if (mCommonInfo.observerStatus == FileDownloadInfo.STATUS_NONE && mCommonInfo instanceof AppInfo &&
//                        ((AppInfo)mCommonInfo).compSourceSize > 0) {
//
//                    String str = mDownloadBtn.getContext().getResources().getString(isVa?CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus):mCommonInfo.getStatusNameResID());
//                    long compressSize = ((AppInfo)mCommonInfo).compSourceSize;
//                    String compressSizeStr = FileUtils.getSizeName(compressSize);
//                    int compressSizeLength = TextUtils.isEmpty(compressSizeStr) ? 0 : compressSizeStr.length();
//                    String sizeStr = FileUtils.getSizeName(mCommonInfo.size);
//                    int sizeLength = TextUtils.isEmpty(sizeStr) ? 0 : sizeStr.length();
//
//                    Configuration config = mContext.getResources().getConfiguration();
//                    if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
//
//                        String newStr = " (" + compressSizeStr + " " + sizeStr + ")";
//                        tv_download.setCrossLineText(str, newStr);
//                        str = str + newStr;
//                        tv_download.setCrossLine(3 + compressSizeLength,
//                                4 + compressSizeLength + sizeLength);
//                    } else {
//                        String newStr = " (" + sizeStr + " " + compressSizeStr + ")";
//                        tv_download.setCrossLineText(str, newStr);
//                        str = str + newStr;
//                        tv_download.setCrossLine(newStr.indexOf("(") + 1, newStr.indexOf("(") + 1 + sizeLength);
//                    }
//                    if(isVa){
//                        if(mCommonInfo.observerStatus != FileDownloadInfo.STATUS_DOWNLOADED){
//                            tv_download.setText(str);
//                        }
//                    } else {
//                        tv_download.setText(str);
//                    }
//
//                }else {
//                    tv_download.setCrossLine(0, 0);
//                    if(isVa){
//                        if(mCommonInfo.observerStatus != FileDownloadInfo.STATUS_DOWNLOADED){
//                            tv_download.setText(CommonUtils.getVaStatusStringResID(mCommonInfo.observerStatus));
//                        }
//                    } else {
//                        tv_download.setText(mCommonInfo.getStatusNameResID());
//                    }
//                }
//            }
//        }
//
//        if (tv_download == null || progressbar_downloading == null || downloadBtnBg == null) {
//            return;
//        }
//
//        int observerStatus = mCommonInfo.observerStatus;
//        FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadingInfo(mCommonInfo.packageName);
//        OfferInfo offerInfo = mOfferInfo;
//        int defaultColor = ContextCompat.getColor(mContext, R.color.detail_btn_text_color);
//        int normalColor = ContextCompat.getColor(mContext, R.color.detail_btn_normal_text_color);
//        int maskingColor = ContextCompat.getColor(mContext, R.color.detail_offer_masking_color);
//        int mCorners = mContext.getResources().getDimensionPixelSize(R.dimen.detail_btn_corner);
//        int txtBgSpecialDrawableId = mDownloadBtn.getTextSpecialBackgroundId();
//        int textSpecialColorId = mDownloadBtn.getTextSpecialColorId();
//
//        if ("T".equals(mCommonInfo.showPlay)) {
//            if (isOfferStyle()) {
//                progressbar_downloading.setVisibility(View.GONE);
//                CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
//                downloadBtnBg.setVisibility(View.VISIBLE);
//                tv_download.setTextColor(offerInfo.mainColor);
//                tv_download.setProgress(0);
//            } else {
//                progressbar_downloading.setVisibility(View.GONE);
//                tv_download.setProgress(0);
//                downloadBtnBg.setVisibility(View.VISIBLE);
//                tv_download.setTextColor(defaultColor);
//            }
//            return;
//        }
//        LogUtils.d(LogUtils.TAG_TR_D_VA_PARSE, "initParseDetailObserver--------0  downloadInfo" +downloadInfo);
//
//        if (downloadInfo != null) {
//            float progress = 0;
//            if (downloadInfo.sourceSize > 0) {
//                progress = downloadInfo.downloadedSize * 100f / downloadInfo.sourceSize;
//            }
//            if (isVa) {
//                progress = PsVaManager.getInstance().getVaDownloadingProgress(progress);
//            }
//            BigDecimal bd = new BigDecimal(progress);
//            float prg = bd.setScale(1, BigDecimal.ROUND_HALF_UP).floatValue();
//            progressbar_downloading.setProgress((int) prg);
//
//            if (isVa) {
//                if (FileDownloadInfo.isVaDownloading(observerStatus)) {
//                    String textProgress = prg + "%";
//                    tv_download.setText(textProgress);
//                }
//                tv_download.setProgress(prg); //设置反色范围
//
//            } else {
//                if (FileDownloadInfo.isDownloading(observerStatus)) {
//                    String textProgress = prg + "%";
//                    tv_download.setText(textProgress);
//                }
//                tv_download.setProgress(prg); //设置反色范围
//            }
//        } else {
//            if (isVa && observerStatus == FileDownloadInfo.STATUS_DOWNLOADED && PsVaManager.getInstance().isShowParseProgress(mCommonInfo.packageName)) {
//                initParseDetailObserver(mDownloadBtn,mCommonInfo.itemID);
//                PsVaManager.getInstance().setVaParseProgress(mCommonInfo.itemID);
//            }
//        }
//
//        if(isVa){
//            switch (observerStatus) {
//                case FileDownloadInfo.STATUS_DOWNING:
//                //case FileDownloadInfo.STATUS_DOWNLOADED:
//                case FileDownloadInfo.STATUS_APP_UPDATE:
//                    progressbar_downloading.setVisibility(View.VISIBLE);
//                    progressbar_downloading.setSelected(false);
//                    downloadBtnBg.setVisibility(View.GONE);
//                    progressbar_downloading.setProgress(0);
//                    tv_download.setProgress(0);
//                    tv_download.setTextColor(normalColor);
//                    tv_download.setTextBackgroundResource(-1);
//                    break;
//                case FileDownloadInfo.STATUS_DOWNLOADED:
//                    progressbar_downloading.setVisibility(View.GONE);
//                    progressbar_downloading.setSelected(false);
//                    downloadBtnBg.setVisibility(View.VISIBLE);
//                    tv_download.setProgress(0);
//                    tv_download.setTextColor(defaultColor);
//                    tv_download.setTextBackgroundResource(-1);
//                    tv_download.setText(R.string.text_install);
//                    break;
//                case FileDownloadInfo.STATUS_APP_INSTALLED:
//                    progressbar_downloading.setVisibility(View.GONE);
//                    tv_download.setProgress(0);
//                    downloadBtnBg.setVisibility(View.VISIBLE);
//                    tv_download.setTextColor(defaultColor);
//                    tv_download.setTextBackgroundResource(-1);
//                    isVaInstallSuccess = true;
//                    break;
//                case FileDownloadInfo.STATUS_WAIT:
//                case FileDownloadInfo.STATUS_PAUSE:
//                    progressbar_downloading.setVisibility(View.VISIBLE);
//                    progressbar_downloading.setSelected(true);
//                    downloadBtnBg.setVisibility(View.GONE);
//                    tv_download.setTextColor(normalColor);
//                    tv_download.setTextBackgroundResource(-1);
//                break;
//                case FileDownloadInfo.STATUS_NETWORK_ERROR:
//                    progressbar_downloading.setVisibility(View.GONE);
//                    progressbar_downloading.setSelected(true);
//                    downloadBtnBg.setVisibility(View.VISIBLE);
//                    tv_download.setProgress(0);
//                    tv_download.setTextColor(defaultColor);
//                    tv_download.setTextBackgroundResource(-1);
//                    break;
//                case FileDownloadInfo.STATUS_APP_VA_INSTALLED_FAIL:
//                case FileDownloadInfo.STATUS_NONE:
//                default:
//                    progressbar_downloading.setVisibility(View.GONE);
//                    tv_download.setProgress(0);
//                    downloadBtnBg.setVisibility(View.VISIBLE);
//                    tv_download.setTextColor(defaultColor);
//                    tv_download.setTextBackgroundResource(-1);
//                    break;
//            }
//        }else {
//            switch (observerStatus) {
//                case FileDownloadInfo.STATUS_WAIT:
//                case FileDownloadInfo.STATUS_DOWNING:
//                    if (isOfferStyle()) {
//                        progressbar_downloading.setVisibility(View.VISIBLE);
//                        progressbar_downloading.setSelected(false);
//                        CommonUtils.setProgressBarDrawable(progressbar_downloading, offerInfo.pbBgColor, offerInfo.getButtonColor(), mCorners);
//                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), maskingColor, mCorners);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(offerInfo.getButtonColor());
//                    } else {
//
//                        progressbar_downloading.setVisibility(View.VISIBLE);
//                        progressbar_downloading.setSelected(false);
//                        downloadBtnBg.setVisibility(View.GONE);
//                        tv_download.setTextColor(normalColor);
//                        tv_download.setTextBackgroundResource(-1);
//                    }
//                    break;
//
//                case FileDownloadInfo.STATUS_PAUSE:
//                    if (isOfferStyle()) {
//
//                        progressbar_downloading.setVisibility(View.VISIBLE);
//                        progressbar_downloading.setSelected(false);
//                        CommonUtils.setProgressBarDrawable(progressbar_downloading, offerInfo.pbBgColor, offerInfo.getButtonColor(), mCorners);
//                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), maskingColor, mCorners);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(offerInfo.getButtonColor());
//
//                    } else {
//
//                        progressbar_downloading.setVisibility(View.VISIBLE);
//                        progressbar_downloading.setSelected(true);
//                        downloadBtnBg.setVisibility(View.GONE);
//                        tv_download.setTextColor(normalColor);
//                        tv_download.setTextBackgroundResource(-1);
//                    }
//                    break;
//
//                case FileDownloadInfo.STATUS_NETWORK_ERROR:
//                    if (isOfferStyle()) {
//
//                        progressbar_downloading.setVisibility(View.GONE);
//                        progressbar_downloading.setSelected(true);
//                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(offerInfo.mainColor);
//                        tv_download.setProgress(0);
//                    } else {
//
//                        progressbar_downloading.setVisibility(View.GONE);
//                        progressbar_downloading.setSelected(true);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setProgress(0);
//                        tv_download.setTextColor(defaultColor);
//                        tv_download.setTextBackgroundResource(-1);
//                    }
//                    break;
//
//                case FileDownloadInfo.STATUS_DOWNLOADED:
//                        updateUI(tv_download, progressbar_downloading, downloadBtnBg, offerInfo, defaultColor, mCorners);
//                    break;
//                case FileDownloadInfo.STATUS_APP_UPDATE:
//                    if (isOfferStyle()) {
//
//                        progressbar_downloading.setVisibility(View.GONE);
//                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(offerInfo.mainColor);
//                        tv_download.setProgress(0);
//
//                    } else {
//
//                        progressbar_downloading.setVisibility(View.GONE);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setProgress(0);
//                        tv_download.setTextColor(defaultColor);
//                        tv_download.setTextBackgroundResource(-1);
//                    }
//                    break;
//                case FileDownloadInfo.STATUS_APP_INSTALLED:
//                    if (isOfferStyle()) {
//                        progressbar_downloading.setVisibility(View.GONE);
//                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(offerInfo.mainColor);
//                        tv_download.setProgress(0);
//                    } else {
//
//                        progressbar_downloading.setVisibility(View.GONE);
//                        progressbar_downloading.setSelected(false);
//                        progressbar_downloading.setProgress(0);
//                        tv_download.setProgress(0);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColorId(textSpecialColorId);
//                        tv_download.setTextBackgroundResource(txtBgSpecialDrawableId);
//                    }
//                    break;
//
//                case FileDownloadInfo.STATUS_INSTALLING:
//                    if (isOfferStyle()) {
//                        CommonUtils.setProgressBarDrawable(progressbar_downloading, offerInfo.pbBgColor, offerInfo.getButtonColor(), mCorners);
//                        progressbar_downloading.setVisibility(View.VISIBLE);
//                        progressbar_downloading.setSelected(true);
//                        progressbar_downloading.setProgress(100);
//                        tv_download.setTextColor(offerInfo.mainColor, true);
//                        tv_download.setProgress(100);
//                        downloadBtnBg.setVisibility(View.GONE);
//                    } else {
//
//                        progressbar_downloading.setVisibility(View.VISIBLE);
//                        progressbar_downloading.setSelected(true);
//                        progressbar_downloading.setProgress(100);
//                        tv_download.setProgress(100);
//                        downloadBtnBg.setVisibility(View.GONE);
//                        tv_download.setTextColor(normalColor);
//                        tv_download.setTextBackgroundResource(-1);
//                    }
//                    break;
//
//                case FileDownloadInfo.STATUS_NONE:
//                default:
//                    if (isOfferStyle()) {
//
//                        progressbar_downloading.setVisibility(View.GONE);
//                        CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(offerInfo.mainColor);
//                        tv_download.setProgress(0);
//                    } else {
//                        progressbar_downloading.setVisibility(View.GONE);
//                        tv_download.setProgress(0);
//                        downloadBtnBg.setVisibility(View.VISIBLE);
//                        tv_download.setTextColor(defaultColor);
//                        tv_download.setTextBackgroundResource(-1);
//                    }
//                    break;
//            }
//        }
//    }

    private void updateUI(XModeView tv_download, ProgressBar progressbar_downloading, View downloadBtnBg, OfferInfo offerInfo, int defaultColor, int mCorners) {
        if (isOfferStyle()) {
            progressbar_downloading.setVisibility(View.GONE);
            CommonUtils.setViewBackgroundWithCorner(downloadBtnBg, offerInfo.getButtonColor(), mCorners);
            downloadBtnBg.setVisibility(View.VISIBLE);
            tv_download.setTextColor(offerInfo.mainColor);
            tv_download.setProgress(0);

        } else if (mDownloadBtn.isQuickOpenStyle()) {
            mDownloadBtn.onAppDownloaded();
        } else {
            progressbar_downloading.setVisibility(View.GONE);
            progressbar_downloading.setSelected(false);
            downloadBtnBg.setVisibility(View.VISIBLE);
            tv_download.setProgress(0);
            tv_download.setTextColor(defaultColor);
            tv_download.setTextBackgroundResource(-1);
        }
    }

    private void updateProgress(FileDownloadInfo downloadingInfo) {

        CommonUtils.updateViewHolderProgressBar(downloadingInfo, mDownloadBtn, mOfferInfo, null);
    }

    @Override
    public void onDownloadStart(FileDownloadInfo downloadInfo) {
        if (downloadInfo != null && downloadInfo.extraInfo != null && !downloadInfo.extraInfo.isVaGame) {
            if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
                updateStatusChanged();
            }

            if (mIMessenger != null) {
                mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_Download_START, downloadInfo);
            }
        }
    }

    @Override
    public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {
        if (downloadInfo == null || downloadInfo.isVa()) {
            return;
        }
        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateProgress(downloadInfo);
        }

    }

    @Override
    public void onDownloadComplete(FileDownloadInfo downloadInfo) {

        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_Download_Complete, downloadInfo);
        }

        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateStatusChanged();
        }
    }

    @Override
    public void onActivated(FileDownloadInfo downloadInfo) {
        // TODO Auto-generated method stub
        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateStatusChanged();
        }
    }

    @Override
    public void onDownloadError(FileDownloadInfo downloadInfo) {

        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateStatusChanged();
        }

        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_Download_Error, downloadInfo);
        }
    }

    @Override
    public void onDownloadPause(FileDownloadInfo downloadInfo) {

        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateStatusChanged();
        }

        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_Download_Pause, downloadInfo);
        }
    }

    @Override
    public void onDownloadResume(FileDownloadInfo downloadInfo) {

        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateStatusChanged();
        }

        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_Download_Resume, downloadInfo);
        }
    }

    @Override
    public void onDownloadDelete(FileDownloadInfo downloadInfo) {
        if (DownloadStatusManager.checkObserverData(mCommonInfo, downloadInfo, DetailType.isApp(downloadInfo.type))) {
            updateStatusChanged();
        }

        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_Download_Delete, downloadInfo);
        }
    }

    @Override
    public void onAppPackageAdded(String packageName, int versionCode) {
        LogUtils.d(LogUtils.TAG_TR_D_VA_DOWNLOAD,"详情页onAppPackageAdded--------"+packageName  + "，mCommonInfo："+mCommonInfo);

        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_APPPackage_Added, packageName, versionCode);
        }

        if (DownloadStatusManager.checkObserverData(mCommonInfo, packageName, true)) {
            updateStatusChanged();
        }

        if (mCommonInfo != null && mCommonInfo.isVa && TextUtils.equals(packageName, mCommonInfo.packageName)) {
            // 当VA游戏下载成功，且页面是运行状态，执行自动打开
            if (mContext instanceof LifecycleOwner) {
                if (((LifecycleOwner) mContext).getLifecycle().getCurrentState() == Lifecycle.State.RESUMED) {
                    if (BuildConfig.PROXY_VA) {
                        VaStaticProxy.launchVaApp(mContext, mCommonInfo.packageName);
                    } else {
                        PsVaManager.getInstance().openVaLoadingActivity(mCommonInfo, new LaunchInfo(LaunchInfo.LAUNCH_FROM_ICON, "button"));//fixme from信息错误
                    }
                }
            }
        }
    }

    @Override
    public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
        if (mIMessenger != null) {
            mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_AppPackage_Removed, packageName, versionCode);
        }

        if (DownloadStatusManager.checkObserverData(mCommonInfo, packageName, true)) {
            updateStatusChanged();
        }
    }

    private void initParseDetailObserver(XFermodeDownloadView xFermodeDownloadView, String itemId) {
        if(TextUtils.isEmpty(itemId)){
            LogUtils.d(LogUtils.TAG_TR_D_VA_PARSE, "详情页面接收解析进度-----itemId为空---");
            return;
        }
        if (!PsVaManager.getInstance().parseDetailMap.containsKey(itemId)) {
            Observer<VaParseBean> observer = new Observer<VaParseBean>() {
                @Override
                public void onChanged(VaParseBean vaParseBean) {
                    LogUtils.d(LogUtils.TAG_TR_D_VA_PARSE, "详情页面接收解析进度--------" + vaParseBean.progress + PsVaManager.getInstance().isVaInstallFinshOnlyDetail);
                    VaParseData vaDetailParseData = PsVaManager.getInstance().parseDetailMap.get(vaParseBean.itemId);
                    if (vaDetailParseData == null) {
                        return;
                    }
                    if (isVaInstallSuccess) {
                        isVaInstallSuccess = false;
                        if( vaDetailParseData.observer != null){
                            LiveDataBus.get().with(PsVaManager.KEY_PARSE_PROGRES, VaParseBean.class).removeObserver(vaDetailParseData.observer);
                            PsVaManager.getInstance().parseDetailMap.remove(itemId, vaDetailParseData.observer);
                        }
                        return;
                    }
                    if (vaDetailParseData.downloadViewList != null && vaDetailParseData.downloadViewList.size() > 0) {
                        for (XFermodeDownloadView xFermodeDownloadView : vaDetailParseData.downloadViewList) {
                            if(xFermodeDownloadView != null) {
                                String textProgress = vaParseBean.progress + "%";
                                xFermodeDownloadView.setText(textProgress);
                                xFermodeDownloadView.setProgress(vaParseBean.progress);
                            }
                        }
                    }
                }
            };
            List<XFermodeDownloadView> downloadViewList =  new ArrayList<>();
            downloadViewList.add(xFermodeDownloadView);
            PsVaManager.getInstance().parseDetailMap.put(itemId, new VaParseData(observer,downloadViewList));
            LiveDataBus.get().with(PsVaManager.KEY_PARSE_PROGRES, VaParseBean.class).observeForever(observer);
        } else {
            VaParseData vaDetailParseData = PsVaManager.getInstance().parseDetailMap.get(itemId);
            if (vaDetailParseData != null && vaDetailParseData.observer != null && vaDetailParseData.downloadViewList != null) {
                vaDetailParseData.downloadViewList.add(xFermodeDownloadView);
                PsVaManager.getInstance().parseDetailMap.put(itemId, new VaParseData(vaDetailParseData.observer,vaDetailParseData.downloadViewList));
            }
        }

    }
}

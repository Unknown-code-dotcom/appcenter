package com.afmobi.palmplay.configs.v6_3;

/**
 * Created by HJG on 2016/11/12.
 */

public interface RankStyleType {

    // Note: not use  type 0

    String H_TITLE = "H_TITLE";
    int H_TITLE_VALUE = 1;

    String H_NO_TITLE = "H_NO_TITLE";
    int H_NO_TITLE_VALUE = 2;

    String V_TITLE = "V_TITLE";
    int V_TITLE_VALUE = 3;

    String V_NO_TITLE = "V_NO_TITLE";
    int V_NO_TITLE_VALUE = 4;

    String R_TITLE = "R_TITLE";
    int R_TITLE_VALUE = 5;

    String R_NO_TITLE = "R_NO_TITLE";
    int R_NO_TITLE_VALUE = 6;

    String SOFT_NEW_RANK = "SOFT_NEW_RANK";
    int SOFT_NEW_RANK_VALUE = 7;

    String H_RECOMMEND_TITLE = "H_RECOMMEND_TITLE";
    int H_RECOMMEND_TITLE_VALUE = 8;

    String H_ROLL_TITLE = "H_ROLL_TITLE";
    int H_ROLL_TITLE_VALUE = 9;

    String H_ROLL_NO_TITLE = "H_ROLL_NO_TITLE";
    int H_ROLL_NO_TITLE_VALUE = 10;

    String V_ROLL_TITLE = "V_ROLL_TITLE";
    int V_ROLL_TITLE_VALUE = 11;

    String V_ROLL_NO_TITLE = "V_ROLL_NO_TITLE";
    int V_ROLL_NO_TITLE_VALUE = 12;

    String H_CARD_TITLE = "H_ROLL_BACKGROUND";
    int H_CARD_TITLE_VALUE = 13;

    String HOT_WORD = "HOT_WORD";
    int HOT_WORD_VALUE = 14;

    String V_ROLL_RECOMMEND = "SEARCH_RECOMMEND";
    int V_ROLL_RECOMMEND_VALUE = 15;

    String H_ROLL_TITLE_LITE = "H_ROLL_TITLE_LITE";
    int H_ROLL_TITLE_LITE_VALUE = 16;

    String H_ROLL_TITLE_TAG_NEW = "H_ROLL_TITLE_TAG_NEW";
    int H_ROLL_TITLE_TAG_NEW_VALUE = 17;

    String V_ROLL_TITLE_TAG_NEW = "V_ROLL_TITLE_TAG_NEW";
    int V_ROLL_TITLE_TAG_NEW_VALUE = 18;



    String V_SMALL_PKG = "V_SMALL_PKG";
    int V_SMALL_PKG_VALUE = 19;

    String V_SMALL_PKG_DETAIL = "V_SMALL_PKG_DETAIL";
    int V_SMALL_PKG_DETAIL_VALUE = 20;

    String H_ROLL_TITLE_LARGE = "H_ROLL_TITLE_LARGE";
    int H_ROLL_TITLE_LARGE_VALUE = 21;
    /** 9.2.3及以上不下发改样式 */
    String LABEL_NAV_DEFAULT = "LABEL_NAV_DEFAULT";
    int LABEL_NAV_DEFAULT_VALUE = 22;

    String BIG_ICON_NAV_DEFAULT = "BIG_ICON_NAV_DEFAULT";
    int BIG_ICON_NAV_DEFAULT_VALUE = 23;

    String VERTICAL_HORIZONTAL_STROKE_STYLE = "VERTICAL_HORIZONTAL_STROKE_STYLE";
    int VERTICAL_HORIZONTAL_STROKE_STYLE_VALUE = 24;

    String BANNER_DEFAULT = "BANNER_DEFAULT";
    int BANNER_DEFAULT_VALUE = 25;
    /** 9.2.3及以上不下发改样式 */

    String MY_GAME_LIBRARY = "MY_GAME_LIBRARY";
    int MY_GAME_LIBRARY_VALUE = 1001;

    // 931B instant专区新增样式：RANK_H_V_H5，展示h5游戏，CATEGORY_BIGCION_VA，展示va游戏
    String RANK_H_V_H5 = "RANK_H_V_H5";
    int RANK_H_V_H5_VALUE = 50;
    String CATEGORY_BIGICON_VA = "CATEGORY_BIGCION_VA";
    int CATEGORY_BIGICON_VA_VALUE = 51;

    //带预约时间的横向
    String H_NEW_RANK = "H_NEW_RANK";
    int H_NEW_RANK_VALUE = 52;
    //Banner带梯形遮罩的横向
    String H_BANNER_V4 = "H_BANNER_V4";
    int H_BANNER_V4_VALUE = 53;

    //H5双行大卡样式
    String V_BIGICON_H5 = "V_BIGICON_H5";
    int V_BIGICON_H5_VALUE = 54;

    //三行排行榜（带排名数字）样式
    String H_ROLL_RANK_TITLE = "H_ROLL_RANK_TITLE";
    int H_ROLL_RANK_TITLE_VALUE = 55;

    //950A-上新日历
    String CALENDAR_M_D = "CALENDAR_M_D";
    int CALENDAR_M_D_VALUE = 56;

    //H5单行横滑大图标样式
    String H_ROLL_TITLE_LARGE_H5 = "H_ROLL_TITLE_LARGE_H5";
    int H_ROLL_TITLE_LARGE_H5_VALUE = 57;

    //推文横滑大卡样式（横向滚动推文带标题样式）
    String H_ROLL_BANNER_TITLE = "H_ROLL_BANNER_TITLE";
    int H_ROLL_BANNER_TITLE_VALUE = 58;

    //Feed eBook 横滑专题样式
    String H_ROLL_TITLE_EBOOK = "H_ROLL_TITLE_EBOOK";
    int H_ROLL_TITLE_EBOOK_VALUE = 59;

}

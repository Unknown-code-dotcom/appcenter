package com.afmobi.palmplay.clean;

import android.os.CountDownTimer;
import android.text.TextUtils;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkCallBack;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.ResponseBuilder;
import com.afmobi.palmplay.model.v6_3.FeatureResponse;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.util.PackageUtil;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.androidnetworking.error.ANError;
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: zhiqiang.hao
 * @date: 2022/8/3 20:18
 * @Desc: add your description
 */
public class CleanCacheCleaningViewModel extends ViewModel {

    private MutableLiveData<FeaturedModel> mFeaturedLiveData = new MutableLiveData<>();
    private static final int PAGE_SIZE = 4;
    private static final String PAGE_CATEGORY = "CLEAN_RESULT";
    private int pageIndex = 0;

    private TFeedNative mTFeedNative;
    private boolean isFeatureAdFinished = false;
    private CountDownTimer mAdLoadTimer;
    protected static volatile long requestTime;//api接口请求的开始时间
    private MutableLiveData<ResponseBuilder> respBuilderLiveData = new MutableLiveData<>();
    private boolean isAdTimerFinished = false;
    private boolean isFeatureRequestFinished = false;
    public List<TaNativeInfo> recommendAdInfos;  //垃圾清理底部广告

    protected Map<String, Integer> mAlreadyAddList = new HashMap<>();  //记录已经展示过的包名

    private boolean isCacheOnError = false;
    private boolean isCacheLoadAd = false;

    /**
     * 每次刷新后的专题数量
     */
    private int preTotalSize = 0;

    public void loadFeaturedData() {
        isFeatureRequestFinished = false;
        requestTime = System.currentTimeMillis();
        startCountDownTimer();
        String serailNum = CommonUtils.generateSerialNum();
        hisavanaSdkRecommendAdLoad(serailNum, pageIndex, PAGE_SIZE);

        NetworkClient.fetchRecommendListHttpRequest(pageIndex, PAGE_SIZE, PAGE_CATEGORY, null, new AbsRequestListener<FeatureResponse>() {
            @Override
            public void onResponse(FeatureResponse response) {
                super.onResponse(response);
                onRecommendDataPreCallback(response);
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                onRecommendDataPreCallback(null);
            }
        }, null, CommonUtils.generateSerialNum(),SceneCode.JF_MR);
    }

    private void onRecommendDataPreCallback(FeatureResponse response) {
        isFeatureRequestFinished = true;
        long interval = System.currentTimeMillis() - requestTime;

        if(response!=null) {
            TRAnalysticsUtil.trackFeatureApi("" + requestTime, "" + interval, SceneCode.JF_MR,isFeatureAdFinished);
        } else {
            TRAnalysticsUtil.trackFeatureApi("" + requestTime, "" + interval, SceneCode.JF_MR+"_"+TRAnalyticsConstant.ERROR,isFeatureAdFinished);
        }

        if (interval <= HisavanaSdkManager.SDK_LOAD_TIMEOUT) {
            if (isFeatureAdFinished) {
                if (isCacheLoadAd) {
                    if (response != null) {
                        FeaturedModel rspFeatureModel = response.data;
                        if (rspFeatureModel != null && rspFeatureModel.featureList != null && rspFeatureModel.featureList.size() > 0) {
                            stopCountDownTimer();
                            ResponseBuilder builder = new ResponseBuilder()
                                    .setResponse(response)
                                    .setPageIndex(pageIndex);
                            respBuilderLiveData.setValue(builder);
                            hisavanaSdkRecommendAdCacheLoad(rspFeatureModel.featureList);
                            return;
                        }
                    }
                } else {
                    stopCountDownTimer();
                }

            }else {
                ResponseBuilder builder = new ResponseBuilder()
                        .setResponse(response);
                respBuilderLiveData.setValue(builder);
                return;
            }
        }else { //大于300ms
            destroyRecommendAd();
            if (!isFeatureAdFinished) {
                TRAnalysticsUtil.trackEwFilterInfo(SceneCode.JF_MR, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                destorySdkAdInfo();
            }

            if (response != null) {
                if (!isFeatureAdFinished) {
                    FeaturedModel rspFeatureModel = response.data;
                    if (rspFeatureModel != null && rspFeatureModel.featureList != null && rspFeatureModel.featureList.size() > 0) {
                        stopCountDownTimer();
                        ResponseBuilder builder = new ResponseBuilder()
                                .setResponse(response)
                                .setPageIndex(pageIndex);
                        respBuilderLiveData.setValue(builder);
                        hisavanaSdkRecommendAdCacheLoad(rspFeatureModel.featureList);
                        return;
                    }
                } else {
                    if (isCacheLoadAd) {
                        FeaturedModel rspFeatureModel = response.data;
                        if (rspFeatureModel != null && rspFeatureModel.featureList != null && rspFeatureModel.featureList.size() > 0) {
                            stopCountDownTimer();
                            ResponseBuilder builder = new ResponseBuilder()
                                    .setResponse(response)
                                    .setPageIndex(pageIndex);
                            respBuilderLiveData.setValue(builder);
                            hisavanaSdkRecommendAdCacheLoad(rspFeatureModel.featureList);
                            return;
                        }
                    }
                }
            }

        }

        onRecommendDataCallback(response);
    }

    private void onRecommendDataCallback(FeatureResponse response) {
        if (response != null) {
            FeaturedModel rspFeatureModel = (response != null) ? (response.data) : null;
            rspFeatureModel = TRHomeUtil.transformAndSortData(rspFeatureModel);
            rspFeatureModel = TRHomeUtil.addTrackLogicField(rspFeatureModel);
            if (mFeaturedLiveData != null) {
                mFeaturedLiveData.postValue(rspFeatureModel);
            }
        }else {
            if (mFeaturedLiveData != null) {
                mFeaturedLiveData.postValue(null);
            }
        }

        respBuilderLiveData.setValue(null);
        isAdTimerFinished = false;
    }

    private void startCountDownTimer() {
        isAdTimerFinished = false;
        if (mAdLoadTimer == null) {
            mAdLoadTimer = new CountDownTimer(HisavanaSdkManager.SDK_LOAD_TIMEOUT, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    isAdTimerFinished = true;
                    if (isFeatureRequestFinished) {
                        destroyRecommendAd();
                    }

                    if (!isFeatureAdFinished && respBuilderLiveData.getValue() != null) {
                        TRAnalysticsUtil.trackEwFilterInfo(SceneCode.AD_de, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                        ResponseBuilder builder = respBuilderLiveData.getValue();
                        FeatureResponse response = builder.response;
                        if (response != null) {
                            FeaturedModel rspFeatureModel = response.data;
                            if (rspFeatureModel != null && rspFeatureModel.featureList != null && rspFeatureModel.featureList.size() > 0) {
                                hisavanaSdkRecommendAdCacheLoad(rspFeatureModel.featureList);
                                return;
                            }
                        }

                        onRecommendDataCallback(builder.response);
                    }
                }
            };
        }else {
            mAdLoadTimer.cancel();
        }

        mAdLoadTimer.start();
    }

    /**
     * 请求垃圾清理页面底部广告数据
     */
    public void hisavanaSdkRecommendAdLoad(String serialNum, int pageIndex, int pageMax) {
        isFeatureAdFinished = false;
        isCacheOnError = false;
        isCacheLoadAd = false;
        mTFeedNative = HisavanaSdkManager.getInstance().sdkLoad(SceneCode.JF_MR, "", serialNum, pageIndex, pageMax, featureCallBack);
    }

    /**
     * 请求垃圾清理页面底部缓存广告数据
     */
    public void hisavanaSdkRecommendAdCacheLoad(List<FeatureBean> featureList) {
        LogUtils.d("load cache ad..");
        isCacheOnError = true;
        String serailNum = CommonUtils.generateSerialNum();
        mTFeedNative = HisavanaSdkManager.getInstance().sdkLoad(SceneCode.JF_MR, "", serailNum, pageIndex, PAGE_SIZE, true, false, featureList, null, null, featureCallBack);
    }

    private HisavanaSdkCallBack featureCallBack = new HisavanaSdkCallBack() {
        @Override
        public void onError(TaErrorCode adError) {
            //获取实时广告失败，请求缓存广告
            if (!isCacheOnError) {
                onLoadAdCache();
            } else {
                if (respBuilderLiveData.getValue() != null) {
                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    onRecommendDataCallback(builder.response);
                }
            }
        }

        @Override
        public void onAdLoaded(List<TaNativeInfo> adInfo) {
            onRecommendAdCallback(adInfo, false);
        }

        @Override
        public void onAdClicked() {

        }

        @Override
        public void onTimeOut() {
            //获取实时广告失败，请求缓存广告
            if (!isCacheOnError) {
                onLoadAdCache();
            } else {
                if (respBuilderLiveData.getValue() != null) {
                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    onRecommendDataCallback(builder.response);
                }
            }

        }

        @Override
        public void onAdCache(List<TaNativeInfo> adInfos) {
            onRecommendAdCallback(adInfos, true);
        }

        private void onLoadAdCache() {
            stopCountDownTimer();
            isFeatureAdFinished = true;

            //每次获取到新广告先判断上一次广告是否destory
            destorySdkAdInfo();

            if (isFeatureRequestFinished) {
                if (respBuilderLiveData.getValue() != null) {
                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    FeatureResponse response = builder.response;
                    if (response != null) {
                        FeaturedModel rspFeatureModel = response.data;
                        if (rspFeatureModel != null && rspFeatureModel.featureList != null && rspFeatureModel.featureList.size() > 0) {
                            hisavanaSdkRecommendAdCacheLoad(rspFeatureModel.featureList);
                        }
                    }
                }
            } else {
                isCacheLoadAd = true;
            }
        }

        private void onRecommendAdCallback(List<TaNativeInfo> adInfo, Boolean isCache) {
            stopCountDownTimer();
            isFeatureAdFinished = true;
            isCacheLoadAd = false;

            //每次获取到新广告先判断上一次广告是否destory
            destorySdkAdInfo();

            if (isFeatureRequestFinished) {
                if (!isAdTimerFinished || isCache) {
                    recommendAdInfos = adInfo;
                } else  {
                    TRAnalysticsUtil.trackEwFilterInfo(SceneCode.JF_MR, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                    if (respBuilderLiveData.getValue() != null) {
                        ResponseBuilder builder = respBuilderLiveData.getValue();
                        FeatureResponse response = builder.response;
                        if (response != null) {
                            FeaturedModel rspFeatureModel = response.data;
                            if (rspFeatureModel != null && rspFeatureModel.featureList != null && rspFeatureModel.featureList.size() > 0) {
                                hisavanaSdkRecommendAdCacheLoad(rspFeatureModel.featureList);
                                return;
                            }
                        }
                    }
                }
            }else {
                recommendAdInfos = adInfo;
            }
            if (respBuilderLiveData.getValue() != null) {

                ResponseBuilder builder = respBuilderLiveData.getValue();
                onRecommendDataCallback(builder.response);
            }
        }
    };

    public void destoryHisavanaSdk() {
        destorySdkAdInfo();

        destroyRecommendAd();
        stopCountDownTimer();
    }

    public void destorySdkAdInfo() {
        if (recommendAdInfos != null && !recommendAdInfos.isEmpty()) {
            for (TaNativeInfo nativeInfo : recommendAdInfos) {
                if (nativeInfo != null) {
                    nativeInfo.destroy();
                }
            }
            recommendAdInfos.clear();
        }
    }

    private void stopCountDownTimer() {
        if (mAdLoadTimer != null) {
            mAdLoadTimer.cancel();
        }
    }

    private void destroyRecommendAd() {
        if (mTFeedNative != null) {
            mTFeedNative.destroy();
        }
    }

    /**
     * ew数据和返回列表数据比较， 如果包名一致，去除本地列表返回项
     * @param featuredModel
     * @param data
     * @param row
     * @param col
     */
    public void filterEWData(FeaturedModel featuredModel, FeatureItemData data, int row, int col) {
        if (featuredModel == null) {
            return;
        }
        List<FeatureBean> featureList = featuredModel.featureList;
        if(featureList == null || featureList.isEmpty()) {
            return;
        }

        if (data == null || TextUtils.isEmpty(data.packageName)) {
            return;
        }

        if (row < 0 || col < 0) {
            return;
        }

        if (PackageUtil.isInstalled(data.isVa, data.packageName)) {
            return;
        }

        if (row >= featureList.size()) {
            return;
        }

        FeatureBean featureBean = featureList.get(row);
        if (featureBean == null || TextUtils.isEmpty(featureBean.style)) {
            return;
        }
        if(featuredModel.pageIndex == 0) {
            preTotalSize = 0;
        }
        int listSize = featureList.size();
        try {
            List<FeatureBean> newFeatureList = featureList.subList(preTotalSize, listSize);
            LogUtils.d("SspSdkManager", "packageName: " + data.packageName  + "  size:" + newFeatureList.size());
            HisavanaSdkManager.getInstance().filterValidateAd(newFeatureList, data);
        }catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    /**
     * 过滤重复数据
     * @param featuredModel
     */
    public void filterDuplicateData(FeaturedModel featuredModel) {

        if(featuredModel.featureList == null) {
            return;
        }
        List<FeatureBean> featureList = featuredModel.featureList;
        int listSize = featureList.size();
        if (featuredModel.pageIndex == 0) {
            mAlreadyAddList.clear();
        }
        if(featuredModel.pageIndex > 0) {
            try {
                List<FeatureBean> preFeatureList = featureList.subList(0, preTotalSize);
                List<FeatureBean> newFeatureList = featureList.subList(preTotalSize, listSize);
                LogUtils.d("SspSdkManager", "onDataReceived2: " + preFeatureList.size() + "    newSize:" + newFeatureList.size());

                HisavanaSdkManager.getInstance().removeDuplicateData(preFeatureList, newFeatureList, mAlreadyAddList, SceneCode.JF_MR);
            }catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        preTotalSize = listSize;

    }

    public MutableLiveData<FeaturedModel> getFeaturedLiveData() {
        return mFeaturedLiveData;
    }

}

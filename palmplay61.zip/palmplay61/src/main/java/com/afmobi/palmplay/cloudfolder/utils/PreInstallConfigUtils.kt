package com.afmobi.palmplay.cloudfolder.utils

import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Resources
import com.transsion.palmstorecore.log.LogUtils

object PreInstallConfigUtils {

    private const val preConfigPkg = "com.tranlauncher.res"

    /**
     * 从指定包名的已安装应用中读取 cloud_folder_apps 数组的所有 item
     *
     * @param context Android Context 对象
     * @param packageName 目标应用的包名，默认为 "com.tranlauncher.res"
     * @param arrayName 要读取的数组名称，默认为 "cloud_folder_apps"
     * @return 包含所有 item 的 List<String>
     */
    fun readArrayFromPackage(
        context: Context,
        arrayName: String
    ): List<String> {
        val result = mutableListOf<String>()

        try {
            // 获取目标应用的 Resources
            val resources = getResourcesForPackage(context, preConfigPkg)

            // 获取数组资源的 ID
            val arrayId = resources.getIdentifier(
                arrayName,
                "array",
                preConfigPkg
            )

            if (arrayId == 0) {
                throw IllegalStateException("未找到数组资源: $arrayName")
            }

            // 读取数组资源
            val array = resources.obtainTypedArray(arrayId)
            val length = array.length()

            for (i in 0 until length) {
                val item = array.getString(i)
                if (!item.isNullOrEmpty()) {
                    result.add(item)
                }
            }

            array.recycle()

        } catch (e: PackageManager.NameNotFoundException) {
            LogUtils.e("应用未安装或包名错误: $preConfigPkg", e)
        } catch (e: Exception) {
            LogUtils.e("读取数组资源失败: ${e.message}", e)
        }

        return result
    }

    /**
     * 获取指定包名的应用的 Resources 对象
     *
     * @param context Android Context 对象
     * @param packageName 目标应用的包名
     * @return Resources 对象
     */
    private fun getResourcesForPackage(
        context: Context,
        packageName: String
    ): Resources {
        return try {
            // 方法1: 使用 PackageManager 获取 Resources
            context.packageManager.getResourcesForApplication(packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            // 方法2: 如果方法1失败，尝试创建 PackageContext
            try {
                val packageContext = context.createPackageContext(
                    packageName,
                    Context.CONTEXT_IGNORE_SECURITY or Context.CONTEXT_INCLUDE_CODE
                )
                packageContext.resources
            } catch (e2: PackageManager.NameNotFoundException) {
                throw PackageManager.NameNotFoundException("无法获取应用资源: $packageName")
            }
        }
    }
}
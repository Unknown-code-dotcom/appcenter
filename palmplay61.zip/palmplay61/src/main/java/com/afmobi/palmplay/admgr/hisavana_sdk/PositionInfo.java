package com.afmobi.palmplay.admgr.hisavana_sdk;



/**
 * Created by hexiuhui on 2022/12/12.
 */
public class PositionInfo {

    int row;
    int col;

    public PositionInfo(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    @Override
    public String toString() {
        return "PositionInfo{" +
                "row=" + row +
                ", col=" + col +
                '}';
    }
}

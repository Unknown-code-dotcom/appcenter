package com.afmobi.palmplay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.afmobi.util.DisplayUtil;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.DeviceTypeExKt;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 详情页折叠预览区截图轻量 Adapter。
 * 仅负责展示截图顶部 48dp 区域，所有点击均回调外层 View All 逻辑，
 * 不打开 DetailScreenShotActivity。
 *
 * 图片宽度、间距、圆角与 TRAppDetailShotAdapter / DetailVShotViewHolder /
 * DetailHShotViewHolder 保持一致：
 *   - 竖屏宽 = screenWidth / (360/90)，高 = 宽 × (160/90)，圆角 ps_card_radius_s (12dp)
 *   - 横屏宽 = screenWidth / (360/277)，高 = 宽 × (160/277)，圆角 8dp
 *   - 首尾 item marginStart/End = 16dp，相邻 item 间距 = 5dp
 *   - 视频封面视为横屏 item，显示在 position 0（由调用方通过 setVideoCover 注入）
 */
public class TRDetailPreviewShotAdapter extends RecyclerView.Adapter<TRDetailPreviewShotAdapter.PreviewViewHolder> {

    private static final int VIEW_TYPE_PORTRAIT = 0;
    private static final int VIEW_TYPE_LANDSCAPE = 1;
    private static final int VIEW_TYPE_VIDEO = 2;

    /** 视频封面 URL，非空时插入到 position 0 */
    private String mVideoCoverUrl = null;

    private List<String> mUrls = new ArrayList<>();
    private List<Integer> mModes = new ArrayList<>();

    private final int mPortraitWidth;
    private final int mPortraitHeight;
    private final int mLandscapeWidth;
    private final int mLandscapeHeight;
    // 视频封面宽高：与 DetailVideoItemViewHolder.initViews() 完全一致
    private final int mVideoWidth;
    private final int mVideoHeight;

    // 与 DetailVShotViewHolder / DetailHShotViewHolder / DetailVideoItemViewHolder 保持一致
    private final int mMargin;      // 相邻 item 间距 = 5dp
    private final int mMarginEdge;  // 首尾 item 外边距 = 16dp

    private final int mDefaultIcon = R.drawable.layer_list_screenshot_default_01_bg;

    public TRDetailPreviewShotAdapter(Context context) {
        int screenWidth = Math.min(
                DisplayUtil.getScreenWidthPx(context),
                DisplayUtil.getScreenHeightPx(context)
        ) + DisplayUtil.getInsetsMargin(context);

        // 与 DetailVShotViewHolder 保持一致
        mPortraitWidth = (int) (screenWidth / (360f / 90));
        mPortraitHeight = (int) (mPortraitWidth * (160f / 90));

        // 与 DetailHShotViewHolder 保持一致
        mLandscapeWidth = (int) (screenWidth / (360f / 277));
        mLandscapeHeight = (int) (mLandscapeWidth * (160f / 277));

        // 与 DetailVideoItemViewHolder.initViews() 保持一致：
        //   先按横屏截图比例算出 height，再用 16:9 反推 width
        float videoHeight = mLandscapeHeight;            // = screenWidth * 160/360
        mVideoWidth = (int) (videoHeight / (9f / 16));   // = videoHeight * 16/9
        mVideoHeight = (int) videoHeight;

        mMargin = context.getResources().getDimensionPixelSize(R.dimen.dp_05);
        mMarginEdge = context.getResources().getDimensionPixelSize(R.dimen.dp_16);

    }

    /**
     * 设置视频封面 URL。非空时在 position 0 显示横屏封面图。
     * 需在 setScreenshots 之前或之后调用，并自行调用 notifyDataSetChanged。
     */
    public void setVideoCover(@Nullable String coverUrl) {
        mVideoCoverUrl = coverUrl;
    }

    public void setScreenshots(List<String> urls, List<Integer> modes) {
        mUrls = urls != null ? urls : new ArrayList<>();
        mModes = modes != null ? modes : new ArrayList<>();
        notifyDataSetChanged();
    }

    private boolean hasVideoCover() {
        return mVideoCoverUrl != null && !mVideoCoverUrl.isEmpty();
    }

    /** position 0 为视频封面（若有），其余为截图 */
    @Override
    public int getItemViewType(int position) {
        if (hasVideoCover() && position == 0) {
            return VIEW_TYPE_VIDEO;
        }
        int shotPos = hasVideoCover() ? position - 1 : position;
        if (mModes != null && !mModes.isEmpty() && shotPos >= 0) {
            int mode = mModes.get(shotPos % mModes.size());
            return mode == 1 ? VIEW_TYPE_LANDSCAPE : VIEW_TYPE_PORTRAIT;
        }
        return VIEW_TYPE_PORTRAIT;
    }

    @Override
    public int getItemCount() {
        return mUrls.size() + (hasVideoCover() ? 1 : 0);
    }

    @NonNull
    @Override
    public PreviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = null;
        int w, h;
        if (viewType == VIEW_TYPE_VIDEO) {
            w = mVideoWidth;
            h = mVideoHeight;
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.z_layout_detail_preview_video_item, parent, false);
        } else if (viewType == VIEW_TYPE_LANDSCAPE) {
            w = mLandscapeWidth;
            h = mLandscapeHeight;
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.z_layout_detail_preview_land_item, parent, false);
        } else {
            w = mPortraitWidth;
            h = mPortraitHeight;
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.z_layout_detail_preview_shot_item, parent, false);
        }
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        lp.width = w;
        lp.height = h;
        view.setLayoutParams(lp);
        return new PreviewViewHolder(view, w, h);
    }

    @Override
    public void onBindViewHolder(@NonNull PreviewViewHolder holder, int position) {
        int total = getItemCount();
        int viewType = getItemViewType(position);

        // 间距：首个 item 左边距 16dp，末尾 item 右边距 16dp，其余 item 左边距 5dp
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        int leftMargin = (position == 0) ? mMarginEdge : mMargin;
        int rightMargin = (position == total - 1) ? mMarginEdge : 0;
        lp.leftMargin = leftMargin;
        lp.setMarginStart(leftMargin);
        lp.rightMargin = rightMargin;
        lp.setMarginEnd(rightMargin);
        holder.itemView.setLayoutParams(lp);

        // 确定要加载的 URL
        String url;
        if (hasVideoCover() && position == 0) {
            url = mVideoCoverUrl;
        } else {
            int shotPos = hasVideoCover() ? position - 1 : position;
            url = shotPos < mUrls.size() ? mUrls.get(shotPos) : "";
        }

        GlideUtils.setCornersWithBorderImageUrl(holder.ivPreview, url, mDefaultIcon, mDefaultIcon);

        // 竖图：仅顶部两角圆角（底部超出 48dp clip 区，不画底角）
        // 横图/视频封面：四角均圆角（完整可见）
//        int corner;
//        boolean topCornersOnly;
//        if (viewType == VIEW_TYPE_VIDEO) {
//            corner = mCornerVideo;
//            topCornersOnly = false;
//        } else if (viewType == VIEW_TYPE_LANDSCAPE) {
//            corner = mCornerLandscape;
//            topCornersOnly = false;
//        } else {
//            corner = mCornerPortrait;
//            topCornersOnly = true;
//        }
//
//        GlideUtils.setImageUrlByOption(holder.ivPreview, url, corner,
//                new RequestOptions()
//                        .diskCacheStrategy(DiskCacheStrategy.ALL)
//                        .transform(new TopCropRoundedTransformation(
//                                holder.mItemWidth, holder.mItemHeight, corner, topCornersOnly)),
//                null,
//                mDefaultIcon,
//                mDefaultIcon);
    }

    class PreviewViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivPreview;
        final int mItemWidth;
        final int mItemHeight;

        PreviewViewHolder(@NonNull View v, int width, int height) {
            super(v);
            ivPreview = v.findViewById(R.id.iv_preview);

            if (DeviceTypeExKt.isPadDisplay(v.getContext(), v.getContext().getResources().getConfiguration(), DeviceTypeExKt.getContextDisplayId(v.getContext()))) {
                ViewGroup.LayoutParams lp = ivPreview.getLayoutParams();
                lp.width = width;
                lp.height = height;
                ivPreview.setLayoutParams(lp);
            }

            mItemWidth = width;
            mItemHeight = height;
        }
    }
}

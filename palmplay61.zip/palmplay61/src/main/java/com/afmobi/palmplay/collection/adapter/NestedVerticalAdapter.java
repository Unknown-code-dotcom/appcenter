package com.afmobi.palmplay.collection.adapter;

import static com.afmobi.util.CommonUtils.NULL_STRING;

import android.content.Context;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.customview.OnFeatureItemClickListener;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter;
import com.afmobi.palmplay.home.instant.IVaPlayDownloadCallback;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.afmobi.palmplay.main.adapter.ItemViewStateListener;
import com.afmobi.palmplay.main.adapter.viewholder.BaseRecyclerViewAdapter;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.StyleRoleType;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.social.whatsapp.utils.ListUtils;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.animations.AnimationFactory;
import com.afmobi.util.animations.AnimationFactoryParams;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutCollectionVerticalItemBindingImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * 纵向滑动的单行的样式的adapter
 */
public class NestedVerticalAdapter extends BaseRecyclerViewAdapter {

    private FeatureBean mFeatureBean;
    private String mFromPage;
    private PageParamInfo mPageParamInfo;
    private ItemViewStateListener mItemViewStateListener;
    private OnViewLocationInScreen mOnViewLocationInScreen;
    private int paddingValue8, paddingValue6, paddingValue4, tvNameWidth, iconWidth;
    private LayoutInflater mInflate;
    private OfferInfo mOfferInfo;
    private TrHomeRecyclerViewAdapter<RecyclerView, RecyclerView.LayoutManager> parentAdapter;
    private int mClickPosition;
    private Context mContext;
    private List<FeatureItemData> mItemDataList = new ArrayList<>();

    public int mSourceType;


    private OnFeatureItemClickListener mOnFeatureClickListener;

    public NestedVerticalAdapter setOnFeatureItemClickListener(OnFeatureItemClickListener l) {
        this.mOnFeatureClickListener = l;
        return this;
    }

    public NestedVerticalAdapter setFromPage(String mFromPage) {
        this.mFromPage = mFromPage;
        return this;
    }

    public NestedVerticalAdapter setPageParamInfo(PageParamInfo PageParamInfo) {
        this.mPageParamInfo = PageParamInfo;
        return this;
    }

    public NestedVerticalAdapter setItemViewStateListener(ItemViewStateListener l) {
        this.mItemViewStateListener = l;
        return this;
    }

    public NestedVerticalAdapter setOnViewLocationInScreen(OnViewLocationInScreen l) {
        mOnViewLocationInScreen = l;
        return this;
    }

    public NestedVerticalAdapter setOfferInfo(OfferInfo offerInfo) {
        mOfferInfo = offerInfo;
        return this;
    }

    public NestedVerticalAdapter setData(FeatureBean featureBean) {
        this.mFeatureBean = featureBean;
        return this;
    }

    public void setParentAdapter(TrHomeRecyclerViewAdapter<RecyclerView, RecyclerView.LayoutManager> adapter) {
        this.parentAdapter = adapter;
    }

    public void smallPkgSortList() {
        mItemDataList.clear();
        if (null == mFeatureBean || ListUtils.isEmpty(mFeatureBean.dataList)) {
            return;
        }
        for (int i=0; i< mFeatureBean.dataList.size(); i++) {
            FeatureItemData itemData = getItem(i);
            DownloadStatusManager.getInstance().registerFeatureItemInstance(itemData);
            mItemDataList.add(itemData);
        }
        Collections.sort(mItemDataList, new Comparator<FeatureItemData>() {
            @Override
            public int compare(FeatureItemData o1, FeatureItemData o2) {
                int o1Status = setCurStatus(o1.observerStatus);
                int o2Status = setCurStatus(o2.observerStatus);
                return Integer.compare(o1Status, o2Status);
            }

            private int setCurStatus(int observerStatus) {
                if (observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
                    return FileDownloadInfo.STATUS_APP_UPDATE;
                } else if (observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED) {
                    return FileDownloadInfo.STATUS_APP_INSTALLED;
                } else {
                    return FileDownloadInfo.STATUS_NONE;
                }
            }
        });
    }

    public NestedVerticalAdapter(Context context) {
        mContext = context;
        mInflate = LayoutInflater.from(context);
        paddingValue8 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 8);
        paddingValue6 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 6);
        paddingValue4 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 4);
        int itemWidth = (DisplayUtil.getScreenWidthPx(PalmplayApplication.getAppInstance()) - DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 21)) / 4;
        tvNameWidth = itemWidth - paddingValue4 - paddingValue4;
        iconWidth = tvNameWidth - paddingValue8 - paddingValue4;
        int defaultIconWidth = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 60);
        if (iconWidth > defaultIconWidth) {
            iconWidth = defaultIconWidth;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        ViewDataBinding viewDataBinding = DataBindingUtil.inflate(LayoutInflater.from(PalmplayApplication.getAppInstance()), R.layout.layout_collection_vertical_item, parent, false);
        return new VerticalScrollSingleLineRecyclerViewHolder(viewDataBinding);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder hld, int position) {
        bind(hld, position);
    }

    @Override
    public int getItemCount() {
        if (mFeatureBean == null || mFeatureBean.dataList == null) {
            return 0;
        }
        int size = mFeatureBean.dataList.size();
        return size;
    }

    private FeatureItemData getItem(int position) {
        if (mFeatureBean.dataList == null) {
            return null;
        }
        int size = mFeatureBean.dataList.size();
        if (size > 0 && position >= 0 && position < size) {
            return (FeatureItemData) mFeatureBean.dataList.get(position);
        } else {
            return null;
        }
    }

    //设置标签
    private void setPositionLable(int label, TextView tvLable, String content) {
        if (label == StyleRoleType.ITEM_LABLE_POSITION_1) {
            tvLable.setTextColor(mContext.getColor(R.color.lable_ec_txt_color));
            tvLable.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
            tvLable.setText(mContext.getText(R.string.lable_ec_text));
            tvLable.setBackgroundResource(R.drawable.lable_ec);
        } else if (label == StyleRoleType.ITEM_LABLE_POSITION_2) {
            tvLable.setTextColor(mContext.getColor(R.color.lable_hot_txt_color));
            tvLable.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
            tvLable.setText(mContext.getText(R.string.lable_hot_text));
            tvLable.setBackgroundResource(R.drawable.lable_hot);
        } else if (label == StyleRoleType.ITEM_LABLE_POSITION_3) {
            tvLable.setTextColor(mContext.getColor(R.color.lable_new_txt_color));
            tvLable.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
            tvLable.setText(mContext.getText(R.string.lable_new_text));
            tvLable.setBackgroundResource(R.drawable.lable_new);
        } else if (label == StyleRoleType.ITEM_LABLE_POSITION_4) {
            tvLable.setTextColor(mContext.getColor(R.color.lable_trending_txt_color));
            tvLable.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 8);
            tvLable.setText(mContext.getText(R.string.lable_trending_text));
            tvLable.setBackgroundResource(R.drawable.lable_trending);
        } else {
            if (mOfferInfo != null && mOfferInfo.isOfferStyle()) {
                tvLable.setTextColor(mOfferInfo.subColor);
            } else {
                tvLable.setTextColor(mContext.getColor(R.color.sub_main_txt_color));
            }
            tvLable.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
            tvLable.setText(content);
            tvLable.setBackgroundResource(0);
        }

    }

    private void bind(RecyclerView.ViewHolder viewHolder, int position) {

        VerticalScrollSingleLineRecyclerViewHolder holder = (VerticalScrollSingleLineRecyclerViewHolder) viewHolder;
        holder.setFeatureName(mFeaturedName);
        holder.setScreenPageName(mScreenPageName);
        holder.setStyleName(mFeatureBean.style);
        FeatureItemData item;
//        if (mScreenPageName.equals(TRAnalyticsConstant.SMALLPKG_PAGE)) {
//            item = mItemDataList.get(position);
//        } else {
            item = getItem(position);
            if (item == null) {
                return;
            }
//        }
        if(item.tNativeInfo!=null) {
            item.tNativeInfo.registerViewForInteraction(holder.itemView,null);
        }

        holder.binding.getRoot().setTag(item);
        DownloadStatusManager.getInstance().registerFeatureItemInstance(item);
        CommonUtils.checkStatusItemDisplay(item, holder.binding.layoutItem.downloadView, mOfferInfo, null);
        holder.binding.layoutItem.vaFlag.setVisibility(item.isVa ? View.VISIBLE : View.GONE);//跟Play按钮成对出现
//        holder.binding.layoutItem.vitemLayout.setOnClickListener(new NoDoubleClickListener(item));
        holder.binding.layoutItem.downloadView.setOnClickListener(new DownloadBtnOnClickListener(holder,item,holder.binding.layoutItem.downloadView, position));
        int defaultIcon = R.drawable.layer_list_app_default_01_bg;
        int radius = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 12f);
        int borderColor = ContextCompat.getColor(PalmplayApplication.getAppInstance(), R.color.img_border_color);

        if (mOfferInfo != null && mOfferInfo.isOfferStyle()) {//for offer
            holder.binding.layoutItem.tvName.setTextColor(mOfferInfo.mainColor);
            borderColor = mOfferInfo.borderColor;
            holder.binding.layoutItem.tvScore.setTextColor(mOfferInfo.subColor);
            holder.binding.layoutItem.tvSourceSize.setTextColor(mOfferInfo.subColor);
            holder.binding.layoutItem.tvDownloadCount.setTextColor(mOfferInfo.subColor);
            holder.binding.layoutItem.tvDescription.setTextColor(mOfferInfo.subColor);
        }
        holder.binding.layoutItem.ivIcon.setStrokeColor(CommonUtils.createColorStateList(borderColor));
        holder.binding.layoutItem.ivIcon.setStrokeWidth(DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 0.3f));
        int padding = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 0.15f);
        holder.binding.layoutItem.ivIcon.setPadding(padding, padding, padding, padding);
        GlideUtils.setImageUrl(holder.binding.layoutItem.ivIcon, item.iconUrl, GlideUtils.newCommonRequestOptions(), defaultIcon, defaultIcon);

        holder.binding.layoutItem.tvName.setText(item.name);

        updateTextDownloadCountAndSize(item,holder.binding.layoutItem.tvSourceSize);
        boolean show = CommonUtils.shouldShowScore(item.score);
        holder.binding.layoutItem.llStarContainer.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            holder.binding.layoutItem.tvScore.setText(String.valueOf(item.score));
        }

        if (item.downloadCount > 0) {
            holder.binding.layoutItem.tvDownloadCount.setVisibility(View.VISIBLE);
            holder.binding.layoutItem.ivDownloadCount.setVisibility(View.VISIBLE);
            holder.binding.layoutItem.tvDownloadCount.setText(CommonUtils.getDownloadCountStr(item.downloadCount));
        } else {
            holder.binding.layoutItem.tvDownloadCount.setVisibility(View.GONE);
            holder.binding.layoutItem.ivDownloadCount.setVisibility(View.GONE);
        }

        String categoryName = CommonUtils.getCategoryName(item);
        if (RankStyleType.V_ROLL_TITLE_TAG_NEW.equals(mFeatureBean.style)) {
            holder.binding.layoutItem.ivGift.setVisibility(TextUtils.isEmpty(item.lableUrl) || !CommonUtils.isGiftFlagNeedShow() ? View.GONE : View.VISIBLE);
            GlideUtils.setImageUrlWithNoBorder(holder.binding.layoutItem.ivGift, item.lableUrl);

            if (item.lablePositonMap.get("2") != null) {
                int label = item.lablePositonMap.get("2");
                setPositionLable(label, holder.binding.layoutItem.tvDescription, "");
            } else {
                setPositionLable(5, holder.binding.layoutItem.tvDescription, categoryName);
            }
        } else {
            holder.binding.layoutItem.ivGift.setVisibility(TextUtils.isEmpty(item.lableUrl) || !CommonUtils.isGiftFlagNeedShow() ? View.GONE : View.VISIBLE);
            GlideUtils.setImageUrlWithNoBorder(holder.binding.layoutItem.ivGift, item.lableUrl);
            setPositionLable(5, holder.binding.layoutItem.tvDescription, categoryName);

            if (mFeatureBean.isShowElement(FeatureBean.SHOW_UP_CONFIG_CATEGORY)) {
                if (TextUtils.isEmpty(item.categoryName) || NULL_STRING.equalsIgnoreCase(item.categoryName)) {
                    holder.binding.layoutItem.tvDescription.setVisibility(View.GONE);
                } else {
                    holder.binding.layoutItem.tvDescription.setVisibility(View.VISIBLE);
                }
            } else {
                holder.binding.layoutItem.tvDescription.setVisibility(View.GONE);
            }

            if (mFeatureBean.isShowElement(FeatureBean.SHOW_UP_CONFIG_RATE)) {
                holder.binding.layoutItem.ivScore.setVisibility(View.VISIBLE);
                holder.binding.layoutItem.tvScore.setVisibility(View.VISIBLE);
            } else {
                holder.binding.layoutItem.ivScore.setVisibility(View.GONE);
                holder.binding.layoutItem.tvScore.setVisibility(View.GONE);
            }
            if (mFeatureBean.isShowElement(FeatureBean.SHOW_UP_CONFIG_SIZE)) {
                holder.binding.layoutItem.tvSourceSize.setVisibility(View.VISIBLE);
            } else {
                holder.binding.layoutItem.tvSourceSize.setVisibility(View.GONE);
            }

            if (mFeatureBean.isShowElement(FeatureBean.SHOW_UP_CONFIG_DOWNLOAD_COUNT)) {
                holder.binding.layoutItem.ivDownloadCount.setVisibility(View.VISIBLE);
                holder.binding.layoutItem.tvDownloadCount.setVisibility(View.VISIBLE);
            } else {
                holder.binding.layoutItem.ivDownloadCount.setVisibility(View.GONE);
                holder.binding.layoutItem.tvDownloadCount.setVisibility(View.GONE);
            }
        }

        if (item.hitActivity > 0 && !item.isVa) {
            holder.binding.layoutItem.ivGift.setVisibility(View.GONE);
        }

        int pos = -1;
        if (!TextUtils.isEmpty(item.topicPlace)) {
            try {
                pos = Integer.parseInt(item.topicPlace);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
        item.placementId = String.valueOf(position);

        FeatureItemData featureItemData = item;
        if (!featureItemData.hasTrack) {
            featureItemData.hasTrack = true;
            String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);
            ComponentExposureBuilder builder = new ComponentExposureBuilder<>();
            String adPosId = featureItemData.tNativeInfo != null ? featureItemData.tNativeInfo.getPlacementId() : null;
            String builderVarId = "";
            if (TextUtils.isEmpty(mVarId)) {
                builderVarId = featureItemData.getVarId();
            } else {
                if (featureItemData.getVarId() == null || featureItemData.getVarId().isEmpty()) {
                    builderVarId = mVarId;
                } else {
                    builderVarId = featureItemData.getVarId() + "," + mVarId;
                }
            }

            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType(mFeatureBean.style)
                    .setTopicId(featureItemData.topicID)
                    .setItemType(featureItemData.detailType)
                    .setItemId(featureItemData.itemID)
                    .setItemValue(featureItemData.packageName)
                    .setExtraValue(getExtraValue(mPageParamInfo, featureItemData.planId))
                    .setTaskId(featureItemData.getTaskId())
                    .setExpId(featureItemData.getExpId())
                    .setItemFrom(featureItemData.getItemFrom())
                    .setReportSource(featureItemData.getReportSource())
                    .setVarId(builderVarId)
                    .setNativeId(featureItemData.nativeId)
                    .setDataType(featureItemData.dataType)
                    .setFeatureId(mFeatureBean.featureId)
                    .setExtras(CommonUtils.getNewExtras(null, mFeaturedName, mFeatureBean.tabNum))
                    .setAdPositionId(adPosId);
            if (featureItemData.reportDto!=null) {
                builder.setTid(featureItemData.reportDto.traceId);
                builder.setNfAbExpId(featureItemData.reportDto.nfAbExpId);
                builder.setNfAbId(featureItemData.reportDto.nfAbId);
            }
            TRAnalysticsUtil.trackExposure(builder);
        }
    }

    private String getExtraValue(PageParamInfo pageParamInfo, int planId) {
        JsonObject js = new JsonObject();
        try {
            if(planId > 0) {
                js.addProperty(TRAnalyticsConstant.PLAN_ID, planId);
            }
            if (pageParamInfo != null && !TextUtils.isEmpty(pageParamInfo.getTabId())) {
                js.addProperty("tabId", pageParamInfo.getTabId());
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return js.toString();
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        if (holder instanceof VerticalScrollSingleLineRecyclerViewHolder) {
            ((VerticalScrollSingleLineRecyclerViewHolder) holder).binding.layoutItem.ivIcon.setImageDrawable(null);
        }
    }

    private void updateTextDownloadCountAndSize(FeatureItemData featureData, TextView tv_download_count_and_size) {
        if (0 != featureData.size) {
            tv_download_count_and_size.setVisibility(View.VISIBLE);
            CommonUtils.setStrikeThroughSpannable(featureData.size, featureData.compSourceSize, tv_download_count_and_size);
        } else {
            tv_download_count_and_size.setVisibility(View.GONE);
        }
    }


    private class VerticalScrollSingleLineRecyclerViewHolder extends BaseRecyclerViewHolder{

        LayoutCollectionVerticalItemBindingImpl binding;
        public VerticalScrollSingleLineRecyclerViewHolder(ViewDataBinding viewDataBinding) {
            super(viewDataBinding.getRoot());
            binding = (LayoutCollectionVerticalItemBindingImpl)viewDataBinding;
        }
    }

    //防止快速点击响应多次
    private class NoDoubleClickListener implements View.OnClickListener {

        private FeatureItemData featureItemData;

        public NoDoubleClickListener(FeatureItemData featureItemData) {
            this.featureItemData = featureItemData;
        }

        @Override
        @SingleClick(800)
        public void onClick(View v) {
            if (featureItemData != null && !TextUtils.isEmpty(featureItemData.itemID)) {
                String builderVarId = "";
                if (TextUtils.isEmpty(mVarId)) {
                    builderVarId = featureItemData.getVarId();
                } else {
                    if (featureItemData.getVarId() == null || featureItemData.getVarId().isEmpty()) {
                        builderVarId = mVarId;
                    } else {
                        builderVarId = featureItemData.getVarId() + "," + mVarId;
                    }
                }

                String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);
                AppBuilder appBuilder = new AppBuilder()
                        .setFromPage(mFromPage)
                        .setTopicID(featureItemData.topicID)
                        .setExpId(featureItemData.getExpId())
                        .setVarId(builderVarId)
                        .setLastPage(PageConstants.getCurPageStr(mPageParamInfo))
                        .setValue(value)
                        .setParamsByData(featureItemData, mFeatureBean.featureId);
                if(featureItemData!=null && featureItemData.tNativeInfo!=null) {
                    featureItemData.tNativeInfo.handleClick(HisavanaSdkManager.CLICK_ICON);
                }
                TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);
                ComponentClickBuilder builder = new ComponentClickBuilder();
                String adPosId = featureItemData.tNativeInfo != null ? featureItemData.tNativeInfo.getPlacementId() : null;
                String clickId = UUID.randomUUID().toString().replace("-","");

                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(mFeatureBean.style)
                        .setTopicId(featureItemData.topicID)
                        .setItemType(featureItemData.detailType)
                        .setItemId(featureItemData.itemID)
                        .setButtonType(TRAnalyticsConstant.ICON)
                        .setItemValue(featureItemData.packageName)
                        .setExtraValue(getExtraValue(mPageParamInfo, featureItemData.planId))
                        .setClickId(clickId)
                        .setTaskId(featureItemData.getTaskId())
                        .setExpId(featureItemData.getExpId())
                        .setItemFrom(featureItemData.getItemFrom())
                        .setVarId(builderVarId)
                        .setReportSource(featureItemData.getReportSource())
                        .setNativeId(featureItemData.nativeId)
                        .setFeatureId(mFeatureBean.featureId)
                        .setReportSource(featureItemData.getReportSource())
                        .setExtras(CommonUtils.getNewExtras(null, mFeaturedName, mFeatureBean.tabNum))
                        .setAdPositionId(adPosId);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                    builder.setNfAbExpId(featureItemData.reportDto.nfAbExpId);
                    builder.setNfAbId(featureItemData.reportDto.nfAbId);
                }
                TRAnalysticsUtil.trackClick(builder);
            }
        }

    }

    // download click listener
    class DownloadBtnOnClickListener implements View.OnClickListener {

        private VerticalScrollSingleLineRecyclerViewHolder holder;
        private FeatureItemData featureItemData;
        private View bindClickView;
        private int mPosition;

        public DownloadBtnOnClickListener(VerticalScrollSingleLineRecyclerViewHolder holder, FeatureItemData featureItemData, View bindClickView, int position) {
            this.holder = holder;
            this.featureItemData = featureItemData;
            this.bindClickView = bindClickView;
            this.mPosition = position;
        }

        @Override
        public void onClick(View v) {
            if (bindClickView == null || holder == null || featureItemData == null)
                return;
            if (mOnFeatureClickListener != null) {
                mOnFeatureClickListener.onFeatureItemClick(featureItemData, mPosition, null);
            }
//            onFeatureItemClick(featureItemData, mPosition, null);
            String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);
            String itemFrom = featureItemData.getItemFrom();
            String adPosId = featureItemData.tNativeInfo != null ? featureItemData.tNativeInfo.getPlacementId() : null;

            String builderVarId = "";
            if (TextUtils.isEmpty(mVarId)) {
                builderVarId = featureItemData.getVarId();
            } else {
                if (featureItemData.getVarId() == null || featureItemData.getVarId().isEmpty()) {
                    builderVarId = mVarId;
                } else {
                    builderVarId = featureItemData.getVarId() + "," + mVarId;
                }
            }
      //      String clickId = UUID.randomUUID().toString().replace("-","");

            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType(mFeatureBean.style)
                    .setTopicId(featureItemData.topicID)
                    .setItemType(featureItemData.detailType)
                    .setItemId(featureItemData.itemID)
                    .setItemValue(featureItemData.packageName)
                    .setExtraValue(getExtraValue(mPageParamInfo, featureItemData.planId))
                    .setTaskId(featureItemData.getTaskId())
                    .setExpId(featureItemData.getExpId())
                    .setItemFrom(itemFrom)
                    .setVarId(builderVarId)
                    .setFeatureId(mFeatureBean.featureId)
                    .setNativeId(featureItemData.nativeId)
                    .setReportSource(featureItemData.getReportSource())
                    .setExtras(CommonUtils.getNewExtras(null, mFeaturedName, mFeatureBean.tabNum))
                    .setAdPositionId(adPosId)
                    .setFromPage(mFromPage)
              //      .setClickId(clickId)
                    .setIsVa(featureItemData.isVa);
            if (featureItemData.reportDto!=null) {
                builder.setTid(featureItemData.reportDto.traceId);
                builder.setNfAbExpId(featureItemData.reportDto.nfAbExpId);
                builder.setNfAbId(featureItemData.reportDto.nfAbId);
            }
            PsVaManager.getInstance().checkDownloadInfo(featureItemData,LaunchInfo.LAUNCH_FROM_ICON,mFromPage,value,
                    new IVaPlayDownloadCallback() {
                        @Override
                        public void clickVaPlay() {
                            builder.setButtonType(TRAnalyticsConstant.PLAY);
                            TRAnalysticsUtil.trackClick(builder);
                        }
                        @Override
                        public void start() {
                            DownloadBtnOnClickListener.this.startDownload(featureItemData, holder.binding.layoutItem.ivIcon, holder.binding.layoutItem.downloadView, builder);
                        }
                    });
        }

        private void startDownload(FeatureItemData featureItemData, ImageView iv_icon, View downloadView, ComponentClickBuilder builder) {
            if (featureItemData == null) {
                return;
            }
            String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);

            if (FileDownloadInfo.STATUS_DOWNING == featureItemData.observerStatus) {
                DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_WAIT == featureItemData.observerStatus) {
                if ((featureItemData.isVa)) {
                    DownloadManager.getInstance().resumeDownload(featureItemData.packageName);
                } else {
                    DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                }
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_PAUSE == featureItemData.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == featureItemData.observerStatus) {
                DownloadUtil.resumeDownload(PalmplayApplication.getAppInstance(), featureItemData.packageName);
                builder.setButtonType(TRAnalyticsConstant.CONTINUE);
                TRAnalysticsUtil.trackClick(builder);
            } else {
                if (FileDownloadInfo.STATUS_NONE == featureItemData.observerStatus) {//下载
                    builder.setButtonType(TRAnalyticsConstant.INSTALL);
                    TRAnalysticsUtil.trackClick(builder);
                } else if (FileDownloadInfo.STATUS_APP_INSTALLED == featureItemData.observerStatus) {//打开
                    builder.setButtonType(TRAnalyticsConstant.OPEN)
                            .setExtraValue(DeeplinkManager.getDeeplink(featureItemData.packageName));
                    TRAnalysticsUtil.trackClick(builder);
                } else if (FileDownloadInfo.STATUS_APP_UPDATE == featureItemData.observerStatus) {
                    builder.setButtonType(TRAnalyticsConstant.UPDATE);
                    TRAnalysticsUtil.trackClick(builder);
                }
                if (DownloadDecorator.checkJumpToGooglePlay(PalmplayApplication.getAppInstance(), featureItemData.getOuterUrl(), featureItemData.packageName, mPageParamInfo, featureItemData.itemID, featureItemData.versionCode, featureItemData.verifyGoogle)) {
                    return;
                }

                if(featureItemData!=null && featureItemData.tNativeInfo!=null && CommonUtils.isFirstClick(featureItemData.observerStatus)) {
                    featureItemData.tNativeInfo.handleClick(HisavanaSdkManager.FIRST_CREATE);
                }

                AnimationFactory mAnimationFactory = null;
                AnimationFactoryParams param = null;

                if (mOnViewLocationInScreen != null) {
                    mAnimationFactory = AppDetailAnimationUtil.getInstance();
                    param = new AnimationFactoryParams(iv_icon, mOnViewLocationInScreen, 24);
                }

                AppInfo appInfo = FeatureItemData.convertToCommonInfo(featureItemData, mFeatureBean.featureId);
                appInfo.sourceType = mSourceType;
                DownloadDecorator.startDownloading(appInfo, mFromPage, new PageParamInfo(mFrom, value), mAnimationFactory, param);
            }
        }


    }

    public static void updateItemProgress(View itemView, FileDownloadInfo downloadInfo, int progress, OfferInfo offerInfo) {
        RecyclerView bv_home_recycleview = (RecyclerView) itemView.findViewById(R.id.bv_home_recycleview);
        if (bv_home_recycleview == null) return;
        RecyclerView.Adapter adapter = bv_home_recycleview.getAdapter();
        if (adapter == null || downloadInfo == null) {
            return;
        }

        String packageName = downloadInfo.packageName;
        int childCount = adapter.getItemCount();
        LinearLayoutManager lm = (LinearLayoutManager) bv_home_recycleview.getLayoutManager();
        for (int i = 0; i < childCount; i++) {
            View childView = lm.findViewByPosition(i);
            Object objTag = childView != null ? childView.getTag() : null;
            if (objTag != null && objTag instanceof FeatureItemData) {
                FeatureItemData featureItemData = (FeatureItemData) objTag;
                if (!TextUtils.isEmpty(featureItemData.packageName) && featureItemData.packageName.equals(packageName)) {
                    XFermodeDownloadView downloadView = (XFermodeDownloadView) childView.findViewById(R.id.downloadView);
                    CommonUtils.updateViewHolderProgressBar(downloadInfo, downloadView, offerInfo, null);
                }
            }
        }
    }

    public void setFeatureName(String featureName) {
        mFeaturedName = featureName;
    }

    public void setCurScreenPage(String screenPage) {
        mScreenPageName = screenPage;
    }

    public void onDestroy() {

    }
}

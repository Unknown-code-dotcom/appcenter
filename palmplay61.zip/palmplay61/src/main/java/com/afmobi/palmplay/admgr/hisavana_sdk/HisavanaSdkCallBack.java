package com.afmobi.palmplay.admgr.hisavana_sdk;


import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;

import java.util.List;

public interface HisavanaSdkCallBack {
    void onError(TaErrorCode adError);
    void onAdLoaded(final List<TaNativeInfo> adInfo);
    void onAdClicked();
    void onTimeOut();
    void onAdCache(List<TaNativeInfo> adInfos);
}

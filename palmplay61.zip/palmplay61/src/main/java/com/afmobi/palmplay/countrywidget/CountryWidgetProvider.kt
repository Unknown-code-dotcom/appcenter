package com.afmobi.palmplay.countrywidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.widget.RemoteViews
import androidx.core.net.toUri
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.thirdlauncher.ThirdLauncherActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.MultiTransformation
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.cloud.tmc.integration.utils.ext.px2dp
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.widgetslib.util.DimensionUtil.dpToPx
import com.transsnet.store.R
import kotlin.random.Random


class CountryWidgetProvider : AppWidgetProvider() {
    companion object {
        const val TAG = "CountryWidgetProvider"
        const val ACTION_MY_WIDGET_UPDATE = "com.afmobi.palmplay.countrywidget.ACTION_MY_WIDGET_UPDATE"
        const val ACTION_MY_WIDGET_CLEAR = "com.afmobi.palmplay.countrywidget.ACTION_MY_WIDGET_CLEAR"
        val SOURCE = "AiWidget"
        val HOME = "palmplay://thirdlauncher.com/?entryType=SubjectRank&detailType=SOFT&_source=$SOURCE"

    }


    override fun onEnabled(context: Context?) {
        super.onEnabled(context)
        LogUtils.d(TAG,"onEnabled")
    }

    override fun onReceive(context: Context, intent: Intent?) {
        super.onReceive(context, intent)
        LogUtils.d(TAG,"onReceive"+ "..."+intent?.getAction())
        if (TextUtils.equals(ACTION_MY_WIDGET_UPDATE , intent?.action)) {
            // 手动触发更新
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val provider: ComponentName = ComponentName(
                context,
                CountryWidgetProvider::class.java
            )
            val appWidgetIds = appWidgetManager.getAppWidgetIds(provider)
            LogUtils.d(TAG,"appWidgetIds.size:"+appWidgetIds.size)
            this.updateMyWidget(context, appWidgetManager, appWidgetIds)
        } else if (TextUtils.equals(ACTION_MY_WIDGET_CLEAR , intent?.action)) {
            clearCard(context)
        }
    }

    private fun updateMyWidget(context: Context,
                               appWidgetManager: AppWidgetManager,
                               appWidgetIds: IntArray) {
        val imageUrls = MMKVUtils.getMMKV().getStringSet("image_urls", emptySet())?.toList()?: emptyList()
        var views = RemoteViews(context.packageName, R.layout.widget_country)

        if (appWidgetIds.isNotEmpty()) {
            val options = appWidgetManager.getAppWidgetOptions(appWidgetIds[0])
            val iconSize = options.getInt("tr_launcher_icon_size")
            val iconDp = iconSize.px2dp
            // 获取最小宽度和高度（以dp为单位）
            val minWidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            if (minWidth > 160) {
                    views = RemoteViews(context.packageName, R.layout.widget_country_min)
                if (iconDp >= 60) {
                    views = RemoteViews(context.packageName, R.layout.widget_country)
                }
            } else if( minWidth > 120) {
                    views = RemoteViews(context.packageName, R.layout.widget_country_small_min)
                if (iconDp >= 50) {
                    views = RemoteViews(context.packageName, R.layout.widget_country_small)
                }
            }

        }

        val intent = Intent(context, ThirdLauncherActivity::class.java)
        intent.setAction(Intent.ACTION_VIEW)
        intent.setData(HOME.toUri())
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val requestCode = Random.nextInt(Int.MAX_VALUE)
        // 点击整个区域跳转 MainActivity
        val pendingIntent = PendingIntent.getActivity(
            context, requestCode, intent,
            flags
        )
        views?.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
        if (appWidgetIds.isNotEmpty()) {
            for (appWidgetId in appWidgetIds) {
                LogUtils.d(TAG, "appWidgetId:$appWidgetId")
                appWidgetManager.updateAppWidget(appWidgetId, views)
                updateWidgetImages(context, appWidgetId, imageUrls, views)
            }
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            LogUtils.d(TAG,"onUpdate" +"..."+appWidgetId)
        }
        this.updateMyWidget(context, appWidgetManager, appWidgetIds)
    }

    private fun clearCard(context: Context) {
        LogUtils.d(TAG,"clearCard")
        val views = RemoteViews(context.packageName, R.layout.widget_country)
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val provider: ComponentName = ComponentName(
            context,
            CountryWidgetProvider::class.java
        )
        val appWidgetIds = appWidgetManager.getAppWidgetIds(provider)
        views.setCharSequence(R.id.widget_root,"setContentDescription","tran_sug_view_disable")
        if (appWidgetIds.isNotEmpty()) {
            for (appWidgetId in appWidgetIds) {
                LogUtils.d(TAG,"clearCard:"+appWidgetId)
                appWidgetManager.updateAppWidget(appWidgetId, views)
            }
        } else {
            appWidgetManager.updateAppWidget(ComponentName(context,
                CountryWidgetProvider::class.java), views)
        }
    }

    private fun getOption(index: Int): RequestOptions {
        val transformations = MultiTransformation(
            CenterCrop(),
            RoundedCorners(dpToPx(
                if (index == 0) 12 else 7, PalmplayApplication.getAppInstance()))
        )
       return RequestOptions.bitmapTransform(transformations)
    }

    private fun getPlaceHolder(index:Int): Int {
        return when (index) {
            0 -> R.drawable.widget_default_bg_1
            1 -> R.drawable.widget_default_bg_2
            2 -> R.drawable.widget_default_bg_3
            3 -> R.drawable.widget_default_bg_4
            4 -> R.drawable.widget_default_bg_5
            else -> 0
        }
    }
    private fun getImageSize(index:Int): Int {
        return when (index) {
            0 -> dpToPx(52, PalmplayApplication.getAppInstance())
            else -> dpToPx(24, PalmplayApplication.getAppInstance())
        }
    }

    private fun fullFiveItemImgList(imageUrls: List<String>):List<String>{
        val defaultValue = "0"
        val resultList = imageUrls.toMutableList()
        while (resultList.size < 5) {
            resultList.add(defaultValue)
        }
        return resultList
    }

    private fun updateWidgetImages(context: Context, appWidgetId: Int, imageUrls: List<String>, remoteViews: RemoteViews) {
        LogUtils.e(TAG,"updateWidgetImages:"+imageUrls?.toString())
        val newList = fullFiveItemImgList(imageUrls)
        newList.take(5).forEachIndexed { index, url ->
            val imageViewId = when (index) {
                0 -> R.id.img_left
                1 -> R.id.img_1
                2 -> R.id.img_2
                3 -> R.id.img_3
                4 -> R.id.img_4
                else -> null
            }
            imageViewId?.let { id ->
                Glide.with(context.applicationContext)
                    .asBitmap()
                    .load(url)
                    .placeholder(getPlaceHolder(index))
                    .error(getPlaceHolder(index))
                    .override(getImageSize(index))
                    .apply(getOption(index))
                    .into(object : CustomTarget<Bitmap>() {
                        override fun onResourceReady(
                            resource: Bitmap,
                            transition: Transition<in Bitmap>?
                        ) {
                            LogUtils.d(TAG,"onResourceReady")
                            remoteViews.setImageViewBitmap(id, resource)
                            if (appWidgetId !=-1) {
                                AppWidgetManager.getInstance(context)
                                    .updateAppWidget(appWidgetId, remoteViews)
                            } else {
                                AppWidgetManager.getInstance(context).updateAppWidget(ComponentName(context,
                                    CountryWidgetProvider::class.java)
                                    ,remoteViews)
                            }
                        }

                        override fun onLoadCleared(placeholder: Drawable?) {
                            LogUtils.d(TAG,"onLoadCleared")
                        }


                        override fun onLoadFailed(errorDrawable: Drawable?) {
                            super.onLoadFailed(errorDrawable)
                            remoteViews.setImageViewResource(id, getPlaceHolder(index))
                            LogUtils.d(TAG,"onLoadFailed")
                            if (appWidgetId != -1) {
                                AppWidgetManager.getInstance(context)
                                    .updateAppWidget(appWidgetId, remoteViews)
                            } else {
                                AppWidgetManager.getInstance(context).updateAppWidget(ComponentName(context,
                                    CountryWidgetProvider::class.java)
                                    ,remoteViews)
                            }
                        }
                    })
            }
        }
    }

    override fun onDisabled(context: Context?) {
        super.onDisabled(context)
        CountrySwitchManager.clearHandlerTask()
    }

    override fun onDeleted(context: Context?, appWidgetIds: IntArray?) {
        super.onDeleted(context, appWidgetIds)
        CountrySwitchManager.clearHandlerTask()
    }


    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        // 获取最小宽度和高度（以dp为单位）
        val newMinWidth = newOptions.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)

        val iconSize = newOptions.getInt("tr_launcher_icon_size")
        val iconDp = iconSize.px2dp
        val intent = Intent(context, ThirdLauncherActivity::class.java)
        intent.setAction(Intent.ACTION_VIEW)
        intent.setData(HOME.toUri())
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val requestCode = Random.nextInt(Int.MAX_VALUE)
        // 点击整个区域跳转 MainActivity
        val pendingIntent = PendingIntent.getActivity(
            context, requestCode, intent,
            flags
        )
        val imageUrls = MMKVUtils.getMMKV().getStringSet("image_urls", emptySet())?.toList()?: emptyList()


        if (newMinWidth > 160) {
            var views = RemoteViews(context.packageName, R.layout.widget_country_min)
            if (iconDp >= 60) {
                views = RemoteViews(context.packageName, R.layout.widget_country)
            }
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            updateWidgetImages(context, appWidgetId, imageUrls, views)
        } else if (newMinWidth > 120) {
            var views = RemoteViews(context.packageName, R.layout.widget_country_small_min)
            if (iconDp >= 50) {
                views = RemoteViews(context.packageName, R.layout.widget_country_small)
            }
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            updateWidgetImages(context, appWidgetId, imageUrls, views)
        }

    }

}

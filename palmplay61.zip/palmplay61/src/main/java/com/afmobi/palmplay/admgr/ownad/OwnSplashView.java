package com.afmobi.palmplay.admgr.ownad;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.glide.CacheChoice;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.DeviceTypeExKt;
import com.transsnet.store.R;

import java.io.File;

import androidx.annotation.Nullable;

public class OwnSplashView extends RelativeLayout implements View.OnClickListener {

    private final static int SPLASH_AD_DEFAULT_SKIP = 3;
    private ImageView iv_ad;
    private LinearLayout ad_btn_layout;
    private TextView tv_adTips;
    private TextView tv_skip;

    private OwnAdLoadListener mAdLoadListener;

    private boolean isAdLoadedSuccess = false;
    private OwnAdBean mAdBean = null;

    private Handler mHandle = null;
    private Runnable mRunnable = null;
    private int mSkipTime = SPLASH_AD_DEFAULT_SKIP; //unit:s
    private final static int SPLASH_AD_MAX_INTERVAL = 5;//5s
    private boolean clickType = false;

    public OwnSplashView(Context context) {
        this(context, null);
    }

    public OwnSplashView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public OwnSplashView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        init();
    }

    @SuppressLint("MissingInflatedId")
    private void init() {
        View adContent = LayoutInflater.from(getContext()).inflate(R.layout.layout_ad_content, null);
        iv_ad = adContent.findViewById(R.id.iv_ad);
        ad_btn_layout = adContent.findViewById(R.id.ad_btn_layout);
        tv_skip = adContent.findViewById(R.id.tv_skip);
        tv_adTips = adContent.findViewById(R.id.tv_adTips);

        iv_ad.setOnClickListener(this);
        tv_skip.setOnClickListener(this);


        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        try {
            this.removeAllViews();
            this.addView(adContent, lp);
            updateAdScaleType();
        } catch (Throwable e) {
            //ignore
        }


        this.setVisibility(View.GONE);

        this.mHandle = new Handler();
        this.mRunnable = new Runnable() {
            @Override
            public void run() {

                stopSkipTimer();
                String txt = getResources().getString(R.string.launcher_admob_ad_skip) + " " + mSkipTime;
                tv_skip.setText(txt);

                if(mHandle != null) {
                    if(mSkipTime > 0) {
                        mSkipTime--;
                        mHandle.postDelayed(mRunnable, 1000);
                    }else {
                        if(mAdLoadListener != null) {
                            mAdLoadListener.onTimeReach();
                        }
                    }
                }

            }
        };
    }

    private void updateAdScaleType() {
        if (iv_ad == null) {
            return;
        }

        iv_ad.setScaleType(DeviceTypeExKt.isPadDisplay(getContext(), getContext().getResources().getConfiguration(), DeviceTypeExKt.getContextDisplayId(getContext()))
                ? ImageView.ScaleType.FIT_CENTER
                : ImageView.ScaleType.FIT_XY);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        updateAdScaleType();
    }

    public void onAdLoad() {
        if (mAdBean == null || iv_ad == null || TextUtils.isEmpty(mAdBean.getAdIconUrl())) {
            if(mAdLoadListener != null) {
                mAdLoadListener.onOwnAdError(OwnAdLoadListener.AD_ERROR_URL);
            }
            return;
        }

        TRBitmapManager.downloadImageByFrescoCbOnMainWithData(mAdBean.getAdIconUrl(), 0, 0, CacheChoice.SMALL, new RequestListener<File>() {

            @Override
            public boolean onResourceReady(File resource, Object model, Target target, com.bumptech.glide.load.DataSource dataSource, boolean isFirstResource) {
                GlideUtils.saveFile(resource, mAdBean.getAdIconUrl());

                isAdLoadedSuccess = false;
                if (dataSource != null && !TextUtils.isEmpty(mAdBean.getAdIconUrl())) {
//                    Bitmap bitmap = TRBitmapManager.getBitmapFromFrescoDiskWithSmallCache(mAdBean.getAdIconUrl());
//                    if (bitmap != null && !bitmap.isRecycled()) {
//                        iv_ad.setImageBitmap(bitmap);
//                    } else
                    {
                        RequestOptions options = DeviceTypeExKt.isPadDisplay(getContext(), getContext().getResources().getConfiguration(), DeviceTypeExKt.getContextDisplayId(getContext())) ? new RequestOptions()
                                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                                .skipMemoryCache(false)
                                                .dontTransform()
                                : GlideUtils.newCommonRequestOptions();
                        GlideUtils.setImageUriWithNoBorderSmall(iv_ad, mAdBean.getAdIconUrl(), 0,
                                options, R.drawable.default_banner, R.drawable.default_banner);
                    }
                    isAdLoadedSuccess = true;
                }

                if(mAdLoadListener != null) {
                    if(isAdLoadedSuccess) {
                        mAdLoadListener.onOwnAdLoaded(mAdBean);
                    }else {
                        mAdLoadListener.onOwnAdError(OwnAdLoadListener.AD_ERROR_UNKNOWN);
                    }
                }
                return true;
            }

            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target target, boolean isFirstResource) {
                isAdLoadedSuccess = false;
                if(mAdLoadListener != null) {
                    mAdLoadListener.onOwnAdError(OwnAdLoadListener.AD_ERROR_NET);
                }
                return false;
            }
        });
    }

    public void onAdPreLoad() {
        if (mAdBean == null || iv_ad == null|| TextUtils.isEmpty(mAdBean.getAdIconUrl())) {
            if(mAdLoadListener != null) {
                mAdLoadListener.onOwnAdError(OwnAdLoadListener.AD_ERROR_URL);
            }
            return;
        }

        TRBitmapManager.downloadImageByFrescoCbOnMainWithData(mAdBean.getAdIconUrl(), 0, 0, CacheChoice.SMALL, new RequestListener<File>() {
            @Override
            public boolean onResourceReady(File resource, Object model, Target target, com.bumptech.glide.load.DataSource dataSource, boolean isFirstResource) {
                GlideUtils.saveFile(resource, mAdBean.getAdIconUrl());

                isAdLoadedSuccess = false;

                if (dataSource != null) {
                    isAdLoadedSuccess = true;
                }

                if(mAdLoadListener != null) {
                    if(isAdLoadedSuccess) {
                        mAdLoadListener.onOwnAdLoaded(mAdBean);
                    }else {
                        mAdLoadListener.onOwnAdError(OwnAdLoadListener.AD_ERROR_UNKNOWN);
                    }
                }
                return true;
            }

            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target target, boolean isFirstResource) {
                isAdLoadedSuccess = false;

                if(mAdLoadListener != null) {
                    mAdLoadListener.onOwnAdError(OwnAdLoadListener.AD_ERROR_NET);
                }
                return false;
            }
        });
    }

    public void showAd() {
        if(iv_ad != null && mAdBean != null && !TextUtils.isEmpty(mAdBean.getAdIconUrl())) {
            this.setVisibility(View.VISIBLE);

            if(mAdLoadListener != null) {
                mAdLoadListener.onShow();
            }

            startSkipTimer();

            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.SPLASH_AD_SHOW, null);
        }else {
            if(mAdLoadListener != null) {
                mAdLoadListener.onSkipAd(mAdBean); // for ad catch exception
            }
        }
    }

    public OwnSplashView setAdBean(OwnAdBean adBean) {
        this.mAdBean = adBean;
        int time = (adBean != null) ? (Math.abs(adBean.getShowTime())) : 0;
        this.mSkipTime = Math.min(time, SPLASH_AD_MAX_INTERVAL); // 最大5秒，防止后台配置出错
        boolean adTipsCanShow = (adBean != null) ? adBean.isAdShow() : false;

        if (tv_adTips != null) {
            if(adTipsCanShow) {
                tv_adTips.setVisibility(View.VISIBLE);
            } else {
                tv_adTips.setVisibility(View.GONE);
            }
        }
        if (mAdBean != null) {
            clickType = mAdBean.getLimitClickArea() == 1;
        }

        if (clickType) {
            ad_btn_layout.setVisibility(View.VISIBLE);
            ad_btn_layout.setOnClickListener(this);
        } else {
            ad_btn_layout.setVisibility(View.GONE);
        }

        return this;
    }

    public OwnAdBean getAdBean() {
        return this.mAdBean;
    }

    public OwnSplashView setOwnAdLoadListener(OwnAdLoadListener l) {
        this.mAdLoadListener = l;
        return this;
    }

    public boolean isAdLoadedSuccess() {
        return isAdLoadedSuccess;
    }

    public void destroySplashView() {
        stopSkipTimer();
        mHandle = null;
        mRunnable = null;
    }

    public void resumeSplashView() {
        startSkipTimer();
    }

    public void stopSplashView() {
        stopSkipTimer();
    }

    private void startSkipTimer() {
        if(mHandle != null && mRunnable != null && mSkipTime > 0) {
            mHandle.post(mRunnable);
        }
    }

    public void stopSkipTimer() {
        if(mHandle != null) {
            mHandle.removeCallbacks(mRunnable);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_ad:
                if (!clickType) {
                    if (mAdLoadListener != null) {
                        mAdLoadListener.onClicked(mAdBean);
                    }
                }
                break;
            case R.id.ad_btn_layout:
                if (clickType) {
                    if (mAdLoadListener != null) {
                        mAdLoadListener.onClicked(mAdBean);
                    }
                }
                break;

            case R.id.tv_skip:
                if(mAdLoadListener != null) {
                    mAdLoadListener.onSkipAd(mAdBean);
                }
                stopSkipTimer();
                break;
        }
    }

}

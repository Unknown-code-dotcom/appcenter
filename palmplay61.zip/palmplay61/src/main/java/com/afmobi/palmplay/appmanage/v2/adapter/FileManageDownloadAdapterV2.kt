package com.afmobi.palmplay.appmanage.v2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.appmanage.v2.holder.DownloadItemViewHolder
import com.afmobi.palmplay.appmanage.v2.holder.InstalledItemViewHolder
import com.afmobi.palmplay.appmanage.v2.model.BTN_ALL_CONTINUE
import com.afmobi.palmplay.appmanage.v2.model.BTN_ALL_PAUSE
import com.afmobi.palmplay.appmanage.v2.model.BTN_GONE
import com.afmobi.palmplay.appmanage.v2.model.BtnAllType
import com.afmobi.palmplay.appmanage.v2.model.DownloadItem
import com.afmobi.palmplay.appmanage.v2.model.DownloadStatus
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.util.TRNoDoubleClickListener
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsnet.store.R
import com.transsnet.store.databinding.LayoutDownloadContentEmptyV2Binding
import com.transsnet.store.databinding.LayoutDownloadingTitleV2Binding
import com.transsnet.store.databinding.LayoutManageDownloadItemV2Binding
import com.transsnet.store.databinding.LayoutManageInstalledItemV2Binding
import kotlinx.coroutines.flow.SharedFlow

/**
 * 下载管理主列表适配器V2 - Kotlin版本
 * 支持多种ViewType：头部、下载项
 */
class FileManageDownloadAdapterV2(
    private val event: EventCombine,
    private val lifecycleScope: LifecycleCoroutineScope
) :
    ListAdapter<DownloadItem, RecyclerView.ViewHolder>(
        object : androidx.recyclerview.widget.DiffUtil.ItemCallback<DownloadItem>() {
            override fun areItemsTheSame(oldItem: DownloadItem, newItem: DownloadItem): Boolean {
                return when {
                    oldItem is DownloadItem.DownloadEmpty && newItem is DownloadItem.DownloadEmpty -> true
                    oldItem is DownloadItem.DownloadTitle && newItem is DownloadItem.DownloadTitle -> oldItem == newItem
                    oldItem is DownloadItem.DownloadItemInfo && newItem is DownloadItem.DownloadItemInfo ->
                        oldItem.info.packageName == newItem.info.packageName

                    else -> false
                }
            }

            override fun areContentsTheSame(oldItem: DownloadItem, newItem: DownloadItem): Boolean {
                return when {
                    oldItem is DownloadItem.DownloadEmpty && newItem is DownloadItem.DownloadEmpty -> true
                    oldItem is DownloadItem.DownloadTitle && newItem is DownloadItem.DownloadTitle -> oldItem == newItem
                    oldItem is DownloadItem.DownloadItemInfo && newItem is DownloadItem.DownloadItemInfo -> {
                        val diffCallback = DownloadDiffCallback()
                        oldItem.installed == newItem.installed
                                && diffCallback.areContentsTheSame(oldItem.info, newItem.info)
                    }

                    else -> false
                }
            }
        }
    ) {

    companion object {
        private const val VIEW_TYPE_EMPTY = -1
        private const val VIEW_TYPE_HEADER = 0
        private const val VIEW_TYPE_DOWNLOAD_ITEM = 1
        private const val VIEW_TYPE_INSTALLED_ITEM = 2
    }

    override fun getItemViewType(position: Int): Int {
        val item = getItem(position)
        return when (item) {
            is DownloadItem.DownloadEmpty -> VIEW_TYPE_EMPTY
            is DownloadItem.DownloadTitle -> VIEW_TYPE_HEADER
            is DownloadItem.DownloadItemInfo -> {
                if (item.installed) {
                    VIEW_TYPE_INSTALLED_ITEM
                } else {
                    VIEW_TYPE_DOWNLOAD_ITEM
                }
            }

            else -> throw IllegalArgumentException("Unknown item type at position $position")
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        return when (viewType) {
            VIEW_TYPE_HEADER -> {
                val binding = LayoutDownloadingTitleV2Binding.inflate(inflater, parent, false)
                HeaderViewHolder(binding, event.onBtnAllClick)
            }

            VIEW_TYPE_DOWNLOAD_ITEM -> {
                val binding =
                    LayoutManageDownloadItemV2Binding.inflate(inflater, parent, false)
                DownloadItemViewHolder(binding, event, lifecycleScope)
            }

            VIEW_TYPE_INSTALLED_ITEM -> {
                val binding =
                    LayoutManageInstalledItemV2Binding.inflate(inflater, parent, false)
                InstalledItemViewHolder(binding, event, lifecycleScope)
            }

            VIEW_TYPE_EMPTY -> {
                val binding =
                    LayoutDownloadContentEmptyV2Binding.inflate(inflater, parent, false)
                EmptyViewHolder(binding, event.onEmptyViewClick)
            }

            else -> throw IllegalArgumentException("Unknown view type: $viewType")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is EmptyViewHolder -> {
                val emptyInfo = getItem(position) as DownloadItem.DownloadEmpty
                holder.bind(emptyInfo)
            }

            is HeaderViewHolder -> {
                val headerInfo = getItem(position) as DownloadItem.DownloadTitle
                holder.bind(headerInfo)
            }

            is DownloadItemViewHolder -> {
                val downloadInfo = (getItem(position) as DownloadItem.DownloadItemInfo).info
                holder.bind(downloadInfo)
            }

            is InstalledItemViewHolder -> {
                val downloadInfo = (getItem(position) as DownloadItem.DownloadItemInfo).info
                holder.bind(downloadInfo)
            }
        }
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.isEmpty()) {
            super.onBindViewHolder(holder, position, payloads)
        } else {
            // 处理局部更新
            if (holder is DownloadItemViewHolder) {
                val downloadInfo = (getItem(position) as DownloadItem.DownloadItemInfo).info
                val changes = payloads[0] as? List<String>
                holder.bindWithPayload(downloadInfo, changes)
            }
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is DownloadItemViewHolder) {
            holder.onRecycled()
        }
    }

    /**
     * 头部ViewHolder
     */
    inner class EmptyViewHolder(
        private val binding: LayoutDownloadContentEmptyV2Binding,
        private var onEmptyViewClick: OnEmptyViewClick?
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(emptyInfo: DownloadItem.DownloadEmpty) {
            if (TRApplicationContextUtil.isProject()) {
                binding.tvSeeMore.visibility = View.GONE
                binding.ivArrow.visibility = View.GONE
            }
            binding.tvSeeMore.setOnClickListener(clickListener)
            binding.ivArrow.setOnClickListener(clickListener)
        }

        private val clickListener by lazy {
            object : TRNoDoubleClickListener() {
                override fun onNoDoubleClick(v: View?) {
                    LogUtils.d("EmptyViewHolder", "onNoDoubleClick")
                    onEmptyViewClick?.invoke()
                }
            }
        }
    }

    /**
     * 头部ViewHolder
     */
    inner class HeaderViewHolder(
        private val binding: LayoutDownloadingTitleV2Binding,
        private var onBtnAllClick: OnBtnAllClick?
    ) : RecyclerView.ViewHolder(binding.root) {

        @BtnAllType
        var btnAllType: Int = BTN_GONE

        fun bind(headerInfo: DownloadItem.DownloadTitle) {
            btnAllType = headerInfo.btnAllType
            binding.tvDownloadingTask.text = headerInfo.title
            binding.tvDownloadingAll.apply {
                when (headerInfo.btnAllType) {
                    BTN_GONE -> {
                        visibility = View.GONE
                    }

                    BTN_ALL_CONTINUE -> {
                        visibility = View.VISIBLE
                        text = binding.root.context.getString(R.string.txt_continue_all)
                    }

                    BTN_ALL_PAUSE -> {
                        visibility = View.VISIBLE
                        text = binding.root.context.getString(R.string.pause_all)
                    }
                }
            }
            binding.tvDownloadingAll.setOnClickListener(clickListener)
        }

        private val clickListener by lazy {
            object : TRNoDoubleClickListener() {
                override fun onNoDoubleClick(v: View?) {
                    LogUtils.d("HeaderViewHolder", "onBtnAllClick$btnAllType")
                    onBtnAllClick?.invoke(btnAllType)
                }
            }
        }
    }
}

data class EventCombine(
    val itemStatusFlow: ItemStatusFlow? = null,
    val onEmptyViewClick: OnEmptyViewClick? = null,
    val onBtnAllClick: OnBtnAllClick? = null,
    val onDownloadItemClick: OnDownloadItemClick? = null,
    val onStateBtnClick: OnStateBtnClick? = null,
    val onDownloadItemDelete: OnDownloadItemDelete? = null,
    val onItemDropDown: OnItemDropDown? = null
)

typealias ItemStatusFlow = (String?) -> SharedFlow<DownloadStatus>?
typealias OnEmptyViewClick = () -> Unit
typealias OnBtnAllClick = (Int) -> Unit
typealias OnDownloadItemClick = (downloadInfo: FileDownloadInfo, installed: Boolean, position: Int) -> Unit
typealias OnStateBtnClick = (downloadInfo: FileDownloadInfo, position: Int) -> Unit
typealias OnDownloadItemDelete = (downloadInfo: FileDownloadInfo, position: Int) -> Unit
typealias OnItemDropDown = (downloadInfo: FileDownloadInfo, position: Int) -> Unit
package com.afmobi.palmplay.appmanage.holder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afmobi.palmplay.thirdlauncher.ThirdEnterUtil;
import com.afmobi.palmplay.thirdlauncher.ThirdLauncherActivity;
import com.afmobi.util.Constant;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 无下载内容提示
 * Created by xiangfei.wei on 2018/12/24.
 */
public class DownloadContentEmptyViewHolder extends RecyclerView.ViewHolder {
    private View mDownloadEmptyView;
    private TextView tv_see_more;
    private Activity mActivity;
    private boolean hasTrack;
    protected String mScreenPageName;
    protected String mFeatureName;
    public String mFrom;//新型打点的from值
    private ImageView mArrowImgView;
    private LinearLayout llMore;

    public DownloadContentEmptyViewHolder(@NonNull View itemView) {
        super(itemView);
        mDownloadEmptyView = itemView.findViewById(R.id.layout_empty_view_root);
        tv_see_more = itemView.findViewById(R.id.tv_see_more);
        mArrowImgView = itemView.findViewById(R.id.iv_arrow);
        llMore = itemView.findViewById(R.id.ll_more);
        if(TRApplicationContextUtil.isProject()) {
            tv_see_more.setVisibility(View.GONE);
            mArrowImgView.setVisibility(View.GONE);
            llMore.setVisibility(View.GONE);
        }
    }

    public DownloadContentEmptyViewHolder setContext(Context context) {
        mActivity = (Activity) context;
        return this;
    }

    public void bind() {
        mDownloadEmptyView.setVisibility(View.VISIBLE);
        tv_see_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mActivity == null) {
                    return;
                }
                if (!mActivity.isDestroyed() && !mActivity.isFinishing()) {
                    mActivity.finish();
                }

                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", "");

                String homeEntry = "palmplay://" + ThirdLauncherActivity.HOST_THIRD_LAUNCHER + "/?entryType=" + ThirdEnterUtil.EnterType.HomeFeatured.name();
                Intent intent = new Intent(mActivity, ThirdLauncherActivity.class);
                intent.setData(Uri.parse(homeEntry));
                intent.putExtra(Constant.FROMPAGE, value);
                intent.setAction(Intent.ACTION_VIEW);

                try {
                    mActivity.startActivity(intent);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) {
                        e.printStackTrace();
                    }
                }


                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId("")
                        .setItemType(TRAnalyticsConstant.DEEP_LINK)
                        .setItemId(ThirdEnterUtil.EnterType.HomeFeatured.name())
                        .setButtonType(TRAnalyticsConstant.ICON)
                        .setItemValue(TRAnalyticsConstant.SEE_INTERESTED_IN)
                        .setExtraValue("");
                TRAnalysticsUtil.trackClick(builder);
            }
        });

        if(!hasTrack){
            hasTrack = true;
            ComponentExposureBuilder builder = new ComponentExposureBuilder();
            builder.setValue(TRStringUtil.generateString(mScreenPageName, mFeatureName, "", ""))
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.DEEP_LINK)
                    .setItemId(ThirdEnterUtil.EnterType.HomeFeatured.name())
                    .setTaskId(0);
            TRAnalysticsUtil.trackExposure(builder);
        }
    }

    public DownloadContentEmptyViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public DownloadContentEmptyViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    public DownloadContentEmptyViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }
}

package com.afmobi.palmplay.cache;

import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.util.FileUtils;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class PlutoPushIdCache{

    private List<String> pushIdList;

    private static final String pluto_push_id_uri = FilePathManager.getCacheBaseFileUri()+ File.separator + "pluto_push_id_cache.txt";

    private static PlutoPushIdCache mInstance;

    public static PlutoPushIdCache getInstance() {
        if (mInstance == null) {
            synchronized (PlutoPushIdCache.class) {
                if (mInstance == null) {
                    mInstance = new PlutoPushIdCache();
                }
            }
        }
        return mInstance;
    }

    public void putPushIdToFile(String pushId){
        pushIdList = FileUtils.getAsListObject(new File(pluto_push_id_uri));

        if(pushIdList == null){
            pushIdList = new LinkedList<>();
        }

        if(pushIdList.size() < 30){
            pushIdList.add(pushId);
        }else{
            pushIdList.remove(0);
            pushIdList.add(pushId);
        }
        FileUtils.put(new File(pluto_push_id_uri), pushIdList);
    }

    public List<String> getPushIdList(){
        return FileUtils.getAsListObject(new File(pluto_push_id_uri));
    }

}

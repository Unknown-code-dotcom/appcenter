// TOP SECRET
package com.afmobi.palmplay.base;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import com.transsnet.store.R;

public abstract class BaseContainerNoTitleFragmentActivity extends BaseFragmentActivity{
	
	
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.layout_common_framelayout);
		
	}
	
	
	/**
	 * new fragment 
	 * @param fragment - need show fragment 
	 * @param bundle - fragment arguments
	 */
	final protected void updateFragment(Fragment fragment, Bundle bundle){
		fragment.setArguments(bundle);
		replaceFragment(fragment);
	}
	
	/**
	 * replace fragment .
	 * @param fragment
	 */
	final protected void replaceFragment(Fragment fragment){
		replaceFragmentCommitAllowingStateLoss(R.id.framelayout_common_content, fragment/*, fragment.getClass().getSimpleName()*/);
	}
	
	/**
	 * fragment viewId - R.id.layout_content
	 * @return
	 */
	final protected Fragment getCurrentFragment(){
		return getSupportFragmentManager().findFragmentById(R.id.framelayout_common_content);
	}

	/**
	 * 获取Athena打点的页面value值；
	 * @return
	 */
	@Override
	public abstract String getValue();
}

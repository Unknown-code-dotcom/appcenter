package com.afmobi.palmplay.alonefuction;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.FrameLayout;

import com.afmobi.palmplay.ProcessLifecycleChecker;
import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.activate.TRSplashActivateExecutor;
import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.admgr.AdsLoadProxy;
import com.afmobi.palmplay.admgr.AdvertiseView;
import com.afmobi.palmplay.admgr.bussiness_sdk.BussinessSdkCallBack;
import com.afmobi.palmplay.admgr.bussiness_sdk.BussinessSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.base.BaseFragmentActivity;
import com.afmobi.palmplay.cache.AdCache;
import com.transsion.calculator.NoNetworkTipExclude;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.util.Constant;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.cloud.hisavana.ac.sdk.api.adx.TSplashView;
import com.cloud.hisavana.ac.sdk.api.listener.AdListener;
import com.cloud.hisavana.ac.sdk.api.listener.OnSkipListener;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.cloud.hisavana.ac.sdk.data.bean.response.BidInfo;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.List;

import static com.afmobi.palmplay.cache.AdCache.RESOURCE_NOT_READY;

@NoNetworkTipExclude
public class SplashAdActivity extends BaseFragmentActivity implements BussinessSdkCallBack {

    private AdvertiseView mAdsView;
    private FrameLayout  mFrameLayout;
    private TSplashView mTSplashView;

    private boolean mIsHisavanaSdkClicked = false;

    @Override
    protected void onCreate(Bundle onSaveInstanceState) {
        super.onCreate(onSaveInstanceState);
        setContentView(R.layout.layout_common_framelayout);
        TRStatusBarUtil.enableEdgeToEdge(this);
        TRStatusBarUtil.setStatusBarTransparent(this);

        initFragment();
        TRSplashActivateExecutor.STATUS = true;
    }

    private void initFragment() {
        mPageParamInfo.deliverPageParamInfo(mPageParamInfo, PageConstants.Start_ads);

        mFrameLayout = findViewById(R.id.framelayout_common_content);

        Intent tempIntent =  getIntent();
        int readyStatus = RESOURCE_NOT_READY;
        if(tempIntent!=null) {
            String adType = tempIntent.getStringExtra(Constant.KEY_FROM_TYPE);
            if(TextUtils.equals(TRActivateConstant.EW_SPLASH_TYPE,adType)) {
                readyStatus =AdCache.HISAVANA_SDK_READY;
            } else if(TextUtils.equals(TRActivateConstant.SPLASH_AD,adType)) {
                readyStatus = AdCache.SELF_RESOURCE_READY;
            }
        }
        LogUtils.e(BussinessSdkManager.TAG,"SplashAdActivity adResource status = "+readyStatus);
        if(readyStatus == AdCache.BUSSINESS_SDK_RESOURCE_READY) {
            LogUtils.e(BussinessSdkManager.TAG,"sdk start load from splash ad activity");
        //    BussinessSdkManager.getInstance().sdkLoad(this);
        } else if (readyStatus == AdCache.HISAVANA_SDK_READY) {
            LogUtils.e(HisavanaSdkManager.TAG,"sdk start load");
            String splashHisavanaSdkCodeId = AdCache.getInstance().getSplashHisavanaSdkCodeId();
            if (splashHisavanaSdkCodeId != null && !TextUtils.isEmpty(splashHisavanaSdkCodeId)) {
                showSdkAdvertisement(splashHisavanaSdkCodeId);
            } else {
                LogUtils.e(HisavanaSdkManager.TAG,"The opening advertisement ID is empty");
                finish();
            }
        } else if(readyStatus == AdCache.SELF_RESOURCE_READY) {
            LogUtils.e("selfsdk","sdk start load");
            showAdvertisement(true);
            LogUtils.e("selfsdk","sdk end load");
        } else {
            finish();
        }
    }

    public void showAdvertisement(boolean showSelfAd) {
        try {
            if(mAdsView==null) {
                mAdsView = new AdvertiseView.Builder(this).build(AdsLoadProxy.TYPE_UNDO, mPageParamInfo, TRAnalyticsConstant.HOME_A,showSelfAd);
            } else {
                mAdsView.onLoadSelfAd();
            }

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
            //mFrameLayout.removeAllViews();
            mFrameLayout.addView(mAdsView, lp);
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private void showSdkAdvertisement(final String codeId){
        try {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
            final String sceneCode = SceneCode.R_SP;
            if(mTSplashView == null) {
                mTSplashView = new TSplashView(this, codeId);
                mTSplashView.setSceneCode(sceneCode);
            }

            mTSplashView.setListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                }

                @Override
                public void onSplashAdLoaded(List<String> packageNames) {
                    super.onSplashAdLoaded(packageNames);
                }

                @Override
                public void onSplashAdCache(String packageName) {
                    super.onSplashAdCache(packageName);

                    int type = TextUtils.isEmpty(packageName) ? HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_SUCCESS_NO_DATA : HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_SUCCESS;
                    TRAnalysticsUtil.trackEWSDKResponse(codeId, sceneCode, type, packageName);
                    TRAnalysticsUtil.trackEwRspRecord(codeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_RSP_SUCCESS, 1, 0, false);

                    if(mTSplashView != null) {
                        if (mAdsView != null) {
                            mTSplashView.setLogoLayout(mAdsView.getAdBottomLog());
                        }
                        mTSplashView.show();
                        TRAnalysticsUtil.trackAddShowQueue(codeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_ADD_QUEUE, packageName, 0, 0);
                    }
                }

                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    if (mTSplashView != null) {
                        mTSplashView.destroy();
                    }
                }

                @Override
                public void onSplashAdShow(String packageName) {
                    super.onSplashAdShow(packageName);
                    //设置展示时间点，每天展示次数
                    AdCache.getInstance().setLastShowTime();
                    AdCache.getInstance().increaseShowCount();

                    String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.SPLASH_PV, "", "");
                    ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
                    builder.setValue(value)
                            .setFrom("x_x_x_x")
                            .setTopicType(TRAnalyticsConstant.ADVERTISE)
                            .setItemValue(packageName)
                            .setReportSource(HisavanaSdkManager.REPORT_SOURCE_EW)
                            .setAdPositionId(codeId);
                    TRAnalysticsUtil.trackExposure(builder);
                }

                @Override
                public void onError(TaErrorCode adError) {
                    super.onError(adError);
                    int errorCode = -1;
                    if(adError!=null) {
                        errorCode = adError.getErrorCode();
                    }
                    TRAnalysticsUtil.trackEWSdkErrorRsp(codeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_ERROR, null,errorCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
                    finish();
                }

                @Override
                public void onSplashAdClicked(String packageName) {
                    super.onSplashAdClicked(packageName);
                    mIsHisavanaSdkClicked = true;

                    String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.SPLASH_PV, "", "");
                    ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                    builder.setValue(value)
                            .setFrom("x_x_x_x")
                            .setTopicType(TRAnalyticsConstant.ADVERTISE)
                            .setButtonType(TRAnalyticsConstant.ICON)
                            .setItemValue(packageName)
                            .setReportSource(HisavanaSdkManager.REPORT_SOURCE_EW)
                            .setAdPositionId(codeId)
                            .setExtraValue("");
                    TRAnalysticsUtil.trackClick(builder);
                }

                @Override
                public void onTimeOut() {
                    super.onTimeOut();
                    TRAnalysticsUtil.trackEWSDKResponse(codeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_TIME_OUT, null);
                    finish();

                }

                @Override
                public void onAdLoaded(List<TaNativeInfo> adInfos) {
                    super.onAdLoaded(adInfos);
                }

                @Override
                public void onBiddingSuccess(BidInfo bidInfo) {
                    super.onBiddingSuccess(bidInfo);
                }

                @Override
                public void onBiddingFailed(TaErrorCode taErrorCode) {
                    super.onBiddingFailed(taErrorCode);
                }
            });

            mTSplashView.setSkipListener(new OnSkipListener() {
                @Override
                public void onClick(String packageName) {

                    String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.SPLASH_PV, "", "");
                    ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                    builder.setValue(value)
                            .setFrom("x_x_x_x")
                            .setTopicType(TRAnalyticsConstant.ADVERTISE)
                            .setButtonType(TRAnalyticsConstant.SKIP)
                            .setItemValue(packageName)
                            .setReportSource(HisavanaSdkManager.REPORT_SOURCE_EW)
                            .setAdPositionId(codeId)
                            .setExtraValue("");
                    TRAnalysticsUtil.trackClick(builder);
                    finish();
                }

                @Override
                public void onTimeEnd() {
                    finish();
                    String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.SPLASH_PV, "", "");
                    ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                    builder.setValue(value)
                            .setFrom("x_x_x_x")
                            .setTopicType(TRAnalyticsConstant.ADVERTISE)
                            .setButtonType(TRAnalyticsConstant.AUTO_TIMEOUT)
                            .setItemValue("")
                            .setReportSource(HisavanaSdkManager.REPORT_SOURCE_EW)
                            .setAdPositionId(codeId)
                            .setExtraValue("");
                    TRAnalysticsUtil.trackClick(builder);
                }
            });

            mTSplashView.getCacheAd();

            mAdsView = new AdvertiseView.Builder(this).build(AdsLoadProxy.TYPE_NORMAL, mPageParamInfo, TRAnalyticsConstant.HOME_A, false);
            FrameLayout layout = mAdsView.getAdContainerView();
            if (layout != null) {
                layout.removeAllViews();
                layout.addView(mTSplashView, lp);
            }
            mFrameLayout.removeAllViews();
            mFrameLayout.addView(mAdsView, lp);
            TRAnalysticsUtil.trackEwCacheReq(codeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_STATUS, 1, ProcessLifecycleChecker.isAppInBackground(), false);

        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    @Override
    public void finish() {
        super.finish();
        TRSplashActivateExecutor.STATUS = false;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.SPLASH_PV, "", "");
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(value)
                .setFrom("x_x_x_x")
                .setTopicType(TRAnalyticsConstant.ADVERTISE)
                .setButtonType(TRAnalyticsConstant.KEY_BACK)
                .setExtraValue("SplashActivity");
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mIsHisavanaSdkClicked) {
            mIsHisavanaSdkClicked = false;
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TRSplashActivateExecutor.STATUS = false;
        if(mAdsView != null) {
            mAdsView.onDestroy();
        }

        if (mTSplashView != null) {
            mTSplashView.destroy();
            mTSplashView = null;
        }

        TRNewManager.getCloseListener().onDialogClosed();
    }

    @Override
    public String getValue() {
        return "";
    }

    @Override
    public void showAdUi(boolean canShowSdkUi) {
        if(AdCache.getInstance().isNeedShowAd()) {
            showAdvertisement(true);
        } else {
            finish();
        }
    }

    @Override
    public void gotoHomePage() {
        finish();
    }

    @Override
    public void recordSdkClicked() {
        finish();
    }

}

package com.afmobi.palmplay.category.v6_3;

import android.view.View;

//viewHolder发送事件，通过监听器传送给fragment
public interface OnItemInteractionListener {
    void onButtonClicked(String buttonId , View view);
    void onUpdateMyStar(int myStar);
}

package com.afmobi.palmplay.activate.handler

import android.app.Activity
import android.content.DialogInterface
import android.content.DialogInterface.OnKeyListener
import android.content.DialogInterface.OnShowListener
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager

class TRPrivacyPolicyHandler (
    executor: TRBaseExecutor<*>?,
    sceneName: String,
    priority: TRPriority,
    popupType: TRPopupType
) : TRChainHandler(sceneName, priority, popupType) {
    private var mExecutor: TRBaseExecutor<*>? = executor
    var showListener: DialogInterface.OnShowListener? = null
    var keyListener: DialogInterface.OnKeyListener? = null

    override fun canShow(fromType: String?): Boolean {
        return TRNewManager.instance.canShow()
    }

    override fun showNext(fromType: String?): Boolean {
        if(AtyManager.getAtyManager().currentActivity != curActivity?.get()) {
            return false
        }
        if(!canShow(fromType)) {
            return  false
        }
        if(showListener == null || keyListener == null || mExecutor == null || curActivity?.get()== null) {
            return false
        }
        return mExecutor!!.show(fromType,curActivity?.get(), showListener, keyListener)

    }

    override fun show(
        fromType: String?,
        activity: Activity?,
        showListener: OnShowListener,
        keyListener: OnKeyListener
    ): Boolean {
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if(canShow(fromType)) {
            return mExecutor?.show(fromType,activity, showListener, keyListener)==true
        }
        return false
    }


}
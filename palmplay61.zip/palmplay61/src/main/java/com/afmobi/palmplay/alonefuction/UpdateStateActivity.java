package com.afmobi.palmplay.alonefuction;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import com.transsion.palmstorecore.util.ToastManager;

import androidx.databinding.DataBindingUtil;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.activate.TRUpdateVersionExecutor;
import com.afmobi.palmplay.base.BaseUpgradeActivity;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.transsion.calculator.NoNetworkTipExclude;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.main.utils.NotificationLayoutManager;
import com.afmobi.palmplay.main.utils.PSNotificationManager;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.network.AsyncHttpRequestUtils;
import com.afmobi.util.Constant;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.trans.common.netstate.AppNetState;
import com.trans.common.netstate.NetTypeKt;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.DialogUpdateStateBinding;

import java.io.File;

@NoNetworkTipExclude
public class UpdateStateActivity extends BaseUpgradeActivity {

    private DialogUpdateStateBinding mBinding;
    private SelfUpgradeReceiver mReceiver;
    private UpgradeCallback mCallBack;

    @Override
    protected void setupBinding() {
        TRUpdateVersionExecutor.SELF_UPDATE_DOWNLOADING = true;
        mBinding = DataBindingUtil.setContentView(this, R.layout.dialog_update_state);
        mBinding.tvCancel.setText(isForceUpdate ? getString(R.string.text_exit_app) : getString(R.string.text_cancel));
        mBinding.tvBackground.setVisibility(isForceUpdate ? View.GONE : View.VISIBLE);
        mBinding.tvBackground.setOnClickListener(this);
        mBinding.tvCancel.setOnClickListener(this);

        regiesterReceiver();
        putNetworkChangeListener();

    }

    @Override
    public void onClick(View v) {
        String upgradeFashion = mClientVersion == null ? "" : mClientVersion.upgradeFashion;
        String id = mClientVersion == null ? "" : mClientVersion.id;
        int versionCode = mClientVersion == null ? -100 : mClientVersion.versionCode;

        switch (v.getId()) {
            case R.id.tv_cancel:
                FirebaseAnalytics.getInstance(this.getApplicationContext()).logEvent(FirebaseConstants.EVENT_UPDATE_POPOFF_CLICK, null);
                if (isForceUpdate) {
                    TRAnalysticsUtil.trackSelfUpdateClick(8, mNewVerStr, upgradeFashion, id, versionCode);
                    finish();
                    AtyManager.getAtyManager().clear();
                } else {
                    // 取消下载
                    TRAnalysticsUtil.trackSelfUpdateClick(7, mNewVerStr, upgradeFashion, id, versionCode);
                    AsyncHttpRequestUtils.cancel(Constant.CLIENT_SELF_UPDATE_DOWLOAD);
                    finish();
                }
                break;

            case R.id.tv_background:
                TRAnalysticsUtil.trackSelfUpdateClick(6, mNewVerStr, upgradeFashion, id, versionCode);
                TRUpdateVersionExecutor.SELF_UPDATE_RUN_IN_BACKGROUND = true;
                //发送通知
                PSNotificationManager.checkCondition(() -> {
                    NotificationLayoutManager.INSTANCE.initNotification(getApplicationContext(), NotificationExtKt.getNOTIFY_ID_UPGRADE_PS()).notifyUpgrade(getApplicationContext());
                });
                finish();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateButtonStatus();
    }

    private void updateButtonStatus() {
        final ClientVersion clientVersion = PalmPlayVersionManager.getInstance().getNewClientVersionInfo();
        final String newVersionFilePath = FilePathManager.myselfNewVersionFilePath();
        File newVersionFile = new File(newVersionFilePath);
        if (!newVersionFile.exists()) {
            SPManager.remove(Constant.preferences_key_downloaded_version_code);
        }

        int versionCode = SPManager.getInt(Constant.preferences_key_downloaded_version_code, 0);

        if (null != clientVersion && clientVersion.versionCode == versionCode) {
            if (PalmPlayVersionManager.getInstance().isInstalling()) {
                mBinding.tvDownloadState.setText(R.string.text_installing);
            } else {
                mBinding.tvDownloadState.setText(R.string.text_install);
            }
        } else {
            // mBinding.tvDownloadState.setText(R.string.try_it_now);
        }
    }

    private void regiesterReceiver() {
        IntentFilter intentFilter = new IntentFilter(Constant.ACTION_UPDATE_PROGRESS);
        intentFilter.addAction(Constant.ACTION_UPDATE_FAILED);
        intentFilter.addAction(Constant.ACTION_UPDATE_SUCCESS);
        mCallBack = new UpgradeCallback() {
            @Override
            public void onUpgradeCallback(int percent, long downloadSize, long totalSize) {
                if (mBinding.progressbarUpgrade != null) {
                    mBinding.progressbarUpgrade.setProgress(percent);
                }
                if (mBinding.tvProgress != null) {
                    mBinding.tvProgress.setText(percent + "%");
                }
            }

            @Override
            public void onUpgradeFinished(boolean result) {
                if (result) {
                    if (PalmplayApplication.mHasSlientPermission) {
                        mBinding.tvDownloadState.setText(R.string.text_installing);
                    } else {
                        mBinding.tvDownloadState.setText(R.string.text_install);
                    }
                } else {
                    ToastManager.getInstance().showS(UpdateStateActivity.this, R.string.text_update_failed_status);
                }
            }
        };
        mReceiver = new SelfUpgradeReceiver(mCallBack);
        LocalBroadcastManager.getInstance(PalmplayApplication.getAppInstance()).registerReceiver(mReceiver, intentFilter);
    }

    static class SelfUpgradeReceiver extends BroadcastReceiver {
        private UpgradeCallback mCallback;
        private int onlinePercent = 0;
        private long onlineLastUpdateTime;

        public SelfUpgradeReceiver(UpgradeCallback callback) {
            mCallback = callback;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                String action = intent.getAction();
                if (TextUtils.equals(action, Constant.ACTION_UPDATE_PROGRESS)) {
                    long downloadSize = intent.getLongExtra("downloadSize", 0);
                    long totalSize = intent.getLongExtra("totalSize", 1);
                    int curPercent = (int) ((100 * downloadSize) / totalSize);
                    long curSysTime = System.currentTimeMillis();
                    if (curPercent > onlinePercent && curSysTime - onlineLastUpdateTime > 500) {
                        onlineLastUpdateTime = curSysTime;
                        if (mCallback != null) {
                            mCallback.onUpgradeCallback(curPercent, downloadSize, totalSize);
                        }
                    }
                    onlinePercent = curPercent;

                } else if (TextUtils.equals(action, Constant.ACTION_UPDATE_SUCCESS)) {
                    if (mCallback != null) {
                        mCallback.onUpgradeCallback(100, 100, 100);
                        mCallback.onUpgradeFinished(true);
                    }
                } else if (TextUtils.equals(action, Constant.ACTION_UPDATE_FAILED)) {
                    if (mCallback != null) {
                        mCallback.onUpgradeFinished(false);
                    }
                }
            }
        }
    }

    private void unregiesterReceiver() {
        if (mReceiver != null) {
            LocalBroadcastManager.getInstance(PalmplayApplication.getAppInstance()).unregisterReceiver(mReceiver);
        }
    }
    private void putNetworkChangeListener() {
        AppNetState.INSTANCE.getNetType().observe(this, netType -> {
            if (!NetTypeKt.connected(netType)) {
                ToastManager.getInstance().showS(UpdateStateActivity.this, R.string.tip_no_network);
            }
        });
    }

    /**
     * 此方法在 UpdateStateActivity 中不适用，可返回默认值
     * @return
     */
    @Override
    protected int getDefaultUpdateMessage() {
        return 0;
    }

    @Override
    protected boolean isForceUpdate() {
        return isForceUpdate;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && isForceUpdate) {
            finish();
            AtyManager.getAtyManager().clear();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        unregiesterReceiver();
        TRUpdateVersionExecutor.SELF_UPDATE_DOWNLOADING = false;
        super.onDestroy();
    }
    @Override
    public void finish() {
        super.finish();
        TRUpdateVersionExecutor.SELF_UPDATE_DOWNLOADING = false;

    }
}
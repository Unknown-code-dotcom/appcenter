// TOP SECRET
package com.afmobi.palmplay.appmanage;

import android.text.TextUtils;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.configs.HttpRequestTracer;
import com.afmobi.palmplay.download.DownloadHandler;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.HttpRequestTracerManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.service.dispatch.PalmstoreDownloadHandler;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.eventbus.IAction;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class ManageUtils {
	

	public static List<FileDownloadInfo> getDownloadUpdateData(){
		
		List<FileDownloadInfo> listUpdateData = new ArrayList<FileDownloadInfo>();
		
		Collection<InstalledAppInfo> listInstalledAppInfo = InstalledAppManager.getInstance().getPackages();
		if(listInstalledAppInfo==null || listInstalledAppInfo.size()==0){
			HttpRequestTracer installedPackageHttpRequestTracer = HttpRequestTracerManager.getInstance().get(IAction.Action_GetInstalledPackageList_task);
			if(installedPackageHttpRequestTracer==null || !installedPackageHttpRequestTracer.isRequesting()){
				DownloadHandler.getInstance().getHandler().sendEmptyMessage(PalmstoreDownloadHandler.MSG_GET_INSTALLED_APP);
			}
			return listUpdateData;
		} 
		
		List<FileDownloadInfo> listDownloading = DownloadManager.getInstance().getShadowDownloadingInfoList();
		List<FileDownloadInfo> listDownloaded = DownloadManager.getInstance().getShadowDownloadedInfoList();
		
		List<FileDownloadInfo> listDownloadAll = new ArrayList<FileDownloadInfo>();
		if(listDownloading!=null)
			listDownloadAll.addAll(listDownloading);
		if(listDownloaded!=null)
			listDownloadAll.addAll(listDownloaded);
		
		if(listDownloadAll.size() > 0){
			boolean isFind;
			for(FileDownloadInfo mFileDownloadInfo : listDownloadAll){
				isFind = false;
				if(mFileDownloadInfo==null || TextUtils.isEmpty(mFileDownloadInfo.packageName))
					continue;
				if (mFileDownloadInfo.extraInfo != null && mFileDownloadInfo.extraInfo.isVaGame) {
					List<FileDownloadInfo> vaList = PsVaManager.getInstance().getVaGameInstalledInfoList(false);
					Iterator it = vaList != null ? vaList.iterator() : null;
					while (it != null && it.hasNext()) {
						FileDownloadInfo mInstalledVaAppInfo = (FileDownloadInfo) it.next();
						if (mInstalledVaAppInfo != null && mFileDownloadInfo.packageName.equals(mInstalledVaAppInfo.packageName) && mFileDownloadInfo.version > mInstalledVaAppInfo.version) {
							isFind = true;
							break;
						}
					}
				} else {
					Iterator it = (listInstalledAppInfo != null) ? listInstalledAppInfo.iterator() : null;
					while (it != null && it.hasNext()) {
						InstalledAppInfo mInstalledAppInfo = (InstalledAppInfo) it.next();
						if (mInstalledAppInfo != null && mFileDownloadInfo.packageName.equals(mInstalledAppInfo.packageName) && mFileDownloadInfo.version > mInstalledAppInfo.versionCode) {
							isFind = true;
							break;
						}
					}
				}
				if(isFind)
					listUpdateData.add(mFileDownloadInfo);
			}
		} 
		
		return listUpdateData;
		
	}


	/**
	 * 获取下载完成的app类型数据, 并去除下载版本低于已安装版本的数据
	 */
	public static List<FileDownloadInfo> filterDownladedInstalledApp(){
		List<FileDownloadInfo> resultList = null;
		List<FileDownloadInfo> list = DownloadManager.getInstance().getShadowDownloadedInfoListWithType(DetailType.TYPE_APP);
		if(list!=null && list.size() > 0){
			Collection<InstalledAppInfo> listInstalledAppInfo = InstalledAppManager.getInstance().getPackages();
			if(listInstalledAppInfo==null || listInstalledAppInfo.size()==0){
				/*HttpRequestTracer installedPackageHttpRequestTracer = HttpRequestTracerManager.getInstance().get(IAction.Action_GetInstalledPackageList_task);
				if(installedPackageHttpRequestTracer==null || !installedPackageHttpRequestTracer.isRequesting()){
					DownloadHandler.getInstance().getHandler().sendEmptyMessage(DownloadService.MSG_GET_INSTALLED_APP);
				}*/
				return list;
			}

			resultList = new ArrayList<>();
			boolean isFind;
			for(FileDownloadInfo mFileDownloadInfo : list){
				if(mFileDownloadInfo!=null && DetailType.isApp(mFileDownloadInfo.type) && !TextUtils.isEmpty(mFileDownloadInfo.packageName)){
					isFind = false;
					for(InstalledAppInfo mInstalledAppInfo : listInstalledAppInfo){
						if(mInstalledAppInfo!=null && mFileDownloadInfo.packageName.equals(mInstalledAppInfo.packageName)){
							if(mInstalledAppInfo.versionCode >= mFileDownloadInfo.version){
								isFind = true;
								break;
							}
						}
					}

					if(!isFind){
						resultList.add(mFileDownloadInfo);
					}
				}
			}
		}

		return resultList;

	}

}

package com.afmobi.palmplay.activitycenter;


import androidx.lifecycle.MutableLiveData;

import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.viewmodel.BaseViewModel;
import com.androidnetworking.error.ANError;

import java.util.ArrayList;
import java.util.List;

public class TRActivityCenterViewModel extends BaseViewModel {

    private MutableLiveData<List<ACBean>> liveData = new MutableLiveData<>();
    private List<ACBean> mList = new ArrayList<>();
    final int pageMax = 5;

    public MutableLiveData<List<ACBean>> getLiveData() {
        return liveData;
    }

    private boolean isOnRefreshing = false;

    private boolean isRequesting = false;
    protected boolean hasRequest = false;
    private int pageIndex = 0;
    private boolean isPageLast;

    public boolean isPageLast() {
        return isPageLast;
    }

    public void setPageLast(boolean pageLast) {
        isPageLast = pageLast;
    }

    public void setOnRefreshing(boolean onRefreshing) {
        isOnRefreshing = onRefreshing;
    }

    public boolean isRequesting() {
        return isRequesting;
    }

    public void setRequesting(boolean requesting) {
        isRequesting = requesting;
    }

    public boolean isHasRequest() {
        return hasRequest;
    }

    public void setHasRequest(boolean hasRequest) {
        this.hasRequest = hasRequest;
    }

    public boolean isNotEmptyDataList() {
        return liveData.getValue() != null && liveData.getValue().size() > 0;
    }

    public boolean isOnRefreshing() {
        return isOnRefreshing;
    }

    public TRActivityCenterViewModel(AppDataManager manager) {
        super(manager);
    }

    public void loadAdData(boolean isLoadMore) {
        setRequesting(true);
        if (isLoadMore) {
            pageIndex++;
        } else {
            pageIndex = 0;
            mList.clear();
        }
        NetworkClient.requestActivityCenterListData(new AbsRequestListener<GenericResponseInfo<ActivityCenterBean>>() {
            @Override
            public void onResponse(GenericResponseInfo<ActivityCenterBean> response) {
                super.onResponse(response);
                if (response != null && response.isSuccess()) {

                    if(response.data!=null&&response.data.getActivityCenterList()!=null){
                        isPageLast = (response.data.getActivityCenterList().size() < pageMax);
                        mList.addAll(response.data.getActivityCenterList());
                    }
                    setRequesting(false);
                    setHasRequest(true);
                    liveData.setValue(mList);

                }
            }
            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                setRequesting(false);
                setHasRequest(true);
                liveData.setValue(null);
            }
        }, String.valueOf(pageIndex),String.valueOf(pageMax),"requestActivityCenterListData");
    }

    public void loadMore() {
        isOnRefreshing = false;
        loadAdData(true);
    }

    public void refresh() {
        isOnRefreshing = true;
        if (liveData.getValue() != null) {
            liveData.getValue().clear();
        }
        loadAdData(false);
    }

}


package com.afmobi.palmplay.appdetail;

import android.app.Activity;
import android.view.View;

import com.afmobi.palmplay.dialog.GdprDialog;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.util.CommonUtils;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;

public class GdprDialogInstance {

    private boolean gdprAgreed = false;
    private GdprDialog trPrivacyDialog;

    private static volatile GdprDialogInstance instance;

    public static GdprDialogInstance getInstance() {
        if (instance == null) { // 第一次检查
            synchronized (GdprDialogInstance.class) {
                if (instance == null) { // 第二次检查
                    instance = new GdprDialogInstance();
                }
            }
        }
        return instance;
    }

    public boolean isGdprAgreed() {
        return gdprAgreed;
    }

    public void gdprAppDetailHandle(Activity activity) {
        gdprAgreed = CommonUtils.isPrivacyPolicyHasAllowed();
        if(!gdprAgreed) {
            trPrivacyDialog = new GdprDialog(activity);
            trPrivacyDialog.show();

            trPrivacyDialog.setAgreeListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gdprAgreed = true;
                    TRAnalysticsUtil.trackPrivatePolicyClick(TRAnalyticsConstant.DETAIL_PAGE);
                    trPrivacyDialog.dismiss();
                    trPrivacyDialog = null;
                }
            });

            trPrivacyDialog.setCancelListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    trPrivacyDialog.dismiss();
                    trPrivacyDialog = null;
                    AtyManager.getAtyManager().clear();
                }
            });
        }
    }

}

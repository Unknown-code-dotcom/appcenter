package com.afmobi.palmplay.cloudfolder.recently

import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.recently.db.PalmInstalledAppEntity
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.launcherlib.config.Constants

object RecentlyInstalledHelper {

    private const val TAG = "RecentlyInstalled"

    /** 底栏展示候选窗口：仅查询最近 50 天内安装的应用 */
    private const val DISPLAY_WINDOW_MS = 50L * 24 * 60 * 60 * 1000

    /** 单次最多展示 4 个 */
    private const val MAX_DISPLAY_COUNT = 4


    data class Result(
        val shownList: List<CloudAppInfo>,    // 最终展示（最多 4）
        val unactivatedTotal: Int             // 通过校验的未激活总数（可能 >4，报表 1 用）
    ) {
        companion object {
            val EMPTY = Result(emptyList(), 0)
        }
    }

    /**
     * 拉活入口：组装最近安装列表 + 自动上报展示埋点（空列表不上报）。
     * 调用方只需关心 result.shownList 用于 UI 渲染。
     */
    fun queryAndReportShow(context: Context, categoryType: Int): Result {
        val result = getPalmInstalledApps(context, categoryType)
        if (result.shownList.isNotEmpty()) {
            // 业务展示事件
            RecentlyInstalledTracker.reportShow(
                shownList = result.shownList,
                unactivatedTotal = result.unactivatedTotal,
                categoryType = categoryType
            )
        }
        return result
    }

    fun getPalmInstalledApps(context: Context, categoryType: Int = 0): Result {
        val startTs = System.currentTimeMillis()
        val now = startTs
        val displaySince = now - DISPLAY_WINDOW_MS
        val pm = context.packageManager
        LogUtils.i(TAG, "【最近安装】>>> 开始组装 当前时间=$now 展示窗口起点(50天前)=$displaySince ")

        // 1. 从新数据库读取候选
        val dbApps: List<PalmInstalledAppEntity> =
            PalmInstalledDBManager.queryRecentInstalledApps(displaySince)
        if (dbApps.isEmpty()) {
            LogUtils.d(TAG, "【最近安装】新表无候选 -> 返回空，云文件夹底栏维持原CDN样式")
            return Result.EMPTY
        }

        // 2. UsageStats Map
        val usageStatsMap = queryUsageStats(context, displaySince, now)
        LogUtils.d(TAG, "【最近安装】系统UsageStats最近30天有使用记录的应用数=${usageStatsMap.size}")

        // 3. 校验候选逐个检查 PackageManager（dbApps 通常个位数，逐个查远轻于全量 getInstalledPackages）
        val verified = ArrayList<CloudAppInfo>(dbApps.size)
        var filterUninstalled = 0
        var filterOpened = 0
        var filterNoLaunchIntent = 0
        for (dbApp in dbApps) {
            val pkg = dbApp.packageName
            if (!isPkgInstalled(pm, pkg)) {
                filterUninstalled++
                if (LogUtils.debug) {
                    LogUtils.d(TAG, "【最近安装·剔除】pkg=$pkg 原因=已卸载 安装时间=${dbApp.installedTime}")
                }
                // 已卸载的应用永远不会回到展示池，DB 自清理 + 技术埋点上报
                PalmInstalledDBManager.deleteByPackageAndReport(pkg, RecentlyInstalledTracker.REASON_UNINSTALLED)
                continue
            }
            val stats = usageStatsMap[pkg]
            if (stats != null && stats.lastTimeUsed >= dbApp.installedTime) {
                filterOpened++
                if (LogUtils.debug) {
                    LogUtils.d(TAG, "【最近安装·剔除】pkg=$pkg 原因=已打开过(本次安装后) 最后使用时间=${stats.lastTimeUsed} 安装时间=${dbApp.installedTime}")
                }
                // 已激活的应用不再是拉活目标
                PalmInstalledDBManager.deleteByPackageAndReport(pkg, RecentlyInstalledTracker.REASON_OPENED)
                continue
            }
            val launchIntent = try {
                pm.getLaunchIntentForPackage(pkg)
            } catch (e: Exception) {
                LogUtils.e(TAG, e)
                null
            }
            if (launchIntent == null) {
                // 无启动入口的应用也没法拉活，剔除
                filterNoLaunchIntent++
                if (LogUtils.debug) {
                    LogUtils.d(TAG, "【最近安装·剔除】pkg=$pkg 原因=无launchIntent，无法启动")
                }
                PalmInstalledDBManager.deleteByPackageAndReport(pkg, RecentlyInstalledTracker.REASON_NO_LAUNCH_INTENT)
                continue
            }
            verified.add(CloudAppInfo().apply {
                packageName = pkg
                name = dbApp.name
                iconUrl = dbApp.iconUrl
                versionCode = dbApp.versionCode
                versionName = dbApp.versionName
                jumpType = Constants.JUMP_TYPE_RECENTLY_INSTALLED
                observerStatus = FileDownloadInfo.STATUS_APP_INSTALLED
                installedTime = dbApp.installedTime
                installFromPage = dbApp.fromPage
                this.launchIntent = launchIntent
            })
            if (LogUtils.debug) {
                LogUtils.d(TAG, "【最近安装·保留】pkg=$pkg name=${dbApp.name} 安装时间=${dbApp.installedTime} 最后使用时间=${stats?.lastTimeUsed ?: "<无记录>"}")
            }
        }

        // 5. 按 installedTime 倒序 + 截前 4
        verified.sortByDescending { it.installedTime }
        val unactivatedTotal = verified.size  // 校验通过、未截断的总数（报表 1 用）
        val finalList = if (verified.size > MAX_DISPLAY_COUNT) {
            ArrayList(verified.subList(0, MAX_DISPLAY_COUNT))
        } else {
            verified
        }
        val cost = System.currentTimeMillis() - startTs
        if (LogUtils.debug) {
            LogUtils.d(
                TAG,
                "【最近安装】<<< 组装完成：新表候选=${dbApps.size} 剔除(已卸载)=$filterUninstalled 剔除(已打开)=$filterOpened 剔除(无launchIntent)=$filterNoLaunchIntent 通过校验(未激活总数)=$unactivatedTotal 最终展示=${finalList.size} 包名=${finalList.map { it.packageName }} 耗时=${cost}ms"
            )
        }
        return Result(shownList = finalList, unactivatedTotal = unactivatedTotal)
    }

    private fun isPkgInstalled(pm: PackageManager, pkg: String): Boolean {
        return try {
            pm.getPackageInfo(pkg, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun queryUsageStats(
        context: Context,
        since: Long,
        now: Long
    ): Map<String, UsageStats> {
        val usm = try {
            context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        } catch (e: Exception) {
            LogUtils.e(TAG, e)
            null
        } ?: return emptyMap()

        // 不同机型/OEM 把使用数据写入不同粒度的 bucket，
        // 遍历所有 interval，取每个包的 lastTimeUsed 最大值，保证跨机型兼容。
        val intervals = intArrayOf(
            UsageStatsManager.INTERVAL_DAILY,
            UsageStatsManager.INTERVAL_WEEKLY,
            UsageStatsManager.INTERVAL_MONTHLY,
            UsageStatsManager.INTERVAL_YEARLY,
            UsageStatsManager.INTERVAL_BEST
        )
        val map = HashMap<String, UsageStats>()
        var totalEntries = 0
        for (interval in intervals) {
            try {
                val list = usm.queryUsageStats(interval, since, now)
                if (list.isNullOrEmpty()) continue
                totalEntries += list.size
                for (s in list) {
                    val pkg = s.packageName ?: continue
                    val exist = map[pkg]
                    if (exist == null || s.lastTimeUsed > exist.lastTimeUsed) {
                        map[pkg] = s
                    }
                }
                if (LogUtils.debug) {
                    LogUtils.d(TAG, "【最近打开】UsageStats interval=$interval size=${list.size}")
                }
            } catch (e: Exception) {
                LogUtils.e(TAG, e)
            }
        }
        if (LogUtils.debug) {
            LogUtils.d(TAG, "【最近打开】UsageStats 合并完成：总条目=$totalEntries 去重后=${map.size}")
        }
        return map
    }

    @Suppress("unused")
    private fun isOpenedSince(
        usageStatsMap: Map<String, UsageStats>,
        pkgName: String,
        installedTime: Long
    ): Boolean {
        val stats = usageStatsMap[pkgName] ?: return false
        return stats.lastTimeUsed >= installedTime
    }
}

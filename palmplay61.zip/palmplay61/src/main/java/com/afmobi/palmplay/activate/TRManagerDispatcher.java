package com.afmobi.palmplay.activate;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;

import com.afmobi.apk.ThreadHelper;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.ProcessLifecycleChecker;
import com.afmobi.palmplay.activitycenter.ACBean;
import com.afmobi.palmplay.category.CategoryActivity;
import com.afmobi.palmplay.find.FindDetailActivity;
import com.afmobi.palmplay.find.FindListActivity;
import com.afmobi.palmplay.giftscenter.bean.GiftsCardBean;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.home.model.FeatureBannerData;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.ShortBannerData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.MiniAppManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.BannerDTO;
import com.afmobi.palmplay.model.DetailShortBannerData;
import com.afmobi.palmplay.model.FeatureBuilder;
import com.afmobi.palmplay.model.HotWordFeatureData;
import com.afmobi.palmplay.model.NavTabInfo;
import com.afmobi.palmplay.model.RaceLamp;
import com.afmobi.palmplay.model.TRGuideEntry;
import com.afmobi.palmplay.model.ToolbarConfigData;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.afmobi.palmplay.model.keeptojosn.ToolInfo;
import com.afmobi.palmplay.model.v6_0.TagItem;
import com.afmobi.palmplay.model.v6_3.BannerModel;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.RankDataModel;
import com.afmobi.palmplay.model.v6_5.MarketEventInfo;
import com.afmobi.palmplay.model.v7_x.ActivityInfo;
import com.afmobi.palmplay.pet.manager.XMPetManager;
import com.afmobi.palmplay.language.LanguageSelectActivity;
import com.transsion.palmstorecore.api.pet.XMPetFrom;
import com.afmobi.palmplay.rank.FeatureSinglePageActivity;
import com.afmobi.palmplay.smallpkg.SmallPackageActivity;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.TRJumpUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.apm.source.PSLaunchUtil;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.SystemUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.xwebview.activity.TrWebViewActivity;
import com.transsnet.store.BuildConfig;

import de.greenrobot.event.EventBus;


/***
 * created by yongli.li
 * manager不好直接处理的让此执行者代劳
 */
public class TRManagerDispatcher {

    public TRManagerDispatcher() {
        new Handler().postDelayed(() -> ThreadHelper.runOnWorkThread(() -> {
            // startJob中的schedule方法是Binder 调用，可能阻塞，此处优化为异步调用
            TRDataJobService.startJob(PalmplayApplication.getAppInstance());
        }), 2000);//延迟2秒启动
    }

    /***
     * 事件分发
     * @param type
     * @param o
     */
    public void dispatchEvent(String type, Object o) {
        TRActivateEntry entry = null;
        switch (type) {
            case TRActivateConstant.NAV_BAR_ACTIVATE:
                ActivityInfo info = (ActivityInfo)o;
                entry = new TRActivateEntry(info.jumpUrl, info.jumpType, info.jumpExt, info.pck,
                        info.versionCode, info.curPage, info.lastPage,
                        info.fromPage, null, info.value, info.taskId);
                entry.nativeId = info.nativeId;
                entry.type = type;
                break;
            case TRActivateConstant.TIP_ACTIVATE:
                MarketEventInfo marketEventInfo = (MarketEventInfo)o;
                entry = new TRActivateEntry(marketEventInfo.jumpUrl, marketEventInfo.jumpType, marketEventInfo.jumpExt,
                        marketEventInfo.pck, marketEventInfo.versionCode,
                        marketEventInfo.curPage, marketEventInfo.lastPage,
                        marketEventInfo.fromPage, marketEventInfo.targetPosition, marketEventInfo.value, marketEventInfo.taskId);
                entry.isAutoDownload = marketEventInfo.isAutoDownload();
                entry.nativeId = marketEventInfo.nativeId;
                entry.type = type;
                break;
            case TRActivateConstant.SPLASH_AD:
                OwnAdBean ownAdBean = (OwnAdBean)o;
                entry = new TRActivateEntry(ownAdBean.getJumpUrl(), ownAdBean.getJumpType(), ownAdBean.getJumpExt(),
                        ownAdBean.getPck(), ownAdBean.getVersionCode(),
                        ownAdBean.getCurPage(), ownAdBean.getLastPage(),
                        ownAdBean.getFromPage(), null, ownAdBean.getValue(), ownAdBean.getTaskId());
                entry.cfgId = ownAdBean.cfgId;
                entry.reportSource = ownAdBean.reportSource;
                entry.isAutoDownload = ownAdBean.isAutoDownload();
                entry.type = type;
                entry.nativeId = ownAdBean.nativeId;
                if(ownAdBean.isFromStartup()) {//启动页过来的单独处理
                    jumpActivateByAd(entry);
                    return;
                }
                break;
            case TRActivateConstant.HOME_BANNER:
                BannerModel bannerModel = (BannerModel)o;
                if (bannerModel.jumpDto != null) {
                    entry = new TRActivateEntry(bannerModel.jumpDto.jumpUrl, bannerModel.jumpDto.jumpType, bannerModel.jumpDto.jumpExt,
                            bannerModel.jumpDto.pck, bannerModel.jumpDto.versionCode,
                            bannerModel.curPage, bannerModel.lastPage,
                            TextUtils.isEmpty(bannerModel.fromPage) ? TRActivateConstant.HOME_BANNER : bannerModel.fromPage,
                            null, bannerModel.value, bannerModel.reportDto == null ? 0 : bannerModel.reportDto.taskId);
                    String nativeId = bannerModel.nativeId;
                    if(TextUtils.isEmpty(nativeId)) {
                        if(bannerModel.taNativeInfo!=null) {
                            nativeId = bannerModel.taNativeInfo.getNativeAdId();
                        } else {
                            nativeId = CommonUtils.generateSerialNum();
                        }
                    }
                    entry.setNativeId(nativeId);


                    if (bannerModel.reportDto != null) {
                        entry.reportSource = bannerModel.getReportSource();
                        entry.cfgId = bannerModel.getCfgId();
                    }
                }
                break;
            case TRActivateConstant.TOOL_SUDOKU:
                ToolInfo toolInfo = (ToolInfo) o;
                LogUtils.d(LogUtils.TAG_NETWORK, toolInfo.toString());

                if (toolInfo.getH5JumpDto()!= null && !TextUtils.isEmpty(toolInfo.getH5JumpDto().gameId)) {  //gameId不为空，说明是H5游戏类型的跳转
                    entry = new TRActivateEntry(TRActivateConstant.H5_GAME,toolInfo.getH5JumpDto().gameId, toolInfo.getH5JumpDto().openUrl,toolInfo.getH5JumpDto().name,toolInfo.getH5JumpDto().iconUrl);
                    //LogUtils.d(LogUtils.TAG_NETWORK, "toolInfo.getH5JumpDto() != null");
                }else{  //是其他类型的跳转
                    entry = new TRActivateEntry(toolInfo.getJumpDto().jumpUrl, toolInfo.getJumpDto().jumpType, toolInfo.getJumpDto().jumpExt,
                            toolInfo.getJumpDto().pck, toolInfo.getJumpDto().versionCode,
                            "", "","",
                            null, "", 0);
                }
                break;
            // 新增：推文横滑大卡跳转处理（参考：其他跳转类型的处理方式，如HOME_BIG_ICON_BANNER）
            case TRActivateConstant.HOME_BANNER_TITLE:
                com.afmobi.palmplay.home.model.FeatureBannerTitleData bannerTitleData = (com.afmobi.palmplay.home.model.FeatureBannerTitleData)o;
                if (bannerTitleData.jumpDto != null) {
                    entry = new TRActivateEntry(bannerTitleData.jumpDto.jumpUrl, bannerTitleData.jumpDto.jumpType, bannerTitleData.jumpDto.jumpExt,
                            bannerTitleData.jumpDto.pck, bannerTitleData.jumpDto.versionCode,
                            bannerTitleData.curPage, bannerTitleData.lastPage,
                            TextUtils.isEmpty(bannerTitleData.fromPage) ? TRActivateConstant.HOME_BANNER_TITLE : bannerTitleData.fromPage,
                            null, bannerTitleData.value, bannerTitleData.reportDto == null ? 0 : bannerTitleData.reportDto.taskId);
                    entry.setNativeId(CommonUtils.generateSerialNum());

                    if (bannerTitleData.reportDto != null) {
                        entry.reportSource = bannerTitleData.getReportSource();
                        entry.cfgId = bannerTitleData.getCfgId();
                    }
                }
                break;
            case TRActivateConstant.RACE_LAMP:
                RaceLamp raceLamp = (RaceLamp)o;
                if (raceLamp.jumpDto != null) {
                    entry = new TRActivateEntry(raceLamp.jumpDto.jumpUrl, raceLamp.jumpDto.jumpType, raceLamp.jumpDto.jumpExt,
                            raceLamp.jumpDto.pck, raceLamp.jumpDto.versionCode,
                            raceLamp.curPage, raceLamp.lastPage, raceLamp.fromPage,
                            null, raceLamp.value, raceLamp.reportDto == null ? 0 : raceLamp.reportDto.taskId);
                }
                break;
            case TRActivateConstant.HOME_ICON:
                TRGuideEntry trGuideEntry = (TRGuideEntry)o;
                if (trGuideEntry.jumpDto != null) {
                    entry = new TRActivateEntry(trGuideEntry.jumpDto.jumpUrl, trGuideEntry.jumpDto.jumpType, trGuideEntry.jumpDto.jumpExt,
                            trGuideEntry.jumpDto.pck, trGuideEntry.jumpDto.versionCode,
                            trGuideEntry.curPage, trGuideEntry.lastPage,
                            trGuideEntry.fromPage, String.valueOf(trGuideEntry.position), trGuideEntry.value,
                            trGuideEntry.reportDto == null ? 0 : trGuideEntry.reportDto.taskId);
                    entry.setAssetCount(trGuideEntry.jumpDto.assetCount);
                }
                break;
            case TRActivateConstant.HOME_LIST_BANNER:
                RankDataModel rankDataModel = (RankDataModel)o;
                entry = new TRActivateEntry(rankDataModel.jumpUrl, rankDataModel.jumpType, rankDataModel.jumpExt,
                        rankDataModel.pck, rankDataModel.versionCode,
                        rankDataModel.curPage, rankDataModel.lastPage,
                        rankDataModel.fromPage, null, rankDataModel.value, rankDataModel.taskId);
                break;
            case TRActivateConstant.HOME_LIST_BANNER_NEW:
                FeatureBean featureBean = (FeatureBean)o;
                if(featureBean.dataList != null && featureBean.dataList.size() > 0){
                    FeatureBannerData featureItemData = (FeatureBannerData) featureBean.dataList.get(0);
                    if(featureItemData.jumpDto != null){
                        entry = new TRActivateEntry(featureItemData.jumpDto.jumpUrl, featureItemData.jumpDto.jumpType, featureItemData.jumpDto.jumpExt,
                                "", "",
                                featureItemData.curPage, featureItemData.lastPage,
                                featureItemData.fromPage, null, featureItemData.value, featureItemData.getTaskId());
                        entry.nativeId = featureBean.featureId;
                    }
                }

                break;
            case TRActivateConstant.HOME_SHORT_BANNER:
                try {
                    FeatureBean featureBeanShort = (FeatureBean)o;
                    if(featureBeanShort.dataList != null && featureBeanShort.dataList.size() > 0){
                        ShortBannerData featureItemData = (ShortBannerData) featureBeanShort.dataList.get(0);
                        if(featureItemData.h5JumpDto!= null && featureItemData.h5JumpDto.gameId!= null){
                            entry = new TRActivateEntry(TRActivateConstant.H5_GAME,featureItemData.h5JumpDto.gameId , featureItemData.h5JumpDto.openUrl ,featureItemData.h5JumpDto.name ,featureItemData.h5JumpDto.iconUrl);
                        }else{
                            entry = new TRActivateEntry(featureItemData.jumpDto.jumpUrl, featureItemData.jumpDto.jumpType, featureItemData.jumpDto.jumpExt,
                                    "", "",
                                    featureItemData.curPage, featureItemData.lastPage,
                                    featureItemData.fromPage, null, featureItemData.value, featureItemData.getTaskId());
                            entry.nativeId = featureBeanShort.featureId;
                        }
                        LogUtils.d(LogUtils.TAG_NETWORK, featureItemData.jumpDto.toString());
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }

                break;
            case TRActivateConstant.DETAIL_SHORT_BANNER:
                DetailShortBannerData shortBannerData = (DetailShortBannerData)o;
                if(shortBannerData.jumpDto != null){
                    entry = new TRActivateEntry(shortBannerData.jumpDto.jumpUrl, shortBannerData.jumpDto.jumpType, shortBannerData.jumpDto.jumpExt,
                            shortBannerData.jumpDto.pck, shortBannerData.jumpDto.versionCode,
                            shortBannerData.curPage, shortBannerData.lastPage,
                            shortBannerData.fromPage, null, shortBannerData.value, shortBannerData.getTaskId());
                }

                break;
            case TRActivateConstant.HOME_ITEM:
                FeatureItemData featureItem = (FeatureItemData)o;
                if(featureItem.jumpDto != null){
                    entry = new TRActivateEntry(featureItem.jumpDto.jumpUrl, featureItem.jumpDto.jumpType, featureItem.jumpDto.jumpExt,
                            featureItem.jumpDto.pck, featureItem.jumpDto.versionCode,
                            featureItem.curPage, featureItem.lastPage,
                            featureItem.fromPage, null, featureItem.value, featureItem.getTaskId());
                }
                break;

            case TRActivateConstant.HOME_BIG_ICON_BANNER:
                FeatureItemData featureItemData = (FeatureItemData)o;
                if(featureItemData.jumpDto != null){
                    entry = new TRActivateEntry(featureItemData.jumpDto.jumpUrl, featureItemData.jumpDto.jumpType, featureItemData.jumpDto.jumpExt,
                            "", "",
                            featureItemData.curPage, featureItemData.lastPage,
                            featureItemData.fromPage, null, featureItemData.value, featureItemData.getTaskId());
                }
                break;

            case TRActivateConstant.SEARCH_TAG:

                HotWordFeatureData tagItem = (HotWordFeatureData) o;
                if(TagItem.TERM_TYPE_RANK == tagItem.getTermType()){

                    entry = new TRActivateEntry(tagItem.rankId, TRActivateConstant.RANK, "", "", "", tagItem.curPage, tagItem.lastPage, tagItem.fromPage,
                            "", tagItem.value, 0);

                } else if (TagItem.TERM_TYPE_CATEGORY == tagItem.getTermType()){
                    String jumpType = "";
                    if (Constant.SOFTTYPE_APP.equalsIgnoreCase(tagItem.category2)){
                        jumpType = TRActivateConstant.APP_CATEGORY;
                    } else {
                        jumpType = TRActivateConstant.GAME_CATEGORY;
                    }
                    entry = new TRActivateEntry(tagItem.category3, jumpType, "", "", "", tagItem.curPage, tagItem.lastPage, tagItem.fromPage,
                            "", tagItem.value, 0);

                }
                break;
            case TRActivateConstant.PUSH://push得实体已经转换好，所以可以直接跳转。无需转换实体
                TRActivateEntry activateEntry = (TRActivateEntry)o;
                activateEntry.type = type;
                return;
            case TRActivateConstant.GP_LINK:
                FeatureBaseData featureBaseData = (FeatureBaseData)o;
                TRJumpUtil.jumpActivateToGp(featureBaseData.getJumpUrl());
                break;

            case TRActivateConstant.SEARCH_BANNER:
                BannerDTO bannerDTO = (BannerDTO)o;
                if (bannerDTO.jumpDto != null) {
                    String pck = bannerDTO.jumpDto.pck;
                    String versionCode = bannerDTO.jumpDto.versionCode;
                    if(!TextUtils.equals(bannerDTO.bannerStyle, BannerDTO.BANNER_COMMON) && bannerDTO.data != null) {
                        pck = bannerDTO.data.packageName;
                        versionCode = String.valueOf(bannerDTO.data.versionCode);
                    }
                    entry = new TRActivateEntry(bannerDTO.jumpDto.jumpUrl, bannerDTO.jumpDto.jumpType, bannerDTO.jumpDto.jumpExt,
                            pck, versionCode,
                            bannerDTO.curPage, bannerDTO.lastPage,
                            bannerDTO.fromPage, null, bannerDTO.value, bannerDTO.reportDto == null ? 0 : bannerDTO.reportDto.taskId);
                    entry.setNativeId(bannerDTO.nativeId);
                }
                break;
            case TRActivateConstant.TOOLBAR_ICON:
                ToolbarConfigData configData = (ToolbarConfigData) o;
                if(configData != null && configData.jumpDto != null){
                    entry = new TRActivateEntry(configData.jumpDto.jumpUrl, configData.jumpDto.jumpType, configData.jumpDto.jumpExt,
                            configData.jumpDto.pck, configData.jumpDto.versionCode, "","", TRAnalyticsConstant.NOTICE_BOARD, null, configData.value, 0);
                }
                break;

            case TRActivateConstant.TOOLS:
                Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                Intent mainIntent = new Intent(PalmplayApplication.getAppInstance(), MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (null != mainActivity) {
                    EventMainThreadEntity entity = new EventMainThreadEntity();
                    entity.setAction(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION);
                    entity.put(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION, NavTabInfo.TOOLS_KEY);
                    EventBus.getDefault().postSticky(entity);
                } else {
                    mainIntent.putExtra(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION, NavTabInfo.TOOLS_KEY);
                }
                try {
                    PalmplayApplication.getAppInstance().startActivity(mainIntent);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                return;

            case TRActivateConstant.ACTIVITY_CENTER_TAB:
                if(o instanceof  ACBean){
                    ACBean acBean = (ACBean) o;
                    if(acBean.getJumpDto() != null){
                        entry = new TRActivateEntry(acBean.getJumpDto().jumpUrl, acBean.getJumpDto().jumpType, acBean.getJumpDto().jumpExt,
                                acBean.getJumpDto().pck, acBean.getJumpDto().versionCode, acBean.getmCurPage(),acBean.getmLastPage(),
                                PageConstants.Activity_Center, null, acBean.getmValue(), 0);
                    }
                }
                break;
            case TRActivateConstant.GIFTS_CENTER_TAB:
                if(o instanceof  GiftsCardBean.WelfareCardBean){
                    GiftsCardBean.WelfareCardBean acBean = (GiftsCardBean.WelfareCardBean) o;
                    if(acBean.jumpDto!= null){
                        entry = new TRActivateEntry(acBean.jumpDto.jumpUrl, acBean.jumpDto.jumpType, acBean.jumpDto.jumpExt,
                                acBean.jumpDto.pck, acBean.jumpDto.versionCode, acBean.mCurPage,acBean.mLastPage,
                                PageConstants.Gifts_Center, null, acBean.mValue, 0);
                    }
                }
                break;
            default:
                break;
        }
        jumpActivate(entry);
    }

    /**
     * 处理启动页过来的广告点击（解决主页面遮挡广告跳转页面问题）
     * */
    private void jumpActivateByAd(TRActivateEntry activateEntry) {

        if (activateEntry == null || TRStringUtil.isBlank(activateEntry.jumpType)) {
            return;
        }

        Intent intent = null;

        switch (activateEntry.jumpType) {
            case TRActivateConstant.ITEM:
                intent = TRJumpUtil.getDetailIntent(PalmplayApplication.getAppInstance());
                if(intent != null) {
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                AppBuilder appBuilder = new AppBuilder()
                        .setAppName("")
                        .setItemId(activateEntry.jumpUrl)
                        .setPackageName(activateEntry.pck)
                        .setFromPage(activateEntry.fromPage)
                        .setLastPage(activateEntry.lastPage)
                        .setUri(null)
                        .setValue(activateEntry.value)
                        .setTaskId(activateEntry.taskId)
                        .setAutoDownload(activateEntry.isAutoDownload)
                        .setReportSource(activateEntry.reportSource)
                        .setNativeId(activateEntry.nativeId)
                        .setCfgId(activateEntry.cfgId)
                        .setType(activateEntry.type);
                TRJumpUtil.putAppDetailParams(intent, appBuilder);
                break;

            case TRActivateConstant.OUTER_URL:
                intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(activateEntry.jumpUrl));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;

            case TRActivateConstant.INNER_URL:
                intent = new Intent(PalmplayApplication.getAppInstance(), TrWebViewActivity.class);
                intent.putExtra(TrWebViewActivity.KEY_WEB_SITE, activateEntry.jumpUrl);
                intent.putExtra(TRAnalyticsConstant.TYPE, activateEntry.jumpType);
                intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, activateEntry.lastPage);
                intent.putExtra(PageConstants.PAGE_KEY_CURPAGE, activateEntry.curPage);
                intent.putExtra(TrWebViewActivity.KEY_FROM, activateEntry.fromPage);
                TrWebViewActivity.appendScreenOrientationExtra(intent, PalmplayApplication.getAppInstance());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ProcessLifecycleChecker.XWebViewForeground = true;
                break;

            case TRActivateConstant.DEEP_LINK:

                String url ="";
                try {
                    if (SystemUtils.checkApkInstalled(PalmplayApplication.getAppInstance(), activateEntry.pck, Integer.valueOf(activateEntry.versionCode))) {
                        //如果没安装使用h5
                        url = activateEntry.jumpUrl;
                    } else { //反之使用deeplink
                        url = activateEntry.jumpExt;
                    }
                } catch (Exception e) {
                    url = activateEntry.jumpExt;
                }
                if (TRStringUtil.isBlank(url)) {//如果最终都为空，则不做处理，兜底逻辑
                    return;
                }

                Uri uri = Uri.parse(url);
                intent = new Intent();
                intent.setData(uri);
                intent.setAction(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;

            case TRActivateConstant.RANK:
                FeatureBuilder featurebuilder = new FeatureBuilder()
                        .setDetailType(activateEntry.jumpType)
                        .setName("")
                        .setRankID(activateEntry.jumpUrl)
                        .setFromPage( activateEntry.fromPage)
                        .setLastPage(activateEntry.curPage)
                        .setValue(activateEntry.value);
                FeatureSinglePageActivity.switchToFeatureSinglePageActivity(PalmplayApplication.getAppInstance(), featurebuilder);
                break;
            case TRActivateConstant.LIST:
                // 跳转到推荐合集页
                if (activateEntry.jumpUrl != null && activateEntry.jumpUrl.startsWith(TRActivateConstant.REC_COLLECTION)) {
                    String tabId = activateEntry.jumpExt;
                    TRJumpUtil.jumpToRecommendCollectionActivity(tabId, activateEntry.fromPage, "0");
                } else {
                    TRJumpUtil.jumpActivateToList(activateEntry.jumpUrl, activateEntry.pushType);
                }
                break;
            case TRActivateConstant.APP_CATEGORY:
            case TRActivateConstant.GAME_CATEGORY:
                String categoryType;
                if (TRActivateConstant.APP_CATEGORY.equalsIgnoreCase(activateEntry.jumpType)) {
                    categoryType = Constant.SOFTTYPE_APP;
                } else {
                    categoryType = Constant.SOFTTYPE_GAME;
                }

                Bundle bundle = new Bundle();
                bundle.putString(CategoryActivity.KEY_CATEGORY_TYPE, categoryType);
                bundle.putSerializable(CategoryActivity.KEY_CATEGORY_ID, activateEntry.jumpUrl);
                bundle.putSerializable(CategoryActivity.KEY_CATEGORY_NAME, "");
                bundle.putString(PageConstants.PAGE_KEY_LASTPAGE, activateEntry.lastPage);
                bundle.putString(TRAnalyticsConstant.VALUE, activateEntry.value);

                intent = new Intent(PalmplayApplication.getAppInstance(), CategoryActivity.class);
                intent.putExtras(bundle);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;

            case TRActivateConstant.GAME_HALL:
                Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                if (null == mainActivity) {
                    Intent mainIntent = new Intent(PalmplayApplication.getAppInstance(), MainActivity.class);
                    mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    PalmplayApplication.getAppInstance().startActivity(mainIntent);
                }
                TRJumpUtil.jumpActivateToGameHall(TRActivateConstant.GAME_HALL, "");
                break;
            case TRActivateConstant.FIND_DETAIL:
                intent = new Intent(PalmplayApplication.getAppInstance(), FindDetailActivity.class);
                intent.putExtra(FindDetailActivity.PARAM_FIND_ID, activateEntry.jumpUrl);
                intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, activateEntry.jumpExt);
                intent.putExtra(TRAnalyticsConstant.VALUE, activateEntry.value);
                intent.putExtra(Constant.KEY_FROM_PAGE, activateEntry.fromPage);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;
            case TRActivateConstant.FIND:
                intent = new Intent(PalmplayApplication.getAppInstance(), FindListActivity.class);
                intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, "null");
                intent.putExtra(PageConstants.PAGE_KEY_CURPAGE, activateEntry.curPage);
                intent.putExtra(TRAnalyticsConstant.VALUE,activateEntry.value);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;
            default:
                break;
        }

        if(intent != null) {
            try {
                Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                if (null != mainActivity) {
                    PalmplayApplication.getAppInstance().startActivity(intent);
                } else {
                    Intent firstIntent = new Intent(PalmplayApplication.getAppInstance(), MainActivity.class);
                    firstIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    PalmplayApplication.getAppInstance().startActivities(new Intent[]{firstIntent, intent});
                }
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
    }

    /***
     * 根据跳转类型开始真正跳转
     * @param activateEntry
     */
    private void jumpActivate(TRActivateEntry activateEntry) {
        if (activateEntry == null || TRStringUtil.isBlank(activateEntry.jumpType)) {
            LogUtils.d(LogUtils.TAG_APM,"jumpActivate----1----"+"activateEntry == null || TRStringUtil.isBlank(activateEntry.jumpType)");
            return;
        }
        LogUtils.d(LogUtils.TAG_NETWORK,"jumpActivate----2----"+activateEntry.toString());
        switch (activateEntry.jumpType) {
            case TRActivateConstant.ITEM:
                AppBuilder appBuilder = new AppBuilder()
                        .setAppName("")
                        .setPackageName(activateEntry.pck)
                        .setItemId(activateEntry.jumpUrl)
                        .setFromPage(activateEntry.fromPage)
                        .setLastPage(activateEntry.lastPage)
                        .setUri(null)
                        .setValue(activateEntry.value)
                        .setTaskId(activateEntry.taskId)
                        .setReportSource(activateEntry.reportSource)
                        .setCfgId(activateEntry.cfgId)
                        .setAutoDownload(activateEntry.isAutoDownload)
                        .setNativeId(activateEntry.nativeId)
                        .setType(activateEntry.type);

                LogUtils.d(LogUtils.TAG_APM,"jumpActivate----3----"+activateEntry.toString());
                TRJumpUtil.jumpActivateToDetail(appBuilder, activateEntry.pushType);
                break;

            case TRActivateConstant.SYS_APP_RANK:
            case TRActivateConstant.RANK:
                FeatureBuilder featurebuilder = new FeatureBuilder()
                        .setDetailType(activateEntry.jumpType)
                        .setName("")
                        .setRankID(activateEntry.jumpUrl)
                        .setFromPage( activateEntry.fromPage)
                        .setLastPage(activateEntry.curPage)
                        .setValue(activateEntry.value);
                FeatureSinglePageActivity.switchToFeatureSinglePageActivity(PalmplayApplication.getAppInstance(), featurebuilder, activateEntry.pushType);
                break;
            case TRActivateConstant.LIST:
                // 跳转到推荐合集页
                if (activateEntry.jumpUrl != null && activateEntry.jumpUrl.startsWith(TRActivateConstant.REC_COLLECTION)) {
                    String tabId = activateEntry.jumpExt;
                    TRJumpUtil.jumpToRecommendCollectionActivity(tabId, activateEntry.fromPage, "0");
                } else {
                    TRJumpUtil.jumpActivateToList(activateEntry.jumpUrl, activateEntry.pushType);
                }
                break;
            case TRActivateConstant.OUTER_URL:
                TRJumpUtil.jumpActivateToOutLink(activateEntry.jumpUrl, activateEntry.pushType);
                break;
            case TRActivateConstant.INNER_URL:
                TRJumpUtil.jumpActivateToInnerLink(activateEntry.jumpUrl, 0, activateEntry.jumpType,
                        activateEntry.curPage, activateEntry.lastPage, null,activateEntry.fromPage,
                        "", "", false, activateEntry.pushType);
                break;
            case TRActivateConstant.MINI_APP:
                TRJumpUtil.jumpActivateToMiniApp(activateEntry.jumpUrl);
                break;
            case TRActivateConstant.DEEP_LINK:
                TRJumpUtil.jumpActivateToDeeplink(activateEntry.jumpUrl, activateEntry.jumpExt, activateEntry.pck, activateEntry.versionCode, activateEntry.pushType);
                break;
            case TRActivateConstant.GP_LINK:
                TRJumpUtil.jumpActivateToGp(activateEntry.jumpUrl, activateEntry.pushType);
                break;
            case TRActivateConstant.APP_CATEGORY:
            case TRActivateConstant.GAME_CATEGORY:
                String categoryType;
                if (TRActivateConstant.APP_CATEGORY.equalsIgnoreCase(activateEntry.jumpType)) {
                    categoryType = Constant.SOFTTYPE_APP;
                } else {
                    categoryType = Constant.SOFTTYPE_GAME;
                }
                TRJumpUtil.jumpToCategoryActivity(categoryType, activateEntry.jumpUrl, "", activateEntry.lastPage, activateEntry.value, activateEntry.pushType);
                break;

            case TRActivateConstant.GAME_HALL:
                TRJumpUtil.jumpActivateToGameHall(TRActivateConstant.GAME_HALL, "");
                break;
            case TRActivateConstant.FIND_DETAIL:
                TRJumpUtil.jumpActivateToFindDetail(activateEntry.jumpUrl, activateEntry.jumpExt, activateEntry.value, activateEntry.fromPage, activateEntry.pushType);
                break;
            case TRActivateConstant.FIND:
                TRJumpUtil.jumpActivateToFind(activateEntry.value, activateEntry.curPage, activateEntry.fromPage, activateEntry.pushType);
                break;

            case TRActivateConstant.TOOLS:
                Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                Intent mainIntent = new Intent(PalmplayApplication.getAppInstance(), MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mainIntent.putExtra(PSLaunchUtil.pushTypeTag, activateEntry.pushType);
                if (null != mainActivity) {
                    EventMainThreadEntity entity = new EventMainThreadEntity();
                    entity.setAction(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION);
                    entity.put(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION, NavTabInfo.TOOLS_KEY);
                    EventBus.getDefault().postSticky(entity);
                } else {
                    mainIntent.putExtra(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION, NavTabInfo.TOOLS_KEY);
                }
                try {
                    PalmplayApplication.getAppInstance().startActivity(mainIntent);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                return;


            case TRActivateConstant.AI_PETS: {
                XMPetManager.jumpToXMPet(XMPetFrom.PROMOTION.INSTANCE);
                break;
            }

            case TRActivateConstant.ACTIVITY_CENTER:
                TRJumpUtil.jumpActivityCenter(activateEntry.value, activateEntry.curPage, activateEntry.fromPage, activateEntry.pushType);
                break;
            case TRActivateConstant.GIFTS_CENTER:
                TRJumpUtil.jumpActivateToGiftsCenter(activateEntry.value, activateEntry.curPage, activateEntry.fromPage, activateEntry.pushType);
                break;
            case TRActivateConstant.OS_APK_ZIP_UPDATE:
                try {
                    Intent smallPkgIntent = new Intent(PalmplayApplication.getAppInstance(), SmallPackageActivity.class);
                    smallPkgIntent.putExtra(TRAnalyticsConstant.FROM, "PS");
                    smallPkgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    smallPkgIntent.putExtra(PSLaunchUtil.pushTypeTag, activateEntry.pushType);
                    PalmplayApplication.getAppInstance().startActivity(smallPkgIntent);
                } catch (Exception e) {
                }
                break;
            case TRActivateConstant.STATUS_SAVER:
                TRJumpUtil.jumpStatusSaverPage(activateEntry.value, activateEntry.curPage, activateEntry.fromPage, activateEntry.pushType);
                break;
            case TRActivateConstant.H5_GAME:
                TRJumpUtil.openH5Game(activateEntry.gameId, activateEntry.openUrl,activateEntry.name,activateEntry.iconUrl);
                break;
            case TRActivateConstant.VABOX:
                TRJumpUtil.openVaBox(activateEntry);
                break;
                //下列都是小程序，书城也是小程序的一个
            case TRActivateConstant.EBOOKS:
            case TRActivateConstant.MINI_APP_RICH:
                MiniAppManager.getInstance().jumpByEntry(activateEntry);
                break;
            case TRActivateConstant.SET_LANG:
                Intent langIntent = new Intent(PalmplayApplication.getAppInstance(), LanguageSelectActivity.class);
                langIntent.putExtra(LanguageSelectActivity.EXTRA_FROM_NOT_BANNER, true);
                try {
                    Activity activity = AtyManager.getAtyManager().getCurrentActivity();
                    if (activity != null && !activity.isFinishing()) {
                        activity.startActivity(langIntent);
                    } else {
                        langIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        PalmplayApplication.getAppInstance().startActivity(langIntent);
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG){
                        e.printStackTrace();
                        LogUtils.e("LanguageSelectActivity", e);
                    }
                }
                break;
            default:
                break;
        }
    }
}

package com.afmobi.palmplay.appdetail;

import android.view.View;

import com.afmobi.palmplay.model.AppInfo;

public interface DownloadHandlerInf {
    void handDownload(View v, AppInfo mAppInfo, String mFrom);
}

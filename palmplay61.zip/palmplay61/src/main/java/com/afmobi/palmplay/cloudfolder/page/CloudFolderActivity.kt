package com.afmobi.palmplay.cloudfolder.page

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.SparseArray
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderRemoteController
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.Lightness
import com.afmobi.palmplay.cloudfolder.utils.WallpaperUtils
import com.afmobi.palmplay.cloudfolder.utils.getFolderTitle
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import com.afmobi.palmplay.cloudfolder.view.FolderTitleContainer
import com.afmobi.palmplay.dialog.GdprDialog
import com.afmobi.util.ActivityLifecycleUtil
import com.afmobi.util.CommonUtils
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.getContextDisplayId
import com.transsion.palmstorecore.util.GDPRUtil
import com.transsion.palmstorecore.util.isPadDisplay
import com.transsion.palmstorecore.util.SystemUtils
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils
import com.transsion.palmstorecore.util.ScreenOrientationManager
import com.transsion.widgetslib.util.OSScreenDensityAdapter
import com.transsnet.store.R


class AppCloudFolderActivity : BaseCloudFolderActivity(FOLDER.APPS)

class GameCloudFolderActivity : BaseCloudFolderActivity(FOLDER.GAMES)


open class BaseCloudFolderActivity(private val currentFolder: FOLDER) : AppCompatActivity() {

    private val TAG = "BaseCloudFolderActivity"

    private lateinit var tabLayout : FolderTitleContainer
    private lateinit var viewPager: ViewPager2
    private val categoryList: MutableList<FOLDER> = ArrayList()
    private val titleList: ArrayList<String> = ArrayList()

    private var defaultIndex = 0

    private var mRootView : FrameLayout? = null

    private var currentMode = Lightness.UNKNOWN

    private var pagerAdapter : FragmentStateAdapter ?= null

    private val fragmentArray = SparseArray<BaseCloudFolderFragment>()

    // 是否由用户手势触发的页面切换（true=手势滑动，false=点击 tab）
    private var isUserDragging = false
    private var isPad = true
    private val iconStyleChangedListener: () -> Unit = {
        refreshVisibleIconStyle()
    }

    override fun getResources(): Resources {
        val resources = super.getResources()
        if (!isPad) {
            OSScreenDensityAdapter.updResource(resources, this)
        }
        return resources
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        refreshPadState(this, newConfig, getContextDisplayId())
        ScreenOrientationManager.apply(this)
        super.onConfigurationChanged(newConfig)
        applyFolderTopMargins()
        isInSmallWindow = newConfig.toString().contains("mMultiWindowMode=SMALL")
        LogUtils.i(TAG, "onConfigurationChanged: smallWindow=$isInSmallWindow, config=$newConfig")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        if (hasFocus) {
            refreshPadState(this, super.getResources().configuration, getContextDisplayId())
        }
        super.onWindowFocusChanged(hasFocus)
    }

    private fun refreshPadState(context: Context, configuration: Configuration, displayId: Int) {
        isPad = isPadDisplay(context, configuration, displayId)
    }

    override fun onCreate(onSaveInstanceState: Bundle?) {
        refreshPadState(this, super.getResources().configuration, getContextDisplayId())
        //统一方向策略：Pad 跟随系统旋转，手机锁竖屏（替代原"非 Pad 锁竖屏"本地逻辑）
        ScreenOrientationManager.apply(this)
        super.onCreate(onSaveInstanceState)
        setContentView(R.layout.activity_cloud_folder)

        DeviceProfile.getInstance().initData()

        // 设置沉浸式状态栏
        SystemUtils.setTransparent(window, false)
        transparentNavigationBar(window)

        defaultIndex = currentFolder.index

        mRootView = findViewById(R.id.rl_shortcut_root_view)
        tabLayout = findViewById(R.id.folder_title_container)
        viewPager = findViewById(R.id.view_pager)

        //add for drag_more end
        WallpaperUtils.getInstance().generateBlurWallpaper({drawable ->
            if (drawable != null) {
                mRootView?.setBackgroundDrawable(drawable)
            } else {
                mRootView?.setBackgroundDrawable(
                    ContextCompat.getDrawable(
                        PalmplayApplication.getAppInstance(),
                        R.drawable.cloud_folder_wallpaper
                    ))
            }
        }) {mode ->
            LogUtils.d(TAG, "getLightMode: $currentMode     --    $mode")
            if(currentMode != mode) {
                try {
                    currentMode = mode
                    if(currentMode != Lightness.UNKNOWN) {
                        WallpaperUtils.getInstance().setDarkMode(this, mode == Lightness.LIGHT)
                        fragmentArray.get(viewPager.currentItem)?.updateDarkUI()
                    }
                }catch (e : Exception) {
                    LogUtils.e(TAG, e)
                }
            }
        }

        if(CloudFolderRemoteController.getInstance().isShowFolderFragment(FOLDER.APPS)) {
            categoryList.add(FOLDER.APPS)
            titleList.add(FOLDER.APPS.getFolderTitle())
        }
        if(CloudFolderRemoteController.getInstance().isShowFolderFragment(FOLDER.GAMES)) {
            categoryList.add(FOLDER.GAMES)
            titleList.add(FOLDER.GAMES.getFolderTitle())
        }
        if(CloudFolderManager.getInstance().isRuCountry) {
            categoryList.reverse()
            titleList.reverse()
            if(currentFolder == FOLDER.APPS) {
                defaultIndex = 1
            } else {
                defaultIndex = 0
            }
        }
        initTabLayout()

        applyFolderTopMargins()
        viewPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        pagerAdapter = object : FragmentStateAdapter(this) {
            override fun createFragment(position: Int): Fragment {
                val cloudFolderFragment =
                    getCloudFolderFragment(categoryList[position].categoryType)
                fragmentArray.put(position, cloudFolderFragment)
                return cloudFolderFragment
            }

            override fun getItemCount(): Int {
                return categoryList.size
            }
        }
        viewPager.adapter = pagerAdapter

        // 监听 ViewPager2 页面切换，区分手势滑动（from=2）与点击 tab（from=1）
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrollStateChanged(state: Int) {
                if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    isUserDragging = true
                } else if (state == ViewPager2.SCROLL_STATE_IDLE) {
                    isUserDragging = false
                }
            }

            override fun onPageSelected(position: Int) {
                val from = if (isUserDragging) CloudFolderTrackUtil.STATUS_ENTER_SCROLL
                           else CloudFolderTrackUtil.STATUS_ENTER_CLICK
                fragmentArray.get(position)?.enterFrom = from
            }
        })

        viewPager.setCurrentItem(defaultIndex, false)

        //关闭其他页面
        showPalmPrivacyDialog()

        mRootView?.setOnClickListener { safeFinish() }

        CloudFolderManager.getInstance().checkAndRefreshPreviewImage(currentFolder)
    }

    private fun getCloudFolderFragment(categoryType: Int) : BaseCloudFolderFragment {
        return if (CloudFolderManager.getInstance().isShortcutSplit()) {
            ShortcutCloudFolderFragment.createCloudFolder(categoryType)
        } else {
            CloudFolderFragment.createCloudFolder(categoryType)
        }
    }

    private fun initTabLayout() {
        tabLayout.updateTitles(titleList, defaultIndex)
        tabLayout.setFolderCore(viewPager)
        tabLayout.setCurrentItem(defaultIndex, false)
    }

    /**
     * 按 layoutStyle 设置 Tab / ViewPager 顶边距与 Tab 水平 padding，与 online 保持一致。
     * onResume 时用 Activity context 重算 DeviceProfile，避免横竖屏切换后 resources 未更新。
     */
    private fun applyFolderTopMargins() {
        val deviceProfile = DeviceProfile.getInstance()
        deviceProfile.initData(this)
        if (!::tabLayout.isInitialized || !::viewPager.isInitialized) {
            return
        }
        val layoutStyle = CloudFolderManager.getInstance().getCloudFolderUiStyle()
        tabLayout.setPaddingRelative(
            getTitlePaddingStart(layoutStyle, deviceProfile),
            tabLayout.paddingTop,
            resources.getDimensionPixelSize(R.dimen.dp_40),
            tabLayout.paddingBottom
        )
        tabLayout.findViewById<LinearLayout>(R.id.folder_titles)?.gravity = Gravity.START

        val layoutParams = tabLayout.layoutParams as ViewGroup.MarginLayoutParams
        layoutParams.topMargin = if (
            !deviceProfile.isPadLayout &&
            layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST
        ) {
            dip2px(65f)
        } else if (layoutStyle == CloudFolderManager.LAYOUT_STYLE_SIMPLE_RANK) {
            deviceProfile.getTitleTopOffset() - dip2px(8f)
        } else {
            // Pad 样式 2/3 共用 getTitleTopOffset，避免样式 3 标题到搜索框偏大。
            deviceProfile.getTitleTopOffset()
        }
        layoutParams.topMargin = (layoutParams.topMargin -
                deviceProfile.padTitleToSearchExtra(resources)).coerceAtLeast(0)
        tabLayout.layoutParams = layoutParams

        val pagerLayoutParams = viewPager.layoutParams as ViewGroup.MarginLayoutParams
        pagerLayoutParams.topMargin = if (deviceProfile.isPadLayout) {
            deviceProfile.getFolderPaddingTop()
        } else {
            // 手机保持 online 的多样式间距。
            layoutParams.topMargin + dip2px(65f)
        }
        viewPager.layoutParams = pagerLayoutParams
    }

    /**
     * Pad 上搜索框会居中且受最大宽度限制；标题从搜索输入框的 start 边缘开始。
     * 手机保持现有标题 padding。
     */
    private fun getTitlePaddingStart(layoutStyle: Int, deviceProfile: DeviceProfile): Int {
        val isOriginalStyle = layoutStyle == CloudFolderManager.LAYOUT_STYLE_ORIGINAL
        val isSimpleRankStyle = layoutStyle == CloudFolderManager.LAYOUT_STYLE_SIMPLE_RANK
        if (!deviceProfile.isPadLayout) {
            return dip2px(if (isOriginalStyle || isSimpleRankStyle) 50f else 40f)
        }

        val searchContainerWidth = minOf(
            deviceProfile.getDesiredWidth(),
            deviceProfile.getPadSearchContainerWidth(resources)
        )
        val searchContainerStart = (
            (deviceProfile.getAvailableWidthPx() - searchContainerWidth) / 2
            ).coerceAtLeast(0)
        return searchContainerStart + deviceProfile.padSearchSidePadding(resources)
    }


    private fun transparentNavigationBar(window: Window?) {
        window?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                it.isNavigationBarContrastEnforced = false
            }
            it.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
            it.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            var systemUiVisibility = it.decorView.systemUiVisibility
            systemUiVisibility =
                systemUiVisibility or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            it.decorView.systemUiVisibility = systemUiVisibility
            it.navigationBarColor = Color.TRANSPARENT

            //设置导航栏按钮或导航条颜色
            setNavigationBarBtnColor(window, true)
        }
    }

    private fun setNavigationBarBtnColor(window: Window, light: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var systemUiVisibility = window.decorView.systemUiVisibility
            systemUiVisibility = if (light) { //白色按钮
                systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            } else { //黑色按钮
                systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = systemUiVisibility
        }
    }

    /**
     * 显示palmStore授权弹窗
     */
    private fun showPalmPrivacyDialog() {
        if (CommonUtils.isPrivacyPolicyHasAllowed()) {
            return
        }

        val cloudFolderPalmPrivacyDialog = GdprDialog(this)
        cloudFolderPalmPrivacyDialog.show()
        cloudFolderPalmPrivacyDialog.setAgreeListener {
            //同意协议
            TRSharedPreferenceUtils.setGdrpGree(true)
            TRSharedPreferenceUtils.setPrivacyPolicyAgree(true)
            val fromPage = if(currentFolder == FOLDER.APPS) {
                CloudFolderManager.getInstance().FILE_FOLDER_FROM_SITE_APP
            } else {
                CloudFolderManager.getInstance().FILE_FOLDER_FROM_SITE_GAME
            }
            TRAnalysticsUtil.trackPrivatePolicyClick(fromPage)
            TRSharedPreferenceUtils.setGdprVersion(GDPRUtil.privacyPolicyVersion)
            cloudFolderPalmPrivacyDialog.dismiss()
        }
        cloudFolderPalmPrivacyDialog.setCancelListener {
            cloudFolderPalmPrivacyDialog.dismiss()
            safeFinish()
        }

    }

    private var isFirstEnter = true

    fun refreshFragmentData() {
        if(isFirstEnter) {
            isFirstEnter = false
            return
        }
        supportFragmentManager.fragments.forEach {
            if(it is CloudFolderFragment) {
                it.initCloudFolderData()
            }
        }
    }

    private var userPressedHome = false // 标记：是否是用户主动离开（如 Home 键）
    var isInternalNavigation = false // 标记：是否是应用内跳转
    private var isInSmallWindow = false

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // 只要触发了该回调，说明是用户主动行为（Home键、多任务键等）
        userPressedHome = true
        LogUtils.i(TAG, "onUserLeaveHint: userPressedHome=$userPressedHome")
    }

    override fun onStop() {
        if (CloudFolderManager.getInstance().isWidgetSplit()) {
            CloudFolderRemoteController.getInstance()
                .removeIconStyleChangedListener(iconStyleChangedListener)
        }
        super.onStop()
        val isAppForeground = ActivityLifecycleUtil.isAppForeground()
        val isInSmallWindow = isInSmallWindowMode()
        val shouldFinishTask = userPressedHome && !isAppForeground &&
            !isInternalNavigation && !isInSmallWindow
        LogUtils.i(
            TAG,
            "onStop: userPressedHome=$userPressedHome, appForeground=$isAppForeground, " +
                "internalNavigation=$isInternalNavigation, smallWindow=$isInSmallWindow, " +
                "shouldFinishTask=$shouldFinishTask"
        )
        if (shouldFinishTask) {
            LogUtils.i(TAG, "onStop: shouldFinishTask=true, finishAndRemoveTask")
//            viewPager.setCurrentItem(defaultIndex, false)
            finishAndRemoveTask()
            // 建议重置，虽然已经 finish，但保持状态闭环是好习惯
        } else {
            LogUtils.i(TAG, "onStop: shouldFinishTask=false, keep task")
        }
        userPressedHome = false
    }

    override fun onPause() {
        LogUtils.i(TAG, "onPause: smallWindow=${isInSmallWindowMode()}")
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        LogUtils.i(TAG, "onResume: smallWindow=${isInSmallWindowMode()}")
        if (::tabLayout.isInitialized) {
            applyFolderTopMargins()
        }
        refreshFragmentData()
    }

    override fun onStart() {
        super.onStart()
        if (CloudFolderManager.getInstance().isWidgetSplit()) {
            CloudFolderRemoteController.getInstance().apply {
                addIconStyleChangedListener(iconStyleChangedListener)
                refreshGlobalIconColoringConfig(this@BaseCloudFolderActivity)
            }
        }
        LogUtils.i(TAG, "onStart: internalNavigation=$isInternalNavigation")
        // 每次回到页面时，重置开关
        isInternalNavigation = false
    }

    private fun refreshVisibleIconStyle() {
        for (index in 0 until fragmentArray.size()) {
            fragmentArray.valueAt(index).refreshIconStyle()
        }
    }

    override fun onDestroy() {
        LogUtils.i(TAG, "onDestroy: isFinishing=$isFinishing, isDestroyed=$isDestroyed")
        super.onDestroy()
    }

    private fun isInSmallWindowMode(): Boolean {
        return isInSmallWindow
    }

    private fun safeFinish() {
        if (!isFinishing && !isDestroyed) {
            finish()
        }
    }

}

package com.afmobi.palmplay.collection.viewholder;

import android.view.View;
import android.widget.ImageView;

import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.model.CurrentTabConfig;
import com.afmobi.palmplay.model.FeatureSinglePageHeadData;
import com.afmobi.palmplay.rank.adapter.FeatureBaseRecyclerViewHolder;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutFeatureActivityStyleHeaderBinding;
import com.transsnet.store.databinding.LayoutRecommendCollectionHeaderBinding;

public class OuterHeaderViewHolder extends RecyclerView.ViewHolder {
    private ImageView imageView;
    public OuterHeaderViewHolder(View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.iv_banner);
    }

    public void bind(CurrentTabConfig tabConfig) {
        itemView.setTag(tabConfig);
        GlideUtils.setImageUrl(imageView, tabConfig.bgImageUrl, R.drawable.default_banner, R.drawable.default_banner);
    }

}

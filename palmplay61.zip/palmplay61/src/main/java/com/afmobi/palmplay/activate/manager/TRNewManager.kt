package com.afmobi.palmplay.activate.manager

import android.app.Activity
import android.content.DialogInterface
import android.view.View
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.TRDiskSpaceLimitExecutor
import com.afmobi.palmplay.activate.TRFileFolderPermissionExecutor
import com.afmobi.palmplay.activate.TRIntantGameExecutor
import com.afmobi.palmplay.activate.TRMustInstallExecutor
import com.afmobi.palmplay.activate.TRNavActivateExecutor
import com.afmobi.palmplay.activate.TRNotificationToggleExecutor
import com.afmobi.palmplay.activate.TROfflineMoreGuideExecutor
import com.afmobi.palmplay.activate.TRPrivacyPolicyExecutor
import com.afmobi.palmplay.activate.TRRecomInstallExecutor
import com.afmobi.palmplay.activate.TRSplashActivateExecutor
import com.afmobi.palmplay.activate.TRTipActivateExecutor
import com.afmobi.palmplay.activate.TRTipNetworkExecutor
import com.afmobi.palmplay.activate.TRUpdateVersionExecutor
import com.afmobi.palmplay.activate.TRUserDialogExecutor
import com.afmobi.palmplay.activate.TRPetGuideDialogExecutor
import com.afmobi.palmplay.activate.TRWidgetGuideExecutor
import com.afmobi.palmplay.activate.dispatcher.TRPopManagerDispatcher
import com.afmobi.palmplay.activate.handler.DefaultChainHandler
import com.afmobi.palmplay.activate.handler.TRIntantGameHandler
import com.afmobi.palmplay.activate.handler.TROfflineMoreGuideHandler
import com.afmobi.palmplay.activate.handler.TRTipActivateHandler
import com.afmobi.palmplay.activate.handler.TRUserDialogHandler
import com.afmobi.palmplay.activate.handler.TRPetGuideHandler
import com.afmobi.palmplay.activate.state.ShowStateManager
import com.afmobi.palmplay.activate.state.TRPopUpScene
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.dialog.OfflineMoreGuideDialog
import com.afmobi.palmplay.model.refactor.NewPop
import com.afmobi.palmplay.mvvm.data.AppDataManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager
import com.afmobi.util.CommonUtils
import com.afmobi.util.Constant
import com.google.gson.Gson
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils

class TRNewManager  private constructor() {
    companion object {

        const val TAG = "TRNewManager"

        @JvmStatic
        val instance by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {TRNewManager() }
        @JvmStatic
        private val dispatcher = TRPopManagerDispatcher()
        @Volatile
        @JvmStatic
        var isInited = false
        private var mNewPop: NewPop? = null
        var canPopNext = false
        private var showStateManager : ShowStateManager = ShowStateManager.getInstance()
        @JvmStatic
        var closeListener :OnDialogCloseListener = object : OnDialogCloseListener {
            override fun onDialogClosed() {
                // 监听对话框关闭事件
                instance?.resetShowStatus();
                if (dispatcher.showNextPopup()) {
                    instance?.markAsShown()
                }
            }
        }
    }

    fun ensureInitialized() {
        if (!isInited) {
            synchronized(this) {
                if (!isInited) {
                    init()
                    isInited = true
                }
            }
        }
    }

    private fun init() {
        // 初始化TRNewManager
        LogUtils.d(TAG, "init TRNewManager")
        canPopNext = mNewPop?.parameterValue?.trPopNextEnable==1
        if(AppDataManager.FEATURE_FILE_FOLDER_SWITCH) {
            dispatcher.addPopupHandler(DefaultChainHandler(TRFileFolderPermissionExecutor(), TRPopUpScene.POP_UP_FILE_FOLDER, TRPriority.MUST, TRPopupType.HOME_ONE_TIME))
         }
        dispatcher.addPopupHandler(DefaultChainHandler(TRUpdateVersionExecutor(), TRPopUpScene.POP_UP_APP_UPDATE, TRPriority.MUST, TRPopupType.HOME_ONE_TIME))
        dispatcher.addPopupHandler(DefaultChainHandler(TRRecomInstallExecutor(), TRPopUpScene.POP_UP_RECOMMOND_INSTALL, TRPriority.HIGH, TRPopupType.HOME_ONE_TIME))
        dispatcher.addPopupHandler(DefaultChainHandler(TRMustInstallExecutor(), TRPopUpScene.POP_UP_MUST_INSTALL, TRPriority.HIGH, TRPopupType.HOME_ONE_TIME))
        dispatcher.addPopupHandler(DefaultChainHandler(TRWidgetGuideExecutor(), TRPopUpScene.POP_UP_GUIDE_WIDGE, TRPriority.HIGH, TRPopupType.HOME_ONE_TIME))
        dispatcher.addPopupHandler(TRTipActivateHandler(TRTipActivateExecutor(), TRPopUpScene.POP_UP_TIP_ACTIVATE, TRPriority.HIGH, TRPopupType.HOME_ONE_TIME))  // 因需要处理showOther，单独构建
        dispatcher.addPopupHandler(DefaultChainHandler(TRNavActivateExecutor(), TRPopUpScene.POP_UP_NAV_ACTIVATE, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(DefaultChainHandler(TRDiskSpaceLimitExecutor(), TRPopUpScene.POP_UP_DISK_SPACE_LIMIT, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(DefaultChainHandler(TRNotificationToggleExecutor(), TRPopUpScene.POP_UP_NOTIFICATION_TOGGLE, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(DefaultChainHandler(TRSplashActivateExecutor(), TRPopUpScene.POP_UP_SPLASH_ACTIVATE, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(DefaultChainHandler(TRTipNetworkExecutor(), TRPopUpScene.POP_UP_TIP_NETWORK, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(TRUserDialogHandler(TRUserDialogExecutor(), TRPopUpScene.POP_UP_USER_DIALOG, TRPriority.HIGH, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(TRPetGuideHandler(TRPetGuideDialogExecutor(), TRPopUpScene.POP_UP_PET_GUIDE, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(TRIntantGameHandler(TRIntantGameExecutor(), TRPopUpScene.POP_UP_INSTANT_GAME_GUIDE, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(DefaultChainHandler(TRPrivacyPolicyExecutor(), TRPopUpScene.POP_UP_PRIVACY_POLICY, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
        dispatcher.addPopupHandler(TROfflineMoreGuideHandler(TROfflineMoreGuideExecutor(), TRPopUpScene.POP_UP_OFFLINE_MORE_GUIDE, TRPriority.MEDIUM, TRPopupType.SCENE_BASED))
    }

    fun show(fromType:String) {
        ensureInitialized()
        LogUtils.d(TAG, "show TRNewManager in home, dispatchEvent")
        dispatcher.dispatchEvent(fromType)
    }


    fun dismiss(fromType: String) {
        ensureInitialized()
        dispatcher.dismiss(fromType)
    }

    fun dismiss(fromType: String, activity: Activity?) {
        ensureInitialized()
        dispatcher.dismiss(fromType, activity)
    }

    /**
     * 根据来源类型获取对应的执行器
     * @param fromType 来源类型标识
     * @return 对应的执行器实例，未找到时返回null
     */
    fun getExecutor(fromPage : String): TRBaseExecutor<*>? {
        ensureInitialized()
        return dispatcher.getExecutor(fromPage)
    }


    fun showing(sceneName: String): Boolean {
        ensureInitialized()
        return dispatcher.showing(sceneName)
    }


    /**
     * 显示弹框等需要传入activity
     * @param activity
     * @param fromType
     */
    fun showPop(fromType: String, activity: Activity?) : Boolean{
        ensureInitialized()
        return dispatcher.showPop(fromType, activity)
    }

    /**
     * 专门用于无网弹窗，因其埋点需要传入from字段
     */
    fun showPop(fromType: String, from:String?, activity: Activity?) :Boolean {
        ensureInitialized()
        return dispatcher.showPop(fromType, from, activity)
    }

    /**
     * 显示弹框，需要传入activity
     */
    fun showPop(fromType: String, activity: Activity?, y:Int): Boolean {
        ensureInitialized()
        return dispatcher.showPop(fromType, activity, y)
    }

    fun showPop(fromType: String, activity: Activity?, isNeedGuide: Boolean, listener: DialogInterface.OnDismissListener): Boolean {
        ensureInitialized()
        return dispatcher.showPop(fromType, activity, isNeedGuide, listener)
    }

    /**
     * 目前专门引用于InstantGame引导，因其需要处理UI，需传入clickListener、dismissListener
     * @param fromType
     * @param activity
     * @param clickListener
     * @param dismissListener
     * @return
     */
    fun showPop(fromType: String, activity: Activity?, clickListener: View.OnClickListener, dismissListener: DialogInterface.OnDismissListener): Boolean {
        ensureInitialized()
        return dispatcher.showPop(fromType, activity, clickListener, dismissListener)
    }

    /**
     * 专门引用于more引导， 需传入listener、isR2L、location
     * @param fromType
     * @param activity
     * @param listener
     * @param isR2L
     * @param location
     * @return
     */
    fun showPop(
        fromType: String,
        activity: Activity?,
        listener: OfflineMoreGuideDialog.OnDialogBtnClickListener,
        isR2L: Boolean,
        location: IntArray
    ): Boolean {
        ensureInitialized()
        return dispatcher.showPop(fromType, activity, listener, isR2L, location)
    }

    fun hide(): Unit {
        ensureInitialized()
        dispatcher.hide()
    }

    fun callbackShow( type:Int , fromType: String) :Boolean {
        ensureInitialized()
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if (CommonUtils.isBlockAllPopUps()) {
            return false
        }
        return dispatcher.callBackShow(type, fromType)
    }

    fun resetShowStatus() {
        // 重置TRNewManager显示状态
        showStateManager.reset()
    }

    fun canShow() : Boolean {
        // 判断是否可以显示TRNewManager
        return showStateManager.canShow()
    }

    fun markAsShown() {
        // 标记TRNewManager已显示
        showStateManager.markAdShown()
    }

    fun initNewPop() {
        val newPopStr =
            MMKVUtils.getMMKV().getString(Constant.KV_NEW_POP, "")
        LogUtils.d(TRNewManager.TAG, "initNewPop: $newPopStr")
        try {
            mNewPop = Gson().fromJson(newPopStr, NewPop::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isNewPopEnable(): Boolean {
        LogUtils.d(TRNewManager.TAG, "isNewPopEnable: ${mNewPop?.parameterValue?.trNewPopEnable}")
        return mNewPop?.parameterValue?.trNewPopEnable == 1
    }

    fun hasNextToShow(): Boolean {
        LogUtils.d(TRNewManager.TAG, "hasNextToShow: ${mNewPop?.parameterValue?.trPopNextEnable}")
        return mNewPop?.parameterValue?.trPopNextEnable == 1
    }

    interface OnDialogCloseListener {
        fun onDialogClosed()
    }
}
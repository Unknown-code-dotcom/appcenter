package com.afmobi.palmplay.collection.repo

import com.afmobi.palmplay.configs.v6_3.FeaturedType
import com.afmobi.palmplay.home.TRHomeUtil
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import com.afmobi.util.Constant
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class CollectionLocalRepo {
    companion object {
        const val TAG = "${LogUtils.TAG_COLLECTION}CollectionLocalRepo"
    }

    fun getCache(tabId: String): Flow<FeaturedModel?> = flow {
        val featuredModel = TRHomeUtil.loadFromCache(FeaturedType.COLLECTION, tabId)
        LogUtils.d(TAG, "缓存： tabId=$tabId featuredModel=${featuredModel.tid}")
        emit(featuredModel)
    }.flowOn(Dispatchers.IO)

    fun saveCache(featuredModel: FeaturedModel, tabId: String) {
        LogUtils.d(TAG, "实时： featuredModel=${featuredModel.tid} tabId=$tabId")
        TRHomeUtil.saveToCache(featuredModel, FeaturedType.COLLECTION, tabId)
        MMKVUtils.getMMKV().putBoolean(Constant.KV_COLLECTION_CACHE_EXIST + tabId, true)
    }
}
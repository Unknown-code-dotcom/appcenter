package com.afmobi.palmplay.clean;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Debug;
import android.os.Process;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.customview.MemoryCheckContainerView;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_6.ProcessInfo;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class ProcessAndMemoryUtil {

    public static final String CLEAN_CACHE_DATA = "clean_cache_data_new";

    public static List<ProcessInfo> getRunningProcessSimpleInfo() {
        File[] files = new File("/proc").listFiles();
        List<ProcessInfo> result = new ArrayList<>();
        for (File file : files) {
            if (file.isDirectory()) {
                int pid;
                try {
                    pid = Integer.parseInt(file.getName());
                    String name = getProcessName(pid);
                    if (!TextUtils.isEmpty(name) && !name.startsWith("/") && !name.startsWith(".") && name.contains(".")) {
                        ProcessInfo item = new ProcessInfo();
                        item.pid = pid;
                        item.processName = name;
                        item.allMemory = formatSizeKbMbGb(memoryInfoPidAll(pid), 2);
                        item.useMemory = formatSizeKbMbGb(memoryInfoPidUsed(pid), 2);

                        result.add(item);
                    }
                } catch (Exception e) {
                    LogUtils.e(LogUtils.TAG_CLEAN_MEMORY, e.toString());
                }
            }
        }

        return result;
    }

    public static String getTopActivityClassName() {
        String className = "";
        try {
            ActivityManager activityManager = (ActivityManager) PalmplayApplication.getAppInstance().getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningTaskInfo> taskInfos = activityManager.getRunningTasks(1);
            if (taskInfos != null && taskInfos.size() > 0) {
                ComponentName cn = taskInfos.get(0).topActivity;
                if (cn != null) {
                    className = cn.getClassName();
                }
            }
        } catch (SecurityException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return className;
    }

    public static String getTopAppPackageName() {
        String pkgName = "";
        try {
            ActivityManager activityManager = (ActivityManager) PalmplayApplication.getAppInstance().getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningTaskInfo> taskInfos = activityManager.getRunningTasks(1);
            if (taskInfos != null && taskInfos.size() > 0) {
                ComponentName cn = taskInfos.get(0).topActivity;
                if (cn != null) {
                    pkgName = cn.getPackageName();
                }
            }
        } catch (SecurityException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return pkgName;
    }


    public static String getProcessName(int pid) throws IOException {
        String cmdline = null;
        try {
            cmdline = readFile(String.format("/proc/%d/cmdline", pid)).trim();
        } catch (IOException ignored) {
        }
        if (TextUtils.isEmpty(cmdline)) {
//            return Stat.get(pid).getComm();
            return cmdline;
        }
        return cmdline;
    }

    static String readFile(String path) throws IOException {
        BufferedReader reader = null;
        try {
            StringBuilder output = new StringBuilder();
            reader = new BufferedReader(new FileReader(path));
            for (String line = reader.readLine(), newLine = ""; line != null; line = reader.readLine()) {
                output.append(newLine).append(line);
                newLine = "\n";
            }
            return output.toString();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    static long memoryInfoPidAll(int pid) {
        return memoryInfoPid(pid, 0);
    }

    static long memoryInfoPidUsed(int pid) {
        return memoryInfoPid(pid, 1);
    }

    static long memoryInfoPid(int pid, int index) {
        String content = null;
        try {
            content = readFile(String.format("/proc/%d/statm", pid)).trim();
        } catch (IOException ignored) {
        }
        if (TextUtils.isEmpty(content)) return 0;
        String[] fields = content.split("\\s+");

//        Log.d(TAG, "content = " + content);

        return Long.parseLong(fields[index]) * 1024;
    }

    /**
     * 获取Android已用内存所占的百分比
     *
     * @param context
     * @return 百分值
     */
    public static int getSystemUsedMemoryPercent(Context context) {
        long[] memoryInfos = getAndroidMemory(context);
        long totalMemory = memoryInfos[0] / 1024 / 1024;
        double usedMemory = totalMemory - memoryInfos[1] / 1024 / 1024;
        return (int) (usedMemory / totalMemory * 100);
    }

    /**
     * 获取android当前内存大小
     *
     * @param context
     * @return 数组元素0是总大小，元素1是可用大小
     */
    public static long[] getAndroidMemory(Context context) {
        ActivityManager activityManager = (ActivityManager) context
                .getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            return new long[]{memoryInfo.totalMem, memoryInfo.availMem};
        }

        return new long[]{0, 0};
    }

    /**
     * 清理运行内存
     */
    public static void cleanMemory() {
        List<ProcessInfo> processInfos = ProcessAndMemoryUtil.getRunningProcessSimpleInfo();
        for (ProcessInfo process : processInfos) {
            if (process.pid == Process.myPid())
                continue;
            Process.killProcess(process.pid);
        }

        doClean();
    }

    /**
     * @param size
     * @param count
     * @return
     */
    public static String formatSizeKbMbGb(long size, int count) {
        if (size < 1024)
            return size + "B";
        float f1 = size / 1024.0F;
        String str = "KB";
        if (f1 > 1024) {
            f1 /= 1024.f;
            str = "MB";
        }
        if (f1 > 1024) {
            f1 /= 1024.f;
            str = "GB";
        }
        return round(f1, count) + str;
    }

    /**
     * @param value 值
     * @param count 保留小数点的位数
     * @return
     */
    public static String round(double value, int count) {
        StringBuilder result = new StringBuilder();
        if (count <= 0) {
            result.append((int) Math.round(value));
            return result.toString();
        }
        if ((count == 1) && (value >= 0.95D + (int) value))
            result.append(1 + (int) value);
        else {
            result.append((int) value);
        }

        result.append(".");

        double d1 = 1.0D;
        for (int j = 0; j < count; j++) {
            d1 *= 10.0D;
        }
        String temp = String.valueOf(Math.round(d1 * (value - (int) value)));
        if (!TextUtils.isEmpty(temp) && temp.length() > 1 && temp.endsWith("0"))
            temp = temp.substring(0, temp.length() - 1);
        result.append(temp);
        return result.toString();
    }

    /**
     * 获取运行中的进程信息，比如App名字、icon、内存使用等
     *
     * @param activityManager
     */
    public static List<CacheListItem> getRunningProcessFullInfo(AsyncTask task, ActivityManager activityManager) {
        List<CacheListItem> list = new ArrayList<>();

        List<ActivityManager.RunningAppProcessInfo> processes = activityManager.getRunningAppProcesses();

        if (processes == null) {
            return list;
        }

        String myPackageName = PalmPlayVersionManager.getMyPackageName(); //context.getPackageName()

        for (ActivityManager.RunningAppProcessInfo processInfo : processes) {
            if (task.isCancelled()) {
                break;
            }

            if (processInfo.processName.contains(myPackageName)) {
                continue;
            }

            InstalledAppInfo appInfo = InstalledAppManager.getInstance().get(processInfo.processName);

            if (appInfo == null) {//未初始化
                continue;
            }

            if (appInfo.isSystemApp) {//系统应用
                continue;
            }

            if (processInfo.pid == Process.myPid()) {
                continue;
            }

            Debug.MemoryInfo[] processMemoryInfo = activityManager.getProcessMemoryInfo(new int[]{processInfo.pid});
            if (processMemoryInfo == null || processMemoryInfo.length == 0) {
                continue;
            }

            long memSize = processMemoryInfo[0].getTotalPrivateDirty() * 1024L;
            CacheListItem cacheListItem = new CacheListItem();
            cacheListItem.setApplicationName(appInfo.appName);
            cacheListItem.setSize(memSize);
            list.add(cacheListItem);
        }

        return list;
    }

    public static ApplicationInfo getApplicationInfo(PackageManager packageManager, String processName) {
        if (TextUtils.isEmpty(processName)) {
            return null;
        }
        try {
            int flags;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
                flags = PackageManager.GET_UNINSTALLED_PACKAGES;
            else
                flags = PackageManager.MATCH_UNINSTALLED_PACKAGES;
            List<ApplicationInfo> appList = packageManager
                    .getInstalledApplications(flags);
            for (ApplicationInfo appInfo : appList) {
                if (processName.equals(appInfo.processName)) {
                    return appInfo;
                }
            }
        } catch (Exception e) {
            LogUtils.e(LogUtils.TAG_CLEAN_MEMORY, e.toString());
        }
        return null;
    }

    /**
     * 生成缓存假数据
     *
     * @return
     */
    public static long getCacheJunkSize() {
        if (getAndroidMemory(PalmplayApplication.getAppInstance())[0] / 1024 / 1024 / 1024f >= 3.5f) {//对于4GB内存及以上机型,Cache junk取5~120 MB随机数字；
            return new Random().nextInt(1024 * 1024 * 120 - 1024 * 1024 * 5) + 1024 * 1024 * 5;
        } else {//Cache junk取200KB~50MB随机数字；
            return new Random().nextInt(1024 * 1024 * 50 - 1024 * 200) + 1024 * 200;
        }
    }

    /**
     * 生成卸载残留假数据
     *
     * @return
     */
    public static long getResidualJunkSize() {
        if (getAndroidMemory(PalmplayApplication.getAppInstance())[0] / 1024 / 1024 / 1024f >= 3.5f) {//对于4GB内存及以上机型,Reasidual Junk File取500KB~10MB随机数字；
            return new Random().nextInt(1024 * 1024 * 10 - 1024 * 500) + 1024 * 500;
        } else {//Reasidual Junk File取100KB~5MB随机数字；
            return new Random().nextInt(1024 * 1024 * 5 - 1024 * 100) + 1024 * 100;
        }
    }


    /**
     * 调用系统一键清理
     *
     * @return 失败，返回false；成功返回true
     */
    public static boolean doClean() {
        ActivityManager am = (ActivityManager) PalmplayApplication.getAppInstance().getSystemService(Context.ACTIVITY_SERVICE);
        Class mActivityManager = am.getClass();
        try {
            Method method = mActivityManager.getMethod("doClean", int.class, List.class);
            List<String> pck = new ArrayList<>();
            pck.add("com.gallery20");
            pck.add("com.transsion.filemanagerx");
            pck.add(PalmplayApplication.getAppInstance().getPackageName());
            method.invoke(am, 3, pck);
        } catch (Exception e) {
            LogUtils.e(LogUtils.TAG_CLEAN_MEMORY, e.getCause());
            return false;
        }
        return true;
    }


    public static String formatSizeMbGb(double size, int count) {
        if (size < 1024)
            return size + "MB";
        double f1 = size / 1024.0D;
        String str = "GB";
        String result = round(f1, count) + str;
        return result;
    }

    public static CleanDataBean getCleanData(){
        return (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
    }

    /**
     * 是否需要进行内存检测；
     *
     * @return 返回空，需要；不为空，则不需要，直接拿缓存数据展示；
     */
    public static CleanDataBean needMemoryCheck() {
        //内存检测结果有效期为 20 min，在该时间周期内，用
        //户若不进行一键优化，并再次进入 Tools 模块，不进行
        //内存检测，直接显示上次检测结果
        CleanDataBean cleanDataBean = (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
        if (cleanDataBean == null) {
            return null;
        }
        long currentTime = System.currentTimeMillis();
        long twentyMinutes = 20 * 60 * 1000;
        if (currentTime - cleanDataBean.memoryOptimizeTime < twentyMinutes) {
            return cleanDataBean;
        }
//        if (currentTime - cleanDataBean.memoryCheckAutoTime < twentyMinutes || currentTime - cleanDataBean.memoryCheckUserTime < twentyMinutes) {
//            return cleanDataBean;
//        }

        return null;
    }

    public static CleanDataBean saveMemoryCheckData(boolean isAuto, int memoryCheckResult) {
        CleanDataBean cleanDataBean = (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
        if (cleanDataBean == null) {
            cleanDataBean = new CleanDataBean();
        }
        if (isAuto) {
            cleanDataBean.memoryCheckAutoTime = System.currentTimeMillis();
        } else {
            cleanDataBean.memoryCheckUserTime = System.currentTimeMillis();
        }
        cleanDataBean.memoryCheckResult = memoryCheckResult;//直接保存展示用的百分比；
        cleanDataBean.backgroundStatus = MemoryCheckContainerView.STATUS_CHECKED;
        ACache.get(PalmplayApplication.getAppInstance()).put(CLEAN_CACHE_DATA, cleanDataBean);
        return cleanDataBean;
    }

    public static CleanDataBean saveMemoryOptimizeData(int memoryOptimizePercentResult, String memoryOptimizeSizeResult) {
        CleanDataBean cleanDataBean = (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
        if (cleanDataBean == null) {
            cleanDataBean = new CleanDataBean();
        }
        cleanDataBean.memoryOptimizeTime = System.currentTimeMillis();
        cleanDataBean.memoryOptimizePercentResult = memoryOptimizePercentResult;
        cleanDataBean.memoryOptimizeSizeResult = memoryOptimizeSizeResult;
        ACache.get(PalmplayApplication.getAppInstance()).put(CLEAN_CACHE_DATA, cleanDataBean);
        return cleanDataBean;
    }

    public static CleanDataBean saveDeepCleanResult(String result) {
        CleanDataBean cleanDataBean = (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
        if (cleanDataBean == null) {
            cleanDataBean = new CleanDataBean();
        }
        cleanDataBean.deepCleanTime = System.currentTimeMillis();
        cleanDataBean.deepCleanResult = result;
        ACache.get(PalmplayApplication.getAppInstance()).put(CLEAN_CACHE_DATA, cleanDataBean);
        return cleanDataBean;
    }

    public static CleanDataBean clearDeepCleanResult() {
        CleanDataBean cleanDataBean = (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
        if (cleanDataBean == null) {
            cleanDataBean = new CleanDataBean();
        }
        cleanDataBean.deepCleanTime = 0;
        cleanDataBean.deepCleanResult = "";
        ACache.get(PalmplayApplication.getAppInstance()).put(CLEAN_CACHE_DATA, cleanDataBean);
        return cleanDataBean;
    }

    public static int getBackgroundStatus(){
        CleanDataBean cleanDataBean = null;
        try {
            cleanDataBean = (CleanDataBean) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(CLEAN_CACHE_DATA);
        } catch (Exception e) {

        }
        if (cleanDataBean == null) {
            return MemoryCheckContainerView.STATUS_CHECKED;
        } else {
            return cleanDataBean.backgroundStatus;
        }
    }

    public static long[] generateMemoryOptimizeData() {
        //检测结果，内存占比在 65~95 中取随机值，并记录此数据。
        //优化结果，内存清理值在本机 RAM 20%~50%中取随机值，内存占比值根据
        //记录的检测结果值，与清理值作换算并显示。
        long[] memoryInfos = getAndroidMemory(PalmplayApplication.getAppInstance());
        long totalMemory = memoryInfos[0] / 1024 / 1024;
        double usedMemory = totalMemory - memoryInfos[1] / 1024 / 1024;
        int usedPercent = (int) (usedMemory / totalMemory * 100);

        int bottom, top;
        int optimizedPercent;
        if (usedPercent >= 60) {
            optimizedPercent = new Random().nextInt(30) + 20;
        } else {
            //已用内存本身就不多的话，生成的随机值不能太大
            top = usedPercent - 10;
            bottom = 20;
            int interval = top - bottom;
            if (interval > 0) {
                optimizedPercent = new Random().nextInt(interval) + bottom;
            } else {
                optimizedPercent = 5;
            }
        }

        return new long[]{usedPercent - optimizedPercent, memoryInfos[0] * optimizedPercent / 100};
    }
}

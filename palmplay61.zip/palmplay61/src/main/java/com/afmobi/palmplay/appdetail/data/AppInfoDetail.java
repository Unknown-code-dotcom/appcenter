package com.afmobi.palmplay.appdetail.data;

import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;

import java.io.Serializable;

public class AppInfoDetail implements Serializable {
    public AppInfo appInfo;
    public boolean isHaveCache;
    public boolean isCache;//走的缓存
    public String mType;
    public boolean isCustomized;
    public PageParamInfo mPageParamInfo;
    public String mFrom;

    public AppInfoDetail(boolean isCache, AppInfo appInfo, boolean isHaveCache, boolean isCustomized) {
        this.isCache = isCache;
        this.appInfo = appInfo;
        this.isHaveCache = isHaveCache;
        this.isCustomized = isCustomized;
    }

    @Override
    public String toString() {
        return "AppInfoDetail{" +
                "appInfo=" + appInfo +
                ", isHaveCache=" + isHaveCache +
                ", isCache=" + isCache +
                ", mType='" + mType + '\'' +
                ", isCustomized=" + isCustomized +
                ", mPageParamInfo=" + mPageParamInfo +
                ", mFrom='" + mFrom + '\'' +
                '}';
    }
}

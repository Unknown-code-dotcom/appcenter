// TOP SECRET
package com.afmobi.palmplay.configs.v6_3;

/**
 * Created by zz on 2016/11/7.
 */
public class FeaturedType {

    /**  this type only use for adapter ItemViewType */
    public static final String EMPTY = "Empty";

    public static final String HOME = "HOME";

    public static final String COLLECTION = "COLLECTION"; //推荐合集

    public static final String TOOL = "TOOL";


    public static final String APP = "APP";

    public static final String GAME = "GAME";

    public static final String INSTANT = "INSTANT";

    /**
     * design from service interface
     */
    private String typeName;

    /**
     * design from user
     */
    private int typeValue;

    FeaturedType(String typeName, int typeValue){
        this.typeName = typeName;
        this.typeValue = typeValue;
    }

    public String getTypeName(){
        return typeName;
    }

    public int getTypeValue(){
        return typeValue;
    }
}

// TOP SECRET
package com.afmobi.palmplay.category.v6_3;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseEventFragment;
import com.afmobi.palmplay.cache.v6_0.RankCache;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.main.utils.LanguageChangeUIStateUtil;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil.UINetworkErrorOnClickListener;
import com.afmobi.palmplay.main.utils.UINetworkUnconnectedUtil;
import com.afmobi.palmplay.main.v6_7.NetworkChangeListener;
import com.afmobi.palmplay.manager.Code;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.TagItemList;
import com.afmobi.palmplay.viewmodel.baseFeatures.BaseFeaturesNavigator;
import com.afmobi.palmplay.viewmodel.baseFeatures.BaseFeaturesViewModel;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.Constant;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.trans.common.netstate.AppNetState;
import com.trans.common.netstate.NetTypeKt;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.FragmentCommonTypeMoreXrecyviewBinding;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;

import xyz.doikki.videoplayer.util.PlayerUtils;

abstract public class BaseFeaturesFragment<T> extends BaseEventFragment implements OnViewLocationInScreen, OnClickListener, BaseFeaturesNavigator {

    protected UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();
    protected UINetworkErrorUtil mUINetworkErrorUtil = UINetworkErrorUtil.create();
    protected UINetworkUnconnectedUtil mNetworkUnconnectedUi = UINetworkUnconnectedUtil.create();

    protected boolean isRequesting = false;
    protected CustomDialog mProductInvalidDialog;

    protected boolean isOnRefreshing;

    protected LinearLayout viewRoot;
    protected BaseFeaturesViewModel mBaseFeaturesViewModel;

    abstract protected void refreshData();

    abstract protected String getTabType();

    private boolean isFirstActivity = true;

    protected FragmentCommonTypeMoreXrecyviewBinding mFragmentCommonTypeMoreXrecyviewBinding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBaseFeaturesViewModel = ViewModelProviders.of(this).get(BaseFeaturesViewModel.class);
        mBaseFeaturesViewModel.setNavigator(this);
        mBaseFeaturesViewModel.initParams(this, mPageParamInfo);

        AppNetState.INSTANCE.getNetType().observe(this.getViewLifecycleOwner(), netType -> {
            if (NetTypeKt.connected(netType)) {
                if ((mNetworkUnconnectedUi != null && mNetworkUnconnectedUi.getVisibility() == View.VISIBLE) ||
                        (mUINetworkErrorUtil != null && mUINetworkErrorUtil.getVisibility() == View.VISIBLE)) {
                    networkErrorRetry();
                }
            }
        });
    }

    protected void request() {
        isRequesting = true;

        mBaseFeaturesViewModel.requestUrl();

        if (mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview != null) {
            mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setEmptyView(null);
        }


        if (mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot != null) {
            mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot.setVisibility(View.GONE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mFragmentCommonTypeMoreXrecyviewBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_common_type_more_xrecyview, container, false);
        viewRoot = (LinearLayout) mFragmentCommonTypeMoreXrecyviewBinding.getRoot();

        mBaseFeaturesViewModel.initView();

        return viewRoot;
    }

    /**
     * 空态页居中显示
     */
    private void setEmptyViewCenter() {
        int height = DisplayUtil.getScreenHeight(getContext());
        int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.empty_view_height);
        int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
        int halfMarginTop = (height - emptyLayoutHeight) / 2;
        int statusBarHeight = (int) PlayerUtils.getStatusBarHeight(getContext());
        int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight;
        if (finalMarginTop <= 0) {
            finalMarginTop = 0;
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot.getLayoutParams();
        params.topMargin = finalMarginTop;
        mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot.setLayoutParams(params);
    }


    @Override
    public void initBaseFeaturesView() {
        setEmptyViewCenter();
        mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailDownload.setOnClickListener(this);
        mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailBack.setOnClickListener(this);
        mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layoutTitleRightSearch.setOnClickListener(this);

        mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.tvContent.setText(R.string.no_related_resource);

        mUILoadingGifUtil.inflate(getActivity(), viewRoot);
        mUINetworkErrorUtil.inflate(getActivity(), viewRoot, true)
                .setFrom(mBaseFeaturesViewModel.getFrom())
                .setVisibility(View.GONE)
                .setNetworkConfigureVisibility(View.GONE)
                .setUINetworkErrorOnClickListener(new UINetworkErrorOnClickListener() {

                    @Override
                    public void onUINetworkErrorClick(View v) {
                        if (v == null)
                            return;
                        if (v.getId() == R.id.tv_retry) {
                            //networkErrorRetry();
                        } else if (v.getId() == R.id.tv_setting) {
                            SysUtils.openSystemMobileNetworkSettings(getActivity(), TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
                        }
                    }
                });

        mNetworkUnconnectedUi.inflate(getActivity(), viewRoot, true)
                .setFrom(mBaseFeaturesViewModel.getFrom())
                .setVisibility(View.GONE)
                .setUINetworkErrorOnClickListener(new UINetworkUnconnectedUtil.UINetworkErrorOnClickListener() {

                    @Override
                    public void onUINetworkErrorClick(View v) {
                        if (v == null){
                            return;
                        }
                        if (v.getId() == R.id.tv_setting) {
                            SysUtils.openSystemMobileNetworkSettings(getActivity(), TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
                        }
                    }
                });

        TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setLayoutManager(linearLayoutManager);
        mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
        mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setLoadingListener(mXRecyclerViewLoadingListener);
        mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setPullRefreshEnabled(false);

        mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.isHeaderRefreshLayoutLimitHeight(true);

//            addNoMore(mXRecyclerView,linearLayoutManager,appBarLayout);

        if (!isRequesting)
            mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setEmptyView(mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot);
    }

    private void networkErrorRetry() {
        mUINetworkErrorUtil.setVisibility(View.GONE);
        mNetworkUnconnectedUi.setVisibility(View.GONE);
        mUILoadingGifUtil.setVisibility(View.VISIBLE);
        request();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS) {
          //  networkErrorRetry();
        }
    }

    protected void init() {
        if (null != mBaseFeaturesViewModel.getDataList()) {
            mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailTitle.setText(RankCache.getInstance().getName(mBaseFeaturesViewModel.getCategoryID(), mBaseFeaturesViewModel.getRankID(), false));
            setHeaderView();
            if (mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot != null) {
                mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot.setVisibility(View.GONE);
            }

            mBaseFeaturesViewModel.setCurrentPageIndexLoadMore();

            refreshData();
            if (RankCache.getInstance().isPageLast(mBaseFeaturesViewModel.getCategoryID(), mBaseFeaturesViewModel.getRankID(), false)) {
                mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setNoMore(true);
            }

        } else {
            request();
            mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailBack.setImageResource(R.drawable.selector_title_img_back);
            mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.ivDownload.setImageResource(R.drawable.home_title_download_icon_selector);
            mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layoutTitleRightSearch.setImageResource(R.drawable.home_title_search_icon_selector);
            TRStatusBarUtil.setStatusBarTextColor(getActivity() == null ? null : getActivity().getWindow(), true);
        }
        mUILoadingGifUtil.setVisibility(isRequesting ? View.VISIBLE : View.GONE);
    }

    public void setHeaderView() {
        try {

            if (!isFirstActivity) {
                return;
            }
            isFirstActivity = false;


            TagItemList<?> tagItemList = RankCache.getInstance().getTagInfo(mBaseFeaturesViewModel.getCategoryID(), mBaseFeaturesViewModel.getRankID());
            String titleStr = tagItemList == null ? "" : tagItemList.name;
            mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailTitle.setText(titleStr);
        } catch (Exception e) {
            LogUtils.e(e);
        }
    }


    protected XRecyclerView.LoadingListener mXRecyclerViewLoadingListener = new XRecyclerView.LoadingListener() {
        @Override
        public void onRefresh() {
            if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                mBaseFeaturesViewModel.callShowPopupWindow.postValue(true);
                //ToastManager.getInstance().show(getActivity(), R.string.tip_no_network);
                if (mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview != null) {
                    mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.refreshComplete();
                }
                return;
            }
            isOnRefreshing = true;
            mBaseFeaturesViewModel.resetCurrentPageIndex();
            request();
        }

        @Override
        public void onLoadMore() {
            if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                mBaseFeaturesViewModel.callShowPopupWindow.postValue(true);
                if (mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview != null) {
                    mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.loadMoreComplete();
                }
                return;
            }

            mBaseFeaturesViewModel.setCurrentPageIndexLoadMore();
            request();
        }
    };


    @Override
    public void onResume() {
        super.onResume();
        if (!isRequesting) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }
        setUpdatedAppCount();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview != null) {
            mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.loadMoreComplete();
            mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.refreshComplete();
        }
        mXRecyclerViewLoadingListener = null;
    }


    protected void setUpdatedAppCount() {
        TRHomeUtil.refreshAppCount(mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.tvDownloadingCount,
                mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.downloadingAnimView);
    }

    @Override
    public void onClick(View v) {
        if (v == null)
            return;
        switch (v.getId()) {
            case R.id.layout_title_back:
            case R.id.layot_detail_back:
                getActivity().finish();
                backButtonPressed();
                break;

            case R.id.layot_detail_download:
                TRJumpUtil.into(getActivity(), false, mPageParamInfo, TRStringUtil.generateString(TRAnalyticsConstant.MORE_PAGE, "", "", ""));
                break;
            case R.id.layout_title_right_search:
                TRJumpUtil.switchToSearchActivity(getActivity(), getTabType(), "", false, "", false,
                        "", mPageParamInfo, TRStringUtil.generateString(TRAnalyticsConstant.MORE_PAGE, "", "", ""), TRAnalyticsConstant.BUTTON_SEARCH_IMG);
                break;
            default:
                break;
        }
    }

    protected abstract void backButtonPressed();

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        super.onEventMainThread(mEventMainThreadEntity);
        if (mEventMainThreadEntity.getAction().equals(mBaseFeaturesViewModel.getNetworkActionWithID())) {

            synchronized (LanguageChangeUIStateUtil.lock) {
                isRequesting = false;

                if (isOnRefreshing) {
                    mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.refreshComplete();
                } else {
                    mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.loadMoreComplete();
                }

                isOnRefreshing = false;
                mUILoadingGifUtil.setVisibility(View.GONE);

                if (mEventMainThreadEntity.isSuccess) {

                    String mFromPage = mBaseFeaturesViewModel.getFromPage();

                    if (mEventMainThreadEntity.getInt("code", 0) == Code.CODE_506_NEGATIVE
                            && !TextUtils.isEmpty(mFromPage) && (mFromPage.equals(FromPageType.Message) || mFromPage.equals(FromPageType.Notify))) {
                        mUINetworkErrorUtil.setVisibility(View.VISIBLE);
                        // showDialog
                        if (mProductInvalidDialog != null) {
                            mProductInvalidDialog.dismiss();
                            mProductInvalidDialog = null;
                        }
                        if (mProductInvalidDialog == null)
                            mProductInvalidDialog = new CustomDialog(getActivity());
                        mProductInvalidDialog.setCancelable(false);
                        mProductInvalidDialog.showAppDetailProductInvalidDialog(getActivity().getString(R.string.content_expired), new OnClickListener() {

                            @Override
                            public void onClick(View v) {
                                getActivity().finish();
                            }
                        });
                        return;
                    }

                    if (mBaseFeaturesViewModel.getDataList() != null && mBaseFeaturesViewModel.getDataList().size() > 0) {
                        if (RankCache.getInstance().isPageLast(mBaseFeaturesViewModel.getCategoryID(), mBaseFeaturesViewModel.getRankID(), false)) {
                            mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setNoMore(true);
                        } else {
                            mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.loadMoreComplete();
                        }
                        refreshData();
                        setHeaderView();
                    }

                    mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setEmptyView(mFragmentCommonTypeMoreXrecyviewBinding.includeEmptyView.layoutEmptyViewRoot);
                } else {

                    if (null != mBaseFeaturesViewModel.getDataList() && !mBaseFeaturesViewModel.getDataList().isEmpty()) {
                        CommonUtils.showToastInfo(getActivity(), null);
                    } else {
                        mUINetworkErrorUtil.setVisibility(View.VISIBLE);
//                        if(NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
//                            mUINetworkErrorUtil.setVisibility(View.VISIBLE);
//                        } else {
//                            mNetworkUnconnectedUi.setVisibility(View.VISIBLE);
//                        }
                    }

                }
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_REFRESH_TAB_RED_POINT)) {//刷新角标
            setUpdatedAppCount();
        }
    }


    /****************************
     * for animation start
     *********************************/
    @Override
    public Object onPreparedCallback(Object obj) {
        return obj;
    }

    @Override
    public Object getObject(Object obj) {
        return mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailDownload;
    }

    @Override
    public int[] onEndTranslateAnimationLocationOnScreen(Object obj) {
        int[] endTranslateAnimationLocationOnScreen = new int[2];
        mFragmentCommonTypeMoreXrecyviewBinding.includeTitle.layotDetailDownload.getLocationOnScreen(endTranslateAnimationLocationOnScreen);
        return endTranslateAnimationLocationOnScreen;
    }

    @Override
    public Object onAnimationEndCallback(Object obj) {
        return obj;
    }

    /**************************** for animation end *********************************/
}

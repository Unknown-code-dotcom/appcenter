package com.afmobi.palmplay.cloudfolder.recently

import android.os.Bundle
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.transsion.palmstorecore.analytics.TRAnalyticsManager
import com.transsion.palmstorecore.log.LogUtils
import org.json.JSONArray
import org.json.JSONObject

object RecentlyInstalledTracker {

    private const val TAG = "RecentlyInstalled"

    private const val TID = 1044
    private const val EVENT_NAME = "cloud_re_act"
    private const val ETYPE = 10446002L

    // 技术埋点（按需开启）：用于排查拉活场景损耗，与业务事件 tid 不同
    private const val TECH_TID = 1044
    private const val TECH_EVENT_NAME = "cloud_re_act_tech"

    private const val ACTION_SHOW = "show"
    private const val ACTION_CLICK = "click"
    private const val ACTION_FILTER = "filter"
    private const val ACTION_INSERT = "insert"
    private const val ACTION_REMOVE = "remove"

    /** Filter reason 取值（与 helper 内过滤分支一一对应） */
    const val REASON_UNINSTALLED = "uninstalled"
    const val REASON_OPENED = "opened"
    const val REASON_NO_LAUNCH_INTENT = "no_launch_intent"
    const val REASON_OVER_50_DAYS = "over_50_days"

    private const val KEY_ETYPE = "etype"
    private const val KEY_ACTION = "action"
    private const val KEY_SHOW_COUNT = "show_count"
    private const val KEY_UNACTIVATED_TOTAL = "unactivated_total"
    private const val KEY_PKG_LIST = "pkg_list"
    private const val KEY_PKG = "pkg"
    private const val KEY_SRC = "from"
    private const val KEY_POSITION = "position"
    private const val KEY_CATEGORY_TYPE = "category_type"
    private const val KEY_FILTER_REASON = "filter_reason"
    private const val KEY_INSTALLED_TIME = "installed_time"
    private const val KEY_LAST_TIME_USED = "last_time_used"
    private const val KEY_DATE = "date"
    private const val KEY_REMOVE_REASON = "remove_reason"

    /**
     * 展示上报：单次场景展示触发 1 次。
     * 空列表（退化到 CDN 底栏）不上报，调用方需自行判断。
     */
    fun reportShow(
        shownList: List<CloudAppInfo>,
        unactivatedTotal: Int,
        categoryType: Int
    ) {
        if (shownList.isEmpty()) return
        val bundle = Bundle().apply {
            putString(KEY_ETYPE, ETYPE.toString())
            putString(KEY_ACTION, ACTION_SHOW)
            putInt(KEY_SHOW_COUNT, shownList.size)
            putInt(KEY_UNACTIVATED_TOTAL, unactivatedTotal)
            putInt(KEY_CATEGORY_TYPE, categoryType)
            putString(KEY_PKG_LIST, buildPkgListJson(shownList))
        }
        post(bundle,
            action = ACTION_SHOW,
            summary = "show_count=${shownList.size} unactivated_total=$unactivatedTotal")
    }

    /**
     * 点击上报：每次点击一个 item 触发 1 次。
     */
    fun reportClick(
        appInfo: CloudAppInfo,
        position: Int,
        categoryType: Int
    ) {
        val src = appInfo.installFromPage.orEmpty()
        val bundle = Bundle().apply {
            putString(KEY_ETYPE, ETYPE.toString())
            putString(KEY_ACTION, ACTION_CLICK)
            putString(KEY_PKG, appInfo.packageName)
            putString(KEY_SRC, src)
            putInt(KEY_POSITION, position)
            putInt(KEY_CATEGORY_TYPE, categoryType)
        }
        post(bundle,
            action = ACTION_CLICK,
            summary = "pkg=${appInfo.packageName} src=$src position=$position")
    }

    /**
     * 技术埋点 · 存入：新表写入一条新记录时触发。
     * 字段：pkg / date(存入时间戳) / from(场景码 = fromPage)
     */
    fun reportInsert(pkg: String?, fromPage: String?, insertedAt: Long) {
        if (pkg.isNullOrEmpty()) return
        val bundle = Bundle().apply {
            putString(KEY_ETYPE, ETYPE.toString())
            putString(KEY_ACTION, ACTION_INSERT)
            putString(KEY_PKG, pkg)
            putString(KEY_SRC, fromPage.orEmpty())
            putLong(KEY_DATE, insertedAt)
        }
        post(
            bundle = bundle,
            action = ACTION_INSERT,
            summary = "pkg=$pkg from=$fromPage date=$insertedAt",
            tid = TECH_TID,
            event = TECH_EVENT_NAME
        )
    }

    /**
     * 技术埋点 · 移除：新表删除一条记录时触发。
     * 字段：pkg / date(移除时间戳) / remove_reason
     * @param reason REASON_UNINSTALLED / REASON_OPENED / REASON_NO_LAUNCH_INTENT / REASON_OVER_50_DAYS
     */
    fun reportRemove(pkg: String?, reason: String, removedAt: Long = System.currentTimeMillis()) {
        if (pkg.isNullOrEmpty()) return
        val bundle = Bundle().apply {
            putString(KEY_ETYPE, ETYPE.toString())
            putString(KEY_ACTION, ACTION_REMOVE)
            putString(KEY_PKG, pkg)
            putString(KEY_REMOVE_REASON, reason)
            putLong(KEY_DATE, removedAt)
        }
        post(
            bundle = bundle,
            action = ACTION_REMOVE,
            summary = "pkg=$pkg reason=$reason date=$removedAt",
            tid = TECH_TID,
            event = TECH_EVENT_NAME
        )
    }

    /**
     * pkg_list 序列化为 [{"pkg":"com.x.a","src":"<原始 fromPage>"}, ...]
     * src 直接透传新表里的 fromPage（如 "FL_A_BOTTOM_NEW_0" / "H_REC_..."），由数仓端按规则分维度。
     */
    private fun buildPkgListJson(list: List<CloudAppInfo>): String {
        val arr = JSONArray()
        for (info in list) {
            val pkg = info.packageName ?: continue
            arr.put(JSONObject().apply {
                put(KEY_PKG, pkg)
                put(KEY_SRC, info.installFromPage.orEmpty())
            })
        }
        return arr.toString()
    }

    private fun post(bundle: Bundle, action: String, summary: String, tid: Int = TID, event: String = EVENT_NAME) {
        try {
            TRAnalyticsManager.getmInstance().postFixedEvent(tid, event, bundle)
            if (LogUtils.debug) {
                LogUtils.i(TAG, "【埋点·$action】tid=$tid event=$event etype=$ETYPE $summary")
            }
        } catch (e: Throwable) {
            LogUtils.e(TAG, e)
        }
    }
}

package com.afmobi.palmplay.activate;

import android.app.Activity;
import android.content.DialogInterface;
import android.view.View;

import com.afmobi.palmplay.dialog.OfflineMoreGuideDialog;
import com.afmobi.palmplay.dialog.TRDialogShowInterface;
import com.afmobi.palmplay.model.v6_5.MarketEventInfo;

/***
 * created by yongli.li
 * 独立业务执行者的基类
 */
public class TRBaseExecutor<T> implements TRDialogShowInterface<T> {
    @Override
    public  void loadData() {

    }

    @Override
    public void parseData(T data) {

    }

    @Override
    public void cacheData(T data) {

    }

    @Override
    public Object getData() {
        return null;
    }

    @Override
    public void callbackShow(String activateType, String subActivateType) {

    }

    @Override
    public Object getSubActivateData(String subActivateType) {
        return null;
    }

    @Override
    public boolean show(String fromType) {
        return false;
    }


    public boolean show(String fromType, Activity  activity) {
        return false;
    }

    public boolean show(String fromType, String from, Activity activity) {return false;}

    public boolean show(String fromType, Activity  activity, int y) {
        return false;
    }

    public boolean show(String fromType, Activity  activity, boolean isShowGuide, DialogInterface.OnDismissListener listener) {
        return false;
    }

    public boolean show(String fromType, Activity  activity, View.OnClickListener clickListener, DialogInterface.OnDismissListener listener) {
        return false;
    }

    public boolean show(String fromType, Activity  activity, DialogInterface.OnShowListener showListener, DialogInterface.OnKeyListener keyListener) {
        return false;
    }

    public boolean show(String fromType, Activity  activity, OfflineMoreGuideDialog.OnDialogBtnClickListener listener, boolean isR2L, int[] location) {
        return false;
    }

    public boolean dismiss() {
        return false;
    }

    @Override
    public boolean isShowing() {
        return false;
    }

    @Override
    public boolean isCanShow(String fromType) {
        return false;
    }

    public Object getActivateData() {
        return null;
    }
    public void updateTipAfterShow(MarketEventInfo item, boolean isPreload){
    }
    public void onClear() {}
    public boolean showOthers(){return false;}
    public boolean isPromptTip(){return false;}
}

package com.afmobi.palmplay.category;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.afmobi.palmplay.model.v6_0.TagItem;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

public class DetailTagAdapter extends RecyclerView.Adapter {

    private Context mContext;
    private List<TagItem> mList = new ArrayList<>();
    private onDetailTagClickListener mListener;
    private int mSpace = 16;

    public DetailTagAdapter(Context context, List<TagItem> list) {
        this.mContext = context;
        this.mSpace = context.getResources().getDimensionPixelSize(R.dimen.app_detail_margin_start);
        setTagList(list);
    }

    public void setTagList(List<TagItem> list) {
        if(list != null && list.size() > 0) {
            this.mList.clear();
            this.mList.addAll(list);
        }
    }

    public void setDetailTagClickListener(onDetailTagClickListener l) {
        this.mListener = l;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_detail_tag_list_item, viewGroup, false);
        return new DetailTagViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        TagItem item = getItemByPosition(i);
        if(item != null && viewHolder instanceof DetailTagViewHolder) {
            DetailTagViewHolder holder = (DetailTagViewHolder)viewHolder;

            RecyclerView.LayoutParams mImageView_param = (RecyclerView.LayoutParams)holder.tv_tag_name.getLayoutParams();
            if (i == 0) {
                mImageView_param.leftMargin = mSpace;
                mImageView_param.setMarginStart(mSpace);
            }

            String tag = "#" + item.getNameValue();
            holder.tv_tag_name.setText(tag);
            holder.tv_tag_name.setTag(item);
            holder.tv_tag_name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener != null) {
                        mListener.onDetailTagClick(v);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        if(mList == null) {
            return 0;
        }
        return this.mList.size();
    }

    public TagItem getItemByPosition(int position) {
        if(position < 0 || position >= getItemCount()) {
            return null;
        }
        return mList.get(position);
    }

    class DetailTagViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_tag_name;
        public DetailTagViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_tag_name = (TextView) itemView.findViewById(R.id.tv_tag_name);
        }
    }

    public interface onDetailTagClickListener {
        public void onDetailTagClick(View v);
    }
}

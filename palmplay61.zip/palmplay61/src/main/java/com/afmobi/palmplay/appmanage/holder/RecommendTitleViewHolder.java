package com.afmobi.palmplay.appmanage.holder;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * 推荐内容标题
 * Created by xiangfei.wei on 2018/12/24.
 */
public class RecommendTitleViewHolder extends RecyclerView.ViewHolder {
    public RecommendTitleViewHolder(@NonNull View itemView) {
        super(itemView);
    }

    public void bind() {

    }
}

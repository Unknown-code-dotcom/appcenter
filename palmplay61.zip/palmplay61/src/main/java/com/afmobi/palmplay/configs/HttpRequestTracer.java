// TOP SECRET
package com.afmobi.palmplay.configs;


public class HttpRequestTracer {
	
	private String mRequestAction;

	private int mRequestCount;
	
	private String mHttpRequestState = HttpRequestState.requestNone;
	
	public HttpRequestTracer(String requestAction){
		this.mRequestAction = requestAction;
	}
	
//	public boolean isRequestNone(){
//		return mHttpRequestState == HttpRequestState.requestNone;
//	}
	
	public boolean isRequesting(){
		return HttpRequestState.requesting.equals(mHttpRequestState);
	}
	
	public boolean isRequstSuccess(){
		return HttpRequestState.requestSuccess.equals(mHttpRequestState);
	}
	
	public boolean isRequestFailure(){
		return HttpRequestState.requestFailure.equals(mHttpRequestState);
	}
	
	public void nextRequest(){
		mRequestCount ++;
		mHttpRequestState = HttpRequestState.requestNone;
	}

//	public String getRequestAction() {
//		return mRequestAction;
//	}
//
//	public void setRequestAction(String mRequestAction) {
//		this.mRequestAction = mRequestAction;
//	}
//
	public int getRequestCount() {
		return mRequestCount;
	}
//
//	public void setRequestCount(int mRequestCount) {
//		this.mRequestCount = mRequestCount;
//	}
//
//	public HttpRequestState getHttpRequestState() {
//		return mHttpRequestState;
//	}

	public void setHttpRequestState(String mHttpRequestState) {
		this.mHttpRequestState = mHttpRequestState;
	}

	public void addRequestCount(){
		mRequestCount ++;
	}

}

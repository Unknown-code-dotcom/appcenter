package com.afmobi.palmplay.activitycenter;


import java.io.Serializable;
import java.util.List;

public class ActivityCenterBean  implements Serializable {


    private String loadTimeInterval;
    private String reloadTimeInterval;

    public String getLoadTimeInterval() {
        return loadTimeInterval;
    }

    public void setLoadTimeInterval(String loadTimeInterval) {
        this.loadTimeInterval = loadTimeInterval;
    }

    public String getReloadTimeInterval() {
        return reloadTimeInterval;
    }

    public void setReloadTimeInterval(String reloadTimeInterval) {
        this.reloadTimeInterval = reloadTimeInterval;
    }

    private List<ACBean> activityCenterList;

    public List<ACBean> getActivityCenterList() {
        return activityCenterList;
    }

    public ActivityCenterBean(List<ACBean> activityCenterList) {
        this.activityCenterList = activityCenterList;
    }

    public void setActivityCenterList(List<ACBean> activityCenterList) {
        this.activityCenterList = activityCenterList;
    }


}

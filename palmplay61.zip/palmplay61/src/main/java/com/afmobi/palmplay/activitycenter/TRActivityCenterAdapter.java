package com.afmobi.palmplay.activitycenter;

import android.app.Activity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.activate.TRManager;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.ViewExtKt;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ItemActivityCenterBigImgBinding;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

public class TRActivityCenterAdapter extends RecyclerView.Adapter<TRActivityCenterAdapter.ViewItemHolder> {
    private Activity mActivity;
    private List<ACBean> acBeanList = new ArrayList<>();
    private PageParamInfo mPageParamInfo;
    private String mScreenPageName;

    private String subPlace="";
    private String model="";
    public String getScreenPageName() {
        return mScreenPageName;
    }

    public TRActivityCenterAdapter setScreenPageName(String mScreenPageName) {
        this.mScreenPageName = mScreenPageName;
        return this;
    }
    private String mFrom;
    private String fromPage;
    private String mValue;
    private String topicId="";

    public String getTopicId() {
        return topicId;
    }

    public void setTopicId(String topicId) {
        this.topicId = topicId;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getSubPlace() {
        return subPlace;
    }

    public void setSubPlace(String subPlace) {
        this.subPlace = subPlace;
    }

    public TRActivityCenterAdapter setPageParamInfo(PageParamInfo paramInfo) {
        this.mPageParamInfo = paramInfo;
        return this;
    }
    public String getFromPage() {
        return fromPage;
    }

    public void setFromPage(String fromPage) {
        this.fromPage = fromPage;
    }

    public String getValue() {
        return mValue;
    }

    public void setValue(String mValue) {
        this.mValue = mValue;
    }

    public String getFrom() {
        return mFrom;
    }

    public void setFrom(String mFrom) {
        this.mFrom = mFrom;
    }

    public TRActivityCenterAdapter(Activity mActivity, List<ACBean> list) {
        this.mActivity = mActivity;
        if (list != null) {
            this.acBeanList.clear();
            this.acBeanList.addAll(list);
        }
    }

    @Override
    public ViewItemHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mActivity);
        ItemActivityCenterBigImgBinding binding = DataBindingUtil.inflate(inflater, R.layout.item_activity_center_big_img, viewGroup, false);
        return new ViewItemHolder(binding);
    }

    @Override
    public void onBindViewHolder(ViewItemHolder holder, int position) {
        ACBean bean = getItemByPosition(position);
        holder.bind(bean,position);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public ACBean getItemByPosition(int pos) {
        if (pos < 0 || pos >= getItemCount()) {
            return null;
        }

        return acBeanList.get(pos);
    }

    public void setData(List<ACBean> list) {
        acBeanList.clear();
        if (list != null) {
            acBeanList.addAll(list);
        }
        notifyDataSetChanged();
    }

    public List<ACBean> getAcBeanList() {
        return acBeanList;
    }

    @Override
    public int getItemCount() {
        return acBeanList == null ? 0 : acBeanList.size();

    }

    public class ViewItemHolder extends RecyclerView.ViewHolder {
        ItemActivityCenterBigImgBinding mBinding;
        public ViewItemHolder(@NonNull ItemActivityCenterBigImgBinding rootView) {
            super(rootView.getRoot());
            mBinding=rootView;
        }

        public void bind(ACBean acBean,int position) {
            mValue = TRStringUtil.generateString(mScreenPageName, model, subPlace, String.valueOf(position));
            mBinding.tvItemName.setText(acBean.getActivityName());
            GlideUtils.setImageUrl(mBinding.ivIcon, acBean.getImgUrl(), R.drawable.default_banner,R.drawable.default_banner);
            mBinding.ivIcon.setOnClickListener(v->onClick(acBean,0,position));
            mBinding.tvItemName.setOnClickListener(v->onClick(acBean,1,position));
            mBinding.btnGet.setOnClickListener(v->onClick(acBean,2,position));
//            if (TRApplicationContextUtil.isProject()) {
//                mBinding.cardView.setCardElevation(0f);
//                mBinding.cardView.setMaxCardElevation(0f);
//                mBinding.cardView.setBackground(null);
//                ViewExtKt.clipRadius(mBinding.cardView, NotificationExtKt.getDp(12));
//            }

            //曝光埋点
            if (!acBean.isTrack){
                acBean.isTrack=true;
                ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
                builder.setValue(mValue)
                        .setFrom(mFrom)
                        .setTopicType(acBean.getCategory())
                        .setTopicId(topicId)
                        .setItemType("")
                        .setItemId(acBean.getId())
                        .setItemValue("");
                TRAnalysticsUtil.trackExposure(builder);
            }


        }

        private void onClick(ACBean acBean, int type,int position){
            mValue = TRStringUtil.generateString(mScreenPageName, model, subPlace, String.valueOf(position));
            if(mPageParamInfo!=null){
               acBean.setmCurPage(mPageParamInfo.getCurPage());
               acBean.setmLastPage(mPageParamInfo.getLastPage());
           }
           acBean.setmValue(mValue);
            if (acBean != null && !TextUtils.isEmpty(acBean.getId())) {
                ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                builder.setValue(mValue)
                        .setFrom(mFrom)
                        .setTopicId(topicId)
                        .setFromPage(fromPage)
                        .setItemId(acBean.getId())
                        .setButtonType(String.valueOf(type));
                TRAnalysticsUtil.trackClick(builder);
                //点击跳转
                TRManager.getInstance().
                        dispatchEvent(TRActivateConstant.ACTIVITY_CENTER_TAB, acBean);
            }
        }
    }
}

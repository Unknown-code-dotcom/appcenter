package com.afmobi.palmplay.cloudfolder.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.utils.CREATE_SHORTCUT
import com.afmobi.palmplay.cloudfolder.utils.CREATE_SHORTCUT_ID
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.transsion.phonehelper.util.LogUtils

class CloudFolderShortcutReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        intent?.let {
            val isCreate = it.getBooleanExtra(CREATE_SHORTCUT, false)
            val shortcutId = it.getStringExtra(CREATE_SHORTCUT_ID)


            if(isCreate) {
                val folderType = if(FOLDER.APPS.shortcutId == shortcutId) {
                    FOLDER.APPS
                } else if(FOLDER.GAMES.shortcutId == shortcutId) {
                    FOLDER.GAMES
                } else {
                    null
                }
                folderType?.let { folderType->
                    CloudFolderManager.getInstance().refreshFolderIcon(folderType, false)
                }
            }
            LogUtils.d("CloudFolderManager", "onReceive: $isCreate -  $shortcutId")

        }
    }
}
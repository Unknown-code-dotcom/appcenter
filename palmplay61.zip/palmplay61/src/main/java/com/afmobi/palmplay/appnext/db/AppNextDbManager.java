package com.afmobi.palmplay.appnext.db;

import com.afmobi.palmplay.PalmplayApplication;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.util.List;

/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 16:07
 * @Desc: add your description
 */
public class AppNextDbManager {

    private static final String TAG = "AppNext";

    public static List<AppNextCache> getAppNextCacheList() {
        try {
            List<AppNextCache> list = AppNextDataBase.getDatabase(PalmplayApplication.getAppInstance()).getAppNextCacheDao().getAppNextCacheList();
            return list;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return null;
    }

    public static void deleteCacheByPkg(String packageNameWithAction) {
        LogUtils.d(TAG, " AppNextDbManager deleteCacheByPkg " + packageNameWithAction);
        try {
            AppNextDataBase.getDatabase(PalmplayApplication.getAppInstance()).getAppNextCacheDao().deleteByPkg(packageNameWithAction);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    public static void updateAppNextCache(AppNextCache appNextCache) {
        try {
            AppNextDataBase.getDatabase(PalmplayApplication.getAppInstance()).getAppNextCacheDao().update(appNextCache);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    public static void saveAppNextCache(String packageNameWithAction, String reportUrl) {
        AppNextCache appNextCache = new AppNextCache();
        appNextCache.setPackageNameWithAction(packageNameWithAction);
        appNextCache.setReportUrl(reportUrl);
        try {
            AppNextDataBase.getDatabase(PalmplayApplication.getAppInstance()).getAppNextCacheDao().insert(appNextCache);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }
}

package com.afmobi.palmplay.appdetail.holder;

import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;
import com.afmobi.palmplay.social.whatsapp.utils.SystemUiUtils;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.PaletteHelper;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.callback.TRBitmapDownloadListener;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import java.io.File;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.palette.graphics.Palette;

public class AppDetailsIconHolder extends BaseAppDetailHolder implements Palette.PaletteAsyncListener {

    private String mIconUrl;
    private boolean isUseSmallCache;
    private MutableLiveData<Integer> mColorLiveData = new MutableLiveData<>();

    public AppDetailsIconHolder(FragmentActivity activity, TRNewAppViewModel mAppDetailModel, CommonAppDetailView commonAppDetailView) {
        super(activity, mAppDetailModel, commonAppDetailView);
    }

    @Override
    public void initHolder() {
        initView();

        initIconShow();

        mColorLiveData.observe(mActivity, new Observer<Integer>() {
            @Override
            public void onChanged(Integer integer) {
                onFetchIconColor(integer);
            }
        });
    }

    private void initView(){
        ViewGroup.MarginLayoutParams vaFlagViewLayoutParams = (ViewGroup.MarginLayoutParams) commonAppDetailView.headerViewBinding.vaFlag.getLayoutParams();
        int vaFlagMarginStart;
        if (mActivity.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
            // 原边距+底图ICON宽度-闪电标宽度 => 16.3+67-24
            vaFlagMarginStart = SystemUiUtils.dp2Px(59.3f, TRApplicationContextUtil.getInstance());
        } else {
            vaFlagMarginStart = SystemUiUtils.dp2Px(16.3f, TRApplicationContextUtil.getInstance());
        }
        vaFlagViewLayoutParams.setMarginStart(vaFlagMarginStart);
    }

    public void setUseSmallCache(boolean useSmallCache) {
        isUseSmallCache = useSmallCache;
    }

    public void initIconShow(){
        if (TRStringUtil.isBlank(mIconUrl)) {
            String url = (commonAppDetailView.mAppInfo == null) ? (String) mAppDetailModel.getParam("imgUrl") : commonAppDetailView.mAppInfo.iconUrl;
            mIconUrl = url;
        }
        if (!TRStringUtil.isBlank(mIconUrl)) {
            onIconShow();
            onPaletteColorFetch();
        }
    }

    private File getLocalIcon() {
        int supportOverlay = (Integer) mAppDetailModel.getParam(Constant.KV_SUPPORT_OVERLAY);
        String localIcon = (String) mAppDetailModel.getParam(Constant.KV_LOCAL_ICON);
        if (supportOverlay == 1 && !TextUtils.isEmpty(localIcon)) {
            File file = new File(localIcon);
            if (file != null && file.exists()) {
                return file;
            }
        }

        return null;
    }

    private void onIconShow() {
        int colorId = commonAppDetailView.isCustomizedStyle() ? R.color.detail_offer_img_border_color : R.color.img_border_color;
        int borderColor =  ContextCompat.getColor(mActivity, colorId);
        int corner = PalmplayApplication.getAppInstance().getResources().getDimensionPixelSize(R.dimen.dp_12);
        commonAppDetailView.headerViewBinding.ivIcon.setStrokeColor(CommonUtils.createColorStateList(borderColor));
        if (isUseSmallCache) {
            File file = getLocalIcon();
            if (file != null) {
                GlideUtils.setImageFileUriWithDefaultImage(commonAppDetailView.headerViewBinding.ivIcon, Uri.fromFile(file), R.drawable.layer_list_app_default_01_bg, R.drawable.layer_list_app_default_01_bg);
            } else {
                GlideUtils.setImageUriWithNoBorderSmall(commonAppDetailView.headerViewBinding.ivIcon, mIconUrl, corner, GlideUtils.newRoundBorderWithCornersRequestOptions(corner, borderColor), R.drawable.layer_list_app_default_01_bg, R.drawable.layer_list_app_default_01_bg);
            }
        }else {
            File file = getLocalIcon();
            if (file != null) {
                GlideUtils.setImageFileUriWithRadius(commonAppDetailView.headerViewBinding.ivIcon, Uri.fromFile(file));
            } else {
                GlideUtils.setImageUrl(commonAppDetailView.headerViewBinding.ivIcon, mIconUrl, GlideUtils.newRoundBorderWithCornersRequestOptions(corner, borderColor), R.drawable.layer_list_app_default_01_bg, R.drawable.layer_list_app_default_01_bg);
            }
        }
        commonAppDetailView.headerViewBinding.vaFlag.setVisibility(commonAppDetailView.mAppInfo != null && commonAppDetailView.mAppInfo.isVa ? View.VISIBLE : View.GONE);
    }

    public void onPaletteColorFetch() {
        String url = mIconUrl;
        File file = getLocalIcon();
        if (file != null) {
            url = file.getAbsolutePath();
        }

        TRBitmapManager.downloadImageByFresco(url, 0, 0, new TRBitmapDownloadListener() {
            @Override
            public void onSuccess(Bitmap bitmap) {
                if (mActivity.isFinishing() || mActivity.isDestroyed()) {
                    return;
                }

                if(bitmap != null && !bitmap.isRecycled()) {
                    Palette.from(bitmap).maximumColorCount(16).generate(AppDetailsIconHolder.this);
                }
            }

            @Override
            public void onError(Bitmap dataSource) {

            }
        });
    }

    @Override
    public void onGenerated(@Nullable Palette palette) {
        if(palette == null) {
            return;
        }

        Palette.Swatch sDominant = palette.getDominantSwatch();//独特的一种
        Palette.Swatch sVibrant = palette.getVibrantSwatch();       //获取到充满活力的这种色调

        Palette.Swatch swatch = (sVibrant != null) ? sVibrant : sDominant;
        if (swatch != null) {
            LogUtils.i(String.format("Palelle generated color by icon bitmap is:#%x", swatch.getRgb()));
            int color = swatch.getRgb();
            mColorLiveData.postValue(color);
        }
    }

    private void onFetchIconColor(Integer integer) {
        if(integer != null && !commonAppDetailView.isCustomizedStyle()) {
            float startPercent = 0.0f;
            float endPercent = 0.18f;
            int headH = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_head_bg_h);
            int tabH = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_tab_h);
            float headPercent = headH * endPercent/(headH + tabH);

            int sColor = PaletteHelper.getArgbByColor(integer, startPercent);
            int cColor = PaletteHelper.getArgbByColor(integer, (startPercent + headPercent)/2);
            int eColor = PaletteHelper.getArgbByColor(integer, headPercent);

            int tabStartColor = PaletteHelper.getArgbByColor(integer, headPercent);
            int tabCenterColor = PaletteHelper.getArgbByColor(integer, (headPercent+endPercent)/2);
            int tabEndColor = PaletteHelper.getArgbByColor(integer, endPercent);

            PaletteHelper.setGradientDrawable(commonAppDetailView.mBinding.vGradient, sColor, cColor, eColor, 0);
            PaletteHelper.setGradientDrawable(commonAppDetailView.mBinding.vTabBg, tabStartColor, tabCenterColor, tabEndColor, 0);

            onIconShow();
        }
    }
}

package com.afmobi.palmplay.alsoinstall;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author: zhiqiang.hao
 * @date: 2023/3/14 10:42
 * @Desc: add your description
 */
public class SafeRecyclerView extends RecyclerView implements LifecycleObserver {
    public SafeRecyclerView(@NonNull Context context) {
        super(context);
        init(context);
    }

    public SafeRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public SafeRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    private void init(Context context) {
        try {
            if (context instanceof LifecycleOwner) {
                ((LifecycleOwner) context).getLifecycle().addObserver(this);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy() {
        /*
         确保Adapter#onDetachedFromRecyclerView被调用
         */
        setAdapter(null);
    }

    @Override
    public void setLayoutManager(LayoutManager layoutManager) {
        super.setLayoutManager(layoutManager);
        try {
            if (layoutManager instanceof LinearLayoutManager) {
                /*
                确保Adapter#onViewDetachedFromWindow被调用
                 */
                ((LinearLayoutManager) layoutManager).setRecycleChildrenOnDetach(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

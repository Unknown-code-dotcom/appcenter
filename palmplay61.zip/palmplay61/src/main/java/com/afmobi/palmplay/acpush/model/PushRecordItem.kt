package com.afmobi.palmplay.acpush.model

import com.google.gson.annotations.SerializedName

/**
 * PM 通过 deliver_push 下发的单条推送记录。
 *
 * - appGrade 取值固定为 "S" / "A" / "OTHER"（仅 AC 更新场景有效）
 * - messageType: "AC_UPDATE" 或 "PUSH"
 * - priorityScore: S=100 / A=40 / OTHER=0
 *
 * AC 端**不**根据 record 本身组装 title/content/icon，
 * 而是基于 packageName 从 InstalledAppsUpdateCache 取 UpdateItem 渲染。
 */
data class PushRecordItem(
    @SerializedName("package_name")   val packageName: String,
    @SerializedName("message_type")   val messageType: String,
    @SerializedName("priority_score") val priorityScore: Int,
    @SerializedName("app_grade")      val appGrade: String,
    @SerializedName("source")         val source: String,
    @SerializedName("version_code")   val versionCode: Long
)

package com.afmobi.palmplay.az.attribution;

import com.transsion.athena.data.TrackData;
import com.transsion.ga.AthenaAnalytics;
import com.transsion.palmstorecore.log.LogUtils;

/**
 * AZ 场景拉活归因链路埋点（Athena 通道）
 *
 * EventID/TrackerID 待产品与数据同学确认，暂用 TODO_ 前缀 + placeholder int，
 * 联调阶段替换为正式值即可。
 */
public class AzAttrTracker {

    private static final String TAG = "AzAttrTracker";
    private static final String LOG_PREFIX = "[AZ_ATTR] ";

    private static final int TECH_TRACKER_ID = 1044;
    private static final String EVENT_NAME_TECH = "ac_az_click_tech";

    private static final int BUSINESS_TRACKER_ID = 1044;
    private static final String EVENT_NAME_BUSINESS = "ac_az_click";


    private static final String NODE_HUNDSUP_RECV  = "AZ_HUNDSUP_RECV";      // hundsup 归因数据接收
    private static final String NODE_AZ_POLL       = "AZ_POLL";              // AZ 拉包名列表
    private static final String NODE_AZ_CLICK_RECV = "AZ_CLICK_RECV";        // AZ 通知点击到达 AC
    private static final String NODE_REPORT_FILTERED = "AZ_REPORT_FILTERED"; // 上报被过滤（CD/上限/开关）


    /** 过滤原因常量 */
    public static final String REASON_DISABLED    = "disabled";       // 总开关关闭
    public static final String REASON_CD          = "cd";             // CD 未过
    public static final String REASON_NO_ITEM     = "no_item";        // 包不在拉活列表
    public static final String REASON_PKG_LIMIT   = "pkg_limit";      // 达到包上限

    private AzAttrTracker() {}

    /** hundsup 收到归因配置 */
    public static void trackHundsupRecv(int orderCount) {
        TrackData data = new TrackData();
        data.add("order_count", orderCount);
        safeTrackTech(NODE_HUNDSUP_RECV, data);
    }

    /** AZ 拉包名列表 */
    public static void trackAzPoll(String packages) {
        TrackData data = new TrackData();
        data.add("pck_list", packages == null ? "" : packages);
        safeTrackTech(NODE_AZ_POLL, data);
    }

    /** AZ 通知点击到达 AC */
    public static void trackClickRecv(String pkg, String clickId) {
        TrackData data = new TrackData();
        data.add("pck_name", pkg == null ? "" : pkg);
        data.add("c_id", clickId == null ? "" : clickId);
        safeTrackTech(NODE_AZ_CLICK_RECV, data);
    }

    /** AC 发出归因上报 */
    public static void trackReportSent(String pkg, String clickId) {
        TrackData data = new TrackData();
        data.add("pck_name", pkg == null ? "" : pkg);
        data.add("c_id", clickId == null ? "" : clickId);
        safeTrackBusiness(EVENT_NAME_BUSINESS, data);
    }

    /** 上报被过滤（含类型） */
    public static void trackReportFiltered(String pkg, String reason) {
        TrackData data = new TrackData();
        data.add("pkg", pkg == null ? "" : pkg);
        data.add("reason", reason == null ? "" : reason);
        safeTrackTech(NODE_REPORT_FILTERED, data);
    }

    private static void safeTrackTech(String node, TrackData data) {
        data.add("node", node);
        safeTrack("技术", TECH_TRACKER_ID, EVENT_NAME_TECH, data);
    }

    private static void safeTrackBusiness(String eventName, TrackData data) {
        safeTrack("业务", BUSINESS_TRACKER_ID, eventName, data);
    }

    private static void safeTrack(String trackerType, int trackerId, String eventName, TrackData data) {
        try {
            LogUtils.i(TAG, LOG_PREFIX + "准备上报Athena" + trackerType + "埋点，trackerId="
                    + trackerId + ", event=" + eventName + ", data=" + data);
            AthenaAnalytics.getInstance(trackerId).track(eventName, data, trackerId);
        } catch (Exception t) {
            LogUtils.d(TAG, LOG_PREFIX + "Athena" + trackerType + "埋点上报异常，trackerId="
                    + trackerId + ", event=" + eventName + ", error=" + t.getMessage());
        }
    }
}

package com.afmobi.palmplay.az.attribution;

import android.text.TextUtils;

import com.android.hundsup.data.model.bean.az.AzAttrConfigBean;
import com.android.hundsup.data.model.bean.az.AzAttrConfigConsumer;
import com.google.gson.reflect.TypeToken;
import com.tencent.mmkv.MMKV;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.GsonUtils;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * AZ 归因数据本地仓库（MMKV 存储，覆盖式写入）
 * 数据来源：hundsup 响应中的归因字段块（{@link #saveConfig(AzAttrConfigBean)}）
 * 存储结构（MMKV mmkvID = "az_attr"）：
 *  - az_config          String  AzAttrConfigBean JSON（覆盖式写入）
 *  - az_report_count    String  Map<String, Integer> JSON（包 → 已上报次数）
 *  - az_last_click      String  Map<String, Long>    JSON（包 → 上次点击时间戳）
 */
public class AzAttrRepository implements AzAttrConfigConsumer {

    private static final String TAG = "AzAttrRepository";
    private static final String LOG_PREFIX = "[AZ_ATTR] ";

    private static volatile AzAttrRepository sInstance;

    public static AzAttrRepository getInstance() {
        if (sInstance == null) {
            synchronized (AzAttrRepository.class) {
                if (sInstance == null) {
                    sInstance = new AzAttrRepository();
                }
            }
        }
        return sInstance;
    }


    public static void init() {
        AzAttrConfigConsumer.Registry.register(getInstance());
        LogUtils.i(TAG, LOG_PREFIX + "已注册为hundsup的AZ归因配置消费者");
    }


    @Override
    public void onConfigLoaded(AzAttrConfigBean config) {
        LogUtils.i(TAG, LOG_PREFIX + "收到hundsup下发配置，");
        saveConfig(config);
    }

    // 内存缓存，减少 JSON 反序列化开销；每次 saveConfig 会失效
    private volatile AzAttrConfigBean mConfigCache;
    private final Object mConfigLock = new Object();

    private MMKV getMmkv() {
        return MMKV.mmkvWithID(AzAttrConstants.MMKV_ID);
    }

    // ---------- hundsup 响应写入 ----------

    /**
     * 覆盖式保存归因配置。未在本次下发中出现的包名，其上报计数和上次点击记录一并清理
     */
    public void saveConfig(AzAttrConfigBean config) {
        if (config == null) {
            LogUtils.d(TAG, LOG_PREFIX + "保存配置跳过：config为空");
            return;
        }
        String json = GsonUtils.getInstance().toJson(config);
        getMmkv().encode(AzAttrConstants.K_CONFIG, json);
        synchronized (mConfigLock) {
            mConfigCache = config;
        }
        LogUtils.i(TAG, LOG_PREFIX + "保存配置成功，jsonLength=" + json.length()
                + ", " + buildConfigSummary(config));
        // 差集清理计数和 CD
        cleanStaleEntries(config);
        // 埋点：hundsup 收到归因配置
        AzAttrTracker.trackHundsupRecv(config.attributeModels == null ? 0 : config.attributeModels.size());
    }

    private void cleanStaleEntries(AzAttrConfigBean config) {
        if (config.attributeModels == null) {
            // 本次未下发任何包 → 清空所有历史计数和 CD
            getMmkv().remove(AzAttrConstants.K_REPORT_COUNT_MAP);
            getMmkv().remove(AzAttrConstants.K_LAST_CLICK_MAP);
            LogUtils.i(TAG, LOG_PREFIX + "本次无包名列表，已清空历史上报次数和点击CD记录");
            return;
        }
        java.util.Set<String> currentPkgs = new java.util.HashSet<>();
        for (AzAttrConfigBean.AzAttrItemBean item : config.attributeModels) {
            if (item != null && !TextUtils.isEmpty(item.pkg)) currentPkgs.add(item.pkg);
        }
        LogUtils.i(TAG, LOG_PREFIX + "清理过期包记录，仅保留keepPkgs=" + currentPkgs);
        retainPkgs(AzAttrConstants.K_REPORT_COUNT_MAP, currentPkgs, Integer.class);
        retainPkgs(AzAttrConstants.K_LAST_CLICK_MAP, currentPkgs, Long.class);
    }

    private <V> void retainPkgs(String key, java.util.Set<String> keep, Class<V> valueType) {
        Map<String, V> map = readMap(key, valueType);
        if (map.isEmpty()) return;
        int beforeSize = map.size();
        boolean changed = map.keySet().retainAll(keep);
        if (changed) {
            getMmkv().encode(key, GsonUtils.getInstance().toJson(map));
            LogUtils.i(TAG, LOG_PREFIX + "清理本地map完成，key=" + key + ", before=" + beforeSize
                    + ", after=" + map.size() + ", keep=" + keep);
        }
    }

    // ---------- 供 InfoContentProvider 消费 ----------

    /** 所有拉活包名，逗号分隔字符串 */
    public String getPackagesJoined() {
        AzAttrConfigBean config = getConfig();
        if (config == null || config.attributeModels == null || config.attributeModels.isEmpty()) return "";
        LinkedHashSet<String> packages = new LinkedHashSet<>();
        for (AzAttrConfigBean.AzAttrItemBean item : config.attributeModels) {
            if (item != null && !TextUtils.isEmpty(item.pkg)) packages.add(item.pkg);
        }
        StringBuilder sb = new StringBuilder();
        for (String pkg : packages) {
            if (sb.length() > 0) sb.append(',');
            sb.append(pkg);
        }
        return sb.toString();
    }

    /** AZ 轮询周期（毫秒）；未下发用默认值 */
    public long getPollIntervalMs() {
        AzAttrConfigBean config = getConfig();
        if (config == null || config.azPollingInterval == null || config.azPollingInterval <= 0) {
            return AzAttrConstants.DEFAULT_POLL_INTERVAL_MS;
        }
        return TimeUnit.HOURS.toMillis(config.azPollingInterval);
    }

    /** 点击 CD（毫秒）；未下发用默认值 */
    public long getClickCdMs() {
        AzAttrConfigBean config = getConfig();
        if (config == null || config.reportInterval == null || config.reportInterval <= 0) {
            return AzAttrConstants.DEFAULT_CLICK_CD_MS;
        }
        return TimeUnit.MINUTES.toMillis(config.reportInterval);
    }

    // ---------- 供 Reporter 消费 ----------

    /** 客户端是否上报总开关（0-否 1-是），null 视为不上报 */
    public boolean isReportEnabled() {
        AzAttrConfigBean config = getConfig();
        return config != null && config.reportEnabled != null && config.reportEnabled == 1;
    }

    /** 包维度上报次数上限；缺失、0 或负数视为无效配置，返回 0 以阻断上报。 */
    public int getPkgReportLimit() {
        AzAttrConfigBean config = getConfig();
        if (config == null || config.pkgReportLimit == null || config.pkgReportLimit <= 0) {
            return 0;
        }
        return config.pkgReportLimit;
    }

    /** 查询指定包的归因项；不在列表内返回 null */
    public AzAttrConfigBean.AzAttrItemBean queryByPackage(String pkg) {
        if (TextUtils.isEmpty(pkg)) return null;
        AzAttrConfigBean config = getConfig();
        if (config == null || config.attributeModels == null) return null;
        for (AzAttrConfigBean.AzAttrItemBean item : config.attributeModels) {
            if (item != null && pkg.equals(item.pkg)) return item;
        }
        return null;
    }

    /** 包维度上报计数 */
    public int getReportCount(String pkg) {
        if (TextUtils.isEmpty(pkg)) return 0;
        Integer v = readMap(AzAttrConstants.K_REPORT_COUNT_MAP, Integer.class).get(pkg);
        return v == null ? 0 : v;
    }

    /** 包上报计数 +1 */
    public synchronized void incReportCount(String pkg) {
        if (TextUtils.isEmpty(pkg)) return;
        Map<String, Integer> map = readMap(AzAttrConstants.K_REPORT_COUNT_MAP, Integer.class);
        Integer cur = map.get(pkg);
        map.put(pkg, (cur == null ? 0 : cur) + 1);
        getMmkv().encode(AzAttrConstants.K_REPORT_COUNT_MAP, GsonUtils.getInstance().toJson(map));
        LogUtils.i(TAG, LOG_PREFIX + "包维度上报次数+1，pkg=" + pkg + ", before=" + (cur == null ? 0 : cur)
                + ", after=" + map.get(pkg));
    }

    /** 该包上次点击时间戳；未记录返回 0 */
    public long getLastClickTs(String pkg) {
        if (TextUtils.isEmpty(pkg)) return 0L;
        Long v = readMap(AzAttrConstants.K_LAST_CLICK_MAP, Long.class).get(pkg);
        return v == null ? 0L : v;
    }

    /** 记录该包本次点击时间戳 */
    public synchronized void updateLastClickTs(String pkg, long tsMs) {
        if (TextUtils.isEmpty(pkg)) return;
        Map<String, Long> map = readMap(AzAttrConstants.K_LAST_CLICK_MAP, Long.class);
        Long last = map.get(pkg);
        map.put(pkg, tsMs);
        getMmkv().encode(AzAttrConstants.K_LAST_CLICK_MAP, GsonUtils.getInstance().toJson(map));
        LogUtils.i(TAG, LOG_PREFIX + "更新点击时间戳，pkg=" + pkg + ", last=" + (last == null ? 0L : last)
                + ", current=" + tsMs);
    }

    // ---------- 内部：读取 & 缓存 ----------

    private AzAttrConfigBean getConfig() {
        AzAttrConfigBean cache = mConfigCache;
        if (cache != null) return cache;
        synchronized (mConfigLock) {
            if (mConfigCache != null) return mConfigCache;
            String json = getMmkv().decodeString(AzAttrConstants.K_CONFIG, "");
            if (TextUtils.isEmpty(json)) {
                LogUtils.i(TAG, LOG_PREFIX + "读取配置为空：MMKV暂无AZ归因配置");
                return null;
            }
            try {
                mConfigCache = GsonUtils.getInstance().fromJson(json, AzAttrConfigBean.class);
                LogUtils.i(TAG, LOG_PREFIX + "从MMKV读取配置成功，jsonLength=" + json.length()
                        + ", " + buildConfigSummary(mConfigCache));
            } catch (Exception e) {
                LogUtils.d(TAG, LOG_PREFIX + "解析MMKV配置异常: " + e.getMessage());
                mConfigCache = null;
            }
            return mConfigCache;
        }
    }

    @SuppressWarnings("unchecked")
    private <V> Map<String, V> readMap(String key, Class<V> valueType) {
        String json = getMmkv().decodeString(key, "");
        if (TextUtils.isEmpty(json)) return new HashMap<>();
        try {
            java.lang.reflect.Type type;
            if (valueType == Integer.class) {
                type = new TypeToken<HashMap<String, Integer>>(){}.getType();
            } else if (valueType == Long.class) {
                type = new TypeToken<HashMap<String, Long>>(){}.getType();
            } else {
                return new HashMap<>();
            }
            Map<String, V> map = GsonUtils.getInstance().fromJson(json, type);
            return map != null ? map : new HashMap<String, V>();
        } catch (Exception e) {
            LogUtils.d(TAG, LOG_PREFIX + "读取本地map异常，key=" + key + " " + e.getMessage());
            return new HashMap<>();
        }
    }

    private static String buildConfigSummary(AzAttrConfigBean config) {
        if (config == null) return "config为空";
        return "reportEnabled=" + config.reportEnabled
                + ", pkgReportLimit=" + config.pkgReportLimit
                + ", mediaPkgReportLimit=" + config.mediaPkgReportLimit
                + ", reportInterval=" + config.reportInterval
                + ", azPollingInterval=" + config.azPollingInterval
                + ", 下发订单数=" + (config.attributeModels == null ? 0 : config.attributeModels.size())
                + ", 有效包名数=" + countValidPkgs(config);
    }

    private static int countValidPkgs(AzAttrConfigBean config) {
        if (config == null || config.attributeModels == null) return 0;
        int count = 0;
        for (AzAttrConfigBean.AzAttrItemBean item : config.attributeModels) {
            if (item != null && !TextUtils.isEmpty(item.pkg)) count++;
        }
        return count;
    }
}

package com.afmobi.palmplay.clean.FlyingStar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.afmobi.util.DisplayUtil;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 内存清理时，加速球旋转时的雪花效果
 * Created by xiangfei.wei on 2017/11/26.
 */

public class FlyingStarView extends View {

    Bitmap droid;       // The bitmap that all flakes use
    Bitmap translucentDroid;// 半透明图片
    int numFlakes = 0;  // 左边小球的总数
    int rightNumFlakes = 0;//右边小球总数
    ArrayList<FlyingStar> flakes = new ArrayList<>(); //左边小球集合
    List<FlyingStar> rightFlakes = new ArrayList<>();//右边小球集合

    private ValueAnimator animator = ValueAnimator.ofFloat(0, 1);
    long prevTime; // Used to track elapsed time for animations and fps
    Matrix m = new Matrix(); // Matrix used to translate/rotate each flake during rendering
    private float destX, destY;//小球的终点坐标

    private static final int BALL_COUNT = 5;
    private int xRange = 100;// 小球的初始位置在x方向上的分布范围
    /**
     * 是否使用混合模式；非混合模式小球只使用一种图片，混合模式使用两种
     */
    private boolean complexMode;

    /**
     * Constructor. Create objects used throughout the life of the View: the Paint and
     * the animator
     */
    public FlyingStarView(Context context) {
        super(context);
    }

    public FlyingStarView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        droid = BitmapFactory.decodeResource(getResources(), R.drawable.img_accelerate_dot);//R.drawable.shape_flying_star// R.drawable.bg_small
        translucentDroid = BitmapFactory.decodeResource(getResources(), R.drawable.img_accelerate_dot2);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator arg0) {
                long nowTime = System.currentTimeMillis();
                float secs = (float) (nowTime - prevTime) / 1000f;
                prevTime = nowTime;

                for (int i = 0; i < numFlakes; ++i) {// 左边
                    FlyingStar flake = flakes.get(i);
                    // 重新计算位置
                    flake.x += (destX - flake.originalX) * secs * flake.speed;

                    if (flake.originalY > destY || flake.originalY < destY) {
                        flake.y += (destY - flake.originalY) * secs * flake.speed;
                    }
                    //如果初始位置不在中间线上，并且现在移动到中间线上了，就沿着中间线走
                    if (Math.abs(flake.originalY - destY) > flake.height && Math.abs(flake.y - destY) < flake.height) {
                        flake.y = destY;
                    }
                    //回到初始位置
                    if (flake.x > destX) {
                        flake.originalX = flake.x = (float) Math.random() * (-xRange - flake.width);
                        flake.y = flake.originalY;
                    }

                    flake.rotation = flake.rotation + (flake.rotationSpeed * secs);
                    flake.scale = flake.scale - (flake.scaleSpeed * secs);
                }
                for (int i = 0; i < rightNumFlakes; i++) { // 右边
                    FlyingStar flake = rightFlakes.get(i);
                    // 重新计算位置
                    flake.x -= (flake.originalX - destX) * secs * flake.speed;

                    if (flake.originalY > destY || flake.originalY < destY) {
                        flake.y += (destY - flake.originalY) * secs * flake.speed;
                    }
                    //如果初始位置不在中间线上，并且现在移动到中间线上了，沿着中间线走
                    if (Math.abs(flake.originalY - destY) > flake.height && Math.abs(flake.y - destY) < flake.height) {
                        flake.y = destY;
                    }
                    //回到初始位置
                    if (flake.x < destX) {
                        flake.originalX = flake.x = getWidth() + (float) Math.random() * (xRange + flake.width);
                        flake.y = flake.originalY;
                    }

                    flake.rotation = flake.rotation + (flake.rotationSpeed * secs);
                    flake.scale = flake.scale - (flake.scaleSpeed * secs);
                }
                invalidate();
            }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
                /*flakes.clear();
                rightFlakes.clear();
                numFlakes = 0;
                rightNumFlakes = 0;
                addFlakes(BALL_COUNT);*/
            }
        });
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setDuration(100);
    }

    public FlyingStarView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * Add the specified number of droidflakes.
     */
    void addFlakes(int quantity) {
        FlyingStar star;
        Bitmap bitmap;
        for (int i = 0; i < quantity; ++i) {
            if (complexMode) {
                bitmap = i % 2 == 0 ? translucentDroid : droid;
            } else {
                bitmap = droid;
            }
            flakes.add(FlyingStar.createFlake(-xRange, getMeasuredHeight(), bitmap));

            star = FlyingStar.createFlake(xRange, getMeasuredHeight(), bitmap);
            star.originalX += getWidth();
            star.x += getWidth();
            rightFlakes.add(star);
        }
        numFlakes = quantity;
        rightNumFlakes = quantity;
    }

    /**
     * 是否使用混合模式（半透明和不透明小球混合）
     *
     * @param complexModeEnable TRUE，混合模式；false，非混合模式
     */
    public void setComplexModeEnable(boolean complexModeEnable) {
        complexMode = complexModeEnable;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        cancel();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            super.onDraw(canvas);

            // For each flake: back-translate by half its size (this allows it to rotate around its center),
            // rotate by its current rotation, translate by its location, then draw its bitmap
            for (int i = 0; i < numFlakes; ++i) {
                FlyingStar flake = flakes.get(i);
                if (flake == null) {
                    return;
                }
                m.setTranslate(-flake.width / 2, -flake.height / 2);
                // m.postRotate(flake.rotation);
//            m.postScale(flake.scale, flake.scale);
                m.postTranslate(flake.width / 2 + flake.x, flake.height / 2 + flake.y);
                //m.setScale(flake.scale, flake.scale);
                if (flake.bitmap != null && !flake.bitmap.isRecycled()) {
                    canvas.drawBitmap(flake.bitmap, m, null);
                }
            }
            for (int i = 0; i < rightNumFlakes; i++) {
                FlyingStar flake = rightFlakes.get(i);
                m.setTranslate(-flake.width / 2, -flake.height / 2);
//            m.postRotate(flake.rotation);
                m.postTranslate(flake.width / 2 + flake.x, flake.height / 2 + flake.y);
                //m.setScale(flake.scale, flake.scale);
                if (flake.bitmap != null && !flake.bitmap.isRecycled()) {
                    canvas.drawBitmap(flake.bitmap, m, null);
                }
            }
        } catch (Exception e) {

        }

    }

    public void cancel() {
        flakes.clear();
        rightFlakes.clear();
        numFlakes = 0;
        rightNumFlakes = 0;
        // Cancel animator in case it was already running
        if (animator != null) {
            animator.cancel();
        }

        invalidate();
    }

    public void start() {
        ValueAnimator currentAnimator = animator;
        if (currentAnimator == null || getWindowToken() == null) {
            return;
        }
        // destX = getMeasuredWidth() / 2;
        destY = getMeasuredHeight() / 2 + DisplayUtil.dip2px(getContext(), 25); // y方向上不是自己的中间，是为了指向扇叶view的中心；
        addFlakes(BALL_COUNT);
        prevTime = System.currentTimeMillis();
        currentAnimator.start();
    }

    public void setDestX(float destX) {
        this.destX = destX;
    }

    public void setDestY(float destY) {
        this.destY = destY;
    }

    /**
     * 设置小球背景资源
     *
     * @param drawableResource 资源ID
     */
    public void setDrawableResource(int drawableResource) {
        droid = BitmapFactory.decodeResource(getResources(), drawableResource);
    }

    public void releaseView() {
        ValueAnimator currentAnimator = animator;
        cancel();
        if (currentAnimator != null) {
            currentAnimator.removeAllUpdateListeners();
            currentAnimator.removeAllListeners();
        }
        animator = null;
    }

    @Override
    protected void onDetachedFromWindow() {
        cancel();
        super.onDetachedFromWindow();
    }
}

package com.afmobi.palmplay.admgr.hisavana_sdk

import com.afmobi.palmplay.collection.AdResult
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative
import com.cloud.hisavana.ac.sdk.api.listener.AdListener
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.store.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn


const val _TAG = "HisavanaAdSdkRepo"
fun HisavanaSdkManager.loadCacheAd(sceneCode:String) : Flow<AdResult> = callbackFlow {
    var mTFeedNative: TFeedNative? = null
    var positionID = getEwScenePositionID(sceneCode)
    fun trySendWithClose(adResult: AdResult) {
        trySend(adResult)
        close(null) // 必须关闭，不然TimeoutCancellationException 还是会抛出
    }

    val callback = object : AdListener() {
        override fun onAdCache(adInfos: List<TaNativeInfo?>?) {
            val count = if (adInfos != null) adInfos.size else 0
            TRAnalysticsUtil.trackEwRspRecord(
                positionID,
                SceneCode.RC_X,
                HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_RSP_SUCCESS,
                count,
                0,
                false
            )
            HisavanaSdkManager.getInstance().onTrackEWSDKResponse(
                adInfos,
                positionID,
                SceneCode.RC_X,
                true,
                HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1,
                false
            )
            trySendWithClose(AdResult.Success(adInfos, false))
            if (adInfos != null && adInfos.size > 0) {
                LogUtils.d(_TAG, "collection  onAdCache adInfo:"+ adInfos.size)
                if(BuildConfig.DEBUG) {
                    if(adInfos != null) {
                        for (item in adInfos) {
                            LogUtils.e(
                                _TAG, " pkg=" + item?.psPackageName
                            )
                        }
                    }
                }
            }
        }

        override fun onError(error: TaErrorCode?) {
            trySendWithClose(AdResult.Error(error))
        }

        override fun onTimeOut() {
            trySendWithClose(AdResult.Timeout)
        }

    }
    HisavanaSdkManager.getInstance().readyShowFixedScene(
        SceneCode.RC_X, callback
    )
    // 将 awaitClose 放在最后
    awaitClose {
        LogUtils.d(_TAG, "loadCacheAd awaitClose")
        mTFeedNative?.destroy()
    }

    }.flowOn(Dispatchers.Main)


fun HisavanaSdkManager.loadAd(sceneCode:String, serialNum: String, pageIndex: Int, pageMax: Int): Flow<AdResult> = callbackFlow {
         var mTFeedNative: TFeedNative? = null

        fun trySendWithClose(adResult: AdResult) {
            trySend(adResult)
            close(null) // 必须关闭，不然TimeoutCancellationException 还是会抛出
        }

        // 1. 注册回调
        val callback = object: HisavanaSdkCallBack {
            override fun onError(adError: TaErrorCode?) {
                LogUtils.d(_TAG, " collection loadAd onError adError=$adError")
                trySendWithClose(AdResult.Error(adError))
            }

            override fun onAdLoaded(adInfo: List<TaNativeInfo?>?) {
//                onSearchDefaultCallback(adInfo, false)
                LogUtils.d(_TAG, "collection  loadAd onAdLoaded adInfo:"+ adInfo?.size)
                if(BuildConfig.DEBUG) {
                    if(adInfo != null) {
                        for (item in adInfo) {
                            LogUtils.e(
                                _TAG, " pkg=" + item?.psPackageName
                            )
                        }
                    }
                }
                trySendWithClose(AdResult.Success(adInfo, false))
            }

            override fun onAdClicked() {}

            override fun onTimeOut() {
                LogUtils.d(_TAG, "collection loadAd getResultAdFlow onTimeOut")
                trySendWithClose(AdResult.Error(null))
            }

            override fun onAdCache(adInfos: List<TaNativeInfo?>?) {
                LogUtils.d(_TAG, "collection loadAd onAdCache adInfos=$adInfos")
            //    trySendWithClose(AdResult.Success(adInfos, true))
            }
        }
    mTFeedNative = HisavanaSdkManager.getInstance().sdkLoad(
        SceneCode.RC_X,
        "",
        serialNum,
        pageIndex,
        pageMax,
        callback
    )
        // 3. 定义取消逻辑
        awaitClose {
            LogUtils.d(_TAG, "collection  getResultAdFlow awaitClose")
            mTFeedNative?.destroy()
        }
    }.flowOn(Dispatchers.Main)



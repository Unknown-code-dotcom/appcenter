package com.afmobi.palmplay.appmanage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afmobi.palmplay.base.BaseFragmentActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.customview.GridSpacingItemDecoration;
import com.afmobi.palmplay.appmanage.adapter.ManageShareAdapter;
import com.afmobi.palmplay.model.ShareInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.Constant;
import com.didi.drouter.annotation.Router;
import com.transsion.palmstorecore.util.ChangeAppNameUtil;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by lenovo on 2017-02-23.
 */
@Router(path = "/page/manageShare")
public class ManageShareActivity extends BaseFragmentActivity implements View.OnClickListener {

    private TextView title;
    private LinearLayout layoutPalmplay;
    private RecyclerView recyclerView;
    private ManageShareAdapter adapter;

    private ShareInfo shareInfo;
    private String pageType;

    private String packName;

    private static final int CLIENT_NOT_EXIST = 101;
    private static final int COMPLETE = 102;

    private static final String FACEBOOK_PACKNAME = "com.facebook.katana";
    private static final String TWITTER_PACKNAME = "com.twitter.android";
    private static final String WHATSAPP_PACKNAME = "com.whatsapp";
    private static final String FACEBOOKMESSENAGE_PACKNAME = "com.facebook.orca";
    private static final String GOOGLEPLUS_PACKNAME = "com.google.android.apps.plus";

    private static final String INTENT_FACEBOOK = "https://www.facebook.com/sharer.php?u=";
    private static final String INTENT_GOOGLEPLUS = "https://plus.google.com/share?text=";
    private static final String INTENT_TWITTER = "https://twitter.com/intent/tweet?url=";
    private static final String INTENT_MESSENAGER = "fb-messenger://share/?link=";

    private List<String> shareList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle onSaveInstanceState) {
        super.onCreate(onSaveInstanceState);

        setContentView(R.layout.activity_share_layout);
        //ShareSDK.initSDK(this);//3.0.0版本开始取消该方法；
//        FacebookSdk.sdkInitialize(getApplicationContext());

        initViews();

        if (getIntent().hasExtra("shareInfo")) {
            shareInfo = (ShareInfo) getIntent().getSerializableExtra("shareInfo");
            title.setText(R.string.details_share);
            pageType = Constant.DETAIL;

            mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.Digital_Share);
        } else {
            shareInfo = new ShareInfo();
//            shareInfo.content = getPalmPlayWebUrl();
//            shareInfo.url = getPalmPlayWebUrl();
            title.setText(ChangeAppNameUtil.INSTANCE.changeAppName(this,R.string.palmplay_share));
            pageType = Constant.INVITE;
            mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.Invite_Friends);
        }
        addShareList();
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);
    }

    private void initViews() {
        title = (TextView) findViewById(R.id.share_title);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        GridLayoutManager manager = new GridLayoutManager(this, 3, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new GridSpacingItemDecoration(30));
        findViewById(R.id.share_cancel).setOnClickListener(this);

    }

    private void addShareList() {
        if (pageType.equals(Constant.INVITE)) {
//            shareList.add(getResources().getString(R.string.str_free_share));
        }
//        shareList.add(getResources().getString(R.string.text_facebook));
        shareList.add(getResources().getString(R.string.text_whatsapp));
        shareList.add(getResources().getString(R.string.text_twitter));
//        shareList.add(getResources().getString(R.string.text_messenger));
        shareList.add(getResources().getString(R.string.text_google));

        adapter = new ManageShareAdapter(this, shareList);
        recyclerView.setAdapter(adapter);
//        onRecyclerItemClickListener();
    }

    public static Intent getIntoIntent(Context context, String title, String text, String imageUrl, String url, String itemID, String size, PageParamInfo pageParamInfo) {
        ShareInfo shareInfo = new ShareInfo();
        shareInfo.title = title;
        shareInfo.content = text;
        shareInfo.imageUrl = imageUrl;
        shareInfo.url = url;
        shareInfo.itemID = itemID;
        shareInfo.size = size;
        Intent intent = new Intent(context, ManageShareActivity.class);
        intent.putExtra("shareInfo", shareInfo);
        PageConstants.putPageParamInfo(intent, pageParamInfo);
        return intent;
    }

    public static void switcToShareActivity(Context context, String title, String text, String imageUrl, String url, String itemID, String size, PageParamInfo pageParamInfo) {
        context.startActivity(getIntoIntent(context, title, text, imageUrl, url, itemID, size, pageParamInfo));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.share_cancel:
                finish();
                break;
        }
    }

    @Override
    public String getValue() {
        return "";
    }
}

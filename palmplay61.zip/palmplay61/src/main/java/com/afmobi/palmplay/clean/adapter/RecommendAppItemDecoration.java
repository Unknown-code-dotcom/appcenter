package com.afmobi.palmplay.clean.adapter;

import android.graphics.Rect;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * Created by xiangfei.wei on 2017/11/24.
 */

public class RecommendAppItemDecoration extends RecyclerView.ItemDecoration {

    private int leftPadding;
    private int rightPadding;
    private int itemSpace;

    public RecommendAppItemDecoration(int leftPadding, int rightPadding, int itemSpace) {
        this.leftPadding = leftPadding;
        this.rightPadding = rightPadding;
        this.itemSpace = itemSpace;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);
        int posi = parent.getChildAdapterPosition(view);
        int count = parent.getAdapter().getItemCount();
        if (posi == 0) {
            outRect.left = leftPadding;
        } else {
            outRect.left = itemSpace;
        }
        if (posi == count - 1)
            outRect.right = rightPadding;
    }
}

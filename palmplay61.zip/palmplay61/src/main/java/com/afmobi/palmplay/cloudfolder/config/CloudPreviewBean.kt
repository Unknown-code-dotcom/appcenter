package com.afmobi.palmplay.cloudfolder.config

import android.graphics.drawable.Drawable
import java.io.Serializable

data class CloudPreviewBean(val isShowMask: Boolean,
                            val previewDrawable: Drawable?
): Serializable
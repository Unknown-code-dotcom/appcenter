package com.afmobi.palmplay.cloudfolder.view

import android.content.Context
import android.graphics.Outline
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import androidx.appcompat.widget.AppCompatImageView
import com.transsnet.store.R


class CloudFolderRoundedImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) :
    AppCompatImageView(context, attrs, defStyleAttr) {
    
    var cornerRadius: Float = 0f
        set(value) {
            field = value
            invalidateOutline()
            invalidate()
        }

    init {
        // 读取自定义属性，若未传则默认使用 18dp
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.CloudFolderRoundedImageView)
        val defaultRadius = context.resources.getDimension(R.dimen.dp_18)
        cornerRadius = typedArray.getDimension(R.styleable.CloudFolderRoundedImageView_cornerRadius, defaultRadius)
        typedArray.recycle()

        // 使用 ViewOutlineProvider 实现完美的硬件加速圆角裁剪
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerRadius)
            }
        }
        clipToOutline = true
    }

}
package com.afmobi.palmplay.activate.state

enum class TRPopupType {
    HOME_ONE_TIME,  // 首页弹框（如mustInstallExecutor、recomInstallExecutor）
    SCENE_BASED // 场景相关弹框（如无网弹框）
}

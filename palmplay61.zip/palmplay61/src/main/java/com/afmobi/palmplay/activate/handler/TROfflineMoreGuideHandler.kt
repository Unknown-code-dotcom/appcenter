package com.afmobi.palmplay.activate.handler

import android.app.Activity
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.dialog.OfflineMoreGuideDialog
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager

class TROfflineMoreGuideHandler(
    executor: TRBaseExecutor<*>?,
    sceneName: String,
    priority: TRPriority,
    popupType: TRPopupType
) :
TRChainHandler(sceneName, priority, popupType) {
    private var mExecutor: TRBaseExecutor<*>? = executor
    var location: IntArray? = null
    var isR2L : Boolean? = null
    var listener: OfflineMoreGuideDialog.OnDialogBtnClickListener? = null
    override fun canShow(fromType: String?): Boolean {
        return TRNewManager.instance.canShow()
    }

    override fun showNext(fromType: String?): Boolean {
        if(AtyManager.getAtyManager().currentActivity != curActivity?.get()) {
            return false
        }
        if(location == null || isR2L == null || listener == null) {
            return false
        }
        if(canShow(fromType)) {
            return mExecutor?.show(fromType, curActivity?.get(), listener, isR2L!!, location) ==true
        }
        return false
    }

    override fun show(
        fromType: String?,
        activity: Activity?,
        Listener: OfflineMoreGuideDialog.OnDialogBtnClickListener,
        isR2L: Boolean,
        position: IntArray
    ): Boolean {
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if(!canShow(fromType)) {
            return false
        }
        return mExecutor?.show(fromType, activity, Listener, isR2L, position) ==true
    }


}
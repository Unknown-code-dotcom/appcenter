package com.afmobi.palmplay.appmanage.v2.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.afmobi.palmplay.appmanage.v2.model.BTN_ALL_CONTINUE
import com.afmobi.palmplay.appmanage.v2.model.BTN_ALL_PAUSE
import com.afmobi.palmplay.appmanage.v2.model.BTN_GONE
import com.afmobi.palmplay.appmanage.v2.model.DownloadItem
import com.afmobi.palmplay.appmanage.v2.model.DownloadStatus
import com.afmobi.palmplay.appmanage.v2.model.DownloadUiState
import com.afmobi.palmplay.appmanage.v2.repository.DownloadRepo
import com.afmobi.palmplay.model.SimpleDataInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.transsion.palmstorecore.analytics.ComponentClickBuilder
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * 下载管理页面ViewModel
 * 作为唯一数据源，管理所有UI相关数据
 */
class ManageDownloadViewModelV2(
    private val repository: DownloadRepo
) : ViewModel() {

    // UI状态数据
    private val _uiState = MutableLiveData(DownloadUiState())
    val uiState: LiveData<DownloadUiState> = _uiState

    // UI状态数据
    /**
     * 省流数据
     */
    private val _dataSaved = MutableLiveData<List<SimpleDataInfo>>(emptyList())
    val dataSaved: LiveData<List<SimpleDataInfo>> = _dataSaved

    /**
     * 不可下载列表是否折叠
     */
    private val _isNoResListFold = MutableLiveData(true)
    val isNoResListFold: LiveData<Boolean> = _isNoResListFold

    val refreshMediator = repository.getRefreshFlow()

    private val refreshMutex = Mutex()

    init {
        // 初始化数据
        refreshDataSaved()
    }

    /**
     * 刷新省流信息
     */
    fun refreshDataSaved() {
        viewModelScope.launch(Dispatchers.IO) {
            val savedDataList = repository.getSavedDataList()
            _dataSaved.postValue(savedDataList)
        }
    }

    fun statusFlowOf(packageName: String): SharedFlow<DownloadStatus> {
        return repository.getProgressFlow(packageName)
    }


    /**
     * 刷新所有数据
     */
    fun refreshData() {
        launchLockedStateUpdate { currentState ->
            val downloadingList = repository.getDownloadingList()
            val downloadedList = repository.getDownloadedList()
            val installedList = repository.getInstalledList()
            val noResList = repository.getNoResList()

            // 过滤已安装的包名，防止同一应用同时出现在安装中和已安装两个分区
            val installedPkgNames = installedList.mapTo(HashSet()) { it.packageName }
            val installingList = buildList {
                addAll(downloadingList
                    .filter { it.packageName !in installedPkgNames }
                    .map { DownloadItem.DownloadItemInfo(it, false) })
                addAll(downloadedList
                    .filter { it.packageName !in installedPkgNames }
                    .map { DownloadItem.DownloadItemInfo(it, false) })
            }

            currentState.copy(
                installingList = installingList,
                installedList = installedList.map { DownloadItem.DownloadItemInfo(it, true) },
                noResList = noResList,
                btnAllType = computeBtnAllType(downloadingList),
                isNoResListFold = _isNoResListFold.value == true,
                isLoading = false
            )
        }
    }

    /**
     * 检查按钮状态
     */
    fun checkBtnAllType() {
        launchLockedStateUpdate { currentState ->
            val downloadingList = repository.getDownloadingList()
            currentState.copy(
                btnAllType = computeBtnAllType(downloadingList),
                isLoading = false
            )
        }
    }

    fun queryNoResList() {
        viewModelScope.launch {
            val newState = withContext(Dispatchers.IO) {
                val currentState = _uiState.value ?: DownloadUiState()
                val noResList = repository.getNoResList()
                currentState.copy(
                    noResList = noResList,
                    isNoResListFold = _isNoResListFold.value == true
                )
            }
            _uiState.value = newState
        }
    }

    /**
     * 删除不可下载任务
     */
    fun deleteNoResTask(info: FileDownloadInfo) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteNoResTask(info)
            }
            queryNoResList()
        }
    }

    /**
     * 清空所有不可下载任务
     */
    fun clearAllNoResTasks(value: String, from: String?) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val noResList = repository.getNoResList()
                for (info in noResList) {
                    // 单独报应用，有几个报几个；ButtonType("ClearAll")
                    val builder: ComponentClickBuilder<*> =
                        ComponentClickBuilder<ComponentClickBuilder<*>>()
                    builder.setValue(value)
                        .setFrom(from)
                        .setTopicType("")
                        .setTopicId("")
                        .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                        .setItemId(info.itemID)
                        .setButtonType("clearAll")
                        .setItemValue(info.packageName)
                        .setExtraValue("")
                    TRAnalysticsUtil.trackClick(builder)
                    repository.deleteNoResTask(info)
                }
            }
            queryNoResList()
        }

    }

    /**
     * 折叠/展开不可下载列表
     */
    fun toggleNoResListFoldState(fold: Boolean) {
        _isNoResListFold.value = fold
    }

    /**
     * 获取不可下载列表
     */
    fun getNoResList(): List<FileDownloadInfo> {
        return _uiState.value?.noResList ?: emptyList()
    }


    private fun launchLockedStateUpdate(block: suspend (DownloadUiState) -> DownloadUiState) {
        viewModelScope.launch {
            refreshMutex.withLock {
                val currentState = _uiState.value ?: DownloadUiState()
                try {
                    _uiState.value = withContext(Dispatchers.Default) { block(currentState) }
                } catch (_: Exception) {
                    _uiState.value = currentState.copy(isLoading = false)
                }
            }
        }
    }

    private fun computeBtnAllType(downloadingList: List<FileDownloadInfo>): Int = when {
        repository.isExistDownloading(downloadingList) -> BTN_ALL_PAUSE
        repository.isExistUnDownload(downloadingList)  -> BTN_ALL_CONTINUE
        else                                           -> BTN_GONE
    }

    override fun onCleared() {
        super.onCleared()
        repository.destroy()
    }
}
package com.afmobi.palmplay.appmanage.db;

import com.afmobi.palmplay.model.ClientVersion;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

/**
 * @author: kun.shi
 * @date: 2024/5/15 11:27
 * @Desc: add your description
 */

@Dao
public interface UpdateDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void saveIgnoreUpdateAppInfoList(List<ClientVersion.UpdateItem> ignoreUpdateAppInfoList);

    @Query("SELECT * FROM UpdateItem")
    List<ClientVersion.UpdateItem> getAllIgnoreUpdateApps();

    @Delete
    void delete(List<ClientVersion.UpdateItem> ignoreUpdateApps);

    @Query("DELETE FROM UpdateItem")
    void deleteAll();

    @Query("DELETE FROM UpdateItem WHERE packageName = :pkg")
    void deleteFixedItem(String pkg);

    @Delete
    void deleteItem(ClientVersion.UpdateItem item);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateIgnoreItem(ClientVersion.UpdateItem... updateItem);


}

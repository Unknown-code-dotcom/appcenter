package com.afmobi.palmplay.appmanage.adapter;


import android.app.Activity;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.adapter.PalmPlayBaseDownloadAdapter;
import com.afmobi.palmplay.appmanage.model.InstantGameBean;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.h5.offline.OfflineDownloadStatus;
import com.afmobi.palmplay.h5.offline.db.H5OfflineInfoDatabase;
import com.afmobi.palmplay.h5.offline.instant.InstantOfflineGameManager;
import com.afmobi.palmplay.home.instant.model.TrInstantRecentBean;
import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameDatabase;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.va.dialog.VaDialogs;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.google.android.material.imageview.ShapeableImageView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideApp;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.TRPath;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.widgetslib.widget.OSIconTextView;
import com.transsion.xwebview.instant.util.GlobalUtil;
import com.transsion.xwebview.offline.WebUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ManagerInstantGamesAdapter extends PalmPlayBaseDownloadAdapter {

    private RecyclerView listview;
    private List<InstantGameBean> instantGameList = new ArrayList<InstantGameBean>();
    private final String PREFIX_TRACK_H5 = "H5_";
    private View.OnClickListener mOnClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            if (mActivity == null || mActivity.isFinishing() || mActivity.isDestroyed()) {
                return;
            }
            int position = (int) v.getTag();
            if (position < 0 || position >= instantGameList.size()) {
                return;
            }
            try {
                InstantGameBean bean = instantGameList.get(position);
                String dialogFrom = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_INSTANT_GAMES, "", String.valueOf(position));
                if (bean.type == TrInstantRecentBean.TYPE_VA) {
                    LiveData<Integer> click = VaDialogs.createUninstallDialog(mActivity, bean.vaGameInfo.name, bean.vaGameInfo.itemID, TRAnalyticsConstant.TRACK_ITEM_TYPE_SOFT, bean.vaGameInfo.packageName, dialogFrom, true)
                            .display()
                            .click();
                    click.observe((LifecycleOwner) mActivity, new Observer<Integer>() {
                        @Override
                        public void onChanged(Integer integer) {
                            if (integer == DialogInterface.BUTTON_POSITIVE) {
                                boolean result = PsVaManager.getInstance().deleteVaGame(bean.vaGameInfo.packageName, true);
                                LogUtils.d(LogUtils.TAG_TR_D_VA_DELETED, "Delete va game in manager install page. The pkg =" + bean.vaGameInfo.packageName + ",Result = " + result);
                                if (result) {
                                    instantGameList.remove(bean);
                                    notifyDataSetChanged();
                                }
                            }
                        }
                    });
                } else if (bean.type == TrInstantRecentBean.TYPE_H5) {
                    File file = new File(TRPath.getH5OfflineGamePath(), GlobalUtil.md5Of32(WebUtil.parseUrl(bean.h5GameInfo.openUrl)));
                    LiveData<Integer> click = VaDialogs.createUninstallDialog(mActivity, bean.h5GameInfo.name, PREFIX_TRACK_H5 + bean.h5GameInfo.gameId, TRAnalyticsConstant.TRACK_ITEM_TYPE_H5, bean.h5GameInfo.name, dialogFrom, false)
                            .display()
                            .click();
                    click.observe((LifecycleOwner) mActivity, new Observer<Integer>() {
                        @Override
                        public void onChanged(Integer integer) {
                            if (integer == DialogInterface.BUTTON_POSITIVE) {
                                boolean result = cleanAndRemoveDirectory(file);
                                if (result) {
                                    instantGameList.remove(bean);
                                    OfflineDownloadStatus.hasFinishTask = true;
                                    TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
                                        @Override
                                        public void run() {
                                            TrInstantH5GameDatabase.getDatabase(PalmplayApplication.getAppInstance()).getTrInstantH5GameDao().deleteById(Integer.valueOf(bean.h5GameInfo.gameId));
                                        }
                                    });
                                    notifyDataSetChanged();
                                    InstantOfflineGameManager.getInstance().onUninstallGame(bean.h5GameInfo.gameId);
                                }
                            }
                        }
                    });
                } else if (bean.type == TrInstantRecentBean.TYPE_OFFLINE) {
                    File file = new File(TRPath.getH5OfflineGamePath(), GlobalUtil.md5Of32(WebUtil.parseUrl(bean.gameFavoriteInfo.openUrl)));
                    LiveData<Integer> click = VaDialogs.createUninstallDialog(mActivity, bean.gameFavoriteInfo.name, "", TRAnalyticsConstant.TRACK_ITEM_TYPE_H5, bean.gameFavoriteInfo.name, dialogFrom, false)
                            .display()
                            .click();
                    click.observe((LifecycleOwner) mActivity, new Observer<Integer>() {
                        @Override
                        public void onChanged(Integer integer) {
                            if (integer == DialogInterface.BUTTON_POSITIVE) {
                                boolean result = cleanAndRemoveDirectory(file);
                                if (result) {
                                    instantGameList.remove(bean);
                                    OfflineDownloadStatus.hasFinishTask = true;
                                    TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
                                        @Override
                                        public void run() {
                                            H5OfflineInfoDatabase.getDatabase(PalmplayApplication.getAppInstance()).getGameFavoriteDao().deleteById(bean.gameFavoriteInfo.id);
                                        }
                                    });
                                    notifyDataSetChanged();
                                }
                            }
                        }
                    });
                }

                String itemValue = "";
                String itemType = "";
                String itemId = "";
                if (bean.type == TrInstantRecentBean.TYPE_VA) {
                    itemValue = bean.vaGameInfo.packageName;
                    itemType = TRAnalyticsConstant.TRACK_ITEM_TYPE_SOFT;
                    itemId = bean.vaGameInfo.itemID;
                } else if (bean.type == TrInstantRecentBean.TYPE_H5) {
                    itemValue = bean.h5GameInfo.name;
                    itemType = TRAnalyticsConstant.TRACK_ITEM_TYPE_H5;
                    itemId = PREFIX_TRACK_H5 + bean.h5GameInfo.gameId;
                } else if (bean.type == TrInstantRecentBean.TYPE_OFFLINE) {
                    itemValue = bean.gameFavoriteInfo.name;
                    itemType = TRAnalyticsConstant.TRACK_ITEM_TYPE_H5;
                }
                boolean isVa = bean.type == TrInstantRecentBean.TYPE_VA ? true : false;
                reportItemClick(itemValue, isVa, position, itemType, itemId);
            } catch (Exception e) {

            }
        }
    };


    public ManagerInstantGamesAdapter(Activity mActivity, RecyclerView listview, List<InstantGameBean> result) {
        super(mActivity);
        this.mActivity = mActivity;
        this.listview = listview;
        this.listview.setLayoutManager(new LinearLayoutManager(mActivity));
        if (instantGameList != null) {
            instantGameList.clear();
            instantGameList.addAll(result);
        }
        this.listview.setAdapter(this);
    }

    public InstantGameBean getItem(int position) {
        if (position < 0 || position >= getItemCount()) {
            return null;
        }
        return instantGameList == null ? null : instantGameList.get(position);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(mActivity).inflate(R.layout.layout_manage_installed_list_item, parent, false);
        return new ViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder1, final int position) {
        final ViewHolder holder = (ViewHolder) holder1;
        if (instantGameList == null || instantGameList.size() == 0) {
            return;
        }
        final InstantGameBean bean = instantGameList.get(position);
        if (bean.type == TrInstantRecentBean.TYPE_VA) {
            holder.size.setText(bean.sizeName);
            holder.title.setText(bean.vaGameInfo.name);
        } else if (bean.type == TrInstantRecentBean.TYPE_H5) {
            if (GlobalUtil.h5GameIsReady(bean.h5GameInfo.openUrl)) {
                holder.size.setText(bean.sizeName);
                holder.title.setText(bean.h5GameInfo.name);
            }
        } else if (bean.type == TrInstantRecentBean.TYPE_OFFLINE) {
            // 离线游戏且收藏过的
            holder.title.setText(bean.gameFavoriteInfo.name);
            if (GlobalUtil.h5GameIsReady(bean.gameFavoriteInfo.openUrl)) {
                holder.size.setText(bean.sizeName);
                holder.title.setText(bean.gameFavoriteInfo.name);
            }
        }
        holder.uninstall.setVisibility(View.VISIBLE);
        holder.checkBox.setVisibility(View.GONE);
        holder.uninstall.setTag(position);
        holder.uninstall.setOnClickListener(mOnClickListener);
        holder.uninstall.setText(R.string.text_delete);
        holder.image.setTag(R.id.id_installed_pos_key, position);
        String itemValue = "";
        String itemType = "";
        String itemId = "";
        boolean isVa = false;
        if (bean.type == TrInstantRecentBean.TYPE_VA) {
            itemValue = bean.vaGameInfo.packageName;
            itemType = TRAnalyticsConstant.TRACK_ITEM_TYPE_SOFT;
            itemId = bean.vaGameInfo.itemID;
            isVa = true;
            if (BuildConfig.PROXY_VA) {
                holder.image.setImageDrawable(VaStaticProxy.getGameIcon(bean.vaGameInfo.packageName));
            } else {
                String vaGameIconUrl = PsVaManager.getInstance().getVaGameIconUrl(bean.vaGameInfo.packageName);
                if (!TextUtils.isEmpty(vaGameIconUrl)) {
                    GlideApp.with(holder.image.getContext()).load(vaGameIconUrl)
                            .placeholder(R.drawable.layer_list_app_default_01_bg)
                            .into(holder.image);
                } else {
                    holder.image.setImageResource(R.drawable.layer_list_app_default_01_bg);
                }
            }
        } else if (bean.type == TrInstantRecentBean.TYPE_H5) {
            itemValue = bean.h5GameInfo.name;
            itemType = TRAnalyticsConstant.TRACK_ITEM_TYPE_H5;
            itemId = PREFIX_TRACK_H5 + bean.h5GameInfo.gameId;
            isVa = false;
            String h5GameIconUrl = bean.h5GameInfo.iconUrl;
            if (!TextUtils.isEmpty(h5GameIconUrl)) {
                GlideApp.with(holder.image.getContext()).load(h5GameIconUrl)
                        .placeholder(R.drawable.layer_list_app_default_01_bg)
                        .into(holder.image);
            } else {
                holder.image.setImageResource(R.drawable.layer_list_app_default_01_bg);
            }
        } else if (bean.type == TrInstantRecentBean.TYPE_OFFLINE) {
            itemValue = bean.gameFavoriteInfo.name;
            itemType = TRAnalyticsConstant.TRACK_ITEM_TYPE_H5;
            isVa = false;
            String h5GameIconUrl = bean.gameFavoriteInfo.iconUrl;
            if (!TextUtils.isEmpty(h5GameIconUrl)) {
                GlideApp.with(holder.image.getContext()).load(h5GameIconUrl)
                        .placeholder(R.drawable.layer_list_app_default_01_bg)
                        .into(holder.image);
            } else {
                holder.image.setImageResource(R.drawable.layer_list_app_default_01_bg);
            }
        }
        reportItemPv(itemValue, isVa, position, itemType, itemId);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return instantGameList == null ? 0 : instantGameList.size();
    }

    @Override
    public int loaderDetailType() {
        return DetailType.TYPE_INVALID;
    }

    @Override
    public InterfaceStatusChange loaderInterfaceStatusChange() {
        return new InterfaceStatusChange() {

            @Override
            public void onDownloadStart(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadResume(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {

            }

            @Override
            public void onDownloadPause(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadError(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadDelete(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadComplete(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onActivated(FileDownloadInfo downloadInfo) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {

            }

            @Override
            public void onAppPackageAdded(String packageName, int versionCode) {

            }
        };
    }


    @Override
    public Object loaderInterfaceStatusChangeObjectKey() {
        return this;
    }

    private class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView subscriptVa;
        public ShapeableImageView image;
        public TextView title;
        public TextView size;
        public View splitView;
        public TextView versions;
        public TextView uninstall;
        public CheckBox checkBox;
        public OSIconTextView share;
        public View mView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.item_for_applist_image);
            title = itemView.findViewById(R.id.item_for_applist_title);
            size = itemView.findViewById(R.id.item_for_applist_size);
            splitView = itemView.findViewById(R.id.item_for_applist_split);
            splitView.setVisibility(View.GONE);
            versions = itemView.findViewById(R.id.item_for_applist_versions);
            uninstall = itemView.findViewById(R.id.manage_menu);
            checkBox = itemView.findViewById(R.id.check);
            subscriptVa = (ImageView) itemView.findViewById(R.id.iv_subscript_va);
            mView = itemView;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (instantGameList != null) {
            instantGameList.clear();
            instantGameList = null;
        }
    }


    private boolean cleanAndRemoveDirectory(File delFile) {
        if (!delFile.exists() || !delFile.isDirectory()) {
            return false;
        }
        // 先递归删除所有子内容
        if (!cleanDirectory(delFile)) {
            return false;
        }
        // 再尝试删除空目录
        return delFile.delete();
    }

    private boolean cleanDirectory(File delFile) {
        if (!delFile.exists() || !delFile.isDirectory()) {
            return false;
        }
        File[] contents = delFile.listFiles();
        if (contents == null) {
            return true;
        }
        boolean success = true;
        for (File content : contents) {
            success &= deleteRecursive(content);
        }
        return success;
    }


    private boolean deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] children = fileOrDirectory.listFiles();
            if (children != null) {
                for (File child : children) {
                    // 确保子目录递归删除成功
                    if (!deleteRecursive(child)) {
                        return false;
                    }
                }
            }
        }
        return fileOrDirectory.delete();
    }

    // 埋点：单游戏(VA/H5)的点击上报
    private void reportItemClick(String itemValue, boolean isVa, int position, String itemType, String itemId) {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_INSTANT_GAMES, "", String.valueOf(position));
        String clickFrom = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_INSTANT_GAMES, "", "");
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(value)
                .setFrom(clickFrom)
                .setIsVa(isVa)
                .setItemValue(itemValue)
                .setItemType(itemType)
                .setItemId(itemId);
        builder.setButtonType(TRAnalyticsConstant.DELETE);
        TRAnalysticsUtil.trackClick(builder);
    }

    // 埋点：单游戏(VA/H5)的曝光
    private void reportItemPv(String packageName, boolean isVa, int position, String itemType, String itemId) {
        String from = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_INSTANT_GAMES, "", "");
        String value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_INSTANT_GAMES, "", String.valueOf(position));
        PagePvBuilder builder = new PagePvBuilder();
        builder.setValue(value)
                .setItemValue(packageName)
                .setItemType(itemType)
                .setItemId(itemId)
                .setIsVa(isVa)
                .setFrom(from);
        TRAnalysticsUtil.trackPV(builder);
    }


}

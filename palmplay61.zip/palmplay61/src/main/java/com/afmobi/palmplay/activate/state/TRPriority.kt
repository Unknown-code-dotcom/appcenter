package com.afmobi.palmplay.activate.state

enum class TRPriority(i: Int) {
    MUST(1000),    // 最高优先级  首页弹框
    HIGH(100),        // 高优先级
    MEDIUM(50),       // 中优先级
    LOW(10),          // 低优先级
    TIP(1);           // 提示类弹框


    private var priority = 0

    fun TRPopupPriority(priority: Int) {
        this.priority = priority
    }

    fun getPriority(): Int {
        return priority
    }
}

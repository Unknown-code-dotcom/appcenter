package com.afmobi.palmplay.activitycenter;

import com.afmobi.palmplay.giftscenter.bean.BaseActionCardBean;
import com.afmobi.palmplay.home.model.base.JumpBean;
import com.afmobi.palmplay.model.v6_3.PageConstants;

import java.io.Serializable;


public class ACBean extends BaseActionCardBean implements Serializable {
    private String category;
    private String activityName;
    private String activityDesc;
    private String detailType;
    private String imgUrl;
    private String bigImgurl;
    public boolean isTrack;

    private String mLastPage = PageConstants.None;
    private String mValue ;
    private String mCurPage = PageConstants.None;

    public String getmValue() {
        return mValue;
    }

    public void setmValue(String mValue) {
        this.mValue = mValue;
    }

    public String getmLastPage() {
        return mLastPage;
    }

    public void setmLastPage(String mLastPage) {
        this.mLastPage = mLastPage;
    }

    public String getmCurPage() {
        return mCurPage;
    }

    public void setmCurPage(String mCurPage) {
        this.mCurPage = mCurPage;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityDesc() {
        return activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }

    public String getDetailType() {
        return detailType;
    }

    public void setDetailType(String detailType) {
        this.detailType = detailType;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getBigImgurl() {
        return bigImgurl;
    }

    public void setBigImgurl(String bigImgurl) {
        this.bigImgurl = bigImgurl;
    }

    public JumpBean getJumpDto() {
        return jumpDto;
    }

    public void setJumpDto(JumpBean jumpDto) {
        this.jumpDto = jumpDto;
    }

    private JumpBean jumpDto;

}

package com.afmobi.palmplay.cloudfolder.adapter

import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter
import com.afmobi.palmplay.cloudfolder.AttributionUploadManager
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderRemoteController
import com.afmobi.palmplay.cloudfolder.CloudFolderManager.Companion.LEADER_SCROLL_ON
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.recently.RecentlyInstalledTracker
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_BOTTOM_NEW
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.CloudFolderLauncher
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.PadFolderUi
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.view.BottomDownloadStatusView
import com.afmobi.palmplay.cloudfolder.view.GlobalShapeClipFrameLayout
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.download.DownloadUtil
import com.afmobi.palmplay.download.InterfaceStatusChange
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.transsion.palmstorecore.glide.GlideApp
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.attribution.AttributionTools
import com.transsnet.launcherlib.config.Constants
import com.transsnet.store.R
import kotlinx.coroutines.launch

class CloudBottomAppInfoAdapter(
    val categoryType: Int,
    items: List<CloudAppInfo>
) : PalmBaseDownloadRecyclerViewAdapter() {

    private var items: MutableList<CloudAppInfo> = ArrayList()

    private var recyclerView: RecyclerView? = null

    var onLongClickListener: ((View, Int, CloudAppInfo) -> Unit)? = null

    /** 当前云文件夹布局样式（由宿主 Fragment 注入），用于埋点 sty 字段 */
    var layoutStyle: Int = CloudFolderTrackUtil.STY_DEFAULT

    init {
        mFrom = if(categoryType == CATEGORY_APP) Constants.FILE_FOLDER_FROM_SITE_APP else Constants.FILE_FOLDER_FROM_SITE_GAME
        this.items.addAll(items)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        this.recyclerView = recyclerView
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        this.recyclerView = null
    }

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView: TextView = itemView.findViewById(R.id.itemText)
        val cardIcon: GlobalShapeClipFrameLayout = itemView.findViewById(R.id.card_icon)
        val iconView: ImageView = itemView.findViewById(R.id.iconView)
        val statusView: BottomDownloadStatusView = itemView.findViewById(R.id.statusView)
        val ivDefaultIcon: ImageView = itemView.findViewById(R.id.iv_default_icon)
        val rootView: View = itemView.findViewById(R.id.rootView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cloud_folder_bottom_new, parent, false)
        val lp = view.layoutParams
        if (lp != null) {
            lp.width = DeviceProfile.getInstance().folderBottomItemWidth
            view.layoutParams = lp
        }
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.layoutParams = holder.itemView.layoutParams.apply {
            width = DeviceProfile.getInstance().folderBottomItemWidth
        }
        PadFolderUi.applyBottomDownloadBadge(holder.itemView)
        val itemInfo = items[position]
        val itemHolder = holder as ItemViewHolder

        itemInfo.placementId = position.toString()
        // 注入页面级别样式，下游埋点与下载链路直接读取 appInfo 即可
        itemInfo.layoutStyle = layoutStyle

        val defaultIcon = R.drawable.layer_list_app_default_01_bg

        val remoteController = CloudFolderRemoteController.getInstance()
        val useGlobalShape = remoteController.hasGlobalIconShape()
        itemHolder.cardIcon.setGlobalIconShapePath(
            if (useGlobalShape) remoteController.getGlobalIconShapePath() else null
        )
        itemHolder.statusView.setClipToIconShape(!useGlobalShape)

        // 停止可能正在播放的动画
//        val oldDrawable = itemHolder.iconView.drawable
//        if (oldDrawable is Animatable) {
//            oldDrawable.stop()
//        }

        // 优先使用动态图标，否则回退到默认图标
        val isDynamicIcon = itemInfo.isDynamicIcon()
        val iconUrl = if (isDynamicIcon) itemInfo.dynamicIconUrl else itemInfo.iconUrl

        val glideRequest = GlideApp.with(PalmplayApplication.getAppInstance())
            .load(iconUrl)
            .placeholder(defaultIcon)
            .error(defaultIcon)
        if (useGlobalShape) {
            glideRequest.transform(CenterCrop()).into(itemHolder.iconView)
        } else {
            glideRequest.transform(CenterCrop(), RoundedCorners(dip2px(15f)))
                .into(itemHolder.iconView)
        }

        checkStatus(itemInfo, itemHolder.textView, itemHolder.statusView, itemHolder.ivDefaultIcon)

        itemHolder.itemView.tag = position
        itemHolder.itemView.setOnLongClickListener { v ->
            onLongClickListener?.invoke(v, position, itemInfo)
            true
        }

        itemHolder.rootView.setOnClickListener {
            if (itemInfo.isRecentlyInstalledItem()) {
                CloudFolderLauncher.launchFromRecentlyInstalled(itemInfo)
                if (CloudFolderManager.getInstance()
                        .shouldReportRecentlyInstalledAttribution(itemInfo.installedTime)) {
                    val pkg = itemInfo.packageName
                    val name = itemInfo.name
                    ioScope.launch {
                        val url = AttributionTools.getAttributionLink(pkg)
                        if (!url.isNullOrEmpty()) {
                            AttributionUploadManager.getInstance().enqueueNewRequest(arrayListOf(url), name)
                            LogUtils.d("RecentlyInstalled", "【最近安装·归因】attrSwitch通过，pkg=$pkg url=$url")
                        }
                    }
                }
                RecentlyInstalledTracker.reportClick(itemInfo, position, categoryType)
                return@setOnClickListener
            }
            if (itemInfo.isPreInstallItem()) {
                CloudFolderLauncher.launchFromPreInstall(itemInfo)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_OPEN_APP, itemInfo, position, itemInfo.jumpType)
                return@setOnClickListener
            }
            if (itemInfo.isOtherType()) {
                val launchType = CloudFolderLauncher.launchFromOtherType(itemInfo)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_INSTALL, itemInfo, position, itemInfo.jumpType, launchType)
                return@setOnClickListener
            }

            if (itemInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING) {
                return@setOnClickListener
            }

            if (FileDownloadInfo.isDownloading(itemInfo.observerStatus)) {
                DownloadManager.getInstance().onDownloadingPauseByUser(itemInfo.packageName, false, true)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_PAUSE, itemInfo, position)
            } else if (FileDownloadInfo.STATUS_PAUSE == itemInfo.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == itemInfo.observerStatus) {
                DownloadUtil.resumeDownload(PalmplayApplication.getAppInstance(), itemInfo.packageName)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_RESUME, itemInfo, position)
            } else {
                if (FileDownloadInfo.STATUS_NONE == itemInfo.observerStatus) {
                    trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_INSTALL, itemInfo, position)
                }
                val sign = if (categoryType == CATEGORY_APP) "A" else "G"
                val fromPage = "FL_${sign}_${SCENE_BOTTOM_NEW}_$position"
                CloudFolderManager.getInstance().startDownload(itemInfo, categoryType, fromPage)
            }
        }
    }

    private fun checkStatus(
        appInfo: AppInfo,
        itemName: TextView,
        statusView: BottomDownloadStatusView,
        ivDefaultIcon: ImageView
    ) {
        DownloadStatusManager.getInstance().registerInfoInstance(appInfo)

        if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
            return
        }

        when (appInfo.observerStatus) {
            FileDownloadInfo.STATUS_NONE -> {
                itemName.text = appInfo.name
                statusView.setProgress(0f)
            }
            FileDownloadInfo.STATUS_WAIT -> {
                itemName.text = PalmplayApplication.getAppInstance().getString(R.string.waiting)
            }
            FileDownloadInfo.STATUS_DOWNING, FileDownloadInfo.STATUS_NETWORK_ERROR -> {
                itemName.text = PalmplayApplication.getAppInstance().getString(R.string.text_downloading)
            }
            FileDownloadInfo.STATUS_PAUSE -> {
                itemName.text = PalmplayApplication.getAppInstance().getString(R.string.paused)
            }
            FileDownloadInfo.STATUS_DOWNLOADED -> {
                itemName.text = PalmplayApplication.getAppInstance().getString(R.string.click_install)
            }
            FileDownloadInfo.STATUS_INSTALLING -> {
                itemName.text = PalmplayApplication.getAppInstance().getString(R.string.text_installing)
            }
            FileDownloadInfo.STATUS_APP_INSTALLED, FileDownloadInfo.STATUS_APP_UPDATE -> {
                itemName.text = appInfo.name
            }
        }

        if (appInfo.observerStatus != FileDownloadInfo.STATUS_NONE && appInfo.observerStatus != FileDownloadInfo.STATUS_APP_UPDATE) {
            ivDefaultIcon.visibility = View.GONE
        } else {
            ivDefaultIcon.visibility = View.VISIBLE
        }

        if (appInfo.observerStatus == FileDownloadInfo.STATUS_WAIT ||
            appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING ||
            appInfo.observerStatus == FileDownloadInfo.STATUS_PAUSE ||
            appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED ||
            appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING ||
            appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {

            statusView.visibility = View.VISIBLE
            statusView.setStatus(appInfo.observerStatus, true)

            if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
                statusView.setProgress(appInfo.progress)
            }
        } else {
            statusView.visibility = View.GONE
        }
    }

    private fun trackClickWithParams(
        eventName: String,
        appInfo: AppInfo,
        position: Int,
        turnType: Int = 0,
        ctj: String? = null
    ) {
        CloudFolderTrackUtil.businessItemClickTrack(
            position,
            eventName,
            appInfo.packageName,
            categoryType,
            appInfo.isOffer,
            turnType,
            ctj,
            CloudFolderTrackUtil.SCENE_BOTTOM_NEW,
            cfValue = (appInfo as? CloudAppInfo)?.getCloudStyleString(),
        )
    }

    override fun getItemCount(): Int = items.size

    fun getAppInfo(position: Int): CloudAppInfo? {
        return if (position in items.indices) items[position] else null
    }

    override fun loaderInterfaceStatusChangeObjectKey(): Any {
        return this
    }

    override fun loaderInterfaceStatusChange(): InterfaceStatusChange {
        return object : InterfaceStatusChange {
            override fun onDownloadStart(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadProgressUpdate(
                downloadInfo: FileDownloadInfo,
                downloadedBytes: Long,
                fileLength: Long,
                speed: Int
            ) {
                downloadProgressUpdate(downloadInfo)
            }

            override fun onDownloadComplete(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onActivated(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadError(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadPause(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadResume(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadDelete(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onAppPackageAdded(packageName: String, versionCode: Int) {
                notifyDataSetChangedWithInterfaceStatusChange(null, packageName)
            }

            override fun onAppPackageRemoved(packageName: String, versionCode: Int, modifyStatusFrom: Int) {
                notifyDataSetChangedWithInterfaceStatusChange(null, packageName)
            }
        }
    }

    private fun downloadProgressUpdate(downloadInfo: FileDownloadInfo) {
        if (items.isNotEmpty()) {
            for (i in items.indices) {
                val item = items[i]
                if (!TextUtils.isEmpty(item.packageName) && item.packageName == downloadInfo.packageName) {
                    recyclerView?.findViewHolderForAdapterPosition(i)?.let { holder ->
                        if (holder is ItemViewHolder) {
                            val progress = downloadInfo.downloadedSize / downloadInfo.sourceSize.toFloat()
                            item.progress = progress
                            holder.statusView.setProgress(progress)
                        }
                    }
                    break
                }
            }
        }
    }

    private fun notifyDataSetChangedWithInterfaceStatusChange(
        downloadInfo: FileDownloadInfo?,
        packageName: String?
    ) {
        val position = if (downloadInfo != null) {
            DownloadStatusManager.checkObserverData(items, downloadInfo, true)
        } else {
            DownloadStatusManager.checkObserverDataWithTypeApp(items, packageName, true)
        }

        if (position in 0 until items.size) {
            val appInfo = items[position]
            DownloadStatusManager.getInstance().registerInfoInstance(appInfo)
            notifyItemChanged(position)
        }
    }
}

package com.afmobi.palmplay.activate;

import static com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager.EXCEPTION_EW_OTHER_SHOW;
import static com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager.TRACK_LOAD_ADS_ADD_QUEUE;

import android.content.Intent;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.language.LanguageSelectActivity;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.RecommendInstallResponse;
import com.afmobi.palmplay.recommendinstall.TRInstallActivity;
import com.afmobi.palmplay.recommendinstall.TRInstallCacheData;
import com.afmobi.palmplay.recommendinstall.TRInstallFullScreenActivity;
import com.afmobi.palmplay.recommendinstall.TRInstallManager;
import com.afmobi.palmplay.recommendinstall.TRInstallNewStyleActivity;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative;
import com.cloud.hisavana.ac.sdk.api.listener.AdListener;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/***
 * created by yongli.li
 * 装机必备的执行者
 */
public class TRMustInstallExecutor extends TRBaseExecutor {
    public static volatile boolean STATUS = false;//代表本身是否正在显示
    private static String positionID = "";
    private String mFromType = "";
    private long mEwRequestStartTime;
    private static volatile boolean mustInstallExclude = false;
    // 用于标记连续进入非屏蔽一键装机Activity次数，大于2次，标记一键装机可弹出
    private static final AtomicInteger enterActivityTimes = new AtomicInteger(0);

    @Override
    public boolean isCanShow(String fromType) {
        if (mustInstallExclude) {
            TRInstallManager.trackCommonInstall(TRAnalyticsConstant.SHOW_TYPE, -1,
                    "14", 4, 0, null, "", "", "", "", "", "", "", fromType);    // 新增埋点
            LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "老手 -> mustInstallExclude:" + mustInstallExclude + " ,return");
            return false;    //新增，被拦截
        } else {
            LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "老手 -> mustInstallExclude:" + mustInstallExclude + " ,continue");
        }
        //老手云控开关
        if (!ConfigManager.enableArCloudControl()) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Recommend install will not show,because clod Cloud control is closed");
            TRInstallManager.trackCommonInstall(TRAnalyticsConstant.SHOW_TYPE, -1, "13", 4, 0, null, "", "", "", "", "", "", "", fromType);
            return false;
        }
        //判断是否需要被拦截
        if (CommonUtils.isNeedDisableByDLC() || CommonUtils.isNeedGtIntercept(TRActivateConstant.GT_OLD_GUIDE)) {
            TRInstallManager.trackCommonInstall(TRAnalyticsConstant.SHOW_TYPE, -1, "12", 4, 0, null, "", "", "", "", "", "", "", fromType);
            return false;
        }
        return TRDialogUtil.mustInstallCanShow(fromType);
    }

    @Override
    public boolean show(String fromType) {
        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            return false;
        }

        if (TRDiskSpaceLimitExecutor.STATUS) {
            LogUtils.d(LogUtils.TAG_TR_INSTALL, "Must install will not show,because disk space limit activity is showing");
            return false;
        }
        mFromType = fromType;
        boolean hasEwCache = HisavanaSdkManager.getInstance().hasSceneCache(SceneCode.AR_X);
        if (hasEwCache) {
            mEwRequestStartTime = System.currentTimeMillis();
            positionID = HisavanaSdkManager.getInstance().getEwScenePositionID(SceneCode.AR_X);
            HisavanaSdkManager.getInstance().readyShowFixedScene(SceneCode.AR_X, mustInstallAdListener);
        } else {
            if (ConfigManager.enableARRealTimeControl()) {   // 没有缓存时，判断是否需要实时广告，仍走实时替换流程
                HisavanaSdkManager.getInstance().readyShowFixedRealTimeScene(SceneCode.AR_X);
            }
            launchActivity(false);
        }

        return true;
    }

    /**
     * 获取展示拦截次数
     *
     * @return
     */
    private int getBlockTimes() {
        int blockTimes = 0;
        JsonElement cacheData = FilePathManager.fileToJson(TRSharedPreferenceUtils.INSTALL_RECOMMEND_NEW_V2);
        if (cacheData != null) {
            try {
                RecommendInstallResponse.RecommendInstallInfo recommendInstallInfo = new Gson().fromJson(cacheData, RecommendInstallResponse.RecommendInstallInfo.class);
                if (recommendInstallInfo != null && recommendInstallInfo.configure != null) {
                    blockTimes = recommendInstallInfo.configure.showInterceptCount;
                }
            } catch (Throwable e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        return blockTimes;
    }

    /**
     * 插入EW数据
     *
     * @param featureItemDataList
     */
    public void insertEwDataToList(List<FeatureItemData> featureItemDataList) {
        if (featureItemDataList != null && featureItemDataList.size() > 0) {
            if (TRInstallCacheData.isGroupStyle()) {// 新的分组样式
                filerEwDataAndSupplyWithDspData(featureItemDataList);
            } else {
                List<AppInfo> orgInfoList = TRInstallCacheData.getAllDataList();
                Iterator<FeatureItemData> iterator = featureItemDataList.iterator();
                int row = 0;
                while (iterator.hasNext()) {
                    FeatureItemData featureItemData = iterator.next();
                    row = featureItemData.tNativeInfo.getTopicRow();
                    TRInstallCacheData.setEwRowInfo(row);

                    AppInfo info = FeatureItemData.convertToAppInfo(featureItemData);
                    info.reportSource = HisavanaSdkManager.REPORT_SOURCE_EW;
                    info.nativeId = featureItemData.tNativeInfo.getNativeAdId();
                    info.adPositionId = featureItemData.tNativeInfo.getPlacementId();
                    int fixedColumn = featureItemData.tNativeInfo.getTopicColumn();

                    TRAnalysticsUtil.trackAddShowQueue(positionID, SceneCode.AR_X, TRACK_LOAD_ADS_ADD_QUEUE,
                            featureItemData.packageName, row, fixedColumn);
                    TRInstallCacheData.addAdForRecommendList(null, orgInfoList, info, row, fixedColumn, true, false);
                }
            }
        }
    }

    private void filerEwDataAndSupplyWithDspData(List<FeatureItemData> featureItemDataList) {
        if (featureItemDataList != null && featureItemDataList.size() > 0) {
            List<RecommendInstallResponse.RecommendGroupInfo> groupStyleDataList = TRInstallCacheData.getGroupStyleDataList();
            RecommendInstallResponse.RecommendGroupInfo groupInfo = null;
            List<AppInfo> orgInfoList = null;
            int firstGroupLimit = 8;
            if (groupStyleDataList != null && groupStyleDataList.size() > 0) {
                groupInfo = groupStyleDataList.get(0);
                if (groupInfo != null) {
                    firstGroupLimit = groupInfo.showCount;
                    orgInfoList = groupInfo.itemList;
                }
            }
            LogUtils.d(LogUtils.TAG_TR_INSTALL_INSERT_EW, "firstGroupLimit = " + firstGroupLimit);

            int row = 0;
            Iterator<FeatureItemData> iterator = featureItemDataList.iterator();

            while (iterator.hasNext()) {
                FeatureItemData featureItemData = iterator.next();
                row = featureItemData.tNativeInfo.getTopicRow();
                TRInstallCacheData.setEwRowInfo(row);
                AppInfo info = FeatureItemData.convertToAppInfo(featureItemData);
                info.reportSource = HisavanaSdkManager.REPORT_SOURCE_EW;
                info.nativeId = featureItemData.tNativeInfo.getNativeAdId();
                info.adPositionId = featureItemData.tNativeInfo.getPlacementId();
                int fixedColumn = featureItemData.tNativeInfo.getTopicColumn();

                if (fixedColumn >= firstGroupLimit) {
                    if (groupStyleDataList != null && groupStyleDataList.size() >= 3) {
                        groupInfo = groupStyleDataList.get(2);
                        if (groupInfo != null) {
                            orgInfoList = groupInfo.itemList;
                            LogUtils.d(LogUtils.TAG_TR_INSTALL_INSERT_EW, "insert third group fixedColumn orginal = " + fixedColumn);
                            fixedColumn = fixedColumn - firstGroupLimit;
                            LogUtils.d(LogUtils.TAG_TR_INSTALL_INSERT_EW, "insert third group fixedColumn = " + fixedColumn);
                        } else {
                            orgInfoList = null;
                        }
                    } else {
                        orgInfoList = null;
                    }
                }

                TRAnalysticsUtil.trackAddShowQueue(positionID, SceneCode.AR_X, TRACK_LOAD_ADS_ADD_QUEUE,
                        featureItemData.packageName, row, fixedColumn);

                TRInstallCacheData.addAdForRecommendList(groupStyleDataList, orgInfoList, info, row, fixedColumn, true, true);
            }
            fillOrgInfoToEwPosition();
        }
    }

    public void fillOrgInfoToEwPosition() {
        List<RecommendInstallResponse.RecommendGroupInfo> groupStyleDataList = TRInstallCacheData.getGroupStyleDataList();
        RecommendInstallResponse.RecommendGroupInfo groupInfo = null;
        List<AppInfo> orgInfoList = null;
        int firstGroupLimit = 8;
        if (groupStyleDataList != null && groupStyleDataList.size() > 0) {
            groupInfo = groupStyleDataList.get(0);
            if (groupInfo != null) {
                firstGroupLimit = groupInfo.showCount;
            }
        }

        List<AppInfo> offerAndCpAndDSPList = TRInstallCacheData.getOfferAndCpAndDSPList();
        if (offerAndCpAndDSPList != null && offerAndCpAndDSPList.size() > 0) {
            List<Integer> cpInsert = TRInstallCacheData.getCpInsert();
            for (Integer index : cpInsert) {
                if (index >= firstGroupLimit) {
                    index = index - firstGroupLimit;
                    orgInfoList = getListByGroupId(groupStyleDataList, 2);
                } else {
                    orgInfoList = getListByGroupId(groupStyleDataList, 0);
                }
                //当前位置已经存在ew数据就跳过，进行下一个坑位填充
                if (orgInfoList != null && orgInfoList.size() > 0 && index > 0 && index < orgInfoList.size()) {
                    AppInfo appInfo = orgInfoList.get(index);
                    if (appInfo != null && TextUtils.equals(appInfo.reportSource, HisavanaSdkManager.REPORT_SOURCE_EW)) {
                        continue;
                    }
                }

                Iterator<AppInfo> iterator = offerAndCpAndDSPList.iterator();
                while (iterator.hasNext()) {
                    try {
                        AppInfo item = iterator.next();
                        //当前应用是否存在EW广告
                        boolean existEwData = TRInstallCacheData.isExistEwData(groupStyleDataList, item.packageName);
                        if (!existEwData) {
                            boolean result = TRInstallCacheData.setCpForRecommendList(groupStyleDataList, orgInfoList, item, 0, index, false, true);
                            if (result) {
                                iterator.remove(); // 安全删除元素
                            }
                            break;
                        } else {
                            iterator.remove(); // 安全删除元素
                        }
                    } catch (Exception e) {
                        LogUtils.d(LogUtils.TAG_TR_INSTALL, "e：" + e.getMessage());
                    }
                }
            }
        }
        TRInstallCacheData.handleShowCountAndSelectItemLogic();

    }

    private List<AppInfo> getListByGroupId(List<RecommendInstallResponse.RecommendGroupInfo> groupStyleDataList, int index) {
        if (groupStyleDataList != null && groupStyleDataList.size() > index) {
            RecommendInstallResponse.RecommendGroupInfo groupInfo = groupStyleDataList.get(index);
            if (groupInfo != null) {
                return groupInfo.itemList;
            }
        }
        return null;
    }


    private final AdListener mustInstallAdListener = new AdListener() {
        @Override
        public void onAdCache(List<TaNativeInfo> adInfos) {
            int count = adInfos != null ? adInfos.size() : 0;
            TRAnalysticsUtil.trackEwRspRecord(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_RSP_SUCCESS, count, 0, false);
            HisavanaSdkManager.getInstance().onTrackEWSDKResponse(adInfos, positionID, SceneCode.AR_X, true, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1, false);

            if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
                TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_ADS_EXCEPTION, EXCEPTION_EW_OTHER_SHOW);
                return;
            }

            if (TRDiskSpaceLimitExecutor.STATUS) {
                TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_ADS_EXCEPTION, EXCEPTION_EW_OTHER_SHOW);
                return;
            }
            if (adInfos != null && adInfos.size() > 0) {
                for (TaNativeInfo item : adInfos) {
                    LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, item.getAppInfo() + " count=" + adInfos.size());
                }
                LogUtils.d(LogUtils.TAG_TR_INSTALL, "reset EW block Times");
            }
            // todo app已安装 & 已下载过滤去重
            List<FeatureItemData> featureItemDataList = HisavanaSdkManager.getInstance().filterInstalledApp(adInfos, SceneCode.AR_X);
            // todo 更新位置 切尾巴
            HisavanaSdkManager.getInstance().fillAppIndexInfo(featureItemDataList, SceneCode.AR_X);
            if (featureItemDataList != null && !featureItemDataList.isEmpty()) {
                //todo 场景show 插入数据
                insertEwDataToList(featureItemDataList);
                List<TaNativeInfo> trackInfos = new ArrayList<>();
                for (FeatureItemData itemData : featureItemDataList) {
                    if (itemData != null && itemData.tNativeInfo != null) {
                        trackInfos.add(itemData.tNativeInfo);
                    }
                }
                TRInstallCacheData.saveNativeAdList(trackInfos);
                //     TrackingUtil.trackShows(trackInfos, SceneCode.AR_X); //  todo 挪到点击下载时上报
            }
            launchActivity(featureItemDataList != null && !featureItemDataList.isEmpty());
        }

        @Override
        public void onError(TaErrorCode adError) {
            super.onError(adError);
            int errorCode = -1;
            String errMsg = "";
            if (adError != null) {
                errorCode = adError.getErrorCode();
                errMsg = adError.getErrorMessage();
                LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, "AR get CacheError " + adError.getErrorMessage());
            }
            if (TRInstallCacheData.isGroupStyle()) {
                TRInstallCacheData.handleShowCountAndSelectItemLogic();
            }
            TRAnalysticsUtil.trackEWSdkErrorRsp(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_ERROR, errMsg, errorCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
            launchActivity(false);
        }

        @Override
        public void onTimeOut() {
            LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, "AR get Data onTimeOut");
            TRAnalysticsUtil.trackEWSDKResponse(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_TIME_OUT, "");
            if (TRInstallCacheData.isGroupStyle()) {
                TRInstallCacheData.handleShowCountAndSelectItemLogic();
            }
            launchActivity(false);
        }
    };

    public void launchActivity(boolean isEwCache) {
        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            return;
        }

        if (TRDiskSpaceLimitExecutor.STATUS) {
            return;
        }

        //没有ew缓存， 判断暂停展示次数
        if (!isEwCache) {
            //添加没有ew缓存埋点
            int ewShowTimes = TRSharedPreferenceUtils.getEwMustInstallShowTimes();
            int blockTimes = getBlockTimes();
            LogUtils.d(LogUtils.TAG_TR_INSTALL, "ew show block -->  showTimes:" + ewShowTimes + "  blockTimes:" + blockTimes);
            boolean isBlock = ewShowTimes < blockTimes;
            if (isBlock) {
                ewShowTimes += 1;
                TRSharedPreferenceUtils.setEwMustInstallShowTimes(ewShowTimes);
                LogUtils.d(LogUtils.TAG_TR_INSTALL, "ew show block -->  block install show ");
                return;
            }
            if (TRInstallCacheData.isGroupStyle()) {
                //EW无数据则
                HisavanaSdkManager.getInstance().updateOrgPositionFillInfo(SceneCode.AR_X);
                fillOrgInfoToEwPosition();
            } else {
                TRInstallCacheData.handleShowCountAndSelectItemLogic();
            }
        }
        TRSharedPreferenceUtils.setEwMustInstallShowTimes(0);
        //重置静默期请求次数
        TRSharedPreferenceUtils.setSilentMustInstallRequestTimes(0);

        //展示老用户一键装机场景时就调用ew设置展示时间
        String positionID = HisavanaSdkManager.getInstance().getEwScenePositionID(SceneCode.AR_X);
        if (TextUtils.isEmpty(positionID)) {
            return;
        }
        TFeedNative feedNative = new TFeedNative(positionID);
        feedNative.setShowAdTime();
        List<AppInfo> appInfos = TRInstallCacheData.getAllDataList();

        Intent intent = new Intent();
        if (TRInstallCacheData.isDialogStyle() && !TRInstallCacheData.isDialogStyleDataEmpty()) {
            intent.setClass(PalmplayApplication.getAppInstance(), TRInstallActivity.class);
        } else if (TRInstallCacheData.isGroupStyle() && !TRInstallCacheData.isGroupStyleDataEmpty()) {
            intent.setClass(PalmplayApplication.getAppInstance(), TRInstallNewStyleActivity.class);
        } else if (appInfos != null && !appInfos.isEmpty()) {
            intent.setClass(PalmplayApplication.getAppInstance(), TRInstallFullScreenActivity.class);
        } else {
            mFromType = "";
            return;
        }
        intent.putExtra("ewRequestStartTime", mEwRequestStartTime);
        intent.putExtra(Constant.KEY_FROM_TYPE, mFromType);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PalmplayApplication.getAppInstance().startActivity(intent);
        mFromType = "";
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }

    public static boolean getMustInstallExclude() {
        return mustInstallExclude;
    }

    public static void setMustInstallExclude() {
        mustInstallExclude = true;
        enterActivityTimes.set(0);
        LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "mustInstallExclude: " + mustInstallExclude + " enterActivityTimes:" + enterActivityTimes);
    }

    public static void unsetMustInstallExclude() {
        if (enterActivityTimes.get() >= 1) {
            mustInstallExclude = false;
        } else {
            enterActivityTimes.getAndIncrement();
        }
        LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "mustInstallExclude: " + mustInstallExclude + " enterActivityTimes:" + enterActivityTimes);
    }

}

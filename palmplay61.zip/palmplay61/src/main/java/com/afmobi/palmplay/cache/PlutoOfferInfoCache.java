package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.apk.PalmIpcServiceManager;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.model.PlutoOfferResponseModel;
import com.transsion.palmstorecore.log.LogUtils;

import java.util.ArrayList;
import java.util.List;

public class PlutoOfferInfoCache {

    public static final String PLUTO_OFFER_INFO_CACHE = "PLUTO_OFFER_INFO_CACHE";

    private static volatile PlutoOfferInfoCache mInstance;
    private static int SHOW_MAX_COUNT = 3;

    public static PlutoOfferInfoCache getInstance() {
        if (mInstance == null) {
            synchronized (PlutoOfferInfoCache.class) {
                if (mInstance == null) {
                    mInstance = new PlutoOfferInfoCache();
                }
            }
        }

        return mInstance;
    }

    public void saveToCacheNotify(PlutoOfferResponseModel plutoOfferResponseModel) {
        ACache.get(PalmplayApplication.getAppInstance()).put(PLUTO_OFFER_INFO_CACHE, plutoOfferResponseModel);
        //通知页面更新
        savePushId(plutoOfferResponseModel);
        LogUtils.d(LogUtils.TAG_PLUTO,"saveToCacheNotify()");
        // 通知PalmA监测亮屏
        PalmIpcServiceManager.getInstance().updateMonitorInfo(true,0,plutoOfferResponseModel.getData().getConfig().getConvertInterval());
    }

    public void savePushId(PlutoOfferResponseModel plutoOfferResponseModel){
        if(plutoOfferResponseModel != null
                && plutoOfferResponseModel.getData() != null
                && plutoOfferResponseModel.getData().getPush() != null
                && !TextUtils.isEmpty(plutoOfferResponseModel.getData().getPush().getPushId())){
            PlutoPushIdCache.getInstance().putPushIdToFile(plutoOfferResponseModel.getData().getPush().getPushId());
        }
    }

    public PlutoOfferResponseModel loadFromCache() {
        Object object = ACache.get(PalmplayApplication.getAppInstance()).getAsObject(PLUTO_OFFER_INFO_CACHE);
        if(object != null && object instanceof PlutoOfferResponseModel){
            return (PlutoOfferResponseModel)object;
        }
        return null;
    }

    public List<PlutoOfferResponseModel.DataBean.PushBean.ApkListBean> getApkList(PlutoOfferResponseModel  plutoOfferResponseModel){
        if(plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null && plutoOfferResponseModel.getData().getPush() != null){
            return plutoOfferResponseModel.getData().getPush().getApkList();
        }else{
            return new ArrayList<>();
        }
    }

	public long getLastFillTime(){
		long lastFillTime = 0;
        PlutoOfferResponseModel  plutoOfferResponseModel = loadFromCache();
        if(plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null && plutoOfferResponseModel.getData().getPush() != null){
            lastFillTime = plutoOfferResponseModel.getData().getPush().getLastFillTime();
        }
        return lastFillTime;
    }

    /**
     * 从服务器获取的弹框时间间隔，单位是分钟，默认（1440分钟 = 24小时）
     * @return
     */
    public long getInduceInterval(){
        long induceInterval = 1440  * 60 * 1000;
        PlutoOfferResponseModel  plutoOfferResponseModel = loadFromCache();
        if(plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null && plutoOfferResponseModel.getData().getConfig() != null){
            induceInterval = plutoOfferResponseModel.getData().getConfig().getConvertInterval();
        }
        return induceInterval;
    }

    /**
     * 从服务器获取是否展示ew物料
     * @return
     */
    public String getPlutoEwSdk(){
        PlutoOfferResponseModel  plutoOfferResponseModel = loadFromCache();
        String toOther = "";
        if(plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null){
            toOther = plutoOfferResponseModel.getData().toOther;
        }
        return toOther;
    }

    /***
     * 锁屏或者其他场景需要显示的弹框物料
     * @return
     */
    public PlutoOfferResponseModel.DataBean.PushBean.ApkListBean getValidShowEntry() {
        PlutoOfferResponseModel plutoOfferResponseModel = loadFromCache();
        if (plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null && plutoOfferResponseModel.getData().getPush() != null) {
            List<PlutoOfferResponseModel.DataBean.PushBean.ApkListBean> listBeans = plutoOfferResponseModel.getData().getPush().getApkList();
            if (listBeans == null || listBeans.size() <= 0) {
                return null;
            }
            long gapTime = getIntervalShowTime(plutoOfferResponseModel);
            for (int i =0; i < listBeans.size(); i++) {
                if (listBeans.get(i) != null
                        && listBeans.get(i).isInstalled
                        && listBeans.get(i).showCount < SHOW_MAX_COUNT
                        && System.currentTimeMillis() - listBeans.get(i).lastShowTime >= gapTime) {
                    return listBeans.get(i);
                }
            }
        }
        return null;
    }

    /***
     * 调用时机：1. 激活弹框展示的时候 2.从pluto安装后又卸载的时候
     * 修改其apk的属性状态
     * @param pck 包名
     * @param installed 是否已经安装（存在已经安装，也存卸载）
     */
    public void updateApkStatus(String pck, boolean installed) {
        PlutoOfferResponseModel plutoOfferResponseModel = loadFromCache();
        if(plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null && plutoOfferResponseModel.getData().getPush() != null){
            PlutoOfferResponseModel.DataBean.PushBean.ApkListBean bean = plutoOfferResponseModel.getData().getPush().getAPk(pck);
            if (bean != null) {
                int count = bean.showCount;
                if (!installed) { //代表从pluto安装后又卸载了
                    bean.showCount = count <= 0 ? 0 : count -1;
                } else {//已经安装后的弹窗
                    bean.showCount = count + 1;
                }
                bean.isInstalled = installed; //修改是否已经安装
                bean.lastShowTime = System.currentTimeMillis(); //修改最近显示的时间
                saveToCacheNotify(plutoOfferResponseModel);
            }
        }
    }

    /***
     * 获取激活弹框的服务端显示的间隔时间
     * @return
     */
    public long getIntervalShowTime(PlutoOfferResponseModel  plutoOfferResponseModel) {
        if (plutoOfferResponseModel == null) {
            plutoOfferResponseModel = loadFromCache();
        }
        if (plutoOfferResponseModel != null && plutoOfferResponseModel.getData() != null && plutoOfferResponseModel.getData().getConfig() != null) {
            return plutoOfferResponseModel.getData().getConfig().getInduceInterval();
        }
        return 0;
    }

}

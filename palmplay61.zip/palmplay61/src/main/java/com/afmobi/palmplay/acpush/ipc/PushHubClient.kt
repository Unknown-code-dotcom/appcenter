package com.afmobi.palmplay.acpush.ipc

import android.content.Context
import android.net.Uri
import android.os.Bundle
import com.afmobi.palmplay.acpush.model.PushRecordItem
import com.afmobi.palmplay.model.ClientVersion
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.transsion.palmstorecore.log.LogUtils

/**
 * PM 推送中枢的 IPC 封装。
 *
 * 调用 com.transsion.pushsdk.provider 的两个 call 方法：
 *   - receive_message：上报候选包名列表 + 自动注册自身 authority
 *   - report_event：上报 IMPRESSION / CLICK / DISMISS 事件
 *
 * 所有 IPC 失败异常都被吞掉（记 Log），不影响主流程。
 */
object PushHubClient {

    private val TAG = LogUtils.TAG_AC_PUSH

    private const val HUB_AUTHORITY = "com.transsion.pushsdk.provider"
    private const val HUB_URI = "content://$HUB_AUTHORITY"

    /** AC 自身向 PM 注册时上报的 authority */
    private const val AC_AUTHORITY = "com.transsion.ac.provider.push"

    private const val METHOD_RECEIVE_MESSAGE = "receive_message"
    private const val METHOD_REPORT_EVENT = "report_event"

    const val MESSAGE_TYPE_AC_UPDATE = "AC_UPDATE"

    private val gson = Gson()

    /** AC 向 PM 上报的轻量包名信息：仅 packageName + versionCode */
    private data class Pkg(
        @SerializedName("packageName") val packageName: String,
        @SerializedName("versionCode") val versionCode: Long
    )

    /**
     * 上报候选包名 + 自动注册。
     *
     * @return true 表示 PM receive_message 调用成功；S/A 包名列表由 update_config 单独下发。
     */
    fun receiveMessage(
        context: Context,
        items: List<ClientVersion.UpdateItem>
    ): Boolean {
        val source = context.packageName
        // 注意：UpdateItem 的版本号字段名是 `version`（int），不是 versionCode
        val packages = items.map { Pkg(it.packageName, it.version.toLong()) }
        val extras = Bundle().apply {
            putString("packages_json", gson.toJson(packages))
            putString("authority", AC_AUTHORITY)
            putString("package_name", context.packageName)
            putString("source", source)
            putString("message_type", MESSAGE_TYPE_AC_UPDATE)
        }
        return try {
            if (!hasHubProvider(context)) {
                LogUtils.d(TAG, "pm receive_message skipped, provider not found, authority=$HUB_AUTHORITY")
                return false
            }
            LogUtils.d(TAG, "pm receive_message calling, source=$source, itemCount=${items.size}, messageType=$MESSAGE_TYPE_AC_UPDATE")
            val result = context.contentResolver.call(
                Uri.parse(HUB_URI), METHOD_RECEIVE_MESSAGE, null, extras
            )
            if (result?.getBoolean("success", false) != true) {
                val error = result?.getString("error")
                LogUtils.d(TAG, "pm receive_message finished, success=false, source=$source, itemCount=${items.size}, error=$error")
                return false
            }
            LogUtils.d(TAG, "pm receive_message finished, success=true, source=$source, itemCount=${items.size}")
            true
        } catch (e: Exception) {
            LogUtils.e(TAG, "receive_message IPC failed", e)
            false
        }
    }

    /**
     * 上报单条通知的事件。records 为该通知实际展示的应用列表；失败重试一次，仍失败丢弃。
     */
    @JvmOverloads
    fun reportEvent(
        context: Context,
        records: List<PushRecordItem>,
        eventType: EventType,
        messageType: String = MESSAGE_TYPE_AC_UPDATE
    ) {
        if (records.isEmpty()) return
        val source = context.packageName
        val extras = Bundle().apply {
            putString("records_json", gson.toJson(records))
            putString("event_type", eventType.raw)
            putString("message_type", messageType)
            putString("source", source)
        }
        repeat(2) { attempt ->
            try {
                if (!hasHubProvider(context)) {
                    LogUtils.d(TAG, "pm report_event skipped, provider not found, authority=$HUB_AUTHORITY, eventType=${eventType.raw}")
                    return
                }
                LogUtils.d(TAG, "pm report_event calling, eventType=${eventType.raw}, recordCount=${records.size}, messageType=$messageType, source=$source, attempt=${attempt + 1}")
                val result = context.contentResolver.call(
                    Uri.parse(HUB_URI), METHOD_REPORT_EVENT, null, extras
                )
                LogUtils.d(TAG, "pm report_event finished, success=true, eventType=${eventType.raw}, recordCount=${records.size}, messageType=$messageType, source=$source, attempt=${attempt + 1}, hasResult=${result != null}")
                return
            } catch (e: Exception) {
                if (attempt == 1) {
                    LogUtils.e(TAG, "report_event IPC failed for ${records.map { it.packageName }}/$eventType", e)
                }
            }
        }
    }

    private fun hasHubProvider(context: Context): Boolean {
        return try {
            val providerInfo = context.packageManager.resolveContentProvider(HUB_AUTHORITY, 0)
            val exists = providerInfo != null
            LogUtils.d(TAG, "pm provider check, authority=$HUB_AUTHORITY, exists=$exists")
            exists
        } catch (e: Exception) {
            LogUtils.e(TAG, "pm provider check failed, authority=$HUB_AUTHORITY", e)
            false
        }
    }

    enum class EventType(val raw: String) {
        IMPRESSION("IMPRESSION"),
        CLICK("CLICK"),
        DISMISS("DISMISS")
    }
}

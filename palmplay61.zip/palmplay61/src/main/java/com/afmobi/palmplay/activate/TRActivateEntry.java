package com.afmobi.palmplay.activate;

import com.transsion.palmstorecore.analytics.apm.source.PSLaunchUtil;

/***
 * created by yongli.li
 * 活动跳转的临时类，方便统一处理
 * 里面仅包含事件跳转所需要的参数
 */
public class TRActivateEntry {
    public String jumpType;
    public String jumpUrl;//跳转的url,有可能是deeplink，也有可能是h5的链接,也可能是itemid，就是对应跳转的必须值
    public String jumpExt;
    public String curPage;//通用，当前的页面
    public String lastPage;//通用，落地页
    public String fromPage;//通用，从哪里来
    public String position;//预留字段，如果有需要的
    public String versionCode;
    public String pck;
    public String value;
    public boolean isAutoDownload = false;//添加预留通用字段是否支持自动下载，不放在构造函数，避免已经使用地方改动过多

    public long taskId;

    public String type; //来源：AD, NAV，PUSH

    public String cfgId;
    public String reportSource;
    public String nativeId;

    public String gameId;
    public String openUrl;
    public String name;
    public String iconUrl;

    public String assetCount;//资产数
    public int pushType = PSLaunchUtil.pushType;//3表示push

    public TRActivateEntry(String jumpUrl, String jumpType, String jumpExt, String pck, String versionCode, String curPage, String lastPage,
                           String fromPage, String position, String value, long taskId) {
        this.jumpUrl = jumpUrl;
        this.jumpType = jumpType;
        this.jumpExt = jumpExt;
        this.pck = pck;
        this.versionCode = versionCode;
        this.curPage = curPage;
        this.lastPage = lastPage;
        this.fromPage = fromPage;
        this.position = position;
        this.value = value;

        this.taskId = taskId;
    }

    public TRActivateEntry(String jumpType, String gameId,String openUrl,String name,String iconUrl) {
        this.gameId = gameId;
        this.openUrl = openUrl;
        this.name = name;
        this.iconUrl = iconUrl;
        this.jumpType = jumpType;
    }

    public void setNativeId(String id) {
        this.nativeId = id;
    }

    public void setAssetCount(String assetCount) {
        this.assetCount = assetCount;
    }

    @Override
    public String toString() {
        return "TRActivateEntry{" +
                "jumpType='" + jumpType + '\'' +
                ", jumpUrl='" + jumpUrl + '\'' +
                ", jumpExt='" + jumpExt + '\'' +
                ", curPage='" + curPage + '\'' +
                ", lastPage='" + lastPage + '\'' +
                ", fromPage='" + fromPage + '\'' +
                ", position='" + position + '\'' +
                ", versionCode='" + versionCode + '\'' +
                ", pck='" + pck + '\'' +
                ", value='" + value + '\'' +
                ", isAutoDownload=" + isAutoDownload +
                ", taskId=" + taskId +
                ", type='" + type + '\'' +
                ", cfgId='" + cfgId + '\'' +
                ", reportSource='" + reportSource + '\'' +
                ", nativeId='" + nativeId + '\'' +
                ", assetCount='" + assetCount + '\'' +
                ", pushType=" + pushType +
                '}';
    }
}

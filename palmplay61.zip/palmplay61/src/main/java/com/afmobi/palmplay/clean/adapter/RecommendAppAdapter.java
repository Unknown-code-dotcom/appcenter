package com.afmobi.palmplay.clean.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.customview.RoundProgressBar;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by xiangfei.wei on 2017/11/23.
 */
@Deprecated
public class RecommendAppAdapter extends PalmBaseDownloadRecyclerViewAdapter {
    private static final int MAX_DATA_COUNT = 4;
    private static final int ITEM_TYPE_NORAML_DATA = 1;
    private static final int ITEM_TYPE_EMPTY_FILL = -1;
    private Context mContext;
    private List<RankDataListItem> mDatas;
    private PageParamInfo mPageParamInfo;
    private RecyclerView recyclerView;
    private List<RankDataListItem> originalDatas;
    private RankDataListItem mEmptyItemData = new RankDataListItem();

    public RecommendAppAdapter(Context context, List<RankDataListItem> datas, PageParamInfo mPageParamInfo, RecyclerView recyclerView) {
        mContext = context;
        originalDatas = datas;
//        mDatas = originalDatas.size() > 4 ? originalDatas.subList(0, 4) : originalDatas;
//        mDatas = new ArrayList<>(4);
//        for (int i = 0; i < originalDatas.size(); i++) {
//            if (i >= 4) {
//                break;
//            }
//            mDatas.add((RankDataListItem) originalDatas.get(i).clone());
//        }
        resetData();

        this.mPageParamInfo = mPageParamInfo;
        this.recyclerView = recyclerView;
    }

    private void resetData(){
        mDatas = new ArrayList<>(MAX_DATA_COUNT);
        for (int i = 0; i < originalDatas.size(); i++) {
            if (i >= MAX_DATA_COUNT) {
                break;
            }
            mDatas.add((RankDataListItem) originalDatas.get(i).clone());
        }

        while (mDatas.size() < MAX_DATA_COUNT){
            mDatas.add(mEmptyItemData);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new RecommendAppViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_recommend_app_item, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int type = getItemViewType(position);
        RankDataListItem item = mDatas.get(position);
        RecommendAppViewHolder viewHolder = (RecommendAppViewHolder) holder;
        if(type == ITEM_TYPE_NORAML_DATA){
            viewHolder.itemLayout.setVisibility(View.VISIBLE);
            viewHolder.tv_name.setText(item.name);
            int defaultIcon = R.drawable.layer_list_app_default_01_bg;
            int corner = 0;
            GlideUtils.setImageUrl(viewHolder.iv_icon, item.iconUrl, corner, defaultIcon, defaultIcon);
            checkStatus(item, viewHolder.layout_download, viewHolder.tv_download, viewHolder.iv_status, viewHolder.progressbar_downloading, viewHolder.tv_percent);
        }else {
            viewHolder.itemLayout.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    public void checkStatus(RankDataListItem mRankDataListItem, LinearLayout layout_download, TextView tv_download, ImageView iv_status, RoundProgressBar progressbar_downloading, TextView tv_percent) {
        if (mRankDataListItem == null)
            return;
        DownloadStatusManager.getInstance().registerInfoInstance(mRankDataListItem);
        tv_download.setText(mRankDataListItem.getStatusNameResID());
        if ("T".equals(mRankDataListItem.showPlay)) {
            tv_download.setBackgroundResource(R.drawable.selector_download_btn_blue);
            tv_download.setTextColor(tv_download.getContext().getResources().getColor(R.color.color_ffffff));
            return;
        }

        switch (mRankDataListItem.observerStatus) {
            case FileDownloadInfo.STATUS_NONE:
                layout_download.setVisibility(View.GONE);
                break;
            case FileDownloadInfo.STATUS_APP_UPDATE:
                layout_download.setVisibility(View.VISIBLE);
                progressbar_downloading.setVisibility(View.GONE);
                tv_percent.setVisibility(View.GONE);
                tv_download.setVisibility(View.VISIBLE);
                iv_status.setVisibility(View.VISIBLE);
                iv_status.setImageResource(R.drawable.icon_accelerate_update);
                break;
            case FileDownloadInfo.STATUS_APP_INSTALLED:
                break;
            case FileDownloadInfo.STATUS_DOWNLOADED:
                layout_download.setVisibility(View.VISIBLE);
                progressbar_downloading.setVisibility(View.GONE);
                tv_percent.setVisibility(View.GONE);
                tv_download.setVisibility(View.VISIBLE);
                iv_status.setVisibility(View.VISIBLE);
                iv_status.setImageResource(R.drawable.icon_accelerate_install);
                break;
            case FileDownloadInfo.STATUS_WAIT:
            case FileDownloadInfo.STATUS_DOWNING:
                layout_download.setVisibility(View.VISIBLE);
                tv_download.setVisibility(View.GONE);
                iv_status.setVisibility(View.GONE);
                progressbar_downloading.setVisibility(View.VISIBLE);
                tv_percent.setVisibility(View.VISIBLE);
                FileDownloadInfo downloadingInfo = DownloadManager.getInstance().getDownloadingInfo(mRankDataListItem.packageName);
                if (null != downloadingInfo && downloadingInfo.sourceSize > 0) {
                    float progress = downloadingInfo.downloadedSize * 100 / downloadingInfo.sourceSize;
                    progressbar_downloading.setProgress((int) progress);
                    tv_percent.setText((int) progress + "%");
                }
                break;
            case FileDownloadInfo.STATUS_PAUSE:
                layout_download.setVisibility(View.VISIBLE);
                progressbar_downloading.setVisibility(View.GONE);
                tv_percent.setVisibility(View.GONE);
                tv_download.setVisibility(View.VISIBLE);
                iv_status.setVisibility(View.VISIBLE);
                iv_status.setImageResource(R.drawable.icon_accelerate_continue);
                break;

            default:
                break;
        }
    }

    class DownloadBtnOnClickListener implements View.OnClickListener {

        private RecommendAppViewHolder holder;
        private RankDataListItem mRankDataListItem;
        private View bindClickView;


        public DownloadBtnOnClickListener(RecommendAppViewHolder holder, RankDataListItem mRankDataListItem, View bindClickView) {
            this.holder = holder;
            this.mRankDataListItem = mRankDataListItem;
            this.bindClickView = bindClickView;
        }

        @Override
        public void onClick(View v) {
            if (bindClickView == null || holder == null || mRankDataListItem == null)
                return;

            if (bindClickView.getId() == holder.iv_icon.getId()) {
                startDownload(mRankDataListItem, holder);
            }

        }

        private void startDownload(RankDataListItem mRankDataListItem, RecommendAppViewHolder holder) {
            if (mRankDataListItem == null)
                return;

            if (FileDownloadInfo.isDownloading(mRankDataListItem.observerStatus)) {
                DownloadManager.getInstance().pauseDownload(mRankDataListItem.packageName);

            } else if (FileDownloadInfo.STATUS_PAUSE == mRankDataListItem.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == mRankDataListItem.observerStatus) {
                DownloadUtil.resumeDownload(mContext, mRankDataListItem.packageName);

            } else {

                if (DownloadDecorator.checkJumpToGooglePlay(mContext, mRankDataListItem.outerUrl, mRankDataListItem.packageName, mPageParamInfo, mRankDataListItem.itemID, mRankDataListItem.version, mRankDataListItem.verifyGoogle)) {
                    return;
                }
                DownloadDecorator.startDownloading(mRankDataListItem, PageConstants.Function_Page, mPageParamInfo, null, null);
            }
        }
    }

    @Override
    public Object loaderInterfaceStatusChangeObjectKey() {
        return this;
    }

    @Override
    public InterfaceStatusChange loaderInterfaceStatusChange() {
        return new InterfaceStatusChange() {
            @Override
            public void onDownloadStart(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadComplete(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onActivated(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadError(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadPause(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadResume(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadDelete(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onAppPackageAdded(String packageName, int versionCode) {
                onAppPackageChange(packageName, versionCode, true);
            }

            @Override
            public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
                onAppPackageChange(packageName, versionCode, false);
            }


            @Override
            public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {
                if (downloadInfo != null && !downloadInfo.isVa() && downloadInfo.sourceSize > 0) {
                    float progress = downloadInfo.downloadedSize * 100f / downloadInfo.sourceSize;
                    updateItemProgress(downloadInfo.packageName, (int) progress);
                }
            }

        };
    }

    private void updateItemProgress(String packageName, int progress) {
        if (mDatas != null && mDatas.size() > 0) {
            RankDataListItem item;
            for (int i = 0; i < mDatas.size(); i++) {
                item = mDatas.get(i);
                if (!TextUtils.isEmpty(item.packageName) && item.packageName.equals(packageName)) {
                    int type = (TextUtils.isEmpty(item.detailType)) ? (item.cus_detailType) : (DetailType.getType(item.detailType));
                    if (!DetailType.isApp(type))
                        continue;
                    View view = recyclerView.getLayoutManager().findViewByPosition(i);
                    if (view != null)
                        checkStatus(item, (LinearLayout) view.findViewById(R.id.layout_download), (TextView) view.findViewById(R.id.tv_download), (ImageView) view.findViewById(R.id.iv_status),
                                (RoundProgressBar) view.findViewById(R.id.progressbar_downloading), (TextView) view.findViewById(R.id.tv_percent));
                    break;
                }
            }
        }
    }

    private void onAppPackageChange(String packageName, int versionCode, boolean isInsatll) {
//        DownloadStatusManager.registerInfoInstance(null, packageName);
//        int index = -1;
//        //原始数据中的该条数据删除
//        for (int i = 0; i < originalDatas.size(); i++) {
//            if (packageName.equals(originalDatas.get(i).packageName)) {
//                index = i;
//                break;
//            }
//        }
//        if (index >= 0)
//            originalDatas.remove(index);
//        //adapter数据中的该条数据删除
//        index = -1;
//        for (int i = 0; i < mDatas.size(); i++) {
//            if (packageName.equals(mDatas.get(i).packageName)) {
//                index = i;
//                break;
//            }
//        }
//        if (index >= 0)
//            mDatas.remove(index);
//        //从原始数据中取出一个adapter数据中没有的，添加进adapter数据中
//        index = -1;
//        for (int i = 0; i < originalDatas.size(); i++, index = -1) {
//            for (int j = 0; j < mDatas.size(); j++) {
//                if (originalDatas.get(i).packageName.equals(mDatas.get(j).packageName)) {
//                    index = -2;
//                    break;
//                }
//            }
//            if (index == -1) {
//                index = i;
//                break;
//            }
//        }
//        if (index >= 0)
//            mDatas.add((RankDataListItem) originalDatas.get(index).clone());

        if(isInsatll){
            int index = -1;
            //原始数据中的该条数据删除
            for (int i = 0; i < originalDatas.size(); i++) {
                if (packageName.equals(originalDatas.get(i).packageName)) {
                    index = i;
                    break;
                }
            }
            if (index >= 0)
                originalDatas.remove(index);

            resetData();

            notifyDataSetChanged();
        }

    }

    private void notifyDataSetChangedWithInterfaceStatusChange(FileDownloadInfo downloadInfo) {

        int position = DownloadStatusManager.checkObserverData(mDatas, downloadInfo, true);
        if (mDatas != null && position >= 0 && position < mDatas.size()) {
            DownloadStatusManager.getInstance().registerInfoInstance(mDatas.get(position));
            notifyDataSetChanged();
        }

    }

    @Override
    public int getItemViewType(int position) {
        if(position < 0 || position >= getItemCount())
            return ITEM_TYPE_EMPTY_FILL;

        RankDataListItem itemData = mDatas.get(position);
        if(itemData == mEmptyItemData || itemData.itemID == null){
            return ITEM_TYPE_EMPTY_FILL;
        }
        return ITEM_TYPE_NORAML_DATA;
    }

    private class RecommendAppViewHolder extends RecyclerView.ViewHolder {
        public ImageView iv_icon;
        public TextView tv_name, tv_percent, tv_download;
        public RoundProgressBar progressbar_downloading;
        public LinearLayout layout_download;
        public ImageView iv_status;
        public View itemLayout;

        RecommendAppViewHolder(View itemView) {
            super(itemView);
            iv_icon =  itemView.findViewById(R.id.iv_icon);
            tv_name = (TextView) itemView.findViewById(R.id.tv_name);
            progressbar_downloading = (RoundProgressBar) itemView.findViewById(R.id.progressbar_downloading);
            tv_percent = (TextView) itemView.findViewById(R.id.tv_percent);
            tv_download = (TextView) itemView.findViewById(R.id.tv_download);
            layout_download = (LinearLayout) itemView.findViewById(R.id.layout_download);
            iv_status = (ImageView) itemView.findViewById(R.id.iv_status);
            itemLayout = itemView.findViewById(R.id.layout_01);
        }
    }
}

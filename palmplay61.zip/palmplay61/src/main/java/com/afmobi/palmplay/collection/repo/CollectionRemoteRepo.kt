package com.afmobi.palmplay.collection.repo

import com.afmobi.palmplay.model.v6_3.FeatureResponse
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import com.afmobi.palmplay.network.AsyncHttpRequestUtils
import com.afmobi.palmplay.network.NetworkClient
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.AbsRequestListener
import com.transsion.palmstorecore.log.LogUtils
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class CollectionRemoteRepo() {
    private val TAG = "${LogUtils.TAG_COLLECTION}CollectionRemoteRepo"

    fun getCollections(tabId: String, tag: String = "rec_collection"): Flow<FeaturedModel?> = callbackFlow {
        LogUtils.d(TAG, "tabId=$tabId tag=$tag")
        // 1. 注册回调
        val callback = object: AbsRequestListener<FeatureResponse>(){
            override fun onResponse(response: FeatureResponse) {
                trySend(response.data)
                LogUtils.d(TAG, "response=$response")
            }

            override fun onError(anError: ANError?) {
                trySend(null)
                LogUtils.e(TAG, "anError=$anError")
            }
        }
        // 2. 绑定到第三方API
        NetworkClient.fetchCollectionListHttpRequest(tabId, false, callback, tag)
        // 3. 定义取消逻辑
        awaitClose {
            AsyncHttpRequestUtils.cancel(tag)
        }
    }
}
package com.afmobi.palmplay.admgr;

import android.content.Context;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.ownad.OwnAdLoadListener;
import com.afmobi.palmplay.admgr.ownad.OwnSplashView;
import com.afmobi.palmplay.cache.AdCache;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.google.firebase.analytics.FirebaseAnalytics;

public class AdsLoadProxy {

    public static String TAG = "AdsLoadLog";
    private final static long AD_DURATION_MAX = 1600;

    public final static int TYPE_NORMAL = 0x101;
    public final static int TYPE_UNDO = 0x102;
    public final static int TYPE_ONCE = 0x103;
    public final static int TYPE_PRELOAD = 0x104;


    private OwnSplashView mOwnView;
    private Context mContext;

    private boolean isTimeOut = false;
    private boolean isOwnAdError = false;
    private boolean isOwnAdLoad = false;
    private boolean isSspAdLoad = false;

    private int mAdDealType = TYPE_NORMAL;

    private AdsListener mAdsListener = null;


    public AdsLoadProxy(Context context) {
        this.mContext = context;

    }


    public void setAdsLoadListener(AdsListener l) {
        this.mAdsListener = l;
    }



    public void onOwnAdPreLoad(OwnAdBean adBean) {

        if(mContext == null || adBean == null) {
            return;
        }

        mOwnView = new OwnSplashView(mContext);
        mOwnView.setAdBean(adBean);
        mOwnView.setOwnAdLoadListener(mOwnAdListener);

        if(TYPE_PRELOAD == mAdDealType) {
            mOwnView.onAdPreLoad();
        } else {
            mOwnView.onAdLoad();
        }

        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.SPLASH_AD_REQUEST, null);
    }



    public void setAdDealType(int type) {
        this.mAdDealType = type;
    }

    public int getAdDealType() {
        return this.mAdDealType;
    }


    public void onResume() {
        if(mOwnView != null) {
            mOwnView.resumeSplashView();
        }
    }


    public void onStop() {
        if(mOwnView != null) {
            mOwnView.stopSplashView();
        }
    }


    public void onDestroy() {

        if(mOwnView != null) {
            mOwnView.destroySplashView();
        }
        mAdsListener = null;
        mContext = null;
    }

    public void stopSkipTimer() {
        if(mOwnView != null) {
            mOwnView.stopSkipTimer();
        }
    }


    public void onAdLoad() {
        if(AdCache.getInstance().isAdValidate() && AdCache.getInstance().isAdOpen()) {
            OwnAdBean adBean = AdCache.getInstance().getLargestWeightAd();

            onOwnAdPreLoad(adBean);
        } else {
            mAdsListener.onAdLoadFailed(0, 0);
        }
    }

    private OwnAdLoadListener mOwnAdListener = new OwnAdLoadListener() {
        @Override
        public void onOwnAdLoaded(Object object) {

            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.SPLASH_AD_REQUEST_SUCCESS, null);
            if(isTimeOut) {
                return;
            }

            isOwnAdLoad = true;

            if(mAdsListener != null) {
                if(mOwnView != null) {

                    mAdsListener.onAdLoaded(AdsListener.AD_FROM_OWN, mOwnView);

                    mOwnView.showAd();

                    mAdsListener.onAdShow(AdsListener.AD_FROM_OWN, mOwnView.getAdBean());
                }else {
                    isOwnAdError = true;
                }
            }
        }

        @Override
        public void onOwnAdError(int var) {
            isOwnAdLoad = false;
            isOwnAdError = true;
        }

        @Override
        public void onShow() {

        }

        @Override
        public void onClicked(Object object) {
            if(mAdsListener != null) {
                mAdsListener.onClicked(AdsListener.AD_FROM_OWN, object);
            }

            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.SPLASH_AD_CLICK, null);
        }

        @Override
        public void onTimeReach() {
            if(mAdsListener != null) {
                mAdsListener.onTimeReach(AdsListener.AD_FROM_OWN);
            }
        }

        @Override
        public void onSkipAd(Object object) {
            if(mAdsListener != null) {
                mAdsListener.onAdSkip(AdsListener.AD_FROM_OWN,object);
            }
        }
    };

}

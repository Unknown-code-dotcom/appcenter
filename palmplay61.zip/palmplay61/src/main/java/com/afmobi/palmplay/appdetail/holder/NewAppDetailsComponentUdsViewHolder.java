package com.afmobi.palmplay.appdetail.holder;

import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appdetail.TrackUtils;
import com.afmobi.palmplay.detail.BaseComponentRecyclerViewHolder;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.FeatureBuilder;
import com.afmobi.palmplay.model.RankInfo;
import com.afmobi.palmplay.rank.FeatureSinglePageActivity;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.TRNoDoubleClickListener;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ZLayoutAppDetailsComponentUdsBinding;

import java.util.Map;

public class NewAppDetailsComponentUdsViewHolder extends BaseComponentRecyclerViewHolder {

    private ZLayoutAppDetailsComponentUdsBinding mBinding;
    private LayoutStarClickInf layoutStarClickInf;
    private String mValue;

    public NewAppDetailsComponentUdsViewHolder(@NonNull View itemView) {
        super(itemView);

        mBinding = (ZLayoutAppDetailsComponentUdsBinding) DataBindingUtil.getBinding(itemView);

        initViews();
    }

    public void setmValue(String mValue) {
        this.mValue = mValue;
    }

    public void setLayoutStarClickInf(LayoutStarClickInf layoutStarClickInf) {
        this.layoutStarClickInf = layoutStarClickInf;
    }

    private void initViews() {

        int marginTop = itemView.getContext().getResources().getDimensionPixelSize(R.dimen.dp_10);
        int marginLeft = itemView.getContext().getResources().getDimensionPixelSize(R.dimen.dp_16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMarginStart(marginLeft);
        lp.setMarginEnd(marginLeft);
        lp.topMargin = marginTop;
        mBinding.getRoot().setLayoutParams(lp);
    }

    @Override
    public void bind(DetailComponentItemData component, int position) {
        super.bind(component, position);

        if (component != null) {
            mBinding.setIsOfferStyle(isOfferStyle());
            mBinding.executePendingBindings();

            updateStarDisplay(component.score);
            Map<String, String> entity = CommonUtils.getDetailDownloadCountStr(component.downloadCount);
            String downloadCount = entity != null ? entity.get("count") : null;
            String unit = entity != null ? entity.get("unit") : null;
            mBinding.tvDownloadcount.setText(downloadCount);
            mBinding.tvDownloadcountUnit.setText(unit);

            long iSize = 0;
            try {
                iSize = Long.parseLong(component.size);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            String size = FileUtils.getSizeName(iSize);
            int length = size.length();
            if (length > 2) {
                mBinding.tvSize.setText(size.substring(0, length - 2));
                mBinding.tvSizeUnit.setText(size.substring(size.length() - 2));
            } else {
                mBinding.tvSize.setText(size);
                mBinding.tvSizeUnit.setText("");
            }
            mBinding.layoutStar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (layoutStarClickInf != null){
                        layoutStarClickInf.clickLayoutStar(v);
                    }
                }
            });

            RankInfo rankInfo = component.rankInfo;
            if (rankInfo != null){
                mBinding.rankInfoLine.setVisibility(View.VISIBLE);
                mBinding.rankInfo.setVisibility(View.VISIBLE);

                mBinding.tvRankCount.setText(String.valueOf(rankInfo.getRank()));

                boolean isTrendingFlag = rankInfo.getTrendingFlag();
                String displayName =  rankInfo.getName();
                if (isTrendingFlag) {
                    displayName = PalmplayApplication.getAppInstance().getString(R.string.lable_trending_text);
                }
                if (displayName.length() > 8) {
                    displayName = displayName.substring(0, 8) + "...";
                }
                mBinding.tvRankName.setText(displayName);

                if (isOfferStyle()){
                    int iconRes = isTrendingFlag ? R.drawable.ic_trending_offer : R.drawable.ic_communication_offer;
                    mBinding.ivRankIcon.setImageResource(iconRes);
                }else {
                    int iconRes = isTrendingFlag ? R.drawable.ic_trending : R.drawable.ic_communication;
                    mBinding.ivRankIcon.setImageResource(iconRes);
                }

                mBinding.rankInfo.setOnClickListener(new TRNoDoubleClickListener() {
                    @Override
                    public void onNoDoubleClick(View v) {

                        String val = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.TIP_RANKING, "", "");
                        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                        builder.setValue(val)
                                .setFrom(mFrom)
                                .setTopicType("")
                                .setTopicId(mAppInfo.topicID)
                                .setItemType(mAppInfo.detailType)
                                .setItemId(mAppInfo.itemID)
                                .setItemValue(mAppInfo.packageName)
                                .setButtonType(TRAnalyticsConstant.BUTTON)
                                .setExtraValue(rankInfo.getType() + "-" + rankInfo.getName() + "-" + rankInfo.getId())
                                .setTaskId(mAppInfo.taskId)
                                .setExpId(mAppInfo.expId)
                                .setVarId(mAppInfo.getVarId());
                        TRAnalysticsUtil.trackClick(builder);

                        String jumpType = rankInfo.getJumpType();
                        if(TextUtils.equals(jumpType, Constant.NF_TRENDING) || TextUtils.equals(jumpType, Constant.NF_TOPIC)){
                            FeatureBuilder featurebuilder = new FeatureBuilder()
                                    .setDetailType(rankInfo.getType())
                                    .setName(rankInfo.getName())
                                    .setRankID(rankInfo.getId())
                                    .setFromPage(mFromPage)
                                    .setLastPage(mPageParamInfo.getLastPage())
                                    .setValue(mValue)
                                    .setFromNotify(false);
                            FeatureSinglePageActivity.switchToFeatureSinglePageActivity(mActivity, featurebuilder);

                        } else if (TextUtils.equals(jumpType, Constant.NF_CATEGORY)){
                            String categoryType;
                            if (Constant.SOFTTYPE_APP.equalsIgnoreCase(rankInfo.getType())) {
                                categoryType = Constant.SOFTTYPE_APP;
                            } else {
                                categoryType = Constant.SOFTTYPE_GAME;
                            }

                            TRJumpUtil.jumpToCategoryActivity(categoryType, rankInfo.getId(), rankInfo.getName(), mPageParamInfo.getCurPage(),
                                    TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.DETAIL_DETAILS, "", ""));
                        }

                        TrackUtils.trackCommon(FirebaseConstants.EVENT_DETAIL_COMMU_CLICK);
                    }
                });

                String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.TIP_RANKING, "", "");
                ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId(mAppInfo.topicID)
                        .setItemType(mAppInfo.detailType)
                        .setItemId(mAppInfo.itemID)
                        .setItemValue(mAppInfo.packageName)
                        .setExtraValue(rankInfo.getType() + "-" + rankInfo.getName() + "-" + rankInfo.getId())
                        .setTaskId(mAppInfo.taskId)
                        .setExpId(mAppInfo.expId)
                        .setVarId(mAppInfo.getVarId())
                        .setIsVa(mAppInfo.isVa);
                TRAnalysticsUtil.trackExposure(builder);
            } else {
                mBinding.rankInfoLine.setVisibility(View.GONE);
                mBinding.rankInfo.setVisibility(View.GONE);
            }
        }
    }

    private void updateStarDisplay(String scoreText) {
        if (mAppInfo != null && mAppInfo.score > 0) {
            mBinding.tvUdsStars.setText(scoreText);
            mBinding.layoutStar.setVisibility(View.VISIBLE);
            mBinding.viewStarDivider.setVisibility(View.VISIBLE);
        } else {
            mBinding.layoutStar.setVisibility(View.GONE);
            mBinding.viewStarDivider.setVisibility(View.GONE);
        }
    }

    public interface LayoutStarClickInf{
        void clickLayoutStar(View v);
    }

}

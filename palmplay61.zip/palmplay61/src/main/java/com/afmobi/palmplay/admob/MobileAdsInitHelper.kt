package com.afmobi.palmplay.admob

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import com.afmobi.util.CrashHandler
import com.afmobi.util.CrashlyticsBreadcrumbUtil
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.trans.common.async.coroutines.CoroutineUtils
import com.transsion.palmstorecore.AppRuntime
import com.transsion.palmstorecore.ad.AdConstants
import com.transsion.palmstorecore.log.KLog
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 主进程 AdMob 单点初始化：延迟 + Idle 预热 WebView + 后台 initialize。
 *
 * 针对传音 ROM `OverrideController` 资源重定向 + GMA SDK 并发 WebView 探测导致的
 * `AssetManager has been destroyed` 崩溃，做三层防护：
 * 1. 全局兜底：GMA 子线程命中该 OEM 崩溃时吞掉并上报 non-fatal（实现见 [CrashHandler]，复用其全局 handler）。
 * 2. [excInit] 用 suspendCancellableCoroutine 等到 callback，并用 CAS 防并发重复 init（修真 bug）。
 * 3. [warmUpWebViewProvider] 主线程串行「真触发」provider load，每步 runCatching 兼作「单次触发」证伪探针（收窄窗口）。
 */
object MobileAdsInitHelper {

    private const val TAG = "MobileAdsInitHelper"
    private const val INIT_DELAY_MS = 3000L
    private const val INIT_TIMEOUT_MS = 15_000L

    private val mainHandler = Handler(Looper.getMainLooper())

    private val initStarted = AtomicBoolean(false)

    @Volatile
    private var initDeferred: CompletableDeferred<Boolean>? = null

    @JvmStatic
    fun scheduleDelayedInit(immediate: Boolean = false) {
        KLog.d(TAG) { "scheduleDelayedInit: postDelayed immediate=$immediate" }
        if (immediate) {
            triggerInit()
            return
        }
        mainHandler.postDelayed({
            Looper.myQueue().addIdleHandler {
                KLog.d(TAG) { "idle init triggered" }
                triggerInit()
                false
            }
        }, INIT_DELAY_MS)
    }

    private fun triggerInit() {
        if (MobileAds.isInitialized) {
            return
        }
        CoroutineUtils.mainScope.launch {
            excInit()
        }
    }

    /**
     * AdMob 单点初始化：warmUp（主线程串行真触发）→ 后台 initialize，等到 callback 才返回。
     * 用 [initStarted] CAS + [initDeferred] 保证并发调用只 init 一次、其余复用同一结果。
     *
     * @return 是否已完成初始化
     */
    suspend fun excInit(): Boolean {
        if (MobileAds.isInitialized) {
            return true
        }
        // 已有 init 在途：复用同一个 deferred，不重复触发
        if (!initStarted.compareAndSet(false, true)) {
            val inflight = initDeferred
            return if (inflight != null) {
                withTimeoutOrNull(INIT_TIMEOUT_MS) { inflight.await() } ?: MobileAds.isInitialized
            } else {
                MobileAds.isInitialized
            }
        }

        val deferred = CompletableDeferred<Boolean>()
        initDeferred = deferred

        // 主线程串行 warmUp：先把 provider load + OEM 资源重定向在单线程跑完，
        // 让 GMA 后续并行探测命中已稳定的 Resources。
        withContext(Dispatchers.Main.immediate) {
            warmUpWebViewProvider()
        }

        val ok = withTimeoutOrNull(INIT_TIMEOUT_MS) {
            withContext(Dispatchers.Default) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    try {
                        KLog.d(TAG) { "MobileAds.initialize start" }
                        CrashlyticsBreadcrumbUtil.logCrashlytics(AppRuntime.getApp(), "MobileAds.initialize start")
                        val config = InitializationConfig.Builder(AdConstants.ADMOB_APP_ID)
                            .setNativeValidatorDisabled()
                            .setExtras(Bundle().apply {
                                putBoolean(InitializationConfig.FORCE_CRONET_KEY, false)
                                putBoolean(InitializationConfig.FORCE_CRONET_FALLBACK_KEY, false)
                            })
                            .build()
                        MobileAds.initialize(AppRuntime.getApp(), config) { status ->
                            CrashlyticsBreadcrumbUtil.logCrashlytics(AppRuntime.getApp(), "MobileAds.initialize finish")
                            KLog.d(TAG) { "AdMob SDK Initialized $status" }
                            if (cont.isActive) {
                                cont.resumeWith(Result.success(true))
                            }
                        }
                    } catch (t: Throwable) {
                        KLog.e(TAG, t) { "MobileAds.initialize error" }
                        if (cont.isActive) {
                            cont.resumeWith(Result.success(false))
                        }
                    }
                }
            }
        } ?: false

        val finalOk = ok || MobileAds.isInitialized
        deferred.complete(finalOk)
        if (!finalOk) {
            // init 失败或超时，允许后续调用重试
            initStarted.set(false)
        }
        return finalOk
    }

    /**
     * 使用 AdMob 前确保 init 已完成（用户在延迟窗口内提前进入需要广告的页面时兜底）。
     */
    suspend fun ensureInit(): Boolean {
        if (MobileAds.isInitialized) {
            return true
        }
        KLog.d(TAG) { "ensureInit: trigger" }
        CrashlyticsBreadcrumbUtil.logCrashlytics(AppRuntime.getApp(), "MobileAds ensureInit")
        return excInit()
    }

    /**
     * 主线程串行「真触发」WebView provider load。
     *
     * 注意：[WebView.getCurrentWebViewPackage] 只查询系统 WebView 包信息，并不会触发 provider load；
     * 真正会走 `WebViewFactory.getProvider → registerResourcePaths`（即崩溃路径）的是
     * [CookieManager.getInstance] / [WebSettings.getDefaultUserAgent] 这类调用。
     *
     * 每步 runCatching 独立兜住，同时兼作「单次串行触发即崩」的证伪探针：
     * 若此处就捕获到 OEM 崩溃，说明与并发无关，warmUp 优化无意义，应转向全局兜底 + ROM 修复。
     */
    private fun warmUpWebViewProvider() {
        warmUpStep("getCurrentWebViewPackage") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WebView.getCurrentWebViewPackage()
            }
        }
        warmUpStep("CookieManager.getInstance") {
            CookieManager.getInstance()
        }
        warmUpStep("getDefaultUserAgent") {
            WebSettings.getDefaultUserAgent(AppRuntime.getApp())
        }
        KLog.d(TAG) { "WebView warm-up done" }
    }

    private inline fun warmUpStep(step: String, block: () -> Unit) {
        runCatching { block() }.onFailure { t ->
            if (CrashHandler.isOemWebViewAssetManagerCrash(t)) {
                // 证伪探针命中：主线程单次串行触发即崩，与并发无关
                KLog.e(TAG, t) { "warmUp OEM crash at $step (single-shot, not concurrency)" }
                CrashlyticsBreadcrumbUtil.logCrashlytics(AppRuntime.getApp(), "warmUp OEM crash: $step")
                recordNonFatal(t)
            } else {
                KLog.wd(TAG) { "warmUp step $step skipped: ${t.message}" }
            }
        }
    }

    /**
     * 主线程局部兜底：主线程上会触发 WebView provider load / AdMob 的调用点用它包一层。
     *
     * 与 [CrashHandler] 的全局兜底分工——全局 handler **只兜子线程**（主线程崩溃后 Looper
     * 状态不可恢复，不能靠全局 handler 静默吞），主线程可控触发点则由本方法在当前栈同步兜底：
     * - 命中该 OEM 崩溃：吞掉 + 面包屑 + non-fatal 上报，返回 null（业务侧按降级处理）；
     * - 其它异常：原样抛出，不掩盖真实问题。
     *
     * @return [block] 的返回值；命中 OEM 崩溃被吞时返回 null。
     */
    @JvmStatic
    fun <T> guardOemWebViewCrashOnMainThread(tag: String, block: () -> T): T? {
        return try {
            block()
        } catch (t: Throwable) {
            if (CrashHandler.isOemWebViewAssetManagerCrash(t)) {
                KLog.e(TAG, t) { "guard OEM crash (main) at $tag" }
                CrashlyticsBreadcrumbUtil.logCrashlytics(AppRuntime.getApp(), "guard OEM crash (main): $tag")
                recordNonFatal(t)
                null
            } else {
                throw t
            }
        }
    }

    private fun recordNonFatal(throwable: Throwable) {
        runCatching {
            val app = AppRuntime.getApp()
            if (FirebaseApp.getApps(app).isNotEmpty()) {
                val fc = FirebaseCrashlytics.getInstance()
                fc.log("[swallow] OEM AssetManager crash | source=warmUpProbe | thread=${Thread.currentThread().name}")
                fc.recordException(throwable)
            }
        }
    }
}

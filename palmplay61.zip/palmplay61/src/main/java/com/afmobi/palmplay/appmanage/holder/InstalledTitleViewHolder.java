package com.afmobi.palmplay.appmanage.holder;

import android.content.Context;
import android.view.View;

import com.afmobi.palmplay.model.v6_3.PageParamInfo;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 已安装模块title
 */
public class InstalledTitleViewHolder extends RecyclerView.ViewHolder {
    private Context mContext;
    private PageParamInfo mPageParamInfo;

    public InstalledTitleViewHolder(@NonNull View itemView) {
        super(itemView);

    }

    public InstalledTitleViewHolder setContext(Context context) {
        mContext = context;
        return this;
    }

    public InstalledTitleViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        mPageParamInfo = pageParamInfo;
        return this;
    }


    public void bind() {

    }
}

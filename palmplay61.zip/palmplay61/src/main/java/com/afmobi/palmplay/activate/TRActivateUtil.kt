package com.afmobi.palmplay.activate

import android.app.Activity
import com.afmobi.palmplay.collection.RecommendCollectionActivity
import com.transsion.calculator.MustInstallExclude
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils

object TRActivateUtil {
    const val TAG = "TRActivateUtil"
    fun executeOnResumeExtension(activity: Activity) {
        val openSwitch= MMKVUtils.getMMKV().getInt(TRSharedPreferenceUtils.KV_COLLECT_RECOMMEND_EXCLUSIVE,0)
        LogUtils.d(TAG, "TRActivateUtil openSwitch:${openSwitch}")
        if(openSwitch==0){//关闭
            return
        }
        isExcludedByAnnotation(activity)
    }

    /**
     * 处理加MustInstallExclude注解的activity，以及用InAppStatus用来判断是否由端外进来
     * 如果命中，则更新新老手装机的MustInstallExclude状态。
     * 如果没命中，根据enterActivityTimes次数设置zhi weiMustInstallExclude
     */
    private fun isExcludedByAnnotation(activity: Activity) {
        if(activity is RecommendCollectionActivity) {
            if (activity.javaClass.isAnnotationPresent(MustInstallExclude::class.java)
                && "0" == activity.getInAppStatus()) {
                LogUtils.d(TAG, "activity:${activity}, isExcludedByAnnotation: true")
                TRMustInstallExecutor.setMustInstallExclude()
                TRRecomInstallExecutor.setMustInstallExclude()
                return
            }
        }
        LogUtils.d(TAG, "activity:${activity}, isExcludedByAnnotation: false")
        TRMustInstallExecutor.unsetMustInstallExclude()
        TRRecomInstallExecutor.unsetMustInstallExclude()
    }
}

package com.afmobi.palmplay.appdetail.viewmodel;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import androidx.lifecycle.MutableLiveData;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.appdetail.NewAppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.appdetail.TrackUtils;
import com.afmobi.palmplay.appdetail.data.AppInfoDetail;
import com.afmobi.palmplay.appdetail.model.AppDetailData;
import com.afmobi.palmplay.appdetail.repo.AppDetailApiRepo;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.BeddingPositionBean;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.manager.DetailConfigManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.DetailResponseData;
import com.afmobi.palmplay.model.DetailTab;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.viewmodel.AppDetailNavigator;
import com.afmobi.palmplay.viewmodel.BaseViewModel;
import com.afmobi.palmplay.viewmodel.TRAppOtherModel;
import com.afmobi.util.PackageUtil;
import com.androidnetworking.error.ANError;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/***
 *
 * 控制器，也可以称之为业务处理路由。所有得业务均有此控制器分发到具体得model执行，来自 TRAppModel
 */
public class TRNewAppViewModel extends BaseViewModel<AppDetailNavigator> {

    private MutableLiveData<AppInfoDetail> appInfoDetailLiveData = new MutableLiveData<>();
    private MutableLiveData<Integer> mCode = new MutableLiveData<>();
    private MutableLiveData<ANError> networkErrorLiveData = new MutableLiveData<>();
    private MutableLiveData<DetailResponseData> mDetailResponseData = new MutableLiveData<>();
    private MutableLiveData<DetailResponseData> mNewDetailResponseData = new MutableLiveData<>();

    private TRAppOtherModel mTrackModel;
    private int code = 0;
    private String desc;

    private static final String PAGE_CATEGORY = "DETAIL_RECOMMEND";
    private List<String> mAlreadyAdList = new ArrayList<String>();  //记录已经展示过的广告包名
    private Map<String, Integer> mAlreadyAddList = new HashMap<>();  //记录已经展示过的包名

    /**
     * 每次刷新后的专题数量
     */
    public int preTotalSize = 0;
    private boolean isHaveCache = false;

    private boolean tipsVisible;


    public TRNewAppViewModel(AppDataManager manager) {
        super(manager);
    }

    public MutableLiveData<ANError> getNetworkErrorLiveData() {
        return networkErrorLiveData;
    }

    public MutableLiveData<AppInfoDetail> getAppInfoDetailLiveData() {
        return appInfoDetailLiveData;
    }

    public MutableLiveData<Integer> getCodeLiveData() {
        return mCode;
    }

    public MutableLiveData<DetailResponseData> getDetailResponseLiveData() {
        return mDetailResponseData;
    }

    public MutableLiveData<DetailResponseData> getNewDetailResponseLiveData() {
        return mNewDetailResponseData;
    }

    public TRAppOtherModel getAppOtherModel() {
        return mTrackModel;
    }

    public boolean isTipsVisible() {
        return tipsVisible;
    }

    public void setTipsVisible(boolean visible) {
        this.tipsVisible = visible;
    }

    private AppDetailApiRepo appDetailApiRepo = new AppDetailApiRepo(new AppDetailApiRepo.LoadListener() {
        @Override
        public void onDataCallback(JsonObject response) {
            onDetailDataCallback(response);
        }

        @Override
        public void networkErrorCallback(ANError anError) {
            networkErrorLiveData.postValue(anError);
        }
    });

    public void setPage(String mValue, String mFrom){
        appDetailApiRepo.setmValue(mValue);
        appDetailApiRepo.setmFrom(mFrom);
    }

    public AppInfoDetail loadDetailCacheData(boolean isUsePreCache) {
        AppInfo appInfo = (AppInfo) buildObject(new AppInfo());
        DetailResponseData responseData = DetailCacheManager.getInstance().getAppDetailByKey(appInfo.itemID, appInfo.packageName, isUsePreCache);
        appInfo.convertData(responseData);

        isHaveCache = (responseData != null);
        boolean isCustomized = DetailCacheManager.getInstance().isCustomizedDetail(appInfo);

        if(TextUtils.equals(String.valueOf(getParam("pageSign")), TRAnalyticsConstant.NOTICE_BOARD_EW)) {
            TrackUtils.initNoticeEwClick(appInfo);
        }
        PsVaManager.getInstance().isVaInstallFinshOnlyDetail = false;

        PsVaManager.getInstance().dealVaGameData(appInfo);
        mDetailResponseData.setValue(responseData);

        AppInfoDetail appInfoDetail = new AppInfoDetail(true, appInfo, isHaveCache, isCustomized);
        if (BuildConfig.DEBUG) {
            LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity loadDetailCacheData 1:" + appInfoDetail.toString());
        }
        return appInfoDetail;
    }

    public void loadDetailApiData(String tag) {
        loadAdData();//加载EW广告
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                String pkg = (String) mTrackModel.getParam("mPackageName");
                String itemID = (String) mTrackModel.getParam("mItemID");
                String fromPage = (String) mTrackModel.getParam("fromPageID");
                String flowSource = (String) mTrackModel.getParam(TRAnalyticsConstant.REPORT_SOURCE);
                PageParamInfo pageParamInfo = (PageParamInfo) mTrackModel.getParam("mPageParamInfo");
                appDetailApiRepo.loadDetailData(tag, pkg, itemID, flowSource, fromPage, pageParamInfo);
                if (BuildConfig.DEBUG) {
                    LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity loadDetailApiData 1");
                }
            }
        }));
    }

    private void analysisAppInfoData(JsonObject response) {
        Gson gson = new Gson();
        if(response.has("code")){
            code = gson.fromJson(response.get("code"), Integer.class);
        }
        if(response.has("desc")){
            desc = gson.fromJson(response.get("desc"), String.class);
        }
        int type = 0;
        String detailType = gson.fromJson(response.get("detailType"), String.class);

        if (detailType == null){
            detailType = gson.fromJson(response.get("itemType"), String.class);
        }

        type = DetailType.getType(detailType);

        //JsonObject detail = (JsonObject) response.get("detailTabList");

        if (type == DetailType.TYPE_APP
                || type == DetailType.TYPE_GAME
                || type == DetailType.TYPE_SOFT) {
            gson = new Gson();

            AppInfo appInfo = null;
            DetailResponseData detailResponseData = null;
            try {
                //appInfo = gson.fromJson(detail, AppInfo.class);
                //String test = "{\"detailTabList\":[{\"tabName\":\"Iteminfo\",\"tabStyle\":\"DEFAULT\",\"tabType\":\"HEAD\",\"components\":[{\"style\":\"DEFAULT\",\"dataType\":\"ITEM_BASE_INFO\",\"name\":\"Flow Line\",\"itemId\":\"s_b8d32d8728dc4cc08ed95fffe2ef84d5\",\"packageName\":\"com.flowline.zhishi.palm\",\"bannerUrl\":\"http://test-cdn.palmplaystore.com/static/835/eaeee5473c624de69a70c43687afcb37.webp\",\"backgroundRgb\":\"#FF17A5EF\",\"iconUrl\":null,\"securityScanPassed\":\"0\",\"buttonRgb\":\"#FF995E00\",\"safeTag\":[{\"type\":\"SHIELD\",\"name\":\"shiled\"},{\"type\":\"FREE\",\"name\":\"free\"}]},{\"style\":\"DEFAULT\",\"dataType\":\"ITEM_INFO\",\"name\":\"Item info\",\"score\":\"4.7\",\"downloadCount\":\"35598\",\"size\":\"15061030\"}]},{\"tabName\":\"Details\",\"tabStyle\":\"DEFAULT\",\"tabType\":\"DETAIL\",\"components\":[{\"style\":\"DEFAULT\",\"dataType\":\"ITEM_IMAGE_INTRODUCE\",\"componentName\":\"Images introduce\",\"screenshot\":[\"http://test-cdn.palmplaystore.com/static/835/eaeee5473c624de69a70c43687afcb37.webp\",\"http://test-cdn.palmplaystore.com/static/500/87ea2f2a30214ccabf05bb0107027e8c.webp\",\"http://test-cdn.palmplaystore.com/static/333/8f01bf1a7487403a9397f658aeeaafab.webp\",\"http://test-cdn.palmplaystore.com/static/592/cb3d51850bb145c1b25cc89c2730a344.webp\",\"http://test-cdn.palmplaystore.com/static/546/ed75e1c20e79416aad55585cca15eff5.webp\"],\"smallScreenshot\":[\"http://test-cdn.palmplaystore.com/static/835/eaeee5473c624de69a70c43687afcb37.webp\",\"http://test-cdn.palmplaystore.com/static/500/87ea2f2a30214ccabf05bb0107027e8c.webp\",\"http://test-cdn.palmplaystore.com/static/333/8f01bf1a7487403a9397f658aeeaafab.webp\",\"http://test-cdn.palmplaystore.com/static/592/cb3d51850bb145c1b25cc89c2730a344.webp\",\"http://test-cdn.palmplaystore.com/static/546/ed75e1c20e79416aad55585cca15eff5.webp\"],\"screenshotMode\":[0,0,0,0,0]},{\"style\":\"DEFAULT\",\"dataType\":\"ITEM_TAG\",\"componentName\":\"Tags\",\"tagList\":[{\"tagID\":\"\",\"name\":\"Casual\",\"category\":\"CATEGORY\",\"categoryID\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"isHot\":\"F\"}]},{\"style\":\"DEFAULT\",\"dataType\":\"ITEM_BRIEF\",\"componentName\":\"Information\",\"descInfo\":\"Flow line is a very simple and creative and addictive puzzle game, easy to play and fun game. From now on, let us enjoy a simple and addictive puzzle game! Connect the matching color to the pipe to create a line. Pair all colors and cover the entire board to solve each puzzle. But please note that if the pipes intersect or overlap, the previous pipes will disappear! The points between the same color are connected to each other until the entire space is filled, and it is considered to pass! The game has three modes: simple, medium and hard. How you play depends on you. So, try Flow Line and experience a different experience!\",\"versionName\":\"1.0.0.0001\",\"devInfo\":\"开发者信息xxxx\"},{\"style\":\"DEFAULT\",\"dataType\":\"ITEM_COMMENT\",\"componentName\":\"Rating and reviews\",\"comment\":[{\"id\":1,\"username\":\"test1\",\"userAvatar\":null,\"content\":\"test1 test1 test1 test1 test1 test1 test1\",\"model\":\"GCO XX6\",\"star\":\"5\",\"ddate\":\"2023-06-08 12:00:00\",\"approveCnt\":111,\"disapproveCnt\":222,\"reportCnt\":665,\"hasApprove\":333},{\"id\":2,\"username\":\"test2\",\"userAvatar\":null,\"content\":\"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\",\"model\":\"GCO XX6\",\"star\":\"5\",\"ddate\":\"2022-06-08 12:00:00\",\"approveCnt\":0,\"disapproveCnt\":0,\"reportCnt\":0,\"hasApprove\":0},{\"id\":3,\"username\":\"test2\",\"userAvatar\":null,\"content\":\"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\",\"model\":\"GCO XX6\",\"star\":\"5\",\"ddate\":\"2022-06-08 12:00:00\",\"approveCnt\":0,\"disapproveCnt\":0,\"reportCnt\":0,\"hasApprove\":0}]},{\"style\":\"DEFAULT\",\"dataType\":\"FEATURE\",\"componentName\":\"Feature\",\"featureDtoList\":[{\"featureId\":332,\"name\":\"Recommend for You\",\"featureType\":\"RANK\",\"style\":\"RANK_BG_5ICON\",\"styleRole\":\"A\",\"bgUrl\":\"http://test-cdn.palmplaystore.com/static/692/0d43c929c4784c46b72ce56f8efea37c.webp\",\"bgColor\":null,\"showAmount\":5,\"data\":[{\"itemID\":\"s_51bc14cbea2342de94331bcd0942a0bd\",\"packageName\":\"com.drawgame.huiyiyou.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/575/d787fac783614bbaa9504de0775d21f9.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.1.1\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":20696753,\"fromType\":1,\"downloadCount\":160220,\"simpleDescription\":\"It's time to use your brain and find a way to bump the balls!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"name\":\"aaaaa\",\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_3145bbd19ce34ba7bbcf8db128c22243\",\"packageName\":\"com.fruitlegend.huiyiyou.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/128/4508b1dc803040c382548181bd9c8644.webp\",\"bgUrl\":null,\"name\":\"aaaaa2222\",\"versionCode\":1,\"versionName\":\"1.1.1\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":15034032,\"fromType\":1,\"downloadCount\":296490,\"simpleDescription\":\"Fruits Legend is #1 match-3 puzzle game with fresh gameplay!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_5d36d974ef684465bd0f3f537256defb\",\"packageName\":\"com.kingbirddefense.huiyiyou.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/164/cb60cd201dcb482cb6e00383b13b79c2.webp\",\"bgUrl\":null,\"name\":\"aaaaa33333\",\"versionCode\":1,\"versionName\":\"1.1.1\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":50408359,\"fromType\":1,\"downloadCount\":114854,\"simpleDescription\":\"Various monsters are about to attack our kingdom.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_c0058563f2e4427f9fbd9f68d0bea14e\",\"packageName\":\"com.gameloft.android.GloftANPH\",\"categoryCode\":\"37bd4cc5e3e347f18a0aba8f69f320f6\",\"categoryName\":\"Racing\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/870/cf548a6e06204fe78371de05a7c5a933.webp\",\"bgUrl\":null,\"name\":\"aaaaa44444\",\"versionCode\":10300,\"versionName\":\"1.0.3\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":27240961,\"fromType\":1,\"downloadCount\":247871,\"simpleDescription\":\"Get enough Asphalt with 35MB monster packs.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_5a2b39e2fdbd42ccb66e94b8d2e00b2d\",\"packageName\":\"com.gameloft.android.GloftDBMF\",\"categoryCode\":\"a148b7535d9e45e799bc90df99227e7c\",\"categoryName\":\"Puzzle\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/500/1b34e312c0fa4e98bf4cea1fc090e24a.webp\",\"bgUrl\":null,\"versionCode\":10300,\"name\":\"bbbbbbb\",\"versionName\":\"1.0.3\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":19413165,\"fromType\":1,\"downloadCount\":86235,\"simpleDescription\":\"Come and play Puzzle Pets! \",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_3c06c17d343f487d82b80dd5d9d997fb\",\"packageName\":\"com.puzzleblock.mutao.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/363/9979e1efd553480ca9c57c5b6f7829be.webp\",\"bgUrl\":null,\"versionCode\":1,\"name\":\"cccccc\",\"versionName\":\"1.0\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":18174809,\"fromType\":2,\"downloadCount\":787735,\"simpleDescription\":\"Drag the blocks to win your game.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"9d39f1427ecc42eccaa6896fc2e159a2\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_76faf61e058c4d728424fd151d8d8ba4\",\"packageName\":\"com.deadlyknifehit.maishi.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/237/064c8b6d124a409882e6786af6434f1e.webp\",\"bgUrl\":null,\"versionCode\":4,\"versionName\":\"2.2\",\"name\":\"ddddd\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":54606567,\"fromType\":2,\"downloadCount\":162395,\"simpleDescription\":\"The ultimate knife challenge is here!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_7d8c9670f6da429b91050af741f5266d\",\"packageName\":\"com.onelinepuzzle.mihe.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/992/af4243dde35b492d9ca6a1616605144b.webp\",\"bgUrl\":null,\"versionCode\":111,\"versionName\":\"1.1.1\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":29561971,\"name\":\"ddddddddd222\",\"fromType\":2,\"downloadCount\":94983,\"simpleDescription\":\"Only one way to go？\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null}],\"rankId\":8,\"longFeatureFlag\":false,\"oemSource\":null,\"filterInstalled\":1},{\"featureId\":257,\"name\":\"Recommend for You\",\"featureType\":\"RANK\",\"style\":\"V_TITLE\",\"styleRole\":\"A\",\"bgUrl\":\"\",\"bgColor\":null,\"showAmount\":14,\"data\":[{\"itemID\":\"s_51bc14cbea2342de94331bcd0942a0bd\",\"packageName\":\"com.drawgame.huiyiyou.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/575/d787fac783614bbaa9504de0775d21f9.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.1.1\",\"isOffer\":0,\"offerDesc\":\"\",\"name\":\"eeee222\",\"size\":20696753,\"fromType\":1,\"downloadCount\":160220,\"simpleDescription\":\"It's time to use your brain and find a way to bump the balls!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_3145bbd19ce34ba7bbcf8db128c22243\",\"packageName\":\"com.fruitlegend.huiyiyou.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/128/4508b1dc803040c382548181bd9c8644.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.1.1\",\"name\":\"eeee33332\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":15034032,\"fromType\":1,\"downloadCount\":296490,\"simpleDescription\":\"Fruits Legend is #1 match-3 puzzle game with fresh gameplay!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_5d36d974ef684465bd0f3f537256defb\",\"packageName\":\"com.kingbirddefense.huiyiyou.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/164/cb60cd201dcb482cb6e00383b13b79c2.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.1.1\",\"name\":\"eeee4444444442\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":50408359,\"fromType\":1,\"downloadCount\":114854,\"simpleDescription\":\"Various monsters are about to attack our kingdom.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_c0058563f2e4427f9fbd9f68d0bea14e\",\"packageName\":\"com.gameloft.android.GloftANPH\",\"categoryCode\":\"37bd4cc5e3e347f18a0aba8f69f320f6\",\"categoryName\":\"Racing\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/870/cf548a6e06204fe78371de05a7c5a933.webp\",\"bgUrl\":null,\"versionCode\":10300,\"versionName\":\"1.0.3\",\"isOffer\":0,\"offerDesc\":\"\",\"name\":\"eeee555555555\",\"size\":27240961,\"fromType\":1,\"downloadCount\":247871,\"simpleDescription\":\"Get enough Asphalt with 35MB monster packs.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_5a2b39e2fdbd42ccb66e94b8d2e00b2d\",\"packageName\":\"com.gameloft.android.GloftDBMF\",\"categoryCode\":\"a148b7535d9e45e799bc90df99227e7c\",\"categoryName\":\"Puzzle\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/500/1b34e312c0fa4e98bf4cea1fc090e24a.webp\",\"bgUrl\":null,\"versionCode\":10300,\"versionName\":\"1.0.3\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":19413165,\"name\":\"eeee6666666666\",\"fromType\":1,\"downloadCount\":86235,\"simpleDescription\":\"Come and play Puzzle Pets! \",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_3c06c17d343f487d82b80dd5d9d997fb\",\"packageName\":\"com.puzzleblock.mutao.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/363/9979e1efd553480ca9c57c5b6f7829be.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0\",\"isOffer\":0,\"name\":\"eeee77777777\",\"offerDesc\":\"\",\"size\":18174809,\"fromType\":2,\"downloadCount\":787735,\"simpleDescription\":\"Drag the blocks to win your game.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"9d39f1427ecc42eccaa6896fc2e159a2\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_76faf61e058c4d728424fd151d8d8ba4\",\"packageName\":\"com.deadlyknifehit.maishi.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/237/064c8b6d124a409882e6786af6434f1e.webp\",\"bgUrl\":null,\"versionCode\":4,\"versionName\":\"2.2\",\"isOffer\":0,\"offerDesc\":\"\",\"name\":\"eeee8888888888\",\"size\":54606567,\"fromType\":2,\"downloadCount\":162395,\"simpleDescription\":\"The ultimate knife challenge is here!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_7d8c9670f6da429b91050af741f5266d\",\"packageName\":\"com.onelinepuzzle.mihe.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/992/af4243dde35b492d9ca6a1616605144b.webp\",\"bgUrl\":null,\"versionCode\":111,\"versionName\":\"1.1.1\",\"isOffer\":0,\"name\":\"eeee9999999999\",\"offerDesc\":\"\",\"size\":29561971,\"fromType\":2,\"downloadCount\":94983,\"simpleDescription\":\"Only one way to go？\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_515d4695ead24f7aa9e6693812999613\",\"packageName\":\"com.acecombat.haoda.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/862/fb124063c340436594d7bfec35320f10.webp\",\"bgUrl\":null,\"versionCode\":38,\"versionName\":\"1.1.1\",\"name\":\"hhhhhhhhhhh\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":27767336,\"fromType\":2,\"downloadCount\":83088,\"simpleDescription\":\"Warning! Enemy invasion! \",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_57d32a2e670c496c8fcff8c92e6cd114\",\"packageName\":\"com.paopaowar.fenglang.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/353/3645578866c54d9694b8282e1a49e16a.webp\",\"bgUrl\":null,\"versionCode\":2,\"name\":\"hhhhhhhhhhh2222\",\"versionName\":\"2.0.0\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":16540860,\"fromType\":2,\"downloadCount\":115333,\"simpleDescription\":\"This is a powerful fire battle！\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_82bd1484a619499cb1334bc5246a19e3\",\"packageName\":\"com.luckybus.shootingwarriors\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/842/261502f6188e4377bedce6b0e6120716.webp\",\"bgUrl\":null,\"versionCode\":6,\"versionName\":\"1.0\",\"isOffer\":0,\"name\":\"hhhhhhhhhhh333\",\"offerDesc\":\"\",\"size\":56589495,\"fromType\":1,\"downloadCount\":688410,\"simpleDescription\":\"Return to the three countries, in the war era relive the hero dream!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_d5b4b65468064a889e79073ec72bd50a\",\"packageName\":\"com.luckybus.aplanetofmine.transsian\",\"categoryCode\":\"cfc2ef8c1e744e22b81316808f187f5e\",\"categoryName\":\"Strategy\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/513/49318b5202cc43e8ae6f8df2511c0e7d.webp\",\"bgUrl\":null,\"versionCode\":35,\"versionName\":\"1.035\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":38927099,\"name\":\"hhhhhhhhhhh44444\",\"fromType\":1,\"downloadCount\":73937,\"simpleDescription\":\"Start colonizing the whole galaxy with 2 peagents.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_e871f2533f9944c2b28f64ae0cc1690c\",\"packageName\":\"com.spidersolitaire.mutao.aha\",\"categoryCode\":\"5c00d098ac8d4bc0924d23fa1d83b264\",\"categoryName\":\"Card\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/254/a453cba416d7458fbba4b32f198c72ec.webp\",\"bgUrl\":null,\"versionCode\":2,\"versionName\":\"1.1\",\"isOffer\":0,\"offerDesc\":\"\",\"name\":\"hhhhhhhhhhh555555555\",\"size\":20452262,\"fromType\":1,\"downloadCount\":200941,\"simpleDescription\":\"Train your brain with Solitaire.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_e280bedadfea47f59de92e4c62e73688\",\"packageName\":\"com.hammerio.zhishi.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/664/5f2dd71c1121462a9c1a7d9bccb6ffe8.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0.0.0001\",\"name\":\"hhhhhhhhhhh6666666666666\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":26819192,\"fromType\":1,\"downloadCount\":159309,\"simpleDescription\":\"Hammer all other people. Popular IO games.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_dc62452f56f84969b12eee2ff28baaa7\",\"packageName\":\"com.mrstick.aiyu.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/681/5bc64cfeeb4e4209a88a5da5f33a0edb.webp\",\"bgUrl\":null,\"versionCode\":1,\"name\":\"hhhhhhhhhhh666666667\",\"versionName\":\"1.0\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":40228301,\"fromType\":1,\"downloadCount\":58890,\"simpleDescription\":\"How far can you go?\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_e6583afed7c24abfb2116fc13f1b9f00\",\"packageName\":\"com.flawlesshit.maishi.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/543/71fe5cf92c434cadb51883bf2d85d43d.webp\",\"bgUrl\":null,\"versionCode\":1,\"name\":\"jjjjjj4\",\"versionName\":\"1.0\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":49699917,\"fromType\":1,\"downloadCount\":88675,\"simpleDescription\":\"Drop, Hit, Stack and Be Flawless!\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_36c8f2eb346c486ba154a4978776d25c\",\"packageName\":\"com.idlefishingmaster.feiyue.aha\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/67/59b6cae4617945518abeecbd6c43df52.webp\",\"bgUrl\":null,\"versionCode\":1,\"name\":\"jjjjjj666\",\"versionName\":\"1.0.1\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":32754059,\"fromType\":1,\"downloadCount\":102688,\"simpleDescription\":\"A new fishing experience you will never imagine.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_b867a1a3fa0c43b2880785af686d8ee5\",\"packageName\":\"com.luckybus.amazingrunes\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/330/93ac6b098ae444bea6a5b420daa8f760.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0\",\"isOffer\":0,\"name\":\"jjjjjj7777777\",\"offerDesc\":\"\",\"size\":38846278,\"fromType\":1,\"downloadCount\":377701,\"simpleDescription\":\"Draw mysterious symbols with your fingers\\\\\\\\\\\\\\\\\\\\\\nDestroy the little monsters\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_d2dc78f3e3af430699201ef072ae2575\",\"packageName\":\"com.luckybus.bottleflip\",\"categoryCode\":\"a148b7535d9e45e799bc90df99227e7c\",\"categoryName\":\"Puzzle\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/386/55c9c30fae3a41a7a0a5aa331434a9ce.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0\",\"isOffer\":0,\"name\":\"jjjjjj8888888888\",\"offerDesc\":\"\",\"size\":52463315,\"fromType\":1,\"downloadCount\":99447,\"simpleDescription\":\"Make the bottle jump or even double flip. How? Just tap the screen at the right \",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_d4f66b18e1734fe8bb1b8d53835e3ffe\",\"packageName\":\"com.luckybus.crazycooking\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/779/7f6ae175a3fb41d789445bfdbc432b39.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0\",\"name\":\"jjjjjj9999999\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":62317807,\"fromType\":1,\"downloadCount\":276385,\"simpleDescription\":\"Be one of the best cooks in the world，Bring delicious food to the world\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_b226029eba8c463ea68ecadf91d179db\",\"packageName\":\"com.luckybus.crosskavir\",\"categoryCode\":\"5d15e5b18ace433b8bf8acb1253023ed\",\"categoryName\":\"Adventure\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/202/c58f0dc291b7440e9c4566d07c6eaadd.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0\",\"name\":\"uuu0\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":30285671,\"fromType\":1,\"downloadCount\":239242,\"simpleDescription\":\"Cross Kavir is an endless running game that makes it the best runner.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null}],\"rankId\":8,\"longFeatureFlag\":false,\"oemSource\":null,\"filterInstalled\":1},{\"featureId\":228,\"name\":\"Let‘s play \",\"featureType\":\"RANK\",\"style\":\"H_ROLL_TITLE\",\"styleRole\":\"A\",\"bgUrl\":\"\",\"bgColor\":null,\"showAmount\":8,\"data\":[{\"itemID\":\"s_105f813d6bf9471fabdb600e9f670f18\",\"packageName\":\"com.truecaller\",\"categoryCode\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":\"Communication\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/934/3f4b40e2103f46a4bc59e7a0610ba44e.webp\",\"bgUrl\":null,\"versionCode\":1054006,\"versionName\":\"10.54.6\",\"isOffer\":0,\"name\":\"uuu02222\",\"offerDesc\":\"\",\"size\":48740367,\"fromType\":1,\"downloadCount\":397493,\"simpleDescription\":\"250 million people trust Truecaller for their communication needs\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"e238d098c26a1d8cce62eec54a5426a8\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":39536190},{\"itemID\":\"s_31966da90289433f8460ac5b61e1dc8c\",\"packageName\":\"com.zhiliaoapp.musically\",\"categoryCode\":\"3c8ca847fc0e4b4383e45849119895ee\",\"categoryName\":\"Social\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/55/9990eaa6b83348c4ac0556d073fe47e5.webp\",\"bgUrl\":null,\"versionCode\":2022007050,\"versionName\":\"20.7.5\",\"isOffer\":0,\"offerDesc\":\"11\",\"size\":77808926,\"fromType\":5,\"downloadCount\":18744,\"simpleDescription\":\"222\",\"verifyGoogle\":\"F\",\"star\":\"3\",\"name\":\"uuu05555\",\"score\":\"3.4\",\"md5\":\"2d28f48d9264232bee30f22c883021dd\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_29afeb4262e84e54b1174e34c2202bdf\",\"packageName\":\"com.koo.app\",\"categoryCode\":\"ea53608ada2e42f79488939f9c8da122\",\"categoryName\":\"News & Magazines\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/216/3c75b7b4c4a94b72b6b62af904317ef8.webp\",\"bgUrl\":null,\"versionCode\":85,\"versionName\":\"0.0.85\",\"name\":\"uuu077777\",\"isOffer\":0,\"offerDesc\":\"Koo\",\"size\":24174506,\"fromType\":2,\"downloadCount\":20918,\"simpleDescription\":\"Koo\",\"verifyGoogle\":\"F\",\"star\":\"4\",\"score\":\"4.0\",\"md5\":\"c5f23ea1ae766bff2c063bb51492b824\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":22370800},{\"itemID\":\"s_0cda4ffdaf2c4a39a2154886786dcf1b\",\"packageName\":\"com.viber.voip\",\"categoryCode\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":\"Communication\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/234/56c3bc1783424dec916d67a1ab7ab063.webp\",\"bgUrl\":null,\"name\":\"uuu088888\",\"versionCode\":640624,\"versionName\":\"15.4.0.1\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":58721542,\"fromType\":2,\"downloadCount\":447921,\"simpleDescription\":\"Viber is the FREE, simple, fast and most secure messaging and calling app.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.9\",\"md5\":\"48e4a5ef5a84943ac0244a4bbda46c0e\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_0ae997725549429ba96c1b64371c2015\",\"packageName\":\"net.iyuntu.pab\",\"categoryCode\":\"674246bde11a4da1afa07ae93244cb69\",\"categoryName\":null,\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/145/9f78d5322af6462b9afefaf026d1214c.webp\",\"bgUrl\":null,\"versionCode\":1002101,\"versionName\":\"1.0.21\",\"isOffer\":0,\"offerDesc\":null,\"name\":\"uuu9999\",\"size\":30340907,\"fromType\":2,\"downloadCount\":20187,\"simpleDescription\":\"Your private butler for album secrecy\",\"verifyGoogle\":null,\"star\":\"4\",\"score\":\"4.0\",\"md5\":\"e596b33ac211cd52a202c4be115537dc\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":29539406},{\"itemID\":\"s_d5d6b38f02fb470f9ed1b2a3437651d4\",\"packageName\":\"com.innockstudios.pandaslide\",\"categoryCode\":\"83cb0a135cca4f738d2b2dead16d9a21\",\"categoryName\":\"Action\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/291/190c72d1ac534588b2e29cd2d070261e.webp\",\"bgUrl\":null,\"name\":\"t5555\",\"versionCode\":19,\"versionName\":\"1.5\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":3870924,\"fromType\":2,\"downloadCount\":20313,\"simpleDescription\":\"This is a unique & very interesting game of a Panda sliding and jumping on bamboos.\",\"verifyGoogle\":\"F\",\"star\":\"3\",\"score\":\"3.0\",\"md5\":\"2c1607a54696d6e69c4745647112b133\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_fed5c4501acb40b2b85c7b37447d54cc\",\"packageName\":\"com.sukhavati.gotoplaying.bubble.BubbleShooter.mint.aha\",\"categoryCode\":\"a148b7535d9e45e799bc90df99227e7c\",\"categoryName\":\"Puzzle\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/546/ed75e1c20e79416aad55585cca15eff5.webp\",\"bgUrl\":null,\"versionCode\":59,\"versionName\":\"2.3.9\",\"isOffer\":1,\"name\":\"yyyyy777\",\"offerDesc\":\"\",\"size\":38851822,\"fromType\":2,\"downloadCount\":6116659,\"simpleDescription\":\"Play with your friendsu0021\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"b776db1c367ef6c822c8cff2fc233e72\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":36997903},{\"itemID\":\"s_a2885f3754674beca2ca3f28d0b7665a\",\"packageName\":\"com.puppy.merge.town\",\"categoryCode\":\"9bfd82fc7e5d417c8c689460d4f63779\",\"categoryName\":\"Casual\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/281/d0575ea867e44ebead806f4a15e6b995.webp\",\"bgUrl\":null,\"versionCode\":137,\"versionName\":\"1.3.7\",\"name\":\"yyyyy888\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":78150012,\"fromType\":2,\"downloadCount\":66973,\"simpleDescription\":\"Merge your puppies to earn money and build your puppy town.\",\"verifyGoogle\":\"F\",\"star\":\"5\",\"score\":\"4.8\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_e2242197f47b40a7ae2fb1079b9a34e2\",\"packageName\":\"com.playgendary.hitmasters\",\"categoryCode\":\"83cb0a135cca4f738d2b2dead16d9a21\",\"categoryName\":\"Action\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/539/1dcea59c173f4200b0152da0cc5e9827.webp\",\"bgUrl\":null,\"versionCode\":174,\"versionName\":\"1.7.0\",\"isOffer\":0,\"offerDesc\":\"\",\"size\":89526792,\"fromType\":2,\"downloadCount\":47928,\"simpleDescription\":\"Have you ever dreamt of becoming a spy? \",\"verifyGoogle\":\"F\",\"name\":\"yyyyy9999\",\"star\":\"5\",\"score\":\"4.6\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_d49ece7844bf443db00b738a5aedbc2b\",\"packageName\":\"com.lastarrows.xiaobaigame.aha\",\"categoryCode\":\"83cb0a135cca4f738d2b2dead16d9a21\",\"categoryName\":\"Action\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/959/d9ecc48400734b26aac3bbabe2fa7bfd.webp\",\"bgUrl\":null,\"versionCode\":100,\"versionName\":\"1.0.0\",\"isOffer\":0,\"offerDesc\":null,\"size\":84396965,\"fromType\":2,\"name\":\"mmm666\",\"downloadCount\":37936,\"simpleDescription\":\"Use the leftover arrows wisely to return safely to home\",\"verifyGoogle\":null,\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null},{\"itemID\":\"s_34e4b36c63c148b781ebcf8fa3de3c87\",\"packageName\":\"com.aryasgames.zombieseverywherec.aha\",\"categoryCode\":\"5d15e5b18ace433b8bf8acb1253023ed\",\"categoryName\":\"Adventure\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/995/2f29f029036140ae890915aa35488f7f.webp\",\"bgUrl\":null,\"versionCode\":2,\"versionName\":\"0.1\",\"isOffer\":0,\"offerDesc\":null,\"size\":91696595,\"fromType\":2,\"downloadCount\":53339,\"simpleDescription\":\"You need to hide, run, shoot and survive! Everything is in your hands.\",\"verifyGoogle\":null,\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"name\":\"mmm666777\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":null,\"compSourceSize\":null},{\"itemID\":\"s_7665750c01a349c9935e889e10b01b9b\",\"packageName\":\"com.triballegend.xiaobaigame.aha\",\"categoryCode\":\"cfc2ef8c1e744e22b81316808f187f5e\",\"categoryName\":\"Strategy\",\"iconUrl\":\"http://test-cdn.palmplaystore.com/static/918/e18764170d434e9a867fe21fc5805a21.webp\",\"bgUrl\":null,\"versionCode\":1,\"versionName\":\"1.0.0\",\"isOffer\":0,\"offerDesc\":null,\"size\":57790090,\"name\":\"mmm666999\",\"fromType\":2,\"downloadCount\":42498,\"simpleDescription\":\"Tribal Legend  is a tower defense game with a unique game style. Set in a magica\",\"verifyGoogle\":null,\"star\":\"5\",\"score\":\"5.0\",\"md5\":\"\",\"detailType\":\"SOFT\",\"showStyle\":null,\"lableUrl\":null,\"obbFlag\":null,\"lablePositonMap\":{},\"compSourceSize\":null}],\"rankId\":613,\"longFeatureFlag\":false,\"oemSource\":null,\"filterInstalled\":1}]},{\"style\":\"DEFAULT\",\"dataType\":\"REPORT\",\"componentName\":\"Report\",\"feedbackUrl\":\"https://www.baidu.com\"},{\"style\":\"DEFAULT\",\"dataType\":\"WELFARE\",\"componentName\":\"Gifts\",\"couponList\":[{\"couponID\":\"aaaaaaaaa\",\"itemID\":\"s_ddddddddddddad\",\"packageName\":\"com.transsion.phonemaster\",\"title\":\"Lite versions for you\",\"couponType\":1,\"couponBgurl\":\"http://test-cdn.palmplaystore.com/static/500/87ea2f2a30214ccabf05bb0107027e8c.webp\",\"couponLinkType\":1,\"couponLink\":\"http://www.baidu.com\"},{\"couponID\":\"5555555555555555555\",\"itemID\":\"s_absdfgg44\",\"packageName\":\"com.transsion.test\",\"title\":\"welcome to shenzhen\",\"couponType\":1,\"couponBgurl\":\"http://test-cdn.palmplaystore.com/static/333/8f01bf1a7487403a9397f658aeeaafab.webp\",\"couponLinkType\":1,\"couponLink\":\"http://www.baidu.com\"}]}]}]}";
                detailResponseData = gson.fromJson(response, DetailResponseData.class);
                if (detailResponseData != null && detailResponseData.detailTabList != null) {
                    for (DetailTab tab : detailResponseData.detailTabList) {
                        if (tab == null || tab.components == null) {
                            continue;
                        }
                        for (int m = 0;m < tab.components.size();m++) {
                            DetailComponentItemData item = tab.components.get(m);
                            if (TextUtils.equals(item.dataType, AppDetailsRecyclerViewAdapter.COMPONET_FEATURE)
                                    && item.featureDtoList != null) {
                                FeaturedModel featuredModel = new FeaturedModel();
                                featuredModel.pageIndex = 0;
                                featuredModel.isCache = false;
                                featuredModel.featureList = item.featureDtoList;
                                featuredModel.tid = detailResponseData.tid;
                                featuredModel.rs = detailResponseData.rs;
                                featuredModel = TRHomeUtil.transformAndSortData(featuredModel);
                                featuredModel = TRHomeUtil.addTrackLogicField(featuredModel);
                                if (featuredModel.featureList != null && featuredModel.featureList.size() > 0) {
                                    for (FeatureBean featureBean : featuredModel.featureList) {
                                        featureBean.tabNum = m;
                                    }
                                }
                            }
                        }
                    }

                    appInfo = new AppInfo().convertData(detailResponseData);

                    appInfo.cfgId = mTrackModel.cfgId;
                    appInfo.pid = mTrackModel.pid;
                    appInfo.subSiteId = mTrackModel.subSiteId;
                    appInfo.siteId = mTrackModel.siteId;
                    appInfo.reportSource = mTrackModel.reportSource;
                    appInfo.referrer = mTrackModel.referrer;
                    appInfo.nativeId = mTrackModel.nativeId;

                    appInfo.topicID = mTrackModel.topicID;
                    appInfo.topicPlace = mTrackModel.topicPlace;
                    appInfo.externalId = mTrackModel.externalId;
                    appInfo.taskId = mTrackModel.taskId;
                    int downloadCount = mTrackModel.downloadCount;
                    if(downloadCount > 0) {
                        appInfo.downloadCount = downloadCount;
                    }
                    appInfo.detailSource = mTrackModel.mDetailSource;
                }

                mNewDetailResponseData.setValue(detailResponseData);//todo 去掉？
                DetailCacheManager.getInstance().putDetailRamCache(detailResponseData);//必须在插入EW之前保存，保证缓存数据不包含EW数据(避免下次进入时再次插入)
                if (BuildConfig.DEBUG) {
                    LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity analysisAppInfoData 1");
                }
                if(!isHaveCache) {
                    mDetailResponseData.setValue(detailResponseData);
                    if (BuildConfig.DEBUG) {
                        LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity analysisAppInfoData 2");
                    }
                }

            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
                if (BuildConfig.DEBUG) {
                    LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity analysisAppInfoData 3");
                }
            }
            boolean isCustomized = DetailCacheManager.getInstance().isCustomizedDetail(appInfo);
            AppInfoDetail appInfoDetail = new AppInfoDetail(false, appInfo, isHaveCache, isCustomized);
            appInfoDetailLiveData.setValue(appInfoDetail);
            mCode.setValue(code);
            DownloadStatusManager.getInstance().registerInfoInstance(appInfoDetailLiveData.getValue().appInfo);
        }
    }

    private void filterRepeatData(List<FeatureBean> featureList) {
        if(featureList == null) {
            return;
        }
        if(appInfoDetailLiveData == null ||
                appInfoDetailLiveData.getValue() == null ||
                appInfoDetailLiveData.getValue().appInfo == null) {
            return;
        }
        for(FeatureBean featureBean: featureList) {
            List<FeatureBaseData> featureBaseDataList = featureBean.dataList;
            if (featureBaseDataList == null) continue;
            Iterator<FeatureBaseData> iterable = featureBaseDataList.iterator();
            while (iterable.hasNext()) {
                FeatureBaseData featureBaseData = iterable.next();
                if(featureBaseData instanceof FeatureItemData) {
                    if(TextUtils.equals(((FeatureItemData) featureBaseData).packageName, appInfoDetailLiveData.getValue().appInfo.packageName)){
                        iterable.remove();
                    }
                }
            }
        }
    }

    public boolean addAdData(DetailResponseData detailResp, boolean isHaveCache) {
        if (detailResp == null || detailResp.detailTabList == null) {
            return false;
        }

        boolean ret = false;
        List<FeatureBean> listItems = null;
        if (detailResp != null) {
            DetailComponentItemData component = detailResp.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
            if (component != null) {
                listItems = component.featureDtoList;
            }
        }
        // 与主应用去重
        filterRepeatData(listItems);

        if (listItems != null && listItems.size() > 0) {
            FeaturedModel featuredModel = new FeaturedModel();
            featuredModel.pageIndex = 0;
            featuredModel.featureList = listItems;

            List<TaNativeInfo> adInfo = appDetailApiRepo.getDetailAdInfos();

            if (adInfo != null) {
                LogUtils.d(LogUtils.TAG_DEDDING, "详情页底部-add ad EW");
                // ew与主应用去重
                if (appInfoDetailLiveData == null ||
                        appInfoDetailLiveData.getValue() == null ||
                        appInfoDetailLiveData.getValue().appInfo == null) {
                    Iterator<TaNativeInfo> iterable = adInfo.iterator();
                    while (iterable.hasNext()) {
//                        if (appInfoApiLiveData == null || appInfoApiLiveData.getValue() == null) {
//                            break;
//                        }
                        TaNativeInfo taNativeInfo = iterable.next();
                        FeatureItemData appinfo = null;
                        try {
                            appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                            if (appinfo != null) {
                                appinfo.tNativeInfo = taNativeInfo;
                            }
                        } catch (GsonUtil.GsonParseException e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }
                        if (appinfo != null) {
                            if (TextUtils.equals(appinfo.packageName, appInfoDetailLiveData.getValue().appInfo.packageName)) {
                                iterable.remove();
                            }
                        }
                    }
                }

                int size = adInfo.size();
                for (int i = 0; i < size; i++) {
                    TaNativeInfo taNativeInfo = adInfo.get(i);
                    if (!taNativeInfo.isIconType()) {
                        //continue
                    } else {
                        //icon类广告
                        FeatureItemData appinfo = null;
                        try {
                            appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                            if (appinfo != null) {
                                appinfo.tNativeInfo = taNativeInfo;
                                //应用详情页底部专题支持VA
                                if(appinfo.extJson!=null){
                                    appinfo.isVa = appinfo.extJson.isVa;
                                }
                            }
                        } catch (GsonUtil.GsonParseException e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }

                        if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {

                            filterEWData(featuredModel, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), null);
                            boolean result = TRHomeUtil.addAdForFeatureData(featuredModel.featureList, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), mAlreadyAdList, SceneCode.AD_de);
                            if (result) {
                                ret = result;
                            }
                        }
                    }
                }
            }
            LogUtils.d(LogUtils.TAG_DEDDING, "详情页底部-add ad bedding");

            try {
                for (int i = 0; i < featuredModel.featureList.size(); i++) {
                    featuredModel.beddingAb = detailResp.beddingAb;
                    List<BeddingPositionBean> beddingPosition = detailResp.beddingPosition;
                    if (beddingPosition != null && beddingPosition.size() > i) {
                        BeddingPositionBean beddingPositionBean = beddingPosition.get(i);
                        if (beddingPositionBean != null) {
                            if (featuredModel.featureList.get(Integer.parseInt(beddingPositionBean.row)).beddingPosition == null || featuredModel.featureList.get(Integer.parseInt(beddingPositionBean.row)).beddingPosition.size() <= 0) {
                                Type type = TRHomeUtil.getDataType(featuredModel.featureList.get(Integer.parseInt(beddingPositionBean.row)).featureType);
                                featuredModel.beddingDataList = new Gson().fromJson(detailResp.beddingData, type);
                                featuredModel.featureList.get(Integer.parseInt(beddingPositionBean.row)).beddingPosition = beddingPosition;
                            }
                        }
                    }
                }
            }catch (Exception e){
                LogUtils.d(LogUtils.TAG_DEDDING, "e：" +e.getMessage());
            }

            boolean isResult = TRHomeUtil.doBeddingData(featuredModel, this, mAlreadyAdList, SceneCode.AD_de, isHaveCache ? HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1 : HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0);

            if (!ret) {
                ret = isResult;
            }
            List<DetailComponentItemData> componentList = detailResp.getComponentListByStyle(AppDetailsRecyclerViewAdapter.TAB_TYPE_DETAIL);
            if (componentList != null && componentList.size() > 0) {
                for (DetailComponentItemData componentItemData : componentList) {
                    if (componentItemData != null
                            && componentItemData.dataType.equals(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE)
                            && componentItemData.featureDtoList != null) {
                        componentItemData.featureDtoList = featuredModel.featureList;
                        break;
                    }
                }
            }

            filterDuplicateData(featuredModel);
        }

        return ret;
    }

    public void loadAdData() {
        AppDetailData.getInstance().setFeatureRequestFinished(false);
        appDetailApiRepo.loadAd();
    }

    private void onDetailDataCallback(JsonObject response) {
        if (response != null) {

            analysisAppInfoData(response);
            if (BuildConfig.DEBUG) {
                LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onDetailDataCallback 1");
            }
        }else {
            if (BuildConfig.DEBUG) {
                LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onDetailDataCallback 2");
            }
            mDetailResponseData.setValue(null);
            appInfoDetailLiveData.setValue(null);
        }
    }

    /**
     * ew数据和返回列表数据比较， 如果包名一致，去除本地列表返回项
     * @param featuredModel
     * @param data
     * @param row
     * @param col
     */
    private void filterEWData(FeaturedModel featuredModel, FeatureItemData data, int row, int col, List<String> repeatList) {
        if (featuredModel == null) {
            return;
        }
        List<FeatureBean> featureList = featuredModel.featureList;
        if(featureList == null || featureList.isEmpty()) {
            return;
        }

        if (data == null || TextUtils.isEmpty(data.packageName)) {
            return;
        }

        if (row < 0 || col < 0) {
            return;
        }

        if (PackageUtil.isInstalled(data.isVa, data.packageName)) {
            return;
        }

        if (row >= featureList.size()) {
            return;
        }

        FeatureBean featureBean = featureList.get(row);
        if (featureBean == null || TextUtils.isEmpty(featureBean.style)) {
            return;
        }
        if(featuredModel.pageIndex == 0) {
            preTotalSize = 0;
        }
        int listSize = featureList.size();
        try {
            List<FeatureBean> newFeatureList = featureList.subList(preTotalSize, listSize);
            LogUtils.d("SspSdkManager", "packageName: " + data.packageName  + "  size:" + newFeatureList.size());
            HisavanaSdkManager.getInstance().filterValidateAd(newFeatureList, data, repeatList);
        }catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    /**
     * 过滤重复数据
     * @param featuredModel
     */
    public void filterDuplicateData(FeaturedModel featuredModel) {

        if(featuredModel.featureList == null) {
            return;
        }
        List<FeatureBean> featureList = featuredModel.featureList;
        int listSize = featureList.size();
        if (featuredModel.pageIndex == 0) {
            mAlreadyAddList.clear();
        }
        if(featuredModel.pageIndex > 0) {
            try {
                List<FeatureBean> preFeatureList = featureList.subList(0, preTotalSize);
                List<FeatureBean> newFeatureList = featureList.subList(preTotalSize, listSize);
                LogUtils.d("SspSdkManager", "onDataReceived2: " + preFeatureList.size() + "    newSize:" + newFeatureList.size());

                HisavanaSdkManager.getInstance().removeDuplicateData(preFeatureList, newFeatureList, mAlreadyAddList, SceneCode.AD_de);
            }catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        preTotalSize = listSize;

    }

//    public boolean isFromPluto() {
//        boolean isPluto = false;
//        Object val = getParam("isPluto");
//        if(val instanceof Boolean) {
//            isPluto = ((Boolean) val).booleanValue();
//        }
//        return isPluto;
//    }

    public Object getParam(String name) {
        initTrackModel();
        return mTrackModel.getParam(name);
    }

    public void setParam(Object o) {
        initTrackModel();
        mTrackModel.setParam(o);
    }

    public void setParam(String name, Object value) {
        initTrackModel();
        mTrackModel.setParam(name, value);
    }

    public void setBooleanParam(String name, boolean flag) {
        initTrackModel();
        mTrackModel.setBooleanParam(name, flag);
    }

    public void handBundleData(Bundle bundle, PageParamInfo pageParamInfo) {
        initTrackModel();
        mTrackModel.analysisIntentData(bundle, pageParamInfo);
    }

    public void setPageCode(int ifNewDetail) {
        initTrackModel();
        mTrackModel.ifNewDetail = ifNewDetail;
    }

    public void trackEvent(int type, AppInfo info) {
        initTrackModel();
        mTrackModel.trackEvent(type, info);
    }

    public void trackNfId(DetailComponentItemData item) {
        initTrackModel();
        mTrackModel.nfAbExpId = item.nfAbExpId;
        mTrackModel.nfAbId = item.nfAbId;
    }

    public Object buildObject(Object o) {
        initTrackModel();
        return mTrackModel.buildObject(o);
    }

    private void initTrackModel() {
        if (mTrackModel == null) {
            mTrackModel = new TRAppOtherModel();
        }
    }
    public void statusVaClickAnalytics(boolean isVa, String value, String buttonType, String itemId, String itemValue, String itemType, String topicId, String topicType, String expId) {
        initTrackModel();
        mTrackModel.statusClickAnalytics(isVa,value,buttonType,itemId,itemValue,itemType,topicId,topicType,expId, false);
    }
    public void statusClickAnalytics(boolean isVa, String value, String buttonType, String itemId, String itemValue, String itemType, String topicId, String topicType, String expId, boolean isQuickOpen) {
        initTrackModel();
        mTrackModel.statusClickAnalytics(isVa,value,buttonType,itemId,itemValue,itemType,topicId,topicType,expId, isQuickOpen);
    }

    public void onClick(View v) {
        if(getNavigator() != null) {
            getNavigator().onClick(v);
        }
    }


    public String getModel(String model) {
        String dst = model;
        if (TRStringUtil.isBlank(model)) {
            dst = PalmplayApplication.getAppInstance().getResources().getString(R.string.unkonwn);
        }
        return dst;
    }

    public void destoryHisavanaSdk() {
        appDetailApiRepo.destoryHisavanaSdk();
    }

    public boolean isAutoDownload(){
        return  mTrackModel.isAutoDownload();
    }

    public String getClickReportUrl(){
        return mTrackModel.mClickReportUrl;
    }

    public String getSearchKeyWord(){
        return mTrackModel.mSearchKeyWord;
    }

    public String getSearchType(){
        return mTrackModel.mSearchType;
    }

    public String getTabId(){
        return mTrackModel.tabId;
    }
}

package com.afmobi.palmplay.clean;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afmobi.apk.ApkInstallUtils;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.clean.FlyingStar.FlyingStarView;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.didi.drouter.annotation.Router;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.AndroidVUIUtils;
import com.transsion.palmstorecore.util.ApiUExtKt;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.Random;

import androidx.annotation.Nullable;
import com.transsion.palmstorecore.BaseCoreActivity;

import static com.transsion.palmstorecore.analytics.TRAnalyticsConstant.PV_CM_JF;

/**
 * 点击通知栏的加速出现的扇叶加速页面
 * Created by xiangfei.wei on 2017/11/10.
 */
@Router(path = "/page/cleanMemory")
public class CleanMemoryActivity extends BaseCoreActivity {

    private long[] memoryInfos;

    private TextView tv_accelerate_finish, tv_accelerate_tips, tv_accelerate_result, tv_clean_entry;
    private LinearLayout ll_accelerate_finish, ll_accelerate_result;
    private ImageView iv_windmill;
    private FlyingStarView flyingStarView;

    private PageParamInfo mPageParamInfo;
    private Handler mHandler;
    public static long lastCleanTime = 0;
    public static long lastCleanPercent = 0;
    private static final int MIN_PERCENT = 3;
    private static final int MAX_PERCENT = 19;

    private String mPackageNname = null;
    private ScreenLockReceiver screenLockReceiver;
    private boolean isNormal = true;
    private boolean screenOff;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clean_memory);
        AndroidVUIUtils.INSTANCE.matchAndroid15UI(this, false);
        overridePendingTransition(0, 0);// 屏蔽系统的转场动画
        mPageParamInfo = new PageParamInfo();
        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.Accelerate_Tips);
        getArgus();
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

        memoryInfos = ProcessAndMemoryUtil.getAndroidMemory(this);

        mHandler = new Handler();
        initViews();
        if (mHandler != null) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    accelerateAnimStart();
                }
            }, 300);
        }
        screenLockReceiver = new ScreenLockReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_USER_PRESENT);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        ApiUExtKt.registerReceiverExported(screenLockReceiver, this, intentFilter);
        pvEvent(getIntent());
     //   TRAnalysticsUtil.trackCommonPvShow(TRAnalyticsConstant.PV_HP_B, mPageParamInfo.getLastPage());
    }

    private void pvEvent(Intent intent){
        if(intent == null){
            return;
        }
        String from = intent.getStringExtra(TRAnalyticsConstant.VALUE);
        if(TextUtils.isEmpty(from)) {
            from = "X_X_X_X";
        }

        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(TRStringUtil.generateString(TRAnalyticsConstant.MEMORY_PAGE, TRAnalyticsConstant.MEMORY_MODULE, "", ""))
                .setFrom(from);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private void getArgus() {
        try {
            Intent intent = getIntent();
            if (intent != null) {
                mPackageNname = intent.getStringExtra(Constant.KEY_PACKAGE_NAME);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private void initViews() {
        flyingStarView = (FlyingStarView) findViewById(R.id.flyingStarView);
        flyingStarView.setDestX(DisplayUtil.dip2px(this, 80));
        flyingStarView.setComplexModeEnable(true);
        ll_accelerate_finish = (LinearLayout) findViewById(R.id.ll_accelerate_finish);
        tv_accelerate_finish = (TextView) findViewById(R.id.tv_accelerate_finish);
        iv_windmill = (ImageView) findViewById(R.id.iv_windmill);
        tv_accelerate_tips = (TextView) findViewById(R.id.tv_accelerate_tips);
        tv_accelerate_result = (TextView) findViewById(R.id.tv_accelerate_result);
        tv_clean_entry = (TextView) findViewById(R.id.tv_clean_entry);
        tv_clean_entry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cleanIntent = new Intent(CleanMemoryActivity.this, CleanNativeMemoryActivity.class);
                cleanIntent.putExtra(PageParamInfo.class.getSimpleName(), mPageParamInfo);
                cleanIntent.putExtra("source", PV_CM_JF);
                Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                if (null != mainActivity) {
                    startActivity(cleanIntent);
                } else {
                    Intent firstIntent = new Intent(CleanMemoryActivity.this, MainActivity.class);
                    startActivities(new Intent[]{firstIntent, cleanIntent});
                }
                finish();
            }
        });
        ll_accelerate_result = (LinearLayout) findViewById(R.id.ll_accelerate_result);
    }

    @Override
    public void finish() {
        super.finish();
        //注释掉activity本身的过渡动画
        overridePendingTransition(0, 0);
    }

    private void accelerateAnimStart() {
        Animation windmillAnim = AnimationUtils.loadAnimation(this, R.anim.anim_accelerate_windmill);
        windmillAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                flyingStarView.start();
                startClean();
                isNormal = true;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (isNormal) {
                    flyingStarView.cancel();
                    iv_windmill.setVisibility(View.GONE);
                    tv_accelerate_tips.setVisibility(View.GONE);
                    showCleanMemoryResult();
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        iv_windmill.setVisibility(View.VISIBLE);
        iv_windmill.startAnimation(windmillAnim);
    }

    private void showCleanMemoryResult() {
        //ProcessAndMemoryUtil.cleanMemory();
        long[] currentMemoryInfos = ProcessAndMemoryUtil.getAndroidMemory(getApplicationContext());
        long cleanResult = (currentMemoryInfos[1] - memoryInfos[1]) / 1024 / 1024;
        double usedMemory = (double) ((memoryInfos[0] - memoryInfos[1]) / 1024 / 1024);
        int percent = (int) (cleanResult / usedMemory * 100);
        if (usedMemory == 0) {
            percent = 0;
        }
        percent = Math.abs(percent);

        String tips;
        if ((System.currentTimeMillis() - lastCleanTime) / 1000 / 60d < 2d) {
            tips = getString(R.string.is_bset_status);//已达最佳状态；
            tv_accelerate_finish.setVisibility(View.GONE);
        } else {
            if (percent <= MIN_PERCENT) {
                //产生随机数（3-19之间）
                percent = new Random().nextInt(MAX_PERCENT - MIN_PERCENT + 1) + MIN_PERCENT;
            }
            tips = CommonUtils.replace(getString(R.string.speed_up_for_you), CommonUtils.TARGET_NAME, String.valueOf(percent));//加速5%

            lastCleanPercent = percent;
            lastCleanTime = System.currentTimeMillis();

        }

        tv_accelerate_result.setText(tips);

        ll_accelerate_result.setVisibility(View.VISIBLE);

        if (screenOff) {
            ll_accelerate_finish.setVisibility(View.VISIBLE);
            if (null != mHandler) {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();

                        ApkInstallUtils.onTryInstallApkByPackageName(mPackageNname);
                    }
                }, 5000);
            }
        } else {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.anim_accelerate_result);
            anim.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    if (null != mHandler) {
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                finish();

                                ApkInstallUtils.onTryInstallApkByPackageName(mPackageNname);
                            }
                        }, 5000);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            ll_accelerate_finish.setVisibility(View.VISIBLE);
            ll_accelerate_finish.startAnimation(anim);
        }

    }

    @Override
    protected void onDestroy() {
        if (iv_windmill != null) {
            iv_windmill.clearAnimation();
        }
        if (flyingStarView != null) {
            flyingStarView.cancel();
        }
        if (ll_accelerate_finish != null) {
            ll_accelerate_finish.clearAnimation();
        }
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }
        if (screenLockReceiver != null) {
            unregisterReceiver(screenLockReceiver);
        }

        super.onDestroy();
    }


    private void startClean() {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                try {
                    ProcessAndMemoryUtil.cleanMemory();
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }));
    }

    /**
     * 某些手机解锁屏幕特别慢，如果用户在锁屏界面点击通知栏的Boost，等屏幕真正解锁成功后已经过去了好几秒，这时候不加下面的处理的话，
     * 用户就看不到动画，甚至看不到本页面了
     */
    private class ScreenLockReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) {
                return;
            }
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                screenOff = true;
                if (iv_windmill != null) {
                    iv_windmill.clearAnimation();
                }
                if (flyingStarView != null) {
                    flyingStarView.cancel();
                }
                if (ll_accelerate_finish != null) {
                    ll_accelerate_finish.clearAnimation();
                    ll_accelerate_finish.setVisibility(View.GONE);
                }
                showCleanMemoryResult();
                return;
            }
            if (screenOff) {
                return;
            }
            if (Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
                if (mHandler != null) {
                    mHandler.removeCallbacksAndMessages(null);
                }

                if (iv_windmill != null) {
                    iv_windmill.clearAnimation();
                }
                if (flyingStarView != null) {
                    flyingStarView.cancel();
                }
                if (ll_accelerate_finish != null) {
                    ll_accelerate_finish.clearAnimation();
                    ll_accelerate_finish.setVisibility(View.GONE);
                }
                if (tv_accelerate_tips != null) {
                    tv_accelerate_tips.setVisibility(View.VISIBLE);
                }
                if (ll_accelerate_result != null) {
                    ll_accelerate_result.setVisibility(View.GONE);
                }
                isNormal = false;
                accelerateAnimStart();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }
}

package com.afmobi.palmplay.activate

import android.app.Activity
import android.content.DialogInterface
import android.view.KeyEvent
import android.view.View
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.dialog.TRDialogUtil
import com.afmobi.palmplay.main.dialog.PrivacyPolicyDialog
import com.afmobi.palmplay.setting.PrivacyDetailActivity
import com.afmobi.util.PhoneDeviceInfo
import com.transsion.palmstorecore.analytics.ComponentClickBuilder
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils
import com.transsion.palmstorecore.util.TRStringUtil

class TRPrivacyPolicyExecutor  : TRBaseExecutor<Any?>() {
    var privacyPolicyDialog : PrivacyPolicyDialog? = null
    var isPrivacyDialogClick = false
    override fun show(fromType: String?, activity: Activity?): Boolean {
        if(activity?.isDestroyed==true || activity?.isFinishing == true) {
            return false
        }
        if(isPrivacyDialogClick) {
            return false
        }

        if(privacyPolicyDialog != null) {
            privacyPolicyDialog!!.show()
            return true
        }

        if (TRDialogUtil.hasDialogShowing()) {
            return false
        }

        if(!isCanShow(fromType)) {
            return false;
        }
        try {

            val keyListener =
                DialogInterface.OnKeyListener { dialogInterface: DialogInterface?, keyCode: Int, event: KeyEvent ->
                    if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                        privacyPolicyDialog?.dismiss()
                        privacyPolicyDialog = null
                        return@OnKeyListener true
                    }
                    false
                }
            privacyPolicyDialog = PrivacyPolicyDialog(activity)
            val showListener =
                DialogInterface.OnShowListener { dialog: DialogInterface? ->

                    privacyPolicyDialog?.btnEnable?.setOnClickListener { v: View? ->
                        MMKVUtils.getNewMMKV()
                            .putBoolean(TRSharedPreferenceUtils.PRIVACY_SETTING_SWITCH, true)
                        PhoneDeviceInfo.setPsprs(1)
                        PrivacyDetailActivity.updatePsprs()
                        trackPrivacyDialogType(1)
                        privacyPolicyDialog?.dismiss()
                        privacyPolicyDialog = null
                        isPrivacyDialogClick = true
                    }
                    privacyPolicyDialog?.btnClose?.setOnClickListener { v: View? ->
                        trackPrivacyDialogType(0)
                        privacyPolicyDialog?.dismiss()
                        privacyPolicyDialog = null
                        isPrivacyDialogClick = true
                    }
                }
            privacyPolicyDialog!!.setOnShowListener(showListener)
            privacyPolicyDialog!!.setOnKeyListener(keyListener)
            privacyPolicyDialog!!.show()
        }catch (e: Exception) {
            return false
        }
        return true
    }

    fun trackPrivacyDialogType(buttonType: Int) {
        val value = TRStringUtil.generateString(
            TRAnalyticsConstant.HOME_A,
            TRAnalyticsConstant.PRIVACY_POLICY,
            "",
            ""
        )
        val builder: ComponentClickBuilder<*> = ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(value)
            .setButtonType(buttonType.toString())
        TRAnalysticsUtil.trackClick(builder)
    }

    override fun isCanShow(fromType: String?): Boolean {
        return TRNewManager.instance.canShow()
    }

    override fun dismiss(): Boolean {
        privacyPolicyDialog?.dismiss()

        return true
    }

    fun hide(): Unit{
        privacyPolicyDialog?.hide()
        PrivacyPolicyDialog.isShowing = false
    }
}

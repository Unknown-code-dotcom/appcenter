package com.afmobi.palmplay.activate.handler

import android.app.Activity
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.log.LogUtils

class TRPetGuideHandler(executor: TRBaseExecutor<*>?,
                        sceneName: String,
                        priority: TRPriority,
                        popupType: TRPopupType
) : TRChainHandler(sceneName, priority, popupType) {
    private var mExecutor: TRBaseExecutor<*>? = executor
    companion object {
        private const val TAG = "TRPetGuideHandler"
    }
    override fun canShow(fromType: String?): Boolean {
        if(mExecutor != null && TRNewManager.instance.canShow()) {
            return mExecutor!!.isCanShow(fromType)
        }
        return false;
    }

    override fun show(fromType: String?, activity: Activity?): Boolean {
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if (canShow(fromType)) {
            if (mExecutor!!.show(fromType, activity)) {
                TRNewManager.instance.markAsShown()
                if(popupType == TRPopupType.HOME_ONE_TIME) {
                    TRAnalysticsUtil.trackPopSenceInfo(
                        "$sceneName show called",
                        fromType,
                        sceneName
                    )
                }
                LogUtils.d(TAG, "show $sceneName")
                return  true
            }
        }
        return  false
    }

    override fun dismiss(): Boolean {
        if(mExecutor != null) {
            return mExecutor!!.dismiss()
        }
        return false
    }

    override fun showNext(fromType: String?): Boolean {
        if(AtyManager.getAtyManager().currentActivity != curActivity?.get()) {
            return false
        }
        if (canShow(fromType)) {
            return show(fromType, curActivity?.get())
        }
        return false
    }

    override fun showing(): Boolean {
        if(mExecutor != null) {
            return mExecutor!!.isShowing
        }
        return false
    }


}

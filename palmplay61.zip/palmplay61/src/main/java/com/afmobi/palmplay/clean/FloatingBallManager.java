package com.afmobi.palmplay.clean;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.afmobi.palmplay.SuspendedNotification.FloatingGuideView;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.customview.FloatingBall;
import com.afmobi.palmplay.customview.WaveBall;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler;
import com.afmobi.palmplay.setting.MsgDataExtJson;
import com.afmobi.palmplay.setting.MsgNodeData;
import com.afmobi.util.Constant;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * 悬浮球的管理
 *
 * @author xiangfei.wei
 * @date 2017/11/18
 */
public class FloatingBallManager {

    /**
     * 悬浮球只在桌面显示的设置
     */
    public static final String FLOATING_BALL_SHOW_ONLY_HOME = "floating_ball_show_only_home";

    /**
     * 悬浮球弹出页是否可见，TRUE，可见；如果可见，悬浮球就要显消失，两者互斥
     */
    public static boolean floatingBallActivityVisible = false;

    /**
     * 悬浮窗View的实例
     */
    private static FloatingBall floatingBall;

    /**
     * 悬浮窗View的参数
     */
    private static LayoutParams floatingBallLayoutParams;

    /**
     * 用于控制在屏幕上添加或移除悬浮窗
     */
    private static WindowManager mWindowManager;

    private static FrameLayout floatingPermissionGuideView;

    private static Handler mHandler = new Handler(Looper.getMainLooper());
    private static ShowRunable mShowRunable;

    /**
     * 创建悬浮球，初始位置为屏幕左边缘
     *
     * @param context 必须为应用程序的Context.
     */
    public static void createFloatingBall(Context context) {
        try {
            if (floatingBallActivityVisible)
                return;

            WindowManager windowManager = getWindowManager(context);
            int screenWidth = windowManager.getDefaultDisplay().getWidth();
            int screenHeight = windowManager.getDefaultDisplay().getHeight();
            if (floatingBall == null) {
                floatingBall = new FloatingBall(context);
                if (floatingBallLayoutParams == null) {
                    floatingBallLayoutParams = new LayoutParams();
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1) {
                        floatingBallLayoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                    } else if (Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1) {
                        floatingBallLayoutParams.type = LayoutParams.TYPE_SYSTEM_ALERT;
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        floatingBallLayoutParams.type = LayoutParams.TYPE_TOAST;
                    } else {
                        floatingBallLayoutParams.type = LayoutParams.TYPE_SYSTEM_ALERT;
                    }
                    floatingBallLayoutParams.format = PixelFormat.RGBA_8888;
                    floatingBallLayoutParams.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | LayoutParams.FLAG_NOT_FOCUSABLE;
                    floatingBallLayoutParams.gravity = Gravity.START | Gravity.TOP;
                    floatingBallLayoutParams.width = floatingBall.getViewWidth();
                    floatingBallLayoutParams.height = floatingBall.getViewHeight();
                    floatingBallLayoutParams.x = 0;
                    floatingBallLayoutParams.y = screenHeight * 3 / 10;
                }
                floatingBall.setParams(floatingBallLayoutParams);
                updateUsedPercent(context);
                windowManager.addView(floatingBall, floatingBallLayoutParams);
            }
        } catch (Exception e) {
            LogUtils.e("FloatingBallManager", e.toString());
        }
    }

    /**
     * 将悬浮球从屏幕上移除。
     *
     * @param context 必须为应用程序的Context.
     */
    public static void removeFloatingBall(Context context) {
        if (floatingBall != null) {
            try {
                WindowManager windowManager = getWindowManager(context);
                windowManager.removeView(floatingBall);
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            floatingBall = null;
        }
    }

    public static void updateFloatingBall(Context context) {
        /*if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1) {
            removeFloatingBall(context);
            createFloatingBall(context);
        } else*/
        updateUsedPercent(context);
    }

    /**
     * 更新悬浮球的内容。
     *
     * @param context
     */

    public static void updateUsedPercent(Context context) {
        if (floatingBall != null) {
            TextView percentView = (TextView) floatingBall.findViewById(R.id.tv_percent);
            FrameLayout container_floating_ball = (FrameLayout) floatingBall.findViewById(R.id.container_floating_ball);
            int percent = ProcessAndMemoryUtil.getSystemUsedMemoryPercent(context);
            percentView.setText(percent + "%");
            /*if (percent >= NotificationManageService.ACCELERATE_WARNNING_VALUE) {
                container_floating_ball.setSelected(true);
            } else {
                container_floating_ball.setSelected(false);
            }*/
            WaveBall waveBall = floatingBall.findViewById(R.id.wave_ball);
            waveBall.updateWavePosition(percent);
        }
    }

    /**
     * 是否有悬浮球显示在屏幕上。
     *
     * @return 有悬浮球显示在桌面上返回true，否则返回false。
     */
    public static boolean isFloatingBallShowing() {
        return floatingBall != null;
    }

    private static WindowManager getWindowManager(Context context) {
        if (mWindowManager == null) {
            mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        }
        return mWindowManager;
    }


    /**
     * 判断当前界面是否是桌面
     */
    public static boolean isHome(Context context) {
        ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> rti = mActivityManager.getRunningTasks(1);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP)
            return getLauncherPackageName(context).contains(rti.get(0).topActivity.getPackageName());
        else
            return getLauncherPackageName(context).contains(getTopApp(context));
    }

    /**
     * 获得属于桌面的应用的包名
     *
     * @return 返回包含所有包名的字符串列表
     */
    private static List<String> getLauncherPackageName(Context context) {
        List<String> names = new ArrayList<>();
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        List<ResolveInfo> resolveInfo = packageManager.queryIntentActivities(intent,
                PackageManager.MATCH_DEFAULT_ONLY);
        for (ResolveInfo ri : resolveInfo) {
            names.add(ri.activityInfo.packageName);
        }
        return names;
    }

    /**
     * API level 21以上获取当前正在使用或最近使用过的应用包名；
     *
     * @param context
     * @return 包名，获取不到返回null
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private static String getTopApp(Context context) {
        UsageStatsManager mUsageStatsManager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);//usagestats
        long time = System.currentTimeMillis();
        List<UsageStats> usageStatsList = mUsageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_BEST, time - 1000 * 60 * 30, time);

        if (usageStatsList != null && !usageStatsList.isEmpty()) {
            SortedMap<Long, UsageStats> usageStatsMap = new TreeMap<>();
            for (UsageStats usageStats : usageStatsList) {
                usageStatsMap.put(usageStats.getLastTimeUsed(), usageStats);
            }
            if (!usageStatsMap.isEmpty()) {
                return usageStatsMap.get(usageStatsMap.lastKey()).getPackageName();
            }
        }
        return null;
    }

    /**
     * 检测用户是否对本app开启了“Apps with usage access”权限;API LEVEL 21 及以上使用
     *
     * @param context
     * @return true, 有权限；
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static boolean hasUsageAccessPermission(Context context) {
        AppOpsManager appOps = (AppOpsManager)
                context.getSystemService(Context.APP_OPS_SERVICE);
        if (appOps == null) {
            return false;
        }
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), context.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }


    /**
     * 创建 系统权限申请时的悬浮引导
     *
     * @param context
     * @param textResId
     */
    public static void createFloatingPermissionGuide(Context context, int textResId, int titleResId) {
        removeFloatingPermissionGuide(context);
        WindowManager windowManager = getWindowManager(context);
        floatingPermissionGuideView = new FloatingGuideView(context, windowManager, textResId, titleResId);
        floatingPermissionGuideView.setVisibility(View.GONE);

        LayoutParams params = new LayoutParams();
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1) {
            params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1) {
            params.type = LayoutParams.TYPE_SYSTEM_ALERT;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            params.type = LayoutParams.TYPE_TOAST;
        } else {
            params.type = LayoutParams.TYPE_SYSTEM_ALERT;
        }
        params.format = PixelFormat.RGBA_8888;
        //params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_NOT_FOCUSABLE;
        params.gravity = Gravity.START | Gravity.BOTTOM;
        params.width = LayoutParams.MATCH_PARENT;
        params.height = LayoutParams.WRAP_CONTENT;

        Point point = new Point();
        windowManager.getDefaultDisplay().getSize(point);
        try {
            windowManager.addView(floatingPermissionGuideView, params);
        } catch (Throwable e) {
            //ignore
        }

        mShowRunable = new ShowRunable();
        mHandler.postDelayed(mShowRunable, 1000);
    }

    /**
     * 移除系统权限申请时的悬浮引导；
     *
     * @param context
     */
    public static void removeFloatingPermissionGuide(Context context) {
        if (floatingPermissionGuideView != null) {
            try {
                getWindowManager(context).removeView(floatingPermissionGuideView);
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            floatingPermissionGuideView = null;
        }
        removeHandleCallback();
    }

    public static void removeHandleCallback() {
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
    }

    /**
     * 处理是否显示download 按钮
     *
     * @param msgData
     * @param downloadBtn
     */
    public static void showDownloadButton(MsgNodeData msgData, TextView downloadBtn) {
        if (!msgData.isNotifyType()) {
            JsonObject jsonObj = msgData.extJson;
            Gson gson = new Gson();
            String itemID = null;
            if (msgData.isItemType()) {
                downloadBtn.setVisibility(View.VISIBLE);

                MsgDataExtJson msgDataExtJson = null;
                if (null != msgData.extJson && !msgData.extJson.isJsonNull()) {
                    msgDataExtJson = gson.fromJson(msgData.extJson, MsgDataExtJson.class);
                }
                if (msgDataExtJson != null
                        && DetailType.isApp(DetailType.getType(msgDataExtJson.detailType))
                        && !TextUtils.isEmpty(msgDataExtJson.packageName)) {
                    Integer installedVersion = InstalledAppManager.getInstance().getInstalledVersion(msgDataExtJson.packageName);
                    if (installedVersion != null) {
                        if (installedVersion < msgDataExtJson.versionCode) {
                            downloadBtn.setText(R.string.text_update);
                        } else {
                            if (!msgData.mInstalled) {
                                downloadBtn.setVisibility(View.GONE);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 处理通知栏的点击事件
     *
     * @param context
     * @param msgData
     * @param isDownloadButtonClick
     */
    public static void onSuspendedNotificationClick(Context context, MsgNodeData msgData, boolean isDownloadButtonClick) {
        Intent broadcastIntent = new Intent(PalmstoreSysHandler.NOTIFICATION_BROADCAST_ACTION_ENTRY);
        broadcastIntent.putExtra("title", msgData.title);
        broadcastIntent.putExtra("message_id", msgData.msgID);
        broadcastIntent.putExtra(MsgNodeData.MsgPushType.class.getSimpleName(), msgData.cmd);
        if (!msgData.isNotifyType()) {
            JsonObject jsonObj = msgData.extJson;
            Gson gson = new Gson();
            String itemID = null;
            String name = "", imgurl = "";
            if (msgData.isItemType()) {
                if (msgData.mInstalled && !TRStringUtil.isBlank(msgData.itemId)) {
                    itemID = msgData.itemId;
                } else {
                    itemID = gson.fromJson(jsonObj.get("itemID"), String.class);
                }
                String detailType = gson.fromJson(jsonObj.get("detailType"), String.class);
                name = gson.fromJson(jsonObj.get("name"), String.class);
                imgurl = TRStringUtil.isBlank(msgData.iconUrl) ? msgData.imgUrl : msgData.iconUrl;
                if (!isDownloadButtonClick) {
                    broadcastIntent.putExtra(DetailType.class.getSimpleName(), detailType);
                } else {
                    //产品增加下载快捷按钮
                    int notifyID = Constant.SYS_MSG_NOTIFY_ID + Integer.valueOf(msgData.msgID);
                    Intent buttonDownloadIntent = new Intent(PalmstoreSysHandler.NOTIFICATION_BROADCAST_ACTION_CLICK_DOWNLOAD);
                    buttonDownloadIntent.putExtra("id", notifyID);
                    buttonDownloadIntent.putExtra(Constant.KEY_ITEMID, itemID);
                    buttonDownloadIntent.putExtra(DetailType.class.getSimpleName(), detailType);
                    buttonDownloadIntent.putExtra("name", name);
                    buttonDownloadIntent.putExtra("imgUrl", imgurl);
                    context.sendBroadcast(buttonDownloadIntent);
                    return;
                }
            } else if (msgData.isRankType()) {
                itemID = gson.fromJson(jsonObj.get("rankID"), String.class);
                String rankName = gson.fromJson(jsonObj.get("rankName"), String.class);
                String detailType = gson.fromJson(jsonObj.get("detailType"), String.class);
                broadcastIntent.putExtra(DetailType.class.getSimpleName(), detailType);
                broadcastIntent.putExtra("rankName", rankName);
            } else if (msgData.isLinkType()) {
                String url = gson.fromJson(jsonObj.get("url"), String.class);
                String browserType = gson.fromJson(jsonObj.get("browserType"), String.class);
                broadcastIntent.putExtra("url", url);
                broadcastIntent.putExtra("browserType", browserType);
            }
            broadcastIntent.putExtra("ItemID", itemID);
            broadcastIntent.putExtra("name", name);
            broadcastIntent.putExtra("imgUrl", imgurl);
            context.sendBroadcast(broadcastIntent);
        }
    }

    static class ShowRunable implements Runnable{

        @Override
        public void run() {
            if (floatingPermissionGuideView != null && floatingPermissionGuideView.getVisibility() != View.VISIBLE) {
                floatingPermissionGuideView.setVisibility(View.VISIBLE);
            }
            removeHandleCallback();
        }
    }
}

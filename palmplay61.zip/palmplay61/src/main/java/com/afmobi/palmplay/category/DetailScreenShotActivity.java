// TOP SECRET
package com.afmobi.palmplay.category;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.afmobi.palmplay.customview.recyclerbanner.FullScreenShotRecyclerView;
import com.afmobi.util.DisplayUtil;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.util.AndroidVUIUtils;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import com.transsion.palmstorecore.BaseCoreActivity;

//只是做个展示无需继承baseactivity，完成base得生命周期
public class DetailScreenShotActivity extends BaseCoreActivity {
	private List<String> mImageUrlList;
	private List<String> mSmallUrlList;
	private List<Integer> mImageModeList;
	private int mPosition = 0;
	private ImageView iv_back;
	private FullScreenShotRecyclerView fullScreenShotRecyclerViewBanner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_screenshot);
		AndroidVUIUtils.INSTANCE.matchAndroid15UI(this, false);
		fullScreenShotRecyclerViewBanner = findViewById(R.id.picture_pager);
		processExtraData(getIntent());
		iv_back = findViewById(R.id.iv_back);
		iv_back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		DisplayUtil.onFitWaterFall(this);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		processExtraData(intent);
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	private void processExtraData(Intent intent) {
		if(intent == null){
			finish();
			return;
		}
		mPosition = intent.getIntExtra("position", 0);
		if(mImageUrlList == null) {
			mImageUrlList = new ArrayList<>(6);
		}

		if(mSmallUrlList == null){
			mSmallUrlList = new ArrayList<>(6);
		}
		mImageUrlList = getIntent().getStringArrayListExtra("ImageUrlList");
		mSmallUrlList = getIntent().getStringArrayListExtra("SmallUrlList");
		mImageModeList = getIntent().getIntegerArrayListExtra("ImageModeList");
		if(mImageUrlList==null && mSmallUrlList == null) {
			finish();
			return;
		}

		if (fullScreenShotRecyclerViewBanner != null) {
			fullScreenShotRecyclerViewBanner.initBannerImageView(mImageUrlList, mSmallUrlList, mImageModeList,mPosition);
		}
	}

	@Override
	public void finish() {
		super.finish();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (fullScreenShotRecyclerViewBanner != null) {
			fullScreenShotRecyclerViewBanner.destroyDrawingCache();
		}
		TRBitmapManager.clearCacheByUrl(mImageUrlList);
	}
}

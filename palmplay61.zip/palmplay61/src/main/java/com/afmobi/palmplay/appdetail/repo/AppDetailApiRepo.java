package com.afmobi.palmplay.appdetail.repo;

import android.content.pm.PackageInfo;
import android.text.TextUtils;

import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.appdetail.model.AppDetailData;
import com.afmobi.palmplay.configs.UrlConfig;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.DetailResponseData;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.ResponseBuilder;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.network.AsyncHttpRequestUtils;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.network.util.RequestParams;
import com.afmobi.util.PhoneDeviceInfo;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.transsion.core.CoreUtil;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.apm.TRApmAnalysticsUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.SignUtils;
import com.transsnet.store.BuildConfig;

import java.io.File;
import java.util.List;

public class AppDetailApiRepo {
    private AppDetailAdRepo appDetailAdRepo = new AppDetailAdRepo();
    private long mStartTime = 0;
    public static long mLastCostTime = 0;
    protected static volatile long requestTime;//ad api接口请求的开始时间
    private String mRequestUrl = "";
    private String mValue, mFrom;
    private LoadListener loadListener;

    private AbsRequestListener<JsonObject> mLoadListener = new AbsRequestListener<JsonObject>() {
        @Override
        public void onResponse(JsonObject response) {
            LogUtils.i("App detail response:" + response != null ? response.toString() : "[no data]");
            mLastCostTime = System.currentTimeMillis()-mStartTime;
            String totalTime = mLastCostTime + "";
            mRequestUrl = UrlConfig.BASE_DETAIL_URL + UrlConfig.DETAIL_NEW;
            TRAnalysticsUtil.trackCommonTime(TRAnalyticsConstant.TRACK_TECH_EVENT,mRequestUrl,totalTime);

            onDetailDataPreCallback(response,null);
        }

        @Override
        public void onError(ANError anError) {
            if(anError != null){
                //为空的都是自己代码中设置的空，我们需要处理非空的由网络框架传递过来的错误
//                networkErrorLiveData.setValue(anError);
                if (loadListener!=null){
                    loadListener.networkErrorCallback(anError);
                }
            }

            onDetailDataPreCallback(null,anError);
        }
    };

    public AppDetailApiRepo(LoadListener loadListener) {
        this.loadListener = loadListener;
    }

    public void setmValue(String mValue) {
        this.mValue = mValue;
    }

    public void setmFrom(String mFrom) {
        this.mFrom = mFrom;
    }

    public List<TaNativeInfo> getDetailAdInfos(){
        return appDetailAdRepo.getDetailAdInfos();
    }

    public void loadAd(){
        requestTime = System.currentTimeMillis();
        appDetailAdRepo.loadAd(new AppDetailAdRepo.AdLoadListener() {
            @Override
            public void onDetailAdDataCallback(JsonObject response) {
                if (loadListener!=null){
                    loadListener.onDataCallback(response);
                }
            }
        });
    }

    public void loadDetailData(String tag, String pkg, String itemID, String flowSource, String fromPage, PageParamInfo pageParamInfo) {
        TRApmAnalysticsUtil.trackAPMPageApiRequest(mValue,mFrom);
        RequestParams params = PhoneDeviceInfo.getCommonRequestParams();
        params.put("itemID", itemID);
        params.put("flowSource", flowSource);
        params.put("fromPage", fromPage);
        params.put("packageName", pkg);
        params.put("apiVersion","1.0.3");
        if (mLastCostTime > 0) {
            params.put("lastCostTime", mLastCostTime);
        }
        params.put("isCandidate","true");
        params.put("sceneCode", SceneCode.AD_de);
        params.put("supportOverlay", NetworkClient.SUPPORT_OVERLAY_FLAG);
        PageConstants.putPageParam(params, pageParamInfo);
        mStartTime = System.currentTimeMillis();
        //判断本地是否安装,如果安装，则上传可以差分的信息给服务器
        try {

            InstalledAppInfo appInfo = InstalledAppManager.getInstance().get(pkg);
            if (appInfo != null) {
                params.put("installed", 1);
            }else {
                params.put("installed", 0);
            }

            if (BuildConfig.FEATURE_APP_DIFF_SWITCH && appInfo != null) {
                params.put("isSupportDiff", "1");
                PackageInfo packageInfo = InstalledAppManager.getInstalledSpecialApp(CoreUtil.getContext(), pkg);
                params.put("curItemVersion", packageInfo.versionCode);
                String dir = InstalledAppManager.getInstance().getSourceDir(pkg);
                if (!TextUtils.isEmpty(dir)) {
                    String curItemMd5= SignUtils.getMd5ByFile(new File(dir));
                    params.put("curItemMd5", curItemMd5);
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        AsyncHttpRequestUtils.get(UrlConfig.BASE_DETAIL_URL + UrlConfig.DETAIL_NEW, params, mLoadListener, tag);
    }

    private void onDetailDataPreCallback(JsonObject response,ANError anError) {
        AppDetailData.getInstance().setFeatureRequestFinished(true);

        long responseTime = System.currentTimeMillis() - requestTime;
        String errorMsg = "";
        if(anError!=null) {
            if(TextUtils.isEmpty(anError.getMessage())) {
                errorMsg = anError.getErrorDetail() + anError.getErrorCode();
            } else {
                errorMsg = anError.getMessage() + anError.getErrorCode();
            }
        }

        if(response!=null) {
            TRAnalysticsUtil.trackFeatureApi("" + requestTime, "" + responseTime, SceneCode.AD_de, appDetailAdRepo.isFeatureAdFinished);
        } else {
            TRAnalysticsUtil.trackFeatureApi("" + requestTime, "" + responseTime, SceneCode.AD_de+"_"+TRAnalyticsConstant.ERROR, appDetailAdRepo.isFeatureAdFinished);
        }

        DetailResponseData detailResponseData = null;
        boolean isValid = false;
        try {
            detailResponseData = new Gson().fromJson(response, DetailResponseData.class);
            isValid = detailResponseData != null && detailResponseData.detailTabList != null;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        TRApmAnalysticsUtil.trackAPMPageApiResponse(mValue, mFrom,anError == null ? TRAnalyticsConstant.APM_STATUS_SUC:TRAnalyticsConstant.APM_STATUS_FAIL,
                isValid ? TRAnalyticsConstant.APM_VALID_DATA :TRAnalyticsConstant.APM_INVALID_DATA, responseTime, errorMsg);

        if (responseTime <= HisavanaSdkManager.SDK_LOAD_TIMEOUT) {
            if (appDetailAdRepo.isFeatureAdFinished) {
                if (appDetailAdRepo.isCacheLoadAd) {
                    List<FeatureBean> listItems = null;
                    if (detailResponseData != null) {
                        DetailComponentItemData component = detailResponseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
                        if (component != null) {
                            listItems = component.featureDtoList;
                        }
                    }

                    if (listItems != null && listItems.size() > 0) {
                        appDetailAdRepo.stopCountDownTimer();
                        ResponseBuilder builder = new ResponseBuilder()
                                .setDetailResponse(response);
                        appDetailAdRepo.respBuilderLiveData.setValue(builder);
                        appDetailAdRepo.hisavanaSdkDetailAdCacheLoad(listItems);
                        return;
                    }
                } else {
                    appDetailAdRepo.stopCountDownTimer();
                }
            }else {
                ResponseBuilder builder = new ResponseBuilder()
                        .setDetailResponse(response);
                appDetailAdRepo.respBuilderLiveData.setValue(builder);
                return;
            }
        }else { //大于300ms
            appDetailAdRepo.destroyDetailAd();
            if (!appDetailAdRepo.isFeatureAdFinished) {
                TRAnalysticsUtil.trackEwFilterInfo(SceneCode.AD_de, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                appDetailAdRepo.destorySdkAdInfo();
            }

            if (response != null) {
                if (!appDetailAdRepo.isFeatureAdFinished) {
                    List<FeatureBean> listItems = null;
                    if (detailResponseData != null) {
                        DetailComponentItemData component = detailResponseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
                        if (component != null) {
                            listItems = component.featureDtoList;
                        }
                    }
                    if (listItems != null && listItems.size() > 0) {
                        appDetailAdRepo.stopCountDownTimer();
                        ResponseBuilder builder = new ResponseBuilder()
                                .setDetailResponse(response);
                        appDetailAdRepo.respBuilderLiveData.setValue(builder);
                        appDetailAdRepo.hisavanaSdkDetailAdCacheLoad(listItems);
                        return;
                    }
                } else {
                    if (appDetailAdRepo.isCacheLoadAd) {
                        List<FeatureBean> listItems = null;
                        if (detailResponseData != null) {
                            DetailComponentItemData component = detailResponseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
                            if (component != null) {
                                listItems = component.featureDtoList;
                            }
                        }

                        if (listItems != null && listItems.size() > 0) {
                            appDetailAdRepo.stopCountDownTimer();
                            ResponseBuilder builder = new ResponseBuilder()
                                    .setDetailResponse(response);
                            appDetailAdRepo.respBuilderLiveData.setValue(builder);
                            appDetailAdRepo.hisavanaSdkDetailAdCacheLoad(listItems);
                            return;
                        }
                    }
                }
            }
        }

        if (loadListener!=null){
            loadListener.onDataCallback(response);
        }
    }

    public void destoryHisavanaSdk() {
        appDetailAdRepo.destorySdkAdInfo();

        appDetailAdRepo.destroyDetailAd();
        appDetailAdRepo.stopCountDownTimer();
    }

    public interface LoadListener{
        void onDataCallback(JsonObject response);

        void networkErrorCallback(ANError anError);
    }

}

package com.afmobi.palmplay.alonefuction;

import java.util.List;

public class H5TaskInfoList {
    public List<H5TaskInfo> tasks;
    public int roundId;
}

package com.afmobi.palmplay.appmanage;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.model.InstantGameBean;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.h5.offline.H5OfflineGameManager;
import com.afmobi.palmplay.h5.offline.db.H5OfflineInfoDatabase;
import com.afmobi.palmplay.home.instant.model.TrInstantRecentBean;
import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameDatabase;
import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameInfo;
import com.afmobi.palmplay.model.GameFavoriteInfo;
import com.afmobi.palmplay.model.H5OfflineGameInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.FileUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.TRPath;
import com.transsion.xwebview.instant.util.GlobalUtil;
import com.transsion.xwebview.offline.WebUtil;

import android.text.TextUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InstantGamesViewModel extends ViewModel {

    private final MutableLiveData<List<InstantGameBean>> instantGamesData = new MutableLiveData<>();
    // 预置的飞机大战的游戏ID
    private static final String GAMEID_AIRCRAFTWAR_STR = "-1";
    private static final String POULTRY_FARM_OPENURL = H5OfflineGameManager.FARM_OPEN_URL;
    private static final int GAMEID_AIRCRAFTWAR_INT = -1;

    public LiveData<List<InstantGameBean>> getInstantGamesData() {
        return instantGamesData;
    }


    public void loadInstantGames() {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                List<InstantGameBean> instantGames = new ArrayList<>();

                List<TrInstantH5GameInfo> h5Games = TrInstantH5GameDatabase.getDatabase(PalmplayApplication.getAppInstance()).getTrInstantH5GameDao()
                        .getTrInstantH5GameRecentPlayedList();
                for (TrInstantH5GameInfo info : h5Games) {
                    if (GlobalUtil.h5GameIsReady(info.openUrl)) {
                        InstantGameBean bean = new InstantGameBean();
                        bean.type = InstantGameBean.TYPE_H5;
                        bean.h5GameInfo = info;
                        String resourceId = GlobalUtil.md5Of32(WebUtil.parseUrl(info.openUrl));
                        String path = TRPath.getH5OfflineGamePath() + File.separator + resourceId;
                        long sizeLong = GlobalUtil.calculateDirectorySize(path);
                        bean.sizeName = FileUtils.getSizeName(sizeLong);
                        // 飞机大战不显示
                        if (GAMEID_AIRCRAFTWAR_STR.equals(bean.h5GameInfo.gameId)) {
                            continue;
                        }
                        // 农场游戏不展示
                        if (normalizeUrl(POULTRY_FARM_OPENURL).equals(normalizeUrl(bean.h5GameInfo.openUrl))) {
                            continue;
                        }
                        if (GlobalUtil.h5GameIsReady(bean.h5GameInfo.openUrl)) {
                            instantGames.add(bean);
                        }
                    }

                }
                List<GameFavoriteInfo> favoriteGames = H5OfflineInfoDatabase.getDatabase(PalmplayApplication.getAppInstance()).getGameFavoriteDao().getGameFavoriteList(10);
                List<H5OfflineGameInfo> offlineGames = H5OfflineGameManager.getInstance().getH5OfflineGameInfoList();
                HashMap<String, GameFavoriteInfo> favoriteWithGameIdInfoMap = new HashMap<>();
                if (favoriteGames != null && favoriteGames.size() > 0) {
                    for (GameFavoriteInfo gameFavoriteInfo : favoriteGames) {
                        int id = gameFavoriteInfo.id;
                        if (id != GAMEID_AIRCRAFTWAR_INT
                                && !normalizeUrl(POULTRY_FARM_OPENURL).equals(normalizeUrl(gameFavoriteInfo.openUrl))) {
                            for (H5OfflineGameInfo h5OfflineGameInfo : offlineGames) {
                                int h5OfflineGameId = h5OfflineGameInfo.id;
                                if (h5OfflineGameId == id) {
                                    favoriteWithGameIdInfoMap.put(h5OfflineGameInfo.gameId + "", gameFavoriteInfo);
                                }
                            }
                        }
                    }
                }
                if (h5Games.size() > 0 && favoriteWithGameIdInfoMap.size() > 0) {
                    //筛选出H5中是否有相同的GameID，如果有，则把对应的Key移除掉(只保留H5游戏的)
                    for (TrInstantH5GameInfo trInstantH5GameInfo : h5Games) {
                        String gameId = trInstantH5GameInfo.gameId;
                        GameFavoriteInfo gameFavoriteInfo = favoriteWithGameIdInfoMap.get(gameId);
                        if (gameFavoriteInfo != null) {
                            favoriteWithGameIdInfoMap.remove(gameId);
                        }
                    }
                }
                if (favoriteWithGameIdInfoMap.size() > 0) {
                    for (Map.Entry<String, GameFavoriteInfo> entry : favoriteWithGameIdInfoMap.entrySet()) {
                        String gameId = entry.getKey();
                        GameFavoriteInfo favoriteInfo = entry.getValue();
                        InstantGameBean bean = new InstantGameBean();
                        bean.type = InstantGameBean.TYPE_OFFLINE;
                        bean.gameFavoriteInfo = favoriteInfo;
                        bean.gameFavoriteInfo.id = Integer.parseInt(gameId);
                        String resourceId = GlobalUtil.md5Of32(WebUtil.parseUrl(favoriteInfo.openUrl));
                        String path = TRPath.getH5OfflineGamePath() + File.separator + resourceId;
                        long sizeLong = GlobalUtil.calculateDirectorySize(path);
                        bean.sizeName = FileUtils.getSizeName(sizeLong);
                        if (sizeLong > 0) {
                            instantGames.add(bean);
                        }
                    }
                }

                if (ConfigManager.getGameSwitch() != -2) {
                    List<FileDownloadInfo> vaGames = PsVaManager.getInstance().getVaInstalledPackages(PsVaManager.GET_INSTALLED_PACKAGES | PsVaManager.GET_KEEP_DATA_PACKAGES);
                    if (vaGames != null && vaGames.size() > 0) {
                        for (FileDownloadInfo info : vaGames) {
                            InstantGameBean bean = new InstantGameBean();
                            bean.type = InstantGameBean.TYPE_VA;
                            info.hasTrack = false;
                            bean.vaGameInfo = info;
                            bean.sizeName = FileUtils.getSizeName(bean.vaGameInfo.sourceSize);
                            instantGames.add(bean);
                        }
                    }
                }
                Collections.sort(instantGames);
                instantGamesData.postValue(instantGames);
            }
        }));
    }

    @Override
    protected void onCleared() {
        super.onCleared();
    }

    private String normalizeUrl(String openUrl) {
        if (TextUtils.isEmpty(openUrl)) return "";
        int idx = openUrl.indexOf('?');
        return idx >= 0 ? openUrl.substring(0, idx) : openUrl;
    }

}

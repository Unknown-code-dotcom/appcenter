package com.afmobi.palmplay.base;

import com.transsion.palmstorecore.util.ToastManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.activate.TRUpdateVersionExecutor;
import com.afmobi.palmplay.alonefuction.UpdateStateActivity;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.service.UpdateService;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.transsion.palmstorecore.util.DeviceTypeExKt;
import com.afmobi.util.PadUtils;
import com.afmobi.util.FileUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.androidnetworking.AndroidNetworking;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.ChangeAppNameUtil;
import com.transsion.palmstorecore.util.SystemUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.DialogUpdateBinding;

import androidx.databinding.DataBindingUtil;


public abstract class BaseUpgradeActivity extends BaseFragmentActivity implements View.OnClickListener {

	protected ClientVersion mClientVersion;
	protected String mNewVerStr = "";
	protected boolean isForceUpdate;
	protected DialogUpdateBinding mBinding;
    public static final String IS_FORCE_UPDATE = "isForceUpdate";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		getWindow().setDimAmount(TRStatusBarUtil.isDarkMode() ? 0.65f : 0.2f);
		setWindow();

		mClientVersion = PalmPlayVersionManager.getInstance().getNewClientVersionInfo();

		if (null == mClientVersion) {
			finish();
			return;
		}
		mNewVerStr = mClientVersion.versionName;

		isForceUpdate = getIntent().getBooleanExtra(IS_FORCE_UPDATE, false);

		setupBinding();

		TRUpdateVersionExecutor.STATUS = true;
	}

	protected void setupBinding() {
		mBinding = DataBindingUtil.setContentView(this, R.layout.dialog_update);
		mBinding.tvOk.setOnClickListener(this);
		mBinding.tvCancel.setOnClickListener(this);
        mBinding.tvName.setText(ChangeAppNameUtil.INSTANCE.changeAppName(this, R.string.access_usage));

		mBinding.tvVersion.setText(getString(R.string.text_version) + ":  " + mNewVerStr);
		mBinding.tvSize.setText(getString(R.string.txt_apk_size) + ":  " + FileUtils.getSizeName(mClientVersion.size));
		String versionText;
		if (TextUtils.isEmpty(mNewVerStr)){
			return;
		}else if (mNewVerStr.startsWith("V")) {
			versionText = mNewVerStr;
		} else {
			versionText = "V" + mNewVerStr;
		}
		mBinding.tvVersion.setText(versionText);
		mBinding.tvSize.setText(FileUtils.getSizeName(mClientVersion.size));

		if (PhoneDeviceInfo.checkWifiIsAvailable()) {
			mBinding.tvCheck.setVisibility(View.GONE);
		}

		String updateInfoStr = "";
		if (null != mClientVersion.updateInfos) {
			for (int i = 0; i < mClientVersion.updateInfos.size(); i++) {
				int dispNum = i + 1;
				String prefixStr = "";
				if (0 == i) {
					//prefixStr += dispNum + ". ";
				} else {
					prefixStr += "\n" /*+ dispNum + ". "*/;
				}
				updateInfoStr += prefixStr + mClientVersion.updateInfos.get(i);
			}
		}
		if (!TextUtils.isEmpty(updateInfoStr)) {
			mBinding.tvMessage.setText(updateInfoStr);
		} else {
			mBinding.tvMessage.setText(ChangeAppNameUtil.INSTANCE.changeAppName(this,getDefaultUpdateMessage()));
		}

		mBinding.tvCancel.setText(isForceUpdate() ? getString(R.string.text_exit_app) : getString(R.string.text_cancel));
	}

	private void setWindow() {
		// PAD 端：居中展示，最大宽度 dialog_max_width，最大高度 85% 屏幕高
		if (DeviceTypeExKt.isPadDisplay(this, getResources().getConfiguration(), DeviceTypeExKt.getContextDisplayId(this))) {
			PadUtils.applyPadActivityAsDialog(this);
			return;
		}
		int mMargin = SystemUtils.dip2px(TRApplicationContextUtil.getInstance(), 16);
		WindowManager wm = (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		DisplayMetrics dm = new DisplayMetrics();
		display.getRealMetrics(dm);

		int mDialogWidth = dm.widthPixels - 2 * mMargin;
		int mDialogHeight = WindowManager.LayoutParams.WRAP_CONTENT;
		WindowManager.LayoutParams p = getWindow().getAttributes();
		p.width = mDialogWidth;
		p.height = mDialogHeight;
		p.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
		int bottomHeightHasNavigation = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 28);
		if (DisplayUtil.bottomNavigationBarHeight > 0 && bottomHeightHasNavigation - DisplayUtil.bottomNavigationBarHeight > 0) {
			bottomHeightHasNavigation = bottomHeightHasNavigation - DisplayUtil.bottomNavigationBarHeight;
		}
		int dp16 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 16);
		p.y = DisplayUtil.isGestureNavigationBarOn(getApplicationContext()) ? bottomHeightHasNavigation : dp16;
		getWindow().setAttributes(p);
	}

	protected void startInstalling() {
		final ClientVersion clientVersion = PalmPlayVersionManager.getInstance().getNewClientVersionInfo();
		final String newVersionFilePath = FilePathManager.myselfNewVersionFilePath();
		DownloadDecorator.installPalmstoreSelf(newVersionFilePath, (clientVersion != null) ? CommonUtils.getPreAuthTokensByString(clientVersion.preAuthToken) : null);
		if (null != clientVersion) {
			TRAnalysticsUtil.palmsClientUpdateClick(TRAnalyticsConstant.FROMPAGE_CLICK, clientVersion.versionCode,
					clientVersion.upgradeFashion, clientVersion.id, clientVersion.versionCode);
		}
	}

	protected void startUpgrading(String fromPage) {
		ClientVersion clientVersion = PalmPlayVersionManager.getInstance().getNewClientVersionInfo();

		if (null != clientVersion) {
			TRAnalysticsUtil.palmsClientUpdateClick(fromPage, clientVersion.versionCode,
					clientVersion.upgradeFashion, clientVersion.id, clientVersion.versionCode);
		}

		if (!PhoneDeviceInfo.netWorkIsConnected()) {
			ToastManager.getInstance().showS(this, R.string.tip_no_network);
			return;
		} else if (!AndroidNetworking.isRequestRunning(Constant.CLIENT_SELF_UPDATE_DOWLOAD)) {
			PalmPlayVersionManager.getInstance().setIsUpdating(true);
			UpdateService.downloadNewVersion(this, clientVersion, true, null, fromPage);
		}

		skipUpdateStateActivity();

		setFinishOnTouchOutside(false);
//		ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tips_downloading);
		finish();
	}

	protected void skipUpdateStateActivity() {
		Intent intent = new Intent(this, UpdateStateActivity.class);
		intent.putExtra(IS_FORCE_UPDATE, isForceUpdate());
		startActivity(intent);
	}

	protected abstract int getDefaultUpdateMessage();

	protected abstract boolean isForceUpdate();

	@Override
	public String getValue() {
		return "";
	}
}    
package com.afmobi.palmplay.activate;

import android.content.Intent;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.v6_3.RecommendInstallCache;
import com.afmobi.palmplay.dialog.TRDialogShowInterface;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.main.TRRecommendNewActivity;
import com.afmobi.palmplay.main.TRRecommondActivity;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.RecommendBean;
import com.cloud.hisavana.ac.sdk.api.listener.AdListener;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.cloud.hisavana.ac.sdk.common.util.TrackingUtil;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.afmobi.util.CommonUtils;
import com.transsnet.store.BuildConfig;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager.SDK_LOAD_CACHE_TIMEOUT;
import static com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager.TRACK_LOAD_ADS_ADD_QUEUE;

import androidx.annotation.NonNull;

/***
 * created by yongli.li
 * 一键安装的执行者
 */
public class TRRecomInstallExecutor extends TRBaseExecutor implements TRDialogShowInterface {
    public static volatile boolean STATUS = false;//代表本身是否正在显示
    private static String positionID = "";

    private boolean showResult = false;
    private static volatile boolean mustInstallExclude = false;
    // 用于标记连续进入非屏蔽一键装机Activity次数，大于2次，标记一键装机可弹出
    private static final AtomicInteger enterActivityTimes = new AtomicInteger(0);

    @Override
    public boolean isCanShow(String fromType) {
        if (mustInstallExclude){
            LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "新手 -> mustInstallExclude:" +mustInstallExclude+" ,return");
            return false;    //新增，被拦截
        } else{
            LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "新手 -> mustInstallExclude:" +mustInstallExclude+" ,continue");
        }
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "isCanShow: " + fromType);
        //新增新手云控开关
        if (!ConfigManager.enableNrCloudControl()) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Recommend install will not show,because clod Cloud control is closed");
            return false;
        }
        //判断是否需要被拦截
        if(CommonUtils.isNeedDisableByDLC() || CommonUtils.isNeedGtIntercept(TRActivateConstant.GT_GUIDE)){
            return false;
        }
        return TRDialogUtil.recommendInstallCanShow();
    }

    @Override
    public boolean show(String fromType) {
        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            return false;
        }
        if (TRDiskSpaceLimitExecutor.STATUS) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL,"Recommend install will not show,because disk space limit activity is showing");
            return false;
        }

        boolean hasEwCache = HisavanaSdkManager.getInstance().hasSceneCache(SceneCode.NR_X);
        // readyShowFixedScene方法是异步执行，需要确定返回值后才能判断是否展示了推荐页面
        CountDownLatch latch = new CountDownLatch(1);
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL_EW, "show: hasEwCache :" + hasEwCache);
        if (hasEwCache) {
            positionID = HisavanaSdkManager.getInstance().getEwScenePositionID(SceneCode.NR_X);
            HisavanaSdkManager.getInstance().readyShowFixedScene(SceneCode.NR_X, new RecomInstallAdListener(fromType) {
                @Override
                public void onAdCache(List<TaNativeInfo> adInfos) {
                    int count = adInfos!=null?adInfos.size():0;
                    TRAnalysticsUtil.trackEwRspRecord(positionID, SceneCode.NR_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_RSP_SUCCESS,count, 0, false);
                    HisavanaSdkManager.getInstance().onTrackEWSDKResponse(adInfos, positionID, SceneCode.NR_X,true, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1, false);

                    if(adInfos!=null && adInfos.size()>0) {
                        for(TaNativeInfo item:adInfos) {
                            LogUtils.e(LogUtils.TAG_TR_RECOMMEND_INSTALL_EW,item.getAppInfo()+" count="+adInfos.size());
                        }
                    }

                    List<FeatureItemData> featureItemDataList = HisavanaSdkManager.getInstance().filterInstalledApp(adInfos,SceneCode.NR_X);
                    HisavanaSdkManager.getInstance().fillAppIndexInfo(featureItemDataList,SceneCode.NR_X);
                    if(featureItemDataList!=null && featureItemDataList.size()>0) {
                        //todo 场景show 插入数据
                        int size = featureItemDataList.size();
                        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Ew app size in recommend = "+size);
                        insertEwDataToList(featureItemDataList);

                        List<TaNativeInfo> trackInfos = new ArrayList<>();
                        for(FeatureItemData itemData:featureItemDataList) {
                            if(itemData!=null && itemData.tNativeInfo!=null) {
                                trackInfos.add(itemData.tNativeInfo);
                            }
                        }
                        TrackingUtil.trackShows(trackInfos,SceneCode.NR_X);
                    }

                    launchActivity(fromType, featureItemDataList != null && featureItemDataList.size() > 0, latch);
                }

                @Override
                public void onError(TaErrorCode adError) {
                    super.onError(adError);
                    LogUtils.e(LogUtils.TAG_TR_RECOMMEND_INSTALL_EW, "NR get CacheError " + adError.getErrorMessage());
                    int errorCode = -1;
                    if(adError!=null) {
                        errorCode = adError.getErrorCode();
                    }
                    TRAnalysticsUtil.trackEWSdkErrorRsp(positionID, SceneCode.NR_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_ERROR, adError.getErrorMessage(),errorCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
                    launchActivity(fromType, false, latch);
                }

                @Override
                public void onTimeOut() {
                    LogUtils.e(LogUtils.TAG_TR_RECOMMEND_INSTALL_EW, "NR get Data onTimeOut");
                    TRAnalysticsUtil.trackEWSDKResponse(positionID, SceneCode.NR_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_TIME_OUT, "");
                    launchActivity(fromType, false, latch);
                }
            });
        } else {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Prepare to launcher activity.");
            launchActivity(fromType, false, latch);
        }

        try {
            boolean ret = latch.await(SDK_LOAD_CACHE_TIMEOUT, TimeUnit.MILLISECONDS);
            if (!ret) {
                LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "NR get Data timeout");
            }
        } catch (InterruptedException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return showResult;
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }

    static class RecomInstallAdListener extends AdListener {
        String fromType;

        RecomInstallAdListener(String fromType) {
            this.fromType = fromType;
        }
    }

    private void insertEwDataToList(List<FeatureItemData> featureItemDataList) {
        // load ew ad and insert to list
        try {
            if (featureItemDataList != null && featureItemDataList.size() > 0) {
                Iterator<FeatureItemData> iterator = featureItemDataList.iterator();
                List<AppInfo> oldList = RecommendInstallCache.getInstance().getOldList();
                List<RecommendBean.NewStyle.CategoryList> categoryLists = RecommendInstallCache.getInstance().getCategoryList();
                int recommendStyle = RecommendInstallCache.getInstance().recommendStyle;
                while(iterator.hasNext()) {
                    FeatureItemData featureItemData = iterator.next();
                    boolean isAdValid = false;
                    if (featureItemData != null && featureItemData.tNativeInfo != null) {
                        isAdValid = featureItemData.tNativeInfo.isAdValid();
                    }
                    if (isAdValid) {
                        AppInfo info = FeatureItemData.convertToAppInfo(featureItemData);
                        info.reportSource = HisavanaSdkManager.REPORT_SOURCE_EW;
                        info.nativeId = featureItemData.tNativeInfo.getNativeAdId();
                        info.adPositionId = featureItemData.tNativeInfo.getPlacementId();
                        int fixedColumn = featureItemData.tNativeInfo.getTopicColumn();

                        TRAnalysticsUtil.trackAddShowQueue(positionID, SceneCode.NR_X, TRACK_LOAD_ADS_ADD_QUEUE,
                                featureItemData.packageName, featureItemData.tNativeInfo.getTopicRow(), featureItemData.tNativeInfo.getTopicColumn());
                        //根据新旧数据格式，插入不同的逻辑
                        if(recommendStyle == RecommendInstallCache.TYPE_OLD || recommendStyle == RecommendInstallCache.TYPE_OLD_2 ){
                            RecommendInstallCache.getInstance().addAdForRecommendListOld(oldList, info, featureItemData.tNativeInfo.getTopicRow(), fixedColumn);
                        }else{
                            RecommendInstallCache.getInstance().addAdForRecommendList(categoryLists, info, featureItemData.tNativeInfo.getTopicRow(), fixedColumn);
                        }
                    } else {
                        TRAnalysticsUtil.trackEwFilterInfo(SceneCode.NR_X, TRAnalyticsConstant.ERROR_MSG_TIME_EXPIRE);
                        iterator.remove();
                    }
                }
                //遍历结束，插入EW数据
                RecommendInstallCache.getInstance().updateEwData();
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }


    public void launchActivity(String fromType, boolean isEwCache, @NonNull CountDownLatch latch) {

        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL,"Recommend install will not show,because hasDialogShowing");
            showResult = false;
            latch.countDown();
            return;
        }
        if (TRDiskSpaceLimitExecutor.STATUS) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL,"Recommend install will not show,because disk space limit activity is showing");
            showResult = false;
            latch.countDown();
            return;
        }

        Intent intent = new Intent();
        try {
            int recommendStyle = RecommendInstallCache.getInstance().getRecommendStyle();
            List<AppInfo> oldList = RecommendInstallCache.getInstance().getOldList();
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Launch recommend activity, style = "+recommendStyle);
            if (recommendStyle == RecommendInstallCache.TYPE_NEW) {
                if (!isEwCache) {
                    //新样式个性化分类插入dsp,联运，offer应用
                    List<RecommendBean.NewStyle.CategoryList> list = RecommendInstallCache.getInstance().getCategoryList();
                    if (list != null) {
                        for (RecommendBean.NewStyle.CategoryList categoryList : list) {
                            int type = categoryList.type;
                            List<AppInfo> itemList = categoryList.itemList;
                            CopyOnWriteArrayList<AppInfo> offerAndCpAndDspItemList = categoryList.offerAndCpAndDspItemList;
                            if (itemList != null) {
                                if (offerAndCpAndDspItemList != null && offerAndCpAndDspItemList.size() > 0) {
                                    //综合分类，插入ew、dsp、联运、offer
                                    if (type == 2) {
                                        itemList.addAll(0, offerAndCpAndDspItemList);
                                    } else if (type == 1) {  //个性化分类只插入dsp、联运、offer
                                        if (offerAndCpAndDspItemList.size() > 2) {
                                            List<AppInfo> appInfos = offerAndCpAndDspItemList.subList(0, 2);
                                            itemList.addAll(0, appInfos);
                                        } else {
                                            itemList.addAll(0, offerAndCpAndDspItemList);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //新的数据类型再这里进行过滤
                LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Filter recommend data.");
                List<RecommendBean.NewStyle.CategoryList> categoryLists = filterData();
                LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Filter recommend data complete.");
                if (categoryLists != null && categoryLists.size() > 0) {
                    intent.setClass(PalmplayApplication.getAppInstance(), TRRecommendNewActivity.class);
                } else {
                    showResult = false;
                    latch.countDown();
                    return;
                }
            } else if (recommendStyle != RecommendInstallCache.TYPE_NEW && oldList !=null && !oldList.isEmpty()){
                intent.setClass(PalmplayApplication.getAppInstance(), TRRecommondActivity.class);
            } else {
                showResult = false;
                latch.countDown();
                return;
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("fromType", fromType);
            intent.putExtra("recommendStyle", recommendStyle);
            RecommendInstallCache.getInstance().launcherActivity(true);
            PalmplayApplication.getAppInstance().startActivity(intent);
            showResult = true;
            latch.countDown();
        } catch (Exception e) {
            showResult = false;
            latch.countDown();
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    //过滤新界面的数据
    private List<RecommendBean.NewStyle.CategoryList> filterData() {
        try {
            List<RecommendBean.NewStyle.CategoryList> categoryLists = RecommendInstallCache.getInstance().getCategoryList();
            if(categoryLists!=null && categoryLists.size()>0){
                RecommendInstallCache.getInstance().getSelectedData().clear();

                //遍历并移除所有已安装的应用
                Iterator<RecommendBean.NewStyle.CategoryList> iterator = categoryLists.iterator();
                while (iterator.hasNext()) {
                    RecommendBean.NewStyle.CategoryList categoryList = iterator.next();
                    if (categoryList != null && categoryList.itemList != null) {
                        CopyOnWriteArrayList<AppInfo> list = categoryList.itemList;
                        Iterator<AppInfo> itemList = list.iterator();
                        while (itemList.hasNext()) {
                            AppInfo appInfo = itemList.next();
                            if (appInfo != null && !TextUtils.isEmpty(appInfo.packageName)) {
                                if (InstalledAppManager.isInstalledSpecialApp(appInfo.packageName)) {
                                    //CopyOnWriteArrayList支持remove，如果使用迭代器删除会有问题。
                                    list.remove(appInfo);
                                }
                            }
                        }
                    }
                }

                //限制个数(移除超出的部分)
                for (RecommendBean.NewStyle.CategoryList categoryList : categoryLists) {
                    int showCount = categoryList.showCount;
                    List<AppInfo> itemList = categoryList.itemList;
                    if (itemList != null) {
                        //计算超出要显示的数量
                        int exceededCount = itemList.size() - showCount;
                        if (exceededCount > 0) {
                            //删除超出的部分
                            itemList.subList(itemList.size() - exceededCount, itemList.size()).clear();
                        }
                    }
                }

                //标记要选中的部分
                for (RecommendBean.NewStyle.CategoryList categoryList : categoryLists) {
                    List<AppInfo> itemList = categoryList.itemList;
                    List<Integer> itemSelectedList = categoryList.itemSelectedList;
                    if (itemList != null) {
                        for (int i = 0; i < itemList.size(); i++) {
                            AppInfo appInfo = itemList.get(i);
                            if (HisavanaSdkManager.REPORT_SOURCE_EW.equals(appInfo.reportSource) || itemSelectedList.contains(i)) {
                                RecommendInstallCache.getInstance().pullSelectedData(appInfo, true);
                                appInfo.isSelect = "T";
                            } else {
                                RecommendInstallCache.getInstance().pullSelectedData(appInfo, false);
                                appInfo.isSelect = "F";
                            }
                        }
                    }
                }
            }
            return categoryLists;
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
            return RecommendInstallCache.getInstance().getCategoryList();
        }
    }

    public static  boolean getMustInstallExclude() {
        return mustInstallExclude;
    }

    public static void setMustInstallExclude() {
        mustInstallExclude = true;
        enterActivityTimes.set(0);
        LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "mustInstallExclude: " + mustInstallExclude+ " enterActivityTimes:" +enterActivityTimes);
    }

    public static void unsetMustInstallExclude() {
        if (enterActivityTimes.get() >= 1) {
            mustInstallExclude = false;
        } else {
            enterActivityTimes.getAndIncrement();
        }
        LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "mustInstallExclude: " + mustInstallExclude+ " enterActivityTimes:" +enterActivityTimes);
    }


}

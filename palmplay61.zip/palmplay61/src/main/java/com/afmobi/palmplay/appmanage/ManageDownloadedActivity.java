package com.afmobi.palmplay.appmanage;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseFragmentActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.NotificationUtil;
import com.didi.drouter.annotation.Router;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

/**
 * 管理已安装的应用页面（APP&GAME）
 * Created by hxy on 2016-12-06.
 */
@Router(path = "/page/manageDownloaded")
public class ManageDownloadedActivity extends BaseFragmentActivity {

    private final int ATIVITY_REQUESTCODE_PERMISSIONS = 11;

    private static final String TAG = "ManageDownloaded";
    private FragmentAdapter adapter;
    private final ArrayList<UnInstallAppsFragment> mFragmentList = new ArrayList<>();
    private AppsGamesFragment mAppsGamesFragment;
    private InstantGamesFragment mInstantGamesFragment;
    private ViewPager2 mViewPager;
    private final String KEY_FRAGMENT_MGR_APP_GAMES = "KEY_FRAGMENT_MGR_APP_GAMES";
    private final String KEY_FRAGMENT_MGR_INSTANT_GAMES = "KEY_FRAGMENT_MGR_INSTANT_GAMES";

    private TabLayout mTabLayout;
    private int mCurrentSelectPosition = 0;
    private Typeface typefaceSelected = null;
    private Typeface typefaceNormal = null;

    private String mFromPage = "None";

    private String value;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uninstall_apps);

        PageParamInfo pageParamInfo = PageConstants.getPageParamInfo(getIntent());
        if(pageParamInfo !=null) {
            mFromPage = pageParamInfo.getLastPage();
        }
        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.My_Download_Soft_Uninstall);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

        value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, "", "", "");
        findViews();

        if(isFromNotify){
            NotificationUtil.cancelNotification(this, NotificationExtKt.getNOTIFY_ID_INSTALL_APP_LIST());
            PalmplayApplication.getPalmplayApplicationInstance().appInit();
            init();
        } else {
            NotificationUtil.removeMetaDataParentActivity(this);
            init();
        }

        initTabs(savedInstanceState);


    }

    @Override
    public String getValue() {
        return value;
    }


    public class FragmentAdapter extends FragmentStateAdapter {
        public FragmentAdapter(@NonNull FragmentActivity frg) {
            super(frg.getSupportFragmentManager(), frg.getLifecycle());
        }

        @NonNull
        @Override
        public UnInstallAppsFragment createFragment(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getItemCount() {
            return mFragmentList.size();
        }
    }

    public interface TextCountListener {
        void updateCount(int count);

        void showToast();
    }


    private boolean checkOnBackPressed() {
        if (isFromNotify) {
            if (!AtyManager.getAtyManager().isExistsOtherActivity(ManageDownloadedActivity.class)) {
                startActivity(new Intent(this, MainActivity.class).putExtra(FromPageType.Notify, false));
            }
            finish();
            return true;
        }
        return false;
    }

    // 埋点:两个tab的曝光
    private void reportTabExposure() {
        if (mCurrentSelectPosition == 0) {
            PagePvBuilder pagePvBuilder = new PagePvBuilder();
            String value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_APPS_GAMES, "", "");
            // 过往埋点，保持不变(AM_X_X_X)
            String from = TRStringUtil.generateString(TRAnalyticsConstant.APP_MANAGEMENT, "", "", "");
            pagePvBuilder.setValue(value).setFrom(from);
            TRAnalysticsUtil.trackPV(pagePvBuilder);
        } else if (mCurrentSelectPosition == 1) {
            PagePvBuilder pagePvBuilder = new PagePvBuilder();
            String value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_INSTANT_GAMES, "", "");
            // 935新增instantTab，需求定义(MA_X_X_X)
            String from = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, "", "", "");
            pagePvBuilder.setValue(value).setFrom(from);
            TRAnalysticsUtil.trackPV(pagePvBuilder);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (checkOnBackPressed()) {
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == ATIVITY_REQUESTCODE_PERMISSIONS){
            init();
        }
    }

    private void init(){
        //initOnClickTitleBack();
        findViewById(R.id.iv_back).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        if(!checkOnBackPressed()){
                            finish();
                        }
                    }
                });

    }

    private void findViews() {
        mViewPager = findViewById(R.id.pager);
        mTabLayout = findViewById(R.id.tab);
    }

    private void initTabs(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            FragmentManager fm = getSupportFragmentManager();
            mAppsGamesFragment = (AppsGamesFragment) fm.getFragment(savedInstanceState, KEY_FRAGMENT_MGR_APP_GAMES);
            mInstantGamesFragment = (InstantGamesFragment) fm.getFragment(savedInstanceState, KEY_FRAGMENT_MGR_INSTANT_GAMES);
            if (mAppsGamesFragment == null) {
                mAppsGamesFragment = new AppsGamesFragment();
            }
            if (mInstantGamesFragment == null) {
                mInstantGamesFragment = new InstantGamesFragment();
            }
        } else {
            mAppsGamesFragment = new AppsGamesFragment();
            mInstantGamesFragment = new InstantGamesFragment();
        }

        mFragmentList.add(mAppsGamesFragment);
        mFragmentList.add(mInstantGamesFragment);


        String[] mTabTitles = new String[]{
                getString(R.string.text_app_game_blank),
                getString(R.string.instant_game_page_title),
        };

        mViewPager.setOffscreenPageLimit(mTabTitles.length);
        adapter = new FragmentAdapter(this);
        mViewPager.setAdapter(adapter);
        new TabLayoutMediator(mTabLayout, mViewPager, (tab, position) -> {
            try {
                tab.setText(mTabTitles[position]);
                TabLayout.TabView tabView = tab.view;
                int count = tabView.getChildCount();
                for (int i = 0; i < count; i++) {
                    View view = tabView.getChildAt(i);
                    if (!(view instanceof TextView)) {
                        continue;
                    }
                    AppCompatTextView textView = (AppCompatTextView) view;
                    try {
                        textView.setSingleLine();
                        textView.setEllipsize(TextUtils.TruncateAt.END);
                        textView.setTypeface(Typeface.create(position == 0 ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
                    } catch (Exception e) {
                        LogUtils.e(TAG, "onCreate: setTypeface err " + e.getMessage());
                    }
                }
            } catch (Exception e) {
                LogUtils.e(TAG, "onCreate: tabLayout setText err " + e.getMessage());
            }

        }).attach();

        TabLayout.OnTabSelectedListener listener = new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                try {
                    TextView tv = (TextView) tab.view.getChildAt(1);
                    if (null == typefaceSelected) {
                        typefaceSelected = Typeface.create("sans-serif-medium", Typeface.NORMAL);
                    }
                    tv.setTypeface(typefaceSelected);
                } catch (Exception e) {
                    LogUtils.e(TAG, "onTabUnselected setTypeface: err " + e.getMessage());
                }

                mCurrentSelectPosition = tab.getPosition();
                LogUtils.e(TAG, "onTabSelected  mCurrentSelectPosition = " + mCurrentSelectPosition);
                reportTabExposure();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                try {
                    TextView tv = (TextView) tab.view.getChildAt(1);
                    if (null == typefaceNormal) {
                        typefaceNormal = Typeface.create("sans-serif", Typeface.NORMAL);
                    }
                    tv.setTypeface(typefaceNormal);
                } catch (Exception e) {
                    LogUtils.e(TAG, "onTabUnselected setTypeface: err " + e.getMessage());
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        };
        mTabLayout.addOnTabSelectedListener(listener);
        listener.onTabSelected(mTabLayout.getTabAt(0));
    }

    @Override
    public void finish() {
        super.finish();
        // 埋点:退出(过往功能)
        String from = TRStringUtil.generateString(TRAnalyticsConstant.APP_MANAGEMENT, "", "",  "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(from)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType("BackBt")
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

}

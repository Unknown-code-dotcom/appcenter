package com.afmobi.palmplay.category;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.customview.DownloadingAnimView;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.main.adapter.v6_3.CommonSoftRecyclerAdapter;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommonInfo;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.TagItemList;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import xyz.doikki.videoplayer.util.PlayerUtils;

/**
 * App、GAME下的new页面的查看更多
 */
public class SoftNewMoreActivity extends BaseEventFragmentActivity implements View.OnClickListener, OnViewLocationInScreen {
    public static final String REQUEST_SOFT_NEW_MORE_LIST = "request_soft_new_more_list";
    public static final String SORT_TYPE_THREE_DAY = "3DAY";
    public static final String SORT_TYPE_SEVEN_DAY = "7DAY";
    public static final String SORT_TYPE_FURTHER = "FURTHER";

    private TextView tv_title, tv_download_count;
    private ImageView iv_back, iv_download, iv_search;
    private View layout_download, layout_empty_view_root;
    private DownloadingAnimView downloadingAnimView;

    private UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();
    private UINetworkErrorUtil mUINetworkErrorUtil = UINetworkErrorUtil.create();

    private boolean isRequesting = false;
    /**
     * 分页请求的页面下标
     */
    private int currentPageIndex = 0;

    private XRecyclerView mXRecyclerView;
    private boolean isOnRefreshing;

    private boolean isFirstActivity = true;

    private CommonSoftRecyclerAdapter mCommonSoftRecyclerAdapter;
    private List<CommonInfo> mAppList;
    private List<CommonInfo> mOrgAppList;
    private String categoryId, sortType, titleDesc;
    private long newTagCount;
    private String mFrom;
    private String value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soft_new_more);
        Intent intent = getIntent();
        categoryId = intent.getStringExtra("categoryId");
        sortType = intent.getStringExtra("sortType");
        titleDesc = intent.getStringExtra("titleDesc");
        newTagCount = intent.getLongExtra("newTagCount", 0);
        mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE);
        if (TextUtils.isEmpty(categoryId) || TextUtils.isEmpty(sortType)) {
            finish();
            return;
        }
        mPageParamInfo.setLastPage(intent.getStringExtra(PageParamInfo.class.getSimpleName()));
        if (DetailType.getTypeName(DetailType.TYPE_APP).equalsIgnoreCase(categoryId)) {
            if (SORT_TYPE_THREE_DAY.equalsIgnoreCase(sortType)) {
                mPageParamInfo.setCurPage(PageConstants.App_New_1);
            } else if (SORT_TYPE_SEVEN_DAY.equalsIgnoreCase(sortType)) {
                mPageParamInfo.setCurPage(PageConstants.App_New_2);
            } else if (SORT_TYPE_FURTHER.equalsIgnoreCase(sortType)) {
                mPageParamInfo.setCurPage(PageConstants.App_New_3);
            }
        } else if (DetailType.getTypeName(DetailType.TYPE_GAME).equalsIgnoreCase(categoryId)) {
            if (SORT_TYPE_THREE_DAY.equalsIgnoreCase(sortType)) {
                mPageParamInfo.setCurPage(PageConstants.Game_New_1);
            } else if (SORT_TYPE_SEVEN_DAY.equalsIgnoreCase(sortType)) {
                mPageParamInfo.setCurPage(PageConstants.Game_New_2);
            } else if (SORT_TYPE_FURTHER.equalsIgnoreCase(sortType)) {
                mPageParamInfo.setCurPage(PageConstants.Game_New_3);
            }
        }

        initViews();
        setEmptyViewCenter();
        init();
    }

    /**
     * 空态页居中显示
     */
    private void setEmptyViewCenter() {
        int height = DisplayUtil.getScreenHeight(this);
        int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.empty_view_height);
        int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
        int halfMarginTop = (height - emptyLayoutHeight) / 2;
        int statusBarHeight = (int) PlayerUtils.getStatusBarHeight(this);
        int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight;
        if (finalMarginTop <= 0) {
            finalMarginTop = 0;
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) layout_empty_view_root.getLayoutParams();
        params.topMargin = finalMarginTop;
        layout_empty_view_root.setLayoutParams(params);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isRequesting) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }
        setUpdatedAppCount();
    }


    private void initViews() {
        iv_back = findViewById(R.id.layot_detail_back);
        tv_title = findViewById(R.id.layot_detail_title);
        layout_download = findViewById(R.id.layot_detail_download);
        iv_download = findViewById(R.id.iv_download);
        tv_download_count = findViewById(R.id.tv_downloading_count);
        layout_download.setOnClickListener(this);
        downloadingAnimView = findViewById(R.id.downloadingAnimView);

        iv_back.setOnClickListener(this);
        iv_search = findViewById(R.id.layout_title_right_search);
        iv_search.setOnClickListener(this);

        layout_empty_view_root = findViewById(R.id.layout_empty_view_root);
        TextView tv_content = layout_empty_view_root.findViewById(R.id.tv_content);
        tv_content.setText(R.string.no_related_resource);

        LinearLayout rootView = findViewById(R.id.cl_view);
        mUILoadingGifUtil.inflate(this, rootView);
        mUINetworkErrorUtil.inflate(this, rootView, true)
                .setFrom(mFrom)
                .setVisibility(View.GONE)
                .setNetworkConfigureVisibility(View.GONE)
                .setUINetworkErrorOnClickListener(new UINetworkErrorUtil.UINetworkErrorOnClickListener() {

                    @Override
                    public void onUINetworkErrorClick(View v) {
                        if (v == null)
                            return;
                        if (v.getId() == R.id.tv_setting) {
                            SysUtils.openSystemMobileNetworkSettings(SoftNewMoreActivity.this, TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
                        } else if (v.getId() == R.id.tv_retry) {
                            if (CommonUtils.isInstantAvailable()) {
                                TRJumpUtil.jumpInstantTab(SoftNewMoreActivity.this);
                            } else {
                                mUINetworkErrorUtil.setVisibility(View.GONE);
                                mUILoadingGifUtil.setVisibility(View.VISIBLE);
                                request();
                            }
                        }
                    }
                });

        mXRecyclerView = (XRecyclerView) findViewById(R.id.xrecyclerview);
        TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mXRecyclerView.setLayoutManager(linearLayoutManager);
        mXRecyclerView.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
        mXRecyclerView.setLoadingListener(mXRecyclerViewLoadingListener);
        mXRecyclerView.setPullRefreshEnabled(false);

        mXRecyclerView.isHeaderRefreshLayoutLimitHeight(true);

        //addNoMore(mXRecyclerView, linearLayoutManager, null);

        if (!isRequesting) {
            mXRecyclerView.setEmptyView(layout_empty_view_root);
        }


        //TP_x_x_x
        value = TRStringUtil.generateString(TRAnalyticsConstant.MORE_PAGE, "", "", "");
        mCommonSoftRecyclerAdapter = new CommonSoftRecyclerAdapter(this, mXRecyclerView, mPageParamInfo.getCurPage(), mPageParamInfo);
//        mCommonSoftRecyclerAdapter.setItemBgResId(android.R.color.transparent, false);
        mXRecyclerView.setAdapter(mCommonSoftRecyclerAdapter);
        mCommonSoftRecyclerAdapter.setOnViewLocationInScreen(this);
        mCommonSoftRecyclerAdapter.onCreateView();
        mCommonSoftRecyclerAdapter.setIMessenger(new IMessenger() {

            @Override
            public void onMessenger(Object... objects) {
                setUpdatedAppCount();
            }
        });
        mCommonSoftRecyclerAdapter.setScreenPageName(TRAnalyticsConstant.MORE_PAGE);
        mCommonSoftRecyclerAdapter.setFrom(mFrom);

        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(value)
                .setFrom(mFrom);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private void init() {
        request();
        iv_back.setImageResource(R.drawable.selector_title_img_back);
        iv_download.setImageResource(R.drawable.home_title_download_icon_selector);
        iv_search.setImageResource(R.drawable.home_title_search_icon_selector);
        TRStatusBarUtil.setStatusBarTextColor(getWindow(), true);
        mUILoadingGifUtil.setVisibility(isRequesting ? View.VISIBLE : View.GONE);
    }

    private XRecyclerView.LoadingListener mXRecyclerViewLoadingListener = new XRecyclerView.LoadingListener() {
        @Override
        public void onRefresh() {
            if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
                if (mXRecyclerView != null) {
                    mXRecyclerView.refreshComplete();
                }
                return;
            }
            isOnRefreshing = true;
            currentPageIndex = 0;
            request();
        }

        @Override
        public void onLoadMore() {
            currentPageIndex += 1;
            request();
        }
    };

    private void request() {
        isRequesting = true;
        NetworkClient.softNewTypeListHttpRequest(categoryId, sortType, REQUEST_SOFT_NEW_MORE_LIST, currentPageIndex, mPageParamInfo);

        if (mXRecyclerView != null) {
            mXRecyclerView.setEmptyView(null);
        }
        if (layout_empty_view_root != null) {
            layout_empty_view_root.setVisibility(View.GONE);
        }
    }

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        super.onEventMainThread(mEventMainThreadEntity);
        if (mEventMainThreadEntity.getAction().equals(REQUEST_SOFT_NEW_MORE_LIST)) {
            isRequesting = false;
            if (isOnRefreshing) {
                mXRecyclerView.refreshComplete();
            } else {
                mXRecyclerView.loadMoreComplete();
            }
            isOnRefreshing = false;
            mUILoadingGifUtil.setVisibility(View.GONE);

            if (mEventMainThreadEntity.isSuccess) {
                TagItemList<AppInfo> data = (TagItemList<AppInfo>) mEventMainThreadEntity.get("mData");

                if (data != null && data.itemList != null && data.itemList.size() > 0) {
                    if (data.pageIndex + 1 == data.pageSum) {
                        mXRecyclerView.setNoMore(true);
                    } else {
                        mXRecyclerView.loadMoreComplete();
                    }
                    if (sortType.equalsIgnoreCase(SORT_TYPE_THREE_DAY) && data.pageIndex == 0) {
                        for (int i = 0; i < (data.itemList.size() > newTagCount ? newTagCount : data.itemList.size()); i++) {
                            data.itemList.get(i).isNew = true;
                        }
                    }
                    refreshData(data);
                    setHeaderView(data);
                }

                mXRecyclerView.setEmptyView(layout_empty_view_root);
            } else {
                //当没有数据时才显示无网络界面
                if (mCommonSoftRecyclerAdapter != null && mCommonSoftRecyclerAdapter.getItemCount() <= 0) {
                    mUINetworkErrorUtil.setVisibility(View.VISIBLE);
                }
            }
        } else if (mEventMainThreadEntity.getAction().equals(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS)) {
            InstalledAppInfo appInfo = (InstalledAppInfo) mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DATA);
            FileDownloadInfo downloadInfo = (FileDownloadInfo) mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DOWNLOADINFO);
            showInstalledCompleteWindow(this, appInfo, downloadInfo);
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_REFRESH_TAB_RED_POINT)) { //刷新角标
            setUpdatedAppCount();
        }
    }

    private void refreshData(TagItemList<AppInfo> data) {
        if (mAppList == null) {
            mAppList = new ArrayList<>();
        }

        if (mOrgAppList == null) {
            mOrgAppList = new ArrayList<>();
        }

//        AdsUtils.adsCheckOrderInsert(mAppList, mOrgAppList, data.itemList, mAdsLoadListProxy);
//        mAppList.clear();
        mAppList.addAll(data.itemList);
        if (mCommonSoftRecyclerAdapter != null) {
            mCommonSoftRecyclerAdapter.setData(mAppList);
        }
    }

    public void setHeaderView(TagItemList data) {
        try {

            if (!isFirstActivity) {
                return;
            }
            isFirstActivity = false;

            tv_title.setText(titleDesc);
        } catch (Exception e) {
            LogUtils.e(e);
        }
    }


    @Override
    public void onClick(View v) {
        if (v == null)
            return;
        switch (v.getId()) {
            case R.id.layout_title_back:
            case R.id.layot_detail_back:
                finish();
                backButtonTrack();
                break;
            case R.id.layot_detail_download:
                TRJumpUtil.into(this, false, mPageParamInfo,
                        TRStringUtil.generateString(TRAnalyticsConstant.MORE_PAGE, "", "", ""));
                break;
            case R.id.layout_title_right_search:
                TRJumpUtil.switchToSearchActivity(this, TabType.SOFT, "", false, "", false,
                        "", mPageParamInfo, TRStringUtil.generateString(TRAnalyticsConstant.MORE_PAGE, "", "", ""), TRAnalyticsConstant.BUTTON_SEARCH_IMG);
                break;

            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        backButtonTrack();
    }

    private void backButtonTrack() {
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    /****************************
     * for animation start
     *********************************/
    @Override
    public Object onPreparedCallback(Object obj) {
        return obj;
    }

    @Override
    public Object getObject(Object obj) {
        return layout_download;
    }

    @Override
    public int[] onEndTranslateAnimationLocationOnScreen(Object obj) {
        int[] endTranslateAnimationLocationOnScreen = new int[2];
        if (layout_download != null && layout_download.getVisibility() != View.GONE) {
            layout_download.getLocationOnScreen(endTranslateAnimationLocationOnScreen);
            int viewWidth = layout_download.getWidth();
            if (viewWidth > 0)
                endTranslateAnimationLocationOnScreen[0] = endTranslateAnimationLocationOnScreen[0] + viewWidth / 4;// 3;
        }
        return endTranslateAnimationLocationOnScreen;
    }

    @Override
    public Object onAnimationEndCallback(Object obj) {
        return obj;
    }

    /**************************** for animation end *********************************/

    protected void setUpdatedAppCount() {
        TRHomeUtil.refreshAppCount(tv_download_count, downloadingAnimView);
    }

    /*----------------20180724 add by liuzhi 6.8.1 begin----------------*/
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onDestroy();

        if (mXRecyclerView != null) {
            mXRecyclerView.loadMoreComplete();
            mXRecyclerView.refreshComplete();
            mXRecyclerView = null;
        }
        mXRecyclerViewLoadingListener = null;
    }
    /*----------------20180724 add by liuzhi 6.8.1 end----------------*/

    @Override
    public String getValue() {
        return value;
    }
}


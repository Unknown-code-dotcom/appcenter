package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.v6_0.StartUpTabsCache;
import com.afmobi.palmplay.configs.v6_3.FeaturedType;
import com.afmobi.palmplay.model.FeatureTabInfo;
import com.afmobi.palmplay.model.NavTabBuilder;
import com.afmobi.palmplay.model.NavTabInfo;
import com.afmobi.palmplay.model.v7_x.ActivityInfo;
import com.afmobi.palmplay.model.v7_x.NavigationAd;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.callback.TRImageDownloadListener;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.xwebview.preload.PreLoadConstants;
import com.transsion.xwebview.preload.UrlPreLoadProcessor;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class NavTabManager {

    public static final String SP_CACHE_NAVTABLIST = "sp_cache_navtablist";

    private static volatile NavTabManager mNavTab;

    /**
     * HOME/APP/GAME页的子tab信息
     * */
    public Map<String, List<FeatureTabInfo>> mFeatureTabMap = new HashMap<>();

    /**
     * 存放nav埋点 key
     */
    public Map<String,String> mNavPageMap = new HashMap<>();


    //保存app、game hot、new  rankID
    public Map<String, String> mHotNewTabMap;

    public List<NavTabInfo> mNavTabList;

    public ActivityInfo mActivityInfo;

    private NavTabManager() {
    }


    public static NavTabManager getInstance() {
        if (mNavTab == null) {
            synchronized (NavTabManager.class) {
                if (mNavTab == null) {
                    mNavTab = new NavTabManager();
                }
            }
        }
        return mNavTab;
    }


    /**
     * 获取HOME/APP/GAME/页的子tab信息
     * @param key   {@link com.afmobi.palmplay.configs.v6_3.FeaturedType#HOME},     -> "1"
     *              {@link com.afmobi.palmplay.configs.v6_3.FeaturedType#APP},      -> "2"
     *              {@link com.afmobi.palmplay.configs.v6_3.FeaturedType#GAME}      -> "3"
     *
     * @return {@link List<FeatureTabInfo>}
     * */
    public List<FeatureTabInfo> getFeatureTabByKey(String key) {
        String realKey = CommonUtils.getTabRealKey(key);
        if(TextUtils.isEmpty(realKey)) {
            return null;
        }

        if(mFeatureTabMap == null || mFeatureTabMap.isEmpty()) {
            return null;
        }

        List<FeatureTabInfo> srcList = mFeatureTabMap.get(realKey);
        if(srcList != null && srcList.size() > 0) {
            List<FeatureTabInfo> list = new ArrayList<>();

            Iterator<FeatureTabInfo> iterator = srcList.iterator();
            while (iterator.hasNext()) {
                FeatureTabInfo item = iterator.next();

                if(TRApplicationContextUtil.isProject() && item.isH5Style()) {
                    continue;
                }
                if (Constant.TAB_TYPE_FIND.equals(item.getTabType())) {
                    continue;
                }
                if(item.isValidate()) {
                    list.add(item);
                }
            }

            return list;
        }

        return null;
    }

    /**
     * 解析featureTypes 数据
     */
    public void saveNavAndTabData(List<NavTabInfo> navTabList) {
        try {
            if (navTabList != null && navTabList.size() > 1) {
                int preloadAllCount =getAllCount(navTabList) ;// 预加载图片的总数
                final int[] successCount = {0}; // 预加载成功的图片数量
                for (NavTabInfo item : navTabList) {
                    if (NavTabInfo.TPY_ACTIVITY.equals(item.navType)) {
                        ActivityInfo activityInfo = getActivityInfo(item);
                        //url预加载
                        UrlPreLoadProcessor.handlePreLoadLogicWithThread(PreLoadConstants.TAB, activityInfo.jumpType, activityInfo.jumpUrl,
                                ConfigManager.isPreLoadOn(), StartUpTabsCache.getInstance().inInUrlWhiteList(activityInfo.jumpUrl));
                        preLoadImageAndSaveJson(activityInfo.activityIconUrl,successCount,preloadAllCount,navTabList,null);
                        preLoadImageAndSaveJson(activityInfo.iconUrlNew,successCount,preloadAllCount,navTabList,null);
                    } else {
                        preLoadImageAndSaveJson(item.iconCheck,successCount,preloadAllCount,navTabList,null);
                        preLoadImageAndSaveJson(item.iconUncheck,successCount,preloadAllCount,navTabList,null);
                        preLoadImageAndSaveJson(item.blackIconCheck,successCount,preloadAllCount,navTabList,null);
                        preLoadImageAndSaveJson(item.blackIconUncheck,successCount,preloadAllCount,navTabList,null);
                    }
                }
                saveNavAndTabJson(navTabList);
                preloadTabImages(navTabList);
            } else {
                if(mActivityInfo!=null) {
                    //url预加载
                    UrlPreLoadProcessor.handlePreLoadLogicWithThread(PreLoadConstants.TAB, mActivityInfo.jumpType, mActivityInfo.jumpUrl,
                            ConfigManager.isPreLoadOn(), StartUpTabsCache.getInstance().inInUrlWhiteList(mActivityInfo.jumpUrl));
                    preLoadImageAndSaveJson(mActivityInfo.activityIconUrl,null,0,navTabList,null);
                    preLoadImageAndSaveJson(mActivityInfo.iconUrlNew,null,0,navTabList,null);
                }
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    /**
     * 预加载Tab配置的图片(若有)
     *
     * @param navTabList
     */
    private void preloadTabImages(List<NavTabInfo> navTabList) {
        if (navTabList != null) {
            for (NavTabInfo navTabInfo : navTabList) {
                if (navTabInfo != null) {
                    List<FeatureTabInfo> tabs = navTabInfo.tabs;
                    if (tabs != null) {
                        for (FeatureTabInfo tab : tabs) {
                            if (tab != null) {
                                String selectUrl = tab.getSelectUrl();
                                String unSelectUrl = tab.getUnSelectUrl();
                                loadImgToCache(selectUrl);
                                loadImgToCache(unSelectUrl);
                            }
                        }
                    }
                }
            }
        }
    }

    private void loadImgToCache(String imgUrl) {
        if (TextUtils.isEmpty(imgUrl)) {
            return;
        }
        if (!TRBitmapManager.isImageCachedWithSmallCache(imgUrl)) {
            TRBitmapManager.preLoadImageWithSmallCache(imgUrl, null, null);
        }
    }

    /**
     * 预加载图片，所有图片缓存成功保存json
     * @param url
     * @param successCount
     * @param preloadCount
     * @param navTabList
     * @param tRBitmapDownloadListener
     */
    private void preLoadImageAndSaveJson(String url, int successCount[], int preloadCount, List<NavTabInfo> navTabList,
                                         TRImageDownloadListener tRBitmapDownloadListener) {
        if (!TRBitmapManager.isImageCachedWithSmallCache(url)) {
            TRBitmapManager.preLoadImageWithSmallCache(url, null, tRBitmapDownloadListener);
        }
    }


    /**
     * 保存nav、tab json数据到mmkv
     * @param navTabList
     */
    private void saveNavAndTabJson(List<NavTabInfo> navTabList) {
        if (navTabList != null) {
            // 所有图片预加载成功，进行保存JSON操作
            Gson gson = new Gson();
            String navTabJson = gson.toJson(navTabList);
            LogUtils.d(LogUtils.TAG_NAV_TAB,"saveNavAndTabJson:" + navTabJson);
            if(!TextUtils.isEmpty(navTabJson)){
                TRSharedPreferenceUtils.setParam("",SP_CACHE_NAVTABLIST, navTabJson);
            }
        }
    }

    /**
     * 获取动态下发的nav和tab缓存数据
     */
    public List<NavTabInfo> getNavAndTabCacheData() {
        String navTabJson = (String) TRSharedPreferenceUtils.getParam("", SP_CACHE_NAVTABLIST, "");
        LogUtils.d(LogUtils.TAG_NAV_TAB,"getNavAndTabCacheData:" + (!TextUtils.isEmpty(navTabJson) ? navTabJson : "null"));
        if (TextUtils.isEmpty(navTabJson)) {
            return null;
        }
        try {
            Type type = new TypeToken<List<NavTabInfo>>() {}.getType();
            List<NavTabInfo> navTabList = new Gson().fromJson(navTabJson, type);
            if (navTabIsCacheSuccess(navTabList)) {
                mNavTabList = filterInvalidDataAndParseData(navTabList);
//                addFreeDataNav();
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return mNavTabList;
    }


    /**
     * 判断本地数据是否全部缓存成功
     * @param navTabList
     * @return
     */
    public boolean navTabIsCacheSuccess(List<NavTabInfo> navTabList) {
        if (navTabList == null || navTabList.size() <= 0) {
            return false;
        }
        boolean isAllCached = true;
        for (NavTabInfo item : navTabList) {
            if (item.navType.equals(NavTabInfo.TPY_ACTIVITY)) {
                ActivityInfo activityInfo = getActivityInfo(item);
                if (activityInfo != null) {
                    if (!TRBitmapManager.isImageCachedWithSmallCache(activityInfo.activityIconUrl)) {
                        isAllCached = false;
                        preloadTabIcon(activityInfo.activityIconUrl);
                    }
                    if (!TRBitmapManager.isImageCachedWithSmallCache(activityInfo.iconUrlNew)) {
                        isAllCached = false;
                        preloadTabIcon(activityInfo.iconUrlNew);
                    }
                }
            } else {
                if (!TRBitmapManager.isImageCachedWithSmallCache(item.iconCheck)) {
                    isAllCached = false;
                    preloadTabIcon(item.iconCheck);
                }
                if (!TRBitmapManager.isImageCachedWithSmallCache(item.iconUncheck)) {
                    isAllCached = false;
                    preloadTabIcon(item.iconUncheck);
                }
                if (!TRBitmapManager.isImageCachedWithSmallCache(item.blackIconUncheck)) {
                    isAllCached = false;
                    preloadTabIcon(item.blackIconUncheck);
                }
                if (!TRBitmapManager.isImageCachedWithSmallCache(item.blackIconCheck)) {
                    isAllCached = false;
                    preloadTabIcon(item.blackIconCheck);
                }
            }
        }
        LogUtils.d(LogUtils.TAG_NAV_TAB,"navTabIsCacheSuccess:" + isAllCached);
        return isAllCached;
    }

    private void preloadTabIcon(String url) {
        TRBitmapManager.preLoadImageWithSmallCache(url, null, new TRImageDownloadListener() {
            @Override
            public void onSuccess(File file) {
            }

            @Override
            public void onError(Object obj) {
            }
        });
    }
    /**
     * 过滤掉非法数据并且解析合法数据
     * @param navTabList
     * @return
     */
    public List<NavTabInfo> filterInvalidDataAndParseData(List<NavTabInfo> navTabList) {
        mNavPageMap.clear();
        mFeatureTabMap.clear();
        Iterator<NavTabInfo> it = navTabList.iterator();
        while (it.hasNext()) {
            NavTabInfo item = it.next();
            mNavPageMap.put(item.navKey,item.navPoint);
            if (item != null) {
                List<FeatureTabInfo> tabInfoList = item.tabs;
                if (tabInfoList == null || tabInfoList.size() == 0) {
                    if (NavTabInfo.TPY_ACTIVITY.equals(item.navType)) {
                        mActivityInfo = getActivityInfo(item);
                    }
                    if (!NavTabInfo.TPY_ME.equals(item.navType) && !NavTabInfo.TPY_TOOL.equals(item.navType) && !NavTabInfo.TPY_ACTIVITY.equals(item.navType) && !NavTabInfo.TPY_OFFLINE.equals(item.navType)) {
                        it.remove();
                    }
                } else {
                    String realKey = item.navKey;
                    if (NavTabInfo.HOME_KEY.equals(item.navKey)) {
                        realKey = CommonUtils.getTabRealKey(FeaturedType.HOME);
                    }
                    if (NavTabInfo.GAME_KEY.equals(item.navKey)) {
                        realKey = CommonUtils.getTabRealKey(FeaturedType.GAME);
                    }
                    if (NavTabInfo.APP_KEY.equals(item.navKey)) {
                        realKey = CommonUtils.getTabRealKey(FeaturedType.APP);
                    }
                    if (NavTabInfo.INSTANT_KEY.equals(item.navKey)) {
                        realKey = CommonUtils.getTabRealKey(FeaturedType.INSTANT);
                    }
                    mFeatureTabMap.put(realKey, tabInfoList);
                }
            }
        }
        if (navTabList.size() < 2) {
            mFeatureTabMap.clear();
            return null;
        }
        return navTabList;
    }


    /**
     * 预加载图片总数
     * @param navTabList
     * @return
     */
    private int getAllCount(List<NavTabInfo> navTabList) {
        int allCount = 0;
        for (NavTabInfo navTabInfo : navTabList) {
            if (NavTabInfo.TPY_ACTIVITY.equals(navTabInfo.navType)) {
                allCount += 2;
            } else {
                allCount += 4;//正常暗黑模式选中不选中
            }
        }
        return allCount;
    }

    /**
     * 获取活动数据
     * @param item
     * @return  ActivityInfo
     */
    private ActivityInfo getActivityInfo(NavTabInfo item) {
        NavigationAd navigationAd = item.activityInfo;
        List<ActivityInfo> list = null;
        if (navigationAd != null) {
            list = navigationAd.adList;
        }
        ActivityInfo activityInfo = null;
        if (list != null && list.size() > 0) {
            activityInfo = list.get(0);
        }
        return activityInfo;
    }


    /**
     * 保存 HOT榜单数据jumpUrl
     * @param key
     * @param info
     */
    public void putHotNewTabMap(String key, FeatureTabInfo info) {
        if (mHotNewTabMap == null) {
            mHotNewTabMap = new HashMap<>();
        }
        FeatureTabInfo.JumpInfo jumpDto = info.getJumpDto();
        if (jumpDto != null) {
            String jumpUrl = jumpDto.getJumpUrl();
            if (!TextUtils.isEmpty(jumpUrl)) {
                mHotNewTabMap.put(key, jumpUrl);
            }
        }
    }
    /**
     * 获取HOT榜单数据jumpUrl
     * @param key
     */
    public String getHotNewTabMap(String key) {
        if(mHotNewTabMap  == null){
            return null;
        }
        return mHotNewTabMap.get(key);
    }

    /**
     * 获取页面埋点value
     * @param key
     */
    public String getPageValue(String key) {
        if(mNavPageMap  == null || TextUtils.isEmpty(key)){
            return null;
        }
        return mNavPageMap.get(key.toLowerCase());
    }

    public void clearData() {
        if (mNavTabList != null) {
            mNavTabList.clear();
        }
    }



    public void setNavTabBuilder(NavTabBuilder builder) {
        if (builder != null && builder.mNavTabList != null) {
            mFeatureTabMap.clear();
            mFeatureTabMap.putAll(builder.mFeatureTabMap);

            mNavPageMap.clear();
            mNavPageMap.putAll(builder.mNavPageMap);

            mHotNewTabMap = builder.mHotNewTabMap;
            mNavTabList = builder.mNavTabList;
//            addFreeDataNav();
            mActivityInfo = builder.mActivityInfo;
        }
    }
}

package com.afmobi.palmplay.cloudfolder.recently

import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.recently.db.PalmInstalledAppDatabase
import com.afmobi.palmplay.cloudfolder.recently.db.PalmInstalledAppEntity
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.thread.TRThreadPool
import com.transsion.palmstorecore.util.MMKVUtils

object PalmInstalledDBManager {

    private const val TAG = "RecentlyInstalled"
    private const val KEY_LAST_CLEANUP_TS = "ps_installed_db_last_cleanup_ts"

    /** 新表数据保留期50天 */
    private const val DATA_RETENTION_MS = 50L * 24 * 60 * 60 * 1000

    /** 兜底清理最小间隔（每 1 天最多 1 次） */
    private const val CLEANUP_MIN_INTERVAL_MS = 24L * 60 * 60 * 1000

    private val dao by lazy {
        PalmInstalledAppDatabase.getInstance(PalmplayApplication.getAppInstance()).installedAppDao()
    }

    private fun submitIO(task: Runnable) {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(task)
    }

    /**
     * 安装广播写入新表，并上报存入事件（pkg + date + from）。
     */
    @JvmStatic
    fun insertOrUpdateInstalledApp(
        packageName: String?,
        itemId: String?,
        name: String?,
        iconUrl: String?,
        versionCode: Int,
        versionName: String?,
        installedTime: Long,
        isUpdate: Int,
        fromPage: String?
    ) {
        if (packageName.isNullOrEmpty()) return
        submitIO {
            try {
                dao.insertOrUpdate(
                    PalmInstalledAppEntity(
                        packageName = packageName,
                        itemId = itemId,
                        name = name,
                        iconUrl = iconUrl,
                        versionCode = versionCode,
                        versionName = versionName,
                        installedTime = installedTime,
                        isUpdate = isUpdate,
                        fromPage = fromPage
                    )
                )
                if (LogUtils.debug) {
                    LogUtils.i(TAG, "【新表写入】pkg=$packageName name=$name 是否更新安装=$isUpdate 安装时间=$installedTime 来源=$fromPage")
                }
                // 技术埋点·存入：pkg / date / from
                RecentlyInstalledTracker.reportInsert(packageName, fromPage, installedTime)
            } catch (e: Exception) {
                LogUtils.e(TAG, e)
            }
        }
    }

    fun queryRecentInstalledApps(since: Long): List<PalmInstalledAppEntity> {
        return try {
            val list = dao.queryRecentFreshInstalled(since)
            if (LogUtils.debug) {
                LogUtils.v(TAG, "【新表查询】查询50天内未激活的应用：起始时间=$since 命中数=${list.size} 包名列表=${list.map { it.packageName }}")
            }
            list
        } catch (e: Exception) {
            LogUtils.e(TAG, e)
            emptyList()
        }
    }


    /**
     * 删除 + 上报技术埋点·移除（pkg / date / remove_reason）。
     */
    fun deleteByPackageAndReport(packageName: String?, reason: String) {
        if (packageName.isNullOrEmpty()) return
        submitIO {
            try {
                if (dao.queryByPackage(packageName) == null) {
                    if (LogUtils.debug) {
                        LogUtils.d(TAG, "【新表移除·跳过】pkg=$packageName 原因=$reason（表中不存在）")
                    }
                    return@submitIO
                }
                dao.deleteByPackage(packageName)
                if (LogUtils.debug) {
                    LogUtils.i(TAG, "【新表移除】pkg=$packageName 原因=$reason")
                }
                RecentlyInstalledTracker.reportRemove(packageName, reason)
            } catch (e: Exception) {
                LogUtils.e(TAG, e)
            }
        }
    }

    /**
     * 兜底清理：默认 50 天前的记录，节流每天最多 1 次。
     * 逐条查询→上报 reason=over_50_days→删除，便于数仓对账。
     */
    @JvmOverloads
    fun cleanupExpiredIfDue(maxAgeMs: Long = DATA_RETENTION_MS) {
        val now = System.currentTimeMillis()
        val lastTs = MMKVUtils.getNewMMKV().getLong(KEY_LAST_CLEANUP_TS, 0L)
        if (lastTs != 0L && now - lastTs < CLEANUP_MIN_INTERVAL_MS) {
            if (LogUtils.debug) {
                val elapsedH = (now - lastTs) / (60 * 60 * 1000)
                LogUtils.d(TAG, "【新表清理】跳过：距上次清理 ${elapsedH}h 未达 ${CLEANUP_MIN_INTERVAL_MS / (60 * 60 * 1000)}h")
            }
            return
        }
        submitIO {
            try {
                val cutoff = System.currentTimeMillis() - maxAgeMs
                val expired = dao.selectExpired(cutoff)
                if (expired.isNotEmpty()) {
                    for (item in expired) {
                        RecentlyInstalledTracker.reportRemove(
                            pkg = item.packageName,
                            reason = RecentlyInstalledTracker.REASON_OVER_50_DAYS
                        )
                    }
                    dao.deleteExpired(cutoff)
                }
                MMKVUtils.getNewMMKV().putLong(KEY_LAST_CLEANUP_TS, System.currentTimeMillis())
                LogUtils.d(TAG, "【新表清理】完成：删除 ${expired.size} 条安装时间早于 $cutoff 的记录（保留期=${maxAgeMs / (24 * 60 * 60 * 1000)}天）")
            } catch (e: Exception) {
                LogUtils.e(TAG, e)
            }
        }
    }
}

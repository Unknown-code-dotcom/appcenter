package com.afmobi.palmplay.adapter;

import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by zz on 2016/11/16.
 */

public abstract class PalmBaseDownloadRecyclerViewAdapter extends RecyclerView.Adapter {
    /**
     * the construction function init DetailType 、 InterfaceStatusChange 、 InterfaceStatusChangeKey .
     */
    public PalmBaseDownloadRecyclerViewAdapter(){
        mInterfaceStatusChangeKey = loaderInterfaceStatusChangeObjectKey();
        mInterfaceStatusChange = loaderInterfaceStatusChange();
    }

    public void refreshInterfaceStatusChangeKeyByActivity(){
        mInterfaceStatusChangeKey = loaderInterfaceStatusChangeObjectKey();
    }

    private Object mInterfaceStatusChangeKey;
    private InterfaceStatusChange mInterfaceStatusChange ;

    protected String mScreenPageName = "";  // 当前屏幕名称
    protected String mFeaturedName = "";   // 当前功能名称
    protected String mFrom = "";
    public  String mVarId = "";

    public void onCreate(){
        putInterfaceStatusChange();
    }

    public void onCreateView(){
        putInterfaceStatusChange();
    }

    public void onResume(){
//        putInterfaceStatusChange(); 如果不注释导致每次界面回来都会重新put，之前的也没删除，就会让map越来越大。
    }

    public void onStart(){
        putInterfaceStatusChange();
    }

    public void onStop(){
        removeInterfaceStatusChange();
    }

    public void onDestroy(){
        removeInterfaceStatusChange();
    }


    /**
     * put a InterfaceStatusChange . the key is from loaderInterfaceStatusChangeObjectKey() .
     */
    public void  putInterfaceStatusChange(){
        mInterfaceStatusChange = loaderInterfaceStatusChange();
        mInterfaceStatusChangeKey = loaderInterfaceStatusChangeObjectKey();

        LogUtils.i("Logger", getClass().getSimpleName()+" ==> putInterfaceStatusChange -> key= "+(mInterfaceStatusChangeKey==null?"null":mInterfaceStatusChangeKey)+" , value="+(mInterfaceStatusChange==null?"null":mInterfaceStatusChange));

        if(mInterfaceStatusChange!=null && mInterfaceStatusChangeKey!=null){
            DownloadStatusManager.getInstance().putStatusChangeListener(mInterfaceStatusChangeKey, mInterfaceStatusChange);
        }
    }

    /**
     * remove a InterfaceStatusChange . the key is from loaderInterfaceStatusChangeObjectKey() .
     */
    public void removeInterfaceStatusChange(){
        if(mInterfaceStatusChangeKey!=null){
            LogUtils.i("Logger", getClass().getSimpleName()+" ==> removeInterfaceStatusChange");
            DownloadStatusManager.getInstance().removeStatusChangeListener(mInterfaceStatusChangeKey);
        }
    }

    /**
     * Note: need Override .
     * init a key for map a InterfaceStatusChange .
     * 监听下载状态的 key, 该key最好为一个Activity 或 Fragment .
     * 主要用于线下, 线下的会有多个继承此类的适配器会处于同一个UI界面 , 所以key 需要自己设定 .
     * @return
     */
    public abstract Object loaderInterfaceStatusChangeObjectKey();

    /**
     * Note: need Override .
     * when you find this return null, you can try new InterfaceStatusChange() in subclass's method loaderInterfaceStatusChange()  .
     * example - Override public InterfaceStatusChange loaderInterfaceStatusChange(new loaderInterfaceStatusChange());
     * init a InterfaceStatusChange .
     * @return
     */
    public abstract InterfaceStatusChange loaderInterfaceStatusChange();

    public void setScreenPageName(String screenPageName) {
        mScreenPageName = screenPageName;
    }

    public String getScreenPageName() {
        return mScreenPageName;
    }

    public void setFeatureName(String featureName) {
        mFeaturedName = featureName;
    }

    public String getmFeaturedName() {
        return mFeaturedName;
    }

    public void setFrom(String from) {
        mFrom = from;
    }

    public String getFrom() {
        return mFrom;
    }

    protected void statusClickAnalytics(String buttonType,String subPlace,String position, String itemId, String itemValue, String itemType, String topicId, String topicType) {
        String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, subPlace, position);
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType(topicType)
                .setTopicId(topicId)
                .setItemType(itemType)
                .setItemId(itemId)
                .setButtonType(buttonType)
                .setItemValue(itemValue)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }
}

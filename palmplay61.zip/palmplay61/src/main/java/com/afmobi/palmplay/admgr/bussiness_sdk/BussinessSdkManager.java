package com.afmobi.palmplay.admgr.bussiness_sdk;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.AdCache;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.manager.SPManager;

import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.palmstorecore.util.TRStringUtil;

public class BussinessSdkManager {

    private static final byte[] lock = new byte[0];
    private static volatile BussinessSdkManager mBussinessSdkManager;
    public static final String TAG = "bussinessSdk";
    public static final String TEST_SDK_CONFIG_ID = "test10001";
    public static final String OFFICIAL_CONFIG_ID = "f2f7516e34514f0cade75c95dbe422fe";
    public static final String OFFICIAL_SDK_APPID = "36875cdb6a7f4da783d3714632937d9c";
    public static final String TEST_SDK_APPID= "test1001";
    private String configID = "";
    private long mBussinessLastShowTime = 0L;
    private long mRequestPreloadTime = 0L;
    private long mRequestFinishedTime = 0L;  // 请求完成时间
    private static final long PRELOAD_FINISHED_GAP = 8 * 60 * 60 * 1000; // 请求完成间隔 8小时
    private static final String BUSSINESS_FILE_NAME = "bussiness_sdk_file"; // 商业化SDK文件名
    private static final String BUSSINESS_KEY_FINISHED_TIME = "finished_req_time"; // 请求完成时间
    private static final long PRELOAD_REQ_GAP = 5000L; // 间隔5S
    private static final String BUSSINESS_LAST_SHOW_TIME = "bussiness_last_time"; // 上次访问商业化广告时间
    public static BussinessSdkManager getInstance() {
        if (mBussinessSdkManager == null) {
            synchronized (lock) {
                if (mBussinessSdkManager == null) {
                    mBussinessSdkManager = new BussinessSdkManager();
                }
            }
        }
        return mBussinessSdkManager;
    }

    public BussinessSdkManager() {
        if(BuildConfig.DEBUG) {
            configID = TEST_SDK_CONFIG_ID;
        } else {
            configID = OFFICIAL_CONFIG_ID;
        }
        long defaultTime = System.currentTimeMillis();
        mRequestFinishedTime = (long)TRSharedPreferenceUtils.getParam(BUSSINESS_FILE_NAME,BUSSINESS_KEY_FINISHED_TIME,defaultTime);
    }

    public boolean canShowBussinessSdk() {
        boolean result = false;
        //todo 删除商业化sdk
//        if(AdCache.getInstance().isCanShowBussinessAd()) {
//            result = true;
//        }
        return result;
    }

    public void sdkPreload() {
        if(!canShowBussinessSdk()) {
            LogUtils.e(TAG,"is not bussiness sdk data");
            return;
        }
        long repeatReqGap = System.currentTimeMillis() - mRequestPreloadTime;
        if(repeatReqGap < PRELOAD_REQ_GAP) {
            LogUtils.e(TAG,"preload gap is not timeout");
            return;
        }
        mRequestPreloadTime = System.currentTimeMillis();
        long finishedGap = System.currentTimeMillis() - mRequestFinishedTime;
        if(finishedGap < PRELOAD_FINISHED_GAP) {
            LogUtils.e(TAG,"preload PRELOAD_FINISHED_GAP");
            return;
        }
    }

    public void sdkLoad(final BussinessSdkCallBack callBack) {

    }
    public void destoryBussinessSdk() {

    }
    /**
     * 展示时间间隔
     */
    public boolean isOverTwoHours() {
        if(mBussinessLastShowTime == 0) {
            mBussinessLastShowTime = SPManager.getLong(BUSSINESS_LAST_SHOW_TIME, 0);
        }

        long currTime = System.currentTimeMillis();

        if(Math.abs(currTime - mBussinessLastShowTime) >= AdCache.ADS_SHOW_INTERVAL) {
            return true;
        }
        LogUtils.e(TAG,"isOverTwoHours false");
        return false;
    }

    public boolean isReadyOfBussinessResource() {
        boolean rst = false;
        //todo 增加同步判断资源方法
        //mTsplashAd.loadAd();
//        rst = TSplashAd.isAdReady(configID);
//        LogUtils.e(TAG,"resource is ready ? "+rst);
        return rst;
    }

    public void trackSdkClick(int value) {
        TRAnalysticsUtil.trackBussinessEventClick(TRAnalyticsConstant.BUSSINESS_SDK_CLICK,value);
    }

    public void trackSdkLoadApi(int value) {
        TRAnalysticsUtil.trackBussinessApi(TRAnalyticsConstant.BUSSINESS_SDK_API_REQ,value);
    }

    public void trackSdkPreLoadApi(int value) {
        TRAnalysticsUtil.trackBussinessApi(TRAnalyticsConstant.BUSSINESS_SDK_PRE_REQ,value);
    }

    public void trackSdkShowApi() {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.SPLASH_PV, "", "");
        ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
        builder.setValue(value)
                .setFrom("x_x_x_x")
                .setTopicType(TRAnalyticsConstant.ADVERTISE)
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setItemValue("")
                .setCfgId(AdCache.getInstance().getBussinessCfgId())
                .setReportSource(AdCache.BUSSINESS_SDK)
                .setTaskId(0);
        TRAnalysticsUtil.trackExposure(builder);
    }
}

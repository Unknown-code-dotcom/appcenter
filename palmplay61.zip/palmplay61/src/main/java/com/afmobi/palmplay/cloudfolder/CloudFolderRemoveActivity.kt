package com.afmobi.palmplay.cloudfolder

import android.os.Bundle
import android.text.TextUtils
import androidx.appcompat.app.AppCompatActivity
import com.afmobi.palmplay.cloudfolder.CloudFolderManager.Companion.getInstance
import com.afmobi.palmplay.cloudfolder.utils.EXTRA_SHORTCUT_ID_KEY
import com.afmobi.palmplay.shortcuts.LauncherShortcutActivity
import com.transsion.palmstorecore.log.LogUtils

class CloudFolderRemoveActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 设置沉浸式状态栏
        try {
           intent?.apply {
               val action = intent.action
               val shortcutId =
                   intent.getStringExtra(EXTRA_SHORTCUT_ID_KEY)
               if (TextUtils.equals(action, "ACTION_SHOW_DELPOPUPWINDOW")) {
                   shortcutId?.let {
                       getInstance().removeShortcutByFolder(it)
                       getInstance().checkFolderStatus(it)
                   }
                   finish()
               }
           }
        } catch (e: Exception) {
            LogUtils.e(e)
        }
        finish()
    }
}
package com.afmobi.palmplay.appmanage;

import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.RankModel;

/**
 * 文件管理页Download模块的数据item
 * Created by xiangfei.wei on 2018/12/14.
 */
public class FileManageDownloadAdapterItem {
    public static final int RECOMMEND_MAX_SHOW_SIZE = 8;

    public static final int INSTALLING_TITLE = 1;
    public static final int DOWNLOADING_ITEM = 2;
    public static final int DOWNLOADED_TITLE = 3;
    public static final int DOWNLOADED_ITEM = 4;
    public static final int NO_DOWNLOAD_TIPS = 5;
    public static final int RECOMMEND_TITLE = 6;
    public static final int RECOMMEND_ITEM = 7;
    public static final int AD = 8;
    public static final int INSTALLED_TITLE = 9;
    public static final int INSTALLED_ITEM = 10;
    public static final int INSTALLED_MORE_APPS = 11;
    public static final int PREORDERED_TITLE = 12;
    public static final int PREORDERED_ITEM = 13;

    public int itemType;
    public int downloadingCount;
    /**
     * 显示start all还是pause all；true为start all；
     */
    public boolean startAllStatus;
    public FileDownloadInfo fileDownloadInfo;
    public RankModel rankModel;
    public String placementId;

    //for pre-order begin
    public int preOrderedCount;
    public float star;
    public String simpleDescription;
    //for pre-order end
}

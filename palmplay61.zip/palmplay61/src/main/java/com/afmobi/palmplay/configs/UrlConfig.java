// TOP SECRET
package com.afmobi.palmplay.configs;


import android.text.TextUtils;

import com.transsion.palmstorecore.BuildConfig;

import static com.transsion.palmstorecore.util.RSAUtil.RSA_PUBLIC_KEY_RELEASE;
import static com.transsion.palmstorecore.util.RSAUtil.RSA_PUBLIC_KEY_TEST;

public final class UrlConfig {

    /******************************** service address config  begin ******************************************/
    public interface WebServiceType {
        String RELEASE = "RELEASE";
        String TEST = "TEST";
        String UAT = "UAT";
    }

    //协议走https
    //protected static final String BASE_URL_RELEASE = "https://android.palmplaystore.com";
    public static final String FIRST_URL_RELEASE = "https://android.palmst0re.com";
    public static final String SECOND_URL_RELEASE = "https://android.pa1mstore.com";
    public static final String THIRD_URL_RELEASE = "https://android.palmplaystore.com";

    public static final String FIRST_DOWNLOAD_CDN = "cdn2.palmplaystore.com";
    public static final String SECOND_DOWNLOAD_CDN = "cdn2.pa1mstore.com";
    public static final String THIRD_DOWNLOAD_CDN = "cdn2.palmst0re.com";
    public static final String UAT_DOWNLOAD_CDN = "https://uat-cdn.palmplaystore.com";

    public static final String BASE_URL_UAT = "https://uat-android.palmplaystore.com";
    //	protected static final String BASE_URL_TEST = "https://pre-android.palmplaystore.com";
    public static final String BASE_URL_TEST = "https://test-android.palmplaystore.com";

    public static String BASE_URL = BASE_URL_TEST;

    public static String BASE_FIND_URL = BASE_URL_TEST;

    //todo 尾量控制
    public static final String BASE_TAIL_STOP_URL_UAT = "https://test-operation-domain.palmplaystore.com";
    public static final String BASE_TAIL_STOP_URL_TEST = "http://test-operation-domain.palmplaystore.com";
    public static final String BASE_TAIL_STOP_URL_RELEASE = "https://operation-domain.palmplaystore.com";
    public static String BASE_TAIL_STOP_URL = BASE_TAIL_STOP_URL_UAT;

    //todo 前台详情页接口
    public static final String BASE_DETAIL_TEST = "https://test-core-api.palmplaystore.com";
    public static final String BASE_DETAIL_RELEASE = "https://android-dcdn.palmplaystore.com";
	public static final String BASE_DETAIL_RELEASE_TWO = "https://android-dcdn.pa1mstore.com";
	public static final String BASE_DETAIL_RELEASE_THREE = "https://android-dcdn.palmst0re.com";
	public static String BASE_DETAIL_URL = BASE_URL_UAT;
    //todo feature域名
    public static final String BASE_FEATURE_TEST = "https://test-feature-api.palmplaystore.com";
	public static final String BASE_FEATURE_UAT = "https://uat-feature-api.palmplaystore.com";
	public static final String BASE_FEATURE_RELEASE = "https://feature-api.palmplaystore.com";
	public static final String BASE_FEATURE_RELEASE_TWO = "https://feature-api.pa1mstore.com";
    public static final String BASE_FEATURE_RELEASE_THREE = "https://feature-api.palmst0re.com";


    public static String BASE_FEATURE = BASE_FEATURE_RELEASE;
    //todo 专题more域名
    public static final String BASE_MORE_FEATURE_TEST = "https://test-feature-api.palmplaystore.com";
    public static final String BASE_MORE_FEATURE_UAT = "https://uat-feature-api.palmplaystore.com";
    public static final String BASE_MORE_FEATURE_RELEASE = "https://feature-api-dcdn.palmplaystore.com";
    public static final String BASE_MORE_FEATURE_RELEASE_TWO = "https://feature-api-dcdn.pa1mstore.com";
    public static final String BASE_MORE_FEATURE_RELEASE_THREE = "https://feature-api-dcdn.palmst0re.com";
    public static String BASE_MORE_FEATURE = BASE_MORE_FEATURE_RELEASE;


    public static final String URL_RELEASE_NEW = "https://api.palmplaystore.com";
    public static final String URL_RELEASE_NEW_TWO = "https://api.pa1mstore.com";
    public static final String URL_RELEASE_NEW_THREE = "https://api.palmst0re.com";
	public static final String BASE_RECOMMEND_UAT = "https://uat-recommend.palmplaystore.com";

    public static final String BASE_RECOMMEND_TEST = "https://test-recommend.palmplaystore.com";
	public static final String BASE_RECOMMEND_RELEASE = "https://recommend.palmplaystore.com";
	public static final String BASE_RECOMMEND_RELEASE_TWO = "https://recommend.pa1mstore.com";
	public static final String BASE_RECOMMEND_RELEASE_THREE = "https://recommend.palmst0re.com";
	public static String BASE_RECOMMEND = BASE_RECOMMEND_RELEASE;

    public static final String SEARCH_BASE_URL_URL_TEST_NEW = "https://test-search-api.palmplaystore.com";
	public static final String SEARCH_BASE_URL_URL_UAT_NEW = "https://uat-search-api.palmplaystore.com";
	public static final String SEARCH_BASE_URL_RELEASE_NEW = "https://search-api-dcdn.palmplaystore.com";
	public static final String SEARCH_BASE_TWO_RELEASE_NEW = "https://search-api-dcdn.pa1mstore.com";
	public static final String SEARCH_BASE_THREE_RELEASE_NEW = "https://search-api-dcdn.palmst0re.com";
	public static String SEARCH_BASE_URL_NEW = SEARCH_BASE_URL_RELEASE_NEW;

	// 红包雨
    public static final String GIFTRAIN_BASE_URL_TEST = "https://test-coins-api.palmplaystore.com";
    public static final String GIFTRAIN_BASE_URL_RELEASE = "https://coins-api.palmplaystore.com";
    public static String GIFTRAIN_BASE_URL = GIFTRAIN_BASE_URL_TEST;

	public static final String URL_RELEASE_NEW_TIMER = "https://timer-api.palmplaystore.com";
	public static final String URL_RELEASE_NEW_TWO_TIMER = "https://timer-api.pa1mstore.com";
	public static final String URL_RELEASE_NEW_THREE_TIMER = "https://timer-api.palmst0re.com";

    public static final String BASE_URL_UAT_NEW_TIMER = "https://uat-timer-api.palmplaystore.com";

    public static final String BASE_URL_TEST_NEW_TIMER = "https://test-timer-api.palmplaystore.com";
	public static final String URL_RELEASE_FEATURE_TIMER = "https://timer-feature-api.palmplaystore.com";
	public static final String URL_RELEASE_FEATURE_TWO_TIMER = "https://timer-feature-api.pa1mstore.com";
	public static final String URL_RELEASE_FEATURE_THREE_TIMER = "https://timer-feature-api.palmst0re.com";

	public static final String BASE_FEATURE_TIMER_UAT = BASE_MORE_FEATURE_UAT;
	public static String BASE_URL_FEATURE_TIMER = BASE_FEATURE_TIMER_UAT;

    public static final String BASE_URL_UAT_NEW = "https://uat-api.palmplaystore.com";
    public static final String BASE_URL_TEST_NEW = "https://test-api.palmplaystore.com";
    public static final String BASE_TEST_DOWNLOAD_URL = "https://test-download-api.palmplaystore.com";
    public static final String BASE_URL_NEW_TEST= "https://test-api.palmplaystore.com";
    public static final String BASE_UAT_DOWNLOAD_URL = "https://uat-download-api.palmplaystore.com";
    public static final String BASE_RELEASE_DOWNLOAD_URL = "https://download-api.palmplaystore.com";
    public static final String BASE_RELEASE_DOWNLOAD_TWO_URL = "https://download-api.pa1mstore.com";
    public static final String BASE_RELEASE_DOWNLOAD_THREE_URL = "https://download-api.palmst0re.com";
    public static String BASE_DOWNLOAD_URL = BASE_UAT_DOWNLOAD_URL;  // 下载完成和安装完成上报地址

    public static String BASE_PRE_CACHE_URL_TEST = "https://test-feature-api.palmplaystore.com";
    public static String BASE_PRE_CACHE_URL_UAT = "https://uat-feature-api.palmplaystore.com";
    public static String BASE_PRE_CACHE_URL_RELEASE = "https://feature-api.palmplaystore.com";
    public static String BASE_PRE_CACHE_URL = BASE_PRE_CACHE_URL_TEST;
    public static String BASE_URL_NEW = BASE_URL_UAT_NEW;
    public static String BASE_URL_NEW_DOMAIN = BASE_URL_NEW_TEST;
    public static String BASE_URL_NEW_TIMER = BASE_URL_UAT_NEW_TIMER;
    public static String BASE_URL_NEW_CONFIG_TEST = "https://test-device-api.palmplaystore.com";
    public static String BASE_URL_NEW_CONFIG_UAT = "https://uat-device-api.palmplaystore.com";
    public static String BASE_URL_NEW_CONFIG_RELEASE = "https://device-api.palmplaystore.com";
    public static String BASE_URL_NEW_CONFIG = BASE_URL_NEW_CONFIG_TEST;
    public static final String BASE_URL_UAT_CORE = "https://uat-core-api.palmplaystore.com";
    public static final String BASE_URL_TEST_CORE = "https://test-core-api.palmplaystore.com";
    public static String BASE_URL_CORE = BASE_URL_UAT_CORE;

    public static String BASE_URL_OPERATION_TEST = "https://test-operation-domain.palmplaystore.com";
    public static String BASE_URL_OPERATION_RELEASE = "https://operation-domain.palmplaystore.com";
    public static String BASE_URL_OPERATION = BASE_URL_OPERATION_RELEASE;


	public static String DOWNLOAD_PRO_URL = "https://mi-dev.shalltry.com:90/meteor/api/ipDomainPush";
	public static String DOWNLAD_PRO_URL_RELEASE = "https://meteor.shalltry.com/meteor/api/ipDomainPush";

    //web url test
    public final static String WEB_BASE_URL_RELEASE = "https://m.palmplaystore.com";
    public final static String WEB_BASE_URL_TEST = "http://52.76.170.110:8800";
    public static String BASE_WEB_URL = WEB_BASE_URL_RELEASE;
    public static String SHARE_BASE_WEB_URL = WEB_BASE_URL_RELEASE;//"https://palmplay.top";
    //public static final String PRIVACY_POLICY_URL = "https://static.palmplaystore.com/static_page/license_agreement.html";

    public static final String PRIVACY_BASE_URL = "https://cdn.shalltry.com/PalmStore/index.html";
    private static String mWebServiceType = BuildConfig.DEBUG ? WebServiceType.TEST : WebServiceType.RELEASE;

    public static boolean USE_FORGROUND_BACKGROUND_FEATRUE = true;//是否使用前后台接口功能，true，使用；
    public static boolean DYNAMIC_FOLDER_SWITCH = false;//动态文件夹功能开关，true，开；false，关


    public static final String PLUTO_TEST_URL = "https://test-api.palmplaystore.com/admaster-poll-api/api/getRemindMessageEncrypt";
    public static final String PLUTO_PRODUCT_URL = "https://api.palmplaystore.com/admaster-poll-api/api/getRemindMessageEncrypt";

    public static final String PLUTO_TEST_EW_UPLOAD_URL = "https://test-api.palmplaystore.com/admaster-poll-api/api/callBackEncrypt";
    public static final String PLUTO_PRODUCT_EW_UPLOAD_URL = "https://api.palmplaystore.com/admaster-poll-api/api/callBackEncrypt";

    public static final String PLUTO_STOP_OFFER_TEST_URL = "https://test-api.palmplaystore.com/admaster-poll-api/api/getStoppedOfferV2Encrypt";
    public static final String PLUTO_STOP_OFFER_PRODUCT_URL = "https://api.palmplaystore.com/admaster-poll-api/api/getStoppedOfferV2Encrypt";

	public static final String PLUTO_COMMON_TEST_URL = "https://mi-test.shalltry.com/admaster-poll-api/api/isEmpowerment";
	public static final String PLUTO_COMMON_URL = "https://af.shalltry.com/admaster-poll-api/api/isEmpowerment";
	public static String API_SIMO_CONFIGS = "/api/client/simo/configs/";   //SIMO配置信息
	public static final String PRE_DOWNLOAD_NEW = "/download/getDownloadUrlList";
    public static String RSA_PUBLIC_KEY = RSA_PUBLIC_KEY_RELEASE;

    public static final String CHECK_VERSION_URL_TEST = "https://test-empower-api.palmplaystore.com";
    public static final String CHECK_VERSION_URL_UAT = "https://uat-empower-api.palmplaystore.com";
    public static final String CHECK_VERSION_URL_RELEASE = "https://empower-api.palmplaystore.com";
    public static final String CHECK_VERSION_URL_RELEASE_1 = "https://empower-api.pa1mstore.com";
    public static final String CHECK_VERSION_URL_RELEASE_2 = "https://empower-api.palmst0re.com";

    public static String CHECK_VERSION_URL = BuildConfig.DEBUG ? CHECK_VERSION_URL_TEST : CHECK_VERSION_URL_RELEASE;

    public static String BASE_SMALL_PKG_URL_TEST = "https://test-osupdate-api.palmplaystore.com";
    public static String BASE_SMALL_PKG_URL_RELEASE = "https://osupdate-api.palmplaystore.com";

    public static String BASE_RESTART_URL_RELEASE = "https://restart-api.palmplaystore.com";
    public static String BASE_RESTART_URL_TEST = "https://test-restart-api.palmplaystore.com";

    public static String BASE_RESTART_URL = BASE_RESTART_URL_RELEASE;
    public static String BASE_SMALL_PKG_URL = BASE_SMALL_PKG_URL_RELEASE;


    /**
     * 分段下载任务的相关url
     */
    public static class SpliteUrl {
        /**
         * 测试或生产的根域名
         */
        private static final String RootUrl = BuildConfig.DEBUG ? "https://filetest-cdn.shalltry.com" : "https://download-api.palmplaystore.com";

        /**
         * 分段下载地址
         */
        public static final String BaseUrl = RootUrl + "/palmstore/source/";
        /**
         * 这个接口是km中定义的
         *
         * <a href="https://km.trasre.com/pages/viewpage.action?pageId=43574270">开发文档在这里</a>
         */
        public static final String SpliteUrlEndWith = ".checksum.json";
    }

    static {
        init();
    }

	private static void init(){
		//common server
		if(WebServiceType.TEST.equals(mWebServiceType)){
			BASE_URL = BASE_URL_TEST;
            BASE_FIND_URL = BASE_URL_TEST;
            BASE_URL_NEW = BASE_URL_TEST_NEW;
			RSA_PUBLIC_KEY = RSA_PUBLIC_KEY_TEST;
			BASE_FEATURE = BASE_FEATURE_TEST;
			BASE_URL_CORE = BASE_URL_TEST_CORE;
			BASE_URL_NEW_TIMER = BASE_URL_TEST_NEW_TIMER;
			SEARCH_BASE_URL_NEW = SEARCH_BASE_URL_URL_TEST_NEW;
			BASE_RECOMMEND = BASE_RECOMMEND_TEST;
			BASE_DOWNLOAD_URL = BASE_TEST_DOWNLOAD_URL;
			BASE_DETAIL_URL = BASE_URL_TEST;
            BASE_MORE_FEATURE = BASE_MORE_FEATURE_TEST;
			BASE_URL_FEATURE_TIMER = BASE_URL_TEST;
            BASE_TAIL_STOP_URL = BASE_TAIL_STOP_URL_TEST;
            BASE_PRE_CACHE_URL = BASE_PRE_CACHE_URL_TEST;
            BASE_URL_NEW_CONFIG = BASE_URL_NEW_CONFIG_TEST;
            BASE_URL_NEW_DOMAIN = BASE_URL_NEW_TEST;
            GIFTRAIN_BASE_URL = GIFTRAIN_BASE_URL_TEST;
            BASE_URL_OPERATION = BASE_URL_OPERATION_TEST;
            BASE_SMALL_PKG_URL = BASE_SMALL_PKG_URL_TEST;
            CHECK_VERSION_URL = CHECK_VERSION_URL_TEST;
            BASE_RESTART_URL = BASE_RESTART_URL_TEST;
		} else if(WebServiceType.UAT.equals(mWebServiceType)){
			BASE_URL = BASE_URL_UAT;
            BASE_FIND_URL = BASE_URL_TEST;
			BASE_URL_NEW = BASE_URL_UAT_NEW;
			RSA_PUBLIC_KEY = RSA_PUBLIC_KEY_TEST;
			BASE_FEATURE = BASE_FEATURE_UAT;
			BASE_URL_CORE = BASE_URL_UAT_CORE;
			BASE_URL_NEW_TIMER = BASE_URL_TEST_NEW_TIMER;
			SEARCH_BASE_URL_NEW = SEARCH_BASE_URL_URL_UAT_NEW;
            CHECK_VERSION_URL = CHECK_VERSION_URL_UAT;
			BASE_RECOMMEND = BASE_RECOMMEND_UAT;
			BASE_DOWNLOAD_URL = BASE_UAT_DOWNLOAD_URL;
			BASE_DETAIL_URL = BASE_URL_UAT_CORE;
            BASE_MORE_FEATURE = BASE_MORE_FEATURE_UAT;
			BASE_URL_FEATURE_TIMER = BASE_FEATURE_TIMER_UAT;
            BASE_TAIL_STOP_URL = BASE_TAIL_STOP_URL_UAT;
            BASE_PRE_CACHE_URL = BASE_PRE_CACHE_URL_TEST;
            BASE_URL_NEW_CONFIG = BASE_URL_NEW_CONFIG_TEST;
            BASE_URL_NEW_DOMAIN = BASE_URL_NEW_TEST;
            GIFTRAIN_BASE_URL = GIFTRAIN_BASE_URL_TEST;
            BASE_URL_OPERATION = BASE_URL_OPERATION_TEST;
            BASE_SMALL_PKG_URL = BASE_SMALL_PKG_URL_TEST;
            BASE_RESTART_URL = BASE_RESTART_URL_TEST;
        } else {
			BASE_URL = FIRST_URL_RELEASE;
            BASE_FIND_URL = FIRST_URL_RELEASE;
            BASE_URL_NEW = URL_RELEASE_NEW;
			RSA_PUBLIC_KEY = RSA_PUBLIC_KEY_RELEASE;
			BASE_FEATURE = BASE_FEATURE_RELEASE;
			BASE_URL_CORE = URL_RELEASE_NEW;
			BASE_URL_NEW_TIMER = URL_RELEASE_NEW_TIMER;
			SEARCH_BASE_URL_NEW = SEARCH_BASE_URL_RELEASE_NEW;
            CHECK_VERSION_URL = CHECK_VERSION_URL_RELEASE;
			BASE_RECOMMEND = BASE_RECOMMEND_RELEASE;
			BASE_DOWNLOAD_URL = BASE_RELEASE_DOWNLOAD_URL;
			BASE_DETAIL_URL = BASE_DETAIL_RELEASE;
            BASE_MORE_FEATURE = BASE_MORE_FEATURE_RELEASE;
			BASE_URL_FEATURE_TIMER = URL_RELEASE_FEATURE_TIMER;
            BASE_TAIL_STOP_URL = BASE_TAIL_STOP_URL_RELEASE;
            BASE_PRE_CACHE_URL = URL_RELEASE_FEATURE_TIMER;
            BASE_URL_NEW_CONFIG = BASE_URL_NEW_CONFIG_RELEASE;
            BASE_URL_NEW_DOMAIN = URL_RELEASE_NEW;
            GIFTRAIN_BASE_URL = GIFTRAIN_BASE_URL_RELEASE;
            BASE_URL_OPERATION = BASE_URL_OPERATION_RELEASE;
            BASE_SMALL_PKG_URL = BASE_SMALL_PKG_URL_RELEASE;
            BASE_RESTART_URL = BASE_RESTART_URL_RELEASE;
        }

//		//Web server
        if (WebServiceType.TEST.equals(mWebServiceType) || WebServiceType.UAT.equals(mWebServiceType)) {
            BASE_WEB_URL = WEB_BASE_URL_TEST;
        } else {
            BASE_WEB_URL = WEB_BASE_URL_RELEASE;
        }
    }

    public static void setBaseUrl(String url) {
        BASE_URL = url;
    }

    public static boolean getCurrentWebServiceType() {
        return WebServiceType.TEST.equals(mWebServiceType);
    }

    public static boolean isTestWebServiceType() {
        return WebServiceType.TEST.equals(mWebServiceType);
    }

    public static boolean isUatWebServiceType() {
        return WebServiceType.UAT.equals(mWebServiceType);
    }

	public static boolean setWebServiceType(String type){
		if(TextUtils.isEmpty(type)) return false;
		mWebServiceType = type;
		init();
		return true;
	}

    /******************************** service address config  end ******************************************/


    public interface VerType {
        String V6_0 = "V6_0";
        String V6_1 = "V6_1";
        String V6_2 = "V6_2";
        String V6_3 = "V6_3";
    }

    public static final String V6_0_PREFIX = "/new";
    public static final String V6_1_PREFIX = "/six";
    public static final String V6_2_PREFIX = "/six";
    public static final String V6_3_PREFIX = "/6.3";
    public static final String V6_4_PREFIX = "/6.4";
    public static final String V6_5_PREFIX = "/6.5";
    public static final String V6_6_PREFIX = "/6.6";
    public static final String V6_7_PREFIX = "/6.7";
    public static final String V6_8_PREFIX = "/6.8";
    public static final String V6_9_PREFIX = "/6.9";


    // description for v6.4 : 6.4 新增少量接口, 所以前缀保持的还是6.3, v6.4的接口在下面
    public static String V_PREFIX = V6_3_PREFIX;// TODO Note


    public static String START_UP = "/device/startup/";
    public static String HOME = V_PREFIX + "/home/";// "/home/";
    public static String CATEGORY = V_PREFIX + "/category/";
    public static String DETAIL = V_PREFIX + "/detail/";

    public static String LOGIN = V_PREFIX + "/login/";
    //public static String CATEGORY_LIST = V_PREFIX + "/category_list/";
    public static String SEARCH = V_PREFIX + "/search/";
    public static String SEARCH_PAGE = V_PREFIX + "/search_page/";
    public static String NEW_SEARCH_PAGE = V6_9_PREFIX + "/search_page/";
    public static String NEW_SEARCH_PAGE_API = "/search/hotWords";
    public static String RANK = V_PREFIX + "/rank/";
    public static String COMMENT_LIST = V_PREFIX + "/comment_list/";
    public static String RECOMMEND = V_PREFIX + "/recommend/";

    public static String SUBMIT_COMMENT = "/user" + V_PREFIX + "/issue_comment/";// Note

    public static String FEEDBACK = V_PREFIX + "/sys/feedback/";

    /**
     * //push新接口
     */
    public static String PUSH = "/operation/push/listByParam/";

    /**
     * 激活提醒接口
     */
    public static String ACTIVATE_REMIND = "/operation/push/listByUnauth";

 //   public static String INSTALL = V6_9_PREFIX + "/one_key_install/";//装机必备
//    public static String SYSMSG = V_PREFIX + "/sys/sysMsg/";//后台服务调用地址：/6.3/sys/sysMsg/
 //   public static String SYSMSG_FORGROUND = V6_9_PREFIX + "/sysMsg/";//前台服务调用地址：/6.9/sysMsg/

    public static String INSTALL_NEW_V2 = "/recommend/install/oneKey/V3";//新版老手 装机必备

	public static String SYSMSG = V_PREFIX + "/sys/sysMsg/";//后台服务调用地址：/6.3/sys/sysMsg/
	public static String SYSMSG_FORGROUND = V6_9_PREFIX + "/sysMsg/";//前台服务调用地址：/6.9/sysMsg/

    /**
     * 自更新检查；
     */
    public static String CHECK_NEW_VERSION = "/core/updates/self";

    public static String MARKET_EVENT_INFO = "/operation/tips/multipleGet/";//运营活动弹框信息；
    public static String CHECK_VERSION = V_PREFIX + "/sys/check_version/";
    public static String CHECK_VERSION_DIFF = "/empower/check_version/";

    //public static String UPLOAD_RECORD = V_PREFIX + "/new_upload_record/";
    public static String FINISH_DOWNLOAD = V_PREFIX + "/finish_download/";
    public static String SETUP = V_PREFIX + "/setup/";
    public static String CHECK_STARTUP_UPDATE = "/startupUpdate/check_version/";

    public static String TRY_CLICK = V_PREFIX + "/try_click/";

    // ----------------- add PalmPlay_v6.3   begin for recharge  --------------------
    //public static String CATEGORY = V_PREFIX + "/category/";
    public static String HOT = V_PREFIX + "/hot/";
    public static String NEW = V_PREFIX + "/new/";
    public static String CATEGORY_LIST = V_PREFIX + "/category/list/";


    // ----------------- add PalmPlay_v6.3   end  for recharge  --------------------


    // ----------------- add v6.3  begin  ---------------------------
    public static String FEATRUED_NEW_API = "/api/client/feature/";
    public static String FEATURED = V6_9_PREFIX + "/featured/";
    public static String FUN_TABS = V6_4_PREFIX + "/fun/tab/";
    public static String UPLOAD_CLIENT_RECORD = V6_3_PREFIX + "/upload_client_record/";
    // ----------------- add v6.3  end  ---------------------------

    public static String FEATURE_NEW_API = "/feature/page";
    // add v_6.3.5  begin  ----------------------
    public static String RECOMMEND_INSTALL = V_PREFIX + "/recommend_install/";
    // add v_6.3.5  end    ----------------------


    // add v_6.4  begin  ----------------------
    public static final String PRE_DOWNLOAD_EXTRA = V6_4_PREFIX + "/pre_download/";
    public static final String PRE_DOWNLOAD_FOR_403 = V6_9_PREFIX + "/pre_download/";
    /**
     * 这个接口是km中定义的
     *
     * <a href="https://km.trasre.com/pages/viewpage.action?pageId=43574270">开发文档在这里</a>
     */
    public static final String CLICK_DOWNLOAD_REPORT = V6_9_PREFIX + "/pre_download_record/";

    public static String DETAIL_NEW = V6_4_PREFIX + "/detail/";
    public static String SHARE_URL = "/api/share_url/";
    public static String SEARCH_PAGE_RANK = V6_4_PREFIX + "/search_page_rank/";
    public static String SEARCH_REAL = V6_4_PREFIX + "/real_search/";
    public static String DOWNLOAD_RECOMMEND = V6_4_PREFIX + "/download_recommend/";
    // add v_6.4  end    ----------------------

    // add v_6.4.1  begin  ----------------------
    public static String NGP_GET_OFFER_SWITCH = "/api/ngp/get_offer_switch/";
    // add v_6.4.1  end    ----------------------

    // v_6_5_3  begin------------------------
    public static String SUBSCRIBE_APP = V6_5_PREFIX + "/suscribe/";//预约APP；
    // v_6_5_3  end------------------------

    public static String GET_CLEAN_CACHE_PATHS = V6_6_PREFIX + "/clean_cache/";//获取清理SD卡的目录
    public static String GET_CLEAN_CACHE_RECOMMEND = V6_6_PREFIX + "/clean_recommend/";//获取清理SD卡后的推荐页内容

    public static String VIDEO_TABS = V6_7_PREFIX + "/video/tab/";
    public static String ACTIVITY_CENTER = V6_7_PREFIX + "/video/tab/";

    public static String GET_ADMOB_INFO = V6_7_PREFIX + "/ad_list/";//请求admob广告配置信息

    public static String GET_TAG_APP_LIST = V6_7_PREFIX + "/tag/list/"; //请求同一tag下的App列表页内容

    public static String APP_DETAILE_TAG_LIST = V6_7_PREFIX + "/tag/"; //请求同一tag下的App列表页内容

    //V6.8.X begin---------------
    public static String SOFT_NEW = V6_8_PREFIX + "/new/sort_list/";    //APP、GAME下的new页面数据
    //V6.8.X end---------------

    public static String LAUNCHER_SHORTCUTS = V6_9_PREFIX + "/shortcuts/";  // 桌面快捷入口接口

    public static String SSP_URL = V6_7_PREFIX + "/ssp_toggle";    // ssp配置接口

    public static String GET_UPDATE_WHITELIST = "/white_list/"; //更新白名单

    public static String BOOT_UPLOAD = "/device_activation?";  //手机第一次开机上传

    public static String BAICE_API_TYPE_MORE = "";  // 首页广告位点击更多按钮接口

    public static String RECOMMEND_INSTALL_NEW = "/recommend/install/new915"; // 新的一键安装接口
    public static String RECOMMEND_PRE_DATA = "/preData/handlePreData915"; //预埋一键安装接口

    public static String API_FIND_DETAIL = "/client/api/find/detail/"; //Find详情页
    public static String URL_FIND_LIST = "/client/api/find/query";//find列表页；

    public static String URL_DETAIL_FIND_LIST = "/client/api/game/findList";//详情页中 类find列表Tab；

    public static String API_PRECACHE_FIND_DETAIL = "/preCache/find/detail/v1"; //预加载Find详情页
    public static String API_PRECACHE_FIND_LIST = "/preCache/find/query/v1";//预加载find列表页；
    public static String API_PRECACHE_SINGLE_RANK = "/preCache/singleRank"; //预加载单专题
    public static String API_PRECACHE_FEATURE = "/preCache/feature/page";//预加载榜单PAGE；
    public static String API_Tool_FEATURE = "/distribute/feature/me";//937新增Tool页面banner实时请求接口
    public static String API_PRECACHE_FIND_LIST_V2 = "/preCache/find/query/v2";//预加载find列表页 for recall


    public static String API_TOOL_CONFIG = "/api/client/speedDial/config";//Tool配置信息；
    public static String API_HOTCOMMENT = "/api/client/commentService/hotComment";//获取热门评论
    public static String API_RATINGINFO = "/api/client/commentService/ratingInfo";//获取评星信息
    public static String API_FEEDBACK = "/api/client/commentService/commentFeedback";//反馈
    public static String API_COMMENT = "/api/client/commentService/comment";//评论
    public static String API_COMMENTLIST = "/api/client/commentService/commentList";//获取评论列表
    public static String API_NEW_COMMENTLIST = "/api/client/commentService/commentListNew";//9.3.1A版本改版，获取评论列表新接口

    public static String API_V2_COMMENTLIST = "/api/client/commentService/commentListV2";//9.3.1B版本改版，将ratingInfo归纳到RecyclerView中来
    public static String API_CURRENTCOMMENT = "/api/client/commentService/currentComment";//获取当前评论
    public static String API_RATING = "/api/client/commentService/rating";//评星

    public static String API_CONFIGS = "/device/config";   //获取preload等配置信息
    public static String APP_SKIN = "/operation/skin/getSkin";//获取皮肤

    //积分
    public static String POINTS_CHECKIN = "/coins/signin/posts";//签到接口
    public static String POINTS_LIST = "/coins/signin/lists";//签到历史接口
    public static String POINTS_QUERY = "/coins/user/points";//查询用户积分
    public static String POINTS_DRAW = "/coins/turntable/draw";//抽奖
    public static String POINTS_WINUSER = "/coins/turntable/winuser";//查询中奖用户

    public static String FEATURE_SINGLE_RANK = "/feature/singleRank";//查询专题明细接口

    public static String FEATURE_CARDPAGE = "/feature/cardRank";//查询专题明细接口
    public static String FEATURE_SINGLE_RANK_CROSSBAR = "/feature/singleRankWithCrossbar";//查询带横栏专题明细接口

    public static String APP_ITEM_DETAIL = "/core/itemDetail";//预加载详情信息
    public static String PRECACHE_FEATURE_DETAIL = "/preCache/feature/page/detail";//预加载详情页feature数据

    public static String API_START_UP = "/device/startup/v2";//启动startup新接口(支持定时)

    public static String API_SEARCH_BOX_TAG = "/search/completeCycleWords";//轮播词

    public static String GET_SINGLE_RANK = V6_9_PREFIX + "/single_rank/"; //单独专题获取

    public static String SPLASH_AD_URL = "/ad/open/multipleGet/"; //获取开屏广告的API接口(新版)

    public static String DOWNLOAD_BASE_CFG = V6_9_PREFIX + "/dl_base_cfg/";  // 获取下载配置信息

	public static String API_SEARCH_OFFLINE = "/search/offline/top";//根据国家简码获取top离线包

	public static String API_SEARCH_NEW = "/search/searchByCategory"; //搜索结果或联想搜索新接口

    public static String API_SEARCH_PAGE = "/feature/searchPage"; //搜索默认页接口(下发热词/推荐/you may like)

    public static String API_SEARCH_FIND = "/search/find"; //搜索结果
    public static String API_SEARCH_FEEDBACK = "/operation/feedback/save"; //搜索反馈
    //红包雨
    public static String API_REDPACKETRAIN_QUERY = "/coins/redPacketRain/queryActivity"; //红包雨活动查询接口
    public static String API_REDPACKETRAIN_ISSUE = "/coins/redPacketRain/issuePrize"; //红包雨下发奖品接口
    public static String API_REDPACKETRAIN_REPORT = "/coins/redPacketRain/reportPrize"; //红包雨中奖上报接口

    public static String API_STATIONMAIL = "/device/stationMail/preReload/V2"; //预加载站内信接口
    public static String API_FEATURE_RECOMMEND = "/feature/recommendAfterDownload"; //榜单下载推荐接口

    public static String API_TOOLS_CONFIG = "/operation/psToolsConfig/queryPsToolsConfig"; //常用工具栏配置api
    public static String API_OFFLINE_GAME = "/operation/offlineGameNew"; //离线游戏下发api. 9.1.5后更换新接口
    public static String API_INSTANT_OFFLINE_GAME = "/operation/instantOfflineGame"; //instant离线游戏预缓存 936B 新增

    public static String API_QUERY_UPDATE_BY_SCENE = "/operation/sceneOrder/queryUpdateOrderByScene/v1"; //查询场景数据更新指令

    /**
     * 9.3.2版本新增，合并startUp和queryUpdateOrderByScene
     */
    public static String API_DATA_HIGH_WAY = "/device/datahighway"; //查询场景数据更新指令&StartUp配置下发

    public static String API_LOCAL_LAN_PRE_CACHE = "/device/localLan/preCache";

    public static String API_MULTI_PRE_CHECK = "/download/multiPreCheck"; //批量查询应用是否可下载

    /**
     * 9.3.3版本新增，eBooks相关接口
     */
    public static String API_EBOOKS_HOME = "/feature/book/home";
    public static String API_EBOOKS_RANK_LIST = "/feature/book/list";

    public static String API_HOME_GAME_FLOW = "/feature/gameFlow"; //首页game tab游戏流api
    public static String API_HOME_GAME_RANKING = "/feature/gameRanking"; //game 榜单
    public static String API_SMALL_PKG_DETAILS = "/api/os-apk-zip/os-update-detail"; //小包升级详情页


    public static final String BASE_URL_NEW_DOMAIN_PH_TEST = "https://test-appassistant-api.palmplaystore.com";
    public static final String BASE_URL_NEW_DOMAIN_PH_MOCK= "https://easymock.tmctool.com/mockurl/650fd07328c83241b984301d";
    public static final String BASE_URL_NEW_DOMAIN_PH_RELEASE = "https://appassistant-api.palmplaystore.com";
    public static final String BASE_URL_NEW_DOMAIN_CLOUD_INSTALL_TEST = "https://test-cloud-preinstall.palmplaystore.com";
    public static final String BASE_URL_NEW_DOMAIN_CLOUD_INSTALL_RELEASE = "https://cloud-preinstall.palmplaystore.com";
    public static String API_GET_PHONE_HELPER_CONFIG = "/appassistant/api/getConfig"; //获取应用助手配置
    public static String API_GET_CLOUD_INSTALL_LIST = "/preinstall/quick/getQuickInstallApps"; //获取云预装的应用列表
    public static String API_GET_CLOUD_PRE_INSTALL_INFO = "/download/getCloudInstallList"; //获取云预装的应用列表

    public static String API_GET_OFFER_LIST_CONFIG = "/appassistant/api/getOffer"; //获取offer列表
    public static String API_GET_GAME_AD_CONFIG = "/distribute/candidate/game"; //获取游戏广告
    public static String BASE_URL_NEW_DOMAIN_PH = BASE_URL_NEW_DOMAIN_PH_RELEASE;

    public static String API_GET_PS_OFFER = "/operation/offer/getOffer";//归因专项-PS&EW OFFER 获取,文档：https://transsioner.feishu.cn/docx/NW2Sd8370oVr0Bx5PYLcTFGAnHe
    public static String API_GET_PM_ATTRIBUTION_INFO = "/distribute/attribution/pm";//Pm归因专项信息 获取,文档：https://transsioner.feishu.cn/docx/C0BNdOCWVoFC5txS8Cic5nkWnyH

    public static String API_GET_THIRD_PKG_INFO_CONFIG = "/detailCrawler/offer/getThirdOffer";//获取三方offer列表,文档：https://transsioner.feishu.cn/docx/RHdhd4B2aoGVaWx6Zvjcozr1nmb
    public static String API_UPLOAD_THIRD_PKG_OR_HOLA_INFO = "/detailCrawler/offer/reportEvent";  //上报监听事件,文档：https://transsioner.feishu.cn/docx/RHdhd4B2aoGVaWx6Zvjcozr1nmb

    public static final String API_FEATURE_SINGLE_H5_RANK = "/feature/singleH5Rank"; //H5游戏专题 more 接口
    private static String mVerType = VerType.V6_3;

    static {
        if (VerType.V6_0.equals(mVerType)) {
            V_PREFIX = V6_0_PREFIX;
        } else if (VerType.V6_1.equals(mVerType)) {
            V_PREFIX = V6_1_PREFIX;
        } else if (VerType.V6_2.equals(mVerType)) {
            V_PREFIX = V6_2_PREFIX;
        } else {
            V_PREFIX = V6_3_PREFIX;
        }
    }

    public static String getVerType() {
        return mVerType;
    }

    public static String getVerTypeStr() {
        return mVerType;
    }

    public static String ACTION_NAV_BAR_ACTIVITY = "/ad/nav/multipleGet";
    public static String GET_NOTIFY_TOGGLE = "/api/client/toolbar/configs/";
    public static String API_DEEPLINK_LIST = "/deeplink/getList"; //指定deeplink跳转

    public static String GET_TAIL_STOP_DATA = "/recall/page";

    public static String GTE_ACTIVITY_CENTER_LIST = "/core/activityCenter/queryActivityCenter";//活动中心列表  未分页
    public static String GTE_ACTIVITY_CENTER_LIST_PAGE = "/core/activityCenter/queryActivityCenterPage";//活动中心列表  分页数据
    public static String GTE_GIFTS_CENTER_LIST = "/core/benifitsCardCenter/queryBenifitsCardCenter";
    public static String GTE_GIFTS_CENTER_COUPON_LIST = "/core/benifitsCardCenter/psCouponListPage";

    public static String GET_VERSION_INFO = "/getVersionInfo";


    public static String BASE_VA_AD_URL = BuildConfig.DEBUG ? "https://tpay-japi.ahagamecenter.com" : "https://pay-japi.ahagamecenter.com"; //VA广告域名
    public static String GET_VACONF = BASE_VA_AD_URL + "/app/vaSource"; // VA容器获取新的广告配置
    public static final String PRE_DOWNLOAD_NEW_VA = BASE_VA_AD_URL + "/va/itemDownloadUrl"; //获取下载地址信息和Va广告信息
    public static String GET_HALFSCREENDETAIL = "/core/halfScreenDetail";

    public static String API_PACKAGE_CHECK = BASE_VA_AD_URL + "/game/packageCheckV2";//app包检测

    public static String API_FEATURE_BANNER = "/feature/bannerList"; //首页banner接口

    //todo: Privacy个性化推荐开关
    public static final String API_PRIVACY_QUERY_PSPRS = "/core/psprs/query";
    //URL_RELEASE_NEW
    //BASE_URL_TEST_NEW
    public static final String API_PRIVACY_UPDATE_PSPRS = "/core/psprs/update";
    // 半屏详情页配置
    public static final String API_HALF_DETAIL_STYLE_CONFIG = "/halfScreenDetailStyle/config";
    // ME页面拉活广告兜底
    public static final String API_DISTRIBUTE_PS_ME = "/distribute/ps/me";
}

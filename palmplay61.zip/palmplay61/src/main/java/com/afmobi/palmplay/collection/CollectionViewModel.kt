package com.afmobi.palmplay.collection

import android.content.Intent
import android.util.Pair
import androidx.lifecycle.viewModelScope
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager.REPORT_SOURCE_EW
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode
import com.afmobi.palmplay.admgr.hisavana_sdk.loadAd
import com.afmobi.palmplay.admgr.hisavana_sdk.loadCacheAd
import com.afmobi.palmplay.collection.repo.CollectionLocalRepo
import com.afmobi.palmplay.collection.repo.CollectionRemoteRepo
import com.afmobi.palmplay.home.TRHomeUtil
import com.afmobi.palmplay.home.model.FeatureBean
import com.afmobi.palmplay.home.model.FeatureItemData
import com.afmobi.palmplay.home.model.base.FeatureBaseData
import com.afmobi.palmplay.home.model.base.ReportBean
import com.afmobi.palmplay.model.CurrentTabConfig
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import com.afmobi.palmplay.model.v6_3.PageConstants
import com.afmobi.palmplay.model.v6_3.PageParamInfo
import com.afmobi.palmplay.viewmodel.BaseViewModel
import com.afmobi.util.CommonUtils
import com.afmobi.util.Constant
import com.afmobi.util.Constant.REPORT_SOURCE_BEDDING
import com.afmobi.util.PackageUtil
import com.androidnetworking.BuildConfig
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.transsion.palmstorecore.BuildConfig.DEBUG
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.NetworkUtils
import com.transsion.palmstorecore.util.TRStringUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.timeout
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.time.DurationUnit
import kotlin.time.toDuration

// 定义数据状态
sealed class DataState {
    object Init : DataState()
    object Loading : DataState()
    object Empty : DataState()
    object NetworkError : DataState()
    object Timeout : DataState()
    data class AdSuccess(val ads: List<FeatureItemData>) : DataState()
    data class Success(val data: FeaturedModel) : DataState()
}

sealed class AdResult {
    data class Success(val adList: List<TaNativeInfo?>?, val isCache: Boolean): AdResult()
    data class FilterSuccess(val adList: List<FeatureItemData>): AdResult()
    data class Error(val adError: TaErrorCode?): AdResult()
    object Timeout: AdResult()
}

class CollectionViewModel: BaseViewModel<CollectionNavigator>() {
    private val TAG = "${LogUtils.TAG_COLLECTION}CollectionViewModel"
    private val remoteRepo by lazy {
        CollectionRemoteRepo()
    }
    private val localRepo by lazy {
        CollectionLocalRepo()
    }
    // 数据源定义
    private val _cacheFlow = MutableStateFlow<DataState>(DataState.Init)
    private val _collectionFlow = MutableStateFlow<DataState>(DataState.Init)
    private val _loadingFlow = MutableStateFlow(false)
    private val _liveEwFlow = MutableStateFlow<DataState>(DataState.Init)
    private val _cacheEwFlow = MutableStateFlow<DataState>(DataState.Init)
    private var hasInflated = false

    var mFrom: String = ""
    var mValue: String = ""
    var mFromPage: String = ""
    var mFromSite: String = ""
    var mPageParamInfo: PageParamInfo? = null
    var mTabId = ""
    var mInApp = "0"
    private val mCollectionSwitch by lazy {
        MMKVUtils.getMMKV().getInt(Constant.KV_COLLECTION_SWITCH, 0)
    }

    // 合并后的UI状态
    val uiState: StateFlow<DataState> = combine(
        _cacheFlow,
        _collectionFlow,
        _loadingFlow,
        _liveEwFlow,
        _cacheEwFlow
    ) { cache, collection, isLoading, liveEw, cacheEw ->
        LogUtils.d(TAG, "cache=$cache collection=$collection isLoading=$isLoading liveEw=$liveEw cacheEw=$cacheEw")
        resolveUiState(cache, collection, liveEw, cacheEw, isLoading)
    }.flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.Lazily, DataState.Init)

    @OptIn(FlowPreview::class)
    fun loadData(tabId: String) {
        hasInflated = false
        // 启动缓存加载
        viewModelScope.launch {
            _cacheFlow.value = DataState.Init
            localRepo.getCache(tabId)
                .map {
                    it.buildDataModel()
                }
                .map{
                    it?.getBeddingDataList()
                }
                .catch {
                    _cacheFlow.value = DataState.Empty
                }
                .flowOn(Dispatchers.IO)
                .collect { featuredModel ->
                    LogUtils.d(TAG, "featuredModel=$featuredModel")
                    if (featuredModel?.featureList?.any { (it.dataList?.size ?: 0) > 1 } == true) {
                        LogUtils.d(TAG, "featureList=${featuredModel.featureList}")
                        LogUtils.d(TAG, "mCollectionSwitch = $mCollectionSwitch")
                        if (mCollectionSwitch == 1) {
                            _cacheFlow.value = DataState.Success(featuredModel)
                            LogUtils.d(TAG, "缓存有效")
                        } else {
                            _cacheFlow.value = DataState.Empty
                        }
                    } else {
                        _cacheFlow.value = DataState.Empty
                    }
                }
        }
        // 启动网络请求
        viewModelScope.launch {
            _collectionFlow.value = DataState.Init
            remoteRepo.getCollections(tabId)
                .onEach { featuredModel ->
                    featuredModel?.let {
                        updateCache(it, tabId)
                    }
                }
                .map {
                    it.buildDataModel()
                }
                .map{
                    it?.getBeddingDataList()
                }
                .catch {
                    _collectionFlow.value = DataState.Empty
                }
                .flowOn(Dispatchers.IO)
                .collect { featuredModel ->
                    if (featuredModel?.featureList?.any { (it.dataList?.size ?: 0) > 1 } == true) {
                        if (mCollectionSwitch == 1) {
                            _collectionFlow.value = DataState.Success(featuredModel)
                        } else {
                            _collectionFlow.value = DataState.Empty
                        }
                    } else {
                        _collectionFlow.value = DataState.Empty
                    }
                }
        }

        viewModelScope.launch {
            _liveEwFlow.value = DataState.Init
            loadEwAd().collect {
                when (it) {
                    is AdResult.FilterSuccess -> {
                        _liveEwFlow.value = DataState.AdSuccess(it.adList)
                    }
                    is AdResult.Error -> {
                        _liveEwFlow.value = DataState.Empty
                    }
                    is AdResult.Timeout -> {
                        _liveEwFlow.value = DataState.Empty
                    }
                    else -> {
                        _liveEwFlow.value = DataState.Empty
                    }
                }
            }
        }

        viewModelScope.launch {
            _cacheEwFlow.value = DataState.Init
            loadCacheAd().collect {
                when (it) {
                    is AdResult.FilterSuccess -> {
                        _cacheEwFlow.value = DataState.AdSuccess(it.adList)
                    }
                    is AdResult.Error -> {
                        _cacheEwFlow.value = DataState.Empty
                    }
                    is AdResult.Timeout -> {
                        _cacheEwFlow.value = DataState.Empty
                    }
                    else -> {
                        _cacheEwFlow.value = DataState.Empty
                    }
                }
            }
        }


        // 延迟显示Loading
        viewModelScope.launch {
            _loadingFlow.value = false
            delay(800)
            _loadingFlow.value = true
        }
    }

    private fun FeaturedModel?.buildDataModel(): FeaturedModel? {
        val featuredModel = this ?: return null
        try {
            val type = object : TypeToken<List<FeatureItemData>>() {}.type
            val gson = Gson()
            var rs: Array<String>? = null
            if (featuredModel.rs?.isNotEmpty() == true) {
                rs = featuredModel.rs.split(",".toRegex()).toTypedArray()
            }
            featuredModel.featureList?.forEach { featureBean ->
                featureBean.dataList = gson.fromJson(featureBean.data, type)
                TRHomeUtil.checkPicUrl(featureBean, featuredModel.iconUrlPre)
                TRHomeUtil.checkTraceId(featureBean, rs, featuredModel.tid)
                removeListInstalled(featureBean)
            }
            TRHomeUtil.addTrackLogicField(featuredModel)
            // 去掉空列表或者只有一个元素的列表
            val iterator = featuredModel.featureList?.iterator()
            if (iterator != null) {
                while (iterator.hasNext()) {
                    val data = iterator.next()
                    if (data.dataList == null || data.dataList.isEmpty()
                        || (data.dataList.size < 2 && Constant.ONE_CLICK_VERTICAL_TITLE == data.style)
                        || (data.dataList.size < 4 && Constant.ONE_CLICK_HORIZONTAL_4 == data.style)
                        || (Constant.ONE_CLICK_HORIZONTAL_4 != data.style && Constant.ONE_CLICK_VERTICAL_TITLE != data.style)) {
                        LogUtils.d(TAG, "已移除-----$data")
                        iterator.remove()
                    }
                }
            }
            // head url 处理
            val tabConfig = featuredModel.currentTabConfig ?: CurrentTabConfig().apply { bgImageUrl="" }
            if (!tabConfig.bgImageUrl.startsWith("http")) {
                tabConfig.bgImageUrl = featuredModel.iconUrlPre + tabConfig.bgImageUrl
                featuredModel.currentTabConfig = tabConfig
            }
            return featuredModel
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) e.printStackTrace()
        }
        return null
    }

    private fun FeaturedModel?.filter(): FeaturedModel? {
        val featuredModel = this ?: return null
        //移除已安装应用
        featuredModel.featureList?.forEach { featureBean ->
            removeTail(featureBean)
        }
        return featuredModel
    }


    @OptIn(FlowPreview::class)
    private fun loadCacheAd(): Flow<AdResult> {
        val hasCache = HisavanaSdkManager.getInstance().hasSceneCache(SceneCode.RC_X)
        if(!hasCache) {
            // 无缓存，则直接返回null，结束
            LogUtils.d(TAG, "RC_X has no cache")
            return flowOf(AdResult.Error(null))
        }
        LogUtils.d(TAG, "collection get cache Ad")
        return HisavanaSdkManager.getInstance().loadCacheAd(SceneCode.RC_X)
            .timeout(1000.toDuration(DurationUnit.MILLISECONDS))
            .catch {
                LogUtils.d(TAG, "exception=$it")
                if (it is TimeoutCancellationException) {
                    emit(AdResult.Timeout)
                }
            }.map {
                if(it is AdResult.Success) {
                    val adList = HisavanaSdkManager.getInstance().filterInstalledApp(it.adList, SceneCode.RC_X, "")
                    if(!adList.isNullOrEmpty()) {
                        LogUtils.d(TAG, "collection loadCacheAd is $adList")
                        AdResult.FilterSuccess(adList)
                    } else {
                        AdResult.Error(null)
                    }
                } else {
                    AdResult.Error(null)
                }
            }.flowOn(Dispatchers.Main)
    }

    @OptIn(FlowPreview::class)
    private fun loadEwAd(): Flow<AdResult> {
        val interval = if(DEBUG) {
            3000
        } else {
            1000
        }
        LogUtils.d(TAG, "load live Ad start： timeout：$interval")
        return HisavanaSdkManager.getInstance()
            .loadAd(SceneCode.RC_X, CommonUtils.generateSerialNum(), 0, 0)
            .timeout(interval.toDuration(DurationUnit.MILLISECONDS))
            .catch {
                LogUtils.d(TAG, "exception=$it")
                if (it is TimeoutCancellationException) {
                    emit(AdResult.Timeout)
                }
            }.map {
                if(it is AdResult.Success) {
                    val adList = HisavanaSdkManager.getInstance().filterInstalledApp(it.adList, SceneCode.RC_X, "")
                    if(!adList.isNullOrEmpty()) {
                        LogUtils.d(TAG, "collection loadAd is $adList")
                        AdResult.FilterSuccess(adList)
                    } else {
                        LogUtils.d(TAG, "collection loadAd is empty")
                        AdResult.Error(null)
                    }
                } else {
                    AdResult.Error(null)
                }
            }.flowOn(Dispatchers.Main)
    }

    private fun insertAdToCollectionData(
        liveEw: MutableList<FeatureItemData>?,
        cacheEw: MutableList<FeatureItemData>,
        featuredModel: FeaturedModel
    ): FeaturedModel {
        val posArray = HisavanaSdkManager.getInstance().getAdPosArray(SceneCode.RC_X)

        if(posArray == null || posArray.size <= 0) {
            return featuredModel
        }
        // 用于标记当前已替换过最后一个的位置
        var posIndex = -1
        LogUtils.d(TAG, "live ew insert liveEw: $posIndex  ${posArray.size}")
        posIndex = insertEwToFeatureList(liveEw, featuredModel, posArray, posIndex)
        LogUtils.d(TAG, "cache ew insert cacheEw:$posIndex  ${posArray.size}")
        if(posIndex < posArray.size) {
            insertEwToFeatureList(cacheEw, featuredModel, posArray, posIndex)
        }

        if (featuredModel.beddingData != null) {
            LogUtils.d(TAG, "live ew insert bedding")
            val list : MutableList<String> = mutableListOf()
            TRHomeUtil.doBeddingData(
                featuredModel,
                null,
                list,
                SceneCode.RC_X,
                if (featuredModel.isCache) HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1 else HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0
            )

        }
        return featuredModel
    }

    private fun insertEwToFeatureList(
        adList: MutableList<out FeatureBaseData>?,
        featuredModel: FeaturedModel,
        posArray: MutableList<Pair<Int, Int>>,
        insertIndex: Int
    ): Int {
        var posIndex = insertIndex
        adList?.takeIf { it.isNotEmpty() }?.forEach { adItem ->
            if (adItem is FeatureItemData) {
                posArray.forEachIndexed { index, position ->
                    if(index> posIndex) {
                        if (tryInsertAdAtPosition(adItem, featuredModel, position)) {
                            posIndex = index
                            return@forEach // 跳出内层循环，处理下一个广告
                        }
                    }
                }
            }
        }
        return posIndex
    }

    private fun tryInsertAdAtPosition(
        adItem: FeatureItemData,
        featuredModel: FeaturedModel,
        position: Pair<Int, Int>
    ): Boolean {
        if (position.first >= featuredModel.featureList.size) return false

        val targetFeature = featuredModel.featureList[position.first]
        val dataList = targetFeature.dataList ?: return false

        if (position.second > dataList.size) return false

        val featureIdList = adItem.ewFeatureIdList ?: emptyList()
        if(adItem.tNativeInfo == null) {
            if (!featureIdList.contains(targetFeature.featureId)) return false
        }
        // 执行插入操作
        performAdInsertion(adItem, dataList, position, featuredModel)
        return true
    }

    private fun performAdInsertion(
        adItem: FeatureItemData,
        dataList: MutableList<FeatureBaseData>,
        position: Pair<Int, Int>,
        featuredModel: FeaturedModel
    ) {
        adItem.topicPlace = position.first.toString()
        adItem.placementId = position.second.toString()

        // 设置报告信息
        adItem.reportDto = ReportBean().apply {
            reportSource = if (adItem.tNativeInfo != null) {
                REPORT_SOURCE_EW
            } else {
                REPORT_SOURCE_BEDDING.also {
                    adItem.beddingAb = featuredModel.beddingAb
                    varId = adItem.beddingAb
                }
            }
        }
        if(position.second < dataList.size) {
            val originalItem = dataList[position.second]
            LogUtils.d(TAG, "row:${position.first}, col:${position.second}, item:${adItem.name}, originalItem:${originalItem.name}, ${adItem.reportDto.reportSource}")
            dataList[position.second] = adItem
            dataList.add(originalItem)
        } else {
            dataList.add(adItem)
        }
    }

    private fun filterRepeat(
        liveEw: MutableList<FeatureItemData>?, cacheEw: MutableList<FeatureItemData>?,
        featuredModel: FeaturedModel
    ) {

        // 实时ew针对缓存ew，合集应用、兜底应用去重
        liveEw?.forEach { ew ->
            run {
                val iterator = cacheEw?.iterator()
                iterator?.apply {
                    while (hasNext()) {
                        val data = next()
                        if (data.packageName == ew.packageName) {
                            LogUtils.d(TAG, "ew cache data is repeat, filterRepeat: ${data.name}")
                            //ew广告去重埋点
                            TRAnalysticsUtil.trackEwFilterInstalled(
                                SceneCode.RC_X,
                                TRAnalyticsConstant.ERROR_MSG_APP_REPEAT,
                                data.packageName
                            )
                            remove()
                        }
                    }
                }
                val featureData = featuredModel.featureList
                featureData.forEach {
                    val featureIterator = it.dataList.iterator()
                    while (featureIterator.hasNext()) {
                        val data = featureIterator.next()
                        if (data is FeatureItemData) {
                            if (data.packageName == ew.packageName) {
                                LogUtils.d(
                                    TAG,
                                    "ew collect data is repeat, filterRepeat: ${data.name}"
                                )
                                featureIterator.remove()
                            }
                        }
                    }
                }
                val beddingIterator = featuredModel.beddingDataList?.iterator()
                beddingIterator?.apply {
                    while (hasNext()) {
                        val data = next()
                        if (data is FeatureItemData) {
                            if (data.packageName == ew.packageName) {
                                LogUtils.d(
                                    TAG,
                                    "ew bedding data is repeat, filterRepeat: ${data.name}"
                                )
                                remove()
                            }
                        }
                    }
                }
            }
        }

        cacheEw?.forEach { ew ->
            run {
                val featureData = featuredModel.featureList
                featureData.forEach {
                    val featureIterator = it.dataList.iterator()
                    while (featureIterator.hasNext()) {
                        val data = featureIterator.next()
                        if (data is FeatureItemData) {
                            if (data.packageName == ew.packageName) {
                                LogUtils.d(
                                    TAG,
                                    "cache collect data is repeat, filterRepeat: ${data.name}"
                                )
                                featureIterator.remove()
                            }
                        }
                    }
                }
                val beddingIterator = featuredModel.beddingDataList?.iterator()
                beddingIterator?.apply {
                    while (hasNext()) {
                        val data = next()
                        if (data is FeatureItemData) {
                            if (data.packageName == ew.packageName) {
                                LogUtils.d(
                                    TAG,
                                    "cache bedding data is repeat, filterRepeat: ${data.name}"
                                )
                                remove()
                            }
                        }
                    }
                }
            }
        }

        filterRepeatWithSet(featuredModel)
    }

    // 参考首页兜底插入， 与h_fe重复则选择下一个。 故兜底与合集应用重复，则兜底去重
    private fun filterRepeatWithSet(featuredModel: FeaturedModel) {
        // 先收集所有 featureList 中的 packageName
        val packageNames = mutableSetOf<String>()
        featuredModel.featureList?.forEach { featureBean ->
            featureBean.dataList?.forEach { data ->
                if (data is FeatureItemData) {
                    packageNames.add(data.packageName)
                }
            }
        }
        // 一次性遍历 beddingDataList 进行去重
        val beddingIterator = featuredModel.beddingDataList?.iterator()
        while (beddingIterator?.hasNext() == true) {
            val beddingDataItem = beddingIterator.next()
            if (beddingDataItem is FeatureItemData) {
                if (packageNames.contains(beddingDataItem.packageName)) {
                    LogUtils.d(TAG, "collect bedding data is repeat, filterRepeat: ${beddingDataItem.name}")
                    beddingIterator.remove()
                }
            }
        }
    }

    private fun FeaturedModel.getBeddingDataList(): FeaturedModel {
        if (beddingData != null) {
            val gson = Gson()
            beddingDataList = gson.fromJson(beddingData,
                object : TypeToken<List<FeatureItemData?>?>() {}.type)
            val iterator = beddingDataList.iterator()
            while (iterator.hasNext()) {
                val data = iterator.next()
                if (data is FeatureItemData) {
                    if (PackageUtil.isInstalled(data.isVa, data.packageName)) {
                        LogUtils.d(TAG, "remove beddingDataList:" + data.packageName +"  isVa:" + data.isVa)
                        iterator.remove()
                    } else {
                        if (data.reportDto == null) {
                            data.reportDto = ReportBean()
                        }
                        data.reportDto.traceId = this.tid
                    }
                }
            }
        }
        TRHomeUtil.resetVaStatus4FeaturedModel(this)
        return this
    }

    /**
     * 去掉一行不能展示4个的
     */
    private fun removeTail(mFeatureBean: FeatureBean?) {
        LogUtils.d(TAG, "removeTail")
        if (mFeatureBean?.dataList == null || mFeatureBean.dataList.isEmpty()) return
        var size = mFeatureBean.dataList.size
        val showAmount = min(mFeatureBean.showAmount, 12)
        if (size > showAmount) {
            mFeatureBean.dataList = mFeatureBean.dataList.subList(0, showAmount)
        }
        size = mFeatureBean.dataList.size
        if (mFeatureBean.style == Constant.ONE_CLICK_HORIZONTAL_4 && size % 4 != 0) {
            mFeatureBean.dataList = mFeatureBean.dataList.subList(0, size - size % 4)
        }
    }

    /**
     * 移除已安装的应用
     * @param mFeatureBean
     */
    private fun removeListInstalled(mFeatureBean: FeatureBean?) {
        if (mFeatureBean == null) return
        LogUtils.d(TAG, "专题-----" + mFeatureBean.name + "---------是否移除------" + mFeatureBean.filterInstalled)
        if (mFeatureBean.dataList != null && mFeatureBean.dataList.size > 0) {
            val iterator = mFeatureBean.dataList.iterator()
            while (iterator.hasNext()) {
                val data = iterator.next()
                if (data is FeatureItemData) {
                    val firstPkg = data.packageName
                    val firstVersionCode = data.versionCode
                    if (PackageUtil.isInstalled(data.isVa, firstPkg, firstVersionCode)) {
                        LogUtils.d(TAG, "已移除-----$firstPkg")
                        iterator.remove()
                    }
                }
            }
        }
    }

    private fun processSuccessState(
        featuredModel: FeaturedModel,
        liveEw: DataState,
        cacheEw: DataState
    ): DataState {
        hasInflated = true
        var liveEwDatas: MutableList<FeatureItemData> = mutableListOf()
        var cacheEwDatas: MutableList<FeatureItemData> = mutableListOf()

        if (liveEw is DataState.AdSuccess) {
            liveEwDatas = liveEw.ads.toMutableList()
        }
        if (cacheEw is DataState.AdSuccess) {
            cacheEwDatas = cacheEw.ads.toMutableList()
        }

        filterRepeat(liveEwDatas, cacheEwDatas, featuredModel)
        insertAdToCollectionData(liveEwDatas, cacheEwDatas, featuredModel)
        featuredModel.filter()

        return DataState.Success(featuredModel)
    }


    private fun resolveUiState(
        cache: DataState,
        collection: DataState,
        liveEw: DataState,
        cacheEw: DataState,
        isLoading: Boolean
    ): DataState {
        return when {
            // 2个都是初始值；缓存为空，网络数据是初始值；缓存是初始值，网络数据为空
            // 总结，至少一个在初始化，另一个无效
            ((cache is DataState.Init && collection is DataState.Init)
                    || (cache is DataState.Empty && collection is DataState.Init)
                    || (cache is DataState.Init && collection is DataState.Empty)
                    || (liveEw is DataState.Init || cacheEw is DataState.Init))-> {
                if (isLoading) {
                    DataState.Loading
                } else {
                    DataState.Init
                }
            }

            // 缓存先返回且有效
            cache is DataState.Success && collection is DataState.Init -> {
                processSuccessState(cache.data, liveEw, cacheEw)
            }

            // 网络数据先返回且有效
            collection is DataState.Success && cache is DataState.Init -> {
                processSuccessState(collection.data, liveEw, cacheEw)
            }

            // 两者都有数据，优先网络
            cache is DataState.Success && collection is DataState.Success && !hasInflated -> {
                processSuccessState(collection.data, liveEw, cacheEw)
            }

            // 两者都有数据，缓存有效
            cache is DataState.Success && collection is DataState.Empty && !hasInflated -> {
                processSuccessState(cache.data, liveEw, cacheEw)
            }

            // 两者都有数据，网络有效
            cache is DataState.Empty && collection is DataState.Success && !hasInflated -> {
                processSuccessState(collection.data, liveEw, cacheEw)
            }

            // 两者都无数据
            cache is DataState.Empty && collection is DataState.Empty && !hasInflated -> {
                hasInflated = true
                if (NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                    DataState.Empty
                } else {
                    DataState.NetworkError
                }
            }

            // 默认忽略
            else -> {
                if (hasInflated) { // 复用上次的值，上层因为去重不会收到这个
                    uiState.value
                } else {
                    DataState.Init
                }
            }
        }
    }

    private fun updateCache(data: FeaturedModel, tabId: String) {
        localRepo.saveCache(data, tabId)
    }

    fun initParams(intent: Intent, mPageParamInfo: PageParamInfo) {
        mValue = TRStringUtil.generateString(TRAnalyticsConstant.COLLECTION_PAGE, "", "", "")
        this.mPageParamInfo = mPageParamInfo
        val bundle = intent.extras
        if (bundle != null) {
            mTabId = bundle.getString(PageConstants.PAGE_KEY_TAB_ID)?:""
            mFromSite = bundle.getString(TRAnalyticsConstant.FROM_SITE)?:""
            mFromPage = bundle.getString(Constant.FROMPAGE) ?:""
            mInApp = bundle.getString(PageConstants.PAGE_KEY_INAPP)?:"0"
            mPageParamInfo.setLastPage(bundle.getString(PageConstants.PAGE_KEY_LASTPAGE))
            mPageParamInfo.setCurPage(mValue)
            mPageParamInfo.setTabId(mTabId)
            mFrom = bundle.getString("value")?:mValue
        }
    }

}
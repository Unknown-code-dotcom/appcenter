package com.afmobi.palmplay.activate;

import android.annotation.SuppressLint;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.acpush.notify.AcPushNotifyHelper;
import com.afmobi.palmplay.acpush.repo.AcPushUpdateRepository;
import com.afmobi.palmplay.appnext.AppNextCacheManager;
import com.afmobi.palmplay.cache.AdCache;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.InstalledAppsUpdateCache;
import com.afmobi.palmplay.cache.PreCacheManager;
import com.afmobi.palmplay.cloudfolder.CloudFolderManager;
import com.afmobi.palmplay.clean.ScanManager;
import com.afmobi.palmplay.download.gp.GPDownloadManager;
import com.afmobi.palmplay.h5.offline.H5OfflineGameManager;
import com.afmobi.palmplay.h5.offline.H5OfflineManager;
import com.afmobi.palmplay.h5.offline.instant.InstantOfflineGameManager;
import com.afmobi.palmplay.halfdetail.HalfDetailRecommendManager;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.main.utils.PSNotificationManager;
import com.afmobi.palmplay.manager.DefaultStoreGuideManager;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.network.DownloadInstallRecordTask;
import com.afmobi.palmplay.network.data.IDataPoolHandleImpl;
import com.afmobi.palmplay.notify.NotificationInstallCompleteManager;
import com.afmobi.palmplay.pluto.GetRemindMessageTask;
import com.afmobi.palmplay.push.TRPushMsgsManager;
import com.afmobi.palmplay.quickinstall.PreInstallManager;
import com.afmobi.palmplay.recommendinstall.TRInstallManager;
import com.afmobi.palmplay.repo.RemoteConfigRepo;
import com.afmobi.palmplay.search.v6_4.offline.OfflineSearchManager;
import com.afmobi.palmplay.social.whatsapp.WhatsStorage;
import com.afmobi.palmplay.stub.StubManager;
import com.afmobi.palmplay.sun.scan.ScanTask;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.GdprTrackUtil;
import com.android.hundsup.Constants;
import com.android.hundsup.PushService;
import com.android.hundsup.utils.StorageUtils;
import com.afmobi.util.MiniAppSupportChecker;
import com.store.component.attribute.AttributeUpload;
import com.transsion.ga.AthenaAnalytics;
import com.store.component.pm.attribution.PMAttributionJobManager;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.SystemUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.palmstorecore.util.crash.WatchDogConfig;
import com.transsion.xwebview.asyncclick.UrlAsyncClickLogic;
import com.transsnet.launcherlib.applaction.ExternalServiceInitializer;
import com.transsnet.launcherlib.services.DispenseDataManager;
import com.transsnet.store.BuildConfig;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Schedulers;

/***
 * created by yongli.li
 * 通用jobService
 */
@SuppressLint("SpecifyJobSchedulerIdRange")
public class TRDataJobService extends JobService {
    private static final int JOB_ID = 200;
    private static final long LATENCY_TIME = BuildConfig.DEBUG ? 60 * 1000L : 60 * 60 * 1000L;//间隔时间

    private static final long MAX_OFFSET = 30 * 60 * 1000L;

    private static final long mIntervalTime = 60 * 1000L;
    private static long mHandleBusinessTime = 0L;
    private static int sNotifySwitchStatus = -1;

    private static String[] activateTyps = new String[]{
            TRActivateConstant.SPLASH_AD,//开屏活动
            TRActivateConstant.TIP_ACTIVATE,//应用内四种活动
            TRActivateConstant.GIFT_RAIN //红包雨
    };

    @Override
    public void onCreate() {
        super.onCreate();
    }

    /***
     * 处理业务代码
     */
    private static void handleBusiness() {
        if (BuildConfig.DEBUG) {
            LogUtils.e("TRDataJobService", "----handleBusiness----");
        }
        AttributeUpload.getInstance().uploadOffer();
        ScanManager.getInstance().scan();

        LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "TRDataJobService handleBusiness: ");
        TRManager.getInstance().loadDataDirectly(activateTyps);
        if(AdCache.getInstance().isNeedPreLoad()) {
            AdCache.getInstance().onPreLoadAd();
        }
      //  ConfigManager.getInstance().fetchConfigInfo();//获取配置信息

        // 9.3.2合并指令下发&StartUp接口
        RemoteConfigRepo.INSTANCE.queryUpdateOrderAndStartUp();

        //定时清理过期通知
        PSNotificationManager.getInstance().clearOverTimeNotification();

        UrlAsyncClickLogic.handleAsyncCLickCacheTask(ConfigManager.getAsyncRetryCount(),
                ConfigManager.getHandReportRetryCount());//处理归因失败缓存的任务

        GetRemindMessageTask.getInstance().getRemindMessage();
        new ScanTask().doWork(PalmplayApplication.getAppInstance());
        TRInstallManager.loadInstallData();
        AppNextCacheManager.getInstance().handleAppNextCacheLogic();
        //ToolManager.handleToolSudokuConfig(false);

        DetailCacheManager.getInstance().preloadAppDetail(Constant.SOURCE_SCHEDULE);
        LogUtils.d("OfflineSearch", "fetchSearchOfflineData: job");
        OfflineSearchManager.getInstance().fetchSearchOfflineData();

        DownloadInstallRecordTask.getInstance().onMsgStart(); //todo 触发下载安装埋点上报

        GPDownloadManager.getInstance().filterInvalideGPDownloadData();

        //todo  PalmS内部场景尾量停投接口请求
       // TailStopManager.getInstance().loadTailStopApi(false);
        //请求deeplink任务
       // DeeplinkManager.getDeeplinkManager().requestDeeplink(false);
        //定时轮训请求H5游戏（默认重试间隔是7*24H，失败重试时是24H）
        H5OfflineGameManager.getInstance().scheduleUpdateTask();
        H5OfflineManager.getInstance().downloadH5OfflineTask();
        InstantOfflineGameManager.getInstance().scheduleUpdateTask();
        //检测预缓存是否存在
        PreCacheManager.getInstance().preRequestData();
        //todo 补上报
        GetRemindMessageTask.getInstance().doCheckUploadStatusToServer();

        PreCacheManager.getInstance().preRequestHomeCacheTab();

//        if (!TRApplicationContextUtil.isProject()) {

//            GiftRainManager.getInstance().onGiftRainReportPrize();
//            GiftRainManager.getInstance().preDownloadGiftRain();

//            //召回通知检测逻辑
//            RecallNotifyManager.getInstance().handleRecallNotifyLogic();
//        }

        //检查是否需要强制上报速度
        IDataPoolHandleImpl.getInstance().checkAndPostToAthena();
        if (NotificationExtKt.isSwitchOpen(TRSharedPreferenceUtils.KV_INSTALL_COMPLETE_SWITCH)){
            NotificationInstallCompleteManager.getInstance().handleFilterInvalidateNotifyAppInfo();
        } else {
            TRPushMsgsManager.getInstance().trackPushTechUV("Install", "3", "", "",1, "A");
        }

        InstalledAppsUpdateCache.getInstance().sendCheckAppsUpdateRequest();
        // ===== AC-PUSH: 心跳触发 S/A 高频拉取 + 兜底轮询 DISMISS =====
        try {
            AcPushUpdateRepository.INSTANCE.tick();
            AcPushNotifyHelper.INSTANCE.pollDismiss(PalmplayApplication.getAppInstance());
        } catch (Throwable t) {
            LogUtils.e("AcPush.JobHook", "tick/pollDismiss failed", t);
        }
        // ============================================================


        if (ConfigManager.isEnablePalmSpacePreDownload()) {
            VaStaticProxy.startCheckGameSpaceStatus(TRAnalyticsConstant.GAME_SPACE_FROM_PAGE_AUTO, TRAnalyticsConstant.GAME_SPACE_FROM_PAGE_AUTO, TRAnalyticsConstant.GAME_SPACE_FROM_PAGE_AUTO, ConfigManager.isGameSpaceSilentInstallEnable()).subscribe();
        }
        if (ConfigManager.isGameSpaceEnable()) {
            PsVaManager.getInstance().requestVAConfigPassive();
        }

        WhatsStorage.checkWhatsStatusUpdate(true, "TRDataJobService", "");//检测WhatsStatus是否有更新

        HalfDetailRecommendManager.loadInstallData();


        if (AppDataManager.FEATURE_FILE_FOLDER_SWITCH) {
            ExternalServiceInitializer.fileFolderSwitch = true;
            DispenseDataManager.getInstance().handleDataLogic();
            CloudFolderManager.Companion.getInstance().onCloudFolderIntervalRefresh();
        }
        int tempStatus =  SystemUtils.curSuspendSwitchStatus() ? 1 : 0;
        if(tempStatus != sNotifySwitchStatus) {
            sNotifySwitchStatus = tempStatus;
            TRAnalysticsUtil.trackNotificationStatus(sNotifySwitchStatus);
            if(sNotifySwitchStatus==0) {
                TRSharedPreferenceUtils.setRecommendationsToggle(false);
            }
        }

        MiniAppSupportChecker.checkMiniAppSupport(); // 检查是否支持小程序 定时任务调用，每天读取一次

        GdprTrackUtil.trackGdprStatus();//每天上报一次用户授权状态：GDPR&隐私协议
        DefaultStoreGuideManager.trackDefaultStoreStatus();//每天上报一次设默状态

        PMAttributionJobManager.getInstance().doJob();

        if (AppDataManager.FEATURE_FILE_FOLDER_SWITCH) {
            CloudFolderManager.Companion.getInstance().onCloudFolderIntervalRefresh();
        }

        MiniAppSupportChecker.checkMiniAppSupport();

        startPushService();//启动hungup job

        PreInstallManager.INSTANCE.doJob();

        requestStubAppDownloadPreCheck();

        if (BuildConfig.DEBUG){
            LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "TRDataJobService handleBusiness: end");
        }// 检查是否支持小程序 定时任务调用，每天读取一次
    }

    /**
     * 主线程处理业务
     */
    private static void handleBusinessMain() {
        LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "TRDataJobService handleBusinessMain: ");
        //涉及EW广告-涉及Handler-主线程
        TRManager.getInstance().loadDataDirectly(activateTyps);
        TRInstallManager.loadInstallData();
        //涉及创建Handler-主线程
        DownloadInstallRecordTask.getInstance().onMsgStart(); //todo 触发下载安装埋点上报
        //涉及通知UI-主线程
        if (NotificationExtKt.isSwitchOpen(TRSharedPreferenceUtils.KV_INSTALL_COMPLETE_SWITCH)){
            NotificationInstallCompleteManager.getInstance().handleFilterInvalidateNotifyAppInfo();
        }
    }

    /**
     * 子线程处理业务
     */
    @SuppressLint("CheckResult")
    private static void handleBusinessNoMain() {
        LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "TRDataJobService handleBusinessNoMain: ");
        Observable.fromCallable(() -> {
                    // 这里调用你的业务逻辑方法
                    handleTask();
                    return true;
                })
                .subscribeOn(Schedulers.io())
                .subscribe(result -> {
                    // 处理成功结果
                }, throwable -> {
                    // 处理异常
                });
    }

    public static void startJob(Context context) {
        JobScheduler mJobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (mJobScheduler == null) {
            return;
        }

        try {
            JobInfo info = getJobInfo(context);
            mJobScheduler.schedule(info); //开始定时执行该系统任务
            //handleBusiness();
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        mHandleBusinessTime = System.currentTimeMillis();

    }

    private static JobInfo getJobInfo(@NonNull Context context) {
        String deviceId = AthenaAnalytics.getAppVAID(context);
        long offset = getLatencyOffset(deviceId);
        LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "TRDataJobService deviceId: " + deviceId + " getLatencyOffset: " + offset);
        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID, new ComponentName(context.getPackageName(), TRDataJobService.class.getName()));
        if (Build.VERSION.SDK_INT >= 24) {
            builder.setMinimumLatency(LATENCY_TIME + offset); //执行的最小延迟时间
            builder.setOverrideDeadline(LATENCY_TIME * 2 + offset);  //执行的最长延时时间
        } else {
            builder.setPeriodic(LATENCY_TIME + offset);
        }
        builder.setPersisted(true);  // 设置设备重启时，执行该任务
        builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
        builder.setRequiresCharging(false); // 当插入充电器，执行该任务
        return builder.build();
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        if (BuildConfig.DEBUG) {
            LogUtils.e("TRDataJobService", "----onStartJob----");
        }
        if(WatchDogConfig.crashSwitch){
            //后台运行，且第一次拉起主进程 记录有谁拉起进程
            Observable.fromCallable(() -> {
                if(CommonUtils.isBackOpen(this)){
                    WatchDogConfig.getInstance(this).saveStartUpState(WatchDogConfig.TRDataJobService);
                }
                return null;
            }).subscribeOn(Schedulers.io()).subscribe();

            if(WatchDogConfig.getInstance(this).isNeedRunFuse(WatchDogConfig.DATA_JOP_IS_BACK)){
                LogUtils.d("TRDataJobService", "触发熔断");
                return true;
            }
        }

        LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "TRDataJobService onStartJob handleBusiness: ");
        if (System.currentTimeMillis() - mHandleBusinessTime > mIntervalTime) {
            if (!ConfigManager.catonOptimizationOpen()) {
                //云控卡顿优化开关关闭
                //处理业务代码
                handleBusiness();
            } else {
                //云控卡顿优化开关打开
                //运行在主线程业务
                handleBusinessMain();
                //运行在子线程业务
                handleBusinessNoMain();
            }
        }
        JobScheduler mJobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (mJobScheduler == null) {
            return true;
        }

        try {
            JobInfo info = getJobInfo(this);
            mJobScheduler.schedule(info); //开始定时执行该系统任务
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return false;
    }


    private static void startPushService() {
        if (!ConfigManager.isHgupOpen() || CommonUtils.isNeedDisableByDLC()) {
            LogUtils.d(LogUtils.TAG_HUNDSUP_START_JOB, "TRdataJob == > PushJobService isHgup close or dlc return ... ");
            return;
        }
        LogUtils.d(LogUtils.TAG_HUNDSUP_START_JOB, "PushJobService startPushService ... ");
        if (StorageUtils.isLessThanUsagePercent(Constants.LEAST_REMAIN_MEMORY_PERCENT)) {
            LogUtils.d(LogUtils.TAG_HUNDSUP_START_JOB, "Lack of storage space");
            return;
        }

        try {
            Intent pushIntent = new Intent(PalmplayApplication.getAppInstance(), PushService.class);
            pushIntent.putExtra("source", Constants.SOURCE_JOB_SERVICE);
            PalmplayApplication.getAppInstance().startService(pushIntent);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }


    private static void handleTask() {
        if (BuildConfig.DEBUG) {
            LogUtils.e("TRDataJobService", "----handleTask----");
        }
        AttributeUpload.getInstance().uploadOffer();
        ScanManager.getInstance().scan();

        // 执行具体的任务
        if (AdCache.getInstance().isNeedPreLoad()) {
            AdCache.getInstance().onPreLoadAd();
        }

        // 9.3.2合并指令下发&StartUp接口
        RemoteConfigRepo.INSTANCE.queryUpdateOrderAndStartUp();

        //定时清理过期通知
        PSNotificationManager.getInstance().clearOverTimeNotification();

        UrlAsyncClickLogic.handleAsyncCLickCacheTask(ConfigManager.getAsyncRetryCount(),
                ConfigManager.getHandReportRetryCount());//处理归因失败缓存的任务

        GetRemindMessageTask.getInstance().getRemindMessage();
        new ScanTask().doWork(PalmplayApplication.getAppInstance());

        AppNextCacheManager.getInstance().handleAppNextCacheLogic();
        //ToolManager.handleToolSudokuConfig(false);

        DetailCacheManager.getInstance().preloadAppDetail(Constant.SOURCE_SCHEDULE);
        LogUtils.d("OfflineSearch", "fetchSearchOfflineData: job");
        OfflineSearchManager.getInstance().fetchSearchOfflineData();

        GPDownloadManager.getInstance().filterInvalideGPDownloadData();

        //todo  PalmS内部场景尾量停投接口请求
        // TailStopManager.getInstance().loadTailStopApi(false);
        //请求deeplink任务
        // DeeplinkManager.getDeeplinkManager().requestDeeplink(false);
        //定时轮训请求H5游戏（默认重试间隔是7*24H，失败重试时是24H）
        H5OfflineGameManager.getInstance().scheduleUpdateTask();
        H5OfflineManager.getInstance().downloadH5OfflineTask();
        InstantOfflineGameManager.getInstance().scheduleUpdateTask();
        //检测预缓存是否存在
        PreCacheManager.getInstance().preRequestData();
        //todo 补上报
        GetRemindMessageTask.getInstance().doCheckUploadStatusToServer();

        PreCacheManager.getInstance().preRequestHomeCacheTab();

        //检查是否需要强制上报速度
        if (BuildConfig.DEBUG) {
            LogUtils.e("TRDataJobService", "----checkAndPostToAthena----start----");
        }
        IDataPoolHandleImpl.getInstance().checkAndPostToAthena();
        //检查是否需要强制上报速度
        if (BuildConfig.DEBUG) {
            LogUtils.e("TRDataJobService", "----checkAndPostToAthena----end----");
        }

        InstalledAppsUpdateCache.getInstance().sendCheckAppsUpdateRequest();
        // ===== AC-PUSH: 心跳触发 S/A 高频拉取 + 兜底轮询 DISMISS =====
        try {
            AcPushUpdateRepository.INSTANCE.tick();
            AcPushNotifyHelper.INSTANCE.pollDismiss(PalmplayApplication.getAppInstance());
        } catch (Throwable t) {
            LogUtils.e("AcPush.JobHook", "tick/pollDismiss failed", t);
        }
        // ============================================================


        if (ConfigManager.isEnablePalmSpacePreDownload()) {
            VaStaticProxy.startCheckGameSpaceStatus(TRAnalyticsConstant.GAME_SPACE_FROM_PAGE_AUTO, TRAnalyticsConstant.GAME_SPACE_FROM_PAGE_AUTO, TRAnalyticsConstant.GAME_SPACE_FROM_PAGE_AUTO, ConfigManager.isGameSpaceSilentInstallEnable()).subscribe();
        }
        if (ConfigManager.isGameSpaceEnable()) {
            PsVaManager.getInstance().requestVAConfigPassive();
        }

        WhatsStorage.checkWhatsStatusUpdate(true, "TRDataJobService", "");//检测WhatsStatus是否有更新

        HalfDetailRecommendManager.loadInstallData();

        int tempStatus =  SystemUtils.curSuspendSwitchStatus() ? 1 : 0;
        if(tempStatus != sNotifySwitchStatus) {
            sNotifySwitchStatus = tempStatus;
            TRAnalysticsUtil.trackNotificationStatus(sNotifySwitchStatus);
            if(sNotifySwitchStatus==0) {
                TRSharedPreferenceUtils.setRecommendationsToggle(false);
            }
        }
        AttributeUpload.getInstance().uploadOffer();

        startPushService();//启动hungup job

        requestStubAppDownloadPreCheck();

        if (BuildConfig.DEBUG) {
            LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "handleBusinessNoMain handleTask: end");
        }

        requestStubAppDownloadPreCheck();

        if (BuildConfig.DEBUG) {
            LogUtils.d(LogUtils.TAG_KEEP_ALIVE, "handleBusinessNoMain handleTask: end");
        }

        GdprTrackUtil.trackGdprStatus();//每天上报一次用户授权状态：GDPR&隐私协议
        DefaultStoreGuideManager.trackDefaultStoreStatus();//每天上报一次设默状态

        PMAttributionJobManager.getInstance().doJob();

        CloudFolderManager.Companion.getInstance().onCloudFolderIntervalRefresh();
        PreInstallManager.INSTANCE.doJob();
    }

    private static long getLatencyOffset(String deviceId){
        if (BuildConfig.DEBUG){
            return 0L;
        }

        // 基于设备ID计算固定偏移（0-30分钟）
        long offset = 0L;
        if (!TextUtils.isEmpty(deviceId) && deviceId.hashCode() != 0) {
            int hashCode = Math.abs(deviceId.hashCode());
            offset = hashCode % (MAX_OFFSET);
        }
        return offset;
    }

    //检测stub预装应用是否下架
    private static void requestStubAppDownloadPreCheck() {
        StubManager.INSTANCE.requestStubAppDownloadPreCheck(); //检测stub预装应用是否下架
    }
}

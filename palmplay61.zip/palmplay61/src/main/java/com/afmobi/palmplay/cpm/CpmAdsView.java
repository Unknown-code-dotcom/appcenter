package com.afmobi.palmplay.cpm;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.alonefuction.WebViewActivity;
import com.afmobi.palmplay.configs.ImageConfig;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.FeatureBuilder;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.network.util.RequestParams;
import com.afmobi.palmplay.rank.FeatureSinglePageActivity;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.NetworkState;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.TRJumpUtil;
import com.transsion.palmstorecore.util.UriExtKt;
import com.transsnet.store.R;

import java.net.URLEncoder;

/**
 * CPM广告
 * Created by xiangfei.wei on 2018/7/25.
 */

public class CpmAdsView extends WebView implements View.OnTouchListener {
    private static final String TAG = CpmAdsView.class.getSimpleName();
    private String mAdStyle;
    public String adUrl;
    private ViewGroup mAdParent;
    private boolean initialLoad = true;
    private PageParamInfo mPageParamInfo;

    private float xStart;
    private float xEnd;
    private float yStart;
    private float yEnd;
    private float mXDistance;
    private float mYDistance;
    private float clickRange;

    private boolean isError;

    public CpmAdsView(Context context, String adStyle, String adUrl, ViewGroup parent, PageParamInfo pageParamInfo) {
        super(context);
        mAdStyle = adStyle;
        this.adUrl = adUrl;
        mAdParent = parent;
        mPageParamInfo = pageParamInfo;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);//禁止硬件加速，解决WebView在列表中刷新列表时候WebView闪烁
        clickRange = ViewConfiguration.get(getContext()).getScaledTouchSlop();//DisplayUtil.dip2px(context, 15);
        init();
    }

    public CpmAdsView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CpmAdsView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public CpmAdsView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    private void init() {
        if (AdStyle.TOP.equalsIgnoreCase(mAdStyle)) {
            setOnTouchListener(this);
        } else if (AdStyle.LIST.equalsIgnoreCase(mAdStyle)) {
            setOnTouchListener(null);
        }
        setInitialScale(getScale(getContext()));//sk add
        setHorizontalScrollBarEnabled(false);
        setVerticalScrollBarEnabled(false);
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(false);  //设置可以访问文件
        settings.setAllowFileAccessFromFileURLs(false);//是否允许运行在一个URL环境中的JavaScript访问来自其他URL环境的内容
        settings.setAllowUniversalAccessFromFileURLs(false);
        //settings.setNeedInitialFocus(true); //当webview调用requestFocus时为webview设置节点
        settings.setJavaScriptCanOpenWindowsAutomatically(true); //支持通过JS打开新窗口
        settings.setLoadsImagesAutomatically(true);  //支持自动加载图片
        settings.setDefaultTextEncodingName("UTF-8");//设置编码格式
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        settings.setDomStorageEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);
        addJavascriptInterface(this, "cpmAd");
        setWebViewClient(adWebViewClient);
        setWebChromeClient(adWebChromeClient);
        loadUrl(adUrl, true);

    }
    private int getScale(Context context) {
        WindowManager wm = (WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        int width = display.getWidth();
        int defaultDivider = 720;
        float value = width * 1f / defaultDivider;
        value *= 100f;
        return (int) value;
    }
    private void addExtraParams() {
        RequestParams params = PhoneDeviceInfo.getCommonRequestParams();
        params.put(PageConstants.PAGE_KEY_LASTPAGE, URLEncoder.encode(mPageParamInfo.getLastPage()));
        params.put(PageConstants.PAGE_KEY_CURPAGE, URLEncoder.encode(mPageParamInfo.getCurPage()));
        //2070301 6.4版本
        // H5带入参数：IMEI、IMSI、位置信息、联网方式、分辨率信息、终端品牌信息

        int screenWidth = DisplayUtil.getScreenWidthPx(getContext());
        int screenHeight = DisplayUtil.getScreenHeightPx(getContext());
        params.put("display", screenWidth + "*" + screenHeight);
        if (!adUrl.contains("noChangePage")) {
            if (!UriExtKt.isHttpOrHttps(adUrl)) {
                adUrl = "https://" + adUrl;
            }
            if (!adUrl.contains("?")) {
                adUrl += "?";
            } else if (!adUrl.endsWith("&")) {//只有一个参数的情况有问题
                adUrl += "&";
            }
            String extraParams = params.toString();
            adUrl += extraParams;
        }
    }

    public void loadUrl(String url, boolean addCommonParams) {
        if (TextUtils.equals(NetworkState.UNAVAILABLE, NetworkUtils.getNetworkState(getContext()))) {
            return;
        } else {
            // LogUtils.e(TAG, "-------------------adUrl = " + url);
            adUrl = url;
            isError = false;
            if (addCommonParams) {
                addExtraParams();
            }
            super.loadUrl(adUrl);
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // LogUtils.e("CPMView", "-------------------------------onTouch =" + event.getAction());
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                xStart = event.getX();
                yStart = event.getY();
                break;

            case MotionEvent.ACTION_MOVE:
                break;

            case MotionEvent.ACTION_UP:
                xEnd = event.getX();
                yEnd = event.getY();
                handleTouchEvent();
                break;

            case MotionEvent.ACTION_CANCEL:
                xEnd = event.getX();
                yEnd = event.getY();
                handleTouchEvent();
                break;
        }
        return true;
    }

    private void handleTouchEvent() {
        mXDistance = xEnd - xStart;
        mYDistance = yEnd - yStart;
        // LogUtils.e("CPMView", "------------------------------mXDistance = " + mXDistance + ",  mYDistance =" + mYDistance);
        if (Math.abs(mXDistance) < clickRange && Math.abs(yEnd - yStart) < clickRange) {
            loadUrl("javascript:clickFun()");
        } else if (mXDistance > clickRange) {
            loadUrl("javascript:swiper.slidePrev(true, 300)");
        } else if (mXDistance < -clickRange) {
            loadUrl("javascript:swiper.slideNext(true, 300)");
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (mAdParent != null) {
            mAdParent = null;
        }
    }

    public WebViewClient adWebViewClient = new WebViewClient() {

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            //LogUtils.e(TAG, "------------------------------------------onReceivedError(old) errorCode=" + errorCode);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) return;
            isError = true;
        }

        @TargetApi(Build.VERSION_CODES.M)
        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            //LogUtils.e(TAG, "------------------------------------------onReceivedError(new) errorCode=" + error.getErrorCode());
            if (request.isForMainFrame() || request.getUrl().toString().equalsIgnoreCase(getUrl())) {
                isError = true;
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            //LogUtils.e(TAG, "----------------------------CpmAdsView onPageFinished; style = " + mAdStyle.name());
        }
    };

    public WebChromeClient adWebChromeClient = new WebChromeClient() {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            //LogUtils.e(TAG, "-----------------------------onProgressChanged = " + newProgress);
            if (100 == newProgress) {
                if (!isError) {
                    if (mAdParent != null && initialLoad) {
                        initialLoad = false;
                        //LogUtils.e(TAG, "----------------------------CpmAdsView onPageFinished; style = " + mAdStyle.name());
                        View childView = mAdParent.getChildAt(0);
                        if (childView != null && !(childView instanceof WebView)) {
                            mAdParent.removeAllViews();
                        }
                        if (mAdParent.getChildCount() == 0) {
                            if (getParent() == null) {
                                try {
                                    mAdParent.addView(CpmAdsView.this);
                                } catch (Throwable e) {
                                    //ignore
                                }
                                setBackgroundColor(0);
                                CpmAdsView.this.setBackgroundColor(PalmplayApplication.getAppInstance().getResources().getColor(R.color.def_bg_color_01));
                            }
                            if (AdStyle.LIST.equalsIgnoreCase(mAdStyle)) {
                                //mAdParent.setPadding(0, 0, 0, DisplayUtil.dip2px(getContext(), 8));
                                int screenWidth = DisplayUtil.getScreenWidthPx(getContext());
                                int headerHeight = ImageConfig.getBannerImageHeight(screenWidth);
                                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) getLayoutParams();
                                params.width = screenWidth;
                                params.height = headerHeight;
                                params.bottomMargin = DisplayUtil.dip2px(getContext(), 8);
                                setLayoutParams(params);
                            }
                        }
                    }
                }
            }
        }
    };

    /**
     * 打开Palmstore内部的WebView页面
     *
     * @param url
     */
    @JavascriptInterface
    public void goToInnerBrowser(final String url, final String currentPage) {
        post(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getContext(), WebViewActivity.class);
                intent.putExtra("WebSite", url);
                intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, currentPage);
                intent.putExtra(PageConstants.PAGE_KEY_CURPAGE, currentPage);
                try {
                    getContext().startActivity(intent);
                }catch (Throwable e) {}
            }
        });
    }

    /**
     * 打开App详情页；
     *
     * @param itemName
     * @param itemId
     * @param packageName
     * @param currentPage
     */
    @JavascriptInterface
    public void goToAppDetailPage(final String itemName, final String itemId, final String packageName, final String currentPage) {
        post(new Runnable() {
            @Override
            public void run() {
                AppBuilder appBuilder = new AppBuilder()
                        .setAppName(itemName)
                        .setItemId(itemId)
                        .setPackageName(packageName)
                        .setFromPage(currentPage)
                        .setLastPage(currentPage)
                        .setUri(null)
                        .setValue("")
                        .setTaskId(0)
                        .setAutoDownload(false);
                TRJumpUtil.switcToAppDetailOptions(getContext(), appBuilder);
            }
        });
    }

    /**
     * 打开专题详情页
     *
     * @param itemType SOFT；
     * @param rankName rank name；
     * @param rankId
     */
    @JavascriptInterface
    public void goToRankDetailPage(final String itemType, final String rankName, final String rankId, final String currentPage) {
        post(new Runnable() {
            @Override
            public void run() {
                FeatureBuilder builder = new FeatureBuilder()
                        .setDetailType(itemType)
                        .setName(rankName)
                        .setRankID(rankId)
                        .setFromPage(currentPage)
                        .setLastPage(currentPage)
                        .setValue("");
                FeatureSinglePageActivity.switchToFeatureSinglePageActivity(getContext(), builder);
            }
        });
    }

    public interface AdStyle {
        String TOP = "TOP";
        String LIST = "LIST";
    }
}

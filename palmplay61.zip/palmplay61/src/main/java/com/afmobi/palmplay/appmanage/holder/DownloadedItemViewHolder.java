package com.afmobi.palmplay.appmanage.holder;

import android.app.Activity;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.adapter.FileManageDownloadAdapter;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler;
import com.afmobi.palmplay.social.whatsapp.utils.ClickUtils;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.NotificationUtil;
import com.afmobi.util.TRNoDoubleClickListener;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.DownloadedItemBinding;

import java.util.List;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 下载完成模块的ViewHolder
 * Created by xiangfei.wei on 2018/12/21.
 */
public class DownloadedItemViewHolder extends RecyclerView.ViewHolder {

    private Activity mActivity;
    private FileManageDownloadAdapter mAdapter;
    private PageParamInfo mPageParamInfo;
    private DownloadedItemBinding binding;
    private FileDownloadInfo fileDownloadInfo;
    public String mFrom;//新型打点的from值

    public DownloadedItemViewHolder(View itemView) {
        super(itemView);
        binding = DataBindingUtil.getBinding(itemView);
        if (binding != null) {
            binding.setHolder(this);
        }
    }

    public DownloadedItemViewHolder setContext(Context context) {
        mActivity = (Activity) context;
        return this;
    }

    public DownloadedItemViewHolder setAdapter(FileManageDownloadAdapter adapter) {
        mAdapter = adapter;
        return this;
    }

    public DownloadedItemViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        mPageParamInfo = pageParamInfo;
        return this;
    }
    public DownloadedItemViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }
    public void bind(final FileDownloadInfo info) {
        if (binding == null) {
            return;
        }
        fileDownloadInfo = info;
        if (info != null) {
            binding.setInfo(info);
            binding.executePendingBindings();
            int defaultIcon = R.drawable.layer_list_app_default_01_bg;
            GlideUtils.setImageUrl(binding.ivIcon, info.iconUrl, defaultIcon, defaultIcon);
            binding.tvVersion.setText(TextUtils.isEmpty(info.versionName)
                    ? "" : CommonUtils.replace(PalmplayApplication.getAppInstance().getString(R.string.versionname_prefix), CommonUtils.TARGET_NAME, info.versionName));
            int observerStatus = DownloadStatusManager.getInstance().getObserverStatus(fileDownloadInfo, fileDownloadInfo.downloadStatus);
            CommonUtils.checkStatusItemDisplay(fileDownloadInfo, observerStatus, binding.idStateview, null, null,false,fileDownloadInfo.packageName,fileDownloadInfo.itemID);
            binding.layoutContent.setOnClickListener(mOnInstallClickListener);

            if(fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isSpaceLimit) {
                binding.layoutDownloading.setVisibility(View.GONE);
                binding.tvSpaceLimit.setVisibility(View.VISIBLE);
                String dstStr = PalmplayApplication.getAppInstance().getString(R.string.disk_space_not_enough_tips_title);
                binding.tvSpaceLimit.setText(dstStr);
            } else if (fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isInstallFail && !fileDownloadInfo.extraInfo.isRetryInstallFail) {
                binding.layoutDownloading.setVisibility(View.GONE);
                binding.tvInstallFail.setVisibility(View.VISIBLE);
                String err = CommonUtils.getInstallFailMsg(fileDownloadInfo.extraInfo.installErrorCode);
                binding.tvInstallFail.setText(err);
                binding.idStateview.setText(R.string.text_retry);
            } else {
                binding.layoutDownloading.setVisibility(View.VISIBLE);
                binding.tvSpaceLimit.setVisibility(View.GONE);
                binding.tvInstallFail.setVisibility(View.GONE);
            }
        } else {
            binding.layoutContent.setVisibility(View.GONE);
        }
        if (fileDownloadInfo != null && fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isInstallFail) {
            if (!info.hasTrack) {
                info.hasTrack = true;
                String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "SF", "", "");
                ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId("")
                        .setItemType(fileDownloadInfo.extraInfo.detailType)
                        .setItemId(fileDownloadInfo.itemID)
                        .setItemValue(fileDownloadInfo.packageName);
                TRAnalysticsUtil.trackExposure(builder);
            }
        }
    }

    private TRNoDoubleClickListener mOnInstallClickListener = new TRNoDoubleClickListener(600) {
        @Override
        public void onNoDoubleClick(View v) {
            boolean isFastClick = ClickUtils.isFastClick();
            if (isFastClick) {
                return;
            }
            onItemLayoutClick(v);
        }
    };

    public void onItemLayoutClick(View view) {
        if(fileDownloadInfo!=null && TextUtils.isEmpty(fileDownloadInfo.downloadUrl)) {
            if(mActivity == null || mActivity.isDestroyed() || mActivity.isFinishing()) {
                return;
            }
            DialogBuilder mDialogBuilder = new DialogBuilder();
            new CustomDialog(mActivity).showCheckBoxFunctionDialog(mDialogBuilder.hideTitle().setMessage(PalmplayApplication.getAppInstance()
                    .getString(R.string.cannot_installed_file_on_device)).hideCheckBox()
                    .setNegativeBtnText(PalmplayApplication.getAppInstance()
                            .getString(R.string.text_ignore))
                    .setPositiveBtnText(PalmplayApplication.getAppInstance()
                            .getString(R.string.text_delete)).setPositiveBtnOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DownloadManager.getInstance().removeDownloadedInfo(fileDownloadInfo.packageName);
                    if(mAdapter!=null) {
                        mAdapter.handleInstallingListInfo(true);
                    }
                }
            }));
        } else {
            if(fileDownloadInfo != null && fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isSpaceLimit) {
                fileDownloadInfo.extraInfo.isSpaceLimit = false;
            }
            DownloadDecorator.clickDownloadedInfo(mActivity, fileDownloadInfo, mPageParamInfo);
        }

        if (fileDownloadInfo != null && fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isInstallFail) {
            String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "SF", "", "");
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setButtonType(TRAnalyticsConstant.BUTTON_RETRY)
                    .setItemType(fileDownloadInfo.extraInfo.detailType)
                    .setItemId(fileDownloadInfo.itemID)
                    .setItemValue(fileDownloadInfo.packageName);
            TRAnalysticsUtil.trackClick(builder);
        }
    }

    public void onDropDownBtnClick() {
        boolean state = binding.ibDropdown.isSelected();
        binding.ibDropdown.setSelected(!state);

        binding.ibOperator.setVisibility(state ? View.GONE : View.VISIBLE);
    }

    public void onDeleteClick() {
        deleteQueryDialog(fileDownloadInfo);
    }


    private void deleteQueryDialog(final FileDownloadInfo info) {
        if (info == null) {
            return;
        }

        final DialogBuilder mDialogBuilder = new DialogBuilder();

        mDialogBuilder.setTitle(PalmplayApplication.getAppInstance().getResources().getString(R.string.dialog_title_delete_app))
                .setMessage(PalmplayApplication.getAppInstance().getResources().getString(R.string.dialog_content_delete_app));

        new CustomDialog(mActivity).showCheckBoxFunctionDialog(
                mDialogBuilder
                        .hideCheckBox()
                        .setNegativeBtnText(PalmplayApplication.getAppInstance().getResources().getString(R.string.text_cancel))
                        .setPositiveBtnText(PalmplayApplication.getAppInstance().getResources().getString(R.string.text_ok))
                        .setPositiveBtnOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                if (DetailType.isApp(info.type)) {
                                    deleteApp(info);
                                }
                            }
                        }));
    }

    private void deleteApp(FileDownloadInfo info) {
        if (info == null) {
            return;
        }
        String filePath = FilePathManager.getDownloadedFilePath(info);

        DownloadManager.getInstance().removeDownloadedInfoWithNoApk(info.packageName);
        // add by HJG 2017-03-01 for notification begin -----
        List<FileDownloadInfo> list = DownloadManager.getInstance().getShadowDownloadedInfoList();
        if (list != null && list.size() <= 0) {
            NotificationUtil.cancelNotification(mActivity, NotificationExtKt.getNOTIFY_ID_UPDATE_APP_LIST());
        }

        PalmstoreSysHandler.startService(PalmplayApplication.getAppInstance().getApplicationContext()
                , PalmstoreSysHandler.ACION_NOTIFICATION_CHECK_APP_DOWNLOADED);
        PalmstoreSysHandler.startService(PalmplayApplication.getAppInstance().getApplicationContext()
                , PalmstoreSysHandler.ACTION_NOTIFICATION_CHECK_APP_DOWNLOADING);

        // add by HJG 2017-03-01 for notification end   -----
        MediaScannerConnection.scanFile(PalmplayApplication.getAppInstance().getApplicationContext(),
                new String[]{filePath}, null, null);

        mAdapter.handleInstallingListInfo(true);
    }
}

package com.afmobi.palmplay.clean;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_6.ScanResult;
import com.afmobi.palmplay.service.CleanNativeMemoryService;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.phonemaster.IPmScanAndClean;
import com.transsion.phonemaster.IPmScanAndCleanListener;
import com.transsnet.store.BuildConfig;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import de.greenrobot.event.EventBus;

import static com.afmobi.palmplay.service.CleanNativeMemoryService.ACTION_POST_SCAN_RESULT;
import static com.afmobi.palmplay.service.CleanNativeMemoryService.KEY_SCAN_RESULT;

public class PmScanAndCleanImpl {

    private static final String PM_PACKAGE_NAME = "com.transsion.phonemaster";
    private static final String PM_BIND_SERVICE = "com.transsion.phonemaster.intent.action.BINDER_CLEAN_SERVICE";

    private final static int APP_CACHE = 0; //缓存垃圾
    private final static int Residuals = 1; //卸载残留
    private final static int UselessApk = 2; //不用的安装包
    private final static int RAM = 3; //内存
    private final static int SYS_CACHE = 4; //系统垃圾

    private final static int MSG_SCAN_START = 200;   //扫描开始
    private final static int MSG_SCAN_UPDATE = 201;  //扫描过程中回调
    private final static int MSG_SCAN_FINISH = 202;  //扫描完成
    private final static int MSG_CLEAN_START = 203;  //清理开始
    private final static int MSG_CLEAN_FINISH = 204;  //扫描完成
    private final static int MSG_SCAN_STOP = 205;  //取消扫描
    private final static int MSG_CLEAN_STOP = 206;  //取消清理

    public static long CACHE_TEMP_SIZE = 0;
    public static long RESIDUAL_JUNK_TEMP_SIZE = 0;
    private final static long SCAN_MAX_TIME = 3 * 60 * 1000L; //扫描超时时间
    private final static long CLEAN_MAX_TIME = 3 * 60 * 1000L; //清理超时时间

    private static volatile PmScanAndCleanImpl sInstance = null;
    private PMServiceConnection mPmServiceConnection;
    private IPmScanAndClean mPmScanAndClean;
    public volatile boolean isInited = false;


    private ScanResult mScanResult = null;
    private CacheListItem mCacheListItem = null;
    private OnCleanUpEventListener mOnCleanUpEventListener;
    private Map<Object, CleanNativeMemoryService.OnScanEventListener> mListenerMap = new HashMap();
    private boolean isOnScanning = false;
    private CountDownTimer mCountDownTimer;
    private CountDownTimer mCleanCountDownTimer;
    private boolean isOnCleanning = false;


    private Handler sHandler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            onHandleCleanEvent(msg);
        }
    };

    private void onHandleCleanEvent(Message msg) {
        if (mListenerMap == null || mListenerMap.size() <= 0) {
            return;
        }

        Iterator<CleanNativeMemoryService.OnScanEventListener> it = mListenerMap.values().iterator();
        while (it.hasNext()) {
            CleanNativeMemoryService.OnScanEventListener mOnScanEventListener = it.next();
            if (mOnScanEventListener == null) {
                continue;
            }

            switch (msg.what) {
                case MSG_SCAN_START:
                    mOnScanEventListener.onScanStart();
                    break;

                case MSG_SCAN_UPDATE:
                    mOnScanEventListener.onScanProgressUpdate(mScanResult, mCacheListItem);
                    break;

                case MSG_SCAN_FINISH:
                    long size = (msg.obj instanceof Long) ? ((long) msg.obj) : 0;
                    mOnScanEventListener.onScanComplete(size, mScanResult);
                    onPostForSubscriber(size);
                    break;

                case MSG_CLEAN_START:
                    mOnScanEventListener.onCleanStart();
                    break;

                case MSG_CLEAN_FINISH:
                    long cacheSize = (msg.obj instanceof Long) ? ((long) msg.obj) : 0;
                    mOnScanEventListener.onCleanComplete(cacheSize);
                    onPostForSubscriber(cacheSize);
                    break;
                default:
                    break;
            }
        }
    }


    public PmScanAndCleanImpl() {
        mScanResult = new ScanResult();
    }

    public static PmScanAndCleanImpl getInstance() {
        if (sInstance == null) {
            synchronized (PmScanAndCleanImpl.class) {
                if (sInstance == null) {
                    sInstance = new PmScanAndCleanImpl();
                }
            }
        }
        return sInstance;
    }

    public void initPmService() {
        LogUtils.d(LogUtils.TAG_PM_CLEAN, "initPmService()");

        if (isInited) {
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "PM service is initialed...");
            stopScaning();

            startScan();
            return;
        }

        boolean bindResult = false;
        try {
            if (mPmServiceConnection == null) {
                mPmServiceConnection = new PMServiceConnection();
            }
            Intent intent = new Intent(PM_BIND_SERVICE);
            intent.setPackage(PM_PACKAGE_NAME);
            bindResult = PalmplayApplication.getAppInstance().bindService(intent, mPmServiceConnection, Context.BIND_AUTO_CREATE);
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "initPmService() bindService result=" + bindResult);
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        if (!bindResult) {
            if (mOnCleanUpEventListener != null) {
                mOnCleanUpEventListener.onCleanUpEvent(isInited);
            }
        }
    }


    public void addOnScanEventListener(Object key, CleanNativeMemoryService.OnScanEventListener l) {
        if (mListenerMap != null && !mListenerMap.containsKey(key)) {
            mListenerMap.put(key, l);
        }
    }

    public void removeOnScanEventListener(Object key) {
        if (mListenerMap != null) {
            mListenerMap.remove(key);
        }
    }

    public void setOnCleanUpEventListener(OnCleanUpEventListener l) {
        this.mOnCleanUpEventListener = l;
    }

    private void onPostForSubscriber(long size) {
        // post出去，给订阅者显示，比如通知栏快捷工具、悬浮球弹出页等
        EventMainThreadEntity entity = new EventMainThreadEntity();
        entity.setAction(ACTION_POST_SCAN_RESULT);
        entity.put(KEY_SCAN_RESULT, size);
        EventBus.getDefault().post(entity);
    }

    private IPmScanAndCleanListener mPmScanAndCleanListener = new IPmScanAndCleanListener.Stub() {
        @Override
        public void onScanProgress(int type, long size) throws RemoteException {
            String strType = null;
            switch (type) {
                case APP_CACHE:
                    strType = "caches";
                    break;
                case Residuals:
                    strType = "uninstall";
                    break;
                case UselessApk:
                    strType = "apkFiles";
                    break;
                case RAM:
                    strType = "memory";
                    break;
                case SYS_CACHE:
                    strType = "sysCaches";
                    break;
            }
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "onScanProgress type=" + type + ", " + strType + " size=" + size);

            onScanProgressCalled(type, size);

            publishMessage(MSG_SCAN_UPDATE, size);
        }

        @Override
        public void onScanFinish(long size) throws RemoteException {
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "onScanFinish  size=" + size);

            stopTimer();
            isOnScanning = false;
            stopScaning();
            publishMessage(MSG_SCAN_FINISH, size);
        }

        @Override
        public void onCleanFinish(long size) throws RemoteException {
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "onCleanFinish  size=" + size);

            stopCleanTimer();
            isOnCleanning = false;
            publishMessage(MSG_CLEAN_FINISH, size);
        }
    };

    private class PMServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LogUtils.i(LogUtils.TAG_PM_CLEAN, "onServiceConnected()");
            mPmScanAndClean = IPmScanAndClean.Stub.asInterface(service);

            isInited = isReady();
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "PMServiceConnect connected, isReady:" + isInited);

            if (!isInited) {
                if (mOnCleanUpEventListener != null) {
                    mOnCleanUpEventListener.onCleanUpEvent(isInited);
                }
                LogUtils.d(LogUtils.TAG_PM_CLEAN, "PM Service connected, but it is not ready, will unbind and use PS clean service");
                onUnbindService(); //绑定成功，但是PM无权限时不能使用PM扫描，需要解绑；
                return;
            }

            stopScaning();
            startScan();
        }

        @Override
        public void onBindingDied(ComponentName name) {
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "onBindingDied componentName = " + name);
            ServiceConnection.super.onBindingDied(name);
            isInited = false;
            if (mOnCleanUpEventListener != null) {
                mOnCleanUpEventListener.onCleanUpEvent(isInited);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            LogUtils.e(LogUtils.TAG_PM_CLEAN, "onServiceDisconnected componentName = " + name);

            isInited = false;
            if (mOnCleanUpEventListener != null) {
                mOnCleanUpEventListener.onCleanUpEvent(isInited);
            }
        }

        @Override
        public void onNullBinding(ComponentName name) {
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "onNullBinding componentName = " + name);
            ServiceConnection.super.onNullBinding(name);
        }
    }

    private void publishMessage(int what, long size) {
        if (sHandler != null) {
            Message msg = new Message();
            msg.what = what;
            msg.obj = size;
            sHandler.sendMessage(msg);
        }
    }

    private void onScanProgressCalled(int type, long size) {
        if (mScanResult != null) {
            switch (type) {
                case APP_CACHE:
                    mScanResult.cacheSize = size;
                    List<CacheListItem> appList = mScanResult.getAppCacheList();
                    if (appList != null) {
                        if (size > 0) {
                            CacheListItem resultItem = new CacheListItem();
                            resultItem.setPackageName("");
                            resultItem.setApplicationName("");
                            resultItem.setSize(size);
                            appList.add(resultItem);
                        }
                    }
                    break;

                case Residuals: //卸载残留
                    mScanResult.uninstallSize = size;
                    List<CacheListItem> uninstallList = mScanResult.getUninstallCacheList();
                    if (uninstallList != null) {
                        if (size > 0) {
                            CacheListItem resultItem = new CacheListItem();
                            resultItem.setPackageName("");
                            resultItem.setApplicationName("");
                            resultItem.setSize(size);
                            uninstallList.add(resultItem);
                        }
                    }
                    break;

                case UselessApk:
                    mScanResult.apkFilesSize = size;
                    List<CacheListItem> apkList = mScanResult.getApkList();
                    if (apkList != null) {
                        if (size > 0) {
                            CacheListItem apkItem = new CacheListItem();
                            apkItem.setPackageName("");
                            apkItem.setApplicationName("");
                            apkItem.setSize(size);
                            apkList.add(apkItem);
                        }
                    }
                    break;

                case RAM: //内存
                    mScanResult.memorySize = size;
                    List<CacheListItem> memoryList = mScanResult.getMemoryList();
                    if (memoryList != null) {
                        if (size > 0) {
                            CacheListItem item = new CacheListItem();
                            item.setPackageName("");
                            item.setApplicationName("");
                            item.setSize(size);
                            memoryList.add(item);
                        }
                    }
                    break;

                case SYS_CACHE:  //系统缓存
                    mScanResult.systemCacheSize = size;
                    List<CacheListItem> sysList = mScanResult.getSystemCacheList();
                    if (sysList != null) {
                        if (size > 0) {
                            CacheListItem item = new CacheListItem();
                            item.setPackageName("");
                            item.setApplicationName("");
                            item.setSize(size);
                            sysList.add(item);
                        }
                    }
                    break;

                default:
                    break;
            }
        }

        CacheListItem item = null;
        switch (type) {
            case APP_CACHE:
                item = new CacheListItem(CacheListItem.Type.CACHE);
                break;

            case Residuals: //卸载残留
                item = new CacheListItem(CacheListItem.Type.UNINSTALL);
                break;

            case UselessApk:
                item = new CacheListItem(CacheListItem.Type.MOUNTING);
                break;

            case RAM:
                item = new CacheListItem(CacheListItem.Type.MEMORY);
                break;

            case SYS_CACHE:
                item = new CacheListItem(CacheListItem.Type.SYSTEM);
                break;

            default:
                break;
        }

        if (item != null) {
            item.setPackageName("");
            item.setApplicationName("");
        }
        mCacheListItem = item;
    }

    /**
     * 连接并且有权限，返回true，否则返回false
     * */
    public boolean isReady(){
        int ret = -1;

        try {
            if (mPmScanAndClean != null) {
                ret = mPmScanAndClean.isReady();
            }
        } catch (RemoteException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return (ret == 0);
    }

    public void startScan() {
        LogUtils.d(LogUtils.TAG_PM_CLEAN, "startScan");

        if (mScanResult != null) {
            mScanResult.resetScanResult();
        }

        try {
            if (mPmScanAndClean != null && mPmScanAndCleanListener != null) {

                publishMessage(MSG_SCAN_START, 0);

                mPmScanAndClean.startScan(mPmScanAndCleanListener);
                isOnScanning = true;
                LogUtils.d(LogUtils.TAG_PM_CLEAN, "startScan, isOnScanning: " + isOnScanning);
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        if (mCountDownTimer == null) {
            mCountDownTimer = new CountDownTimer(SCAN_MAX_TIME, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    if (isOnScanning) {
                        LogUtils.e(LogUtils.TAG_PM_CLEAN, "On pm scanning time out, stop and callback.");
                        stopScan();
                    }
                }
            };
        }else {
            mCountDownTimer.cancel();
        }
        mCountDownTimer.start();
    }

    public void startClean() {
        LogUtils.d(LogUtils.TAG_PM_CLEAN, "startClean");
        try {
            if (mPmScanAndClean != null && mPmScanAndCleanListener != null) {

                publishMessage(MSG_CLEAN_START, 0);

                mPmScanAndClean.startClean(mPmScanAndCleanListener);
                isOnCleanning = true;
                LogUtils.d(LogUtils.TAG_PM_CLEAN, "startClean = " + mPmScanAndCleanListener);
            }
        } catch (RemoteException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        if (mCleanCountDownTimer == null) {
            mCleanCountDownTimer = new CountDownTimer(CLEAN_MAX_TIME, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    if (isOnCleanning) {
                        LogUtils.e(LogUtils.TAG_PM_CLEAN, "On pm cleaning time out, stop and callback.");
                        stopClean();
                    }
                }
            };
        }else {
            mCleanCountDownTimer.cancel();
        }
        mCleanCountDownTimer.start();
    }

    final private void stopScaning() {
        try {
            if (mPmScanAndClean != null && mPmScanAndCleanListener != null) {
                LogUtils.d(LogUtils.TAG_PM_CLEAN, "stopScan");
                mPmScanAndClean.stopScan();
                isOnScanning = false;
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    final private void stopCleaning() {
        try {
            if (mPmScanAndClean != null && mPmScanAndCleanListener != null) {
                LogUtils.d(LogUtils.TAG_PM_CLEAN, "stopCleaning");
                mPmScanAndClean.stopClean();
                isOnCleanning = false;
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    public void stopScan() {

        stopScaning();

        //TODO:refresh UI
        if (mScanResult != null) {
            long cacheSize = mScanResult.cacheSize + mScanResult.apkFilesSize + mScanResult.uninstallSize
                                + mScanResult.memorySize + mScanResult.systemCacheSize;
            publishMessage(MSG_SCAN_FINISH, cacheSize);
        }
    }

    public void stopClean() {

        stopCleaning();

        //TODO:refresh UI
        if (mScanResult != null) {
            long cacheSize = mScanResult.cacheSize + mScanResult.apkFilesSize + mScanResult.uninstallSize
                    + mScanResult.memorySize + mScanResult.systemCacheSize;
            publishMessage(MSG_CLEAN_FINISH, cacheSize);
        }
    }

    public void onUnbindService() {

        if (mPmServiceConnection != null) {
            try {
                PalmplayApplication.getAppInstance().unbindService(mPmServiceConnection);
                mPmScanAndClean = null;
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            mPmServiceConnection = null;
            isInited = false;

            if (sHandler != null) {
                sHandler.removeCallbacksAndMessages(null);
            }
            LogUtils.d(LogUtils.TAG_PM_CLEAN, "onUnbindService");
        }


    }

    public void onStop(Object key) {
        stopScaning();
        isOnScanning = false;

        stopCleaning();
        isOnCleanning = false;

        setOnCleanUpEventListener(null);
        removeOnScanEventListener(key);

        stopTimer();
        stopCleanTimer();

        LogUtils.d(LogUtils.TAG_PM_CLEAN, "onStop");
    }

    public void stopTimer() {
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
        }
    }

    public void stopCleanTimer() {
        if (mCleanCountDownTimer != null) {
            mCleanCountDownTimer.cancel();
        }
    }
}

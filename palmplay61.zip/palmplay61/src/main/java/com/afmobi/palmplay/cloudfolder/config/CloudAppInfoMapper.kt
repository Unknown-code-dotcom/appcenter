package com.afmobi.palmplay.cloudfolder.config

import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.launcherlib.model.FileFolderData

/**
 * FileFolderData.DataItem.Apps -> CloudAppInfo 映射封装。
 *
 */
object CloudAppInfoMapper {

    fun mapList(apps: List<FileFolderData.DataItem.Apps>?): List<CloudAppInfo> {
        if (apps.isNullOrEmpty()) return emptyList()
        return apps.mapNotNull { map(it) }
    }

    fun map(src: FileFolderData.DataItem.Apps?): CloudAppInfo? {
        if (src == null) return null
        return CloudAppInfo().apply {
            // FileFolderData2L.AppInfo 基础字段
            name = src.name
            itemID = src.itemID
            packageName = src.packageName
            iconUrl = src.iconUrl
            dynamicIconUrl = src.dynamicIconUrl
            isOffer = src.isOffer

            // Apps 扩展字段
            size = src.size
            downloadCount = src.downloadCount
            simpleDescription = src.simpleDescription
            countryCode = src.countryCode
            reportSource = src.reportSource
            smallScreenshot = src.smallScreenshot
            star = if (src.star.isNullOrEmpty()) 0 else src.star.toIntOrNull() ?: 0
            score = if (src.score.isNullOrEmpty()) 0f else src.score.toFloatOrNull() ?: 0f

            // CloudAppInfo 自身字段
            jumpType = src.jumpType
            storePkgName = src.storePkgName
            deeplink = src.deeplink
            clickTracking = src.clickTracking
            showTracking = src.showTracking
            html5Url = src.html5Url
        }
    }
}

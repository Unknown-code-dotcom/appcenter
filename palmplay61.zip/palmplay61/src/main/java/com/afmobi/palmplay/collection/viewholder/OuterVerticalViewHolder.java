package com.afmobi.palmplay.collection.viewholder;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.collection.ICollectionController;
import com.afmobi.palmplay.collection.IViewHolder;
import com.afmobi.palmplay.collection.adapter.NestedVerticalAdapter;
import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.customview.OnFeatureItemClickListener;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureDataType;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.home.viewholder.TrBaseRecyclerViewHolder;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.PhoneDeviceInfo;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.R;

import java.util.HashMap;

/**
 * 单行纵向滑动组件
 */
public class OuterVerticalViewHolder extends TrBaseRecyclerViewHolder implements OnFeatureItemClickListener, IViewHolder {
    private static final String TAG = LogUtils.TAG_COLLECTION+"OuterVerticalViewHolder";
    private TextView tv_title_name, tv_small_pkg_title;

    private RecyclerView bv_home_recycleview;

    private View v_item_bottom_divider;
    private Button getAllBtn;

    private NestedVerticalAdapter mAdapter;

    private FeatureBean mFeatureBean;
    public int bottomPosition = 0;
    public ICollectionController collectionController;
    private HashMap<String, Boolean> mHasBindMap = new HashMap<>();

    public OuterVerticalViewHolder(View itemView) {
        super(itemView);
        tv_title_name = itemView.findViewById(R.id.tv_title_name);
        tv_small_pkg_title = itemView.findViewById(R.id.tv_small_pkg_title);
        bv_home_recycleview = itemView.findViewById(R.id.bv_home_recycleview);
        v_item_bottom_divider = itemView.findViewById(R.id.v_item_bottom_divider);
        getAllBtn = itemView.findViewById(R.id.collection_get_all_btn);
        TRLinearLayoutManager mLayoutManager = new TRLinearLayoutManager(itemView.getContext());
        mLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        bv_home_recycleview.setLayoutManager(mLayoutManager);
        bv_home_recycleview.setHasFixedSize(true);
        bv_home_recycleview.setNestedScrollingEnabled(false);

    }

    @Override
    public void bind(final FeatureBean featureBean, final int position) {
        super.bind(featureBean, position);
        if (featureBean == null || featureBean.dataList == null ||featureBean.dataList.size() <= 0) {
            itemView.setVisibility(View.GONE);
            itemView.getLayoutParams().height = 0;
            unbind();
            return;
        }
        mFeatureBean = featureBean;
        mAdapter = mAdapter == null ? new NestedVerticalAdapter(PalmplayApplication.getAppInstance()) : mAdapter;
        showItemVIew();
        mAdapter.setData(featureBean);
        if (mScreenPageName.equals(TRAnalyticsConstant.SMALLPKG_PAGE)) {
            mAdapter.smallPkgSortList();
        }
        int sizeItem = mAdapter.getItemCount();

        mAdapter.setFromPage(mFromPage);
        mAdapter.setPageParamInfo(mPageParamInfo);
        mAdapter.setCurScreenPage(mScreenPageName);
        mAdapter.setFeatureName(mFeatureName);
        mAdapter.mFrom = mFrom;
        mAdapter.mVarId = mVarId;
        mAdapter.mIsFromCache = isFromCache();
        mAdapter.setItemViewStateListener(mItemViewStateListener);
        mAdapter.setOnViewLocationInScreen(mOnViewLocationInScreen);
        mAdapter.setOfferInfo(mOfferInfo);
        mAdapter.setGdprHasAllowed(gdprHasAllowed);
        mAdapter.setOnFeatureItemClickListener(this);

        if (position ==0) {
            itemView.setBackgroundResource(R.drawable.collection_item_view_bg);
        } else {
            itemView.setBackgroundColor(PalmplayApplication.getAppInstance().getResources().getColor(R.color.recommend_collection_item_bg));
        }

        if (bottomPosition == position) {
            v_item_bottom_divider.getLayoutParams().height = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 80f);
        } else {
            v_item_bottom_divider.getLayoutParams().height = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 11f);
        }

        if (RankStyleType.V_NO_TITLE.equals(featureBean.style)) {
            tv_small_pkg_title.setVisibility(View.GONE);
        } else {
            if (mScreenPageName.equals(TRAnalyticsConstant.SMALLPKG_PAGE)) {
                tv_small_pkg_title.setVisibility(View.VISIBLE);
            } else {
                tv_small_pkg_title.setVisibility(View.GONE);
            }
        }

        if (sizeItem > 0) {
            itemView.getLayoutParams().height = RecyclerView.LayoutParams.WRAP_CONTENT;
            itemView.setVisibility(View.VISIBLE);

            getAllBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (collectionController != null) {
                        collectionController.askWifiOnlyPermission(OuterVerticalViewHolder.this, featureBean);
                    }
                }
            });
            tv_title_name.setText(featureBean.name);
            tv_title_name.setVisibility(View.VISIBLE);
            if (bv_home_recycleview.getAdapter() == null && mAdapter!= null) {
                bv_home_recycleview.setAdapter(mAdapter);
            } else {
                if (mAdapter != null) { // 非第一次滑动正常，否则不需要操作adapter
                    mAdapter.notifyDataSetChanged();
                }
            }

            if(mOfferInfo != null && mOfferInfo.isOfferStyle()) {
                tv_title_name.setTextColor(mOfferInfo.mainColor);
            }
        }  else {
            dismissItemVIew();
        }
        bv_home_recycleview.postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshGetAllBtn();
            }
        }, 500L);
    }

    @Override
    public void continueExecuteGetAll(@NonNull FeatureBean featureBean, boolean waitingWiFi) {
        if (!PhoneDeviceInfo.netWorkIsConnected()) {
            ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(),R.string.tip_no_network);
        } else {
            if (!waitingWiFi) {
                ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tips_downloading);
            }
        }
        DownloadUtil.sLastClickGetAllTime = System.currentTimeMillis();
        DownloadUtil.sWaitingWiFiForGetAll = waitingWiFi;
        int childCount = bv_home_recycleview.getChildCount();
        mAdapter.mSourceType = 1;
        for(int i=0; i< childCount; i++) {
            XFermodeDownloadView downloadView = bv_home_recycleview.getChildAt(i).findViewById(R.id.downloadView);
            FeatureItemData itemData = (FeatureItemData) featureBean.dataList.get(i);
            if (downloadView != null && itemData!= null && (itemData.observerStatus == FileDownloadInfo.STATUS_NONE
                    ||itemData.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE
                    ||(itemData.observerStatus == FileDownloadInfo.STATUS_PAUSE && !waitingWiFi))) {
                downloadView.performClick();
            }
        }
        mAdapter.mSourceType = 0;
        FeatureItemData featureItemData = (FeatureItemData) mFeatureBean.dataList.get(0);
        String value = TRStringUtil.generateString(mScreenPageName, getFeatureName(), featureItemData.topicPlace, "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType(featureBean.style)
                .setTopicId(featureBean.getId())
                .setExtraValue( mPageParamInfo != null ? mPageParamInfo.getTabId() : "")
                .setItemType(featureBean.itemType)
                .setItemId(featureBean.getId())
                .setButtonType(TRAnalyticsConstant.GET_ALL_TYPE)
                .setItemValue(featureBean.name)
                .setTaskId(featureItemData.getTaskId())
                .setExpId(featureItemData.getExpId())
                .setNativeId(featureItemData.nativeId)
                .setItemFrom(featureBean.getOemSource())
//                                .setExtras(CommonUtils.getNewExtras(null, mFeatureName,featureBean.tabNum))
                .setFeatureId(featureBean.featureId);
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public void trimViewMemory() {
        super.trimViewMemory();
        bv_home_recycleview.destroyDrawingCache();
        if (mAdapter != null) {
            mAdapter.onDestroy();
        }
    }

    private void refreshGetAllBtn() {
        boolean enableGetAll = false;
        int size = mFeatureBean.dataList.size();
        for(int i=0; i< size; i++) {
            FeatureItemData itemData = (FeatureItemData) mFeatureBean.dataList.get(i);
            LogUtils.d(TAG, "refreshGetAllBtn itemData.observerStatus="+itemData.observerStatus);
            if (itemData!= null && (itemData.observerStatus == FileDownloadInfo.STATUS_NONE
                    ||itemData.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE
                    ||itemData.observerStatus == FileDownloadInfo.STATUS_PAUSE)) {
                enableGetAll = true;
                break;
            }
        }
        if (getAllBtn != null) {
            getAllBtn.setEnabled(enableGetAll);
        }
    }

    @Override
    public void onFeatureItemClick(FeatureBaseData featureBaseData, int position, RecyclerView.ViewHolder holder) {
        if (featureBaseData == null || FeatureDataType.GP_ITEM.equals(featureBaseData.dataType)) {
            return;
        }

        if (!(featureBaseData instanceof FeatureItemData)) {
            return;
        }

        final FeatureItemData data = (FeatureItemData) featureBaseData;

        if (DownloadDecorator.checkJumpToGooglePlay(PalmplayApplication.getAppInstance(), data.getOuterUrl(), data.packageName, mPageParamInfo, data.itemID, data.versionCode, data.verifyGoogle)) {
            return;
        }
        // 来自单个点击下载
//        if (System.currentTimeMillis() - lastClickGetAllTime > 800L && !PhoneDeviceInfo.netWorkIsConnected()) {
//            ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(),R.string.tip_no_network);
//        }
//        if (System.currentTimeMillis() - lastClickGetAllTime > 800L) {
//            DownloadUtil.sForbidSendBroadcast = false;
//        }
//        getAllBtn.postDelayed(new Runnable(){
//            @Override
//            public void run() {
//                refreshGetAllBtn();
//            }
//        }, 500); // 状态改变有延迟
    }
}

package com.afmobi.palmplay.customview.banner.adapter;

import android.view.ViewGroup;

import com.afmobi.palmplay.customview.banner.config.BannerConfig;
import com.afmobi.palmplay.customview.banner.listener.OnBannerListener;
import com.afmobi.palmplay.customview.banner.util.BannerUtils;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public abstract class BannerAdapter<T, VH extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<VH> implements IViewHolder<T, VH> {
    protected List<T> mDatas = new ArrayList<>();
    private OnBannerListener<T> mOnBannerListener;
    private VH mViewHolder;
    private int mIncreaseCount = BannerConfig.INCREASE_COUNT;

    public BannerAdapter(List<T> datas) {
        setDatas(datas);
    }

    /**
     * 设置实体集合（可以在自己的adapter自定义，不一定非要使用）
     *
     * @param datas
     */
    public void setDatas(List<T> datas) {
        if(datas != null) {
            mDatas.clear();
            mDatas.addAll(datas);
        }
        notifyDataSetChanged();
    }

    /**
     * AC banner 合规：移除指定位置的数据并触发刷新。position 越界时静默忽略。
     * 注意：操作的是真实数据下标（getRealDataList 下标），不含 banner 库的 infinite-loop padding。
     */
    public void removeAt(int position) {
        if (mDatas == null || position < 0 || position >= mDatas.size()) return;
        mDatas.remove(position);
        if (getRealCount() > 1 && mIncreaseCount > 0) {
            // infinite-loop 模式下 adapter position = realIndex + 1（前有1个 copy padding）
            // 用精准 notifyItemRemoved 避免 ViewPager2 全量重建（notifyDataSetChanged 会导致 scroll offset 重置）
            notifyItemRemoved(position + 1);
            // 同步更新首尾 copy item，保证无限循环的 copy 内容正确
            notifyItemChanged(0);
            notifyItemChanged(getItemCount() - 1);
        } else {
            notifyDataSetChanged();
        }
    }

    /** AC banner 合规：真实数据列表（不含 banner 库的 infinite-loop padding），用于判断是否空。 */
    public List<T> getRealDataList() {
        return mDatas;
    }

    /**
     * 获取指定的实体（可以在自己的adapter自定义，不一定非要使用）
     *
     * @param position 真实的position
     * @return
     */
    public T getData(int position) {
        return mDatas.get(position);
    }

    /**
     * 获取指定的实体（可以在自己的adapter自定义，不一定非要使用）
     *
     * @param position 这里传的position不是真实的，获取时转换了一次
     * @return
     */
    public T getRealData(int position) {
        return mDatas.get(getRealPosition(position));
    }


    @Override
    public final void onBindViewHolder(@NonNull VH holder, int position) {
        mViewHolder = holder;
        int real = getRealPosition(position);
        T data = mDatas.get(real);
        holder.itemView.setTag(R.id.banner_data_key, data);
        holder.itemView.setTag(R.id.banner_pos_key, real);
        onBindView(holder, mDatas.get(real), real, getRealCount());
        if (mOnBannerListener != null) {
            holder.itemView.setOnClickListener(view -> mOnBannerListener.OnBannerClick(data, real));
        }
    }

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        VH vh = onCreateHolder(parent, viewType);
        vh.itemView.setOnClickListener(v -> {
            if (mOnBannerListener != null) {
                T data = (T) vh.itemView.getTag(R.id.banner_data_key);
                int real = (int) vh.itemView.getTag(R.id.banner_pos_key);
                mOnBannerListener.OnBannerClick(data, real);
            }
        });
        return vh;
    }

    @Override
    public int getItemCount() {
        return getRealCount() > 1 ? getRealCount() + mIncreaseCount : getRealCount();
    }

    public int getRealCount() {
        return mDatas == null ? 0 : mDatas.size();
    }

    public int getRealPosition(int position) {
        return BannerUtils.getRealPosition(mIncreaseCount == BannerConfig.INCREASE_COUNT, position, getRealCount());
    }

    public void setOnBannerListener(OnBannerListener<T> listener) {
        this.mOnBannerListener = listener;
    }

    public VH getViewHolder() {
        return mViewHolder;
    }

    public void setIncreaseCount(int increaseCount) {
        this.mIncreaseCount = increaseCount;
    }
}
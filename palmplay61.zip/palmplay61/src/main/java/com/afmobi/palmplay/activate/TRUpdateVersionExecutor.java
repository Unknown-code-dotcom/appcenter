package com.afmobi.palmplay.activate;

import android.app.Activity;
import android.content.Intent;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.ProcessLifecycleChecker;
import com.afmobi.palmplay.alonefuction.ForceUpgradeActivity;
import com.afmobi.palmplay.alonefuction.NewVersionTipActivity;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.util.ActivityLifecycleUtil;
import com.afmobi.util.CommonUtils;
import com.transsion.palmstorecore.log.LogUtils;

/***
 * created by yongli.li
 * 升级的执行者
 */
public class TRUpdateVersionExecutor extends TRBaseExecutor {
    public static volatile boolean STATUS = false;//代表本身是否正在显示
    //代表普通升级在下载中
    public static volatile boolean SELF_UPDATE_DOWNLOADING = false;

    public static volatile boolean SELF_UPDATE_RUN_IN_BACKGROUND= false;

    @Override
    public Object getSubActivateData(String subActivateType) {
        return null;
    }

    @Override
    public boolean isCanShow(String fromType) {
        int type = TRDialogUtil.showUpdateType();
        if (type == ClientVersion.UPDATE_TYPE_FORCE || type == ClientVersion.UPDATE_TYPE_NOT_FORCE) {
            return true;
        }
        return false;
    }

    @Override
    public boolean show(String fromType) {
        if(!CommonUtils.isPrivacyPolicyHasAllowed()){
            return false;
        }
        if(PalmPlayVersionManager.getInstance().blockMainUpdateShow){
            return false;
        }
        int type = TRDialogUtil.showUpdateType();
        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            return false;
        }

        if (TRDiskSpaceLimitExecutor.STATUS) {
            LogUtils.d("Update version will not show,because disk space limit activity is showing");
            return false;
        }

        //sun功能的页面之上不允许有其它页面弹出；
        Activity currentActivity = AtyManager.getAtyManager().getCurrentActivity();
        if (currentActivity == null || currentActivity.isDestroyed() || currentActivity.isFinishing()) {
            LogUtils.d("Update version will not show,because current activity is null or is destroyed.");
            return false;
        }

        if(ProcessLifecycleChecker.blockToggleNotificationShow(currentActivity)){
            return false;
        }

        if (ActivityLifecycleUtil.visibleActivityCount < 1) {
            return false;    // 已退到后台，则不显示
        }

        if (type == ClientVersion.UPDATE_TYPE_FORCE) {//显示强制升级
            //todo 强制更新存在交互bug 暂时不打开
            AtyManager.getAtyManager().popAllActivityExceptOne(MainActivity.class);
            Intent intent = new Intent(PalmplayApplication.getAppInstance(), ForceUpgradeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PalmplayApplication.getAppInstance().startActivity(intent);
        } else if (type == ClientVersion.UPDATE_TYPE_NOT_FORCE) {//显示普通升级
            Intent intent = new Intent(PalmplayApplication.getAppInstance(), NewVersionTipActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PalmplayApplication.getAppInstance().startActivity(intent);
        } else {
            return false;
        }
        return true;
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }
}

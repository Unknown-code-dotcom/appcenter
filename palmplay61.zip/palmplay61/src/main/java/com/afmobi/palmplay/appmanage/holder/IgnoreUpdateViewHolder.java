package com.afmobi.palmplay.appmanage.holder;

import android.graphics.Paint;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.adapter.ManageIgnoreUpdateAdapter;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import java.io.File;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class IgnoreUpdateViewHolder extends RecyclerView.ViewHolder {

   private ImageView iv_image;
   public TextView tv_name, tv_version, tv_restore, tv_size, tv_diff_size;
   public View h_margin;
   public View rootView;
   private ManageIgnoreUpdateAdapter.IgnoreRestoreClickListener mListener;
   private String mFrom;

   public IgnoreUpdateViewHolder(@NonNull View itemView) {
      super(itemView);
      iv_image = itemView.findViewById(R.id.iv_image);
      tv_name = itemView.findViewById(R.id.tv_name);
      tv_version = itemView.findViewById(R.id.tv_version);
      tv_restore = itemView.findViewById(R.id.tv_restore);
      tv_size = itemView.findViewById(R.id.tv_size);
      tv_diff_size = itemView.findViewById(R.id.tv_diff_size);
      h_margin = itemView.findViewById(R.id.h_margin);
      rootView = itemView.findViewById(R.id.rootView);
   }

   public void setIgnoreRestoreClickListener(ManageIgnoreUpdateAdapter.IgnoreRestoreClickListener l) {
      this.mListener = l;
   }

   public void setFrom(String from) {
      this.mFrom = from;
   }

   public void bind(ClientVersion.UpdateItem item, int position) {
      if (item != null) {
         int defaultIcon = R.drawable.layer_list_app_default_02_bg;
         File iconFile = TextUtils.isEmpty(item.iconLocalUrl) ? null : new File(item.iconLocalUrl);
         if (iconFile != null && iconFile.exists()) {
            GlideUtils.setImageFileUriWithRadius(iv_image, Uri.fromFile(iconFile));
         }
         else {
            GlideUtils.setImageUrl(iv_image, item.iconUrl, defaultIcon, defaultIcon);
         }
         tv_name.setText(item.name);
         tv_version.setText(TextUtils.isEmpty(item.versionName) ? "" : CommonUtils.replace(PalmplayApplication.getAppInstance().getString(R.string.versionname_prefix), CommonUtils.TARGET_NAME, item.versionName));
         tv_size.setText(FileUtils.getSizeName(item.size));
         if (!TextUtils.isEmpty(item.diffSize)) {
            tv_diff_size.setVisibility(View.VISIBLE);
            tv_size.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
            try {
               tv_diff_size.setText(FileUtils.getSizeName(Long.parseLong(item.diffSize)));
            } catch (Exception e) {
            }
         } else {
            tv_size.getPaint().setFlags(0);
            tv_diff_size.setVisibility(View.GONE);
         }
         tv_restore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if (mListener != null) {
                  mListener.onClick(v);
               }

               String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, TRAnalyticsConstant.IGNORE_UPDATE,"", ""+position);
               ComponentClickBuilder builder = new ComponentClickBuilder();
               builder.setValue(value)
                       .setFrom(mFrom)
                       .setTopicType("")
                       .setTopicId("")
                       .setItemType(item.detailType)
                       .setItemId(item.itemID)
                       .setButtonType(TRAnalyticsConstant.RESTORE)
                       .setNativeId(item.nativeId)
                       .setReportSource(item.reportSource)
                       .setItemValue(item.packageName)
                       .setExtraValue("");
               TRAnalysticsUtil.trackClick(builder);
            }
         });

         itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, TRAnalyticsConstant.IGNORE_UPDATE,"", ""+position);
               AppBuilder appBuilder = new AppBuilder()
                       .setFromPage(Constant.NEW_FROMPAGE_UPDATE)
                       .setLastPage(PageConstants.Update)
                       .setValue(value)
                       .setParamsByData(TRJumpUtil.convetToRankDataItem(item), "");
               TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);

               ComponentClickBuilder builder = new ComponentClickBuilder();
               builder.setValue(value)
                       .setFrom(mFrom)
                       .setTopicType("")
                       .setTopicId("")
                       .setItemType(item.detailType)
                       .setItemId(item.itemID)
                       .setButtonType(TRAnalyticsConstant.ICON)
                       .setReportSource(item.reportSource)
                       .setNativeId(item.nativeId)
                       .setItemValue(item.packageName)
                       .setExtraValue("");
               TRAnalysticsUtil.trackClick(builder);
            }
         });

         if(!item.hasTrack) {
            item.hasTrack = true;
            if(TextUtils.isEmpty(item.nativeId)) {
               item.nativeId = CommonUtils.generateSerialNum();
            }
            String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, TRAnalyticsConstant.IGNORE_UPDATE,"", ""+position);
            ComponentExposureBuilder builder = new ComponentExposureBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId(item.topicID)
                    .setItemType(item.detailType)
                    .setItemId(item.itemID)
                    .setNativeId(item.nativeId)
                    .setItemValue(item.packageName)
                    .setTaskId(0);
            TRAnalysticsUtil.trackExposure(builder);
         }
      }
   }
}

package com.afmobi.palmplay.clean;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.base.BaseEventFragment;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.statusbar.TRNavigationBarUtil;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 清理完成一定时间内用户再打开扫描功能，手机已达完美状态提示
 *
 * @author xiangfei.wei
 * @date 2017/12/29
 */
public class CleanPerfectStateFragment extends BaseEventFragment {
    private Activity mActivity;

    private LinearLayout ll_perfect, ll_perfect_copy, ll_recommend_zone;
    private TextView tv_perfect, tv_perfect_copy;
    private ImageView iv_shield, iv_shield_copy;
    private NestedScrollView scrollView;
    private RecyclerView recommend_recyle;
    private TrHomeRecyclerViewAdapter mHomeRecyclerViewAdapter;

    protected List<String> mAlreadyAdList = new ArrayList<String>();  //记录已经展示过的广告包名
    private CleanCacheCleaningViewModel mCleanCacheCleaningViewModel;
    private FeaturedModel mFeaturedModel;

    public static CleanPerfectStateFragment newInstance() {
        return new CleanPerfectStateFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = (Activity) context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //打点统计
        mPageParamInfo.setLastPage(PageConstants.Deep_Clean);
        mPageParamInfo.setCurPage(PageConstants.Deep_Clean_Finish);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

        View contentView = inflater.inflate(R.layout.fragment_clean_perfect_state, container, false);

        LinearLayout linearLayout = contentView.findViewById(R.id.linearLayout);
        View view = new View(mActivity);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, TRStatusBarUtil.getStatusBarHeight(mActivity));
        view.setLayoutParams(params);
        view.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.color_0a9beb));
        try {
            linearLayout.addView(view, 0);
        } catch (Throwable e) {
            //ignore
        }

        ll_perfect = (LinearLayout) contentView.findViewById(R.id.ll_perfect);
        ll_perfect_copy = (LinearLayout) contentView.findViewById(R.id.ll_perfect_copy);
        ll_recommend_zone = (LinearLayout) contentView.findViewById(R.id.ll_recommend_zone);

        tv_perfect = (TextView) contentView.findViewById(R.id.tv_perfect);
        tv_perfect_copy = (TextView) contentView.findViewById(R.id.tv_perfect_copy);

        iv_shield = (ImageView) contentView.findViewById(R.id.iv_shield);
        iv_shield_copy = (ImageView) contentView.findViewById(R.id.iv_shield_copy);
        scrollView = contentView.findViewById(R.id.scrollView);
        recommend_recyle = (RecyclerView) contentView.findViewById(R.id.recommend_recyle);

        mCleanCacheCleaningViewModel = ViewModelProviders.of(getActivity()).get(CleanCacheCleaningViewModel.class);

        mCleanCacheCleaningViewModel.getFeaturedLiveData().observe(getActivity(), new Observer<FeaturedModel>() {
            @Override
            public void onChanged(FeaturedModel featuredModel) {
                if (featuredModel != null) {
                    mFeaturedModel = featuredModel;
                    if (mHomeRecyclerViewAdapter == null){
                        showRecommendList();
                        recommend_recyle.post(moveUpAnimationAction);
                    }
                }
            }
        });
        initData();
        return contentView;
    }

    private void initData() {
        mCleanCacheCleaningViewModel.loadFeaturedData();
    }

    private void showRecommendList() {
        if (mActivity == null || mActivity.isDestroyed() || mActivity.isFinishing()) {
            return;
        }
        ll_perfect_copy.getLayoutParams().height = ll_perfect.getHeight();
        scrollView.setVisibility(View.VISIBLE);
        ll_perfect.setVisibility(View.GONE);

        if (mFeaturedModel != null && mFeaturedModel.featureList != null && mFeaturedModel.featureList.size() > 0) {

            ll_recommend_zone.setVisibility(View.VISIBLE);
            LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false);
            recommend_recyle.setNestedScrollingEnabled(true);
            recommend_recyle.setLayoutManager(mLinearLayoutManager);
            if (mHomeRecyclerViewAdapter == null) {
                mHomeRecyclerViewAdapter = new TrHomeRecyclerViewAdapter(mActivity, recommend_recyle, mLinearLayoutManager, null, null,
                        null,  mPageParamInfo.getLastPage(), mPageParamInfo, false, 0, 0,false);
                mHomeRecyclerViewAdapter.setFrom(TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", ""));
                mHomeRecyclerViewAdapter.setCurScreenPage(TRAnalyticsConstant.JUNK_FILE);
                mHomeRecyclerViewAdapter.setFeatureName(TRAnalyticsConstant.JUNK_RECOMMOND);
                mHomeRecyclerViewAdapter.onCreateView();
            }

            List<TaNativeInfo> adInfo = mCleanCacheCleaningViewModel.recommendAdInfos;
            if (adInfo != null) {
                int size = adInfo.size();
                for (int i = 0; i < size; i++) {
                    TaNativeInfo taNativeInfo = adInfo.get(i);
                    if (!taNativeInfo.isIconType()) {
                        //continue
                    } else {
                        //icon类广告
                        FeatureItemData appinfo = null;
                        try {
                            appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                            if (appinfo != null) {
                                appinfo.tNativeInfo = taNativeInfo;
                                if (TextUtils.isEmpty(appinfo.categoryName)) {
                                    appinfo.categoryName = appinfo.extJson != null ? appinfo.extJson.categoryName : "";
                                }
                            }
                        } catch (GsonUtil.GsonParseException e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }

                        if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {
                            mCleanCacheCleaningViewModel.filterEWData(mFeaturedModel, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn());
                            TRHomeUtil.addAdForFeatureData(mFeaturedModel.featureList, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), mAlreadyAdList, SceneCode.JF_MR);
                        }
                    }
                }
            }

            mCleanCacheCleaningViewModel.filterDuplicateData(mFeaturedModel);
            mHomeRecyclerViewAdapter.setVarId(mFeaturedModel.varId);
            mHomeRecyclerViewAdapter.setData(mFeaturedModel.featureList, null, null,false,false, true);
            recommend_recyle.setAdapter(mHomeRecyclerViewAdapter);
        }
    }

    private Runnable moveUpAnimationAction = new Runnable() {
        @Override
        public void run() {

            //推荐内容从底部滑出来；
            int originalValue = ll_perfect_copy.getLayoutParams().height;
            ValueAnimator anim = ValueAnimator.ofInt(originalValue, DisplayUtil.dip2px(mActivity, 151));
            anim.setDuration(1000);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    ll_perfect_copy.getLayoutParams().height = (int) valueAnimator.getAnimatedValue();
                    ll_perfect_copy.requestLayout();
                }
            });
            anim.addListener(new AnimatorListenerAdapter() {

                @Override
                public void onAnimationStart(Animator animation) {
                    super.onAnimationStart(animation);
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);

                    LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) iv_shield_copy.getLayoutParams();
                    params.bottomMargin = DisplayUtil.dip2px(mActivity, 0);
                    iv_shield_copy.requestLayout();
                }
            });
            anim.start();

            ValueAnimator anim2 = ValueAnimator.ofInt(DisplayUtil.dip2px(mActivity, 135), DisplayUtil.dip2px(mActivity, 0));
            anim2.setDuration(1000);
            anim2.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) iv_shield_copy.getLayoutParams();
                    params.topMargin = (int) valueAnimator.getAnimatedValue();
                    iv_shield_copy.requestLayout();
                }
            });
            anim2.start();

            iv_shield_copy.animate().setDuration(1000).scaleX(0.6f).scaleY(0.6f);

        }
    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mHomeRecyclerViewAdapter != null) {
            mHomeRecyclerViewAdapter.onDestroy();
        }
        recommend_recyle.removeCallbacks(moveUpAnimationAction);
    }
}

package com.afmobi.palmplay.admgr.hisavana_sdk;

import static com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode.ME_O;
import static com.transsnet.store.BuildConfig.DEBUG;

import android.content.Context;
import android.text.TextUtils;
import android.util.Pair;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.ProcessLifecycleChecker;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.v6_0.StartUpTabsCache;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.SPKey;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.FeatureSinglePageData;
import com.afmobi.palmplay.model.FeatureSinglePageItemData;
import com.afmobi.palmplay.model.PlutoOfferResponseModel;
import com.afmobi.palmplay.model.RecommendBean;
import com.afmobi.palmplay.model.RecommendInstallResponse;
import com.afmobi.palmplay.model.SearchRespInfo;
import com.afmobi.palmplay.model.ew.HisavanaConfigInfo;
import com.afmobi.palmplay.model.ew.RemovalCfg;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.RankModel;
import com.afmobi.palmplay.optimize.OptimizeUtils;
import com.afmobi.palmplay.pluto.GetRemindMessageTask;
import com.afmobi.palmplay.pluto.dialog.PlutoDialog;
import com.afmobi.palmplay.recommendinstall.LiveEwDataStore;
import com.afmobi.palmplay.recommendinstall.TRInstallCacheData;
import com.afmobi.palmplay.recommendinstall.TRInstallManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.PhoneDeviceInfo;
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative;
import com.cloud.hisavana.ac.sdk.api.listener.AdListener;
import com.cloud.hisavana.ac.sdk.api.listener.RealtimeAdRequestListener;
import com.cloud.hisavana.ac.sdk.api.request.AttachedRealtimeAdRequest;
import com.cloud.hisavana.ac.sdk.api.request.FeedAdRequest;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.Constants;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.cloud.hisavana.ac.sdk.data.bean.request.CategoryCode;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.transsion.newphonerecommend.bean.AppDetailInfo;
import com.transsion.newphonerecommend.utils.PackageUtil;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.basecomponent.NewPhoneRecommendEwAdCallback;
import com.transsion.palmstorecore.basecomponent.NewPhoneRecommendEwCacheAdCallback;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class HisavanaSdkManager {

    public static final long SDK_LOAD_TIMEOUT = 1000;  //unit: ms
    public static final int SDK_LOAD_CACHE_TIMEOUT = 120; //unit:ms
    public static final int SDK_LOAD_PLUTO_CACHE_TIMEOUT = 180;// ms
    private static final byte[] lock = new byte[0];
    private static volatile HisavanaSdkManager mSspSdkManager;

    private ConcurrentHashMap<String,List<HisavanaConfigInfo>> mEwGlobalInfo = null;
    private RemovalCfg mRemovalCfg;
    private Map<String, List<PositionInfo>> lineMap = new HashMap<>();

    public static final String HISAVANA_APP_ID = "36875cdb6a7f4da783d3714632937d9c";

    public static final String HISAVANA_INFO_KEY = "hisavanaAdConfigMap";
    public static final String REMOVAL_CONFIG_KEY = "removalConfig";
    public static final int FIRST_DOWNLOAD = 1; //首次下载
    public static final int EW_DOWNLOAD_FINISHED = 2; //ew下载完成
    public static final int EW_INSTALLED = 3; // ew安装完成
    public static final int FIRST_CREATE = 2; // 首次创建任务
    public static final int CLICK_ICON = 1; //进入详情页面
    public static final int START_DOWNLOAD = 4; //记录开始下载

    public static final int NO_CACHE_COUNT = 0;

    public static final String TAG = "SspSdkManager";
    private String configID = "dev_native";
    public static final String AR_JSON_FILE_NAME = "hisavana_ar_data"; // 老手一键安装
    public static final String NR_JSON_FILE_NAME = "hisavana_nr_data"; // 新手一键安装
    public static final String REPORT_SOURCE_EW = "7"; //EW广告的reportSource用7标识
    public static final String REPORT_SOURCE_NATIVE = "2";  // 散发自然流
    public static final String FROMPAGE_EW = "EW"; //EW广告来源
    public static final int TRACK_LOAD_ADS_RSP_SUCCESS = 0; //EW广告接口返回成功
    public static final int TRACK_LOAD_ADS_SUCCESS = 1; //加载广告成功
    public static final int TRACK_LOAD_ADS_SUCCESS_NO_DATA = 2; //加载广告成功 没数据
    public static final int TRACK_LOAD_ADS_ERROR = 3; //加载广告Error
    public static final int TRACK_LOAD_ADS_TIME_OUT = 4; //加载广告超时
    public static final int TRACK_LOAD_CACHE_ADS_SUCCESS = 5; //加载缓存广告成功
    public static final int TRACK_LOAD_CACHE_ADS_SUCCESS_NO_DATA = 6; //加载缓存广告成功 没数据
    public static final int TRACK_LOAD_CACHE_ADS_ERROR = 7; //加载缓存广告Error
    public static final int TRACK_LOAD_CACHE_ADS_TIME_OUT = 8; //加载缓存广告超时
    public static final int TRACK_LOAD_CACHE_ADS_HAS_CACHE = 9; // 有缓存
    public static final int TRACK_LOAD_CACHE_ADS_NO_CACHE = 10; // 无缓存
    public static final int TRACK_LOAD_CACHE_ADS_STATUS = 11; // 获取缓存状态
    public static final int TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION = 12; // 缓存之后异常
    public static final int TRACK_LOAD_ADS_EXCEPTION = 13; // 数据返回后加载广告异常
    public static final int TRACK_LOAD_ADS_ADD_QUEUE = 14; // 加入展示队列
    public static final int TRACK_LOAD_CACHE_ADS_RSP_SUCCESS = 15; // 请求缓存成功
    public static final int TRACK_LOAD_LIVE_ADS_RSP_SUCCESS = 16;
    public static final int PLUTO_EXCEPTION_CODE_ORG = 1001; // 代表pluto配置信息为空
    public static final int PLUTO_EXCEPTION_CODE_NULL = 1002; // 代表数据为空
    public static final int EXCEPTION_POSITIONID_NULL = 1003; // 代码位ID为空
    public static final int EXCEPTION_EW_CONFIG_NULL = 1004; // EW配置为空
    public static final int EXCEPTION_EW_OTHER_SHOW = 1005; // 被其他页面展示

    public static final int TRACK_LOAD_ADS_SUCCESS_ISCACHE_0 = 0; //加载成功的广告是否是缓存广告 0 -不是  1-是
    public static final int TRACK_LOAD_ADS_SUCCESS_ISCACHE_1 = 1;

    public static final int AD_STYLE_0 = 0;     //不显示ad标签
    public static final int AD_STYLE_1 = 1;     //显示ad标签 高亮背景
    public static final int AD_STYLE_2 = 2;     //显示ad标签 + 图片

    //有结果，长列表，多结果
    public static final int RESULT_TOPIC_ROW_0 = 0;
    //无结果，90第一行，91第二行
    public static final int RESULT_TOPIC_ROW_90 = 90;
    public static final int RESULT_TOPIC_ROW_91 = 91;
    //少结果
    public static final int RESULT_TOPIC_ROW_80 = 80;

    public static HisavanaSdkManager getInstance() {
        if (mSspSdkManager == null) {
            synchronized (lock) {
                if (mSspSdkManager == null) {
                    mSspSdkManager = new HisavanaSdkManager();
                }
            }
        }
        return mSspSdkManager;
    }

    public HisavanaSdkManager() {

        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_REMOVAL_WHITELIST, null);
        int frequency = MMKVUtils.getMMKV().getInt(Constant.KV_REMOVAL_FREQUENCY, 4);
        if (set != null && set.size() > 0) {
            mRemovalCfg = new RemovalCfg();
            mRemovalCfg.whiteList = new ArrayList<>(set);
            mRemovalCfg.frequency = frequency;
        }

        String txt = MMKVUtils.getMMKV().getString(Constant.KV_EW_MAP, null);
        try {
            if (!TextUtils.isEmpty(txt)) {
                Type type = new TypeToken<ConcurrentHashMap<String,List<HisavanaConfigInfo>>>() {}.getType();
                ConcurrentHashMap<String,List<HisavanaConfigInfo>> map = new Gson().fromJson(txt, type);
                if (map != null && map.size() > 0) {
                    mEwGlobalInfo = map;
                }
            }
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        if (mEwGlobalInfo == null) {
            mEwGlobalInfo = new ConcurrentHashMap<>();
        }
    }

    private int calculatePositionArrayLength(List<HisavanaConfigInfo> sceneCodeList, int pageIndex, int pageMax) {
        int row = 0;
        int max = (pageIndex+1) * pageMax;
        int min = pageIndex * pageMax;

        if (sceneCodeList == null || sceneCodeList.size() <= 0) {
            return row;
        }

        Iterator<HisavanaConfigInfo> it = sceneCodeList.iterator();
        while (it.hasNext()) {

            HisavanaConfigInfo hisavanaConfigInfo = it.next();

            int tmpRow = 0;
            try {
                String srcRow = hisavanaConfigInfo.getRow();
                String srcCol = hisavanaConfigInfo.getCol();
                if (!TextUtils.isEmpty(srcRow) && !TextUtils.equals("X", srcRow)) {
                    tmpRow = Integer.parseInt(hisavanaConfigInfo.getRow());
                }else if (!TextUtils.isEmpty(srcCol) && !TextUtils.equals("X", srcCol)) { //HOT / search result等无行情况
                    tmpRow = Integer.parseInt(hisavanaConfigInfo.getCol());
                }
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }

            if (max > 0) {
                if (tmpRow >= min && tmpRow < max) {
                    row++;
                }
                //对于搜索结果页特殊处理
                if (tmpRow == RESULT_TOPIC_ROW_80 || tmpRow == RESULT_TOPIC_ROW_90 || tmpRow == RESULT_TOPIC_ROW_91) {
                    row++;
                }
            }else {
                row++;
            }
        }

        return row;
    }

    public TFeedNative sdkLoad(final String sceneCode, String searchContent, String serialNum, int pageIndex, int pageMax, final HisavanaSdkCallBack callBack) {
        return sdkLoad(sceneCode, searchContent, serialNum, pageIndex,pageMax, false, false, null, null, null, callBack);
    }

    /**
     * 加载sdk广告
     * @param sceneCode 场景码 {@link com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode}
     * @param searchContent 搜索关键词，仅搜索结果请求需要
     * @param serialNum 请求id，标识请求的唯一性  {@link CommonUtils#generateSerialNum()}
     * @param pageIndex 分页的页数，第一页index从0开始
     * @param pageMax   分页单页最大数，若不需要分页，则直接传0即可
     * @param callBack  广告回调监听方法  {@link com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkCallBack}
     *
     * */
    public TFeedNative sdkLoad(final String sceneCode, String searchContent, String serialNum, int pageIndex, int pageMax, Boolean isCache, Boolean isEmbeddedData, List<FeatureBean> featureList, FeatureSinglePageData singlePageData, SearchRespInfo searchRespInfo, final HisavanaSdkCallBack callBack) {
        LogUtils.i(TAG, "sceneCode = " + sceneCode);
        FeedAdRequest feedAdRequest;
        TFeedNative tFeedNative;
        List<HisavanaConfigInfo> sceneCodeList = getHisavanaConfigByKey(sceneCode);

        int length = calculatePositionArrayLength(sceneCodeList, pageIndex, pageMax);
        if (length <= 0) {
            if (callBack != null) {
                callBack.onError(new TaErrorCode(-1,"no config value"));
            }
            LogUtils.i(TAG, "will not request sdk ad, because length is zero, length:" + length);
            return null;
        }

        Map<Integer, CategoryCode> categoryCodeMap = new HashMap<>();
        //转换二维数组
        int[][] positionArray = new int[length][];
        int position = -1;
        int max = (pageIndex+1) * pageMax;
        int min = pageIndex * pageMax;

        int lastRow = -100;
        int currentTime = 0;

        Iterator<HisavanaConfigInfo> it = sceneCodeList.iterator();
        while (it.hasNext()) {
            HisavanaConfigInfo hisavanaConfigInfo = it.next();
            String row = hisavanaConfigInfo.getRow();
            String col = hisavanaConfigInfo.getCol();
            if ("X".equals(row)) {
                row = "0";
            }
            if ("X".equals(col)) {
                col = "0";
            }

            int iRow = 0;
            int iCol = 0;
            try {
                iRow = Integer.parseInt(row);
                iCol = Integer.parseInt(col);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }


            if (max > 0) {
                //对于搜索结果页特殊处理
                if(iRow != RESULT_TOPIC_ROW_80 && iRow != RESULT_TOPIC_ROW_90 && iRow != RESULT_TOPIC_ROW_91) {
                    if (TextUtils.equals(sceneCode,SceneCode.A_ho) || TextUtils.equals(sceneCode,SceneCode.A_ne)
                            || TextUtils.equals(sceneCode,SceneCode.G_ho) || TextUtils.equals(sceneCode,SceneCode.A_ne)
                            ) {
                        if (iCol < min || iCol >= max) {
                            continue;
                        }

                    } else {
                        if (iRow < min || iRow >= max) {
                            continue;
                        }
                    }
                }
            }

            if (position < positionArray.length - 1) {
                position ++;

                int[] q = {iRow, iCol};//获取对象成员保存至一维数组
                positionArray[position] = q;

                if (isCache) {
                    if (TextUtils.equals(sceneCode, SceneCode.A_ho) || TextUtils.equals(sceneCode, SceneCode.G_ho)) {
                        if (singlePageData != null) {
                            String category2 = singlePageData.getCategory2();
                            String category3 = singlePageData.getCategory3();
                            CategoryCode categoryCode = new CategoryCode(category2, category3);
                            categoryCodeMap.put(iRow, categoryCode);
                        }
                    } else if (TextUtils.equals(sceneCode, SceneCode.SSR_hl)) {
                        if (searchRespInfo != null) {
                            SearchRespInfo.TermCategory termCategory = searchRespInfo.termCategory;
                            if (termCategory != null) {
                                String category2 = termCategory.category2;
                                String category3 = termCategory.category3;
                                CategoryCode categoryCode = new CategoryCode(category2, category3);
                                categoryCodeMap.put(iRow, categoryCode);
                            }
                        }
                    } else {
                        if (featureList != null && featureList.size() > 0) {
                            if(currentTime < featureList.size()){
                                if(iRow == lastRow){
                                    continue;
                                }else{
                                    FeatureBean featureBean = featureList.get(currentTime);
                                    String category2 = featureBean.category2;
                                    String category3 = featureBean.category3;
                                    CategoryCode categoryCode = new CategoryCode(category2, category3);
                                    categoryCodeMap.put(iRow, categoryCode);

                                    currentTime ++;
                                    lastRow = iRow;
                                }

                            }
                        }
                    }
                }
            }
        }

        final String adPositionId = sceneCodeList.get(0).getAdPositionId();
        tFeedNative = new TFeedNative(adPositionId);
        AdListener listener = new AdListener() {
            @Override
            public void onError(TaErrorCode adError) {
                if (callBack != null) {
                    callBack.onError(adError);
                }
                int errorCode = -1;
                if(adError!=null) {
                    errorCode = adError.getErrorCode();
                }
                TRAnalysticsUtil.trackEWSdkErrorRsp(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_ERROR, null,errorCode, isCache ? HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1 : HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, isEmbeddedData);
                if (adError!=null ){
                    LogUtils.i(TAG, "errorCode:" + adError.getErrorCode() + ",errorMessage:" + adError.getErrorMessage()+" sencode="+sceneCode);
                }

            }

            @Override
            public void onAdLoaded(final List<TaNativeInfo> adInfos) {
                if (callBack != null) {
                    callBack.onAdLoaded(adInfos);
                }
                if(adInfos!=null && adInfos.size()>0) {
                    TRAnalysticsUtil.trackEwRspRecord(adPositionId, sceneCode, TRACK_LOAD_ADS_RSP_SUCCESS, adInfos.size(), HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, isEmbeddedData);
                }
                //todo 防止ANR
                TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
                    @Override
                    public void run() {
                        onTrackEWSDKResponse(adInfos, adPositionId, sceneCode,false, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, isEmbeddedData);
                        if(BuildConfig.DEBUG) {
                            LogUtils.i(TAG, "onAdLoaded = " + (adInfos != null ? adInfos.size() : -1));
                            String s = new Gson().toJson(adInfos);
                            LogUtils.i(TAG, "onAdLoaded sceneCode = " + sceneCode + "------------- " +(s));
                        }
                    }
                });


            }

            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {
                if (callBack != null) {
                    callBack.onAdCache(adInfos);
                }
                if(adInfos!=null && adInfos.size()>0) {
                    TRAnalysticsUtil.trackEwRspRecord(adPositionId, sceneCode, TRACK_LOAD_ADS_RSP_SUCCESS, adInfos.size(), HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1, isEmbeddedData);
                }
                //todo 防止ANR
                TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
                    @Override
                    public void run() {
                        onTrackEWSDKResponse(adInfos, adPositionId, sceneCode,false, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1, isEmbeddedData);
                        if(BuildConfig.DEBUG) {
                            LogUtils.i(TAG, "onAdCache = " + (adInfos != null ? adInfos.size() : -1));
                            String s = new Gson().toJson(adInfos);
                            LogUtils.i(TAG, "onAdCache sceneCode = " + sceneCode + "------------- " +(s));
                        }
                    }
                });
            }

            @Override
            public void onAdShow() {
                LogUtils.i(TAG, "onAdShow");
            }

            @Override
            public void onTimeOut() {
                LogUtils.i(TAG, "onTimeOut");
                TRAnalysticsUtil.trackEWSDKResponse(adPositionId, sceneCode, TRACK_LOAD_ADS_TIME_OUT, null);
                if(callBack!=null) {
                    callBack.onTimeOut();
                }
            }

            @Override
            public void onAdClicked() {
                LogUtils.i(TAG, "onAdClicked");
            }
        };

        FeedAdRequest.Builder builder = new FeedAdRequest.Builder()
                .setAdListener(listener);

        if (!TextUtils.equals(sceneCode, SceneCode.H_nba) && !TextUtils.equals(sceneCode, SceneCode.FLOAT_X)
                && !TextUtils.equals(sceneCode,SceneCode.INSERT_SCREEN_X)) {
            builder.setPositionArray(positionArray)
                    .setSceneCode(sceneCode)
                    .setPsSerialNum(serialNum)
                    .setPsChannel(TRApplicationContextUtil.getChannelType())
                    .setPsCountryCode(PhoneDeviceInfo.getCountryCode());
        } else {
            builder.setSceneCode(sceneCode);
            builder.setAdCount(length);
        }

        if (isCache && categoryCodeMap.size() > 0) {
            builder.setCategoryCodeMap(categoryCodeMap);
        }

        if (!TextUtils.equals(sceneCode, SceneCode.R_SP) && !TextUtils.equals(sceneCode, SceneCode.H_nba)) {
            builder.setPsApiVersion("1.0.7");
        }

        if (!TextUtils.isEmpty(searchContent)) {
            builder.setSearchContent(searchContent);
        }

        if(TextUtils.equals(sceneCode,SceneCode.AR_X) || TextUtils.equals(sceneCode,SceneCode.NR_X)
            || TextUtils.equals(sceneCode,SceneCode.PLUTO_X) || TextUtils.equals(sceneCode,SceneCode.FLOAT_X)
                || TextUtils.equals(sceneCode,SceneCode.INSERT_SCREEN_X) || TextUtils.equals(sceneCode,SceneCode.OO_X)
                  || TextUtils.equals(sceneCode, ME_O) || (TextUtils.equals(sceneCode,SceneCode.RC_X))) {
            builder.setUseCache(true);
        }

        feedAdRequest = builder.build();

        if(isCache) {
            tFeedNative.getCacheAdForRealTime(feedAdRequest);
            TRAnalysticsUtil.trackEwCacheReq(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_STATUS, length,ProcessLifecycleChecker.isAppInBackground(), isEmbeddedData);
        } else {
            tFeedNative.loadAd(feedAdRequest);
            TRAnalysticsUtil.trackEWSDKLoad(adPositionId, sceneCode,length,ProcessLifecycleChecker.isAppInBackground());
        }
        return tFeedNative;
    }

    public void onTrackEWSDKResponse(List<TaNativeInfo> list, String adPositionId, String sceneCode,boolean isCacheReq, int isCache, boolean isEmbeddedData) {
        if (list != null && list.size() > 0) {
            Iterator<TaNativeInfo> it = list.iterator();
            int index = -1;
            while (it.hasNext()) {
                TaNativeInfo info = it.next();
                index++;
                String pkg = null;
                int row = -1;
                int col = -1;

                if (info != null && !TextUtils.isEmpty(info.getAppInfo())) {
                    try {
                        FeatureItemData item = new Gson().fromJson(info.getAppInfo(), FeatureItemData.class);
                        pkg = item.packageName;
                        row = info.getTopicRow();
                        col = info.getTopicColumn();
                    }catch (Exception e){
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
                if (TextUtils.equals(sceneCode, SceneCode.H_nba) || TextUtils.equals(sceneCode, SceneCode.FLOAT_X)
                        || TextUtils.equals(sceneCode,SceneCode.INSERT_SCREEN_X)) {
                    List<HisavanaConfigInfo> infos = HisavanaSdkManager.getInstance()
                            .getHisavanaConfigByKey(sceneCode);
                    if (infos != null && index < infos.size()) {
                        try {
                            HisavanaConfigInfo cfg = infos.get(index);
                            if("X".equalsIgnoreCase(cfg.getRow())) {
                                row = 0;
                            }
                            if (cfg != null) {
                                col = Integer.parseInt(cfg.getCol());
                            }
                        } catch (Exception e) {

                        }
                    }
                }
                if(isCacheReq) {
                    TRAnalysticsUtil.trackEWSDKResponse(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_SUCCESS, pkg,row,col, isCache, isEmbeddedData);
                } else {
                    TRAnalysticsUtil.trackEWSDKResponse(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS, pkg,row,col, isCache, isEmbeddedData);
                }
            }
        } else {
            if(isCacheReq) {
                TRAnalysticsUtil.trackEWSDKResponse(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_SUCCESS_NO_DATA, null);
            } else {
                TRAnalysticsUtil.trackEWSDKResponse(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_NO_DATA, null);
            }
        }
    }

    public void onTrackEWSDKResponseForRealTime(List<TaNativeInfo> list, String adPositionId, String sceneCode) {
        if (list != null && list.size() > 0) {
            Iterator<TaNativeInfo> it = list.iterator();
            int index = -1;
            while (it.hasNext()) {
                TaNativeInfo info = it.next();
                index++;
                String pkg = null;
                int row = -1;
                int col = -1;
                boolean isAttachedRealtimeRequestAd = false;

                if (info != null && !TextUtils.isEmpty(info.getAppInfo())) {
                    try {
                        FeatureItemData item = new Gson().fromJson(info.getAppInfo(), FeatureItemData.class);
                        pkg = item.packageName;
                        row = info.getTopicRow();
                        col = info.getTopicColumn();
                        isAttachedRealtimeRequestAd = info.isAttachedRealtimeRequestAd();
                    }catch (Exception e){
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
                if (TextUtils.equals(sceneCode, SceneCode.H_nba) || TextUtils.equals(sceneCode, SceneCode.FLOAT_X)
                        || TextUtils.equals(sceneCode,SceneCode.INSERT_SCREEN_X)) {
                    List<HisavanaConfigInfo> infos = HisavanaSdkManager.getInstance()
                            .getHisavanaConfigByKey(sceneCode);
                    if (infos != null && index < infos.size()) {
                        try {
                            HisavanaConfigInfo cfg = infos.get(index);
                            if("X".equalsIgnoreCase(cfg.getRow())) {
                                row = 0;
                            }
                            if (cfg != null) {
                                col = Integer.parseInt(cfg.getCol());
                            }
                        } catch (Exception e) {

                        }
                    }
                }
                TRAnalysticsUtil.trackEWSDKResponseForRealtime(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS, pkg, row,col, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, isAttachedRealtimeRequestAd, false);
            }
        } else {
            TRAnalysticsUtil.trackEWSDKResponseForRealTime(adPositionId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_NO_DATA, null);
        }
    }

    public void replaceEwAd(final List<FeatureItemData> liveDataList, final List<RecommendInstallResponse.RecommendGroupInfo> groupStyleDataList, String uniqueId) {
        if(liveDataList == null || liveDataList.isEmpty() || groupStyleDataList == null || groupStyleDataList.isEmpty()) {
            return;
        }
        RecommendInstallResponse.RecommendGroupInfo groupInfo = null;
        List<AppInfo> orgInfoList = null;
        int firstGroupLimit = 8;
        groupInfo = groupStyleDataList.get(0);
        if (groupInfo != null) {
            firstGroupLimit = groupInfo.showCount;
            orgInfoList = groupInfo.itemList;
        }
        LogUtils.d(LogUtils.TAG_TR_INSTALL_INSERT_EW, "firstGroupLimit = " + firstGroupLimit);

        int row = 0;

        Iterator<FeatureItemData> iterator = liveDataList.iterator();

        while (iterator.hasNext()) {
            try {
                FeatureItemData featureItemData = iterator.next();
                row = featureItemData.tNativeInfo.getTopicRow();
                TRInstallCacheData.setEwRowInfo(row);
                AppInfo info = FeatureItemData.convertToAppInfo(featureItemData);
                info.reportSource = HisavanaSdkManager.REPORT_SOURCE_EW;
                info.nativeId = featureItemData.tNativeInfo.getNativeAdId();
                info.adPositionId = featureItemData.tNativeInfo.getPlacementId();
                int fixedColumn = featureItemData.tNativeInfo.getTopicColumn();

                if (fixedColumn >= firstGroupLimit) {
                    if (groupStyleDataList.size() >= 3) {
                        groupInfo = groupStyleDataList.get(2);
                        if (groupInfo != null) {
                            orgInfoList = groupInfo.itemList;
                            LogUtils.d(LogUtils.TAG_TR_INSTALL_INSERT_EW, "insert third group fixedColumn orginal = " + fixedColumn);
                            fixedColumn = fixedColumn - firstGroupLimit;
                            row = 2;
                            LogUtils.d(LogUtils.TAG_TR_INSTALL_INSERT_EW, "insert third group fixedColumn = " + fixedColumn);
                        } else {
                            orgInfoList = null;
                        }
                    } else {
                        orgInfoList = null;
                    }
                }
                if (orgInfoList == null || fixedColumn < 0 || fixedColumn > orgInfoList.size() || fixedColumn > groupInfo.showCount) {
                    return;
                }

                String positionID = HisavanaSdkManager.getInstance().getEwScenePositionID(SceneCode.AR_X);
                if(fixedColumn< groupInfo.itemList.size()) {
                    List<TaNativeInfo> list = TRInstallCacheData.getNativeAdListForTrackShows();
                    if(list != null && !list.isEmpty()) {
                        Iterator<TaNativeInfo> it = list.iterator();
                        while (it.hasNext()) {
                            TaNativeInfo taNativeInfo = it.next();
                            FeatureItemData appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                            if (TextUtils.equals(appinfo.packageName, groupInfo.itemList.get(fixedColumn).packageName)) {
                                it.remove();
                                break;
                            }
                        }
                    }
                }
                if(fixedColumn == groupInfo.itemList.size() && groupInfo.itemList.size() < groupInfo.showCount) {
                    orgInfoList.add(fixedColumn,info);
                    cacheAppIcon(info.iconUrl);
                    TRInstallCacheData.saveSelectDataForReplaceEw(info, true);
                    TRInstallCacheData.saveNativeAd(featureItemData.tNativeInfo);
                    TRAnalysticsUtil.trackAddShowQueue(positionID, SceneCode.AR_X, TRACK_LOAD_ADS_ADD_QUEUE,
                            featureItemData.packageName, row, fixedColumn,featureItemData.tNativeInfo.isAttachedRealtimeRequestAd(), uniqueId);
                }else if(fixedColumn < groupInfo.itemList.size()){
                    AppInfo appInfo = orgInfoList.get(fixedColumn);
                    TRInstallCacheData.removeNativeAd(appInfo.taNativeInfo);
                    TRInstallCacheData.saveSelectDataForReplaceEw(appInfo, false);
                    orgInfoList.set(fixedColumn, info);
                    cacheAppIcon(info.iconUrl);
                    TRInstallCacheData.saveSelectDataForReplaceEw(info, true);
                    TRInstallCacheData.saveNativeAd(featureItemData.tNativeInfo);
                    TRAnalysticsUtil.trackAddShowQueue(positionID, SceneCode.AR_X, TRACK_LOAD_ADS_ADD_QUEUE,
                            featureItemData.packageName, row, fixedColumn,featureItemData.tNativeInfo.isAttachedRealtimeRequestAd(), uniqueId);
                }

            }catch (Throwable t) {
                LogUtils.e(LogUtils.TAG_TR_INSTALL_LIVE, "replaceEwAd error = " + t.getMessage());
            }
        }

    }

    /**
     * 获取server端下发的配置信息
     * @param key 场景key
     * @return 此场景的所有信息
     */
    public List<HisavanaConfigInfo> getHisavanaConfigByKey(String key) {

        if(TextUtils.isEmpty(key)) {
            return null;
        }
        //主要用于第一次冷启动获取缓存
        StartUpTabsCache.getInstance().init();

        if(mEwGlobalInfo == null || mEwGlobalInfo.isEmpty()) {
            return null;
        }

        List<HisavanaConfigInfo> srcList = mEwGlobalInfo.get(key);
        if (BuildConfig.DEBUG && ME_O.equals(key) && srcList != null && srcList.size() > 0) {
            for(HisavanaConfigInfo info:srcList) {
                LogUtils.d(LogUtils.TAG_TR_INSTALL_EW, "getHisavanaConfigByKey info = " + info.toString());
            }
        }
        if(srcList != null && srcList.size() > 0) {
            return srcList;
        }

        return null;
    }

    public List<Pair<Integer,Integer>> getAdPosArray(String sceneCode) {
        List<Pair<Integer,Integer>> positionArray = new ArrayList<Pair<Integer,Integer>>();
        try {
            List<HisavanaConfigInfo> sceneCodeList = getHisavanaConfigByKey(sceneCode);
            if (BuildConfig.DEBUG) {
                LogUtils.i(TAG, "getPosArray sceneCode = " + sceneCode + " sceneCodeList = " + GsonUtil.toJson(sceneCodeList));
            }
            int length = calculatePositionArrayLength(sceneCodeList, 0, 0);
            if (length <= 0) {
                LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, "getPosArray length <= 0");
                TRAnalysticsUtil.trackEWSDKPosArrayNullForRealTime(sceneCode);
                return null;
            }
            Iterator<HisavanaConfigInfo> it = sceneCodeList.iterator();
            while (it.hasNext()) {
                try {
                    HisavanaConfigInfo hisavanaConfigInfo = it.next();
                    String row = hisavanaConfigInfo.getRow();
                    String col = hisavanaConfigInfo.getCol();
                    if ("X".equals(row)) {
                        row = "0";
                    }
                    if ("X".equals(col)) {
                        col = "0";
                    }
                    int rowInt = Integer.parseInt(row);
                    int colInt = Integer.parseInt(col);
                    Pair pair = new Pair(rowInt, colInt);
                    positionArray.add(pair);
                } catch (Throwable t) {
                    LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, "getPosArray error = " + t.getMessage());
                }
            }

            // 根据Pair的first和second进行排序
            Collections.sort(positionArray, (p1, p2) -> {
                // 首先按first排序
                int firstCompare = Integer.compare((int)p1.first, (int)p2.first);
                if (firstCompare != 0) {
                    return firstCompare;
                }
                // 如果first相等，则按second排序
                return Integer.compare((int)p1.second, (int)p2.second);
            });

        }catch (Exception e){
            LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, "getPosArray error = " + e.getMessage());
        }
        return positionArray;
    }

    public int[][] getPosArray(String sceneCode) {
        try {
            List<HisavanaConfigInfo> sceneCodeList = getHisavanaConfigByKey(sceneCode);
            int length = calculatePositionArrayLength(sceneCodeList, 0, 0);
            if (length <= 0) {
                LogUtils.e(LogUtils.TAG_TR_INSTALL_EW, "getPosArray length <= 0");
                TRAnalysticsUtil.trackEWSDKPosArrayNullForRealTime(sceneCode);
                return null;
            }
            //转换二维数组
            int[][] positionArray = new int[length][];
            int position = -1;

            Iterator<HisavanaConfigInfo> it = sceneCodeList.iterator();
            while (it.hasNext()) {
                HisavanaConfigInfo hisavanaConfigInfo = it.next();
                String row = hisavanaConfigInfo.getRow();
                String col = hisavanaConfigInfo.getCol();
                if ("X".equals(row)) {
                    row = "0";
                }
                if ("X".equals(col)) {
                    col = "0";
                }

                int iRow = 0;
                int iCol = 0;
                try {
                    iRow = Integer.parseInt(row);
                    iCol = Integer.parseInt(col);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }

                if (position < positionArray.length - 1) {
                    position++;
                    int[] q = {iRow, iCol};//获取对象成员保存至一维数组
                    positionArray[position] = q;
                }
            }
            if (BuildConfig.DEBUG) {
                for (int i = 0; i < positionArray.length; i++) {
                    LogUtils.d(LogUtils.TAG_TR_INSTALL_EW, "getPosArray positionArray[" + i + "] = " + positionArray[i][0] + " " + positionArray[i][1]);
                }
            }
            return positionArray;
        }catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return null;
    }

    public void clearEwConfigByKey(String key) {
        if(mEwGlobalInfo != null && mEwGlobalInfo.containsKey(key)) {
            try {
                mEwGlobalInfo.remove(key);
                MMKVUtils.getMMKV().putString(Constant.KV_EW_MAP, new Gson().toJson(mEwGlobalInfo));
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
    }
    public void setRemovalConfig(RemovalCfg cfg) {
        mRemovalCfg = cfg;
    }

    public void setHisavanaMap(Map<String, List<HisavanaConfigInfo>> map) {
        if (mEwGlobalInfo != null) {
            mEwGlobalInfo.clear();
            mEwGlobalInfo.putAll(map);
        }
    }

    /**
     * 获取去重白名单列表
     * @return
     */
    public ArrayList<String> getRemovalWhiteList() {
        if(mRemovalCfg == null || mRemovalCfg.whiteList == null) {
            return null;
        }
        return mRemovalCfg.whiteList;
    }

    private static void cacheAppIcon(String iconUrl) {
        if (!TextUtils.isEmpty(iconUrl)) {
            TRBitmapManager.prefetchToBitmapCacheByFresco(iconUrl, 0, 0);
        }
    }

    /**
     * 指定包是否在白名单
     * @param pkg
     * @return
     */
    public boolean pkgInWhiteList(String pkg) {
        if(TextUtils.isEmpty(pkg)) {
            return false;
        }
        if(mRemovalCfg == null|| mRemovalCfg.whiteList == null ) {
            return false;
        }
        if(mRemovalCfg.whiteList.contains(pkg)) {
            return true;
        }
        return false;
    }

    /**
     * 获取去重频次
     * @return
     */
    public int getRemovalFrequency() {
        if(mRemovalCfg == null) {
            return 0;
        }
        return mRemovalCfg.frequency;
    }

    /**
     * 数据去重处理
     * @param featureBeanList ps返回数据列表
     * @param ewAdData ew广告数据实体
     * @return true 不合规 过滤  false 合规
     */
    public void filterValidateAd(List<FeatureBean> featureBeanList, FeatureItemData ewAdData) {
        filterValidateAd(featureBeanList, ewAdData, null);
    }

    /**
     * 数据去重处理
     * @param featureBeanList ps返回数据列表
     * @param ewAdData ew广告数据实体
     * @return true 不合规 过滤  false 合规
     */
    public void filterValidateAd(List<FeatureBean> featureBeanList, FeatureItemData ewAdData, List<String> repeatList) {
        String packageName = ewAdData.packageName;
        for (FeatureBean featureBean : featureBeanList) {
            removeSamePackage(featureBean.dataList, packageName, repeatList);
        }
    }
  /**
     * 数据去重处理
     * @param featureBeanList ps返回数据列表
     * @param packageName ew广告数据实体
     * @return true 不合规 过滤  false 合规
     */
    public void filterValidateAdByFeatureSinglePageItemData(List<FeatureSinglePageItemData> featureBeanList,  String packageName) {
        Iterator<FeatureSinglePageItemData> it = featureBeanList.iterator();
        while (it.hasNext()) {
            FeatureSinglePageItemData item = it.next();
            if (TextUtils.equals(item.packageName, packageName)) {
                LogUtils.d("SspSdkManager", "filterPageDuplicateByAppInfo : " + packageName);
                //移除相同的包
                it.remove();
                break;
            }
        }
    }

    /**
     * 数据去重处理
     */
    public void filterValidateAdByAppInfo(List<AppInfo> list, String packageName) {

        try {
            if(list instanceof CopyOnWriteArrayList){
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    AppInfo appInfo = list.get(i);
                    if(appInfo!=null && TextUtils.equals(appInfo.packageName, packageName)){
                        LogUtils.d("SspSdkManager", "filterPageDuplicateByAppInfo : " + packageName);
                        //移除相同的包
                        //如果是CopyOnWriteArrayList的场景下，使用迭代器删除会有问题，内部没有实现remove方法
                        //CopyOnWriteArrayList在轮询遍历的时候，index不用--,可以正常遍历
                        list.remove(i);
                    }
                }
            }else{
                Iterator<AppInfo> it = list.iterator();
                while (it.hasNext()) {
                    AppInfo item = it.next();
                    if (TextUtils.equals(item.packageName, packageName)) {
                        LogUtils.d("SspSdkManager", "filterPageDuplicateByAppInfo : " + packageName);
                        //移除相同的包
                        it.remove();
                        break;
                    }
                }
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    /**
     * 新的数据格式的数据去重
     */
    public void filterValidateRecommendAdByAppInfo(List<RecommendBean.NewStyle.CategoryList> list, String packageName) {
        Iterator<RecommendBean.NewStyle.CategoryList> iterator = list.iterator();
        while (iterator.hasNext()) {
            RecommendBean.NewStyle.CategoryList item = iterator.next();
            if(item!=null){
                List<AppInfo> itemList = item.itemList;
                if(itemList!=null){
                    filterValidateAdByAppInfo(itemList, packageName);
                }
            }
        }
    }

    /**
     * 数据去重处理
     */
    public void filterValidateAdByRankDataListItem(List<RankModel> itemList, String packageName) {
        Iterator<RankModel> it = itemList.iterator();
        while (it.hasNext()) {
            RankModel item = it.next();
            RankDataListItem itemValue = item.rankData.itemList.get(0);
            if (TextUtils.equals(itemValue.packageName, packageName)) {
                LogUtils.d("SspSdkManager", "filterValidateAdByRankDataListItem : " + packageName);
                //移除相同的包
                it.remove();
                break;
            }
        }
    }

    /**
     * 移除多页中重复的数据
     * @param originFeatureList
     * @param newFeatureList
     */
    public void removeDuplicateData(List<FeatureBean> originFeatureList, List<FeatureBean> newFeatureList, Map<String, Integer> addedMaps, String sceneCode) {
        if(getRemovalFrequency() == 0) {
            //频次是0， 不进行去重操作
            return;
        }

        for (int i = 0; i < originFeatureList.size(); i++) {
            FeatureBean featureBean = originFeatureList.get(i);
            List<FeatureBaseData> dataList = featureBean.dataList;
            if (dataList != null) {
                for (int j = 0; j < dataList.size(); j++) {
                    //循环拿到之前存在的所有包信息
                    FeatureBaseData featureBaseData = dataList.get(j);
                    if (featureBaseData instanceof FeatureItemData) {
                        FeatureItemData item = (FeatureItemData) featureBaseData;
                        if (TextUtils.isEmpty(item.packageName)) {
                            continue;
                        }
                        for (int k = 0; k < newFeatureList.size(); k++) {
                            //循环获取新刷新的页面的包信息
                            FeatureBean newFeatureBean = newFeatureList.get(k);
                            //校验当前包是否符合白名单、频次判断
                            removeSamePackage(newFeatureBean.dataList, item.packageName, addedMaps, sceneCode, null);
                        }
                    }
                }
            }
        }

    }

    /**
     * 校验包是否有效
     * @return true 有效 false 无效
     */
    private boolean checkPkgValidate(String pkgName, Map<String, Integer> addedMaps) {
        if(pkgInWhiteList(pkgName)) {
            return true;
        }
        Integer numbers = addedMaps.get(pkgName);
        if(numbers == null) {
            if(getRemovalFrequency() <= 1) {
                return false;
            }else {
                addedMaps.put(pkgName, 2);
                return true;
            }
        }else {
            if(numbers < getRemovalFrequency()) {
                numbers += 1;
                addedMaps.put(pkgName, numbers);
                LogUtils.d("SspSdkManager", "put times : " + pkgName + "    numbers: " + numbers);
                return true;
            }else {
                return false;
            }
        }
    }


    /**
     * 从List中移除相同包名的包
     * @param featureBaseDataList 给定的列表
     * @param pkgName 要移除的包名
     */
    private void removeSamePackage(List<FeatureBaseData> featureBaseDataList, String pkgName, List<String> repeatList) {
        removeSamePackage(featureBaseDataList, pkgName, null, "", repeatList);
    }

    /**
     * 从List中移除相同包名的包
     * @param featureBaseDataList 给定的列表
     * @param pkgName 要移除的包名
     * @param sceneCode
     */
    public void removeSamePackage(List<FeatureBaseData> featureBaseDataList, String pkgName, Map<String, Integer> addedMaps, String sceneCode, List<String> repeatList) {
        if(featureBaseDataList == null || TextUtils.isEmpty(pkgName)) {
            return;
        }
        Iterator<FeatureBaseData> iterator = featureBaseDataList.iterator();
        while (iterator.hasNext()) {
            FeatureBaseData next = iterator.next();
            if (next instanceof FeatureItemData) {
                FeatureItemData item = (FeatureItemData) next;
                if (BuildConfig.DEBUG) {
                    LogUtils.d("SspSdkManager", "主包名: " + pkgName + " ---  推荐列表包名: " + item.packageName);
                }
                if (TextUtils.equals(item.packageName, pkgName) && (addedMaps == null || !checkPkgValidate(item.packageName, addedMaps))) {
                    LogUtils.d("SspSdkManager", "filterPageDuplicate : " + pkgName);
                    if (item.tNativeInfo != null && !TextUtils.isEmpty(sceneCode)) {
                        //ew广告 && 两页去重场景
                        TRAnalysticsUtil.trackEwFilterInfo(sceneCode, TRAnalyticsConstant.ERROR_MSG_APP_REPEAT);
                    }

                    if (item.reportDto != null && Objects.equals(item.reportDto.reportSource, Constant.REPORT_SOURCE_BEDDING)) {
                        TRAnalysticsUtil.trackEwBeddingFilterInfo(sceneCode, TRAnalyticsConstant.ERROR_MSG_APP_REPEAT, pkgName);
                        if (repeatList != null) {
                            repeatList.add(item.packageName);
                        }
                    }
                    //移除相同的包
                    iterator.remove();
                    break;
                }
            }
        }
    }

    /**
     * 发起提醒式场景的EW请求
     */
    public void requestEwAdForPluto() {
        String serialNum = CommonUtils.generateSerialNum();
        String sceneCode = SceneCode.PLUTO_X;
        sdkLoad(sceneCode,"",serialNum,0,0, new HisavanaSdkCallBack() {
            @Override
            public void onError(TaErrorCode adError) {
                if(adError!=null) {
                    LogUtils.e(TAG,"adError="+adError.getErrorMessage()+" code="+adError.getErrorCode());
                }
                TRSharedPreferenceUtils.put(TRSharedPreferenceUtils.PLUTO_EW_STATUS_FILE_NAME,
                        GetRemindMessageTask.KEY_REQUEST_EW_STATUS,0);
            }

            @Override
            public void onAdLoaded(List<TaNativeInfo> adInfo) {
                if(adInfo!=null && adInfo.size()>0) {
                    for(TaNativeInfo item:adInfo) {
                        LogUtils.e(TAG,item.getAppInfo()+" count="+adInfo.size());
                    }
                }
                TRSharedPreferenceUtils.put(TRSharedPreferenceUtils.PLUTO_EW_STATUS_FILE_NAME,
                        GetRemindMessageTask.KEY_REQUEST_EW_STATUS,1);
                GetRemindMessageTask.getInstance().startUploadEwStatusToServer(GetRemindMessageTask.EW_PL_RSP);
            }

            @Override
            public void onAdClicked() {

            }

            @Override
            public void onTimeOut() {
                TRSharedPreferenceUtils.put(TRSharedPreferenceUtils.PLUTO_EW_STATUS_FILE_NAME,
                        GetRemindMessageTask.KEY_REQUEST_EW_STATUS,0);
            }

            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {

            }
        });
    }

    /**
     * 展示Pluto场景
     * @param
     */
    public void readyShowPlutoScene() {
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(SceneCode.PLUTO_X);
        if(list == null || list.size()==0) {
            TRAnalysticsUtil.trackExceptionInfo("", SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, PLUTO_EXCEPTION_CODE_NULL);
            return;
        }

        if(list.get(0)==null) {
            return;
        }
        final String positionID = list.get(0).getAdPositionId();
        if (TextUtils.isEmpty(positionID)) {
            LogUtils.e(TAG, "SceneCode:" + SceneCode.PLUTO_X + " positionID=null");
            TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, EXCEPTION_POSITIONID_NULL);
            return;
        }

        //todo 屏蔽判断plutoOfferResponseModel存在空
//        if(plutoOfferResponseModel == null || plutoOfferResponseModel.getData()==null
//                || plutoOfferResponseModel.getData().getPush()==null) {
//            TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, PLUTO_EXCEPTION_CODE_ORG);
//        }

        TFeedNative feedNative = new TFeedNative(positionID);
        feedNative.setListener(new AdListener() {
            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {
                //todo 场景show
                try {
                    int count = adInfos!=null? adInfos.size() : 0;

                    TRAnalysticsUtil.trackEwRspRecord(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_RSP_SUCCESS,count, 0, false);
                    onTrackEWSDKResponse(adInfos, positionID, SceneCode.PLUTO_X,true, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1, false);

                    PlutoOfferResponseModel.DataBean.PushBean dataBean = PlutoOfferResponseModel.convertPlutoModel(adInfos);
                    if(dataBean == null || dataBean.getApkList() == null || dataBean.getApkList().size() == 0) {
                        LogUtils.e(TAG,"dataBean is null ");
                        TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_ADS_EXCEPTION, PLUTO_EXCEPTION_CODE_NULL);
                        return;
                    }

                    PlutoOfferResponseModel plutoOfferResponseModel = new PlutoOfferResponseModel();
                    plutoOfferResponseModel.setData(new PlutoOfferResponseModel.DataBean());
                    plutoOfferResponseModel.getData().setPush(dataBean);

                    if(plutoOfferResponseModel == null || plutoOfferResponseModel.getData()==null
                            || plutoOfferResponseModel.getData().getPush()==null) {
                        TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_ADS_EXCEPTION, PLUTO_EXCEPTION_CODE_ORG);
                        return;
                    }
                    List<PlutoOfferResponseModel.DataBean.PushBean.ApkListBean> apkList = dataBean.getApkList();
                    for(PlutoOfferResponseModel.DataBean.PushBean.ApkListBean bean:apkList) {
                        int row = -1;
                        int col = -1;
                        if(bean.taNativeInfo!=null) {
                            row = bean.taNativeInfo.getTopicRow();
                            col = bean.taNativeInfo.getTopicColumn();
                        }
                        TRAnalysticsUtil.trackAddShowQueue(positionID,SceneCode.PLUTO_X,TRACK_LOAD_ADS_ADD_QUEUE,bean.getApkPkgName(),row,col);
                    }
                   // plutoOfferResponseModel.getData().getPush().setApkList(apkList);
                    PlutoDialog mPlutoDialog = new PlutoDialog(PalmplayApplication.getPalmplayApplicationInstance(), plutoOfferResponseModel);
                    mPlutoDialog.setShowType(PlutoDialog.SHOW_TYPE_EW);
                    mPlutoDialog.show();
                    SPManager.putInt(SPKey.KEY_REMIND_DIALOG_SHOW_STATUS, 1);
                } catch (Exception e) {
                    LogUtils.e(TAG,"start show Dialog " + e.getMessage());
                }
            }

            @Override
            public void onError(TaErrorCode adError) {
                super.onError(adError);
                String errorStr = "";
                int errorCode = -1;
                if(adError!=null) {
                    errorStr = adError.getErrorMessage();
                    LogUtils.e(TAG,"get sdk data " + errorStr);
                    errorCode = adError.getErrorCode();
                }
                TRAnalysticsUtil.trackEWSdkErrorRsp(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_ERROR, errorStr,errorCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
            }
            @Override
            public void onTimeOut() {
                LogUtils.e(TAG,"start show Dialog onTimeOut");
                TRAnalysticsUtil.trackEWSDKResponse(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_TIME_OUT, null);
            }
        });
        TRAnalysticsUtil.trackEwCacheReq(positionID, SceneCode.PLUTO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_STATUS, list.size(),ProcessLifecycleChecker.isAppInBackground(), false);
        feedNative.getCacheAd(list.size(), SDK_LOAD_PLUTO_CACHE_TIMEOUT);
    }

    public void requestEwAdForNewPhoneRecommend(NewPhoneRecommendEwAdCallback callback) {
        String serialNum = CommonUtils.generateSerialNum();
        HisavanaSdkManager.getInstance().sdkLoad(SceneCode.OO_X,"",serialNum,0,0, new HisavanaSdkCallBack() {
            @Override
            public void onError(TaErrorCode adError) {
                callback.onError(adError);
            }

            @Override
            public void onAdLoaded(List<TaNativeInfo> adInfo) {
                callback.onAdLoaded(adInfo);
            }

            @Override
            public void onAdClicked() {

            }

            @Override
            public void onTimeOut() {

            }

            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {

            }
        });
    }

    /**
     * 获取新客提醒场景缓存广告
     */
    public void getNewPhoneRecommendCacheAd(Context context, NewPhoneRecommendEwCacheAdCallback callback) {
        final String positionID = getEwScenePositionID(SceneCode.OO_X);
        if(TextUtils.isEmpty(positionID)) {
            LogUtils.e(TAG,"SceneCode:"+SceneCode.OO_X+" positionID=null");
            if (callback != null) {
                callback.onError(null);
            }
            return;
        }

        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(SceneCode.OO_X);
        if(list == null || list.size()==0) {
            if (callback != null) {
                callback.onError(null);
            }
            TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.OO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, PLUTO_EXCEPTION_CODE_NULL);
            return;
        }

        TFeedNative feedNative = new TFeedNative(positionID);
        feedNative.setListener(new AdListener() {
            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {
                //todo 场景show
                try {
                    int count = adInfos!=null? adInfos.size() : 0;
                    TRAnalysticsUtil.trackEwRspRecord(positionID, SceneCode.OO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_RSP_SUCCESS,count, 0, false);
                    onTrackEWSDKResponse(adInfos, positionID, SceneCode.OO_X,true, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_1, false);

                    if (adInfos != null) {
                        int size = adInfos.size();
                        List<AppDetailInfo> appList = new ArrayList<>();
                        List<TaNativeInfo> trackShowsList = new ArrayList<>();
                        for (int i = 0; i < size; i++) {
                            TaNativeInfo taNativeInfo = adInfos.get(i);
                            if (!taNativeInfo.isIconType()) {
                                //continue
                            } else {
                                //icon类广告
                                com.transsion.newphonerecommend.bean.AppInfo appinfo = null;
                                try {
                                    appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), com.transsion.newphonerecommend.bean.AppInfo.class);
                                    if (appinfo != null) {
                                        appinfo.tNativeInfo = taNativeInfo;
                                        appinfo.adPositionId = taNativeInfo.getPlacementId();
                                        appinfo.nativeId = taNativeInfo.getNativeAdId();
                                    }
                                } catch (GsonUtil.GsonParseException e) {
                                    if (BuildConfig.DEBUG) e.printStackTrace();
                                }

                                if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {
                                    if (PackageUtil.checkApkExist(context, appinfo.packageName, appinfo.getVersionCode())) {
                                        TRAnalysticsUtil.trackEwFilterInstalled(SceneCode.OO_X, TRAnalyticsConstant.ERROR_MSG_INSTALLED,appinfo.packageName);
                                        LogUtils.d("HisavanaSdk add ad for feature failed, because the app:" + appinfo.packageName + ", is installed.");
                                    } else {
                                        AppDetailInfo detailInfo = AppDetailInfo.convertToAppDetailInfo(appinfo);
                                        appList.add(detailInfo);
                                        //用于sdk数据上报
                                        trackShowsList.add(taNativeInfo);
                                    }
                                }
                            }
                        }

                        if (appList.size() > 0) {
                            for(AppDetailInfo bean: appList) {
                                int row = -1;
                                int col = -1;
                                if(bean.tNativeInfo!=null) {
                                    row = bean.tNativeInfo.getTopicRow();
                                    col = bean.tNativeInfo.getTopicColumn();
                                }
                                TRAnalysticsUtil.trackAddShowQueue(positionID,SceneCode.OO_X,TRACK_LOAD_ADS_ADD_QUEUE,bean.getPkgName(),row,col);
                            }
                        } else {
                            LogUtils.e(TAG,"dataBean is null ");
                            TRAnalysticsUtil.trackExceptionInfo(positionID, SceneCode.OO_X, HisavanaSdkManager.TRACK_LOAD_ADS_EXCEPTION, PLUTO_EXCEPTION_CODE_NULL);
                        }

                        if (callback != null) {
                            callback.onAdLoaded(new Gson().toJson(appList), trackShowsList);
                        }
                    }
                } catch (Exception e) {
                    if (callback != null) {
                        callback.onError(null);
                    }
                    LogUtils.e(TAG,"start show Dialog " + e.getMessage());
                }
            }

            @Override
            public void onError(TaErrorCode adError) {
                super.onError(adError);
                if (callback != null) {
                    callback.onError(adError);
                }
                String errorStr = "";
                int errorCode = -1;
                if(adError!=null) {
                    errorStr = adError.getErrorMessage();
                    errorCode = adError.getErrorCode();
                    LogUtils.e(TAG,"get sdk data " + errorStr);
                }
                TRAnalysticsUtil.trackEWSdkErrorRsp(positionID, SceneCode.OO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_ERROR, errorStr,errorCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
            }
            @Override
            public void onTimeOut() {
                if (callback != null) {
                    callback.onTimeOut();
                }
                LogUtils.e(TAG,"start show Dialog onTimeOut");
                TRAnalysticsUtil.trackEWSDKResponse(positionID, SceneCode.OO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_TIME_OUT, null);
            }
        });
        TRAnalysticsUtil.trackEwCacheReq(positionID, SceneCode.OO_X, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_STATUS, list.size(),ProcessLifecycleChecker.isAppInBackground(), false);
        feedNative.getCacheAd(list.size(), SDK_LOAD_PLUTO_CACHE_TIMEOUT);
    }

    /**
     * 请求一键安装的EW SDK数据
     * @param type
     */
    public void requestEwAdForOneKeyInstall(final int type) {
        String serialNum = CommonUtils.generateSerialNum();
        String sceneCode = SceneCode.NR_X;
        if(type == 1) {
            sceneCode = SceneCode.AR_X;
        }
        HisavanaSdkManager.getInstance().sdkLoad(sceneCode,"",serialNum,0,0, new HisavanaSdkCallBack() {
            @Override
            public void onError(TaErrorCode adError) {
                if(type == 1) {
                    TRSharedPreferenceUtils.setEWInstallRequest(System.currentTimeMillis());
                    TRInstallManager.isEwInstallRequesting = false;
                }else if (type == 0) {
                    if (adError != null && adError.getErrorCode() == -1) {
                        OptimizeUtils.setRecomendEWNoConfig(true);
                    }
                }
                if(adError!=null) {
                    LogUtils.e(LogUtils.TAG_TR_INSTALL_REQUEST, "ew --> load error :" + adError.getErrorMessage());
                }
            }

            @Override
            public void onAdLoaded(List<TaNativeInfo> adInfo) {
                //todo 屏蔽此代码缓存EW SDK做
//                String fileName = NR_JSON_FILE_NAME;
//                String jsonStr = "";
//                if(type == 1) {
//                    fileName = AR_JSON_FILE_NAME;
//                }
//                if(adInfo!=null && adInfo.size()>0) {
//                    try {
//                        jsonStr = new Gson().toJson(adInfo);
//                        FilePathManager.jsonToFile(jsonStr, fileName);
//                    } catch (Exception e) {
//
//                    }
//                }
                if(type == 1) {
                    TRSharedPreferenceUtils.setSilentMustInstallRequestTimes(0);
                    TRInstallManager.isEwInstallRequesting = false;
                    TRSharedPreferenceUtils.setEWInstallRequest(System.currentTimeMillis());
                    if (adInfo != null && adInfo.size() > 0) {
                        LogUtils.e(LogUtils.TAG_TR_INSTALL_REQUEST, "ew --> load install data success");
                        TRSharedPreferenceUtils.setEwRequestStatus(true);
                    }
                }

            }

            @Override
            public void onAdClicked() {

            }

            @Override
            public void onTimeOut() {
                if(type == 1) {
                    TRSharedPreferenceUtils.setEWInstallRequest(System.currentTimeMillis());
                    TRInstallManager.isEwInstallRequesting = false;
                    LogUtils.e(LogUtils.TAG_TR_INSTALL_REQUEST, "ew --> load timeout");
                }
            }

            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {

            }
        });
    }

    /**
     * 获取指定场景码开关
     * @param sceneCode
     * @return
     */
    public boolean isOpenEwScene(String sceneCode) {
        boolean result = true;
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(sceneCode);
        if(list == null || list.size()==0) {
            result = false;
        }
        return result;
    }

    /**
    * 获取指定场景,指定位置ad样式
    * */
    public int getAdStyleConfig(String sceneCode, int position, int extraType) {
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(sceneCode);
        if(list == null || list.size() == 0 || position < 0) {
            return AD_STYLE_0;
        }

        int adStyle = AD_STYLE_0;
        try {
            for (HisavanaConfigInfo hisavanaConfigInfo : list) {
                String col = hisavanaConfigInfo.getCol();
                String row = hisavanaConfigInfo.getRow();
                //少结果
                if (extraType == 2) {
                    if (TextUtils.equals(row, String.valueOf(HisavanaSdkManager.RESULT_TOPIC_ROW_80)) && TextUtils.equals(col, String.valueOf(position))) {
                        adStyle = hisavanaConfigInfo.getAdStyle();
                        break;
                    }
                } else {
                    if (TextUtils.equals(col, String.valueOf(position))) {
                        adStyle = hisavanaConfigInfo.getAdStyle();
                        break;
                    }
                }
            }
        } catch (Exception e) {

        }
        return adStyle;
    }

    /**
     * 判断指定场景下ew广告是否去重,false = 去重，true = 不去重
     * */
    public boolean isShowAdLabel(String sceneCode, int position) {
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(sceneCode);
        if(list == null || list.size() == 0 || position < 0) {
            return false;
        }

        try {
            String isRepeatSceneStr = MMKVUtils.getMMKV().getString(Constant.KV_EW_IS_REPEAT, "");
            if (!TextUtils.isEmpty(isRepeatSceneStr)) {
                String[] split = isRepeatSceneStr.split(",");
                for (String s : split) {
                    if (s.equalsIgnoreCase(sceneCode)) {
                        for (HisavanaConfigInfo hisavanaConfigInfo : list) {
                            String col = hisavanaConfigInfo.getCol();
                            if (TextUtils.equals(col, String.valueOf(position))) {
                                int adStyle = hisavanaConfigInfo.getAdStyle();
                                if (adStyle == HisavanaSdkManager.AD_STYLE_1 || adStyle == HisavanaSdkManager.AD_STYLE_2) {
                                   return true;
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        } catch (Exception e) {

        }

        return false;
    }

    /**
     * 获取指定场景的代码位ID
     * @param sceneCode
     * @return
     */
    public String getEwScenePositionID(String sceneCode) {
        String positionID = "";
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(sceneCode);
        if(list == null || list.size()==0) {
            return positionID;
        }
        try {
            positionID = list.get(0).getAdPositionId();
        } catch (Exception e) {

        }
        return positionID;
    }

    /**
     * 判断指定场景的缓存
     * @param sceneCode
     * @return
     */
    public boolean hasSceneCache(String sceneCode) {
        String positionID = "";
        positionID = getEwScenePositionID(sceneCode);

        if(TextUtils.isEmpty(positionID)) {
            return false;
        }
        TFeedNative tFeedNative = new TFeedNative(positionID);
        boolean hasSceneCache = tFeedNative.isHaveCache(Constants.ASKSCENE.ENTER_SCENE_ASK);
        if(hasSceneCache) {
            TRAnalysticsUtil.trackEWSDKResponse(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_HAS_CACHE, null);
        } else {
            TRAnalysticsUtil.trackEWSDKResponse(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_NO_CACHE, null);
        }
        return hasSceneCache;
    }

    /**
     * 保存已安装过滤的位置信息
     * @param sceneCode
     * @return
     */
    public void saveInstalledPosition(String sceneCode, int row , int col) {
        List<PositionInfo> positionInfos = lineMap.get(sceneCode + row);
        PositionInfo positionInfo = new PositionInfo(row, col);
        if (positionInfos == null) {
            List<PositionInfo> pList = new ArrayList<>();
            pList.add(positionInfo);
            lineMap.put(sceneCode + row, pList);
        } else {
            positionInfos.add(positionInfo);
        }
    }

    /**
     * 根据场景码获取指定已安装过滤的位置信息,并替换成新的位置
     * @param key
     * @return
     */
    public int getInstalledPosition(String key, int row, int col) {
        int intstalledCol = -1;
        if (!lineMap.isEmpty()) {
            List<PositionInfo> positionInfos = lineMap.get(key);
            if (positionInfos != null && !positionInfos.isEmpty()) {
                PositionInfo positionInfo = positionInfos.get(0);
                intstalledCol = positionInfo.getCol();

                //删除已经填充过的，把新的未填充的位置添加进来
                positionInfos.remove(0);
                PositionInfo info = new PositionInfo(row, col);
                positionInfos.add(info);
            }
        }
        return intstalledCol;
    }

    public void clearPositionInfosBySceneCode(String key){
        if (lineMap != null) {
            lineMap.remove(key);
        }
    }

    /**
     * 根据场景码获取被过滤的位置list
     * @param sceneCode
     * @param row
     * @return
     */
    public List<PositionInfo> getPositionInfosBySceneCode(String sceneCode, int row){
        if (lineMap == null || lineMap.isEmpty()) {
            return null;
        }
        return lineMap.get(sceneCode + row);
    }

    public void readyShowFixedRealTimeScene(String sceneCode) {

        String positionID = getEwScenePositionID(sceneCode);
        if(TextUtils.isEmpty(positionID)) {
            TRAnalysticsUtil.trackExceptionInfo(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, EXCEPTION_POSITIONID_NULL);
            return;
        }
        TFeedNative feedNative = new TFeedNative(positionID);
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(sceneCode);
        if(list == null || list.size()==0) {
            TRAnalysticsUtil.trackExceptionInfo(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, EXCEPTION_EW_CONFIG_NULL);
            return;
        }
        AttachedRealtimeAdRequest attachedRealtimeAdRequest = null;
        if(SceneCode.AR_X.equals(sceneCode)) {
            attachedRealtimeAdRequest = shouldShowARRealTimeControl(positionID, sceneCode);
        }
        feedNative.getCacheAd(NO_CACHE_COUNT,SDK_LOAD_CACHE_TIMEOUT, attachedRealtimeAdRequest);
    }

    public void readyShowFixedScene(String sceneCode,AdListener listener) {
        String positionID = getEwScenePositionID(sceneCode);
        if(TextUtils.isEmpty(positionID)) {
            listener.onError(new TaErrorCode(0,"code seat is null"));
            TRAnalysticsUtil.trackExceptionInfo(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, EXCEPTION_POSITIONID_NULL);
            return;
        }
        TFeedNative feedNative = new TFeedNative(positionID);
        feedNative.setListener(listener);
        List<HisavanaConfigInfo> list = getHisavanaConfigByKey(sceneCode);
        if(list == null || list.size()==0) {
            listener.onError(new TaErrorCode(1,"list size null"));
            TRAnalysticsUtil.trackExceptionInfo(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_PRE_EXCEPTION, EXCEPTION_EW_CONFIG_NULL);
            return;
        }
        TRAnalysticsUtil.trackEwCacheReq(positionID, sceneCode, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_STATUS, list.size(),ProcessLifecycleChecker.isAppInBackground(), false);

        AttachedRealtimeAdRequest shouldShowARRealTimeControl = null;
        if (ConfigManager.enableARRealTimeControl() && SceneCode.AR_X.equalsIgnoreCase(sceneCode)) {
            shouldShowARRealTimeControl = shouldShowARRealTimeControl(positionID, sceneCode);
        }
        feedNative.getCacheAd(list.size(),SDK_LOAD_CACHE_TIMEOUT, shouldShowARRealTimeControl);
    }

    public AttachedRealtimeAdRequest shouldShowARRealTimeControl(String positionID, String sceneCode) {
        AttachedRealtimeAdRequest  attachedRealtimeAdRequest = null;
        List<HisavanaConfigInfo> configList = HisavanaSdkManager.getInstance().getHisavanaConfigByKey(sceneCode);
        int count = 5;  // 默认请求3个实时ewAd，通过广告位配置确认.默认一屏8个
        if (configList != null && configList.size() - 8 > count) {
            count = configList.size() - 8;
        }
        LogUtils.d(LogUtils.TAG_TR_INSTALL_LIVE, "shouldShowARRealTimeControl: " + positionID + " " + sceneCode + " ");
        int[][] posArray = getPosArray(sceneCode);
        attachedRealtimeAdRequest = new AttachedRealtimeAdRequest(null, count, new RealtimeAdRequestListener() {
            @Override
            public void onAdLoaded(List<TaNativeInfo> adInfos) {
                if (adInfos != null && !adInfos.isEmpty()) {
                    TRAnalysticsUtil.trackEwRspRecordForRealtime(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_LIVE_ADS_RSP_SUCCESS, adInfos.size(), TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
                    onTrackEWSDKResponseForRealTime(adInfos, positionID, sceneCode);
                    LogUtils.d(LogUtils.TAG_TR_INSTALL_LIVE, "onAdLoaded: " + adInfos.size());
                    TRInstallCacheData.setLiveNativeInfoList(adInfos);
                    LiveEwDataStore.getInstance().setLiveNativeInfos(adInfos);
                }
            }

            @Override
            public void onError(TaErrorCode adError) {
                TRAnalysticsUtil.trackEWSdkErrorRspForRealtime(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_ADS_ERROR, adError.getErrorMessage(), adError.getErrorCode(), HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
                LogUtils.d(LogUtils.TAG_TR_INSTALL_LIVE, "onError: " + adError.getErrorCode() + " " + adError.getErrorMessage());
            }

            @Override
            public void onTimeOut() {
                TRAnalysticsUtil.trackEWSDKResponseForRealTime(positionID, SceneCode.AR_X, HisavanaSdkManager.TRACK_LOAD_ADS_TIME_OUT, "");
                LogUtils.d(LogUtils.TAG_TR_INSTALL_LIVE, "onTimeOut: ");
            }
        } );
        if (!TextUtils.isEmpty(sceneCode)) {
            attachedRealtimeAdRequest.setSceneCode(sceneCode);
        }
        if (posArray != null) {
            attachedRealtimeAdRequest.setPositionArray(posArray);
        }
        TRAnalysticsUtil.trackEWSDKLoadForRealtime(positionID, sceneCode, count, ProcessLifecycleChecker.isAppInBackground());

        return attachedRealtimeAdRequest;
    }

    /**
     * 过滤已经安装的app
     */
    public List<FeatureItemData> filterInstalledApp(List<TaNativeInfo> nativeInfoList,String sceneCode) {

        if(nativeInfoList == null || nativeInfoList.size() == 0) {
            return null;
        }
        // start filter taNativeInfo list
        Iterator<TaNativeInfo> iterator = nativeInfoList.iterator();
        List<FeatureItemData> myAppInfos = new ArrayList<>();
        int orgSize = nativeInfoList.size();
        while(iterator.hasNext()) {
            TaNativeInfo taNativeInfo = iterator.next();
            // todo 防错判断
            if (!taNativeInfo.isIconType()) {
                iterator.remove();
            } else {
                //icon类广告
                FeatureItemData appinfo = null;
                try {
                    appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                    if (appinfo != null) {
                        appinfo.tNativeInfo = taNativeInfo; //记录EW nativeID 下载和安装需要
                        //老的一键安装EW支持VA
                        if(SceneCode.AR_X.equals(sceneCode) && appinfo.extJson!=null){
                            appinfo.isVa = appinfo.extJson.isVa;
                        }
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                if(appinfo == null) {
                    TRAnalysticsUtil.trackEwFilterInstalled(sceneCode, TRAnalyticsConstant.ERROR_JSON_ERROR,taNativeInfo.getNativeAdId());
                    iterator.remove();
                    continue;
                }
                FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadingInfo(appinfo.itemID,appinfo.packageName);
                if(downloadInfo!=null) {
                    TRAnalysticsUtil.trackEwFilterInstalled(sceneCode, TRAnalyticsConstant.ERROR_MSG_ADDED,appinfo.packageName);
                    iterator.remove();
                } else if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName)) && !InstalledAppManager.isInstalledSpecialApp(appinfo.packageName)) {
                    appinfo.tNativeInfo = taNativeInfo;
                    myAppInfos.add(appinfo);
                } else {
                    if((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {
                        TRAnalysticsUtil.trackEwFilterInstalled(sceneCode,TRAnalyticsConstant.ERROR_MSG_INSTALLED,appinfo.packageName);
                    }
                    iterator.remove();
                }
            }
        }
        //todo 统计过滤前和过滤后的数量
        TRAnalysticsUtil.trackEwBackAndFilterCount(sceneCode,orgSize,myAppInfos.size(), null);
        return myAppInfos;
    }

    /**
     * 过滤已经安装的app
     */
    public List<FeatureItemData> filterInstalledApp(List<TaNativeInfo> nativeInfoList,String sceneCode, String uniqueId) {

        if(nativeInfoList == null || nativeInfoList.size() == 0) {
            return null;
        }
        // start filter taNativeInfo list
        Iterator<TaNativeInfo> iterator = nativeInfoList.iterator();
        List<FeatureItemData> myAppInfos = new ArrayList<>();
        int orgSize = nativeInfoList.size();
        while(iterator.hasNext()) {
            TaNativeInfo taNativeInfo = iterator.next();
            // todo 防错判断
            if (!taNativeInfo.isIconType()) {
                iterator.remove();
            } else {
                //icon类广告
                FeatureItemData appinfo = null;
                try {
                    appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                    if (appinfo != null) {
                        appinfo.tNativeInfo = taNativeInfo; //记录EW nativeID 下载和安装需要
                        //老的一键安装EW支持VA
                        if(SceneCode.AR_X.equals(sceneCode) && appinfo.extJson!=null){
                            appinfo.isVa = appinfo.extJson.isVa;
                        }
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                if(appinfo == null) {
                    TRAnalysticsUtil.trackEwFilterInstalledForRealTime(sceneCode, TRAnalyticsConstant.ERROR_JSON_ERROR,taNativeInfo.getNativeAdId(), taNativeInfo.isAttachedRealtimeRequestAd(), uniqueId);
                    iterator.remove();
                    continue;
                }
                FileDownloadInfo downloadInfo = DownloadManager.getInstance().getDownloadingInfo(appinfo.itemID,appinfo.packageName);
                if(downloadInfo!=null) {
                    TRAnalysticsUtil.trackEwFilterInstalledForRealTime(sceneCode, TRAnalyticsConstant.ERROR_MSG_ADDED,appinfo.packageName, taNativeInfo.isAttachedRealtimeRequestAd(),  uniqueId);
                    iterator.remove();
                } else if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName)) && !InstalledAppManager.isInstalledSpecialApp(appinfo.packageName)) {
                    appinfo.tNativeInfo = taNativeInfo;
                    myAppInfos.add(appinfo);
                } else {
                    if((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {
                        TRAnalysticsUtil.trackEwFilterInstalledForRealTime(sceneCode,TRAnalyticsConstant.ERROR_MSG_INSTALLED,appinfo.packageName, taNativeInfo.isAttachedRealtimeRequestAd(), uniqueId);
                    }
                    iterator.remove();
                }
            }
        }
        //todo 统计过滤前和过滤后的数量
        TRAnalysticsUtil.trackEwBackAndFilterCount(sceneCode,orgSize,myAppInfos.size(),uniqueId);
        return myAppInfos;
    }

    /**
     * 根据StartUp流控填充APP展示序号
     */
    public void fillAppIndexInfo(List<FeatureItemData> featureItemDataList,String sceneCode) {
        if(featureItemDataList == null || featureItemDataList.size() == 0) {
            return;
        }
        List<HisavanaConfigInfo> configList = HisavanaSdkManager.getInstance().getHisavanaConfigByKey(sceneCode);
        int index = 0;
        int featureSize = featureItemDataList.size();
        int configSize = 12; // default size
        if(configList!=null && configList.size()>0) {
            configSize = configList.size();
            Iterator<HisavanaConfigInfo> iterator = configList.iterator();
            while(iterator.hasNext()) {
                HisavanaConfigInfo configInfo = iterator.next();
                if(configInfo!=null) {
                    String col = configInfo.getCol();
                    try {
                        if(!TextUtils.isEmpty(col) && !TextUtils.equals("X",col)) {
                            int intCol = Integer.parseInt(col);
                            if(index<featureSize) {
                                FeatureItemData itemData = featureItemDataList.get(index);
                                itemData.tNativeInfo.setTopicColumn(intCol);
                                itemData.tNativeInfo.setTopicRow(0);
                            } else {
                                if(!TextUtils.equals(SceneCode.NR_X,sceneCode)) {
                                    HisavanaSdkManager.getInstance().saveInstalledPosition(sceneCode,0,intCol);
                                }
                            }
                        }
                    }catch (Exception e) {

                    }
                    index++;
                }
            }
        }
        int diff = featureSize - configSize;
        //todo  切除多余部分
        if(diff>0) {
            for(int i=1;i<=diff;i++) {
                if((featureSize-i>=0)) {
                    try {
                        featureItemDataList.remove(featureSize-i);
                    }catch (Exception e) {

                    }
                }
            }
        }
    }

    public void updateOrgPositionFillInfo(String sceneCode) {
        List<HisavanaConfigInfo> configList = HisavanaSdkManager.getInstance().getHisavanaConfigByKey(sceneCode);
        int index = 0;
        int configSize = 12; // default size
        if(configList!=null && configList.size()>0) {
            Iterator<HisavanaConfigInfo> iterator = configList.iterator();
            while(iterator.hasNext()) {
                HisavanaConfigInfo configInfo = iterator.next();
                if(configInfo!=null) {
                    String col = configInfo.getCol();
                    try {
                        if(!TextUtils.isEmpty(col) && !TextUtils.equals("X",col)) {
                            int intCol = Integer.parseInt(col);
                            if (!TextUtils.equals(SceneCode.NR_X, sceneCode)) {
                                HisavanaSdkManager.getInstance().saveInstalledPosition(sceneCode, 0, intCol);
                            }
                        }
                    }catch (Exception e) {

                    }
                    index++;
                }
            }
        }
    }
}

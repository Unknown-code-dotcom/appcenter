package com.afmobi.palmplay.activate;

import android.app.Activity;
import android.app.Dialog;

import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.pet.manager.XMPetManager;
import com.afmobi.util.GuideStatus;
import com.transsion.palmstorecore.api.pet.IPetHomeGuideDialogCallback;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsnet.store.BuildConfig;

public class TRPetGuideDialogExecutor extends TRBaseExecutor {

    Dialog mPetHomeGuideDialog = null;

    @Override
    public boolean isCanShow(String fromType) {
        // 仅在online(非入库) Home tab 可见且引导未展示过时允许弹出
        boolean result = GuideStatus.INSTANCE.getHomeState().getValue() == 1
                && !GuideStatus.INSTANCE.hasShowPetGuide()
                && !TRApplicationContextUtil.isProject();
        return result;
    }

    @Override
    public boolean show(String fromType, Activity activity) {
        try {
            mPetHomeGuideDialog = XMPetManager.createHomeGuide(activity, new IPetHomeGuideDialogCallback() {
                @Override
                public void onDialogClosed() {
                    TRNewManager.getCloseListener().onDialogClosed();
                }
            }) ;
            if (mPetHomeGuideDialog != null) {
                mPetHomeGuideDialog.show();
            }
            return true;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public boolean isShowing() {
        return mPetHomeGuideDialog != null && mPetHomeGuideDialog.isShowing();
    }

    @Override
    public boolean dismiss() {
        if(mPetHomeGuideDialog != null) {
            try {
                mPetHomeGuideDialog.dismiss();
                return true;
            }catch (Exception e) {
                if (BuildConfig.DEBUG) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }
}

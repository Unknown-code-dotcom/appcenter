package com.afmobi.palmplay.cloudfolder.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

/**
 * 处理横向滑动RecyclerView 在ViewPager中的滑动冲突问题
 */
public class CloudFolderBottomRecyclerView extends RecyclerView {

    private float startX, startY;

    public CloudFolderBottomRecyclerView(Context context) {
        super(context);
        init();
    }

    public CloudFolderBottomRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CloudFolderBottomRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = e.getX();
                startY = e.getY();
                getParent().requestDisallowInterceptTouchEvent(true);
                break;

            case MotionEvent.ACTION_MOVE:
                float scrollDirection = startX - e.getX();
                float dx = Math.abs(scrollDirection);
                float dy = Math.abs(e.getY() - startY);

                // 判断是水平滚动还是垂直滚动
                boolean isHorizontalScroll =  dx > dy;

                boolean isCanScroll = canScrollHorizontally((int) scrollDirection);

                // 如果检测到水平滚动，请求父View不拦截事件
                getParent().requestDisallowInterceptTouchEvent(isHorizontalScroll && isCanScroll);
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                getParent().requestDisallowInterceptTouchEvent(false);
                break;
        }
        return super.onInterceptTouchEvent(e);
    }

}
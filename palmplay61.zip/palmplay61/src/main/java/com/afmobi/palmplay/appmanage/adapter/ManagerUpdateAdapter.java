// TOP SECRET
package com.afmobi.palmplay.appmanage.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RotateDrawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter;
import com.afmobi.palmplay.alonefuction.UnknownSourceDialogActivity;
import com.afmobi.palmplay.appmanage.ManageUpdateActivity;
import com.afmobi.palmplay.appmanage.holder.UpdateFoldRecyclerViewHolder;
import com.afmobi.palmplay.appmanage.holder.UpdateRecyclerViewHolder;
import com.afmobi.palmplay.cache.InstalledAppsUpdateCache;
import com.afmobi.palmplay.clean.DiskSpaceNotEnoughTipsActivity;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.download.InterfaceBatchStatusChange;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.manager.PalmPlayNetworkDownloadStateManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.ClientVersion.UpdateItem;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.service.PalmstoreService;
import com.afmobi.palmplay.setting.IndividualCenterUpdateManageUtils;
import com.afmobi.palmplay.setting.WifiOnlyTipsActivity;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.va.dialog.VaDialogs;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkState;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.TRJumpUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import org.json.JSONObject;

import de.greenrobot.event.EventBus;

public class ManagerUpdateAdapter extends PalmBaseDownloadRecyclerViewAdapter{
	private static final int FOLD_ITEM = 1;
	public static final int ALL_SORT = 0;
	public static final int SYSTEM_SORT = 1;
	public static final int OTHER_SORT = 2;

	public static final int FOLD_COUNT = 4;

	private final LinearLayoutManager mLinearLayoutManager;
	protected Activity mActivity;
	private String TAG = ManagerUpdateAdapter.class.getSimpleName();
	private RecyclerView mRecyclerView;
	private volatile List<UpdateItem> listUpdateItem = new ArrayList<UpdateItem>(); // 保存当前展示的数据

	private volatile List<UpdateItem> listUpdateData = new ArrayList<UpdateItem>(); // 保存所有数据
	private volatile List<UpdateItem> listFilteredData = new ArrayList<UpdateItem>(); // 保存当前筛选后的所有数据（缓存）
	private boolean needFold = false; // 是否需要显示折叠按钮（筛选后数据>=4时为true）
	private boolean isFolded = true; // 当前是否处于折叠状态（true=折叠，false=展开）
	private int currentAppSort = ALL_SORT; // 当前分类，默认ALL-0， System - 1, Other - 2

	// 折叠按钮曝光标志 - 防止重复曝光
	private boolean hasFoldButtonTrackedExposure = false;

	private IMessenger mIMessenger;

    private PageParamInfo mPageParamInfo = new PageParamInfo().setCurPage(PageConstants.Update);

	public ManagerUpdateAdapter(Activity mActivity, RecyclerView recyclerView, List<UpdateItem> mUpdateItemList, PageParamInfo pageParamInfo){
		this.mActivity = mActivity;
		this.mRecyclerView = recyclerView;

		List<UpdateItem> initialList = new ArrayList<>();
		if (mUpdateItemList != null && mUpdateItemList.size() > 0)
			initialList.addAll(mUpdateItemList);
		this.listUpdateItem = initialList;

		mPageParamInfo = pageParamInfo;

		mLinearLayoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false);
		mLinearLayoutManager.setSmoothScrollbarEnabled(true);
		mLinearLayoutManager.setAutoMeasureEnabled(true);
		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);

		recyclerView.setLayoutManager(mLinearLayoutManager);
		recyclerView.setAdapter(this);

        RecyclerView.ItemAnimator itemAnimator = recyclerView.getItemAnimator();
        if(itemAnimator instanceof SimpleItemAnimator){
            ((SimpleItemAnimator)itemAnimator).setSupportsChangeAnimations(false);
        }
	}

	public void setIMessenger(IMessenger mIMessenger){
		this.mIMessenger = mIMessenger;
	}

	/**
	 * 获取当前显示的数据（用于UI显示，可能被折叠）
	 */
	public List<UpdateItem> getDisplayData() {
		return listUpdateItem;
	}

	/**
	 * 获取当前筛选后的所有数据（用于业务逻辑，如全部更新/暂停）
	 * 返回根据currentAppSort筛选后的完整列表，不受折叠状态影响
	 */
	public List<UpdateItem> getData() {
		return listFilteredData;
	}


	public void setData(List<UpdateItem> mUpdateItemList) {
		List<UpdateItem> newUpdateData = new ArrayList<>();
		List<UpdateItem> newFilteredData = new ArrayList<>();
		List<UpdateItem> newUpdateItem = new ArrayList<>();

		if (mUpdateItemList != null && mUpdateItemList.size() > 0)
			newUpdateData.addAll(mUpdateItemList);

		// 1、根据 currentAppSort 筛选对应类型数据并缓存到 listFilteredData
		if (mUpdateItemList != null && mUpdateItemList.size() > 0) {
			for (UpdateItem item : mUpdateItemList) {
				if (currentAppSort == ALL_SORT) {
					// 显示所有
					newFilteredData.add(item);
				} else if (currentAppSort == SYSTEM_SORT) {
					// 只显示系统应用
					if (item.isSystemApp()) {
						newFilteredData.add(item);
					}
				} else if (currentAppSort == OTHER_SORT) {
					// 只显示非系统应用
					if (!item.isSystemApp()) {
						newFilteredData.add(item);
					}
				}
			}
		}

		// 2、判断是否需要显示折叠按钮（筛选后数据>4个）
		needFold = newFilteredData.size() > FOLD_COUNT;

		// 3、根据折叠状态决定显示的数据
		if (needFold && isFolded) {
			// 需要折叠且当前是折叠状态，只显示前4个
			for (int i = 0; i < 4; i++) {
				newUpdateItem.add(newFilteredData.get(i));
			}
		} else {
			// 不需要折叠或当前是展开状态，显示全部
			newUpdateItem.addAll(newFilteredData);
		}

		// 原子性赋值
		this.listUpdateData = newUpdateData;
		this.listFilteredData = newFilteredData;
		this.listUpdateItem = newUpdateItem;

		notifyDataSetChanged();
	}


	public void setCurrentAppSort(int currentAppSort) {
		this.currentAppSort = currentAppSort;
		setData(listUpdateData);
	}

	public int getCurrentAppSort() {
		return currentAppSort;
	}

	// 获取和设置折叠按钮曝光标志
	public boolean hasFoldButtonTrackedExposure() {
		return hasFoldButtonTrackedExposure;
	}

	public void setFoldButtonTrackedExposure(boolean tracked) {
		this.hasFoldButtonTrackedExposure = tracked;
	}

	// 获取和设置折叠状态
	public boolean isFolded() {
		return isFolded;
	}

	public void setFolded(boolean folded) {
		this.isFolded = folded;
	}

	public void toggleFold() {
		isFolded = !isFolded;
		setData(listUpdateData);

		// 点击埋点
		String value = TRStringUtil.generateString(mScreenPageName, TRAnalyticsConstant.UPDATE_FOLD_BTN, "", "");
		ComponentClickBuilder builder = new ComponentClickBuilder();
		builder.setValue(value)
				.setFrom(mFrom)
				.setButtonType(isFolded ? "Fold" : "Unfold");
		TRAnalysticsUtil.trackClick(builder);
	}

	@Override
	public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		if (viewType == FOLD_ITEM) {
			View foldView = LayoutInflater.from(mActivity).inflate(R.layout.layout_update_fold_item, parent, false);
			return new UpdateFoldRecyclerViewHolder(foldView);
		}
		View convertView = LayoutInflater.from(mActivity).inflate(R.layout.layout_manage_update_list_item, parent, false);
		return new UpdateRecyclerViewHolder(convertView);
	}

	@Override
	public void onBindViewHolder(RecyclerView.ViewHolder hld, int position) {
		if (hld instanceof UpdateFoldRecyclerViewHolder) {
			UpdateFoldRecyclerViewHolder foldHolder = (UpdateFoldRecyclerViewHolder) hld;
			// 设置展开/收起按钮文案和箭头方向
			if (isFolded) {
				// 折叠状态 - 箭头向下
				foldHolder.tvFoldText.setText(mActivity.getString(R.string.txt_instant_ebooks_view_all));
				setArrowDrawable(foldHolder.tvFoldText, 0); // 不旋转
			} else {
				// 展开状态 - 箭头向上(旋转180度)
				foldHolder.tvFoldText.setText(mActivity.getString(R.string.download_collapse_list));
				setArrowDrawable(foldHolder.tvFoldText, 180); // 旋转180度
			}
			// 设置点击事件
			foldHolder.layoutFold.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					toggleFold();
				}
			});

			// 折叠按钮曝光埋点（防止重复曝光）
			if (!hasFoldButtonTrackedExposure) {
				hasFoldButtonTrackedExposure = true;
				String value = TRStringUtil.generateString(mScreenPageName, TRAnalyticsConstant.UPDATE_FOLD_BTN, "", "");
				ComponentExposureBuilder builder = new ComponentExposureBuilder();
				builder.setValue(value)
						.setFrom(mFrom);
				TRAnalysticsUtil.trackExposure(builder);
			}
			return;
		}

		UpdateItem mUpdateItem = null;
		if(position >= 0 && position < listUpdateItem.size()){
			mUpdateItem = listUpdateItem.get(position);
		}
		if(mUpdateItem == null){
			return;
		}
		UpdateRecyclerViewHolder updateRecyclerViewHolder = (UpdateRecyclerViewHolder) hld;
		AdapterOnClickListener itemAndViewOnClinck = new AdapterOnClickListener(updateRecyclerViewHolder, mUpdateItem, position);
		updateRecyclerViewHolder.setActivity(mActivity).bind(mUpdateItem, position, itemAndViewOnClinck);
		if(!mUpdateItem.hasTrack) {
			mUpdateItem.hasTrack = true;
			if(TextUtils.isEmpty(mUpdateItem.nativeId)) {
				mUpdateItem.nativeId = CommonUtils.generateSerialNum();
			}
			String value = TRStringUtil.generateString(mScreenPageName, "","", ""+position);
			ComponentExposureBuilder builder = new ComponentExposureBuilder();
			builder.setValue(value)
					.setFrom(mFrom)
					.setTopicType("")
					.setTopicId(mUpdateItem.topicID)
					.setItemType(mUpdateItem.detailType)
					.setItemId(mUpdateItem.itemID)
					.setNativeId(mUpdateItem.nativeId)
					.setItemValue(mUpdateItem.packageName)
					.setTaskId(0)
					.setIsVa(mUpdateItem.isVa)
					.setExtras(getItemPVExtraValue());
			TRAnalysticsUtil.trackExposure(builder);
		}
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public int getItemCount() {
		// 如果需要显示折叠按钮，则item数量 + 1（折叠按钮）
		if (needFold) {
			return listUpdateItem.size() + 1;
		}
		return listUpdateItem == null ? 0 : listUpdateItem.size();
	}

	/**
	 * 获取实际的应用数量（不包含折叠按钮）
	 */
	public int getRealItemCount() {
		return listUpdateItem == null ? 0 : listUpdateItem.size();
	}

	@Override
	public int getItemViewType(int position) {
		int listItemSize = listUpdateItem == null ? 0 : listUpdateItem.size();
		if (position >= listItemSize) {
			return FOLD_ITEM;
		}
		return super.getItemViewType(position);
	}

	public class AdapterOnClickListener implements OnClickListener{

		private UpdateRecyclerViewHolder holder;
		private UpdateItem info;
		private int mPosition;

		public AdapterOnClickListener(UpdateRecyclerViewHolder holder, UpdateItem info, final int position){
			this.holder = holder;
			this.info = info;
			this.mPosition = position;
		}

		@Override
		public void onClick(View v) {
			if(holder==null)
				return;
			int viewId = v.getId();
			if(viewId == holder.ib_more.getId()){

				if(holder.layout_ignore.getVisibility() == View.VISIBLE){
					holder.layout_ignore.setVisibility(View.GONE);
					//holder.ib_more.setImageResource(R.drawable.btn_download_more_up_n);
				}else {
					holder.layout_ignore.setVisibility(View.VISIBLE);
					//holder.ib_more.setImageResource(R.drawable.btn_download_more_down_n);
				}

				info.isExpandInAdapter = holder.layout_ignore.getVisibility()==View.VISIBLE;

				holder.checkIbMoreImageResource(holder.layout_ignore, holder.ib_more);

			} else if(viewId == holder.tv_uninstall.getId()){

				if(info==null) return;
				if(info.isVa) {
					deleteVaGame(info);
				} else {
					DownloadDecorator.uninstallApp(info.packageName);
				}
//				if(mPosition>=0 && mPosition < listUpdateItem.size())
//					listUpdateItem.remove(mPosition);
				notifyDataSetChanged();

			} else if(viewId == holder.tv_ignore.getId()){

				saveIgnoerList(info, mPosition);

//				if(SPManager.getBoolean(Constant.preferences_ignoer_tips_is_select, false)){
//					saveIgnoerList(info, mPosition);
//				}else {
//					final DialogBuilder mDialogBuilder = new DialogBuilder();
//					new CustomDialog(mActivity).showCheckBoxFunctionDialog(
//							mDialogBuilder
//							.hideTitle()
//							.setMessage(mActivity.getString(R.string.ignore_update))
//							.setCheckBoxChecked(false)
//							.setCheckBoxText(mActivity.getString(R.string.no_again))
//							.setNegativeBtnText(mActivity.getString(R.string.text_cancel))
//							.setPositiveBtnText(mActivity.getString(R.string.text_ok))
//							.setPositiveBtnOnClickListener(new OnClickListener() {
//
//								@Override
//								public void onClick(View v) {
//									saveIgnoerList(info, mPosition);
//									SPManager.putBoolean(Constant.preferences_ignoer_tips_is_select, mDialogBuilder.isCheckBoxChecked());
//								}
//							}));
//				}

			} else if(viewId == holder.btn_operation.getId()){

				if(info.observerStatus == FileDownloadInfo.STATUS_NONE){
					listUpdateItem.remove(info);
					if(mIMessenger!=null)
						mIMessenger.onMessenger();
					notifyDataSetChanged();
					return;
				}

				if (info.observerStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
					// 文件下载完成，正在进行校验，此时不处理点击事件，页面显示进度100%
					if (BuildConfig.DEBUG) {
						Log.e("checkDownloadInfo", "文件下载完成，校验中...", new Throwable("who call me"));
					}
					return;
				}
				String value = TRStringUtil.generateString(mScreenPageName, "","", info.placementId);
				String buttonType = "";
				if(holder.btn_operation.getText().equals(mActivity.getString(R.string.text_pause))){
					//info.observerStatus = FileDownloadInfo.STATUS_PAUSE;
					DownloadManager.getInstance().pauseDownload(info.packageName);

					buttonType = TRAnalyticsConstant.PAUSE;
				} else if(holder.btn_operation.getText().equals(mActivity.getString(R.string.text_continue))){ArrayList<String> list = new ArrayList<>();
					list.add(info.packageName);
					DownloadUtil.resumeDownload(mActivity, list, true, true, null);
					buttonType = TRAnalyticsConstant.CONTINUE;
				} else if(holder.btn_operation.getText().equals(mActivity.getString(R.string.text_retry))){
					ArrayList<String> list = new ArrayList<>();
					list.add(info.packageName);
					DownloadUtil.resumeDownload(mActivity, list, true, true, null);
					buttonType = TRAnalyticsConstant.CONTINUE;

				} else if(holder.btn_operation.getText().equals(mActivity.getString(R.string.text_install))){
					//DownloadDecorator.installAppDownloaded(DownloadManager.getInstance().getDownloadedInfo(info.packageName));
					DownloadDecorator.installAppDownloadedWhenDeletedTips(mActivity, DownloadManager.getInstance().getDownloadedInfo(info.packageName), mPageParamInfo, true);
					buttonType = TRAnalyticsConstant.INSTALL;
				} else if(holder.btn_operation.getText().equals(mActivity.getString(R.string.text_open))){
					if(info.isVa) {
						PsVaManager.getInstance().openVaLoadingActivity(info, mFrom);
					} else {
						DownloadDecorator.launchApp(info.packageName, info.name);
					}
					buttonType = TRAnalyticsConstant.OPEN;

				} else if(holder.btn_operation.getText().equals(mActivity.getString(R.string.text_update))){
					if(NetworkUtils.isNetworkAvailable(mActivity)){

						if (!TextUtils.equals(NetworkUtils.getNetworkState(mActivity), NetworkState.WIFI) && PalmPlayNetworkDownloadStateManager.isDataChargesLimit()) {
							UpdateItem mUpdateItem = getDisplayData().get(mPosition);
							String iValue = TRStringUtil.generateString(mScreenPageName, "","", "");
							WifiOnlyTipsActivity.wifiDownloadOnlyUpdateSingle(mActivity, 1001, mUpdateItem.packageName, mUpdateItem.itemID, true, iValue);

						} else {
							updateSingle(mPosition, false);
						}
					}else {
						ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
					}
					buttonType = TRAnalyticsConstant.UPDATE;
				}

				ComponentClickBuilder builder = new ComponentClickBuilder();
				builder.setValue(value)
						.setFrom(mFrom)
						.setTopicType("")
						.setTopicId("")
						.setItemType(info.detailType)
						.setItemId(info.itemID)
						.setButtonType(buttonType)
						.setNativeId(info.nativeId)
						.setReportSource(info.reportSource)
						.setItemValue(info.packageName)
						.setExtraValue("")
						.setFromPage(Constant.NEW_FROMPAGE_UPDATE)
						.setIsVa(info.isVa)
						.setExtras(getItemPVExtraValue());
				if (TRAnalyticsConstant.OPEN.equals(buttonType)) {
					builder.setExtraValue(DeeplinkManager.getDeeplink(info.packageName));
				}
				TRAnalysticsUtil.trackClick(builder);

			}else if(viewId == holder.rootView.getId()){
				String value = TRStringUtil.generateString(mScreenPageName, "","", info.placementId);
				AppBuilder appBuilder = new AppBuilder()
						.setFromPage(Constant.NEW_FROMPAGE_UPDATE)
						.setLastPage(PageConstants.Update)
						.setValue(value)
						.setParamsByData(TRJumpUtil.convetToRankDataItem(info), "");
				TRJumpUtil.switcToAppDetailOptions(mActivity, appBuilder);

				ComponentClickBuilder builder = new ComponentClickBuilder();
				builder.setValue(value)
						.setFrom(mFrom)
						.setTopicType("")
						.setTopicId("")
						.setItemType(info.detailType)
						.setItemId(info.itemID)
						.setButtonType(TRAnalyticsConstant.ICON)
						.setReportSource(info.reportSource)
						.setNativeId(info.nativeId)
						.setItemValue(info.packageName)
						.setExtraValue("")
						.setExtras(getItemPVExtraValue())
						.setIsVa(info.isVa);
				TRAnalysticsUtil.trackClick(builder);
			}
		}

	}

	private void deleteVaGame(UpdateItem info) {
		if (info != null) {
			String from = TRStringUtil.generateString(mScreenPageName, "","", info.placementId);
			LiveData<Integer> click = VaDialogs.createUninstallDialog(mActivity, info.name, info.itemID, TRAnalyticsConstant.TRACK_ITEM_TYPE_SOFT, info.packageName, from, true)
					.display()
					.click();
			click.observeForever(new Observer<Integer>() {
				@Override
				public void onChanged(Integer integer) {
					click.removeObserver(this);
					if (integer == DialogInterface.BUTTON_POSITIVE) {
						boolean result = PsVaManager.getInstance().deleteVaGame(info.packageName, false);
						if (result) {
							InstalledAppsUpdateCache.getInstance().removeVaGame(info.packageName);
							String text = PalmplayApplication.getAppInstance().getResources().getString(R.string.text_uninstalled) + " " + info.name;
							ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), text);
						}
					}
				}
			});
		}
	}

	private void saveIgnoerList(UpdateItem info, int position){
		InstalledAppsUpdateCache.getInstance().addIgnoreUpdateItem(info);
		listUpdateItem.remove(info);
		if (listFilteredData != null) {
			listFilteredData.remove(info);
		}
		if (listUpdateData != null) {
			listUpdateData.remove(info);
		}
		String name = PalmplayApplication.getAppInstance().getString(R.string.txt_update_ignored_tip);//CommonUtils.replace(mActivity.getString(R.string.ignored_tips), CommonUtils.TARGET_NAME, TextUtils.isEmpty(info.name)?"":info.name);
		ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), name);

		DownloadManager.getInstance().cancelDownload(info.packageName);

		notifyDataSetChanged();

		if (mIMessenger != null)
			mIMessenger.onMessenger();

		//sk add for update notification update count number begin
		if (mActivity == null) {
			return;
		}
		EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
		eventMainThreadEntity.setAction(PalmstoreService.ACTION_NOTIFICATION_UPDATE_COUNT);
		EventBus.getDefault().post(eventMainThreadEntity);

		//sk add for update notification update count number end

		String value = TRStringUtil.generateString(mScreenPageName, "","", info.placementId);
		ComponentClickBuilder builder = new ComponentClickBuilder();
		builder.setValue(value)
				.setFrom(mFrom)
				.setTopicType("")
				.setTopicId("")
				.setItemType(info.detailType)
				.setItemId(info.itemID)
				.setButtonType(TRAnalyticsConstant.BUTTON_Ignore)
				.setReportSource(info.reportSource)
				.setNativeId(info.nativeId)
				.setItemValue(info.packageName)
				.setExtraValue("");
		TRAnalysticsUtil.trackClick(builder);
	}

	private void updateSingle(int position, boolean waitingWiFi) {
		if (position >= 0 && position < getRealItemCount()) {
			//判断是否开启 安装未知来源应用
			if(!SysUtils.isAllowedUnknownSource(mActivity)){
				Intent unknownSourceIntent = new Intent(mActivity, UnknownSourceDialogActivity.class);
				PageConstants.putPageParamInfo(unknownSourceIntent,  mPageParamInfo);
					/*Gson gson = new Gson();
					String infoBuffer = gson.toJson(loadingInfo, FileDownloadInfo.class);
					intent.putExtra(Constant.KEY_URL, infoBuffer);*/
				mActivity.startActivity(unknownSourceIntent);
			}else {
				if (!FileUtils.hasEnoughDiskSpace(mActivity, getDisplayData().get(position).size)) {
					//if(!FileUtils.hasEnoughDiskSpace(mActivity, 10737418240L)){
					Intent intent = new Intent(mActivity, DiskSpaceNotEnoughTipsActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra(PageParamInfo.class.getSimpleName(), mPageParamInfo);
					mActivity.startActivity(intent);
				}else {
					UpdateItem mUpdateItem = getDisplayData().get(position);
					if(isNeedJumpToGpUpdate(mUpdateItem)) { //sk add for filter jump to gp update
						//TODO:jump to GP
						DownloadDecorator.checkJumpToGooglePlay(mActivity, mUpdateItem.outerUrl, mUpdateItem.packageName, mPageParamInfo, mUpdateItem.itemID, mUpdateItem.version, mUpdateItem.verifyGoogle);
						return;
					}
					String placementId = (mUpdateItem != null) ? (mUpdateItem.placementId) : "";
					String value = TRStringUtil.generateString(mScreenPageName, "","", placementId);
					DownloadManager.updateNewVersion(mUpdateItem, new PageParamInfo(mFrom, value), waitingWiFi);
					DownloadStatusManager.getInstance().registerInfoInstance(mUpdateItem);
				}
			}
		}

		notifyDataSetChanged();

		if (mIMessenger != null)
			mIMessenger.onMessenger();
	}

	public void updateSingle(String str, boolean isApp, boolean isWaitingWiFi){
		if(TextUtils.isEmpty(str))
			return;
		if(listUpdateItem==null)
			return;
		if(isApp){
			//判断是否开启 安装未知来源应用
			if(!SysUtils.isAllowedUnknownSource(mActivity)){
				Intent unknownSourceIntent = new Intent(mActivity, UnknownSourceDialogActivity.class);
				PageConstants.putPageParamInfo(unknownSourceIntent,  mPageParamInfo);
						/*Gson gson = new Gson();
						String infoBuffer = gson.toJson(loadingInfo, FileDownloadInfo.class);
						intent.putExtra(Constant.KEY_URL, infoBuffer);*/
				mActivity.startActivity(unknownSourceIntent);
			}else {
				for (UpdateItem mUpdateItem : listUpdateItem) {
					if (mUpdateItem != null && str.equals(mUpdateItem.packageName)) {
						String value = TRStringUtil.generateString(mScreenPageName, "","", mUpdateItem.placementId);
						DownloadManager.updateNewVersion(mUpdateItem, new PageParamInfo(mFrom, value), isWaitingWiFi);
						DownloadStatusManager.getInstance().registerInfoInstance(mUpdateItem);
						break;
					}
				}
			}
		} else {
			for(UpdateItem mUpdateItem : listUpdateItem){
				if(mUpdateItem!=null && str.equals(mUpdateItem.itemID)){
					String value = TRStringUtil.generateString(mScreenPageName, "","", mUpdateItem.placementId);
					DownloadManager.updateNewVersion(mUpdateItem, new PageParamInfo(mFrom, value), isWaitingWiFi);
					DownloadStatusManager.getInstance().registerInfoInstance(mUpdateItem);
					break;
				}
			}
		}

		notifyDataSetChanged();

		if (mIMessenger != null)
			mIMessenger.onMessenger();

	}

	public boolean isPauseAll(int downloadingCount, int downloadedCount, int updateCount, int pauseCount) {
		int filteredTotalCount = getData().size();
		return (downloadingCount == filteredTotalCount
				|| (downloadingCount > 0
				&& (downloadingCount == filteredTotalCount - downloadedCount && updateCount == 0
				&& pauseCount == 0)));
	}

	public void updateAll(int requestCode, boolean isNeedJumpToWifiOnly, boolean onlyHandleUpdate) {

		boolean isNeedNotify = true;

		if (getRealItemCount() > 0) {
			int pauseCount = 0;
			int updateCount = 0;
            boolean canInstall = true;
			List<UpdateItem> listDownloadingUpdateItem = new ArrayList<UpdateItem>();
			List<UpdateItem> listDownloadedUpdateItem = new ArrayList<UpdateItem>();
			
			for(UpdateItem mUpdateItem : getData()){
				if(mUpdateItem!=null){
					if(FileDownloadInfo.isDownloading(mUpdateItem.observerStatus)){
						listDownloadingUpdateItem.add(mUpdateItem);
						
					} else if(mUpdateItem.observerStatus == FileDownloadInfo.STATUS_PAUSE){
						pauseCount ++;
						
					}else if(mUpdateItem.observerStatus  == FileDownloadInfo.STATUS_APP_UPDATE){
						updateCount++;
						
					} else if(mUpdateItem.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED){
						listDownloadedUpdateItem.add(mUpdateItem);
					}
				}
			}
			
			//if(listDownloadingUpdateItem.size() == (getItemCount() - downloadedCount)){ // pause all
			if(!onlyHandleUpdate && isPauseAll(listDownloadingUpdateItem.size(), listDownloadedUpdateItem.size(), updateCount, pauseCount)){

				List<FileDownloadInfo> pauseList = new ArrayList<>();
				for (UpdateItem mUpdateItem : listDownloadingUpdateItem) {
					FileDownloadInfo info = DownloadManager.getInstance().getDownloadingInfobyPackageName(mUpdateItem.packageName);
					if (info != null) {
						pauseList.add(info);
					}
				}

				List<FileDownloadInfo> dstList = DownloadManager.getInstance().onDownloadingBatchPause(pauseList);
				CommonUtils.onHandleWiFiRetrieve(dstList, false);
				
			} else/* if(listDownloadingUpdateItem.size() >= 0)*/{ // update all

				for (UpdateItem mUpdateItem : listDownloadedUpdateItem) {
					// TODO 需要注意是否会弹多个窗口
                    canInstall = false;
					PageParamInfo pageParamInfo = new PageParamInfo().copyValue(mPageParamInfo).setCurPage(PageConstants.Update_Button);
					DownloadDecorator.installAppDownloadedWhenDeletedTips(mActivity, DownloadManager.getInstance().getDownloadedInfobyPackageName(mUpdateItem.packageName), pageParamInfo, false);
				}

				if(updateCount > 0 || pauseCount > 0){
					
					if(NetworkUtils.isNetworkAvailable(mActivity)){

						if (!TextUtils.equals(NetworkUtils.getNetworkState(mActivity), NetworkState.WIFI) && PalmPlayNetworkDownloadStateManager.isDataChargesLimit()) {
							
							if(isNeedJumpToWifiOnly) {
								String value = TRStringUtil.generateString(mScreenPageName, "","", "");
								WifiOnlyTipsActivity.wifiDownloadOnlyUpdateAll(mActivity, requestCode, value);
							}
							
							isNeedNotify = false;
							
						}else{
							updateAll(canInstall, false);
							isNeedNotify = false;
						}
						
					} else {
						ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
						isNeedNotify = false;
					}
				}
				
				
			} 
			
		}
		
		if(isNeedNotify){
			
			DownloadStatusManager.getInstance().registerInfoInstance(this.listUpdateItem);
			
			notifyDataSetChanged();
			
			if(mIMessenger!=null)
				mIMessenger.onMessenger();
		}
	}
	
	public void updateAll(boolean canInstall, boolean waitingWiFi){
		/*for (UpdateItem mUpdateItem : getData()) {
			if(mUpdateItem==null) 
				continue;
			if(mUpdateItem.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE){
				CommonUtils.updateNewVersion(mUpdateItem);
				
			} else if(mUpdateItem.observerStatus == FileDownloadInfo.STATUS_PAUSE){
				DownloadManager.getInstance().resumeDownload(mUpdateItem.itemID);
				
			} else if(mUpdateItem.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED){
				// TODO 需要注意是否会弹多个窗口
				DownloadDecorator.installAppDownloadedWhenDeletedTips(mActivity, DownloadManager.getInstance().getDownloadedInfobyPackageName(mUpdateItem.packageName));
			}
		}
		
		DownloadStatusManager.getInstance().registerInfoInstance(this.listUpdateItem);*/
		if (mActivity == null || mActivity.isFinishing() || mActivity.isDestroyed()) {
			return;
		}

		//判断是否开启 安装未知来源应用
		if(!SysUtils.isAllowedUnknownSource(mActivity)){
			Intent unknownSourceIntent = new Intent(mActivity, UnknownSourceDialogActivity.class);
			PageConstants.putPageParamInfo(unknownSourceIntent,  mPageParamInfo);
						/*Gson gson = new Gson();
						String infoBuffer = gson.toJson(loadingInfo, FileDownloadInfo.class);
						intent.putExtra(Constant.KEY_URL, infoBuffer);*/
			mActivity.startActivity(unknownSourceIntent);
			return;
		}

		PageParamInfo pageParamInfo = new PageParamInfo().copyValue(mPageParamInfo).setCurPage(PageConstants.Update_Button);

		//sk add by 20190618 for [Filter jump to GP item] begin
		List<ClientVersion.UpdateItem> localUpdate = new ArrayList<>();
		for(ClientVersion.UpdateItem item : this.listFilteredData) {
			if(!isNeedJumpToGpUpdate(item)) {
				localUpdate.add(item);
			}
		}
		String value = TRStringUtil.generateString(mScreenPageName, "","", "");
		IndividualCenterUpdateManageUtils.updateAll(mActivity, localUpdate, new PageParamInfo(mFrom,value),canInstall, waitingWiFi);
		DownloadStatusManager.getInstance().registerInfoInstance(localUpdate);
		//sk add by 20190618 for [Filter jump to GP item] end
		
		notifyDataSetChanged();
		
		if(mIMessenger!=null)
			mIMessenger.onMessenger();
	}

	private boolean isNeedJumpToGpUpdate(ClientVersion.UpdateItem list) {
		//TODO:check is jump to GP
		boolean ret = false;
		if(list != null && list.isOuter && !TextUtils.isEmpty(list.outerUrl)) {
			ret = true;
		}
		return ret;
	}
	
	private void notifyDataSetChangedWithInterfaceStatusChange(FileDownloadInfo downloadInfo) {

		int position = DownloadStatusManager.checkObserverData(listUpdateItem, downloadInfo, /*DetailType.isApp(downloadInfo.type)*/true);
		if (position >= 0 && position < listUpdateItem.size()) {
			UpdateItem mUpdateItem = listUpdateItem.get(position);
			DownloadStatusManager.getInstance().registerInfoInstance(mUpdateItem);
		}
		notifyDataSetChanged();

		if (mIMessenger != null)
			mIMessenger.onMessenger();
	}
	
	private void onAppPackageChange(String packageName, int versionCode, boolean isAdded) {
		
		
//		int position = DownloadStatusManager.checkObserverDataWithTypeApp(listUpdateItem, packageName, true);
//		UpdateItem mUpdateItem = null;
//		if (position >= 0 && position < listUpdateItem.size()) {
//			mUpdateItem = listUpdateItem.get(position);
//		}
//
//		if(null != mUpdateItem){
//			DownloadStatusManager.getInstance().registerInfoInstance(mUpdateItem);
//			if(isAdded){
//				listUpdateItem.remove(mUpdateItem);
//
//			} else{
//
//
//
//				//liuzhi 20170314下载完成再卸载，需要在updaet 列表消失
////				if(mUpdateItem.observerStatus == FileDownloadInfo.STATUS_NONE || mUpdateItem.observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED){
////					listUpdateItem.remove(mUpdateItem);
////				}
//				listUpdateItem.remove(mUpdateItem);
//			}
//		}
		
		if (mIMessenger != null)
			mIMessenger.onMessenger(InterfaceStatusChange.LISTENER_APPPackage_Added, packageName, versionCode);
	}
	public void destory() {
		onDestroy();
		if(listUpdateItem != null) {
			listUpdateItem.clear();
			//listUpdateItem = null;
		}
	}
	@Override
	public void putInterfaceStatusChange() {
		InterfaceBatchStatusChange mInterfaceStatusChange = new InterfaceBatchStatusChange() {

			@Override
			public void onDownloadStart(FileDownloadInfo downloadInfo) {
				if (downloadInfo != null && downloadInfo.extraInfo != null && downloadInfo.extraInfo.isVaGame) {
				} else {
					notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
				}
			}

			@Override
			public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {
				if (downloadInfo == null || downloadInfo.isVa()) {
					return;
				}
				int position = DownloadStatusManager.checkObserverData(listUpdateItem, downloadInfo, /*DetailType.isApp(downloadInfo.type)*/true);
				if (position >= 0 && position < listUpdateItem.size() && downloadInfo.downloadStatus != FileDownloadInfo.STATUS_PAUSE && downloadInfo.sourceSize > 0) {
//					float progress = downloadInfo.downloadedSize * 100 / downloadInfo.sourceSize;
//					updateOnItemProgressbar(position, (int) progress, downloadInfo, speed);
					UpdateRecyclerViewHolder updateRecyclerViewHolder = null;
					View view = mRecyclerView.getChildAt(position);
					if(view != null) {
						updateRecyclerViewHolder = (UpdateRecyclerViewHolder) mRecyclerView.getChildViewHolder(view);
					}

					if(updateRecyclerViewHolder != null){
						updateRecyclerViewHolder.updateViewHolderProgressBar(downloadInfo, speed);
					}
				}
			}

			@Override
			public void onDownloadComplete(FileDownloadInfo downloadInfo) {
				notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
			}

			@Override
			public void onActivated(FileDownloadInfo downloadInfo) {
				notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
			}

			@Override
			public void onDownloadError(FileDownloadInfo downloadInfo) {
				notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
			}

			@Override
			public void onDownloadPause(FileDownloadInfo downloadInfo) {
				notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
			}

			@Override
			public void onDownloadResume(FileDownloadInfo downloadInfo) {
				notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
			}

			@Override
			public void onDownloadDelete(FileDownloadInfo downloadInfo) {
				notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
			}

			@Override
			public void onDownloadBatchResume(List<FileDownloadInfo> downloadInfoList) {
				if (mLinearLayoutManager != null) {
					int first = mLinearLayoutManager.findFirstVisibleItemPosition();
					int last = mLinearLayoutManager.findLastVisibleItemPosition();
					int range = (last > first) ? (last - first + 1) : 1;
					notifyItemRangeChanged(first, range);
				}
                if (mIMessenger != null)
                    mIMessenger.onMessenger();
			}

			@Override
			public void onDownloadBatchPause(List<FileDownloadInfo> downloadInfoList) {
				if (mLinearLayoutManager != null) {
					int first = mLinearLayoutManager.findFirstVisibleItemPosition();
					int last = mLinearLayoutManager.findLastVisibleItemPosition();
					int range = (last > first) ? (last - first + 1) : 1;
					notifyItemRangeChanged(first, range);
				}
                if (mIMessenger != null)
                    mIMessenger.onMessenger();
			}

			@Override
			public void onAppPackageAdded(String packageName, int versionCode) {
				onAppPackageChange(packageName, versionCode, true);
			}

			@Override
			public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
				onAppPackageChange(packageName, versionCode, false);
			}
		};
		DownloadStatusManager.getInstance().putStatusChangeListener(TAG, mInterfaceStatusChange);
		DownloadStatusManager.getInstance().putStatusBatchChangeListener(TAG, mInterfaceStatusChange);
	}

	@Override
	public void removeInterfaceStatusChange() {
		DownloadStatusManager.getInstance().removeStatusChangeListener(TAG);
		DownloadStatusManager.getInstance().removeStatusBatchChangeListener(TAG);
	}

	@Override
	public Object loaderInterfaceStatusChangeObjectKey() {
		return null;
	}

	@Override
	public InterfaceStatusChange loaderInterfaceStatusChange() {
		return null;
	}

	public void notifyItemByPosition(String pkg) {
		if (TextUtils.isEmpty(pkg)) {
			return;
		}

		if (listUpdateItem == null || listUpdateItem.size() <= 0) {
			return;
		}

		int findIdx = -1;
		Iterator<UpdateItem> it = listUpdateItem.iterator();
		while (it.hasNext()) {
			findIdx++;
			UpdateItem item = it.next();
			if (TextUtils.equals(item.packageName, pkg)) {
				break;
			}
		}

		if (findIdx != -1) {
			notifyItemChanged(findIdx);
		}
	}

	private String getItemPVExtraValue() {
		String txt = "";
		try {
			JSONObject obj = new JSONObject();
			obj.put("s_item", ManageUpdateActivity.getCurrentFilterText(currentAppSort));
			txt = obj.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return txt;
	}

	/**
	 * 设置箭头图标并旋转
	 *
	 * @param textView TextView
	 * @param rotation 旋转角度 (0 或 180)
	 */
	private void setArrowDrawable(TextView textView, float rotation) {
		if (mActivity == null || textView == null) {
			return;
		}
		Drawable arrowDrawable = mActivity.getResources().getDrawable(R.drawable.arrow_down);
		if (arrowDrawable != null) {
			// 创建旋转的 Drawable
			RotateDrawable rotateDrawable = new android.graphics.drawable.RotateDrawable();
			rotateDrawable.setDrawable(arrowDrawable);
			rotateDrawable.setFromDegrees(rotation);
			rotateDrawable.setToDegrees(rotation);
			rotateDrawable.setLevel(10000); // 必须设置 level 才能显示

			// 设置固有尺寸
			int width = arrowDrawable.getIntrinsicWidth();
			int height = arrowDrawable.getIntrinsicHeight();
			rotateDrawable.setBounds(0, 0, width, height);

			textView.setCompoundDrawablesWithIntrinsicBounds(null, null, rotateDrawable, null);
		}
	}
}
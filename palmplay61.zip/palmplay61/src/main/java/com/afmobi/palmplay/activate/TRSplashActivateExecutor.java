package com.afmobi.palmplay.activate;

import android.content.Intent;

import com.afmobi.apk.ThreadHelper;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.alonefuction.SplashAdActivity;
import com.afmobi.palmplay.cache.AdCache;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.v6_0.StartUpTabsCache;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.OpenAdData;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.xwebview.preload.PreLoadConstants;
import com.transsion.xwebview.preload.UrlPreLoadProcessor;
import com.transsnet.store.BuildConfig;

import java.util.Iterator;
import java.util.List;

import static com.androidnetworking.common.ANConstants.PARSE_ERROR;

/***
 * created b yongli.li
 * 开屏广告的执行者
 */
public class TRSplashActivateExecutor extends TRBaseExecutor<GenericResponseInfo<OpenAdData>> {
    public static volatile boolean STATUS = false;//代表本身是否正在显示

    public TRSplashActivateExecutor() {

    }

    @Override
    public void loadData() {
        if(!AdCache.getInstance().isAdConfigLoadExpired()) {
            return;
        }

        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_REQUEST, TRAnalyticsConstant.SP_AD_REQUEST_NORMAL);

        AdCache.getInstance().onPreLoadHisavanaAd();

        List<String> list = AdCache.getInstance().getAdIdList();
        NetworkClient.requestSplashAdConfig(list, new AbsRequestListener<GenericResponseInfo<OpenAdData>>() {
            @Override
            public void onResponse(GenericResponseInfo<OpenAdData> response) {
                ThreadHelper.runOnWorkThread(() -> handleData(response));
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                if (PARSE_ERROR.equals(anError.getErrorDetail())){
                    TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_PARSE_FAIL);
                } else {
                    TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_FAIL);
                }

                AdCache.getInstance().setLastConfigLoadTime();
            }
        }, AdCache.class.toString());
    }

    private void handleData(GenericResponseInfo<OpenAdData> response) {
        // 返回成功后则设置时间，防止后台数据异常时导致客户端大量请求api接口
        AdCache.getInstance().setLastConfigLoadTime();
        if (response == null) {
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_REACH,TRAnalyticsConstant.SP_AD_REACH_NO_ADS);
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_NO_ADS);
            return;
        }
        parseData(response);//数据解析
    }

    @Override
    public void parseData(GenericResponseInfo<OpenAdData> data) {
        try {
            OpenAdData adData = data.getData();

            AdCache.getInstance().initOpenAdCaches(adData, true);

            if (adData != null && !adData.isAdListEmpty()) {
                TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_REACH,TRAnalyticsConstant.SP_AD_REACH_ADS);
                TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_ADS);
                List<OwnAdBean> ownAdBeans = AdCache.getAdList(adData);
                for (OwnAdBean adBean:ownAdBeans){

                    //url预加载
                    UrlPreLoadProcessor.handlePreLoadLogicWithThread(PreLoadConstants.SPLASH, adBean.getJumpType(), adBean.getJumpUrl(),
                            ConfigManager.isPreLoadOn(),StartUpTabsCache.getInstance().inInUrlWhiteList(adBean.getJumpUrl()));
                }
            } else {
                AdCache.getInstance().setAdsIsEmpty(true);
                TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_REACH,TRAnalyticsConstant.SP_AD_REACH_NO_ADS);
                TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_NO_ADS);
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    @Override
    public boolean show(String fromType) {
        if(CommonUtils.isBlockAllPopUps()) {
            return false;
        }

        //弹广告
        Intent intent = new Intent(PalmplayApplication.getAppInstance(), SplashAdActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(Constant.KEY_FROM_TYPE,fromType);
        PalmplayApplication.getAppInstance().startActivity(intent);
        LogUtils.d("start Splash Ad activity");
        return true;
    }

    @Override
    public boolean isCanShow(String fromType) {
        return true;
    }

    @Override
    public void cacheData(GenericResponseInfo<OpenAdData> data) {
    }
}

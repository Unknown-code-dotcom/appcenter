package com.afmobi.palmplay.activate.handler

import android.app.Activity
import android.content.DialogInterface
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.TRPrivacyPolicyExecutor
import com.afmobi.palmplay.activate.TRTipNetworkExecutor
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.activate.state.TRPopUpScene
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.dialog.TRDialogUtil
import com.afmobi.palmplay.main.dialog.PrivacyPolicyDialog
import com.afmobi.palmplay.main.dialog.TipNetworkDialog
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.log.LogUtils


/**
 * 默认的Handler, 适用于activity类弹框，show(fromtype)
 */
class DefaultChainHandler(
    executor: TRBaseExecutor<*>?,
    sceneName: String,
    priority: TRPriority,
    popupType: TRPopupType
) : TRChainHandler(sceneName, priority, popupType) {
    private var mExecutor: TRBaseExecutor<*>? = executor
    var from: String? = null

    companion object {
        private const val TAG = "DefaultChainHandler"
    }

    override fun canShow(fromType: String?): Boolean {
        if(!TRNewManager.instance.canShow()) {
            return  false
        }
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {    // 因为有DLCProvisionedDialog，AsrManager等不少未控制的弹框，需要加这个
            return false
        }
        if(mExecutor != null) {
            return mExecutor!!.isCanShow(fromType)
        }
        return false;
    }

    override fun show(fromType: String?): Boolean {

        if (canShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "home show $sceneName")
            if (mExecutor?.show(fromType) == true) {
                TRNewManager.instance.markAsShown()
                if(popupType == TRPopupType.HOME_ONE_TIME) {
                    TRAnalysticsUtil.trackPopSenceInfo(
                        "$sceneName show called",
                        fromType,
                        sceneName
                    )
                }
                LogUtils.d(TAG, "show $sceneName success")
                return true
            }
        }
        LogUtils.d(TRNewManager.TAG, " $sceneName can not show")
        return false
    }

    override fun show(fromType: String?, activity: Activity?): Boolean {
        if (canShow(fromType)) {
            if (mExecutor?.show(fromType, activity) == true) {
                if (sceneName != TRPopUpScene.POP_UP_TIP_NETWORK) {
                    TRNewManager.instance.markAsShown()
                }
                if (popupType == TRPopupType.HOME_ONE_TIME) {
                    TRAnalysticsUtil.trackPopSenceInfo(
                        "$sceneName show called",
                        fromType,
                        sceneName
                    )
                }
                LogUtils.d(TAG, "show $sceneName")
                return true
            }
        }
         return  false
    }

    override fun show(fromType: String?,
                      from: String?,
                      activity: Activity?): Boolean {
        if(canShow(fromType)) {
           if(mExecutor?.show(fromType, from, activity) == true) {
               if (sceneName != TRPopUpScene.POP_UP_TIP_NETWORK) {
                   TRNewManager.instance.markAsShown()
               }
               if (popupType == TRPopupType.HOME_ONE_TIME) {
                   TRAnalysticsUtil.trackPopSenceInfo(
                       "$sceneName show called",
                       fromType,
                       sceneName
                   )
               }
               LogUtils.d(TAG, "show $sceneName")
               return true
           }
        }
        return false
    }

    override fun show(
        fromType: String?,
        activity: Activity?,
        isNeedGuide: Boolean,
        listener: DialogInterface.OnDismissListener
    ): Boolean {
        if(canShow(fromType)) {
            if (mExecutor?.show(fromType, activity, isNeedGuide, listener) == true) {
                TRNewManager.instance.markAsShown()
                if(popupType == TRPopupType.HOME_ONE_TIME) {
                    TRAnalysticsUtil.trackPopSenceInfo(
                        "$sceneName show called",
                        fromType,
                        sceneName
                    )
                }
                LogUtils.d(TAG, "show $sceneName")
                return true
            }
        }
        return false
    }

    override fun dismiss(): Boolean {
        if(TRNewManager.instance.isNewPopEnable()) {
            if (mExecutor != null) {
                return mExecutor!!.dismiss()
            }
        }else{
            var aty = curActivity?.get()
            if(aty == null) {
                aty = AtyManager.getAtyManager().currentActivity
            }
            if(sceneName == TRPopUpScene.POP_UP_TIP_NETWORK) {
                val tipNetworkDialog = TipNetworkDialog.getDialog(aty)
                tipNetworkDialog?.dismiss()
            }
        }
        return false
    }

    override fun dismiss(activity: Activity?): Boolean {
        if(TRNewManager.instance.isNewPopEnable()) {
            if (mExecutor != null) {
                return mExecutor!!.dismiss()
            }
        }else{
            if(sceneName == TRPopUpScene.POP_UP_TIP_NETWORK) {
                val tipNetworkDialog = TipNetworkDialog.getDialog(activity)
                tipNetworkDialog?.dismiss()
            }
        }
        return false
    }

    override fun showNext(fromType: String?): Boolean {
        if(!canShow(fromType)) {
            return false
        }
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if(AtyManager.getAtyManager().currentActivity != curActivity?.get()) {
            return false
        }
        if(mExecutor is TRTipNetworkExecutor) {
            return (mExecutor as TRTipNetworkExecutor).show(fromType?:"", curActivity?.get())
        }
        if (mExecutor is TRPrivacyPolicyExecutor) {
            return (mExecutor as TRPrivacyPolicyExecutor).show(fromType?:"", curActivity?.get())
        }
        return mExecutor?.show(fromType) == true
    }

    override fun showing(): Boolean {
        if(mExecutor != null) {
            return mExecutor!!.isShowing
        }
        return false
    }

    override fun hide() {
        if(mExecutor is TRPrivacyPolicyExecutor) {
            (mExecutor as TRPrivacyPolicyExecutor).hide()
        }
    }

    override fun getExecutor(): TRBaseExecutor<*>? {
        return mExecutor
    }


}

//package com.afmobi.palmplay.cloudfolder.adapter
//
//import android.graphics.Rect
//import android.view.View
//import androidx.recyclerview.widget.RecyclerView
//import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
//import com.afmobi.palmplay.cloudfolder.utils.dip2px
//import com.transsion.palmstorecore.log.LogUtils
//
//
//class ShortcutsSpaceItemDecoration(private val mBottomSpacePx: Int, private val mHorizontalSpacePx: Int) :
//    RecyclerView.ItemDecoration() {
//
//        //屏幕宽度
//    private var availableWidthPx = DeviceProfile.getInstance().getAvailableWidthPx()
//    //item wrap_content时, 默认条目会向左边对齐(第一个贴着左侧屏幕)， 条目的间距计算规则如下
//    val padding : Float = (availableWidthPx - dip2px(76f) * 3 - dip2px(10f)).toFloat() / 3
//    //两侧两个条目距离中间的间距
//    val space = dip2px(10f)
//
//
//    override fun getItemOffsets(
//        outRect: Rect,
//        view: View,
//        parent: RecyclerView,
//        state: RecyclerView.State
//    ) {
//        val position = parent.getChildAdapterPosition(view) // item position
//
//        val column = position % 3 // item column
//
//        if(column == 0) {
//            outRect.left = (padding - space).toInt()
//        } else if(column == 1) {
//            outRect.left = (padding/2).toInt()
//        } else {
//            outRect.left = space
//        }
//
//        LogUtils.d("getItemOffsets " + column + "   left:"  + outRect.left + "     right:" + outRect.right +   " space: " + mHorizontalSpacePx)
//
////        if (position < 3) { // top edge
////            outRect.top = mBottomSpacePx
////        }
//        outRect.bottom = mBottomSpacePx // item bottom
//
//    }
//}
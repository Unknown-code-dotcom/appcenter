// TOP SECRET
package com.afmobi.palmplay.adapter;

import android.app.Activity;

import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.transsion.palmstorecore.log.LogUtils;

/**
 * Palmplay listener download state .
 * @author HJG
 * @date 2015-11-30 下午3:06:40
 * @modifyAuthor:
 * @modifyDate: 2015-11-30 下午3:06:40
 * @modifyContent:
 */
public abstract class PalmPlayBaseDownloadAdapter extends RecyclerView.Adapter {

	protected Activity mActivity;

	protected int mDetailType = DetailType.TYPE_INVALID;

	private Object mInterfaceStatusChangeKey;
	private InterfaceStatusChange mInterfaceStatusChange ;

	/**
	 * the construction function init DetailType 、 InterfaceStatusChange 、 InterfaceStatusChangeKey . 
	 * @param mActivity
	 */
	public PalmPlayBaseDownloadAdapter(Activity mActivity){
		this.mActivity = mActivity;
		mDetailType = loaderDetailType();
		mInterfaceStatusChangeKey = loaderInterfaceStatusChangeObjectKey();
		mInterfaceStatusChange = loaderInterfaceStatusChange();
	}

	public void onCreate(){
		putInterfaceStatusChange();
	}

	public void onCreateView(){
		putInterfaceStatusChange();
	}

	public void onResume(){
		putInterfaceStatusChange();
	}

	public void onStart(){
		putInterfaceStatusChange();
	}

	public void onStop(){
		removeInterfaceStatusChange();
	}

	public void onDestroy(){
		removeInterfaceStatusChange();
	}

	public InterfaceStatusChange getInterfaceStatusChange(){
		return mInterfaceStatusChange;
	}

	/**
	 * put a InterfaceStatusChange . the key is from loaderInterfaceStatusChangeObjectKey() .
	 */
	public void  putInterfaceStatusChange(){
		mInterfaceStatusChange = loaderInterfaceStatusChange();
		mInterfaceStatusChangeKey = loaderInterfaceStatusChangeObjectKey();

		LogUtils.e("Logger", getClass().getSimpleName()+" ==> putInterfaceStatusChange -> key= "+(mInterfaceStatusChangeKey==null?"null":mInterfaceStatusChangeKey)+" , value="+(mInterfaceStatusChange==null?"null":mInterfaceStatusChange));

		if(mInterfaceStatusChange!=null && mInterfaceStatusChangeKey!=null){
			DownloadStatusManager.getInstance().putStatusChangeListener(mInterfaceStatusChangeKey, mInterfaceStatusChange);
		}
	}

	/**
	 * remove a InterfaceStatusChange . the key is from loaderInterfaceStatusChangeObjectKey() .
	 */
	public void removeInterfaceStatusChange(){
		if(mInterfaceStatusChangeKey!=null){
			LogUtils.e("Logger", getClass().getSimpleName()+" ==> removeInterfaceStatusChange");
			DownloadStatusManager.getInstance().removeStatusChangeListener(mInterfaceStatusChangeKey);
		}
	}

	/**
	 * Note: need Override . 
	 * init data with this DetailType . 
	 * @return
	 */
	public abstract int loaderDetailType();

	/**
	 * Note: need Override . 
	 * init a key for map a InterfaceStatusChange . 
	 * 监听下载状态的 key, 该key最好为一个Activity 或 Fragment . 
	 * 主要用于线下, 线下的会有多个继承此类的适配器会处于同一个UI界面 , 所以key 需要自己设定 .
	 * @return
	 */
	public abstract Object loaderInterfaceStatusChangeObjectKey();

	/**
	 * Note: need Override .  
	 * when you find this return null, you can try new InterfaceStatusChange() in subclass's method loaderInterfaceStatusChange()  .
	 * example - Override public InterfaceStatusChange loaderInterfaceStatusChange(new loaderInterfaceStatusChange());
	 * init a InterfaceStatusChange . 
	 * @return
	 */
	public abstract InterfaceStatusChange loaderInterfaceStatusChange();


}

// TOP SECRET
package com.afmobi.palmplay.base;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.afmobi.util.DisplayUtil;
import com.transsnet.store.R;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;


/**
 * 
 * @author HJG
 * @date 2016-1-26 下午4:18:00
 * @modifyAuthor: 
 * @modifyDate: 2016-1-26 下午4:18:00
 * @modifyContent:
 */
public abstract class BaseEventContainerTitleFragmentActivity extends BaseEventFragmentActivity {

	protected TextView title_tv_content;
	protected View title_btn_back_right;
	
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.layout_common_container_frgment_view);
		
		if(getIntent()==null)
			finish();
		
		initTitleView();
		
	}
	
	final private void initTitleView(){
		findViewById(R.id.layout_title_back).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
		findViewById(R.id.layout_common_title).setBackgroundColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
		title_tv_content = (TextView) findViewById(R.id.layout_title_content);
		title_btn_back_right = findViewById(R.id.layout_title_right);
	}
	
	final protected void setRightBtnBackVisibility(int visibility){
		title_btn_back_right.setVisibility(visibility);
	}
	
	
	/**
	 * replace new fragment 
	 * @param titleStringId - title string id
	 * @param fragment - need show fragment 
	 */
	final protected void updateFragment(int titleStringId, Fragment fragment){
		title_tv_content.setText(titleStringId);
		replaceFragment(fragment);
	}
	
	/**
	 * new fragment 
	 * @param titleStringId - title string id
	 * @param fragment - need show fragment 
	 * @param bundle - fragment arguments
	 */
	final protected void updateFragment(int titleStringId, Fragment fragment, Bundle bundle){
		title_tv_content.setText(titleStringId);
		fragment.setArguments(bundle);
		replaceFragment(fragment);
	}
	
	/**
	 * replace fragment .
	 * @param fragment
	 */
	final protected void replaceFragment(Fragment fragment){
		replaceFragmentCommitAllowingStateLoss(R.id.layout_content, fragment/*, fragment.getClass().getSimpleName()*/);
	}
	
	/**
	 * fragment viewId - R.id.layout_content
	 * @return
	 */
	final protected Fragment getCurrentFragment(){
		return getSupportFragmentManager().findFragmentById(R.id.layout_content);
	}
	
	/**
	 * hide common title layout
	 */
	final protected void hideCommonTitleLayout(){
		findViewById(R.id.main_toolbar).setVisibility(View.GONE);// hide common title
	}
	
	final protected void showCommonTitleLayout(){
		findViewById(R.id.main_toolbar).setVisibility(View.VISIBLE);// show common title
	}
	
	/**
	 * get common title layout
	 * @return
	 */
	final protected View getCommonTitleLayout(){
		return findViewById(R.id.main_toolbar);
	}
	
}

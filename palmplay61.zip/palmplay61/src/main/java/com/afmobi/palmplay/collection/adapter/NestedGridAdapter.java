package com.afmobi.palmplay.collection.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.appnext.AppNextConstants;
import com.afmobi.palmplay.appnext.AppNextProcessor;
import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.customview.OnFeatureItemClickListener;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.home.instant.IVaPlayDownloadCallback;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureDataType;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.MarkStyle;
import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.afmobi.palmplay.main.adapter.ItemViewStateListener;
import com.afmobi.palmplay.main.adapter.viewholder.BaseRecyclerViewAdapter;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.animations.AnimationFactory;
import com.afmobi.util.animations.AnimationFactoryParams;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.shape.CornerFamily;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.SystemUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import java.util.UUID;

/**
 * 左右滑动的单行的样式的adapter
 */
public class NestedGridAdapter extends BaseRecyclerViewAdapter {

    private FeatureBean mFeatureBean;
    private String mFromPage;
    private boolean fromVA;
    private PageParamInfo mPageParamInfo;
    private ItemViewStateListener mItemViewStateListener;
    private OnViewLocationInScreen mOnViewLocationInScreen;
    private int paddingValue8, paddingValue6, paddingValue4, tvNameWidth, iconWidth;
    private LayoutInflater mInflate;
    private Context mContext;
    private OfferInfo mOfferInfo;

    public int mSourceType;
    private OnFeatureItemClickListener mOnFeatureClickListener;

    public NestedGridAdapter setFromPage(String mFromPage) {
        this.mFromPage = mFromPage;
        this.fromVA = TextUtils.equals(mFromPage, TRAnalyticsConstant.VA);
        return this;
    }

    public NestedGridAdapter setPageParamInfo(PageParamInfo PageParamInfo) {
        this.mPageParamInfo = PageParamInfo;
        return this;
    }

    public NestedGridAdapter setItemViewStateListener(ItemViewStateListener l) {
        this.mItemViewStateListener = l;
        return this;
    }

    public NestedGridAdapter setOnViewLocationInScreen(OnViewLocationInScreen l) {
        mOnViewLocationInScreen = l;
        return this;
    }

    public NestedGridAdapter setOfferInfo(OfferInfo offerInfo) {
        mOfferInfo = offerInfo;
        return this;
    }

    public NestedGridAdapter setData(FeatureBean featureBean) {
        this.mFeatureBean = featureBean;
        return this;
    }

    public NestedGridAdapter setOnFeatureItemClickListener(OnFeatureItemClickListener l) {
        this.mOnFeatureClickListener = l;
        return this;
    }

    public NestedGridAdapter(Context context) {
        mContext = context;
        mInflate = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(mContext).inflate(R.layout.layout_collection_grid_item, parent, false);
        return new SingleLineRecyclerViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder hld, int position) {
        bind(hld, position);
    }

    @Override
    public int getItemCount() {
        if (mFeatureBean == null || mFeatureBean.dataList == null) {
            return 0;
        }
        int size = mFeatureBean.dataList.size();
        return size;
    }

    private FeatureItemData getItem(int position) {
        if (mFeatureBean.dataList == null) {
            return null;
        }
        int size = mFeatureBean.dataList.size();
        if (size > 0 && position >= 0 && position < size) {
            return (FeatureItemData) mFeatureBean.dataList.get(position);
        } else {
            return null;
        }
    }

    private void bind(RecyclerView.ViewHolder viewHolder, int position) {

        paddingValue8 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 8);
        paddingValue6 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 6);
        paddingValue4 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 4);

        int screenWidth = fromVA ? Math.min(DisplayUtil.getScreenWidthPx(PalmplayApplication.getAppInstance()), DisplayUtil.getScreenHeightPx(PalmplayApplication.getAppInstance())) : DisplayUtil.getScreenWidthPx(PalmplayApplication.getAppInstance());
        int itemWidth = (screenWidth - DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 32)) / 4;
        int defaultIconWidth = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 60);
        tvNameWidth = itemWidth - paddingValue4 - paddingValue4;
        iconWidth = tvNameWidth - paddingValue8 - paddingValue4;
        if (iconWidth > defaultIconWidth) {
            iconWidth = defaultIconWidth;
        }

        SingleLineRecyclerViewHolder holder = (SingleLineRecyclerViewHolder) viewHolder;
        holder.setFeatureName(mFeaturedName);
        holder.setScreenPageName(mScreenPageName);
        holder.setStyleName(mFeatureBean.style);
        FeatureItemData item = getItem(position);
        if (item == null) {
            return;
        }

        holder.layout_01.setTag(item);
        int defaultIcon = R.drawable.layer_list_app_default_01_bg;

        if(item.tNativeInfo!=null) {
            item.tNativeInfo.registerViewForInteraction(holder.itemView,null);
        }

        int boderColor = ContextCompat.getColor(PalmplayApplication.getAppInstance(), R.color.img_border_color);
        if (mOfferInfo != null && mOfferInfo.isOfferStyle()) {//for offer
            holder.tv_name.setTextColor(mOfferInfo.mainColor);
            boderColor = mOfferInfo.borderColor;
            holder.tv_size.setTextColor(mOfferInfo.subColor);
            holder.tv_rate.setTextColor(mOfferInfo.subColor);
        }

        int radius = SystemUtils.dip2px(PalmplayApplication.getAppInstance(), 12);
        holder.tv_name.setText(item.name);
        holder.iv_icon.setShapeAppearanceModel(holder.iv_icon.getShapeAppearanceModel().toBuilder().setAllCorners(CornerFamily.ROUNDED, radius).build());
        holder.iv_icon.setStrokeColor(CommonUtils.createColorStateList(boderColor));
        GlideUtils.setImageUrl(holder.iv_icon, item.iconUrl, GlideUtils.newCommonRequestOptions(), defaultIcon, defaultIcon);

        holder.tv_name.getLayoutParams().width = tvNameWidth;
        if (holder.downloadView.getLayoutParams().width > tvNameWidth) {
            holder.downloadView.getLayoutParams().width = tvNameWidth;
        }
        holder.iv_icon.getLayoutParams().width = iconWidth;
        holder.iv_icon.getLayoutParams().height = iconWidth;

        updateTextDownloadCountAndSize(item, holder.tv_size);
        boolean show = CommonUtils.shouldShowScore(item.score);
        holder.ll_rate_layout.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            holder.tv_rate.setText(String.valueOf(item.score));
        }

        if (MarkStyle.GP_SHOW.equals(item.showStyle) && FeatureDataType.GP_ITEM.equals(item.dataType)){
            holder.iv_google.setVisibility(View.VISIBLE);
        } else {
            holder.iv_google.setVisibility(View.GONE);
        }

        holder.tv_size.setVisibility(View.VISIBLE);
        holder.ll_rate_layout.setVisibility(View.GONE);
        if (item.hitActivity > 0 && !item.isVa) {
            holder.iv_gift.setVisibility(View.GONE);
        }else {
            holder.iv_gift.setVisibility(TextUtils.isEmpty(item.lableUrl) || !CommonUtils.isGiftFlagNeedShow() ? View.GONE : View.VISIBLE);
            GlideUtils.setImageUrlWithNoBorder(holder.iv_gift, item.lableUrl);
        }

        holder.downloadView.setOnClickListener(new DownloadBtnOnClickListener(holder, item, holder.downloadView, position));
//        holder.layout_01.setOnClickListener(new NoDoubleClickListener(item));

        DownloadStatusManager.getInstance().registerFeatureItemInstance(item);
        CommonUtils.checkStatusItemDisplay(item, holder.downloadView, mOfferInfo, null);
        holder.va_flag.setVisibility(item.isVa ? View.VISIBLE : View.GONE);//跟Play按钮成对出现

        item.placementId = String.valueOf(position);

        FeatureItemData featureItemData = item;
        if (!featureItemData.hasTrack) {
            featureItemData.hasTrack = true;
            String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);
            ComponentExposureBuilder builder = new ComponentExposureBuilder<>();
            String adPosId = featureItemData.tNativeInfo != null ? featureItemData.tNativeInfo.getPlacementId() : null;
            String builderVarId = "";
            if (TextUtils.isEmpty(mVarId)) {
                builderVarId = featureItemData.getVarId();
            } else {
                if (featureItemData.getVarId() == null || featureItemData.getVarId().isEmpty()) {
                    builderVarId = mVarId;
                } else {
                    builderVarId = featureItemData.getVarId() + "," + mVarId;
                }
            }

            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType(mFeatureBean.style)
                    .setTopicId(featureItemData.topicID)
                    .setItemType(featureItemData.detailType)
                    .setItemId(featureItemData.itemID)
                    .setItemValue(featureItemData.packageName)
                    .setExtraValue(getExtraValue(mPageParamInfo, featureItemData.planId))
                    .setTaskId(featureItemData.getTaskId())
                    .setExpId(featureItemData.getExpId())
                    .setItemFrom(featureItemData.getItemFrom())
                    .setReportSource(featureItemData.getReportSource())
                    .setVarId(builderVarId)
                    .setNativeId(featureItemData.nativeId)
                    .setDataType(featureItemData.dataType)
                    .setFeatureId(mFeatureBean.featureId)
                    .setExtras(CommonUtils.getNewExtras(null, mFeaturedName, mFeatureBean.tabNum))
                    .setAdPositionId(adPosId);
            if (featureItemData.reportDto!=null) {
                builder.setTid(featureItemData.reportDto.traceId);
                builder.setNfAbExpId(featureItemData.reportDto.nfAbExpId);
                builder.setNfAbId(featureItemData.reportDto.nfAbId);
            }
            TRAnalysticsUtil.trackExposure(builder);
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        if (holder instanceof SingleLineRecyclerViewHolder) {
            ((SingleLineRecyclerViewHolder) holder).iv_icon.setImageDrawable(null);
        }
    }

    private void updateTextDownloadCountAndSize(FeatureItemData featureData, TextView tv_download_count_and_size) {
        if (mFeatureBean.isShowElement(FeatureBean.SHOW_UP_CONFIG_RATE) && mFeatureBean.isShowElement(FeatureBean.SHOW_UP_CONFIG_SIZE)) {
            tv_download_count_and_size.setVisibility(View.VISIBLE);
            CommonUtils.setStrikeThroughSpannable(featureData.size, featureData.compSourceSize, tv_download_count_and_size);
        } else {
            tv_download_count_and_size.setVisibility(View.GONE);
        }
    }

    private String getExtraValue(PageParamInfo mPageParamInfo, int planId) {
        JsonObject js = new JsonObject();
        try {
            if(planId > 0) {
                js.addProperty(TRAnalyticsConstant.PLAN_ID, planId);
            }
            if(mPageParamInfo != null && !TextUtils.isEmpty(mPageParamInfo.getTabId())) {
                js.addProperty("tabId", mPageParamInfo.getTabId());
            }
        }catch (Exception ignored) {
        }
        return js.toString();
    }


    private class SingleLineRecyclerViewHolder extends BaseRecyclerViewHolder {

        private View layout_01;
        private ShapeableImageView iv_icon;
        private TextView tv_name;
        private TextView tv_size;
        private TextView tv_rate;
        private ImageView iv_google;
        private LinearLayout ll_rate_layout;
        private XFermodeDownloadView downloadView;
        private ImageView iv_gift;
        private View va_flag;

        public SingleLineRecyclerViewHolder(View itemView) {
            super(itemView);
            layout_01 = itemView.findViewById(R.id.layout_01);
            iv_icon = itemView.findViewById(R.id.iv_icon);
            iv_google = itemView.findViewById(R.id.iv_google);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_size = itemView.findViewById(R.id.tv_size);
            ll_rate_layout = itemView.findViewById(R.id.ll_rate_layout);
            tv_rate = itemView.findViewById(R.id.tv_rate);
            downloadView = itemView.findViewById(R.id.downloadView);
            iv_gift = itemView.findViewById(R.id.iv_gift);
            va_flag = itemView.findViewById(R.id.va_flag);
        }
    }

    //防止快速点击响应多次
    private class NoDoubleClickListener implements View.OnClickListener {

        private FeatureItemData featureItemData;

        public NoDoubleClickListener(FeatureItemData featureItemData) {
            this.featureItemData = featureItemData;
        }

        @Override
        @SingleClick(800)
        public void onClick(View v) {
            if (featureItemData != null && !TextUtils.isEmpty(featureItemData.itemID)) {
                String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);
                ComponentClickBuilder builder = new ComponentClickBuilder();
                String adPosId = featureItemData.tNativeInfo != null ? featureItemData.tNativeInfo.getPlacementId() : null;
                String builderVarId = "";
                if (TextUtils.isEmpty(mVarId)) {
                    builderVarId = featureItemData.getVarId();
                } else {
                    if (featureItemData.getVarId() == null || featureItemData.getVarId().isEmpty()) {
                        builderVarId = mVarId;
                    } else {
                        builderVarId = featureItemData.getVarId() + "," + mVarId;
                    }
                }

                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(mFeatureBean.style)
                        .setTopicId(featureItemData.topicID)
                        .setItemType(featureItemData.detailType)
                        .setItemId(featureItemData.itemID)
                        .setButtonType(TRAnalyticsConstant.ICON)
                        .setItemValue(featureItemData.packageName)
                        .setExtraValue(getExtraValue(mPageParamInfo, featureItemData.planId))
                        .setTaskId(featureItemData.getTaskId())
                        .setExpId(featureItemData.getExpId())
                        .setItemFrom(featureItemData.getItemFrom())
                        .setReportSource(featureItemData.getReportSource())
                        .setVarId(builderVarId)
                        .setNativeId(featureItemData.nativeId)
                        .setDataType(featureItemData.dataType)
                        .setFeatureId(mFeatureBean.featureId)
                        .setExtras(CommonUtils.getNewExtras(null, mFeaturedName, mFeatureBean.tabNum))
                        .setAdPositionId(adPosId);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                    builder.setNfAbExpId(featureItemData.reportDto.nfAbExpId);
                    builder.setNfAbId(featureItemData.reportDto.nfAbId);
                }
                TRAnalysticsUtil.trackClick(builder);

                if(handleJumpGpLogic(featureItemData)){
                    return;
                }

                if(featureItemData!=null && featureItemData.tNativeInfo!=null) {
                    featureItemData.tNativeInfo.handleClick(HisavanaSdkManager.CLICK_ICON);
                }
                AppBuilder appBuilder = new AppBuilder()
                        .setFromPage(mFromPage)
                        .setLastPage(PageConstants.getCurPageStr(mPageParamInfo))
                        .setVarId(builderVarId)
                        .setExpId(featureItemData.getExpId())
                        .setTopicID(featureItemData.topicID)
                        .setValue(value)
                        .setParamsByData(featureItemData, mFeatureBean.featureId);
                if (fromVA && AtyManager.getAtyManager().getActivity(MainActivity.class) == null) {
                    TRJumpUtil.switchToAppDetailOptionsWithMain(appBuilder);
                } else {
                    TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);
                }
            }
        }


    }

    // download click listener
    class DownloadBtnOnClickListener implements View.OnClickListener {

        private SingleLineRecyclerViewHolder holder;
        private FeatureItemData featureItemData;
        private View bindClickView;
        private int mPosition;

        public DownloadBtnOnClickListener(SingleLineRecyclerViewHolder holder, FeatureItemData featureItemData, View bindClickView, int position) {
            this.holder = holder;
            this.featureItemData = featureItemData;
            this.bindClickView = bindClickView;
            this.mPosition = position;
        }

        @Override
        public void onClick(View v) {
            if (bindClickView == null || holder == null || featureItemData == null)
                return;

            if (bindClickView.getId() == holder.downloadView.getId()) {
                if (mOnFeatureClickListener != null) {
                    mOnFeatureClickListener.onFeatureItemClick(featureItemData, mPosition, null);
                }
                String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);
                String itemFrom = featureItemData.getItemFrom();
                String reportSource = featureItemData.getReportSource();
                String cfgId = featureItemData.reportDto!=null ? featureItemData.reportDto.cfgId : "";
                String adPosId = featureItemData.tNativeInfo != null ? featureItemData.tNativeInfo.getPlacementId() : null;
            //    String clickId = UUID.randomUUID().toString().replace("-","");

                ComponentClickBuilder builder = new ComponentClickBuilder();

                String builderVarId = "";
                if (TextUtils.isEmpty(mVarId)) {
                    builderVarId = featureItemData.getVarId();
                } else {
                    if (featureItemData.getVarId() == null || featureItemData.getVarId().isEmpty()) {
                        builderVarId = mVarId;
                    } else {
                        builderVarId = featureItemData.getVarId() + "," + mVarId;
                    }
                }
                if (featureItemData.tNativeInfo != null) {
                    featureItemData.tNativeInfo.handleClick(HisavanaSdkManager.CLICK_ICON);
                }

                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(mFeatureBean.style)
                        .setTopicId(featureItemData.topicID)
                        .setItemType(featureItemData.detailType)
                        .setItemId(featureItemData.itemID)
                        .setItemValue(featureItemData.packageName)
                        .setExtraValue(getExtraValue(mPageParamInfo, featureItemData.planId))
                        .setTaskId(featureItemData.getTaskId())
                        .setExpId(featureItemData.getExpId())
                        .setItemFrom(itemFrom)
                        .setReportSource(reportSource)
                        .setCfgId(cfgId)
                  //      .setClickId(clickId)
                        .setVarId(builderVarId)
                        .setNativeId(featureItemData.nativeId)
                        .setReportSource(featureItemData.getReportSource())
                        .setDataType(featureItemData.dataType)
                        .setFeatureId(mFeatureBean.featureId)
                        .setExtras(CommonUtils.getNewExtras(null, mFeaturedName, mFeatureBean.tabNum))
                        .setAdPositionId(adPosId)
                        .setFromPage(mFromPage)
                        .setIsVa(featureItemData.isVa);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                    builder.setNfAbExpId(featureItemData.reportDto.nfAbExpId);
                    builder.setNfAbId(featureItemData.reportDto.nfAbId);
                }
                PsVaManager.getInstance().checkDownloadInfo(featureItemData,LaunchInfo.LAUNCH_FROM_ICON,mFromPage,value,
                        new IVaPlayDownloadCallback() {
                            @Override
                            public void clickVaPlay() {
                                builder.setButtonType(TRAnalyticsConstant.PLAY);
                                TRAnalysticsUtil.trackClick(builder);
                            }
                            @Override
                            public void start() {
                                DownloadBtnOnClickListener.this.startDownload(featureItemData, holder.iv_icon, builder);
                            }
                        });
            }

        }

        private void startDownload(FeatureItemData featureItemData, ImageView iv_icon, ComponentClickBuilder builder) {
            if (featureItemData == null) {
                return;
            }
            String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, featureItemData.topicPlace, featureItemData.placementId);

            //处理gp跳转逻辑
            if(handleJumpGpLogic(featureItemData)){
                builder.setButtonType(TRAnalyticsConstant.INSTALL);
                TRAnalysticsUtil.trackClick(builder);
                return;
            }


            if (FileDownloadInfo.STATUS_DOWNING == featureItemData.observerStatus) {
                DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_WAIT == featureItemData.observerStatus) {
                if ((featureItemData.isVa)) {
                    DownloadManager.getInstance().resumeDownload(featureItemData.packageName);
                } else {
                    DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                }
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_PAUSE == featureItemData.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == featureItemData.observerStatus) {
                DownloadUtil.resumeDownload(PalmplayApplication.getAppInstance(), featureItemData.packageName);
                builder.setButtonType(TRAnalyticsConstant.CONTINUE);
                TRAnalysticsUtil.trackClick(builder);
            } else {
                if (FileDownloadInfo.STATUS_NONE == featureItemData.observerStatus) {//下载

                    if (!TextUtils.isEmpty(featureItemData.getClickReportUrl())) {
                        AppNextProcessor.addAsyncTask(featureItemData.packageName, AppNextConstants.ITEM_CLICK, featureItemData.getClickReportUrl());
                    }
                    builder.setButtonType(TRAnalyticsConstant.INSTALL);
                    TRAnalysticsUtil.trackClick(builder);
                } else if (FileDownloadInfo.STATUS_APP_INSTALLED == featureItemData.observerStatus) {//打开
                    builder.setButtonType(TRAnalyticsConstant.OPEN)
                            .setExtraValue(DeeplinkManager.getDeeplink(featureItemData.packageName));
                    TRAnalysticsUtil.trackClick(builder);
                } else if (FileDownloadInfo.STATUS_APP_UPDATE == featureItemData.observerStatus) {
                    builder.setButtonType(TRAnalyticsConstant.UPDATE);
                    TRAnalysticsUtil.trackClick(builder);
                }
                if (DownloadDecorator.checkJumpToGooglePlay(PalmplayApplication.getAppInstance(), featureItemData.getOuterUrl(), featureItemData.packageName, mPageParamInfo, featureItemData.itemID, featureItemData.versionCode, featureItemData.verifyGoogle)) {
                    return;
                }

                if(featureItemData!=null && featureItemData.tNativeInfo!=null && CommonUtils.isFirstClick(featureItemData.observerStatus)) {
                    featureItemData.tNativeInfo.handleClick(HisavanaSdkManager.FIRST_CREATE);
                }

                AnimationFactory mAnimationFactory = null;
                AnimationFactoryParams param = null;

                if (mOnViewLocationInScreen != null) {
                    mAnimationFactory = AppDetailAnimationUtil.getInstance();
                    param = new AnimationFactoryParams(iv_icon, mOnViewLocationInScreen, 24);
                }
                AppInfo appInfo = FeatureItemData.convertToCommonInfo(featureItemData, mFeatureBean.featureId);
                appInfo.sourceType = mSourceType;
                DownloadDecorator.startDownloading(appInfo, mFromPage, new PageParamInfo(mFrom, value), mAnimationFactory, param);
            }
        }
    }


    public static void updateItemProgress(View itemView, FileDownloadInfo downloadInfo, int progress, OfferInfo offerInfo) {
        RecyclerView bv_home_recycleview = (RecyclerView) itemView.findViewById(R.id.bv_home_recycleview);
        if (bv_home_recycleview == null) return;
        RecyclerView.Adapter adapter = bv_home_recycleview.getAdapter();
        if (adapter == null || downloadInfo == null) {
            return;
        }

        String packageName = downloadInfo.packageName;
        int childCount = adapter.getItemCount();
        LinearLayoutManager lm = (LinearLayoutManager) bv_home_recycleview.getLayoutManager();
        for (int i = 0; i < childCount; i++) {
            View childView = lm.findViewByPosition(i);
            Object objTag = childView != null ? childView.getTag() : null;
            if (objTag != null && objTag instanceof FeatureItemData) {
                FeatureItemData featureItemData = (FeatureItemData) objTag;
                if (!TextUtils.isEmpty(featureItemData.packageName) && featureItemData.packageName.equals(packageName)) {
                    XFermodeDownloadView downloadView = (XFermodeDownloadView) childView.findViewById(R.id.downloadView);
                    CommonUtils.updateViewHolderProgressBar(downloadInfo, downloadView, offerInfo, null);
                }
            }
        }
    }

    public void setFeatureName(String featureName) {
        mFeaturedName = featureName;
    }

    public void setCurScreenPage(String screenPage) {
        mScreenPageName = screenPage;
    }
}

package com.afmobi.palmplay.appmanage.holder;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.FileManageDownloadAdapterItem;
import com.afmobi.palmplay.appmanage.adapter.FileManageDownloadAdapter;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutManageDownloadingListItemBinding;

import java.util.List;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by sk on 17-5-10.
 */

public class ChildDownloadingRecyclerViewHolder extends RecyclerView.ViewHolder {
    private Activity mActivity;
    private FileManageDownloadAdapter adapter;
    private List<FileManageDownloadAdapterItem> mDatas;
    private PageParamInfo mPageParamInfo;
    private LayoutManageDownloadingListItemBinding binding;
    private FileDownloadInfo fileDownloadInfo;
    protected String mScreenPageName;
    protected String mFeatureName;
    public String mFrom;//新型打点的from值
    private FileManageDownloadAdapterItem mDownloadingInfo;

    public ChildDownloadingRecyclerViewHolder(View itemView) {
        super(itemView);
        binding = DataBindingUtil.getBinding(itemView);
        if (binding != null) {
            binding.setHolder(this);
        }
    }

    public void bind(FileManageDownloadAdapterItem downloadingInfo, final int position) {
        itemView.setTag(downloadingInfo);
        if (binding == null) {
            return;
        }

        mDownloadingInfo = downloadingInfo;
        fileDownloadInfo = downloadingInfo.fileDownloadInfo;
        binding.tvName.setText(fileDownloadInfo.name);

        int defaultIcon = R.drawable.layer_list_app_default_01_bg_l;
        if (!TextUtils.isEmpty(fileDownloadInfo.iconUrl)) {
            GlideUtils.setImageUrl(binding.ivIcon, fileDownloadInfo.iconUrl, defaultIcon, defaultIcon);
        } else {
            binding.ivIcon.setImageDrawable(PalmplayApplication.getAppInstance().getDrawable(defaultIcon));
        }

        int observerStatus = DownloadStatusManager.getInstance().getObserverStatus(fileDownloadInfo, fileDownloadInfo.downloadStatus);
        CommonUtils.checkDownloadingItemDisplay(fileDownloadInfo, observerStatus, binding.tvSpeed, binding.tvProgress);

        CommonUtils.checkStatusItemDisplay(fileDownloadInfo, observerStatus, binding.btnOperation, null, null,false,fileDownloadInfo.packageName,fileDownloadInfo.itemID);

        binding.btnOperation.setEnabled(true);

        binding.ibDropdown.setSelected(fileDownloadInfo.isExpand());
        binding.ibDelete.setVisibility(fileDownloadInfo.isExpand() ? View.VISIBLE : View.GONE);

//        if(ConfigManager.getDownloadManagerDeleIsExpand()){
//            binding.ibDropdown.setImageResource(R.drawable.ic_close_grey_pressed);
//        } else {
//            binding.ibDropdown.setImageResource(R.drawable.selector_drop_down_bg);
//            binding.ibDropdown.setSelected(fileDownloadInfo.isExpand());
//            binding.ibDelete.setVisibility(fileDownloadInfo.isExpand() ? View.VISIBLE : View.GONE);
//        }
        if(fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isSpaceLimit) {
            binding.tvName.setTextColor(mActivity.getResources().getColor(R.color.download_manage_title));
            binding.tvProgress.setTextColor(mActivity.getResources().getColor(R.color.download_manage_desc));
            binding.tvSpeed.setTextColor(mActivity.getResources().getColor(R.color.download_manage_desc));
            binding.layoutBtn.setVisibility(View.VISIBLE);
            binding.ivDeleteNoResoures.setVisibility(View.GONE);
            binding.ivLayer.setVisibility(View.GONE);
            binding.layoutDownloading.setVisibility(View.GONE);
            binding.tvSpaceLimit.setVisibility(View.VISIBLE);
            String dstStr = PalmplayApplication.getAppInstance().getString(R.string.disk_space_not_enough_tips_title);
            binding.tvSpaceLimit.setText(dstStr);
            Drawable d = ContextCompat.getDrawable(PalmplayApplication.getAppInstance(), R.drawable.ic_clean_warn);
            binding.tvSpaceLimit.setCompoundDrawablesRelative(d,null,null,null);
        } else if (fileDownloadInfo.downloadStatus == FileDownloadInfo.STATUS_PAUSE && fileDownloadInfo.extraInfo != null && !fileDownloadInfo.extraInfo.itemCheckFlag && !fileDownloadInfo.extraInfo.canRetry) {
//            binding.layoutDownloading.setVisibility(View.VISIBLE);
//            binding.ivLayer.setVisibility(View.VISIBLE);
//            binding.layoutBtn.setVisibility(View.GONE);
//            binding.ivDeleteNoResoures.setVisibility(View.VISIBLE);
//            String dstStr = PalmplayApplication.getAppInstance().getString(R.string.no_resource);
//            binding.tvName.setTextColor(mActivity.getResources().getColor(R.color.pluto_item_desc_color));
//            binding.tvProgress.setTextColor(mActivity.getResources().getColor(R.color.pluto_item_desc_color));
//            binding.tvSpeed.setTextColor(mActivity.getResources().getColor(R.color.pluto_item_desc_color));
//            CommonUtils.setDownloadButtonGray(binding.btnOperation,
//                    PalmplayApplication.getAppInstance().getResources().getDrawable(R.drawable.selector_common_gray_btn_bg));
//            binding.btnOperation.setEnabled(false);
//            binding.tvSpeed.setText(dstStr);
        } else if (fileDownloadInfo.downloadStatus == FileDownloadInfo.STATUS_PAUSE && fileDownloadInfo.isWaitingWifi()) {
            binding.tvName.setTextColor(mActivity.getResources().getColor(R.color.download_manage_title));
            binding.tvProgress.setTextColor(mActivity.getResources().getColor(R.color.download_manage_desc));
            binding.tvSpeed.setTextColor(mActivity.getResources().getColor(R.color.download_manage_desc));
            binding.ivLayer.setVisibility(View.GONE);
            binding.layoutDownloading.setVisibility(View.GONE);
            binding.tvSpaceLimit.setVisibility(View.VISIBLE);
            binding.layoutBtn.setVisibility(View.VISIBLE);
            binding.ivDeleteNoResoures.setVisibility(View.GONE);
            String dstStr = PalmplayApplication.getAppInstance().getString(R.string.txt_waiting_wifi);
            binding.tvSpaceLimit.setText(dstStr); //复用空间不足的view展示Waiting for Wi-Fi提示
            binding.tvSpaceLimit.setCompoundDrawablesRelative(null,null,null,null);
        } else {
            binding.tvName.setTextColor(mActivity.getResources().getColor(R.color.download_manage_title));
            binding.tvProgress.setTextColor(mActivity.getResources().getColor(R.color.download_manage_desc));
            binding.tvSpeed.setTextColor(mActivity.getResources().getColor(R.color.download_manage_desc));
            binding.ivLayer.setVisibility(View.GONE);
            binding.layoutDownloading.setVisibility(View.VISIBLE);
            binding.tvSpaceLimit.setVisibility(View.GONE);
            binding.layoutBtn.setVisibility(View.VISIBLE);
            binding.ivDeleteNoResoures.setVisibility(View.GONE);
        }
    }

    public ChildDownloadingRecyclerViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public ChildDownloadingRecyclerViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    public ChildDownloadingRecyclerViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }

    public void updateViewHolderProgressBar(FileDownloadInfo downloadInfo, int speed) {
        String sizeStr = FileUtils.getSizeName(downloadInfo.downloadedSize) + "/" + FileUtils.getSizeName(downloadInfo.sourceSize);
        binding.tvProgress.setText(sizeStr);
        binding.tvSpeed.setText(FileUtils.getFileSizeMapUnit(speed, false) + "/S");
        CommonUtils.updateViewHolderProgressBar(downloadInfo, binding.btnOperation, null, null);
    }

    public ChildDownloadingRecyclerViewHolder setActivity(Activity curActivity) {
        mActivity = curActivity;
        return this;
    }

    public ChildDownloadingRecyclerViewHolder setAdapter(FileManageDownloadAdapter adapter) {
        this.adapter = adapter;
        return this;
    }

    public ChildDownloadingRecyclerViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        this.mPageParamInfo = pageParamInfo;
        return this;
    }

    public ChildDownloadingRecyclerViewHolder setDatas(List<FileManageDownloadAdapterItem> datas) {
        mDatas = datas;
        return this;
    }

    public void onDeleteNoResoures() {
        onDeleteBtnClick();
    }

    public void onDropDownBtnClick() {
        if(ConfigManager.getDownloadManagerDeleIsExpand()) {
            onDeleteBtnClick();
        } else {
            boolean state = binding.ibDropdown.isSelected();
            binding.ibDropdown.setSelected(!state);

            binding.ibDelete.setVisibility(state ? View.GONE : View.VISIBLE);
            if (fileDownloadInfo != null) {
                fileDownloadInfo.setExpandFlag(!state);
            }
            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, String.valueOf("0"), mDownloadingInfo.placementId);
            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(fileDownloadInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.MORE_TYPE)
                    .setItemValue(fileDownloadInfo.packageName)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);
        }
    }

    public void onDeleteBtnClick() {
        if (binding == null || fileDownloadInfo == null) {
            return;
        }
        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
            deleteTask(fileDownloadInfo);
        } else {
            final DialogBuilder mDialogBuilder = new DialogBuilder();
            new CustomDialog(mActivity).showCheckBoxFunctionDialog(
                    mDialogBuilder
                            .hideTitle()
                            .setMessage(mActivity.getString(R.string.delete_task))
                            .setCheckBoxChecked(false)
                            .setCheckBoxText(mActivity.getString(R.string.no_again))
                            .setNegativeBtnText(mActivity.getString(R.string.text_cancel))
                            .setPositiveBtnText(mActivity.getString(R.string.text_ok))
                            .setPositiveBtnOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View view) {
                                    SPManager.putBoolean(Constant.preferences_delete_tips_downloading_record, mDialogBuilder.isCheckBoxChecked());
                                    deleteTask(fileDownloadInfo);
                                }
                            }));
        }
        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_EXPAND_CLICK, null);
    }

    public void onOperationBtnClick() {
        if (fileDownloadInfo == null) {
            return;
        }
        if (fileDownloadInfo.downloadStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
            // 文件下载完成，正在进行校验，此时不处理点击事件，页面显示进度100%
            if (BuildConfig.DEBUG) {
                Log.e("checkDownloadInfo", "文件下载完成，校验中...", new Throwable("who call me"));
            }
            return;
        }

        if (fileDownloadInfo.isOffline && fileDownloadInfo.isGrp && DownloadManager.getInstance().isGrpCanUncompress(fileDownloadInfo)) {
            // PalmPlayGrpZipUtils.unCompressGroup(info);
        } else if (fileDownloadInfo.downloadStatus != FileDownloadInfo.STATUS_PAUSE
                && fileDownloadInfo.downloadStatus != FileDownloadInfo.STATUS_NETWORK_ERROR) {//点击暂停
            fileDownloadInfo.downloadStatus = FileDownloadInfo.STATUS_PAUSE;
            DownloadManager.getInstance().pauseDownload(fileDownloadInfo.packageName);
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_PAUSE_CLICK, null);
            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, String.valueOf("0"), mDownloadingInfo.placementId);
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(fileDownloadInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.PAUSE)
                    .setItemValue(fileDownloadInfo.packageName)
                    .setFromPage(fileDownloadInfo.fromPage)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);

            ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.getPausePageParamInfo(mPageParamInfo, fileDownloadInfo.type));
        } else {//继续下载
//            if (!FileUtils.hasEnoughDiskSpace(mActivity, fileDownloadInfo.sourceSize - fileDownloadInfo.downloadedSize)) {
//                ToastManager.getInstance().showS(PalmplayApplication.getAppInstance().getApplicationContext(),
//                        R.string.tips_not_enough_disk_space);
//                return;
//            }

            if(fileDownloadInfo.extraInfo != null && fileDownloadInfo.extraInfo.isSpaceLimit) {
                fileDownloadInfo.extraInfo.isSpaceLimit = false;
            }
            DownloadUtil.resumeDownload(mActivity, fileDownloadInfo.packageName);
            if (fileDownloadInfo.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR || fileDownloadInfo.isWifiLostPause) {
                FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_FAILED_CONTINUE_CLICK, null);
            } else {
                FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_PAUSE_CONTINUE_CLICK, null);
            }
            ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.getContinuePageParamInfo(mPageParamInfo, fileDownloadInfo.type));
            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, String.valueOf("0"), mDownloadingInfo.placementId);
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(fileDownloadInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.CONTINUE)
                    .setItemValue(fileDownloadInfo.packageName)
                    .setFromPage(fileDownloadInfo.fromPage)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);
        }
    }

    public void onItemLayoutClick(View view) {
        if (fileDownloadInfo == null) {
            return;
        }
        // 屏蔽PalmSpace插件的点击
        if (VaStaticProxy.isInstantPluginApp(fileDownloadInfo.packageName)) {
            return;
        }
        RankDataListItem item = new RankDataListItem();
        item.name = fileDownloadInfo.name;
        item.versionName = fileDownloadInfo.versionName;
        item.downloadCount = CommonUtils.sting2IntNoException(fileDownloadInfo.downloadCount);
        item.downloadID = fileDownloadInfo.downloadID;
        item.downloadUrl = fileDownloadInfo.downloadUrl;
        item.iconUrl = fileDownloadInfo.iconUrl;
        item.imgUrl = fileDownloadInfo.iconUrl;
        item.observerStatus = fileDownloadInfo.downloadStatus;
        item.packageName = fileDownloadInfo.packageName;
        item.itemID = fileDownloadInfo.itemID;
        if(fileDownloadInfo.extraInfo!=null) {
            item.nativeId = fileDownloadInfo.extraInfo.nativeId;
        }


        String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, String.valueOf(0), mDownloadingInfo.placementId);
        AppBuilder appBuilder = new AppBuilder()
                .setFromPage(PageConstants.My_Download)
                .setLastPage(PageConstants.My_Download)
                .setValue(value)
                .setParamsByData(item, "");
        TRJumpUtil.switcToAppDetailOptions(mActivity, appBuilder);

        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(fileDownloadInfo.itemID)
                .setButtonType(TRAnalyticsConstant.ICON)
                .setItemValue(fileDownloadInfo.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private void deleteTask(FileDownloadInfo info) {
        if (info == null) {
            return;
        }
        if (VaStaticProxy.isInstantPluginApp(info.packageName)) {
            // 取消下载对应插件，应当拒绝
            VaStaticProxy.disagree(info.packageName);
        }
        //避免用户点击删除按钮之前，该应用已经下载完成了
        if (FileDownloadInfo.STATUS_DOWNLOADED != info.downloadStatus) {
            for (FileManageDownloadAdapterItem item : mDatas) {
                if (item.fileDownloadInfo != null && !TextUtils.isEmpty(item.fileDownloadInfo.packageName) && TextUtils.equals(item.fileDownloadInfo.packageName, info.packageName)) {
                    mDatas.remove(item);
                    break;
                }
            }
        }

        if (info.isGrp && FileDownloadInfo.STATUS_DOWNLOADED == info.downloadStatus) {
            DownloadManager.getInstance().removeDownloadedInfo(info.packageName);
        } else {
            DownloadManager.getInstance().cancelDownload(info.packageName);
        }
        //adapter.onResume();
        adapter.handleInstallingListInfo(true);
        if (info.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR || info.isWifiLostPause) {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_FAILED_DELETE, null);
        } else {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.EVENT_DOWNLOAD_DOWNLOADING_DELETE, null);
        }
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.getDeletePageParamInfo(mPageParamInfo, info.type));

        String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, String.valueOf("0"), mDownloadingInfo.placementId);
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(fileDownloadInfo.itemID)
                .setButtonType(TRAnalyticsConstant.DELETE)
                .setItemValue(fileDownloadInfo.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }
}

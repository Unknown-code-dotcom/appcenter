package com.afmobi.palmplay.cloudfolder.track
 
import android.graphics.Rect
import android.view.View
import androidx.core.view.size
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs

/**
2026-05-27 Created RVExposureHelper to replace RVItemExposureListener.
tracks RecyclerView item exposure accurately using scroll and layout listeners.
*/
class RVExposureHelper(
    private val recyclerView: RecyclerView,
    private val onExposure: (Int) -> Unit
) {

    private val mExposureList: MutableList<Int> = ArrayList()

    private var mScrollState = 0
 
    init {
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (mScrollState != 2 || abs(dy) <= 50) {
                    checkExposure()
                }

            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                mScrollState = newState
            }
        })
    }
 
    fun checkExposure() {
        val length: Int = recyclerView.size
        if (length != 0) {
            var view: View?
            var i = 0

            while (i < length) {
                view = recyclerView.getChildAt(i)
                if (view != null) {
                    val viewVisible = Rect()
                    view.getLocalVisibleRect(viewVisible)
                    if (viewVisible.height() > (view.height / 3) && viewVisible.top < recyclerView.bottom) {
                        checkExposure(view)
                    }
                }
                ++i
            }
        }
    }

    private fun checkExposure(childView: View): Boolean {
        val position: Int = recyclerView.getChildAdapterPosition(childView)
        if (position >= 0 && !mExposureList.contains(position)) {
            mExposureList.add(position)
            onExposure(position)
            return true
        } else {
            return false
        }
    }

    fun resetExposureData() {
        mExposureList.clear()
    }
}

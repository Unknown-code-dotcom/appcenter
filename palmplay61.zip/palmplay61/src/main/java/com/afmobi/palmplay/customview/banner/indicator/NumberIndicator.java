package com.afmobi.palmplay.customview.banner.indicator;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;

import com.transsnet.store.R;

import java.util.Locale;

import androidx.annotation.ColorInt;
import androidx.annotation.Nullable;

/**
 * 数字指示器
 * 底部带背景：上面是数字， 如: 1/5
 */
public class NumberIndicator extends BaseIndicator {
    private static final int DEFAULT_TEXT_SIZE = 12;
    private static final String DEFAULT_SEPARATOR = "/";

    /**
     * 用来记录分割符号。
     */
    private String mSeparator;
    /**
     * 用来记录字体颜色。
     */
    @ColorInt
    private int mTextColor;
    /**
     * 分隔符颜色。
     */
    @ColorInt
    private int mSeparatorTextColor;
    /**
     * 当前页颜色。
     */
    @ColorInt
    private int mCurrentPageTextColor;
    /**
     * 总页数颜色。
     */
    @ColorInt
    private int mTotalPageTextColor;

    /**
     *  文字标识的位置Gravity
     * */
    private int mTextGravity = Gravity.CENTER;

    /**
     * 数字指示器背景 Paint
     * */
    private Paint bgPaint;

    /**
     * 数字指示器 Paint
     * */
    private Paint paint = null;

    public NumberIndicator(Context context) {
        this(context, null);
    }

    public NumberIndicator(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    @SuppressLint("Recycle")
    public NumberIndicator(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray typedArray = attrs == null ? null : context.obtainStyledAttributes(attrs, R.styleable.NumberIndicator);
        final float fontScale = getContext().getResources().getDisplayMetrics().scaledDensity;
        int textSize = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, DEFAULT_TEXT_SIZE, getResources().getDisplayMetrics());
        getPaint().setColor(Color.WHITE);
        mTextColor = mSeparatorTextColor = mCurrentPageTextColor = mTotalPageTextColor = getPaint().getColor();
        String separator = null;
        if (typedArray != null) {
            textSize = typedArray.getDimensionPixelSize(R.styleable.NumberIndicator_android_textSize, textSize);
            separator = typedArray.getString(R.styleable.NumberIndicator_separator);
            mTextColor = typedArray.getColor(R.styleable.NumberIndicator_android_textColor, mTextColor);
            mSeparatorTextColor = typedArray.getColor(R.styleable.NumberIndicator_separatorTextColor, mTextColor);
            mCurrentPageTextColor = typedArray.getColor(R.styleable.NumberIndicator_currentPageTextColor, mTextColor);
            mTotalPageTextColor = typedArray.getColor(R.styleable.NumberIndicator_totalPageTextColor, mTextColor);
            typedArray.recycle();
        }

        if (mSeparatorTextColor == mCurrentPageTextColor && mTotalPageTextColor == mCurrentPageTextColor) {
            //如果这三个颜色相等则将这个颜色赋值给textColor。
            if (mSeparatorTextColor != mTextColor) {
                mTextColor = mSeparatorTextColor;
                getPaint().setColor(mTextColor);
            }
        } else {
            mTextColor = Color.TRANSPARENT;
        }
        mSeparator = TextUtils.isEmpty(separator) ? DEFAULT_SEPARATOR : separator;
        getPaint().setTextSize(textSize);

        bgPaint = new Paint();
        bgPaint.setColor(config.getIndicatorBgColor());
        bgPaint.setAntiAlias(true);
        bgPaint.setStrokeWidth(0);
        bgPaint.setStyle(Paint.Style.FILL);

        paint = getPaint();
        paint.setColor(mTextColor);
    }

    /**
     * 设置分隔符号文本。
     *
     * @param separator 要设置的分割符。
     */
    public void setSeparator(String separator) {
        mSeparator = separator;
        invalidate();
    }

    /**
     * 设置所有文字的颜色。
     *
     * @param textColor 要设置的颜色。
     */
    public void setTextColor(@ColorInt int textColor) {
        if (textColor == mTextColor) {
            return;
        }
        mTextColor = mCurrentPageTextColor = mSeparatorTextColor = mTotalPageTextColor = textColor;
        getPaint().setColor(mTextColor);
        invalidate();
    }

    /**
     * 设置分隔符文字颜色。
     *
     * @param separatorTextColor 要设置的颜色。
     */
    public void setSeparatorTextColor(@ColorInt int separatorTextColor) {
        if (mSeparatorTextColor == separatorTextColor) {
            return;
        }
        if (mTextColor != separatorTextColor) {
            mTextColor = Color.TRANSPARENT;
        }
        mSeparatorTextColor = separatorTextColor;
        invalidate();
    }

    /**
     * 设置当前页文字颜色。
     *
     * @param currentPageTextColor 要设置的颜色。
     */
    public void setCurrentPageTextColor(@ColorInt int currentPageTextColor) {
        if (mCurrentPageTextColor == currentPageTextColor) {
            return;
        }
        if (mTextColor != currentPageTextColor) {
            mTextColor = Color.TRANSPARENT;
        }
        mCurrentPageTextColor = currentPageTextColor;
        invalidate();
    }

    /**
     * 设置总页数文字颜色。
     *
     * @param totalPageTextColor 要设置的颜色。
     */
    public void setTotalPageTextColor(@ColorInt int totalPageTextColor) {
        if (mTotalPageTextColor == totalPageTextColor) {
            return;
        }
        if (mTextColor != totalPageTextColor) {
            mTextColor = Color.TRANSPARENT;
        }
        mTotalPageTextColor = totalPageTextColor;
        invalidate();
    }


    protected int getContentHeight() {
        return (int) (Math.abs(getPaint().ascent() + getPaint().descent()) + 0.5f);
    }

    protected int getContentWidth() {
        return (int) (getPaint().measureText(getContentText()) + 0.5f);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int count = config.getIndicatorSize();
        if (count <= 1) {
            return;
        }

        int width = config.getNormalWidth();
        int height = config.getHeight();
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int count = config.getIndicatorSize();
        if (count <= 1) {
            return;
        }

        int paddingTop = getPaddingTop();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();

        int width = getWidth();
        int measureWidth = getContentWidth();
        int startX;
        int height = getHeight();
        int measureHeight = getContentHeight();
        int baseLine;

        if (haveGravityFlag(Gravity.LEFT)) {
            //默认按照Gravity.START算。
            startX = paddingLeft;
        } else if (haveGravityFlag(Gravity.RIGHT)) {
            startX = width - measureWidth + paddingRight;
        } else if (haveGravityFlag(Gravity.CENTER_HORIZONTAL)) {
            startX = ((width - measureWidth) >>> 1) - paddingRight + paddingLeft;
        } else {
            //默认按照Gravity.START算。
            startX = paddingLeft;
        }

        int paddingBottom = (int) getPaddingBottom();
        if (haveGravityFlag(Gravity.TOP)) {
            //默认按照Gravity.TOP算。
            baseLine = measureHeight + paddingTop;
        } else if (haveGravityFlag(Gravity.BOTTOM)) {
            baseLine = height - paddingBottom;
        } else if (haveGravityFlag(Gravity.CENTER_VERTICAL)) {
            baseLine = (int) (((height + measureHeight) / 2f) - paddingBottom + paddingTop);
        } else {
            //默认按照Gravity.TOP算。
            baseLine = measureHeight + paddingTop;
        }

        RectF rect = new RectF();
        rect.left = 0;
        rect.right = getWidth();
        rect.top = 0;
        rect.bottom = getHeight();
        bgPaint.setColor(config.getIndicatorBgColor());
        int corners = config.getRadius();
        canvas.drawRoundRect(rect, corners, corners, bgPaint);

        //draw text
        if (mTextColor != Color.TRANSPARENT) {
            drawText(canvas, paint, getContentText(), startX, mTextColor, baseLine);
        } else {
            String curPageNum = String.valueOf(getCurPageNum());
            drawText(canvas, paint, curPageNum, startX, mCurrentPageTextColor, baseLine);

            startX += paint.measureText(curPageNum);
            drawText(canvas, paint, mSeparator, startX, mSeparatorTextColor, baseLine);

            startX += paint.measureText(mSeparator);
            drawText(canvas, paint, String.valueOf(config.getIndicatorSize()), startX, mTotalPageTextColor, baseLine);
        }
    }

    private void drawText(Canvas canvas, Paint paint, String text, float startLocation, int textColor, int y) {
        paint.setColor(textColor);
        canvas.drawText(text, startLocation, y, paint);
    }

    /**
     * 获取当前控件中文字。
     *
     * @return 返回当前控件中文字。
     */
    public String getContentText() {
        return String.format(Locale.CHINA, "%d%s%d", getCurPageNum(), mSeparator, config.getIndicatorSize());
    }

    /**
     * 获取当前的页码数字号。
     *
     * @return 返回一个可以展示给用户看的页码数字。
     */
    public int getCurPageNum() {
        return config.getCurrentPosition() + 1;
    }

    protected final boolean haveGravityFlag(int gravity) {
        return haveFlag(mTextGravity, gravity);
    }

    /**
     * 判断某个flag标识容器中是否存在指定的标识。
     *
     * @param flags 标识容器。
     * @param flag  要判断的标识。
     * @return 存在则返回true，否则返回false。
     */
    protected final boolean haveFlag(int flags, int flag) {
        return (flags & flag) == flag;
    }

}

package com.afmobi.palmplay.countrywidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.TextUtils
import androidx.annotation.RequiresApi
import com.afmobi.apk.ThreadHelper
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.manager.HttpRequestTracerManager
import com.afmobi.palmplay.manager.InstalledAppManager
import com.afmobi.palmplay.model.FeatureSinglePageData
import com.afmobi.palmplay.model.GenericResponseInfo
import com.afmobi.palmplay.network.NetworkClient
import com.afmobi.util.Constant
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.AbsRequestListener
import com.google.gson.reflect.TypeToken
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.GsonUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils

object CountrySwitchManager {
    var mIsRequesting = false
    const val TAG = "CountrySwitchManager"
    const val RankID = "CountrySwitchManager_rank_id"
    const val CURRENT_COUNTRY_CODE = "CountrySwitchManager_country_id"
    const val LAST_SUCCESS_COUNTRY_CODE = "Last_CountrySwitchManager_country_id"
    const val LoadCountryStatusMap = "LoadCountrySuccess"
    const val MSG_TIMER = 1
    var timerSize: Int = 0
    var map: MutableMap<String,Boolean>? = null

    init {
        val json = MMKVUtils.getMMKV().getString(LoadCountryStatusMap,"")
        if (!TextUtils.isEmpty(json)) {
            try {
                map = (GsonUtils.getInstance().fromJson(json, object : TypeToken<Map<String, Boolean>>() {}.type))
            } catch (e: Exception) {
                map = mutableMapOf<String, Boolean>()
                e.printStackTrace()
            }
        } else {
            map = mutableMapOf<String, Boolean>()
        }
    }

    fun loadCountrySwitchData(countryCode: String) {
        MMKVUtils.getMMKV().putString(CURRENT_COUNTRY_CODE, countryCode)
        LogUtils.d(TAG, "loadCountrySwitchData:"+countryCode)

        if (mIsRequesting) {
            LogUtils.e(TAG, "ps -- > the request has doing")
            return
        }
        mIsRequesting = true

        //-200代表半屏详情页推荐列表rankid，服务端会根据这个去获取印度还是爱尔兰的真实rankid
        val rankId = ""
        val pageIndex = 0
        val tag = rankId
        NetworkClient.requestFeatureCardPage(
            Constant.SOURCE_SCHEDULE,
            rankId,
            pageIndex,
            20,
            null,
            null,
            tag,
            countryCode,
            object : AbsRequestListener<GenericResponseInfo<FeatureSinglePageData?>?>() {
                override fun onResponse(response: GenericResponseInfo<FeatureSinglePageData?>?) {
                    super.onResponse(response)
                    MMKVUtils.getMMKV().putString(LAST_SUCCESS_COUNTRY_CODE, countryCode)
                    val map = map?.apply {
                        put(countryCode,true)
                    }?: emptyMap<String, Boolean>()
                    MMKVUtils.getMMKV().putString(LoadCountryStatusMap, GsonUtils.getInstance().toJson(map))
                    clearHandlerTask()
                    LogUtils.d(TAG, "response:$response")
                    ThreadHelper.runOnWorkThread {
                        response?.data?.apply {
//                          data as?
                            handleData(this)
                        }

                    }
                    mIsRequesting = false
                }

                override fun onError(anError: ANError) {
                    super.onError(anError)
                    LogUtils.d(TAG, "anError:${anError.toString()}")
                    LogUtils.e(TAG,"map:"+map)
                    val lastSuccessCountryCode = MMKVUtils.getMMKV().getString(LAST_SUCCESS_COUNTRY_CODE,"")
                    LogUtils.e(TAG,"lastSuccessCountryCode:"+lastSuccessCountryCode)
                    val requestSuccess : Boolean = map?.get(countryCode) ?: false
                    mIsRequesting = false
                    HttpRequestTracerManager.getInstance().remove(tag)
                    if (!requestSuccess) {
                        map?.put(countryCode, false)
                        MMKVUtils.getMMKV().putString(LoadCountryStatusMap, GsonUtils.getInstance().toJson(map))
                        handleTask({ loadCountrySwitchData(countryCode) })
                    } else if(!TextUtils.equals(lastSuccessCountryCode, countryCode)) {
                        handleTask({ loadCountrySwitchData(countryCode) })
                    }
                    if (timerSize >= 2) {
                        sendClearBroadcast()
                        clearHandlerTask()
                    }
                }
            },
            false
        )
    }

    fun handleData(featureSinglePageData: FeatureSinglePageData) {
        val rankID = featureSinglePageData.rankId
        val listImg = ArrayList<String>()
        listImg.clear()
        // 优先展示未安装应用，如果不满5个，展示已安装应用
        featureSinglePageData.data?.forEach { value ->
            val result = InstalledAppManager.isInstalledSpecialApp(value.packageName)
            if (!result && listImg.size < 5) {
                listImg.add(value.iconUrl)
            }
            if (listImg.size == 5) {
                return@forEach
            }
        }
        if (listImg.size < 5) {
            featureSinglePageData.data?.forEach { value ->
                val result = InstalledAppManager.isInstalledSpecialApp(value.packageName)
                if (result && listImg.size < 5) {
                    listImg.add(value.iconUrl)
                }
                if (listImg.size == 5) {
                    return@forEach
                }
            }
        }
        LogUtils.d(TAG, "image_urls:" + listImg.toString())
        // 保存图片列表到 SharedPreferences
        MMKVUtils.getMMKV().putStringSet("image_urls", listImg.toSet())
        MMKVUtils.getMMKV().putString(RankID, rankID)
        val refreshIntent =
            Intent(PalmplayApplication.getAppInstance(), CountryWidgetProvider::class.java)
        refreshIntent.setAction(CountryWidgetProvider.ACTION_MY_WIDGET_UPDATE)
        PalmplayApplication.getAppInstance().sendBroadcast(refreshIntent)

    }

    private fun sendClearBroadcast() {
        LogUtils.d(TAG,"sendClearBroadcast")
        val clearIntent =
            Intent(PalmplayApplication.getAppInstance(), CountryWidgetProvider::class.java)
        clearIntent.setAction(CountryWidgetProvider.ACTION_MY_WIDGET_CLEAR)
        PalmplayApplication.getAppInstance().sendBroadcast(clearIntent)
    }

    private var handler: Handler? = null
    fun handleTask(task : () -> Unit) {
        if (handler == null) {
            handler = object : Handler(Looper.getMainLooper()) {
                override fun handleMessage(msg: Message) {
                    super.handleMessage(msg)
                    if (msg.what == MSG_TIMER) {
                        sendEmptyMessageDelayed(MSG_TIMER, 5 * 60 * 1000)
                        task()
                        timerSize++
                        LogUtils.d(TAG,"handleTask:"+ timerSize)
                    }
                }
            }
        }
        if (!handler!!.hasMessages(MSG_TIMER)) {
            LogUtils.e(TAG,"sendEmptyMessageDelayed")
            handler!!.sendEmptyMessageDelayed(MSG_TIMER,0)
        }
    }

    fun clearHandlerTask() {
        handler?.removeCallbacksAndMessages(null)
        timerSize = 0
    }
}

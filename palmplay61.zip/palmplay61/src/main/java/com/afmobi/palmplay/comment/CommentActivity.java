package com.afmobi.palmplay.comment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.customview.RatingBar;
import com.afmobi.palmplay.dialog.FeedbackDialog;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.CommentInfo;
import com.afmobi.palmplay.model.keeptojosn.CurrentCommentResp;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.mvvm.BaseActivity;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.viewmodel.comment.CommentNavigator;
import com.afmobi.palmplay.viewmodel.comment.CommentViewModel;
import com.afmobi.util.Constant;
import com.afmobi.util.DateHelper;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.WindowUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.BR;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ActivityWriteCommentBinding;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CommentActivity extends BaseActivity<ActivityWriteCommentBinding, CommentViewModel> implements CommentNavigator, onAvatarSelectChanged {

    private final static int COMMENT_LEN_MAX = 200;//最高评论长度
    private final static int USERNAME_LEN_MAX = 30;//最高用户名长度
    private final static int COMMENT_LEN_MIN = 10;//最低评论长度
    private final static int USERNAME_LEN_MIN = 1;//最低用户名长度
    private final static int RATING_STAR_MIN = 1;//最低评星

    private CommentViewModel mCommentViewModel;
    private ActivityWriteCommentBinding mBinding;

    private String fromPage;
    private String mFrom;
    private String mItemId;
    private String mAppName;
    private String mPackageName;
    private int mVersionCode;
    private CommentInfo mCommentInfo;

    private UserAvatarAdapter mAdapter;
    private PageParamInfo mPageParamInfo = new PageParamInfo();
    private boolean isSuccess = false;
    private String mValues = null;
    private FeedbackDialog mFeedbackDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBinding = getViewDataBinding();

        if(getIntent() != null) {
            fromPage = getIntent().getStringExtra(PageConstants.PAGE_KEY_LASTPAGE);
            mFrom = getIntent().getStringExtra(TRAnalyticsConstant.VALUE);
            mItemId = getIntent().getStringExtra(Constant.KEY_ITEMID);
            mAppName = getIntent().getStringExtra(Constant.KEY_APPNAME);
            mPackageName = getIntent().getStringExtra(Constant.KEY_PACKAGE_NAME);
            mVersionCode = getIntent().getIntExtra(Constant.KEY_VERSIONCODE, 0);
            mCommentInfo = getIntent().getParcelableExtra(Constant.KEY_CURRENT_COMMENT);
            mValues = TRStringUtil.generateString(fromPage, TRAnalyticsConstant.MODULE_WRITE_REVIEW, "", "");
        }

        if(TextUtils.isEmpty(mItemId) && TextUtils.isEmpty(mPackageName)) {
            finish();
            return;
        }

        init();

        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(mValues)
                .setFrom(mFrom).setItemId(mItemId);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    @Override
    public int getBindingVariable() {
        return BR.commentViewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_write_comment;
    }

    @Override
    public CommentViewModel getViewModel() {
        mCommentViewModel = new ViewModelProvider(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(CommentViewModel.class);
        mCommentViewModel.setNavigator(this);
        getLifecycle().addObserver(mCommentViewModel);
        return mCommentViewModel;
    }


    public void init() {

        mCommentViewModel.getSubmitCodeLiveData().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer integer) {
                onSubmitChanged(integer);
            }
        });


        //ratingbar
        mBinding.commentRatingbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public boolean onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if(fromUser) {
                    onComplianceMonitoring();
                }

                return true;
            }
        });


        //comment
        mBinding.etInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(COMMENT_LEN_MAX)});
        mBinding.etInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String realStr = s.toString().trim();

                onCommentReminderLenMonitor(realStr);

                onComplianceMonitoring();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //username
        mBinding.etName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(USERNAME_LEN_MAX)});
        mBinding.etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String realStr = s.toString().trim();
                onNameReminderLenMonitor(realStr);

                onComplianceMonitoring();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setOrientation(RecyclerView.HORIZONTAL);
        mBinding.idAvatarlist.setLayoutManager(lm);
        mAdapter = new UserAvatarAdapter();
        mAdapter.setOnAvatarSelectChanged(this);
        mBinding.idAvatarlist.setAdapter(mAdapter);

        //init current comment
        onCurrentCommentChanged(mCommentInfo);

        WindowUtil.showSoftKeyboard(mBinding.etInput);
    }


    private void onSubmitChanged(int code) {
        if(code == 0) {
            isSuccess = true;
            if(!isFinishing() && !isDestroyed()) {
                if(mFeedbackDialog == null) {
                    mFeedbackDialog = new FeedbackDialog(this);
                }
                mFeedbackDialog.setOnFeedbackChangedListener(new FeedbackDialog.onFeedbackChangedListener() {
                    @Override
                    public void onFeedbackChanged() {
                        toCommentList();
                    }
                }).showCommentTip();
            }
        }else if(code == -111) {
            ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), getResources().getString(R.string.tip_operation_frequent));
        }else {
            ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), R.string.tip_submmit_failed);
        }
    }

    private void toCommentList() {
        Intent intent = new Intent();
        CommentInfo commentInfo = getNewCommentInfo();
        mCommentInfo = commentInfo;
        CurrentCommentResp commentRespInfo = new CurrentCommentResp();
        commentRespInfo.data = commentInfo;
        intent.putExtra(Constant.KEY_CURRENT_COMMENT, commentInfo);
        intent.putExtra("success", isSuccess);
        PageConstants.putPageParamInfo(intent, mPageParamInfo);
        setResult(RESULT_OK, intent);
        finish();
    }

    private CommentInfo getNewCommentInfo() {
        CommentInfo commentInfo = new CommentInfo();
        commentInfo.username = mBinding.etName.getText().toString().trim();
        commentInfo.userAvatar = mAdapter.getUserAvatar();
        commentInfo.itemID = mItemId;
        commentInfo.model = PhoneDeviceInfo.getModel();
        commentInfo.star = (int) mBinding.commentRatingbar.getRating();
        commentInfo.content = mBinding.etInput.getText().toString().trim();
        commentInfo.ddate = DateHelper.getNowDate_yyyy_MM_dd_HH_mm_ss_SSS(System.currentTimeMillis());
        if (mCommentInfo != null && mCommentInfo.cpContent != null) {
            commentInfo.cpContent = mCommentInfo.cpContent;
        }

        return commentInfo;
    }

    private void onCommentReminderLenMonitor(String realStr) {

        int strlen = 0;
        if(!TextUtils.isEmpty(realStr)) {
            strlen = realStr.length();
        }

        int sy = Math.min(COMMENT_LEN_MAX, strlen);
        String txt = sy + "/" + COMMENT_LEN_MAX;
        mBinding.tvInputLen.setText(txt);
    }
    private void onNameReminderLenMonitor(String realStr) {
        int strlen = 0;
        if(!TextUtils.isEmpty(realStr)) {
            strlen = realStr.length();
        }

        int sy = Math.min(USERNAME_LEN_MAX, strlen);
        String txt = sy + "/" + USERNAME_LEN_MAX;
        mBinding.tvNameLen.setText(txt);
    }


    private void onCurrentCommentChanged(CommentInfo commentInfo) {

        if(commentInfo != null) {
            mBinding.setVariable(BR.commentInfo, commentInfo);
            mBinding.executePendingBindings();

            if(mAdapter != null) {
                mAdapter.setSelectPosition(commentInfo.userAvatar);
                 }

            try {
                int len = mBinding.etInput.getText() != null ? mBinding.etInput.getText().length() : 0;
                mBinding.etInput.setSelection(len);
            }catch (Exception e){
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
    }


    /**
     * 检查必填项是否合规，动态更新SEND按钮状态
     *
     * */
    private void onComplianceMonitoring() {

        boolean isValide = true;

        float rating = mBinding.commentRatingbar.getRating();
        if(rating < RATING_STAR_MIN || rating > mBinding.commentRatingbar.getNumStars()) {
            isValide = false;
        }

        String comment = mBinding.etInput.getText().toString().trim();
        if(TextUtils.isEmpty(comment) || comment.length() < COMMENT_LEN_MIN) {
            isValide = false;
        }

        String username = mBinding.etName.getText().toString().trim();
        if(TextUtils.isEmpty(username) || username.length() < USERNAME_LEN_MIN) {
            isValide = false;
        }

        //avatar
        boolean isSelectedAvatar = (mAdapter != null) ? mAdapter.isAvatarSelected() : false;
        if(!isSelectedAvatar) {
            isValide = false;
        }

        mBinding.tvSend.setSelected(isValide);
        mBinding.tvSend.setClickable(isValide);
    }


    @Override
    public void onAvatarChanged() {
        onComplianceMonitoring();
    }

    @Override
    public void finish() {
        super.finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_title_back:
                onBackClick();
                break;

            case R.id.tv_send:
                onCommentSubmit();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        onBackClick();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        WindowUtil.hideSoftKeyboard(mBinding.etInput);
        if(mFeedbackDialog != null) {
            mFeedbackDialog.onDestroy();
            mFeedbackDialog = null;
        }
    }

    private void onBackClick() {
        finish();
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(mValues)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId(mItemId)
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue(mPackageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private void onCommentSubmit() {
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
            return;
        }

        FileDownloadInfo downloadedInfo = PsVaManager.getInstance().getVaInstallResult(mPackageName);

        if(!InstalledAppManager.getInstance().isInstalled(mPackageName) && downloadedInfo == null) {
            ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_install_for_feedback);
            return;
        }

        String content = mBinding.etInput.getText().toString();
        int star = (int) mBinding.commentRatingbar.getRating();
        String userAvatar = mAdapter.getUserAvatar();
        String userName = mBinding.etName.getText().toString();

        if(star < RATING_STAR_MIN || star > mBinding.commentRatingbar.getNumStars()) {
            return;
        }
        if(TextUtils.isEmpty(userName) || userName.length() < USERNAME_LEN_MIN) {
            return;
        }
        if(!mAdapter.isAvatarSelected()) {
            return;
        }

        WindowUtil.hideSoftKeyboard(mBinding.etInput);

        String itemid = isFromPluto() ? null : mItemId;

        mCommentViewModel.submitComment(mAppName, itemid, mPackageName, content, star, userAvatar, userName);

        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(mValues)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId(mItemId)
                .setButtonType(TRAnalyticsConstant.SEND)
                .setItemValue(mPackageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private boolean isFromPluto() {
        boolean isPluto = false;
        //isPluto
        FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadingInfobyPackageName(mPackageName);
        if(fileDownloadInfo == null) {
            fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(mPackageName);
        }
        if(fileDownloadInfo != null && fileDownloadInfo.extraInfo != null) {
            isPluto = fileDownloadInfo.extraInfo.isPlutoOffer;
        }
        return isPluto;
    }

    @Override
    public String getValue() {
        return mValues;
    }
}

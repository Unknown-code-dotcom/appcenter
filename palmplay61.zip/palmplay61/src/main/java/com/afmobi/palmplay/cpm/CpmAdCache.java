package com.afmobi.palmplay.cpm;

import android.view.ViewGroup;

import com.afmobi.palmplay.configs.v6_3.FeaturedType;

import java.util.HashMap;
import java.util.Map;

/**
 * CPM广告View的缓存
 * Created by xiangfei.wei on 2018/8/7.
 */

public class CpmAdCache {
    private static volatile CpmAdCache cpmAdCache = new CpmAdCache();

    private HashMap<String, CpmAdsView> homeFeatureViews;
    private HashMap<String, CpmAdsView> gameFeatureViews;
    private HashMap<String, CpmAdsView> appFeatureViews;
    /**
     * 数据来自于缓存还是网络；true为缓存。
     */
    private boolean fromCacheOrNet;

    private CpmAdCache() {
    }

    public static CpmAdCache getInstance() {
        return cpmAdCache;
    }

    public CpmAdCache setDataSource(boolean fromCacheOrNet) {
        this.fromCacheOrNet = fromCacheOrNet;
        return this;
    }

    public boolean getDataSource() {
        return fromCacheOrNet;
    }

    public void addCpmAdView(String featureType, String url, CpmAdsView cpmAdsView) {
        /*if (fromCacheOrNet) {
            return;
        }*/
        if (FeaturedType.HOME.equalsIgnoreCase(featureType)) {
            if (homeFeatureViews == null) {
                homeFeatureViews = new HashMap<>(8);
            }
            homeFeatureViews.put(url, cpmAdsView);
        } else if (FeaturedType.GAME.equalsIgnoreCase(featureType)) {
            if (gameFeatureViews == null) {
                gameFeatureViews = new HashMap<>(8);
            }
            gameFeatureViews.put(url, cpmAdsView);
        } else if (FeaturedType.APP.equalsIgnoreCase(featureType)) {
            if (appFeatureViews == null) {
                appFeatureViews = new HashMap<>(8);
            }
            appFeatureViews.put(url, cpmAdsView);
        }
    }

    public CpmAdsView getCpmAdView(String featureType, String url) {
        if (FeaturedType.HOME.equalsIgnoreCase(featureType)) {
            if (homeFeatureViews == null) {
                return null;
            }
            return homeFeatureViews.get(url);
        } else if (FeaturedType.GAME.equalsIgnoreCase(featureType)) {
            if (gameFeatureViews == null) {
                return null;
            }
            return gameFeatureViews.get(url);
        } else if (FeaturedType.APP.equalsIgnoreCase(featureType)) {
            if (appFeatureViews == null) {
                return null;
            }
            return appFeatureViews.get(url);
        }
        return null;
    }

    public void destroyView(String featureType) {
        //LogUtils.e("CPMAdCache", "-----------------destroyView-------------featureType = " + featureType);
        CpmAdsView view;
        if (FeaturedType.HOME.equalsIgnoreCase(featureType) && homeFeatureViews != null) {
            for (Map.Entry<String, CpmAdsView> entry : homeFeatureViews.entrySet()) {
                view = entry.getValue();
                view.destroy();
                if (view.getParent() != null) {
                    ((ViewGroup) view.getParent()).removeView(view);
                }
            }
            homeFeatureViews.clear();
            homeFeatureViews = null;
        } else if (FeaturedType.GAME.equalsIgnoreCase(featureType) && gameFeatureViews != null) {
            for (Map.Entry<String, CpmAdsView> entry : gameFeatureViews.entrySet()) {
                view = entry.getValue();
                view.destroy();
                if (view.getParent() != null) {
                    ((ViewGroup) view.getParent()).removeView(view);
                }
            }
            gameFeatureViews.clear();
            gameFeatureViews = null;
        } else if (FeaturedType.APP.equalsIgnoreCase(featureType) && appFeatureViews != null) {
            for (Map.Entry<String, CpmAdsView> entry : appFeatureViews.entrySet()) {
                view = entry.getValue();
                view.destroy();
                if (view.getParent() != null) {
                    ((ViewGroup) view.getParent()).removeView(view);
                }
            }
            appFeatureViews.clear();
            appFeatureViews = null;
        }
    }

}

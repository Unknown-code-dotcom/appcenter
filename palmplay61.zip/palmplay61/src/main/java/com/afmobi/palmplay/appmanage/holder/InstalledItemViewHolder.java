package com.afmobi.palmplay.appmanage.holder;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.appmanage.FileManageDownloadAdapterItem;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.UriExtKt;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutManageInstalledItemBinding;

import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 安装完成模块的ViewHolder
 */
public class InstalledItemViewHolder extends RecyclerView.ViewHolder {

    private PageParamInfo mPageParamInfo;
    private LayoutManageInstalledItemBinding binding;
    private FileManageDownloadAdapterItem itemData;
    private Activity mActivity;

    protected String mScreenPageName;
    protected String mFeatureName;
    public String mFrom;//新型打点的from值

    public InstalledItemViewHolder(ViewDataBinding binding) {
        super(binding.getRoot());
        this.binding = (LayoutManageInstalledItemBinding) binding;

        this.binding.setHolder(this);

    }

    public InstalledItemViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        mPageParamInfo = pageParamInfo;
        return this;
    }
    public InstalledItemViewHolder setActivity(Activity curActivity) {
        mActivity = curActivity;
        return this;
    }
    public void bind(FileManageDownloadAdapterItem info, final int position) {
        if (binding == null) {
            return;
        }
        if (info != null) {
            itemData = info;
            binding.layoutContent.setVisibility(View.VISIBLE);
            binding.setInfo(info.fileDownloadInfo);
            int defaultIcon = R.drawable.layer_list_app_default_01_bg;
            if (info.fileDownloadInfo.extraInfo != null && !TextUtils.isEmpty(info.fileDownloadInfo.extraInfo.category2)
                    && info.fileDownloadInfo.extraInfo.category2.equals("local")) {
                //本地app
                binding.layoutContent.setTag(position);
                if (UriExtKt.isHttpOrHttps(info.fileDownloadInfo.iconUrl)) {
                    //重新下载的游戏
                    GlideUtils.setImageUrl(binding.ivIcon, info.fileDownloadInfo.iconUrl, defaultIcon, defaultIcon);
                } else {
                    PsVaManager.getInstance().showLocalAppIcon(mActivity, info.fileDownloadInfo.name, binding.ivIcon, info.fileDownloadInfo.iconUrl, position, (int) (binding.layoutContent.getTag()));
                }
            } else {
                GlideUtils.setImageUrl(binding.ivIcon, info.fileDownloadInfo.iconUrl, defaultIcon, defaultIcon);
            }
        } else {
            binding.layoutContent.setVisibility(View.GONE);
        }
    }


    public void onItemLayoutClick() {
        if (itemData == null) {
            return;
        }
        DownloadDecorator.launchApp(itemData.fileDownloadInfo.packageName, itemData.fileDownloadInfo.name);

        String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", itemData.placementId);
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(itemData.fileDownloadInfo.itemID)
                .setButtonType(TRAnalyticsConstant.OPEN)
                .setItemValue(itemData.fileDownloadInfo.packageName)
                .setExtraValue(DeeplinkManager.getDeeplink(itemData.fileDownloadInfo.packageName));
        TRAnalysticsUtil.trackClick(builder);
    }


    public InstalledItemViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public InstalledItemViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    public InstalledItemViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }
}

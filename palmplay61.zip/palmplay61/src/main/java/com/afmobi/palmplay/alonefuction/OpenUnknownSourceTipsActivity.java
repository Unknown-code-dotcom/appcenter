package com.afmobi.palmplay.alonefuction;

import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;

import com.afmobi.palmplay.base.BaseFragmentActivity;
import com.afmobi.util.PadUtils;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.transsion.palmstorecore.util.ScreenOrientationManager;
import com.transsnet.store.R;

/**
 * 未知来源提醒页面
 * 20180403.
 */
public class OpenUnknownSourceTipsActivity extends BaseFragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_unknown_source_tips2);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            ScreenOrientationManager.INSTANCE.apply(this);
        }

        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.DownloadTips);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

    }

    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadActivityAsDialog(this);
    }

    public boolean onTouchEvent(MotionEvent event) {
        onBackPressed();
        return true;
    }

    @Override
    public String getValue() {
        return "";
    }
}

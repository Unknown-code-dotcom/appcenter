package com.afmobi.palmplay.category;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.configs.ImageConfig;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.main.adapter.v6_3.CommonSoftRecyclerAdapter;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.CommonInfo;
import com.afmobi.palmplay.model.TagItemList;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.appbar.AppBarLayout;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import xyz.doikki.videoplayer.util.PlayerUtils;

/**
 * 同一标签下的应用列表页；
 */
public class TagAppListActivity extends BaseEventFragmentActivity implements View.OnClickListener, AppBarLayout.OnOffsetChangedListener, OnViewLocationInScreen {
    public static final String TAG_ID = "tagId";
    public static final String REQUEST_TAG_APP_LIST = "request_tag_app_list";

    private View view_blur_mask;
    private TextView tv_title, tv_download_count;
    private ImageView iv_back, iv_download, iv_search;
    private AppBarLayout appBarLayout;
    private Toolbar mToolbar;
    private View layout_download, layout_empty_view_root;
    private View layout_header_describe;
    private TextView describe_title, describe_detail;
    private RelativeLayout layoutDetailTitle;

    private UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();
    private UINetworkErrorUtil mUINetworkErrorUtil = UINetworkErrorUtil.create();

    private boolean isRequesting = false;
    /**
     * 分页请求的页面下标
     */
    private int currentPageIndex = 0;

    private int currentOffset;

    // 头布局的高度
    private int headerHeight;

    private XRecyclerView mXRecyclerView;
    private boolean isOnRefreshing;
    private int screenWidth;

    private boolean isFirstActivity = true;

    private CommonSoftRecyclerAdapter mCommonSoftRecyclerAdapter;
    private String mTagId;
    private List<CommonInfo> mAppList;
    private int randomAction;
    private List<CommonInfo> mOrgAppList;
    private String value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tag_app_list);
        screenWidth = DisplayUtil.getScreenWidthPx(this) + DisplayUtil.getInsetsMargin(this);
        mTagId = getIntent().getStringExtra(TAG_ID);
        mPageParamInfo.setLastPage(getIntent().getStringExtra(PageParamInfo.class.getSimpleName()));
        mPageParamInfo.setCurPage(PageConstants.Tag + mTagId);
        randomAction = new Random().nextInt();
        initViews();
        setEmptyViewCenter();
        init();
    }

    /**
     * 空态页居中显示
     */
    private void setEmptyViewCenter() {
        int height = DisplayUtil.getScreenHeight(this);
        int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.empty_view_height);
        int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
        int halfMarginTop = (height - emptyLayoutHeight) / 2;
        int statusBarHeight = (int) PlayerUtils.getStatusBarHeight(this);
        int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight;
        if (finalMarginTop <= 0) {
            finalMarginTop = 0;
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) layout_empty_view_root.getLayoutParams();
        params.topMargin = finalMarginTop;
        layout_empty_view_root.setLayoutParams(params);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isRequesting) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }
        setUpdatedAppCount();
    }

    private void setSystemBarColor(int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(color);
        }
    }

    private void initViews() {
        setSystemBarColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
        headerHeight = ImageConfig.getImageHeight(screenWidth, ImageConfig.FEATURES_BANNER_IMG_WIDTH_HEIGHT_PERCENT);

        //Title Layout
        view_blur_mask = findViewById(R.id.view_blur_mask);
        view_blur_mask.setBackgroundColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
        iv_back = findViewById(R.id.layot_detail_back);
        tv_title = findViewById(R.id.layot_detail_title);
        layout_download = findViewById(R.id.layot_detail_download);
        iv_download = findViewById(R.id.iv_download);
        tv_download_count = findViewById(R.id.tv_downloading_count);
        layout_download.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        iv_search = findViewById(R.id.layout_title_right_search);
        iv_search.setOnClickListener(this);

        layout_header_describe = findViewById(R.id.layout_header_describe);
        describe_title = findViewById(R.id.describe_title);
        describe_detail = findViewById(R.id.describe_detail);
        // title  end  --------

        appBarLayout = findViewById(R.id.main_appbar);
        appBarLayout.addOnOffsetChangedListener(this);
        mToolbar = findViewById(R.id.main_toolbar);

        layoutDetailTitle = findViewById(R.id.layout_detail_title);

        layout_empty_view_root = findViewById(R.id.layout_empty_view_root);
        TextView tv_content = layout_empty_view_root.findViewById(R.id.tv_content);
        tv_content.setText(R.string.no_related_resource);

        String from = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE,"","","");
        CoordinatorLayout rootView = findViewById(R.id.cl_view);
        mUILoadingGifUtil.inflate(this, rootView);
        mUINetworkErrorUtil.inflate(this, rootView, true)
                .setFrom(from)
                .setVisibility(View.GONE)
                .setNetworkConfigureVisibility(View.GONE)
                .setUINetworkErrorOnClickListener(new UINetworkErrorUtil.UINetworkErrorOnClickListener() {

                    @Override
                    public void onUINetworkErrorClick(View v) {
                        if (v == null)
                            return;
                        if (v.getId() == R.id.tv_setting) {
                            SysUtils.openSystemMobileNetworkSettings(TagAppListActivity.this, TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
                        } else if (v.getId() == R.id.tv_retry) {
                            if (CommonUtils.isInstantAvailable()) {
                                TRJumpUtil.jumpInstantTab(TagAppListActivity.this);
                            } else {
                                mUINetworkErrorUtil.setVisibility(View.GONE);
                                mUILoadingGifUtil.setVisibility(View.VISIBLE);
                                request();
                            }
                        }
                    }
                });

        mXRecyclerView = (XRecyclerView) findViewById(R.id.xrecyclerview);
        TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mXRecyclerView.setLayoutManager(linearLayoutManager);
        mXRecyclerView.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
        mXRecyclerView.setLoadingListener(mXRecyclerViewLoadingListener);
        mXRecyclerView.setPullRefreshEnabled(false);

        mXRecyclerView.isHeaderRefreshLayoutLimitHeight(true);

        addNoMore(mXRecyclerView, linearLayoutManager, appBarLayout);

        if (!isRequesting)
            mXRecyclerView.setEmptyView(layout_empty_view_root);

        mCommonSoftRecyclerAdapter = new CommonSoftRecyclerAdapter(this, mXRecyclerView, mPageParamInfo.getCurPage(), mPageParamInfo);
//        mCommonSoftRecyclerAdapter.setItemBgResId(android.R.color.transparent, false);
        mXRecyclerView.setAdapter(mCommonSoftRecyclerAdapter);
        mCommonSoftRecyclerAdapter.setOnViewLocationInScreen(this);
        mCommonSoftRecyclerAdapter.onCreateView();
        mCommonSoftRecyclerAdapter.setIMessenger(new IMessenger() {

            @Override
            public void onMessenger(Object... objects) {
                if (isDestroyed() || isFinishing()) {
                    return;
                }
                setUpdatedAppCount();
            }
        });
        mCommonSoftRecyclerAdapter.setScreenPageName(TRAnalyticsConstant.PAGE_TAG);
        mCommonSoftRecyclerAdapter.setFrom(TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE,"","",""));
        value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_TAG,"","","");

        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(value)
                .setFrom(from);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private void init() {
        request();
        iv_back.setImageResource(R.drawable.selector_title_img_back);
        iv_download.setImageResource(R.drawable.ic_detail_dl_count);
        iv_search.setImageResource(R.drawable.ic_detail_search_ic);
        TRStatusBarUtil.setStatusBarTextColor(getWindow(), true);

        mUILoadingGifUtil.setVisibility(isRequesting ? View.VISIBLE : View.GONE);
    }

    private XRecyclerView.LoadingListener mXRecyclerViewLoadingListener = new XRecyclerView.LoadingListener() {
        @Override
        public void onRefresh() {
            if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
                if (mXRecyclerView != null) {
                    mXRecyclerView.refreshComplete();
                }
                return;
            }
            isOnRefreshing = true;
            currentPageIndex = 0;
            request();
        }

        @Override
        public void onLoadMore() {
            currentPageIndex += 1;
            request();
        }
    };

    private void request() {
        isRequesting = true;
        NetworkClient.requestTagAppList(REQUEST_TAG_APP_LIST + randomAction, mTagId, currentPageIndex, mPageParamInfo);

        if (mXRecyclerView != null) {
            mXRecyclerView.setEmptyView(null);
        }
        if (layout_empty_view_root != null) {
            layout_empty_view_root.setVisibility(View.GONE);
        }
    }

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        super.onEventMainThread(mEventMainThreadEntity);
        if (mEventMainThreadEntity.getAction().equals(REQUEST_TAG_APP_LIST + randomAction)) {
            isRequesting = false;
            if (isOnRefreshing) {
                mXRecyclerView.refreshComplete();
            } else {
                mXRecyclerView.loadMoreComplete();
            }
            isOnRefreshing = false;
            mUILoadingGifUtil.setVisibility(View.GONE);

            if (mEventMainThreadEntity.isSuccess) {
                TagItemList data = (TagItemList) mEventMainThreadEntity.get(TagItemList.class.getSimpleName());

                if (data != null && data.itemList != null && data.itemList.size() > 0) {
                    if (data.pageIndex + 1 == data.pageSum) {
                        mXRecyclerView.setNoMore(true);
                    } else {
                        mXRecyclerView.loadMoreComplete();
                    }
                    refreshData(data);
                    setHeaderView(data);
                }

                mXRecyclerView.setEmptyView(layout_empty_view_root);
            } else {
                mUINetworkErrorUtil.setVisibility(View.VISIBLE);
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_REFRESH_TAB_RED_POINT)) { //刷新角标
            setUpdatedAppCount();
        }
    }

    private void refreshData(TagItemList data) {
        if (mAppList == null) {
            mAppList = new ArrayList<>();
        }

        if (mOrgAppList == null) {
            mOrgAppList = new ArrayList<>();
        }

        //AdsUtils.adsCheckOrderInsert(mAppList, mOrgAppList, data.itemList, mAdsLoadListProxy);
//        mAppList.clear();
        mAppList.addAll(data.itemList);

        if (mCommonSoftRecyclerAdapter != null) {
            mCommonSoftRecyclerAdapter.setData(mAppList);
        }
    }

    public void setHeaderView(TagItemList data) {
        try {

            if(!isFirstActivity){
                return;
            }
            setSystemBarColor(0x33000000);
            isFirstActivity = false;

            iv_back.setImageResource(R.drawable.selector_title_img_back_white);
            iv_download.setImageResource(R.drawable.ic_detail_dl_count_white);
            iv_search.setImageResource(R.drawable.ic_detail_search_white);
            TRStatusBarUtil.setStatusBarTextColor(getWindow(), false);
            layoutDetailTitle.setBackgroundColor(getResources().getColor(android.R.color.transparent));
            tv_title.setText(data.name);
            mToolbar.setBackgroundResource(R.drawable.bg_title_shade);

            ImageView iv_avatar_cover = findViewById(R.id.iv_avatar_cover);
            RelativeLayout.LayoutParams iv_avatar_cover_params = (RelativeLayout.LayoutParams) iv_avatar_cover.getLayoutParams();
            iv_avatar_cover_params.width = screenWidth;
            iv_avatar_cover_params.height = headerHeight;
            iv_avatar_cover.requestLayout();

            /*编译版本改成8.0的时候，appbarlayout高度的问题*/
            appBarLayout.getLayoutParams().height = headerHeight +  DisplayUtil.dip2px(this,3);

            String bannerUrl = data.bannerUrl;
            describe_title.setText(data.name);
            describe_detail.setText(data.info);
            layout_header_describe.setVisibility(View.VISIBLE);
            if (TextUtils.isEmpty(bannerUrl)) {
                iv_avatar_cover.setImageResource(R.drawable.img_header_banner_applist);
            } else {
                layout_header_describe.setVisibility(View.INVISIBLE);
                iv_avatar_cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                int corner = DisplayUtil.dip2px(this, 12f);
                GlideUtils.setImageUrlByOption(iv_avatar_cover, bannerUrl, corner, GlideUtils.newCommonRequestOptions()
                    , new RequestListener<Drawable>() {
                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                layout_header_describe.setVisibility(View.INVISIBLE);
                                return true;
                            }
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                return false;
                            }
                        }
                        , R.drawable.img_header_banner_applist, R.drawable.img_header_banner_applist);
            }
        } catch (Exception e) {
            LogUtils.e(e);
        }
    }


    @Override
    public void onClick(View v) {
        if (v == null)
            return;
        switch (v.getId()) {
            case R.id.layout_title_back:
            case R.id.layot_detail_back:
                finish();
                backButtonTrack();
                break;
            case R.id.layot_detail_download:
                TRJumpUtil.into(this, false, mPageParamInfo,value);
                break;
            case R.id.layout_title_right_search:
                TRJumpUtil.switchToSearchActivity(this, TabType.SOFT, "", false, "", false, "",
                        mPageParamInfo, value, TRAnalyticsConstant.BUTTON_SEARCH_IMG);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        backButtonTrack();
    }

    private void backButtonTrack() {
        String from = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE,"","","");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(from)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        int abOffset = Math.abs(verticalOffset);
        float alpha = abOffset / (float) appBarLayout.getTotalScrollRange();//796

        /*
         * monkey空指针异常
         * java.lang.NullPointerException: Attempt to invoke virtual method 'void com.jcodecraeer.xrecyclerview.XRecyclerView.scrollToPosition(int)' on a null object reference
         */
        if(mXRecyclerView == null){
            return;
        }
        if (verticalOffset == 0) {
            mXRecyclerView.scrollToPosition(0);
        }
        if (abOffset > currentOffset) {//上拉
            setAlphaByScroll(abOffset, alpha);
        } else if (abOffset == currentOffset) {//静止
//            setAlphaByScroll(abOffset, alpha);
//            if(alpha == 0.0){
//                iv_back.setBackgroundResource(R.drawable.selector_title_img_back);
//                iv_download.setBackgroundResource(R.drawable.selector_btn_download_2);
//            }
        } else {//下拉
            setAlphaByScroll(abOffset, alpha);
        }
        currentOffset = abOffset;
    }

    protected void setAlphaByScroll(int offset, float alpha) {
        // LogUtils.e("setAlphaByScroll==>" + alpha);
        view_blur_mask.setAlpha(alpha);
        if (alpha > 0.4) {
            setSystemBarColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
            iv_back.setImageResource(R.drawable.selector_title_img_back);
            iv_download.setImageResource(R.drawable.ic_detail_dl_count);
            iv_search.setImageResource(R.drawable.ic_detail_search_ic);
            TRStatusBarUtil.setStatusBarTextColor(getWindow(), true);
        } else {
            setSystemBarColor(0x33000000);
            iv_back.setImageResource(R.drawable.selector_title_img_back_white);
            iv_download.setImageResource(R.drawable.ic_detail_dl_count_white);
            iv_search.setImageResource(R.drawable.ic_detail_search_white);
            TRStatusBarUtil.setStatusBarTextColor(getWindow(), false);
        }
        if (alpha == 1.0) {
            tv_title.setVisibility(View.VISIBLE);
        } else {
            tv_title.setVisibility(View.GONE);
        }
    }

    /****************************
     * for animation start
     *********************************/
    @Override
    public Object onPreparedCallback(Object obj) {
        return obj;
    }

    @Override
    public Object getObject(Object obj) {
        return layout_download;
    }

    @Override
    public int[] onEndTranslateAnimationLocationOnScreen(Object obj) {
        int[] endTranslateAnimationLocationOnScreen = new int[2];
        if (layout_download != null && layout_download.getVisibility() != View.GONE) {
            layout_download.getLocationOnScreen(endTranslateAnimationLocationOnScreen);
            int viewWidth = layout_download.getWidth();
            if (viewWidth > 0)
                endTranslateAnimationLocationOnScreen[0] = endTranslateAnimationLocationOnScreen[0] + viewWidth / 4;// 3;
        }
        return endTranslateAnimationLocationOnScreen;
    }

    @Override
    public Object onAnimationEndCallback(Object obj) {
        return obj;
    }

    /**************************** for animation end *********************************/

    protected void setUpdatedAppCount() {
        TRHomeUtil.refreshAppCount(tv_download_count, null);
    }

    /*----------------20180724 add by liuzhi 6.8.1 begin----------------*/
    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mCommonSoftRecyclerAdapter!=null)
            mCommonSoftRecyclerAdapter.onDestroy();

        if(mXRecyclerView != null){
            mXRecyclerView.loadMoreComplete();
            mXRecyclerView.refreshComplete();
            mXRecyclerView = null;
        }
        mXRecyclerViewLoadingListener = null;
    }
    /*----------------20180724 add by liuzhi 6.8.1 end----------------*/

    @Override
    public String getValue() {
        return value;
    }
}

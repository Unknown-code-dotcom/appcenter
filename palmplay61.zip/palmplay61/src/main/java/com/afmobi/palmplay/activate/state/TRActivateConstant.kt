package com.afmobi.palmplay.activate.state

class TRActivateConstant {
    enum class ShowState {
        ACTIVATE_NEED_SHOW,
        ACTIVATE_SHOWED,
        ACTIVATE_BLOCKED
    }
}

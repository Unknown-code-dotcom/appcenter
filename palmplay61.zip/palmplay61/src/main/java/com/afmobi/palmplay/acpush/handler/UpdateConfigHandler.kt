package com.afmobi.palmplay.acpush.handler

import android.os.Bundle
import com.afmobi.palmplay.acpush.repo.AcPushConfigRepo
import com.transsion.palmstorecore.log.LogUtils

/**
 * 处理 PM 通过 ContentProvider.call("update_config") 主动推下来的配置。
 *
 * 入参 extras:
 *   - config_json: String
 *     JSON: { updateCfg: { interval, fastInterval, ac_update_enabled: 1/0, high_grade_list: "[]", expId, varId } }
 *
 * 返回 Bundle:
 *   - success: Boolean
 *   - error:   String?
 *
 * 本方法**不**受 A/B 闸门约束（spec § 四：用户从 false 切 true 必须靠这个方法）。
 */
object UpdateConfigHandler {

    fun handle(extras: Bundle?): Bundle {
        val result = Bundle()
        if (extras == null) {
            LogUtils.d(LogUtils.TAG_AC_PUSH, "pm update_config received, extras=null")
            result.putBoolean("success", false)
            result.putString("error", "extras is null")
            return result
        }
        val configJson = extras.getString("config_json")
        LogUtils.d(
            LogUtils.TAG_AC_PUSH,
            "pm update_config received, configJson=$configJson"
        )
        val applied = AcPushConfigRepo.applyAll(configJson)
        result.putBoolean("success", applied)
        if (!applied) {
            result.putString("error", "no fields applied (config_json blank/malformed/empty)")
        }

        return result
    }
}

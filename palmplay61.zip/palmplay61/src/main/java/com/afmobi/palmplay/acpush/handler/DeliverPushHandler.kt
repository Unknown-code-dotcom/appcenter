package com.afmobi.palmplay.acpush.handler

import android.content.Context
import android.os.Bundle
import com.afmobi.palmplay.acpush.ipc.PushHubClient
import com.afmobi.palmplay.acpush.model.PushRecordItem
import com.afmobi.palmplay.acpush.notify.AcPushNotifyHelper
import com.afmobi.palmplay.acpush.repo.AcPushConfigRepo
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.transsion.palmstorecore.log.LogUtils

/**
 * 处理 PM 通过 ContentProvider.call("deliver_push") 主动推下来的通知。
 *
 * 入参 extras:
 *   - message_type: String (AC_UPDATE / PUSH)
 *   - records_json: String (List<PushRecordItem> JSON)
 *
 * 返回 Bundle:
 *   - success: Boolean
 *   - error:   String?
 *
 * A/B 关闭时直接返回 disabled，不渲染、不解析。
 */
object DeliverPushHandler {

    private val TAG = LogUtils.TAG_AC_PUSH

    private val gson = Gson()

    fun handle(context: Context, extras: Bundle?): Bundle {
        val result = Bundle()
        if (!AcPushConfigRepo.isEnabled()) {
            result.putBoolean("success", false)
            result.putString("error", "disabled")
            return result
        }
        if (extras == null) {
            result.putBoolean("success", false)
            result.putString("error", "extras is null")
            return result
        }
        val messageType = extras.getString("message_type") ?: PushHubClient.MESSAGE_TYPE_AC_UPDATE
        val recordsJson = extras.getString("records_json").orEmpty()
        LogUtils.d(TAG, "records_json recived:" + recordsJson)
        if (recordsJson.isEmpty()) {
            result.putBoolean("success", false)
            result.putString("error", "records_json is empty")
            return result
        }
        val records: List<PushRecordItem> = try {
            val type = object : TypeToken<List<PushRecordItem>>() {}.type
            gson.fromJson(recordsJson, type)
        } catch (e: Exception) {
            LogUtils.e(TAG, "records_json parse failed", e)
            result.putBoolean("success", false)
            result.putString("error", "records_json parse failed: ${e.message}")
            return result
        }
        return try {
            AcPushNotifyHelper.renderBatch(context, messageType, records)
            result.putBoolean("success", true)
            result
        } catch (e: Exception) {
            LogUtils.e(TAG, "renderBatch failed", e)
            result.putBoolean("success", false)
            result.putString("error", "render failed: ${e.message}")
            result
        }
    }
}

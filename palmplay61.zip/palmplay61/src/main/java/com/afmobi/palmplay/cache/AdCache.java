package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.ProcessLifecycleChecker;
import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.admgr.bussiness_sdk.BussinessSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.alonefuction.SplashAdActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.OpenAdData;
import com.afmobi.palmplay.model.ew.HisavanaConfigInfo;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.tailstop.ReCall;
import com.afmobi.util.Constant;
import com.afmobi.util.TimeUtil;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.cloud.hisavana.ac.sdk.api.adx.TSplashView;
import com.cloud.hisavana.ac.sdk.api.listener.AdListener;
import com.cloud.hisavana.ac.sdk.common.constant.Constants;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.apm.TRErrorAnalysticsUtil;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.callback.TRImageDownloadListener;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.androidnetworking.common.ANConstants.PARSE_ERROR;

public class AdCache implements LocalCache{

    private static final String TAG = AdCache.class.getSimpleName();
    private static final String AD_CACHE_URI = "OPEN_AD_CACHE";
    public static final String SPLASH_FROM_STR = "splashAct";
    private static final byte[] lock = new byte[0];
    private static volatile AdCache mAdCache;

    private long mRequestPreloadTime = 0L;
    private static final long PRELOAD_REQ_GAP = 5000L; // 间隔5S

    public static final long AD_REQUEST_INTERVAL = 4 * 60 * 60 * 1000L; //4h
    public static final long AD_UPDATE_INTERVAL = 24 * 60 * 60 * 1000L; //24h

    public final static long ADS_SHOW_INTERVAL = 2 * 60 * 60 * 1000L;       //2h for ads show time interval
    private static final String ADS_LAST_SHOW_TIME = "ads_last_show_time";
    public static final String ADS_CFG_LAST_LOAD_TIME = "ads_cfg_last_load_time"; //上次请求时间

    //开屏广告
    public static final String SPLASH_ADS_CFG_LOAD_TIME = "splash_ads_cfg_load_time"; //请求时间
    public static final String SPLASH_ADS_CFG_RELOAD_TIME = "splash_ads_cfg_reload_time"; //reload时间
    public static final String SPLASH_ADS_CFG_ADS_IS_EMPTY = "splash_ads_cfg_ads_is_empty"; //数据为空

    private static final String ADS_CFG_LAST = "ads_cfg_last";  //升级前(旧版本)缓存广告信息
    private static final String ADS_TOTAL_SHOW_COUNT = "ads_total_show_count"; //当天广告已展示总次数，次日重新计数

    private OpenAdData mOpenAdData;
    private boolean isOnCacheing = false;
    private int mTotalShowCount;//当天的累积展示次数
    private static final String ADS_STATUS_MAP = "ads_status_map"; //存储广告展示状态信息
    private Map<String, Integer> mAdStatusMap = new ConcurrentHashMap<>();
    public static final String BUSSINESS_SDK = "5";  // 商业化SDK
    public static final int BUSSINESS_SDK_RESOURCE_READY = 1;
    public static final int SELF_RESOURCE_READY = 2;
    public static final int RESOURCE_NOT_READY = 0;
    public static final int HISAVANA_SDK_READY = 3;
    public static String FROM_SPLASH = SPLASH_FROM_STR + Constant.FROM_DETAIL_SEPARATOR + Constant.FROM_DETAIL;

    private String mSplashAdPositionId;
    private boolean mIsHasCache = true;

    public AdCache() {
        loadFromCache();
        initTotalShowCount();
        initAdStatusMap();
    }


    public static AdCache getInstance() {
        if (mAdCache == null) {
            synchronized (lock) {
                if (mAdCache == null) {
                    mAdCache = new AdCache();
                }
            }
        }
        return mAdCache;
    }

    /**
     * 初始化广告状态表
     * */
    private void initAdStatusMap() {

        mAdStatusMap.clear();

        ConcurrentHashMap<String, Integer> map = null;
        if(SPManager.containsKey(ADS_STATUS_MAP)) {
            String txt = SPManager.getString(ADS_STATUS_MAP, "");
            try {
                Type type = new TypeToken<ConcurrentHashMap<String, Integer>>(){}.getType();
                map = new Gson().fromJson(txt, type);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        if (map != null && !map.isEmpty()) {
            mAdStatusMap.putAll(map);
        }else {

            if(isAdEmpty()) {
                return;
            }

            List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
            for (OwnAdBean item:ownAdBeans){
                if(item != null && !TextUtils.isEmpty(item.getId())) {
                    mAdStatusMap.put(item.getId(), 0);
                }
            }
        }
    }

    /**
     * 更新广告状态表
     * */
    private void updateAdStatusMap() {

        mAdStatusMap.clear();

        if(!isAdEmpty()) {
            List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
            for (OwnAdBean item:ownAdBeans){
                if(item != null && !TextUtils.isEmpty(item.getId())) {
                    mAdStatusMap.put(item.getId(), 0);
                }
            }
        }

        saveAdStatus();
    }

    /**
     * 根据广告id获取对应状态值
     * */
    private int getAdStatusFromMap(String id) {
        if(mAdStatusMap == null || mAdStatusMap.isEmpty()) {
            return 0;
        }

        if(TextUtils.isEmpty(id)) {
            return 0;
        }

        Integer status = mAdStatusMap.get(id);

        return ((status != null) ? (status) : 0);
    }

    /**
     * 展示后更新对应状态值
     * */
    private void updateAdStatus(OwnAdBean adBean) {

        if(adBean == null || TextUtils.isEmpty(adBean.getId())) {
            return;
        }

        if(mAdStatusMap == null) {
            mAdStatusMap = new ConcurrentHashMap<>();
        }

        Integer val = mAdStatusMap.get(adBean.getId());
        if (val == null) {
            val = 0;
        }

        val++;
        if (!TextUtils.isEmpty(adBean.getId())) {
            mAdStatusMap.put(adBean.getId(), val);
        }

        saveAdStatus();
    }

    private void saveAdStatus() {
        try {
            if(mAdStatusMap != null) {
                JSONObject js = new JSONObject(mAdStatusMap);
                String txt = js.toString();
                SPManager.putString(ADS_STATUS_MAP, txt);
            }
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }


    /***
     * 保存上次请求广告配置时间
     */
    public void setLastConfigLoadTime() {
        SPManager.putLong(ADS_CFG_LAST_LOAD_TIME, System.currentTimeMillis());
    }



    /***
     * 获取上次请求广告配置时间
     */
    public long getLastRequestTime() {
        return SPManager.getLong(ADS_CFG_LAST_LOAD_TIME, 0);
    }

    public void setAdsIsEmpty(boolean isEmpty) {
        SPManager.putBoolean(SPLASH_ADS_CFG_ADS_IS_EMPTY,isEmpty);
    }

    public void setConfigLoadTime(long loadTime) {
        SPManager.putLong(SPLASH_ADS_CFG_LOAD_TIME,loadTime);
    }

    public void setConfigReLoadTime(long reloadTime) {
        SPManager.putLong(SPLASH_ADS_CFG_RELOAD_TIME,reloadTime);
    }

    /***
     * 当天展示次数递增
     */
    public void increaseShowCount() {
        mTotalShowCount++;
        SPManager.putInt(ADS_TOTAL_SHOW_COUNT, mTotalShowCount);
    }

    /***
     * 获取当天展示次数
     */
    public int getTotalShowCount() {
        return SPManager.getInt(ADS_TOTAL_SHOW_COUNT, 0);
    }

    /***
     * 重置当天展示次数
     */
    public void resetTotalShowCount() {
        mTotalShowCount = 0;
        SPManager.putInt(ADS_TOTAL_SHOW_COUNT, mTotalShowCount);
    }


    /**
     * 当天展示次数是否达到上限
     * */
    public boolean isUpperLimit() {
        return (mOpenAdData == null || mTotalShowCount >= mOpenAdData.getShowFrequency());
    }

    /**
     * 判断请求广告配置时间是否过期, 间隔时间以服务器有下发时间为准；若没有下发时本地无物料时默认4h，本地有物料时默认24h。
     * */
    public boolean isAdConfigLoadExpired() {
        long currTime = System.currentTimeMillis();
        long lastTime = getLastRequestTime();
        long interval = 0;

        if(isAdEmpty()) { //本地无物料

            if(mOpenAdData != null && mOpenAdData.getAdConfig() != null) {
                interval = mOpenAdData.getAdConfig().getLoadTimeInterval();
            }

            if(interval <= 0) {
                interval = AD_REQUEST_INTERVAL;
            }

        }else { //本地有物料
            if(mOpenAdData != null && mOpenAdData.getAdConfig() != null) {
                interval = mOpenAdData.getAdConfig().getReloadTimeInterval();
            }
            if(interval <= 0) {
                interval = AD_UPDATE_INTERVAL;
            }
        }

        if(Math.abs(currTime - lastTime) >= interval) {
            return true;
        }

        return false;
    }

    private void initTotalShowCount() {
        if(isDateChanged()) {
            resetTotalShowCount();
        }else {
            mTotalShowCount = getTotalShowCount();
        }
    }


    /**
     *  解析开屏广告信息，处理预加载缓存等
     *  若当天再次请求配置则已展示次数不清0，若次日更新则已展示次数清0
     *  ps:下发列表已排序，本地无需再次排序
     * */
    public void initOpenAdCaches(OpenAdData adData, boolean isFromNetwork) {
        boolean isFromAdSdk = false; // 数据来源外部SDK
        if(adData != null && !adData.isAdListEmpty()) {
            //TODO:过滤无效的广告，预加载广告
            AdCache.getInstance().setAdsIsEmpty(false);
            if (adData.adConfigDTO != null) {
                AdCache.getInstance().setConfigLoadTime(adData.adConfigDTO.getLoadTimeInterval());
                AdCache.getInstance().setConfigReLoadTime(adData.adConfigDTO.getReloadTimeInterval());
            }
            try {
                Iterator<OwnAdBean> it = adData.getAdList().iterator();
                while (it.hasNext()) {
                    OwnAdBean adBean = it.next();
                    if (adBean == null
                            || TRStringUtil.isBlank(adBean.getJumpType()) || adBean.getJumpType().equalsIgnoreCase(TRActivateConstant.GAME_HALL)) {//过滤调游戏大厅
                        it.remove();
                        continue;
                    }
                    //todo 删除商业化sdk 20220701
    //                if(TextUtils.equals(adBean.getReportSource(),BUSSINESS_SDK)) {
    //                    adBean.reportSource = BUSSINESS_SDK + "_bak";  // 埋点时用到的信息
    //                    isFromAdSdk = true;
    //                }
                    if(isAdValidate(adBean) && !TRBitmapManager.isImageCachedWithSmallCache(adBean.getAdIconUrl())) {
                        preDownloadImge(adBean);
                    }

                    adBean.setFromPage(SPLASH_FROM_STR);
                }
            }catch (Exception e){
                TRErrorAnalysticsUtil.trackCommonError(TRErrorAnalysticsUtil.PS_net_data, "AdCache----getAdList: " + e.getMessage(),
                        "initOpenAdCaches", "catch");
            }

        } else {
            AdCache.getInstance().setAdsIsEmpty(true);
        }

        //TODO:判断是否日期改变，当天更新广告信息不需要更新以展示的总次数
        if(isDateChanged()) {
            resetTotalShowCount();
        }

        mOpenAdData = adData;

        if(isFromAdSdk) {
            //todo 删除商业化sdk 20220701
//            LogUtils.e(BussinessSdkManager.TAG,"response include sdk info ready preload");
//            mOpenAdData.adConfigDTO.setBussinessSdk(BUSSINESS_SDK);
//            BussinessSdkManager.getInstance().sdkPreload();
//            LogUtils.e(BussinessSdkManager.TAG,"response include sdk info preload end");
        } else {
            mOpenAdData.adConfigDTO.setBussinessSdk("");
        }

        updateAdStatusMap();

        if(isFromNetwork) {
            saveToCache();
        }

        DetailCacheManager.getInstance().addItemByObject(adData);
    }


    /**
     * 判断广告列表是否为空
     * */
    public boolean isAdEmpty() {

        return (mOpenAdData == null || mOpenAdData.isAdListEmpty());
    }


    /**
     * 获取列表中符合条件的权重最大的广告
     * */
    public OwnAdBean getLargestWeightAd() {

        if (isAdEmpty()) {
            return null;
        }

        int smallestStatus = -1;
        OwnAdBean findAd = null;

        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean item:ownAdBeans){
            if(item != null && !TextUtils.isEmpty(item.getAdIconUrl()) && isAdValidate(item)
                    && TRBitmapManager.isImageCachedWithSmallCache(item.getAdIconUrl())) {

                int val = getAdStatusFromMap(item.getId());
                if(smallestStatus == -1 || val < smallestStatus) {
                    smallestStatus = val;
                    findAd = item;
                }
            }
        }

        return findAd;
    }


    /**
     * 预加载广告
     * */
    public void onPreLoadAd() {
        if(isAdEmpty()) {
            return;
        }

        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean adBean:ownAdBeans){
            if(isAdValidate(adBean) && !TextUtils.isEmpty(adBean.getAdIconUrl()) && !TRBitmapManager.isImageCachedWithSmallCache(adBean.getAdIconUrl())) {
                preDownloadImge(adBean);
            }
        }
    }

    /**
     * 预加载EW广告
     * */
    public void onPreLoadHisavanaAd() {
        final String splashHisavanaSdkCodeId;
        List<HisavanaConfigInfo> sceneCodeList = HisavanaSdkManager.getInstance().getHisavanaConfigByKey(SceneCode.R_SP);
        if (sceneCodeList == null || sceneCodeList.size() <= 0) {
            LogUtils.e(HisavanaSdkManager.TAG,"No configuration information");
            return;
        } else {
            splashHisavanaSdkCodeId = sceneCodeList.get(0).getAdPositionId();

        }

        long gap = System.currentTimeMillis() - mRequestPreloadTime;
        if(gap < PRELOAD_REQ_GAP) {
            LogUtils.e(TAG,"preload gap is not timeout");
            return;
        }
        mRequestPreloadTime = System.currentTimeMillis();

        final String sceneCode = SceneCode.R_SP;
        TSplashView tSplashView = new TSplashView(PalmplayApplication.getPalmplayApplicationInstance(), splashHisavanaSdkCodeId);
        tSplashView.setSceneCode(sceneCode);
        tSplashView.setListener(new AdListener() {
            @Override
            public void onSplashAdLoaded(List<String> packageNames) {
                super.onSplashAdLoaded(packageNames);
                int reuslt = HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS;
                if(packageNames!=null && packageNames.size()>0) {
                    TRAnalysticsUtil.trackEwRspRecord(splashHisavanaSdkCodeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_RSP_SUCCESS, packageNames.size(), 0, false);
                    for(String pkg:packageNames) {
                        TRAnalysticsUtil.trackEWSDKResponse(splashHisavanaSdkCodeId, sceneCode, reuslt, pkg);
                    }
                } else {
                    reuslt = HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_NO_DATA;
                    TRAnalysticsUtil.trackEWSDKResponse(splashHisavanaSdkCodeId, sceneCode, reuslt, null);
                }
            }

            @Override
            public void onError(TaErrorCode adError) {
                super.onError(adError);
                int errorCode = -1;
                if(adError!=null) {
                    errorCode = adError.getErrorCode();
                }
                TRAnalysticsUtil.trackEWSdkErrorRsp(splashHisavanaSdkCodeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_ERROR, null,errorCode, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0, false);
            }

            @Override
            public void onTimeOut() {
                super.onTimeOut();
                TRAnalysticsUtil.trackEWSDKResponse(splashHisavanaSdkCodeId, sceneCode, HisavanaSdkManager.TRACK_LOAD_ADS_TIME_OUT, null);
            }
        });
        tSplashView.setUseCache(true);
        tSplashView.loadAd();
        TRAnalysticsUtil.trackEWSDKLoad(splashHisavanaSdkCodeId, sceneCode, 1, ProcessLifecycleChecker.isAppInBackground());
    }

    /**
     * 预加载图片
     * */
    private void preDownloadImge(final OwnAdBean adBean) {
        if (adBean == null) {
            return;
        }

        String imageUrl = adBean.getAdIconUrl();
        if (TRStringUtil.isBlank(imageUrl)) {
            return;
        }
        TRBitmapManager.preLoadImageWithSmallCache(imageUrl, null, new TRImageDownloadListener() {
            @Override
            public void onSuccess(File file) {
                LogUtils.i(LogUtils.TAG_AD, "AD Image preload finish, id:" + adBean.getId());
            }

            @Override
            public void onError(Object dataSource) {
            }
        });
    }

    /**
     * 通过广告id获取广告信息对象
     * @param id 广告id
     * */
    public OwnAdBean getOwnAdBean(String id) {
        if(TextUtils.isEmpty(id)) {
            return null;
        }

        if(isAdEmpty()) {
            return null;
        }

        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean adBean:ownAdBeans){
            if (adBean != null && TextUtils.equals(adBean.getId(), id)) {
                return adBean;
            }
        }

        return null;
    }


    public List<String> getAdIdList() {
        if(isAdEmpty()) {
            return null;
        }

        List<String> list = new ArrayList<>();
        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean adBean:ownAdBeans){
            list.add(adBean.getId());
        }

        return list;
    }

    /**
     * todo 这是为了解决 Caused by java.lang.ClassCastException: com.google.gson.internal.LinkedTreeMap cannot be cast to com.afmobi.palmplay.model.keeptojosn.OwnAdBean
     *        at com.afmobi.palmplay.cache.AdCache.getAdIdList(Proguard:5)
     *        at com.afmobi.palmplay.activate.TRSplashActivateExecutor.loadData(Proguard:4)
     *        at com.afmobi.palmplay.activate.TRManager.loadDataDirectly(Proguard:11)
     *        at com.afmobi.util.NetStateReceiver.onReceive(Proguard:21)
     * 由于实在是不知道这是怎么出现的，先try catch了，网上说的混淆问题，不太可能，后台数据结构问题，也不太可能，都已经走到这里了，只能出此下策了
     * @param openAdData
     * @return
     */
    public static List<OwnAdBean> getAdList(OpenAdData openAdData){
        List<OwnAdBean> list = new ArrayList<>();
        try {
            Iterator<OwnAdBean> it = openAdData.getAdList().iterator();
            while (it.hasNext()) {
                OwnAdBean adBean = it.next();
                list.add(adBean);
            }
        } catch (Exception e){
            TRErrorAnalysticsUtil.trackCommonError(TRErrorAnalysticsUtil.PS_net_data, "AdCache----getAdList: " + e.getMessage(),
                    "mOpenAdData.getAdList()", "catch");
        }

        return list;
    }


    /**
     * 广告是否有效（列表中只要有一个广告有效即为有效）
     * */
    public boolean isAdValidate() {
        if(isAdEmpty() || !mOpenAdData.isAdOpened()) {
            return false;
        }

        if(isDateChanged()) {
            resetTotalShowCount();
        }

        if(isUpperLimit()) {
            return false;
        }

        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean adBean:ownAdBeans){
            if(isAdValidate(adBean)) {
                return true;
            }
        }

        return false;
    }


    /**
     * 根据传入的广告信息判断是否有效广告
     * */
    public boolean isAdValidate(OwnAdBean mOwnAdBean) {
        try {

            if(mOwnAdBean != null) {

                long startTime = 0;
                long endTime = 0;
                long currTime = System.currentTimeMillis();
                //时间转成时间戳
                if(!TextUtils.isEmpty(mOwnAdBean.getStartDate())) {
                    startTime = TimeUtil.getMillisByDate(mOwnAdBean.getStartDate());
                }
                if(!TextUtils.isEmpty(mOwnAdBean.getEndDate())) {
                    endTime = TimeUtil.getMillisByDate(mOwnAdBean.getEndDate());
                }

                if((currTime >= startTime) && (currTime <= endTime)) {
                    return true;
                }
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return false;
    }


    /**
     * 日期是否改变？
     * */
    public boolean isDateChanged() {
        long lastInterval = getLastShowTime();
        long currInterval = System.currentTimeMillis();

        String lastYMD = TimeUtil.getDateToStringYMD(lastInterval);
        String currYMD = TimeUtil.getDateToStringYMD(currInterval);

        return (!TextUtils.equals(lastYMD, currYMD));
    }


    /**
     * 广告展示之后更新广告信息，同步更新缓存
     * @param adBean 广告广告信息
     * */
    public void updateAdAfterShow(OwnAdBean adBean) {

        AdCache.getInstance().setLastShowTime();

        increaseShowCount();

        updateAdStatus(adBean);

        if (adBean != null) {
            int freqency = mOpenAdData != null ? mOpenAdData.getShowFrequency() : 0;
            LogUtils.d(LogUtils.TAG_AD, "Ad showed id:" + adBean.getId() + ",showed count:" + mTotalShowCount + ", Frequency:" + freqency);
        }
    }

    /**
     * 广告状态是否打开： 1代表广告是开的，0代表是关的（只要有一个广告是开的即为打开）
     * */
    public boolean isAdOpen() {
        //TODO:adSwitchFlag字段和 adStatus字段意思相同，直接看外面的adSwitchFlag字段即可

        return (mOpenAdData != null && mOpenAdData.isAdOpened());
    }

    public long getLastShowTime() {
        return SPManager.getLong(ADS_LAST_SHOW_TIME, 0);
    }

    public void setLastShowTime() {
        SPManager.putLong(ADS_LAST_SHOW_TIME, System.currentTimeMillis());
    }

    public boolean isOverTwoHours() {
        long lastTime = SPManager.getLong(ADS_LAST_SHOW_TIME, 0);
        long currTime = System.currentTimeMillis();

        long ad_show_interval = ADS_SHOW_INTERVAL;
        if (mOpenAdData != null) {
            ad_show_interval = mOpenAdData.getScreenOpeningIntervalTime();
        }

        if(Math.abs(currTime - lastTime) >= ad_show_interval) {
            return true;
        }

        return false;
    }


    /**
     * 是否需要展示广告（只要有一个有效广告即需要展示）
     * */
    public boolean isNeedShowAd() {

        if(isAdEmpty()){
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE,TRAnalyticsConstant.SP_AD_EXPOSE_NO_ADS);
            return false;
        }
        if(!mOpenAdData.isAdOpened()) {
            return false;
        }

        if(isDateChanged()) {
            resetTotalShowCount();
        }

        if(isUpperLimit()) {
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE,TRAnalyticsConstant.SP_AD_EXPOSE_OVER_MAX);
            return false;
        }

        if(!isOverTwoHours()) {
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE,TRAnalyticsConstant.SP_AD_EXPOSE_INTERVAL);
            return false;
        }

        boolean isCacheFail = false;
        boolean isAdValidate = false;
        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean adBean:ownAdBeans){
            if(!isAdValidate(adBean)){
                isAdValidate = true;
                continue;
            }
            isAdValidate = false;
            if(TRBitmapManager.isImageCachedWithSmallCache(adBean.getAdIconUrl())) {
                return true;
            } else {
                isCacheFail = true;
            }
        }

        if(isAdValidate){
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE,TRAnalyticsConstant.SP_AD_EXPOSE_ADS_EXPIRED);
        }
        if(isCacheFail){
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE,TRAnalyticsConstant.SP_AD_EXPOSE_CACHE_FAIL);
        }

        return false;
    }


    /**
     * 是否需要预加载（只要有一个有效广告未缓存完成即需要预加载）
     * */
    public boolean isNeedPreLoad() {
        if(isAdEmpty() || !mOpenAdData.isAdOpened()) {
            return false;
        }

        if(isDateChanged()) {
            resetTotalShowCount();
        }
        if(isUpperLimit()) {
            return false;
        }

        List<OwnAdBean> ownAdBeans = AdCache.getAdList(mOpenAdData);
        for (OwnAdBean adBean:ownAdBeans){
            if(isAdValidate(adBean) && !TRBitmapManager.isImageCachedWithSmallCache(adBean.getAdIconUrl())) {
                return true;
            }
        }

        return false;
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
        String fileName = getFileName();

        if (fileName != null) {
            FilePathManager.jsonToFile(jsonBuffer, fileName);
        }

        isOnCacheing = false;
    }

    @Override
    public void loadFromCache(Object... objects) {
        String fileName = getFileName();


        JsonElement jsonObject = FilePathManager.fileToJson(fileName);
        OpenAdData adData = null;
        try {
            Gson gson = new Gson();
            Type type = new TypeToken<OpenAdData>(){}.getType();
            adData = gson.fromJson(jsonObject, type);
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        mOpenAdData = adData;


        //处理版本升级前缓存的广告
        if(SPManager.containsKey(ADS_CFG_LAST)) {
            //删除旧版本的缓存
            SPManager.remove(ADS_CFG_LAST);
        }
    }

    @Override
    public String getFileName(Object... objects) {
        return AD_CACHE_URI;
    }

    public void removeCacheAndFile() {
        mOpenAdData = null;
        mSplashAdPositionId = null;
        FilePathManager.removeFile(AD_CACHE_URI);
        HisavanaSdkManager.getInstance().clearEwConfigByKey(SceneCode.R_SP);

    }
    /**
     *  保存到缓存文件
     * */
    public void saveToCache() {

        //update cache
        if(isOnCacheing) {
            return;
        }
        isOnCacheing = true;
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_LOW).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {

                String txt = null;
                if(mOpenAdData != null) {
                    Gson gson = new Gson();
                    JsonElement je = gson.toJsonTree(mOpenAdData, OpenAdData.class);
                    txt = (je != null) ? je.toString() : "";
                }else {
                    //广告列表为空
                    txt = "";
                }

                saveToCache(txt);

                LogUtils.i(LogUtils.TAG_AD, "Open Ad data:" + txt);
            }
        }));

    }


    public static void loadAdsConfig() {

        if(!AdCache.getInstance().isAdConfigLoadExpired()) {
            return;
        }

        List<String> list = AdCache.getInstance().getAdIdList();
        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_REQUEST, TRAnalyticsConstant.SP_AD_REQUEST_NORMAL);

        AdCache.getInstance().onPreLoadHisavanaAd();

        NetworkClient.requestSplashAdConfig(list, new AbsRequestListener<GenericResponseInfo<OpenAdData>>() {
            @Override
            public void onResponse(GenericResponseInfo<OpenAdData> response) {
                try {
                    // 返回成功后则设置时间，防止后台数据异常时导致客户端大量请求api接口
                    AdCache.getInstance().setLastConfigLoadTime();

                    if(response == null) {
                        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_NO_ADS);
                        return;
                    }

                    OpenAdData adData = response.getData();
                    if (adData != null && !adData.isAdListEmpty()) {
                        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_ADS);
                    } else {
                        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_NO_ADS);
                    }
                    AdCache.getInstance().initOpenAdCaches(adData, true);

                }catch (Exception e){
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                if (PARSE_ERROR.equals(anError.getErrorDetail())){
                    TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_PARSE_FAIL);
                } else {
                    TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_RESPONSE,TRAnalyticsConstant.SP_AD_RESPONSE_FAIL);
                }
                AdCache.getInstance().setLastConfigLoadTime();
            }
        }, AdCache.class.toString());
    }

    public boolean isCanShowBussinessAd() {
        boolean result = false;
        //todo 删除商业化sdk 20220701
//        if(mOpenAdData!=null && mOpenAdData.adConfigDTO!=null && mOpenAdData.adConfigDTO.isBussinessSdk()) {
//            result = true;
//        }
        return result;
    }

    public boolean isCanShowHisavanaAd() {
        //TODO:判断是否日期改变，当天更新广告信息不需要更新以展示的总次数
        if(isDateChanged()) {
            resetTotalShowCount();
        }

        //每天限制展示次数
        if (isUpperLimit()) {
            return false;
        }

        //开屏时间间隔2小时
        if(!isOverTwoHours()) {
            LogUtils.e(HisavanaSdkManager.TAG,"It has been displayed within one hour");
            TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE,TRAnalyticsConstant.SP_AD_EXPOSE_INTERVAL);
            return false;
        }

        boolean result = true;
        List<HisavanaConfigInfo> sceneCodeList = HisavanaSdkManager.getInstance().getHisavanaConfigByKey(SceneCode.R_SP);
        if (sceneCodeList == null || sceneCodeList.size() <= 0) {
            LogUtils.e(HisavanaSdkManager.TAG,"No configuration information");
            result = false;
        } else {
            mSplashAdPositionId = sceneCodeList.get(0).getAdPositionId();
            TSplashView tSplashView = new TSplashView(PalmplayApplication.getPalmplayApplicationInstance(), mSplashAdPositionId);
            result = tSplashView.hasCache(Constants.ASKSCENE.ENTER_SCENE_ASK);
            int type = result ? HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_HAS_CACHE : HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_NO_CACHE;
            TRAnalysticsUtil.trackEWSDKResponse(mSplashAdPositionId, SceneCode.R_SP, type, null);
        }
        return result;
    }

    /**
     * 获取开屏广告位id
     * */
    public String getSplashHisavanaSdkCodeId() {
        return mSplashAdPositionId;
    }

    /**
     * ew开屏广告缓存池是否有广告
     * */
    public boolean isHasCache() {
        return mIsHasCache;
    }

    public String getBussinessCfgId() {
        String cfgId = "";
        if(mOpenAdData!=null && mOpenAdData.adList!=null && mOpenAdData.adList.size()>0) {
            OwnAdBean ownAdBean = mOpenAdData.adList.get(0);
            if(ownAdBean!=null) {
                return ownAdBean.cfgId;
            }
        }
        return cfgId;
    }

    /**
     * 广告资源是否ready
     * @return
     */
    public int isReadyOfSplashAdResource() {
        int result = -1;
        if(isCanShowBussinessAd()) {
            //todo 商业化sdk开启并且判断是否超过指定间隔
            if(!BussinessSdkManager.getInstance().isOverTwoHours()) {
                return result;
            }
            if(BussinessSdkManager.getInstance().isReadyOfBussinessResource()) {
                //todo 待判断缓存数据是否OK
                result = BUSSINESS_SDK_RESOURCE_READY;
            } else if(isNeedShowAd()) {
                result = SELF_RESOURCE_READY;
            }

        } else if (isCanShowHisavanaAd()) {
            result = HISAVANA_SDK_READY;
        } else if(isNeedShowAd()) {
            result = SELF_RESOURCE_READY;
        }
        return result;
    }

    /**
     * 更新尾量数据
     * @param reCallList
     */
    public void updateAdInfoListForTailStop(List<ReCall> reCallList) {
        if(reCallList == null || reCallList.size() == 0) {
            return;
        }
        if(AtyManager.getAtyManager().isExistsActivity(SplashAdActivity.class)) {
            return;
        }
        if(mOpenAdData == null || mOpenAdData.adList == null || mOpenAdData.adList.size() == 0) {
            return;
        }
        Iterator<ReCall> iterator = reCallList.listIterator();
        boolean findItemInfo = false;
        while (iterator!=null && iterator.hasNext()) {
            ReCall reCall = iterator.next();
            if(reCall == null || TextUtils.isEmpty(reCall.source) || !TextUtils.equals(reCall.source,FROM_SPLASH)) {
                continue;
            }
            if(mOpenAdData == null || mOpenAdData.adList == null || mOpenAdData.adList.size() == 0) {
                return;
            }
            Iterator<OwnAdBean> ownAdBeanIterator = mOpenAdData.adList.listIterator();
            // 查找包体并做删除
            while(ownAdBeanIterator!=null && ownAdBeanIterator.hasNext()) {
                OwnAdBean ownAdBean = ownAdBeanIterator.next();
                if(ownAdBean!=null && TextUtils.equals(ownAdBean.getPck(),reCall.packageName)) {
                    ownAdBeanIterator.remove();
                    iterator.remove();
                    findItemInfo = true;
                    break;
                }
            }
        }
        if(findItemInfo) {
            // 更新磁盘缓存
            saveToCache();
        }
    }

}

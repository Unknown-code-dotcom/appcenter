package com.afmobi.palmplay.activate;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.activate.state.TRPopUpScene;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.main.NotificationToggleActivity;
import com.transsion.palmstorecore.log.LogUtils;

import static com.afmobi.palmplay.main.NotificationToggleActivity.setToggleChangeTime;

/***
 * created by yongli.li
 * 装机必备的执行者
 */
public class TRNotificationToggleExecutor extends TRBaseExecutor{
    public static volatile boolean STATUS = false;//代表本身是否正在显示

    @Override
    public boolean isCanShow(String fromType) {
        return TRDialogUtil.NotificationToggleCanShow();
    }

    @Override
    public boolean show(String fromType) {
        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            return false;
        }
        if (TRDiskSpaceLimitExecutor.STATUS) {
            LogUtils.d(NotificationToggleActivity.TAG,"NotificationToggle will not show,because disk space limit activity is showing");
            return false;
        }

        // 如果在instant页面，需要关闭无网
        TRNewManager.Companion.getInstance().dismiss(TRPopUpScene.POP_UP_TIP_NETWORK);

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent = new Intent(PalmplayApplication.getAppInstance(), NotificationToggleActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    PalmplayApplication.getAppInstance().startActivity(intent);
                    setToggleChangeTime();
                    LogUtils.d(NotificationToggleActivity.TAG,"start notification toggle activity");
                } catch (Exception e) {
                }
            }
        });

        return true;
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }
}

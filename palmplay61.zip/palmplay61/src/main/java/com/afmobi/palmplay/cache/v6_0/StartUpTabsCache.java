// TOP SECRET
package com.afmobi.palmplay.cache.v6_0;

import static com.transsion.palmstorecore.log.LogUtils.TAG_H5_OFFLINE_GAME;
import static com.transsion.palmstorecore.log.LogUtils.TAG_H5_WEB;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.cache.widgetprocess.DeskWidgetProcessor;
import com.afmobi.palmplay.hotword.SearchBarPosition;
import com.afmobi.palmplay.hotword.cache.HotWordCache;
import com.afmobi.palmplay.hotword.model.SearchTagDataV2;
import com.afmobi.palmplay.cloudfolder.CloudFolderRemoteController;
import com.afmobi.palmplay.configs.UrlConfig;
import com.afmobi.palmplay.download.DownloadTaskHelper;
import com.afmobi.palmplay.download.ForegroundInstallManager;
import com.afmobi.palmplay.h5.offline.H5OfflineManager;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.manager.DetailConfigManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.NotifyToggleManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.AttributionConfigInfo;
import com.afmobi.palmplay.model.ConfigInfo;
import com.afmobi.palmplay.model.CustomizedInfo;
import com.afmobi.palmplay.model.DeepLinkInfo;
import com.afmobi.palmplay.model.DownloadTaskConfigInfo;
import com.afmobi.palmplay.model.GameAdConfigInfo;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.GtInterceptConfigInfo;
import com.afmobi.palmplay.model.HalfScreenDetailConfigInfo;
import com.afmobi.palmplay.model.HalfScreenTypesInfo;
import com.afmobi.palmplay.model.LauncherConfigInfo;
import com.afmobi.palmplay.model.NotificationConfigInfo;
import com.afmobi.palmplay.model.NotificationReportConfig;
import com.afmobi.palmplay.model.NotifyToggleConfigInfo;
import com.afmobi.palmplay.model.OfferNotifyConfigInfo;
import com.afmobi.palmplay.model.OfflineNotifyConfigInfo;
import com.afmobi.palmplay.model.RecallConfigInfo;
import com.afmobi.palmplay.model.StartUpInfo;
import com.afmobi.palmplay.model.StationMailInfo;
import com.afmobi.palmplay.model.StatusSaverConfigInfo;
import com.afmobi.palmplay.model.ToolBarConfigInfo;
import com.afmobi.palmplay.model.ew.RemovalCfg;
import com.afmobi.palmplay.model.v6_0.PalmLanguage;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.newdiff.HsynzCompatKt;
import com.afmobi.palmplay.repo.RemoteConfigRepo;
import com.afmobi.palmplay.shortcuts.LauncherShortcutModel;
import com.afmobi.palmplay.shortcuts.LauncherShortcutsManager;
import com.afmobi.palmplay.startup.MeSwitch;
import com.afmobi.palmplay.switchcountry.SwitchCountryManager;
import com.afmobi.palmplay.thirdlauncher.SafeDeepLinkHandler;
import com.afmobi.palmplay.thirdlauncher.strategy.NavigationDispatcher;
import com.afmobi.palmplay.va.PsVaConstants;
import com.afmobi.util.CommonExt;
import com.afmobi.palmplay.video.helper.TrVideoPlayer;
import com.afmobi.palmplay.vabox.admob.IconAdBusinessManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.TRSetBragdeCountUtil;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.store.component.attribute.AttrSwitch;
import com.transsion.newphonerecommend.utils.Constants;
import com.transsion.newphonerecommend.utils.SpUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.apm.ApmSwitch;
import com.transsion.palmstorecore.analytics.apm.banner.BannerSwitch;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppCacheUtil;
import com.transsion.palmstorecore.analytics.apm.http.config.HttpSwitch;
import com.transsion.palmstorecore.analytics.apm.log.LogSwitch;
import com.transsion.palmstorecore.basecomponent.IStartUpCallback;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.hipush.HiPushEventManager;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.GDPRUtil;
import com.transsion.palmstorecore.util.GsonUtils;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.palmstorecore.util.TrWebDomainUtils;
import com.transsnet.attribution.data.LocalDataManager;
import com.transsnet.launcherlib.services.DispenseDataManager;
import com.transsnet.launcherlib.services.LauncherDispenseManager;
import com.transsnet.store.BuildConfig;

import org.json.JSONArray;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import de.greenrobot.event.EventBus;

/**
 * 启动页缓存类
 *
 * @author HJG
 * @date 2016-5-17 上午11:42:41
 * @modifyAuthor:
 * @modifyDate: 2016-5-17 上午11:42:41
 * @modifyContent:
 */
public class StartUpTabsCache implements LocalCache {

    private static final String CACHE_URI = "Main_TABS_CACHE";

    private static volatile StartUpTabsCache mCache;

    private static final byte[] lock = new byte[0];

    private PalmLanguage mPalmLanguage = null;



    /**
     * 开机启动激活提醒通知的最大显示次数；
     */
    private int activateRemindShowCount = -1;

    private final static long LOAD_INTERVAL = 4 * 60 * 60 * 1000L; //4h
    public final static String SP_LAST_REQ_TIME = "sp_last_req_time";


    public StartUpInfo mStartUpInfo;



    private List<CustomizedInfo> customizedList = null;
    private ArrayList<String> preloadWhiteList = null;

    private StartUpTabsCache() {
		loadFromCache();
	}

    public static StartUpTabsCache getInstance() {
        if (mCache == null) {
            synchronized (lock) {
                if (mCache == null) {
                    mCache = new StartUpTabsCache();
                }
            }
        }
        return mCache;
    }

    public void init() {

    }

    public void release() {
        mPalmLanguage = null;
        mCache = null;
    }

    public void initPageCaches(StartUpInfo startUpInfo,JsonObject dataJE, boolean isFromNetworkRequest,  boolean isFromJob) {
        if (startUpInfo == null) {
            return;
        }
        mStartUpInfo = startUpInfo;


        if (isFromNetworkRequest) {
            if (mStartUpInfo.countrySwitchConfigInfo != null && mStartUpInfo.countrySwitchConfigInfo.parameterValue != null) {
                SwitchCountryManager.getInstance().saveConfigInfo(mStartUpInfo.countrySwitchConfigInfo.parameterValue);
                if (SwitchCountryManager.getInstance().isMasterSwitchOpen() && isFromJob) {
                    SwitchCountryManager.getInstance().preCacheHomeFeature(mStartUpInfo.ipCountryCode);
                }
            } else {
                if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("countrySwitchConfigInfo")){
                    SwitchCountryManager.getInstance().saveConfigInfo(null);
                }
            }
        }

        // searchTagData 按位置存入 HotWordCache
        if (startUpInfo.searchTagData != null) {
            SearchTagDataV2 v2 = startUpInfo.searchTagData;
            HotWordCache cache = HotWordCache.getInstance();
            if (v2.getHome() != null) cache.save(SearchBarPosition.HOME, v2.getHome());
            if (v2.getApp() != null) cache.save(SearchBarPosition.APP, v2.getApp());
            if (v2.getGame() != null) cache.save(SearchBarPosition.GAME, v2.getGame());
            if (v2.getInstant() != null) cache.save(SearchBarPosition.INSTANT, v2.getInstant());
            if (v2.getDetail() != null) cache.save(SearchBarPosition.DETAIL, v2.getDetail());
        }

// 2、获取桌面快捷图标信息
        if (UrlConfig.DYNAMIC_FOLDER_SWITCH) {
            try {
                if (dataJE != null && dataJE.has("shortcuts_data")) {
                    final String shortcutJson = dataJE.getAsJsonObject("shortcuts_data").toString();
                    if (!TextUtils.isEmpty(shortcutJson) && LauncherShortcutsManager.canUpdateShortcutConfig()) {
                        TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new TRRunnable(new TRRunnableInterface() {
                            @Override
                            public void doRun() {
                                LauncherShortcutsManager.saveShortcutData(shortcutJson, new LauncherShortcutModel(), true);
                            }
                        }));
                    }
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

//3、详情页面缓存信息
//        if (mStartUpInfo != null && mStartUpInfo.offerInfoList!=null && mStartUpInfo.offerInfoList.size()>0) {
//            mCustomizedList.clear();
//            mCustomizedList.addAll(mStartUpInfo.offerInfoList);
//        }


//4、首页榜单品类配置信息（首页投保tab信息）
        //todo  mark 20230816
//        if (mStartUpInfo != null && mStartUpInfo.featureTabMap!=null) {
//            mFeatureTabMap.clear();
//            mFeatureTabMap.putAll(mStartUpInfo.featureTabMap);
//        }

//        mFeatureTabDataMark = mStartUpInfo.featureTabDataMark;
//        SPManager.putLong(FEATURE_TAB_DATA_MARK, mFeatureTabDataMark);

        //5、登录配置信息（为了token 用于后续API请求）
        PhoneDeviceInfo.setLoginResult(mStartUpInfo.loginData);

        if (mStartUpInfo.h5Offline != null) {
            H5OfflineManager.getInstance().saveLatestConfig(mStartUpInfo.h5Offline.h5OfflineConfigs);
        }

        //判断Launch 角标拦截是否关闭
        NotifyToggleManager.getInstance().onCacheModelList(mStartUpInfo,isFromNetworkRequest);

        if (mStartUpInfo.popupSceneConfig != null) {
            JsonElement je = (dataJE != null) ? dataJE.get("popupSceneConfig") : null;
            if (je != null) {
                String popupSceneConfigJson = je.toString();
                MMKVUtils.getMMKV().putString(Constant.KV_DEFAULT_STORE_POPUP_SCENE_CONFIG, popupSceneConfigJson);
            }
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("popupSceneConfig")) {
                MMKVUtils.getMMKV().remove(Constant.KV_DEFAULT_STORE_POPUP_SCENE_CONFIG);
            }
        }

        //判断Launch 角标拦截是否关闭
        if (mStartUpInfo.modelBizSwitchInfo != null && mStartUpInfo.modelBizSwitchInfo.parameterValue != null) {
            GtInterceptConfigInfo.GtInterceptConfigInfoParameterValue info = mStartUpInfo.modelBizSwitchInfo.parameterValue;
            MMKVUtils.getMMKV().putBoolean(Constant.KV_GT_INTERRUPT, true);
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_COMMON_NOTIFY, info.isCommonNotification());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_INSTALL_NOTIFY, info.isInstallComplete());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_OFFLINE_FLOAT, info.isOfflineFloat());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_INSTALL_FLOAT, info.isInstallCompleteFloat());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_RECALL_FLOAT, info.isRecallFloat());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_CLEAR_FLOAT, info.isClearSpaceFloat());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_TOOLBAR_NOTIFY, info.isToolBarNotify());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_LAUNCHE_REDDOT, info.isLauncherRedDotTips());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_NEW_GUIDE, info.isGuide());
            MMKVUtils.getMMKV().putInt(Constant.KV_GT_OLD_GUIDE, info.isOldGuide());

            if (info.isLauncherRedDotTips() == 0) {
                LogUtils.d(LogUtils.TAG_LAUNCHER_BADGE, "gt_switch is 0, set badge count to -1");
                TRSetBragdeCountUtil.setCountToLauncher(-1, false);
            }
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("modelBizSwitchInfo")){
                MMKVUtils.getMMKV().putBoolean(Constant.KV_GT_INTERRUPT, false);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_COMMON_NOTIFY);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_INSTALL_NOTIFY);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_OFFLINE_FLOAT);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_INSTALL_FLOAT);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_RECALL_FLOAT);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_CLEAR_FLOAT);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_TOOLBAR_NOTIFY);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_LAUNCHE_REDDOT);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_NEW_GUIDE);
                MMKVUtils.getMMKV().remove(Constant.KV_GT_OLD_GUIDE);
            }
        }


        if (mStartUpInfo.deepLinkInfo != null && mStartUpInfo.deepLinkInfo.parameterValue != null) {

            SafeDeepLinkHandler.getInstance().updateDeepLinkWhiteList(mStartUpInfo.deepLinkInfo.parameterValue);

            JsonElement je = (dataJE != null) ? dataJE.get("deepLinkInfo") : null;
            if (je != null) {
                String deepLinkInfoJson = je.toString();
                MMKVUtils.getMMKV().putString(Constant.KV_DP_WHITELIST, deepLinkInfoJson);
                List<String> h5DomainNames = GsonUtils.getInstance().fromJson(je.toString(), DeepLinkInfo.class).parameterValue.h5DomainName;
                String domainsArrayStr = new JSONArray(h5DomainNames).toString();
                LogUtils.d(TAG_H5_WEB, "startUp get h5DomainNames:" + domainsArrayStr);
                MMKVUtils.getMMKV().putString(Constant.KV_DP_H5_WHITELIST, domainsArrayStr);
                TrWebDomainUtils.updateH5Domains();
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("deepLinkInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_DP_WHITELIST);
            }

        }
        // 推荐合集ids
        if (mStartUpInfo != null && mStartUpInfo.collectionsTabsConfig != null && mStartUpInfo.collectionsTabsConfig.parameterValue != null) {
            List<String> list = mStartUpInfo.collectionsTabsConfig.parameterValue.getTabIds();
            Set<String> set = (list != null && list.size() > 0) ? new HashSet<>(list) : null;
            if (set != null) {
                MMKVUtils.getMMKV().putStringSet(Constant.KV_COLLECTION_IDS, set);
            }
            if (mStartUpInfo.collectionsTabsConfig.parameterValue.isCollectionsSwitch()) {
                MMKVUtils.getMMKV().putInt(Constant.KV_COLLECTION_SWITCH, 1);
            }
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("collectionsTabsConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_COLLECTION_IDS);
            }
        }
        // 搜索反馈显示配置
        if (mStartUpInfo.feedback != null && mStartUpInfo.feedback.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_SEARCH_FEEDBACK, mStartUpInfo.feedback.parameterValue.show);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("feedback")){
                MMKVUtils.getMMKV().remove(Constant.KV_SEARCH_FEEDBACK);
            }
        }
        LogUtils.d("StartUpTabsCache", "mStartUpInfo.feedback="+mStartUpInfo.feedback);

        // 搜索重构配置
        if (mStartUpInfo.refactoring != null && mStartUpInfo.refactoring.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_SEARCH_REFACTOR_SWITCH, mStartUpInfo.refactoring.parameterValue.getSearchValue());
            NavigationDispatcher.INSTANCE.savePsLinkSwitchStatus(mStartUpInfo.refactoring.parameterValue.getPsLinkValue());
            MMKVUtils.getMultiMMKV().putInt(TRSharedPreferenceUtils.KV_IS_HALF_ACTIVITY_ENABLE, mStartUpInfo.refactoring.parameterValue.getHalfDetailValue());
            MMKVUtils.getMMKV().putInt(Constant.KV_MD_REFACTOR_SWITCH, mStartUpInfo.refactoring.parameterValue.getMdValue());
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("refactoring")){
                MMKVUtils.getMMKV().remove(Constant.KV_SEARCH_REFACTOR_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_MD_REFACTOR_SWITCH);
            }
        }

        // 详情页来源折叠配置
        if (mStartUpInfo.detailConfig != null && mStartUpInfo.detailConfig.parameterValue != null) {
            DetailConfigManager.getInstance().update(mStartUpInfo.detailConfig.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("detailConfig")) {
                DetailConfigManager.getInstance().clear();
            }
        }

        if (mStartUpInfo.attributionConfig != null && mStartUpInfo.attributionConfig.parameterValue != null) {
            AttributionConfigInfo.AttributionConfigParameterValue cfg = mStartUpInfo.attributionConfig.parameterValue;

            LocalDataManager.saveAttributionConfig(cfg.switchAttribution);
            MMKVUtils.getMMKV().putInt(Constant.KV_NO_NET_TIPS_SWITCH, cfg.switchNoNetTips);
            MMKVUtils.getMMKV().putInt(Constant.KV_NO_NET_TIPS_TIMES, cfg.timesNoNetTips);
            MMKVUtils.getMMKV().putInt(Constant.KV_BY_NET_OPEN_TIMES, cfg.timesNetOpenTimes);
            MMKVUtils.getMMKV().putInt(Constant.KV_NO_NET_EXPIRE_DAYS, cfg.expireNetTips);
            MMKVUtils.getMMKV().putInt(Constant.KV_BLOCK_RETRY_TIMES, cfg.blockRetryTimes);
            MMKVUtils.getMMKV().putInt(Constant.KV_BLOCK_RETRY_TIMEOUT, cfg.blockRetryTimeout);

            AttrSwitch.update(mStartUpInfo.attributionConfig.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("attributionConfig")){
                LocalDataManager.removeUploadStatus();
                MMKVUtils.getMMKV().remove(Constant.KV_NO_NET_TIPS_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_NO_NET_TIPS_TIMES);
                MMKVUtils.getMMKV().remove(Constant.KV_BY_NET_OPEN_TIMES);
                MMKVUtils.getMMKV().remove(Constant.KV_NO_NET_EXPIRE_DAYS);
                MMKVUtils.getMMKV().remove(Constant.KV_BLOCK_RETRY_TIMES);
                MMKVUtils.getMMKV().remove(Constant.KV_BLOCK_RETRY_TIMEOUT);

                AttrSwitch.remove();
            }
        }

        if(mStartUpInfo.gameCandidateConf != null) {
            GameAdConfigInfo gameAdConfig = mStartUpInfo.gameCandidateConf;
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_AD_REQ_INTERVAL, gameAdConfig.cacheTimeInterval);
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_AD_SHOW_TIMES, gameAdConfig.showFrequency);
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_AD_SHOW_INTERVAL, gameAdConfig.showCycle);
            MMKVUtils.getMMKV().putString(Constant.KV_GAME_AD_HALF_PAGE_STYLE, gameAdConfig.halfPageStyle);
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_AD_ACTIVE_TOTAL_TIMES, gameAdConfig.activateClickFrequency);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("gameCandidateConf")){
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_AD_REQ_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_AD_SHOW_TIMES);
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_AD_SHOW_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_AD_HALF_PAGE_STYLE);
            }
        }

        if (mStartUpInfo.isShowGuide != null) {
            //  ConfigManager.isShowGuide = mStartUpInfo.isShowGuide.parameterValue;
            SpUtil.getSP().putBoolean(TRAnalyticsConstant.SHOW_GUIDE_CONFIG, mStartUpInfo.isShowGuide.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("isShowGuide")){
                SpUtil.getSP().remove(TRAnalyticsConstant.SHOW_GUIDE_CONFIG);
            }
        }

        if (mStartUpInfo.connectionInfo != null) {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(PalmplayApplication.getAppInstance());
            sp.edit().putInt("count", mStartUpInfo.connectionInfo.getParameterValue()).commit();
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("connectionInfo")){
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(PalmplayApplication.getAppInstance());
                sp.edit().remove("count").commit();
            }
        }

        if (mStartUpInfo.searchConfigInfo != null && mStartUpInfo.searchConfigInfo.parameterValue != null) {
            SPManager.putBoolean("oneCharSearchSwitch", mStartUpInfo.searchConfigInfo.parameterValue.oneCharSearchSwitch);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("searchConfigInfo")){
                SPManager.remove("oneCharSearchSwitch");
            }
        }


//6、自升级配置信息
        long checkSelfUpdateInterval = mStartUpInfo.checkSelfUpdateInterval;
        checkSelfUpdateInterval *= 1000;//转为毫秒值
        MMKVUtils.getMMKV().putLong(Constant.KV_UPDATE_INTERVAL, checkSelfUpdateInterval);

        if (mStartUpInfo != null && mStartUpInfo.removalConfig != null) {
            RemovalCfg cfg = mStartUpInfo.removalConfig;
            MMKVUtils.getMMKV().putInt(Constant.KV_REMOVAL_FREQUENCY, cfg.frequency);
            Set<String> set = (cfg.whiteList != null) ? new HashSet<String>(cfg.whiteList) : null;
            if (set != null) {
                MMKVUtils.getMMKV().putStringSet(Constant.KV_REMOVAL_WHITELIST, set);
            }

            HisavanaSdkManager.getInstance().setRemovalConfig(cfg);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("removalConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_REMOVAL_FREQUENCY);
                MMKVUtils.getMMKV().remove(Constant.KV_REMOVAL_WHITELIST);
                HisavanaSdkManager.getInstance().setRemovalConfig(null);
            }
        }

//7、EW配置信息
        if (mStartUpInfo != null && mStartUpInfo.hisavanaAdConfigMap != null) {
            HisavanaSdkManager.getInstance().setHisavanaMap(mStartUpInfo.hisavanaAdConfigMap);

            JsonElement je = (dataJE != null) ? dataJE.get("hisavanaAdConfigMap") : null;
            if (je != null) {
                MMKVUtils.getMMKV().putString(Constant.KV_EW_MAP, je.toString());
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("hisavanaAdConfigMap")){
                MMKVUtils.getMMKV().remove(Constant.KV_EW_MAP);
            }
        }

        if(mStartUpInfo != null) {
            MMKVUtils.getMMKV().putString(Constant.KV_EW_IS_REPEAT, mStartUpInfo.hisavanaAdCanRepeated);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("hisavanaAdCanRepeated")){
                MMKVUtils.getMMKV().remove(Constant.KV_EW_IS_REPEAT);
            }
        }

//8、半屏详情页展示风格配置信息
        String detailStyleRole = mStartUpInfo.detailStyleRole;
        MMKVUtils.getMMKV().putString(Constant.KV_DETAIL_ROLE, detailStyleRole);

//10、下载任务配置信息
        if (mStartUpInfo != null && mStartUpInfo.downloadTaskCfgInfo != null && mStartUpInfo.downloadTaskCfgInfo.parameterValue != null) {
            DownloadTaskConfigInfo.DownloadTaskParameterValue taskCfg = mStartUpInfo.downloadTaskCfgInfo.parameterValue;
            MMKVUtils.getMMKV().putInt(Constant.OFFER_TASK_LIMIT, taskCfg.offerTaskLimit);
            MMKVUtils.getMMKV().putInt(Constant.NORMAL_TASK_LIMIT, taskCfg.normalTaskLimit);
            MMKVUtils.getMMKV().putInt(Constant.VA_TASK_LIMIT, taskCfg.vaTaskLimit);

            DownloadTaskHelper.initDownloadTaskLimit(taskCfg.offerTaskLimit, taskCfg.normalTaskLimit, taskCfg.vaTaskLimit);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("downloadTaskCfgInfo")){
                MMKVUtils.getMMKV().remove(Constant.OFFER_TASK_LIMIT);
                MMKVUtils.getMMKV().remove(Constant.NORMAL_TASK_LIMIT);
                MMKVUtils.getMMKV().remove(Constant.VA_TASK_LIMIT);

                DownloadTaskHelper.initDownloadTaskLimit(1, 1, 1);
            }
        }

//11、消息调度优化配置信息
        if (mStartUpInfo != null && mStartUpInfo.msgOptConfigInfo != null && mStartUpInfo.msgOptConfigInfo.parameterValue != null) {
            int flag = mStartUpInfo.msgOptConfigInfo.parameterValue.msgOptSwitch;
            MMKVUtils.getMMKV().putInt(Constant.MSG_OPT_SWITCH, flag);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("msgOptConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.MSG_OPT_SWITCH);
            }
        }

        //缓存离线游戏列表请求时间信息
        if(mStartUpInfo!=null && mStartUpInfo.gameOfflineResourceConfigInfo!=null){
            LogUtils.d(TAG_H5_OFFLINE_GAME, "Get h5 game time config.");
            SPManager.putString(Constant.PREFERENCES_KEY_H5_OFFLINE_GAME_CONFIG_TIME,new Gson().toJson(mStartUpInfo.gameOfflineResourceConfigInfo));
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("gameOfflineResourceConfigInfo")){
                SPManager.remove(Constant.PREFERENCES_KEY_H5_OFFLINE_GAME_CONFIG_TIME);
            }
        }

        if(mStartUpInfo!=null && mStartUpInfo.updateOwnerClearInfo !=null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_UPDATE_OWNERSHIP_CLEAR_ENABLE,mStartUpInfo.updateOwnerClearInfo.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("updateOwnerClearInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_UPDATE_OWNERSHIP_CLEAR_ENABLE);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.apmConfigInfo != null && mStartUpInfo.apmConfigInfo.parameterValue !=null){
            ApmSwitch.update(mStartUpInfo.apmConfigInfo.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("apmConfigInfo")){
                ApmSwitch.remove();
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.logConfigInfo != null && mStartUpInfo.logConfigInfo.parameterValue !=null){
            LogSwitch.update(mStartUpInfo.logConfigInfo.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("logConfigInfo")){
                LogSwitch.remove();
            }
        }
        if (mStartUpInfo != null && mStartUpInfo.meConfigInfo != null && mStartUpInfo.meConfigInfo.parameterValue !=null){
            MeSwitch.update(mStartUpInfo.meConfigInfo.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("meConfigInfo")){
                MeSwitch.remove();
            }
        }
//  offer customize
        if (mStartUpInfo != null && mStartUpInfo.offerInfoList != null) {
            customizedList = mStartUpInfo.offerInfoList;

            JsonElement je = (dataJE != null) ? dataJE.get("offerInfoList") : null;
            if (je != null) {
                MMKVUtils.getMMKV().putString(Constant.KV_CUSTOMIZE_LIST, je.toString());
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("offerInfoList")){
                MMKVUtils.getMMKV().remove(Constant.KV_CUSTOMIZE_LIST);
            }
        }

//  taskid
        MMKVUtils.getMMKV().putInt(Constant.KV_TASK_ID, mStartUpInfo.taskId);

//   isPreloadOn2
        if (mStartUpInfo != null && mStartUpInfo.isPreLoadOn2 != null && mStartUpInfo.isPreLoadOn2.parameterValue != null) {
            ConfigInfo.WebViewPreLoad.WebViewPreLoadConfig cfg = mStartUpInfo.isPreLoadOn2.parameterValue;

            MMKVUtils.getMMKV().putString(Constant.KV_WEBVIEW_PRELOAD_SWITCH, cfg.getWebViewPreLoadSwitch());
            if (cfg.getUrlWhiteList() != null) {
                preloadWhiteList = cfg.getUrlWhiteList();
                Set<String> set = new HashSet<>(cfg.getUrlWhiteList());
                MMKVUtils.getMMKV().putStringSet(Constant.KV_WEBVIEW_WHITELIST, set);
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("isPreLoadOn2")){
                MMKVUtils.getMMKV().remove(Constant.KV_WEBVIEW_PRELOAD_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_WEBVIEW_WHITELIST);
            }
        }

//        notifyshow
        if (mStartUpInfo != null && mStartUpInfo.notifyShow != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTIFY_SHOW, mStartUpInfo.notifyShow.getParameterValue());
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("notifyShow")){
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_SHOW);
            }
        }


//        STATUS SAVER
        if (mStartUpInfo != null && mStartUpInfo.statusSaverConfigInfo != null && mStartUpInfo.statusSaverConfigInfo.parameterValue != null) {
            StatusSaverConfigInfo.StatusSaverParameterValue cfg = mStartUpInfo.statusSaverConfigInfo.parameterValue;
            MMKVUtils.getMMKV().putInt(Constant.KV_STATUS_SAVER_SWITCH, cfg.statusSwitch);
            MMKVUtils.getMMKV().putInt(Constant.KV_STATUS_SAVER_RATIO, cfg.leftSpaceRatio);
            MMKVUtils.getMMKV().putInt(Constant.KV_STATUS_SAVER_MAXCACHE, cfg.maxCacheSize);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("statusSaverConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_STATUS_SAVER_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_STATUS_SAVER_RATIO);
                MMKVUtils.getMMKV().remove(Constant.KV_STATUS_SAVER_MAXCACHE);
            }
        }

// VAConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.VAConfigInfo != null && mStartUpInfo.VAConfigInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_VA_UPDATE_INDEX, mStartUpInfo.VAConfigInfo.parameterValue.configUpdateIndex);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("VAConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_VA_UPDATE_INDEX);
            }
        }

// Gameswitch
        if (mStartUpInfo != null && mStartUpInfo.gameSwitch != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_SWITCH, mStartUpInfo.gameSwitch.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("gameSwitch")){
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_SWITCH);
            }
        }
        if (mStartUpInfo != null && mStartUpInfo.webGameSwitch != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_WEB_GAME_SWITCH, mStartUpInfo.webGameSwitch.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("webGameSwitch")){
                MMKVUtils.getMMKV().remove(Constant.KV_WEB_GAME_SWITCH);
            }
        }
        if (mStartUpInfo != null && mStartUpInfo.vaKeepFragileData != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_KEEP_FRAGILE_DATA, mStartUpInfo.vaKeepFragileData.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("vaKeepFragileData")){
                MMKVUtils.getMMKV().remove(Constant.KV_KEEP_FRAGILE_DATA);
            }
        }
        if (mStartUpInfo != null && mStartUpInfo.instantConfig != null && mStartUpInfo.instantConfig.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_VA_STARTUP_INTERVAL, mStartUpInfo.instantConfig.parameterValue.startupInterval);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("instantConfig")) {
                MMKVUtils.getMMKV().remove(Constant.KV_VA_STARTUP_INTERVAL);
            }
        }
        //GameSpace相关配置
        if (mStartUpInfo.gameSpaceConfigInfo != null && mStartUpInfo.gameSpaceConfigInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putBoolean(Constant.KV_GAMESPACE_ENABLE, mStartUpInfo.gameSpaceConfigInfo.parameterValue.enable);
            if (mStartUpInfo.gameSpaceConfigInfo.parameterValue.enable) {
                MMKVUtils.getMMKV().putBoolean(Constant.KV_GAMESPACE_SILENT_STATUS, mStartUpInfo.gameSpaceConfigInfo.parameterValue.silent_status);
                MMKVUtils.getMMKV().putBoolean(Constant.KV_GAMESPACE_SILENT_DOWNLOAD, mStartUpInfo.gameSpaceConfigInfo.parameterValue.silent_download);
                MMKVUtils.getMMKV().putInt(Constant.KV_GAMESPACE_MIN_VERSION, mStartUpInfo.gameSpaceConfigInfo.parameterValue.gs_ver);
            } else {
                //false等同于纯净版，调整Switch状态为-2
                MMKVUtils.getMMKV().putInt(Constant.KV_GAME_SWITCH, PsVaConstants.GameSwitch.SUPER_SEVERE);
                MMKVUtils.getMMKV().putBoolean(Constant.KV_GAMESPACE_SILENT_STATUS, false);
                MMKVUtils.getMMKV().putBoolean(Constant.KV_GAMESPACE_SILENT_DOWNLOAD, false);
                MMKVUtils.getMMKV().putInt(Constant.KV_GAMESPACE_MIN_VERSION, PsVaConstants.VA_FEATURE.SUPPORT_COOPERATION_VERSION);
            }
        } else {
            //信息校验不通过时，不可以移除配置，应该保留上次的配置，因：1.可能是网络问题导致的信息获取失败；2.可能是后台配置信息有问题 而非产品本意
//            MMKVUtils.getMMKV().remove(Constant.KV_GAMESPACE_ENABLE);
//            MMKVUtils.getMMKV().remove(Constant.KV_GAMESPACE_SILENT_STATUS);
        }

        // historyShow
        if (mStartUpInfo != null && mStartUpInfo.historyShow != null && mStartUpInfo.historyShow.parameterValue != null) {
            MMKVUtils.getMMKV().putBoolean(Constant.KV_HISTORY_SHOW, mStartUpInfo.historyShow.parameterValue.historyShow);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("historyShow")){
                MMKVUtils.getMMKV().remove(Constant.KV_HISTORY_SHOW);
            }
        }
        //caton optimization
        if (mStartUpInfo != null && mStartUpInfo.catonOptimization != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_CATON_OPTIMIZATION, mStartUpInfo.catonOptimization.parameterValue);
            com.afmobi.util.Constants.catonOptimizationOpen = mStartUpInfo.catonOptimization.parameterValue == 1;
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("catonOptimization")){
                MMKVUtils.getMMKV().remove(Constant.KV_CATON_OPTIMIZATION);
                com.afmobi.util.Constants.catonOptimizationOpen = false;
            }
        }
        // desc details link
        if (mStartUpInfo != null && mStartUpInfo.descDetailsLinkSwitch != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_HALF_DETAIL_DESC_DETAILS_LINK, mStartUpInfo.descDetailsLinkSwitch.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("descDetailsLinkSwitch")){
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_DETAIL_DESC_DETAILS_LINK);
            }
        }
        // autoCreate
        if (mStartUpInfo != null && mStartUpInfo.autoCreate != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_AUTO_CREATE, mStartUpInfo.autoCreate.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("autoCreate")){
                MMKVUtils.getMMKV().remove(Constant.KV_AUTO_CREATE);
            }
        }
// downloadManagerDeleIsExpand
        if (mStartUpInfo != null && mStartUpInfo.downloadManagerDeleIsExpand != null) {
            MMKVUtils.getMMKV().putBoolean(Constant.KV_MANAGE_DOWNLOAD_DELETE, mStartUpInfo.downloadManagerDeleIsExpand.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("downloadManagerDeleIsExpand")){
                MMKVUtils.getMMKV().remove(Constant.KV_MANAGE_DOWNLOAD_DELETE);
            }
        }

// xDayProtector
        if (mStartUpInfo != null && mStartUpInfo.xDayProtector != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_X_DAY_PROTECTOR, mStartUpInfo.xDayProtector.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("xDayProtector")){
                MMKVUtils.getMMKV().remove(Constant.KV_X_DAY_PROTECTOR);
            }
        }

// notifyToggleConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.notifyToggleConfigInfo != null && mStartUpInfo.notifyToggleConfigInfo.parameterValue != null) {
            NotifyToggleConfigInfo.NotifyToggleParameterValue cfg = mStartUpInfo.notifyToggleConfigInfo.parameterValue;
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTIFY_TOGGLE_MAX, cfg.maxNotifyLimit);
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTIFY_TOGGLE_INTERVAL, cfg.notifyIntervalTime);
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTITY_TOGGLE_IGNORE, cfg.ignoreSystemKeepAlive);
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTIFY_TOGGLE_SWITCH_S_BELOW, cfg.showNotifySwitchForSAndBelow);
            MMKVUtils.getMMKV().putInt(Constant.KV_TPMS_ALIVE_SWITCH, cfg.tpmsKeepAliveSwitch);
            MMKVUtils.getMMKV().putInt(Constant.KV_PM_ALIVE_SWITCH, cfg.pmPowerSwitch);
            MMKVUtils.getMMKV().putInt(Constant.KV_PM_ALIVE_INTERVAL, cfg.aliveInterval);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("notifyToggleConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_TOGGLE_MAX);
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_TOGGLE_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_NOTITY_TOGGLE_IGNORE);
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_TOGGLE_SWITCH_S_BELOW);
                MMKVUtils.getMMKV().remove(Constant.KV_TPMS_ALIVE_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_PM_ALIVE_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_PM_ALIVE_INTERVAL);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.notificationConfigInfo != null && mStartUpInfo.notificationConfigInfo.parameterValue != null) {
            NotificationConfigInfo.NotificationParameterValue cfg = mStartUpInfo.notificationConfigInfo.parameterValue;
            MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_FUNCTION_NOTIFICATION_SHOW_COUNT, cfg.funcNotificationShowCount);
            MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_MARKET_NOTIFICATION_SHOW_COUNT, cfg.marketNotificationShowCount);
            MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_AUTO_CLEAR_NOTIFICATION_TIME, cfg.autoClearTime);
            MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_USER_CLEAR_NO_DISPLAY_TIME, cfg.userClearTime);
            //通知开关
            NotificationExtKt.putSwitch(cfg);

            MMKVUtils.getMMKV().putInt(Constant.KV_INSTALL_COMPLETE_NOTIFY_CONFIG, mStartUpInfo.notificationConfigInfo.parameterValue.installCompleteHighPriority);
            MMKVUtils.getMMKV().putInt(Constant.KV_UPDATE_COMPLETE_NOTIFY_CONFIG, mStartUpInfo.notificationConfigInfo.parameterValue.updateCompleteHighPriority);
            MMKVUtils.getMMKV().putInt(Constant.KV_ONLY_OFFER_INSTALL_NOTIFY_CONFIG, mStartUpInfo.notificationConfigInfo.parameterValue.isOnlyOfferInstallHighNotifyOpen);
            MMKVUtils.getMMKV().putInt(Constant.KV_ONLY_OFFER_UPDATE_NOTIFY_CONFIG, mStartUpInfo.notificationConfigInfo.parameterValue.isOnlyOfferUpdateHighNotifyOpen);
            NotificationConfigInfo.saveHighNotifyReportSources(mStartUpInfo.notificationConfigInfo.parameterValue.highNotifyReportSources);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("notificationConfigInfo")){
                MMKVUtils.getMMKV().remove(TRSharedPreferenceUtils.KV_FUNCTION_NOTIFICATION_SHOW_COUNT);
                MMKVUtils.getMMKV().remove(TRSharedPreferenceUtils.KV_MARKET_NOTIFICATION_SHOW_COUNT);
                MMKVUtils.getMMKV().remove(TRSharedPreferenceUtils.KV_AUTO_CLEAR_NOTIFICATION_TIME);
                MMKVUtils.getMMKV().remove(TRSharedPreferenceUtils.KV_USER_CLEAR_NO_DISPLAY_TIME);

                MMKVUtils.getMMKV().remove(Constant.KV_INSTALL_COMPLETE_NOTIFY_CONFIG);
                MMKVUtils.getMMKV().remove(Constant.KV_UPDATE_COMPLETE_NOTIFY_CONFIG);
                MMKVUtils.getMMKV().remove(Constant.KV_ONLY_OFFER_INSTALL_NOTIFY_CONFIG);
                MMKVUtils.getMMKV().remove(Constant.KV_ONLY_OFFER_UPDATE_NOTIFY_CONFIG);
                MMKVUtils.getMMKV().remove(Constant.KV_HIGH_NOTIFY_REPORT_SOURCES);
                NotificationExtKt.removeSwitch();
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.notificationReportConfig != null) {
             NotificationReportConfig.saveNotificationReportConfig(mStartUpInfo.notificationReportConfig.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("notificationReportConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_REPORT_CONFIG);
            }
        }

// DLCConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.dlcConfigInfo != null) {
            CommonExt.INSTANCE.setStartUpDLCOpen(mStartUpInfo.dlcConfigInfo.parameterValue == 1);
            if (isFromNetworkRequest) {
                MMKVUtils.getMMKV().putInt(Constant.KV_DLC_SWITCH, mStartUpInfo.dlcConfigInfo.parameterValue);
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("dlcConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_DLC_SWITCH);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.hgupConfigInfoV2 != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_HGUP_SWITCH, mStartUpInfo.hgupConfigInfoV2.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("hgupConfigInfoV2")){
                MMKVUtils.getMMKV().remove(Constant.KV_HGUP_SWITCH);
            }
        }

// splitConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.splitConfigInfo != null && mStartUpInfo.splitConfigInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_SPLIT_SWITCH, mStartUpInfo.splitConfigInfo.parameterValue.splitSwitch);
            MMKVUtils.getMMKV().putInt(Constant.KV_SPLIT_RETRYCOUNT, mStartUpInfo.splitConfigInfo.parameterValue.splitRetryCount);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("splitConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_SPLIT_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_SPLIT_RETRYCOUNT);
            }
        }

// asyncConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.asyncConfigInfo != null && mStartUpInfo.asyncConfigInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_ASYNC_RETRYCOUNT, mStartUpInfo.asyncConfigInfo.parameterValue.asyncRetryCount);
            MMKVUtils.getMMKV().putInt(Constant.KV_ASYNC_REPORTCOUNT, mStartUpInfo.asyncConfigInfo.parameterValue.handReportRetryCount);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("asyncConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_ASYNC_RETRYCOUNT);
                MMKVUtils.getMMKV().remove(Constant.KV_ASYNC_REPORTCOUNT);
            }
        }

// offerNotifyConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.offerNotifyConfigInfo != null && mStartUpInfo.offerNotifyConfigInfo.parameterValue != null) {
            OfferNotifyConfigInfo.OfferNotifyParameterValue cfg = mStartUpInfo.offerNotifyConfigInfo.parameterValue;
            MMKVUtils.getMMKV().putBoolean(Constant.KV_OFFER_NOTIFY_ISVIBRATE, cfg.isVibration);
            MMKVUtils.getMMKV().putString(Constant.KV_OFFER_NOTIFY_STARTTIME, cfg.startLocalTime);
            MMKVUtils.getMMKV().putString(Constant.KV_OFFER_NOTIFY_ENDTIME, cfg.endLocalTime);
            MMKVUtils.getMMKV().putInt(Constant.KV_OFFER_NOTIFY_INTERVAL, cfg.intervalTime);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("offerNotifyConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_OFFER_NOTIFY_ISVIBRATE);
                MMKVUtils.getMMKV().remove(Constant.KV_OFFER_NOTIFY_STARTTIME);
                MMKVUtils.getMMKV().remove(Constant.KV_OFFER_NOTIFY_ENDTIME);
                MMKVUtils.getMMKV().remove(Constant.KV_OFFER_NOTIFY_INTERVAL);
            }
        }

// spaceLockConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.spaceLockConfigInfo != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_SPACE_LOCK_SWITCH, mStartUpInfo.spaceLockConfigInfo.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("spaceLockConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_SPACE_LOCK_SWITCH);
            }
        }

// preCacheInfo
        if (mStartUpInfo != null && mStartUpInfo.preCacheInfo != null && mStartUpInfo.preCacheInfo.parameterValue != null) {
            JsonElement je = (dataJE != null) ? dataJE.get("preCacheInfo") : null;
            if (je != null && je.isJsonObject()) {
                JsonObject childJs = je.getAsJsonObject();
                JsonElement childJe = childJs.get("parameterValue");
                if (childJe != null) {
                    MMKVUtils.getMMKV().putString(Constant.KV_PRE_CACHE_INFO, childJe.toString());
                }
            }
            MMKVUtils.getMMKV().putLong(Constant.KV_PRE_CACHE_LOADINGTIME, mStartUpInfo.preCacheInfo.parameterValue.loadingShowTime);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("preCacheInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_PRE_CACHE_INFO);
                MMKVUtils.getMMKV().remove(Constant.KV_PRE_CACHE_LOADINGTIME);
            }
        }

        //openTabIdCache
        if (mStartUpInfo != null && mStartUpInfo.openTabIdCache != null && mStartUpInfo.openTabIdCache.parameterValue != null) {
            List<String> list = mStartUpInfo.openTabIdCache.parameterValue.tabIds;
            Set<String> set = (list != null && list.size() > 0) ? new HashSet<>(list) : null;
            if (set != null) {
                MMKVUtils.getMMKV().putStringSet(Constant.KV_TAB_CACHE_PAGE_CONFIG_INFO, set);
            }
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("openTabIdCache")){
                MMKVUtils.getMMKV().remove(Constant.KV_TAB_CACHE_PAGE_CONFIG_INFO);
            }
        }

        //preCacheSingleRankConfig
        if (mStartUpInfo != null && mStartUpInfo.preCacheSingleRankConfig != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_SINGLE_RANK_CONFIG_LOAD_TIME, mStartUpInfo.preCacheSingleRankConfig.loadTimeInterval);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("preCacheSingleRankConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_SINGLE_RANK_CONFIG_LOAD_TIME);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.preCacheSingleRankConfig != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_SINGLE_ME_CONFIG_LOAD_TIME, mStartUpInfo.preCacheSingleRankConfig.meLoadTimeInterval);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("preCacheSingleMEConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_SINGLE_RANK_CONFIG_LOAD_TIME);
            }
        }

        //newSearchEngine
        if (mStartUpInfo != null && mStartUpInfo.newSearchEngine != null) {
            //MMKVUtils.getMMKV().putBoolean(Constant.KV_NEW_SEARCH_ENGING_CONFIG_INFO, mStartUpInfo.newSearchEngine.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("newSearchEngine")){
                MMKVUtils.getMMKV().remove(Constant.KV_NEW_SEARCH_ENGING_CONFIG_INFO);
            }
        }

        if(mStartUpInfo != null) {
            DetailCacheManager.getInstance().getHalfDetailStyleConfig(mStartUpInfo.halfScreenDetailStyleTimeInterval);
        }

// recallConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.recallConfigInfo != null && mStartUpInfo.recallConfigInfo.parameterValue != null) {
            RecallConfigInfo.RecallConfigParameterValue cfg = mStartUpInfo.recallConfigInfo.parameterValue;

            MMKVUtils.getMMKV().putInt(Constant.KV_RECALL_SWITCH, cfg.recallSwitchFlag);
            MMKVUtils.getMMKV().putLong(Constant.KV_RECALL_NOTICE_LIMIT, cfg.recallNoticeLimit);
            MMKVUtils.getMMKV().putLong(Constant.KV_RECALL_INTERVAL, cfg.recallIntervalTime);
            MMKVUtils.getMMKV().putLong(Constant.KV_RECALL_ACTIVE_DAY, cfg.recallActiveDayLimit);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("recallConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_RECALL_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_RECALL_NOTICE_LIMIT);
                MMKVUtils.getMMKV().remove(Constant.KV_RECALL_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_RECALL_ACTIVE_DAY);
            }
        }

// stationMailInfo
        if (mStartUpInfo != null && mStartUpInfo.stationMailInfo != null && mStartUpInfo.stationMailInfo.parameterValue != null) {
            StationMailInfo.StationMailParameterValue cfg = mStartUpInfo.stationMailInfo.parameterValue;

            MMKVUtils.getMMKV().putBoolean(Constant.KV_STATIONMAIL_SWITCH, cfg.switchFlag);
            MMKVUtils.getMMKV().putInt(Constant.KV_STATIONMAIL_INTERVAL, cfg.intervalTime);
            MMKVUtils.getMMKV().putInt(Constant.KV_STATIONMAIL_ACTIVEDAY, cfg.activeDayLimit);
            MMKVUtils.getMMKV().putInt(Constant.KV_STATIONMAIL_SHOWINTERVAL, cfg.showIntervalTime);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("stationMailInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_STATIONMAIL_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_STATIONMAIL_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_STATIONMAIL_ACTIVEDAY);
                MMKVUtils.getMMKV().remove(Constant.KV_STATIONMAIL_SHOWINTERVAL);
            }
        }

// bigFileInfo
        if (mStartUpInfo != null && mStartUpInfo.bigFileInfo != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_BIGFILE_SWITCH, mStartUpInfo.bigFileInfo.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("bigFileInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_BIGFILE_SWITCH);
            }
        }

// cutInlineInfo
        if (mStartUpInfo != null && mStartUpInfo.cutInlineInfo != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_CUT_INLINE_INTERVAL, mStartUpInfo.cutInlineInfo.getParameterValue());
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("cutInlineInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_CUT_INLINE_INTERVAL);
            }
        }

// offlineNotifyConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.offlineNotifyConfigInfo != null && mStartUpInfo.offlineNotifyConfigInfo.parameterValue != null) {
            OfflineNotifyConfigInfo.OfflineNotifyParameterValue cfg = mStartUpInfo.offlineNotifyConfigInfo.parameterValue;
            MMKVUtils.getMMKV().putInt(Constant.KV_OFFLINE_NOTIFY_SWITCH, cfg.switchFlag);
            MMKVUtils.getMMKV().putInt(Constant.KV_OFFLINE_NOTIFY_MAXLIMIT, cfg.maxNotifyLimit);
            MMKVUtils.getMMKV().putInt(Constant.KV_OFFLINE_NOTIFY_DAYLIMIT, cfg.notifyDayLimit);
            MMKVUtils.getMMKV().putInt(Constant.KV_OFFLINE_NOTIFY_INTERVAL, cfg.notifyIntervalTime);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("offlineNotifyConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_OFFLINE_NOTIFY_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_OFFLINE_NOTIFY_MAXLIMIT);
                MMKVUtils.getMMKV().remove(Constant.KV_OFFLINE_NOTIFY_DAYLIMIT);
                MMKVUtils.getMMKV().remove(Constant.KV_OFFLINE_NOTIFY_INTERVAL);
            }
        }

// plutoCfgInfo
        if (mStartUpInfo != null && mStartUpInfo.plutoCfgInfo != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_PLUTO_SWITCH, mStartUpInfo.plutoCfgInfo.parameterValue);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("plutoCfgInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_PLUTO_SWITCH);
            }
        }

// downloadNotifyInfo
        if (mStartUpInfo != null && mStartUpInfo.downloadNotifyInfo != null && mStartUpInfo.downloadNotifyInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTIFY_PAUSE_VALIDETIME, mStartUpInfo.downloadNotifyInfo.parameterValue.pauseValidateTime);
            MMKVUtils.getMMKV().putInt(Constant.KV_NOTIFY_INSTALLED_VLIDATETIME, mStartUpInfo.downloadNotifyInfo.parameterValue.installedValidateTime);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("downloadNotifyInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_PAUSE_VALIDETIME);
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_INSTALLED_VLIDATETIME);
            }
        }

// halfDetailInfo
        if (mStartUpInfo != null && mStartUpInfo.halfDetailInfo != null && mStartUpInfo.halfDetailInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putBoolean(Constant.KV_HALF_DETAIL_AUTOOPEN, mStartUpInfo.halfDetailInfo.parameterValue.autoOpenFlag);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_HALF_DETAIL_AUTODOWNLOAD, mStartUpInfo.halfDetailInfo.parameterValue.autoDownloadFlag);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("halfDetailInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_DETAIL_AUTOOPEN);
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_DETAIL_AUTODOWNLOAD);
            }
        }

// launcherConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.launcherConfigInfo != null && mStartUpInfo.launcherConfigInfo.parameterValue != null) {
            LauncherConfigInfo.LauncherConfigInfoParameterValue cfg = mStartUpInfo.launcherConfigInfo.parameterValue;
            MMKVUtils.getMMKV().putBoolean(Constant.KV_LAUNCHER_SWITCH, cfg.launcherSwitchFlag);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_LAUNCHER_PLUTO_SWITCH, cfg.plutoSwitchFlag);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_RECOMMEND_INSTALL_SWITCH, cfg.recommendInstallSwitchFlag);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("launcherConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_LAUNCHER_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_LAUNCHER_PLUTO_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_RECOMMEND_INSTALL_SWITCH);
            }
        }

        //桌面角标开关
        if (mStartUpInfo != null && mStartUpInfo.launcherDotNewConfig != null &&  mStartUpInfo.launcherDotNewConfig.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_LAUNCHER_DOT_SWITCH, mStartUpInfo.launcherDotNewConfig.parameterValue.launcherDotSwitch);
            MMKVUtils.getMMKV().putInt(Constant.KV_GDPR_OS12_SWITCH, mStartUpInfo.launcherDotNewConfig.parameterValue.os12Switch);

            if (mStartUpInfo.launcherDotNewConfig.parameterValue.launcherDotSwitch != 1) {
                TRSetBragdeCountUtil.setCountToLauncher(-1, false);
            }

        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("launcherDotNewConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_LAUNCHER_DOT_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_GDPR_OS12_SWITCH);
            }
        }


// cloudBackupConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.cloudBackupConfigInfo != null && mStartUpInfo.cloudBackupConfigInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putBoolean(Constant.KV_CLOUD_BACKUP_SWITCH, mStartUpInfo.cloudBackupConfigInfo.parameterValue.cloudBackupSwitch);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("cloudBackupConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_CLOUD_BACKUP_SWITCH);
            }
        }

// actionToolSudokuConfig
        if (mStartUpInfo != null && mStartUpInfo.actionToolSudokuConfig != null && mStartUpInfo.actionToolSudokuConfig.parameterValue != null) {
            List<String> list = mStartUpInfo.actionToolSudokuConfig.parameterValue.getCount();
            Set<String> set = (list != null && list.size() > 0) ? new HashSet<>(list) : null;
            if (set != null) {
                MMKVUtils.getMMKV().putStringSet(Constant.KV_HOME_TOOLS_COUNTRY, set);
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("actionToolSudokuConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_HOME_TOOLS_COUNTRY);
            }
        }

// HalfScreenTypes
        if (mStartUpInfo != null && mStartUpInfo.HalfScreenTypes != null && mStartUpInfo.HalfScreenTypes.parameterValue != null) {
            HalfScreenTypesInfo.ParameterValue cfg = mStartUpInfo.HalfScreenTypes.parameterValue;

            Set<String> set = (cfg.styles != null && cfg.styles.size() > 0) ? new HashSet<>(cfg.styles) : null;
            if (set != null) {
                MMKVUtils.getMMKV().putStringSet(Constant.KV_HALF_SCREEN_TYPES, set);
            }

            Set<String> bizSet = (cfg.bizlist != null && cfg.bizlist.size() > 0) ? new HashSet<>(cfg.bizlist) : null;
            if (bizSet != null) {
                MMKVUtils.getMMKV().putStringSet(Constant.KV_HALF_SCREEN_BIZS, bizSet);
            }

            int halfRecomCandidateTime = cfg.halfRecomCandidateTime;
            if (halfRecomCandidateTime > 0) {
                MMKVUtils.getMMKV().putInt(Constant.KV_HALF_SCREEN_REQUEST_INTERVAL, halfRecomCandidateTime);
            }

            int halfRecomCandidateNums = cfg.halfRecomCandidateNums;
            if (halfRecomCandidateNums > 0) {
                MMKVUtils.getMMKV().putInt(Constant.KV_HALF_SCREEN_CANDIDATE_NUMS, halfRecomCandidateNums);
            }

            int showDeveloper = cfg.showDeveloper;
            MMKVUtils.getMMKV().putInt(Constant.KV_HALF_SCREEN_SHOW_DEVELOPER, showDeveloper);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("HalfScreenTypes")){
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_SCREEN_TYPES);
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_SCREEN_BIZS);
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_SCREEN_REQUEST_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_SCREEN_CANDIDATE_NUMS);
                MMKVUtils.getMMKV().remove(Constant.KV_HALF_SCREEN_SHOW_DEVELOPER);
            }
        }

// toolBarConfigInfo
        if (mStartUpInfo != null && mStartUpInfo.toolBarConfigInfo != null && mStartUpInfo.toolBarConfigInfo.parameterValue != null) {
            ToolBarConfigInfo.ToolBarConfigParameterValue cfg = mStartUpInfo.toolBarConfigInfo.parameterValue;

            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_ACTIVE_LIMIT, cfg.activeClickLimit);
            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_NEW_LIMIT, cfg.newClickLimit);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_TOOLBAR_OFFLINE_SWITCH, cfg.offlineTipsFlag);
            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_OFFLINE_SHOWTIME, cfg.offlineTipsShowTime);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_TOOLBAR_CLEAN_SWITCH, cfg.cleanTipsFlag);
            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_CLEAN_SHOWTIME, cfg.cleanTipsShowTime);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_TOOLBAR_HOME_SWITCH, cfg.homeTipsFlag);
            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_HOME_SHOWTIME, cfg.homeTipsShowTime);
            MMKVUtils.getMMKV().putBoolean(Constant.KV_TOOLBAR_STATUSAVER_SWITCH, cfg.statusSaverTipsFlag);
            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_STATUSAVE_SHOWTIME, cfg.statusSaverShowTime);
            MMKVUtils.getMMKV().putInt(Constant.KV_TOOLBAR_STATUSAVE_CHECKTIME, cfg.statusSaverCheckIntervalTime);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("toolBarConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_ACTIVE_LIMIT);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_NEW_LIMIT);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_OFFLINE_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_OFFLINE_SHOWTIME);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_CLEAN_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_CLEAN_SHOWTIME);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_HOME_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_HOME_SHOWTIME);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_STATUSAVER_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_STATUSAVE_SHOWTIME);
                MMKVUtils.getMMKV().remove(Constant.KV_TOOLBAR_STATUSAVE_CHECKTIME);
            }
        }

// preorderInfo
        if (mStartUpInfo != null && mStartUpInfo.preorderInfo != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_PREORDER_INTERVAL, mStartUpInfo.preorderInfo.getParameterValue());
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("preorderInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_PREORDER_INTERVAL);
            }
        }

// md5Info
        if (mStartUpInfo != null && mStartUpInfo.md5Info != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_MD5_RETRY_COUNT, mStartUpInfo.md5Info.getParameterValue());
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("md5Info")){
                MMKVUtils.getMMKV().remove(Constant.KV_MD5_RETRY_COUNT);
            }
        }

// reloadTimeInterval
        if (mStartUpInfo != null) {
            MMKVUtils.getMMKV().putLong(Constant.KV_REALOAD_TIME_INTERVAL, mStartUpInfo.reloadTimeInterval);
        }

// silentAD
        if (mStartUpInfo != null) {
            MMKVUtils.getMMKV().putString(Constant.KV_SILENT_AD, mStartUpInfo.silentAD);
        }

        //halfScreenDetailConfig
        if (mStartUpInfo != null && mStartUpInfo.halfScreenDetailConfig != null && mStartUpInfo.halfScreenDetailConfig.size() > 0) {
            saveHalfScreenDetailConfig(mStartUpInfo.halfScreenDetailConfig);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("halfScreenDetailConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_HALFSCREENDETAILCONFIG);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.deskWidgetPopup != null && mStartUpInfo.deskWidgetPopup.getParameterValue()!=null) {
            DeskWidgetProcessor.INSTANCE.processDeskInfoConfig(mStartUpInfo.deskWidgetPopup);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("deskWidgetPopup")){
                HttpSwitch.getInstance().remove();
            }
        }

        // dns & dcdn & preConnect & cronet
        if (mStartUpInfo != null && mStartUpInfo.httpConfigInfo != null && mStartUpInfo.httpConfigInfo.parameterValue !=null){
            HttpSwitch.getInstance().update(mStartUpInfo.httpConfigInfo.parameterValue);
            // cronet or okhttp
//            LogUtils.d("httpConfigInfo.quicSwitch = " + mStartUpInfo.httpConfigInfo.parameterValue.quicSwitch);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("httpConfigInfo")){
                HttpSwitch.getInstance().remove();
            }
        }
        // newDiff
        if (mStartUpInfo != null && mStartUpInfo.newDiff != null && mStartUpInfo.newDiff.parameterValue != null) {
            MMKVUtils.getMultiMMKV().putInt(HsynzCompatKt.KV_NEWDIFF_SWITCH, mStartUpInfo.newDiff.parameterValue.diffSwitch);
            MMKVUtils.getMultiMMKV().putInt(HsynzCompatKt.KV_NEWDIFF_MAX_RANGES, mStartUpInfo.newDiff.parameterValue.maxRanges);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("newDiff")){
                MMKVUtils.getMultiMMKV().remove(HsynzCompatKt.KV_NEWDIFF_SWITCH);
                MMKVUtils.getMultiMMKV().remove(HsynzCompatKt.KV_NEWDIFF_MAX_RANGES);
            }
        }

        //隐私协议版本号
        if (isFromNetworkRequest && !isFromJob && mStartUpInfo != null && mStartUpInfo.privacyAgreementConfigInfo != null && mStartUpInfo.privacyAgreementConfigInfo.parameterValue != null) {
            GDPRUtil.privacyPolicyVersion = mStartUpInfo.privacyAgreementConfigInfo.parameterValue.latest_version;
            //存储gdpr最新版本
            MMKVUtils.getMultiMMKV().putInt(TRSharedPreferenceUtils.KV_PRIVACY_AGREEMENT_VERSION, GDPRUtil.privacyPolicyVersion);
            TRSharedPreferenceUtils.setGdprVersionStr(GDPRUtil.appendDateToVersion(GDPRUtil.privacyPolicyVersion));

            LogUtils.d(LogUtils.TAG_PS_GDPR, "startup api => privacyPolicyVersion =" +  GDPRUtil.privacyPolicyVersion +
                    ", reauthorize = " + mStartUpInfo.privacyAgreementConfigInfo.parameterValue.reauthorize );

            if (mStartUpInfo.privacyAgreementConfigInfo.parameterValue.reauthorize == 1) {
                MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_GDPR_REAUTHORIZE, 1);
            } else {
                MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_GDPR_REAUTHORIZE, 0);
            }

        }

//updateCfgInfo
        if (mStartUpInfo != null && mStartUpInfo.empowerUpdateConfigInfo != null && mStartUpInfo.empowerUpdateConfigInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_UPDATE_FIRST_INTERVAL, mStartUpInfo.empowerUpdateConfigInfo.parameterValue.firstRequestDelayInterval);
            MMKVUtils.getMMKV().putInt(Constant.KV_UPDATE_OTHER_INTERVAL, mStartUpInfo.empowerUpdateConfigInfo.parameterValue.firstRequestNoDataReloadTimeInterval);
            MMKVUtils.getMMKV().putInt(Constant.KV_UPDATE_PROTECTION_INTERVAL, mStartUpInfo.empowerUpdateConfigInfo.parameterValue.newUserProtectionPeriod);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("empowerUpdateConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_UPDATE_FIRST_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_UPDATE_OTHER_INTERVAL);
                MMKVUtils.getMMKV().remove(Constant.KV_UPDATE_PROTECTION_INTERVAL);
            }
        }

//noNetCfgInfo
        if (mStartUpInfo != null && mStartUpInfo.noNetCfgInfo != null && mStartUpInfo.noNetCfgInfo.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_NET_TIP_CARD_TYPE, mStartUpInfo.noNetCfgInfo.parameterValue.cardType);
            MMKVUtils.getMMKV().putString(Constant.KV_NONET_BTN_PLAY_OFFLINE, mStartUpInfo.noNetCfgInfo.parameterValue.playOfflineText);
            MMKVUtils.getMMKV().putString(Constant.KV_NONET_BTN_NET_SETTINGS, mStartUpInfo.noNetCfgInfo.parameterValue.networkSettingsText);
            MMKVUtils.getMMKV().putString(Constant.KV_NONET_BTN_CONNECT, mStartUpInfo.noNetCfgInfo.parameterValue.connectText);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("noNetCfgInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_NET_TIP_CARD_TYPE);
                MMKVUtils.getMMKV().remove(Constant.KV_NONET_BTN_PLAY_OFFLINE);
                MMKVUtils.getMMKV().remove(Constant.KV_NONET_BTN_NET_SETTINGS);
                MMKVUtils.getMMKV().remove(Constant.KV_NONET_BTN_CONNECT);
            }
        }
        //保存新手、老手一键安装云控开关状态
        if (mStartUpInfo != null && mStartUpInfo.installShowConfigInfo != null && mStartUpInfo.installShowConfigInfo.parameterValue!=null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_INSTALL_NR, mStartUpInfo.installShowConfigInfo.parameterValue.isNREnable);
            MMKVUtils.getMMKV().putInt(Constant.KV_INSTALL_AR, mStartUpInfo.installShowConfigInfo.parameterValue.isAREnable);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("installShowConfigInfo")){
                MMKVUtils.getMMKV().remove(Constant.KV_INSTALL_NR);
                MMKVUtils.getMMKV().remove(Constant.KV_INSTALL_AR);
            }
        }
        if(mStartUpInfo!=null && mStartUpInfo.aRrealtimeEnable != null) {
            LogUtils.d("aRrealtimeEnable",  mStartUpInfo.aRrealtimeEnable.parameterValue +" aRrealtimeEnable");
            MMKVUtils.getMMKV().putInt(Constant.KV_AR_REALTIME_ENABLE, mStartUpInfo.aRrealtimeEnable.parameterValue);
        }else{
            LogUtils.d("aRrealtimeEnable", (mStartUpInfo.aRrealtimeEnable!= null)+ " "  );
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("aRrealtimeEnable")) {
                MMKVUtils.getMMKV().remove(Constant.KV_AR_REALTIME_ENABLE);
            }
        }

        //是否跳过前台应用的静默安装，默认是跳过
        if(mStartUpInfo.skipForegroundInstall!=null && mStartUpInfo.skipForegroundInstall.parameterValue!=null){
            MMKVUtils.getMMKV().putInt(Constant.KV_SKIP_INSTALL_FOREGROUND, mStartUpInfo.skipForegroundInstall.parameterValue.skip);
            ForegroundInstallManager.getInstance().setEnableState(mStartUpInfo.skipForegroundInstall.parameterValue.skip);
        }else{
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("skipForegroundInstall")){
                MMKVUtils.getMMKV().remove(Constant.KV_SKIP_INSTALL_FOREGROUND);
                ForegroundInstallManager.getInstance().setEnableState(ForegroundInstallManager.CONSTANT_ENABLE);
            }
        }

        if (mStartUpInfo.calendar != null && mStartUpInfo.calendar.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_CALENDAR_DATA_SIZE, mStartUpInfo.calendar.parameterValue.dateSize);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("calendar")) {
                MMKVUtils.getMMKV().remove(Constant.KV_CALENDAR_DATA_SIZE);
            }
        }

        if (mStartUpInfo.randomPlay != null && mStartUpInfo.randomPlay.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_RANDOM_PLAY_SWITCH, mStartUpInfo.randomPlay.parameterValue.open);
            MMKVUtils.getMMKV().putInt(Constant.KV_RANDOM_PLAY_INTERVALTIME, mStartUpInfo.randomPlay.parameterValue.intervalTime);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("randomPlay")) {
                MMKVUtils.getMMKV().remove(Constant.KV_RANDOM_PLAY_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KV_RANDOM_PLAY_INTERVALTIME);
            }
        }

        //是否显示Instant 专区 VA大卡的Play按钮
        if(mStartUpInfo.showInstantVaPlay!=null && mStartUpInfo.showInstantVaPlay.parameterValue!=null){
            MMKVUtils.getMMKV().putInt(Constant.KV_SHOW_INSTANT_PLAY,mStartUpInfo.showInstantVaPlay.parameterValue.showPlay);
            LogUtils.d(LogUtils.TR_D_VA_INFO, "Service config show instant va play button state = "+mStartUpInfo.showInstantVaPlay.parameterValue.showPlay);
        }else{
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("showInstantVaPlay")){
                MMKVUtils.getMMKV().remove(Constant.KV_SHOW_INSTANT_PLAY);
            }
        }

        //StartUp的配置在下一次生效
        if (mStartUpInfo.voiceSearchConfig != null && mStartUpInfo.voiceSearchConfig.parameterValue != null) {
            Set<String> langSet = new HashSet<>();
            List<String> langList = mStartUpInfo.voiceSearchConfig.parameterValue.langList;
            if (langList != null && !langList.isEmpty()) {
                langSet.addAll(langList);
            } else {
                langSet.add("en");
            }
            MMKVUtils.getMMKV().putStringSet(Constant.KV_SKIP_SHOW_ASR_LANG, langSet);
            MMKVUtils.getMMKV().putInt(Constant.KV_SKIP_SHOW_ASR, mStartUpInfo.voiceSearchConfig.parameterValue.isAllow);
            LogUtils.d(LogUtils.TAG_ASR, "Service config voice search state = " + mStartUpInfo.voiceSearchConfig.parameterValue.isAllow);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("voiceSearchConfig")) {
                MMKVUtils.getMMKV().remove(Constant.KV_SKIP_SHOW_ASR);
                MMKVUtils.getMMKV().remove(Constant.KV_SKIP_SHOW_ASR_LANG);
            }
        }

        MMKVUtils.getMMKV().putInt(RemoteConfigRepo.KV_CONFIG_DATA_HIGH_WAY, mStartUpInfo.datahighwaySwitch);
        MMKVUtils.getMMKV().putInt(RemoteConfigRepo.KV_CONFIG_PUSH_USE_ORDER, mStartUpInfo.pushUseOrderSwitch);

        MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_PRIVACY_EXP_SWITCH, mStartUpInfo.privacyExpSwitch);

        //deeplink悬浮球配置
        if (mStartUpInfo != null && mStartUpInfo.backFloatballConfig != null) {
            JsonElement je = (dataJE != null) ? dataJE.get("backFloatballConfig") : null;
            if (je != null) {
                MMKVUtils.getMMKV().putString(Constant.KV_DEEPLINK_FLOATBALL, je.toString());
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("backFloatballConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_DEEPLINK_FLOATBALL);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.appPreCacheConfig != null) {
            JsonElement je = (dataJE != null) ? dataJE.get("appPreCacheConfig") : null;
            if (je != null) {
                MMKVUtils.getMMKV().putString(Constant.KV_DETAIL_PRE_CACHE_CONFIG, je.toString());
            }
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("appPreCacheConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_DETAIL_PRE_CACHE_CONFIG);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.notifyGuideInfo != null) {
            JsonElement je = (dataJE != null) ? dataJE.get("notifyGuideInfo") : null;
            if (je != null) {
                MMKVUtils.getMMKV().putString(Constant.KV_NOTIFY_GUIDE, je.toString());
            }
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("notifyGuideInfo")) {
                MMKVUtils.getMMKV().remove(Constant.KV_NOTIFY_GUIDE);
            }
        }


        if (mStartUpInfo != null && mStartUpInfo.downloadCdnRetryDomains != null) {
            String downloadCdnRetryDomainsStr = GsonUtils.getInstance().toJson(mStartUpInfo.downloadCdnRetryDomains);
            MMKVUtils.getMMKV().putString(Constant.KV_DOWNLOAD_CDN_RETRY_DOMAINS, downloadCdnRetryDomainsStr);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("downloadCdnRetryDomains")) {
                MMKVUtils.getMMKV().remove(Constant.KV_DOWNLOAD_CDN_RETRY_DOMAINS);
            }
        }

        if (isFromNetworkRequest) {

            CommonExt.checkIsNeedDisableByDLC(disable -> {
                TRAnalysticsUtil.trackDLCProvisioned(disable ? 1 : 0);
                if (!disable) {
                    CommonUtils.onDLCDialog(null, "StartUp","init");
                }
                return null;
            });

            //9、底部导航栏以及tab数据
            // 新版删除
//            if (LocalLangRepo.getInstance().getDataMark() == 0) {
//                NavTabManager.getInstance().saveNavAndTabData(mStartUpInfo.featureTypes);
//            }

            MMKVUtils.getMMKV().putBoolean(Constant.KV_STARTUP_CACHE, true);
        }


        if(AppDataManager.FEATURE_FILE_FOLDER_SWITCH){
            try {
                if(mStartUpInfo.cloudFileSwitch!=null&&!TextUtils.isEmpty(mStartUpInfo.cloudFileSwitch.parameterValue)){
                    DispenseDataManager.getInstance().doCloudFileSwitch(Integer.parseInt(mStartUpInfo.cloudFileSwitch.parameterValue));
                    CloudFolderRemoteController.Companion.getInstance().doCloudFileSwitch(Integer.parseInt(mStartUpInfo.cloudFileSwitch.parameterValue));
                }
                if(mStartUpInfo.cloudFileSettings!=null&&mStartUpInfo.cloudFileSettings.parameterValue!=null){
                    DispenseDataManager.getInstance().doCloudFileSetting(mStartUpInfo.cloudFileSettings.parameterValue.reCreateSwitch,mStartUpInfo.cloudFileSettings.parameterValue.reCreatePopStyle);
                }
            }catch (Exception e){
               e.printStackTrace();
            }
        }
//        if(mStartUpInfo.itelClose!=null){
//            CloudFolderManager.Companion.getInstance().doCloseSwitch(mStartUpInfo.itelClose.parameterValue, 1);
//        }
//        if(mStartUpInfo.notifyLauncherGetConfig != null) {
//            DispenseDataManager.getInstance().notifyLauncher(mStartUpInfo.notifyLauncherGetConfig.parameterValue);
//        }
        if (mStartUpInfo != null && mStartUpInfo.bannerConfigInfo != null && mStartUpInfo.bannerConfigInfo.parameterValue != null){
            BannerSwitch.update(mStartUpInfo.bannerConfigInfo.parameterValue);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("bannerConfigInfo")){
                BannerSwitch.remove();
            }
        }

//        if (mStartUpInfo != null && mStartUpInfo.bookBottomPrompt != null) {
//            EBooksRepo.saveProviderMap(mStartUpInfo.bookBottomPrompt.parameterValue);
//        } else {
//            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("bookBottomPrompt")){
//                EBooksRepo.removeProviderMap();
//            }
//        }

        if (mStartUpInfo != null && mStartUpInfo.gameBanner != null && mStartUpInfo.gameBanner.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_INSTANT_OLDORNEW, mStartUpInfo.gameBanner.parameterValue.oldOrNew);
            MMKVUtils.getMMKV().putInt(Constant.KV_GAME_IMMERSIVE_BANNER, mStartUpInfo.gameBanner.parameterValue.immersiveBanner);
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("gameBanner")){
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_INSTANT_OLDORNEW);
                MMKVUtils.getMMKV().remove(Constant.KV_GAME_IMMERSIVE_BANNER);
            }
        }

        if (mStartUpInfo != null) {
            LogUtils.d("XMPet", "startup: " + mStartUpInfo.AIPets);
            if (mStartUpInfo.AIPets != null) {
                MMKVUtils.getMMKV().putInt(Constant.KEY_AI_PET_MAIN_SWITCH, mStartUpInfo.AIPets.getSafeMainSwitch());
                MMKVUtils.getMMKV().putInt(Constant.KEY_AI_PET_WIDGET_SWITCH, mStartUpInfo.AIPets.getSafeWidgetSwitch());
                MMKVUtils.getMMKV().putString(Constant.KEY_AI_PET_PRIMARY_APK_PCK_NAME, mStartUpInfo.AIPets.getSafePrimaryApkPck());
                MMKVUtils.getMMKV().putString(Constant.KEY_AI_PET_AD_ID, mStartUpInfo.AIPets.getSafeAdId());
                MMKVUtils.getMMKV().putInt(Constant.KEY_AI_PET_REWARD_AD_SWITCH, mStartUpInfo.AIPets.getSafeRewardAdSwitch());
            } else {
                MMKVUtils.getMMKV().remove(Constant.KEY_AI_PET_MAIN_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KEY_AI_PET_WIDGET_SWITCH);
                MMKVUtils.getMMKV().remove(Constant.KEY_AI_PET_PRIMARY_APK_PCK_NAME);
                MMKVUtils.getMMKV().remove(Constant.KEY_AI_PET_AD_ID);
                MMKVUtils.getMMKV().remove(Constant.KEY_AI_PET_REWARD_AD_SWITCH);
            }
        }

        // 桌面动态ICON配置
        if (mStartUpInfo != null && mStartUpInfo.desktopManagerAbilityConfig != null
                &&mStartUpInfo.desktopManagerAbilityConfig.parameterValue!=null
                &&mStartUpInfo.desktopManagerAbilityConfig.parameterValue.curPages!=null) {
            MMKVUtils.getMMKV().putString(Constant.KV_DESKTOP_MANAGER_LIST,new Gson().toJson(mStartUpInfo.desktopManagerAbilityConfig.parameterValue.curPages));
            MMKVUtils.getMMKV().putInt(Constant.KV_DESKTOP_MANAGER_SWITCH,mStartUpInfo.desktopManagerAbilityConfig.parameterValue.configSwitch);
            LauncherDispenseManager.getInstance().refStartUpInfo();
        }

        if (mStartUpInfo != null && mStartUpInfo.newPop != null) {
            MMKVUtils.getMMKV().putString(Constant.KV_NEW_POP, GsonUtils.getInstance().toJson(mStartUpInfo.newPop));
        } else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("newPop")){
                MMKVUtils.getMMKV().remove(Constant.KV_NEW_POP);
            }
        }

        if(mStartUpInfo!=null && mStartUpInfo.aRCoReExclusiveEnable != null) {
            LogUtils.d("aRCoReExclusiveEnable",  mStartUpInfo.aRCoReExclusiveEnable.parameterValue +" aRCoReExclusiveEnable");
            MMKVUtils.getMMKV().putInt(TRSharedPreferenceUtils.KV_COLLECT_RECOMMEND_EXCLUSIVE, mStartUpInfo.aRCoReExclusiveEnable.parameterValue);
        }else{
            LogUtils.d("aRCoReExclusiveEnable", (mStartUpInfo.aRCoReExclusiveEnable!= null)+ " "  );
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("aRCoReExclusiveEnable")) {
                MMKVUtils.getMMKV().remove(TRSharedPreferenceUtils.KV_COLLECT_RECOMMEND_EXCLUSIVE);
            }
        }

        if (mStartUpInfo != null && mStartUpInfo.videoConfig != null && mStartUpInfo.videoConfig.parameterValue != null) {
            MMKVUtils.getMMKV().putInt(Constant.KV_VIDEO_AUTO_CONFIG, mStartUpInfo.videoConfig.parameterValue.autoPlay);
            TrVideoPlayer.autoPlay = mStartUpInfo.videoConfig.parameterValue.autoPlay;
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("videoConfig")){
                MMKVUtils.getMMKV().remove(Constant.KV_VIDEO_AUTO_CONFIG);
                TrVideoPlayer.autoPlay = -1;
            }
        }
        // 桌面动态ICON配置
        if (mStartUpInfo != null && mStartUpInfo.desktopManagerAbilityConfig != null
                &&mStartUpInfo.desktopManagerAbilityConfig.parameterValue!=null
                &&mStartUpInfo.desktopManagerAbilityConfig.parameterValue.curPages!=null) {
            MMKVUtils.getMMKV().putString(Constant.KV_DESKTOP_MANAGER_LIST,new Gson().toJson(mStartUpInfo.desktopManagerAbilityConfig.parameterValue.curPages));
            MMKVUtils.getMMKV().putInt(Constant.KV_DESKTOP_MANAGER_SWITCH,mStartUpInfo.desktopManagerAbilityConfig.parameterValue.configSwitch);
            LauncherDispenseManager.getInstance().refStartUpInfo();
        }

        if (mStartUpInfo != null && mStartUpInfo.hiPushConfig != null && mStartUpInfo.hiPushConfig.parameterValue != null) {
            HiPushEventManager.getInstance().startUp(mStartUpInfo.hiPushConfig.parameterValue.hiPushAppList);
        }else {
            if (!RemoteConfigRepo.INSTANCE.checkConfigVersion("hiPushConfig")){
                MMKVUtils.getMultiMMKV().remove(HiPushEventManager.KV_HIPUSH_WHITE_LIST);
            }
        }

        if(mStartUpInfo!=null && mStartUpInfo.instantAdmobConfig != null) {
            LogUtils.d("instantAdmobConfig",  mStartUpInfo.instantAdmobConfig.parameterValue +" instantAdmobConfig");
            IconAdBusinessManager.Companion.getInstance().updateConfig(mStartUpInfo.instantAdmobConfig.parameterValue);
        }

    }


    private void saveHalfScreenDetailConfig(List<HalfScreenDetailConfigInfo> halfScreenDetailConfig) {
        List<String> halfList = new ArrayList<>();
        String halfScreenDetailString = "";
        for (HalfScreenDetailConfigInfo halfScreenDetailConfigInfo : halfScreenDetailConfig) {
            halfScreenDetailString = halfScreenDetailConfigInfo.appId + "," + halfScreenDetailConfigInfo.style + "," + halfScreenDetailConfigInfo.autoDownload;
            halfList.add(halfScreenDetailString);
        }

        Set<String> set = new HashSet<>(halfList);
        MMKVUtils.getMMKV().putStringSet(Constant.KV_HALFSCREENDETAILCONFIG, set);
    }


    @Override
    public String getFileName(Object... objects) {
        return CACHE_URI;
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
//        String fileName = getFileName();
//
//        if (fileName != null) {
//            FilePathManager.jsonToFile(jsonBuffer, fileName);
//        }

    }

    @Override
    public void loadFromCache(Object... objects) {
        String fileName = getFileName();

        File file = new File(PalmplayApplication.getAppInstance().getFilesDir() + File.separator + fileName);
        if (file != null && file.exists()) {
            JsonElement jsonObject = FilePathManager.fileToJson(fileName);

            Gson gson = new Gson();
            Type curType = new TypeToken<GenericResponseInfo<StartUpInfo>>() {
            }.getType();

            StartUpInfo startUpInfo = null;
            JsonObject dataJE = null;
            try {
                GenericResponseInfo<StartUpInfo> responseInfo = gson.fromJson(jsonObject, curType);
                if (responseInfo != null && responseInfo.isSuccess()) {
                    startUpInfo = responseInfo.data;
                }
                JsonObject json = (JsonObject) jsonObject;
                dataJE = json.has("data") ? json.get("data").getAsJsonObject() : null;
            } catch (Exception e) {
            }
            if (jsonObject != null) {
                initPageCaches(startUpInfo, dataJE, false, false);
                LogUtils.d("Startup read from cache:" + file.getAbsolutePath());
            }

            FileUtils.deleteFile(file);
        }
    }

    public PalmLanguage getPalmLanguage() {
        return mPalmLanguage;
    }

    public String translateStr(String name, String language) {
        if (!TextUtils.isEmpty(name)) {

            PalmLanguage mPalmLanguage = StartUpTabsCache.getInstance().getPalmLanguage();
            if (mPalmLanguage != null && !mPalmLanguage.isNullValue() && mPalmLanguage.existLanValue(language)) {
                name = mPalmLanguage.getTranslateStr(language, name);
            }
        }

        return name;
    }

    public CustomizedInfo getCustomizedDetail(String pkg, String itemID) {
        List<CustomizedInfo> list = getCustomizedList();
        if(list == null || list.size() <= 0) {
            return null;
        }

        Iterator<CustomizedInfo> iterator = list.iterator();
        while (iterator.hasNext()) {
            CustomizedInfo info = iterator.next();
            if(info == null) {
                continue;
            }

            if(!TextUtils.isEmpty(pkg) && TextUtils.equals(info.getPackageName(), pkg)) {
                return info;
            }else if (!TextUtils.isEmpty(itemID) && TextUtils.equals(info.getItemId(), itemID)) {
                return info;
            }
        }

        return null;
    }

    public boolean isCustomizedDetailByPackageName(String pkg) {
        return (getCustomizedDetail(pkg, null) != null);
    }

    public boolean isCustomizedDetailByItemID(String itemID) {
        return (getCustomizedDetail(null, itemID) != null);
    }

    public List<CustomizedInfo> getCustomizedList() {
        if (customizedList == null) {
            customizedList = new ArrayList<>();

            String txt = MMKVUtils.getMMKV().getString(Constant.KV_CUSTOMIZE_LIST, null);
            if (!TextUtils.isEmpty(txt)) {
                try {
                    List<CustomizedInfo> list = new Gson().fromJson(txt, new TypeToken<List<CustomizedInfo>>() {}.getType());
                    if (list != null) {
                        customizedList.clear();
                        customizedList.addAll(list);
                    }
                }catch(Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }

        return customizedList;
    }


    public void updateStartupRequestTime() {
        SPManager.putLong(SP_LAST_REQ_TIME, System.currentTimeMillis());
    }

    /**
     * 启动接口：主页每次启动调用一次，后台JobService和网络切换定时调用
     * @param srcTag   0：启动调用   1：定时调用
     * */
    public static boolean onStartupLoad(int srcTag, IStartUpCallback callback) {

        long diffTime = 0;
        if(Constant.SOURCE_SCHEDULE == srcTag) {
            long lastInterval = SPManager.getLong(SP_LAST_REQ_TIME, 0);
            long currInterval = System.currentTimeMillis();
            diffTime = Math.abs(currInterval - lastInterval);
            if(diffTime < LOAD_INTERVAL) {
                //LogUtils.i("startup load from SCHDULE, and is below 4h");
                ApmAppCacheUtil.getInstance().startCollectCacheTime(ApmAppCacheUtil.start_t, diffTime);
                return false;
            }
        }
        long mLastReqApiTime = System.currentTimeMillis();
        long finalDiffTime = diffTime;
        long firstTime = SPManager.getLong(Constant.SP_FIRST_REQ_TIME, 0);
        if (firstTime <= 0) {
            SPManager.putLong(Constant.SP_FIRST_REQ_TIME, System.currentTimeMillis());
        }
        NetworkClient.startUpHttpRequest(PalmplayApplication.getAppInstance().getApplicationContext()
                , NetworkActions.ACTION_STARTUP, MainActivity.class.getSimpleName(), srcTag, new IStartUpCallback(){

                    @Override
                    public void onRequestSuccess() {
                        if (callback!=null){
                            callback.onRequestSuccess();
                        }
                        ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.start_t,
                                finalDiffTime, mLastReqApiTime, "S",0,0);
                    }

                    @Override
                    public void onRequestFailed() {
                        if (callback!=null){
                            callback.onRequestFailed();
                        }
                        ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.start_t,
                                finalDiffTime, mLastReqApiTime, "");
                    }
                });
        return true;
    }



    public boolean inInUrlWhiteList(String targetUrl) {
        ArrayList<String> urlWhiteList = getUrlWhiteList();
        if (urlWhiteList == null || urlWhiteList.size() == 0) {
            return false;
        }
        return urlWhiteList.contains(targetUrl);
    }

    public ArrayList<String> getUrlWhiteList() {
        if (preloadWhiteList == null) {
            preloadWhiteList = new ArrayList<>();

            Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_WEBVIEW_WHITELIST, null);
            if (set != null) {
                preloadWhiteList.clear();
                preloadWhiteList.addAll(set);
            }

        }

        return preloadWhiteList;
    }

}
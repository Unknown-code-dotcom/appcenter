package com.afmobi.palmplay.cloudfolder.page

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.PorterDuff
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.text.layoutDirection
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import androidx.recyclerview.widget.SnapHelper
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.AttributionUploadManager
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderPreviewManager
import com.afmobi.palmplay.cloudfolder.adapter.CloudBottomAppInfoAdapter
import com.afmobi.palmplay.cloudfolder.adapter.CloudFolderPagerAdapter
import com.afmobi.palmplay.cloudfolder.adapter.CloudShortcutAdapter
import com.afmobi.palmplay.cloudfolder.adapter.NewBottomItemDecoration
import com.afmobi.palmplay.cloudfolder.adapter.ShortcutsSpaceItemDecoration
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.isAdxItem
import com.afmobi.palmplay.cloudfolder.model.*
import com.afmobi.palmplay.cloudfolder.recently.PalmInstalledDBManager
import com.afmobi.palmplay.cloudfolder.recently.RecentlyInstalledHelper
import com.afmobi.palmplay.cloudfolder.recently.RecentlyInstalledTracker
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_BOTTOM_NEW
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_CENTER
import com.afmobi.palmplay.cloudfolder.track.RVExposureHelper
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.CloudFolderLauncher
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.KEY_CLOUD_FOLDER_TYPE
import com.afmobi.palmplay.cloudfolder.utils.PaletteControls
import com.afmobi.palmplay.cloudfolder.utils.TYPE_GET_CACHED
import com.afmobi.palmplay.cloudfolder.utils.WallpaperUtils
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.view.CloudClickPopupWindow
import com.afmobi.palmplay.cloudfolder.view.CloudFolderPauseDialog
import com.afmobi.palmplay.cloudfolder.view.CloudFolderRecyclerView
import com.afmobi.palmplay.cloudfolder.view.FixedRankSectionView
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.mvvm.data.AppDataManager
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.GsonUtils
import com.transsion.palmstorecore.util.NetworkUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.model.FileFolderAdTrackData
import com.transsnet.store.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume


class CloudFolderFragment : BaseCloudFolderFragment() {

    private val TAG = "CloudFolderFragment"

    private var shotCutExposureHelper: RVExposureHelper? = null
    private var mGridAdapter: CloudShortcutAdapter? = null
    private lateinit var mRecyclerView: CloudFolderRecyclerView
    private lateinit var mBottomRecyclerView : RecyclerView
    private lateinit var mBottomLayoutManager : LinearLayoutManager
    private var mBottomAdapter : CloudFolderPagerAdapter ?= null
    private var mNewBottomAdapter: CloudBottomAppInfoAdapter? = null
    private var mRootView: View? = null

    private var mLayoutManager: GridLayoutManager? = null
    private lateinit var searchItem: LinearLayout
    private lateinit var searchIcon: ImageView
    private lateinit var layoutContainer: LinearLayout
    private var iconSearch: ImageView ?= null
    private var textHint: TextView ?= null
    private var textNoNet: TextView ?= null
    private var iconNoNet: ImageView ?= null
    private var layoutSearch: LinearLayout? = null

    private var layoutFolderEmptyContent: LinearLayout? = null
    private var textEmptyContent: TextView? = null
    private var layoutEmptyNoNet: LinearLayout? = null

    // 固定榜单区域
    private var mFixedRankSectionView: FixedRankSectionView? = null
    private var mFixedRankListenerRegistered: Boolean = false
    private var mHasReportedFixedRankExposureInResume: Boolean = false
    private var recentlyInstalledShowResult: RecentlyInstalledHelper.Result? = null
    private var hasReportedRecentlyInstalledShow = false

    // 当前数据的布局样式，用于 spanSizeLookup 判断列数
    private var mLayoutStyle: Int = -1
    private var mHasRendered: Boolean = false

    private var mPopMenuWindow: CloudClickPopupWindow? = null

    private var mPopMenuItemSelectedListener: CloudClickPopupWindow.PopMenuItemSelectedListener? = null
    private var mBottomPopMenuItemSelectedListener: CloudClickPopupWindow.PopMenuItemSelectedListener? = null


    val MAX_ROW = 12

    private var triggerId = ""

    private lateinit var snapHelper : SnapHelper

    private lateinit var customSmoothScroller: CustomSmoothScroller
    private var cancelList = arrayListOf<String>()

    private val paletteControls : PaletteControls by lazy {
        PaletteControls.getInstance(PalmplayApplication.getAppInstance())
    }


    companion object {
        fun createCloudFolder(categoryType: Int) : CloudFolderFragment{
            val cloudFolderFragment = CloudFolderFragment()
            val bundle = Bundle()
            bundle.putInt(KEY_CLOUD_FOLDER_TYPE, categoryType)
            cloudFolderFragment.arguments = bundle
            return cloudFolderFragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val inflate: View = LayoutInflater.from(context)
            .inflate(R.layout.fragment_launcher_shortcuts, container, false)
        mRootView = inflate
        initData(inflate, arguments)
        if (AppDataManager.CLOUD_FOLDER_RECENTLY_INSTALLED_SWITCH) {
            PalmInstalledDBManager.cleanupExpiredIfDue()
        }
        return inflate
    }

    private fun initData(view: View, arguments: Bundle?) {
        mRootView = view
        arguments?.let {
            categoryType = it.getInt(KEY_CLOUD_FOLDER_TYPE)
        }
        val rootView = view.findViewById<RelativeLayout>(R.id.rl_shortcut_root_view)
        textHint = view.findViewById(R.id.textHint)
        iconNoNet = view.findViewById(R.id.iconNoNet)
        iconSearch = view.findViewById(R.id.iconSearch)
        searchItem = view.findViewById(R.id.searchItem)
        textNoNet = view.findViewById(R.id.textNoNet)
        textEmptyContent = view.findViewById(R.id.textEmptyContent)
        layoutSearch = view.findViewById(R.id.layoutSearch)
        // 获取系统语言的布局方向
        try {
            val systemLocale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Resources.getSystem().configuration.locales[0]
            } else {
                @Suppress("DEPRECATION")
                Resources.getSystem().configuration.locale
            }
            // layoutSearch 跟随系统语言方向
            layoutSearch?.layoutDirection = systemLocale.layoutDirection
        }catch (_: Exception) { }
        updateDarkUI()

        // 提前同步读取当前的布局样式，存入内存进行首帧布局控制，避免异步回调时界面发生抖动/跳变
        mLayoutStyle = CloudFolderManager.getInstance().getCloudFolderUiStyle()
        updateLayoutSearchPadding(mLayoutStyle)

        val layoutParams = rootView.layoutParams
        val deviceProfile = DeviceProfile.getInstance()
        layoutParams.height = deviceProfile.getDesiredHeight() +
            deviceProfile.padContentHeightExtra(resources, mLayoutStyle)
        rootView.layoutParams = layoutParams
        applyContentWidth(rootView)
        applyBottomLayout(
            view.findViewById(R.id.layoutBottom),
            view.findViewById(R.id.layoutNewBottom)
        )
        // 固定榜单区域 view 初始化
        mFixedRankSectionView = view.findViewById(R.id.fixedRankSectionView)
        initRecyclerView(view)
        // wakeup 打开时，initBottomRecyclerView 已显示了 CDN 底栏；
        // 必须在首帧渲染前立刻 GONE 掉，否则用户看到 CDN → 拉活的一闪而过。
        if (CloudFolderManager.getInstance()
                .isRecentlyInstalledEnabled(categoryType, mLayoutStyle)
        ) {
            view.findViewById<ConstraintLayout>(R.id.layoutBottom)?.visibility = View.GONE
            view.findViewById<ConstraintLayout>(R.id.layoutNewBottom)?.visibility = View.GONE
        }

        // 首帧直接应用边距和样式控制
        mGridAdapter?.layoutStyle = mLayoutStyle
        applyRecyclerViewSideMargin(mLayoutStyle)

        initTrackEvent()
        initClickEvent(view)
        initCloudFolderData()

    }

    override fun updateDarkUI() {
        try {
            if (WallpaperUtils.getInstance().isLightMode()) {
                iconSearch?.clearColorFilter()
                iconSearch?.setImageResource(R.drawable.ic_folder_search_dark)
                searchItem.setBackgroundResource(R.drawable.bg_folder_search_dark)
                iconNoNet?.setImageResource(R.drawable.ic_cloud_folder_no_net_dark)
                context?.let {
                    textHint?.setTextColor(resources.getColor(R.color.color_cloud_folder_search_dark))
                    textNoNet?.setTextColor(resources.getColor(R.color.color_cloud_folder_search_dark))
                    textEmptyContent?.setTextColor(resources.getColor(R.color.color_cloud_folder_search_dark))
                }
            } else {
                applyPadSearchBarAppearance()
            }
        }catch (e: Exception) {
            LogUtils.e(TAG, e)
        }
    }

    private fun applyPadSearchBarAppearance() {
        if (!DeviceProfile.getInstance().isPadLayout) {
            return
        }
        if (!::searchItem.isInitialized) {
            return
        }
        searchItem.setBackgroundResource(R.drawable.bg_folder_search_pad)
        val contentColor = resources.getColor(R.color.color_cloud_folder_search_content_pad)
        textHint?.setTextColor(contentColor)
        iconSearch?.setImageResource(R.drawable.ic_folder_search)
        iconSearch?.setColorFilter(contentColor, PorterDuff.Mode.SRC_IN)
    }

    private fun initTrackEvent() {
        val folderTag = if (categoryType == CATEGORY_APP) "APP" else "GAME"
        shotCutExposureHelper = RVExposureHelper(
            mRecyclerView
        ) { position: Int ->
            val appInfo = mGridAdapter?.getAppInfo(position) ?: return@RVExposureHelper
            // RANK_SECTION header 由 FixedRankSectionView 自上报 3 个子条目曝光，RV 通用上报跳过
            if (appInfo.rankViewType == BaseFolderUiModel.TYPE_RANK_SECTION) {
                val holder = mRecyclerView.findViewHolderForAdapterPosition(position)
                (holder as? CloudShortcutAdapter.RankSectionViewHolder)
                    ?.sectionView?.reportRankExposure(enterFrom)
                return@RVExposureHelper
            }

            val actualPosition = computeReportPosition(position)
            LogUtils.i(TAG, "onItemExposure: rvPos=$position actualPos=$actualPosition name=${appInfo.name} pkg=${appInfo.packageName} thread=${Thread.currentThread().name}")
            var adType = 0
            if(appInfo.isOffer == Constants.IS_ADX && FileDownloadInfo.STATUS_NONE == appInfo.observerStatus) {
                if (TextUtils.isEmpty(triggerId)) {
                    triggerId = CloudFolderManager.getInstance().generateTriggerId()
                }
                adType = 1
                val trackList = arrayListOf(
                    FileFolderAdTrackData(
                        appInfo.packageName,
                        triggerId,
                        CloudFolderManager.getInstance().generateShowId()
                    )
                )

                CloudFolderManager.getInstance().uploadAdxExposure(GsonUtils.getInstance().toJson(trackList), categoryType)
            } else if(appInfo.isPreInstallItem()) {
                adType = 10;
            }
            if(appInfo.isOtherType()) {
                //三方应用上报
                AttributionUploadManager.getInstance().enqueueNewRequest(
                    appInfo.showTracking,
                    appInfo.name
                )
            }
            LogUtils.i(TAG, "onItemExposure: >>> track actualPos=$actualPosition pkg=${appInfo.packageName} adType=$adType")
            CloudFolderTrackUtil.businessItemExposureTrack(
                actualPosition,
                appInfo.packageName,
                CloudFolderTrackUtil.getDownloadStatus(appInfo.observerStatus),
                enterFrom,
                categoryType,
                adType,
                appInfo.jumpType,
                cfValue = appInfo.getCloudStyleString(),
            )

        }
    }

    /**
     * 计算埋点上报用的应用绝对 position（应用在数据流中的 index）：
     * - 存在榜单区域（固定榜单可见 或 RV 头部为 RANK_SECTION）：actualPosition = rvPos + 3
     * - 其他情况：actualPosition = rvPos
     */
    private fun computeReportPosition(rvPos: Int): Int {
        return rvPos + (mGridAdapter?.clickPositionOffset ?: 0)
    }

    private fun initClickEvent(view: View) {
        searchIcon = view.findViewById(R.id.searchIcon)
        layoutContainer = view.findViewById(R.id.layoutContainer)
        layoutFolderEmptyContent = view.findViewById(R.id.layoutFolderEmptyContent)
        layoutEmptyNoNet = view.findViewById(R.id.layoutEmptyNoNet)
        layoutContainer.setOnClickListener {
            activity?.let {
                if (!it.isFinishing) {
                    it.finish()
                }
            }
        }

        searchItem.setOnClickListener {
            CloudFolderTrackUtil.tecTrack(
                CloudFolderTrackUtil.TYPE_CLICK,
                CloudFolderTrackUtil.STATUS_CLICK_ICON,
                "",
                categoryType.toString()
            )

            CloudFolderManager.getInstance().goToPsSearchPage(categoryType)
        }

        searchIcon.setOnClickListener {
            CloudFolderTrackUtil.tecTrack(
                CloudFolderTrackUtil.TYPE_CLICK,
                CloudFolderTrackUtil.STATUS_CLICK_SEARCH,
                "",
                categoryType.toString()
            )

            CloudFolderManager.getInstance().goToPsHomePage(categoryType)
        }
    }

    private fun initRecyclerView(view: View) {
        context?.let {
            mRecyclerView = view.findViewById(R.id.shortcut_recyclerView)
            applyRecyclerViewSideMargin(mLayoutStyle)
            mLayoutManager = GridLayoutManager(context, MAX_ROW)
            mLayoutManager?.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    val viewType = mGridAdapter?.getItemViewType(position)
                    // SECTION header 占整行
                    if (viewType == CloudShortcutAdapter.VIEW_TYPE_RANK_SECTION) return MAX_ROW
                    // 样式3 (LAYOUT_STYLE_RANK_LIST) 下应用为 4 列，其余均 3 列
                    return if (mLayoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST) {
                        3 // 4 items per row (12 / 3)
                    } else {
                        4 // 3 items per row (12 / 4)
                    }
                }
            }
            mRecyclerView.layoutManager = mLayoutManager
            mGridAdapter =
                CloudShortcutAdapter(
                    it, categoryType
                )
            val space = resources.getDimensionPixelSize(R.dimen.dp_24)
            mRecyclerView.addItemDecoration(ShortcutsSpaceItemDecoration(space, 0))
            mRecyclerView.adapter = mGridAdapter
            mGridAdapter?.setGridLayoutManager(mLayoutManager)
            val itemAnimator = mRecyclerView.itemAnimator
            if (itemAnimator is SimpleItemAnimator) {
                itemAnimator.supportsChangeAnimations =
                    false //解决刷新单个item时，该item闪烁的问题
            }

            mPopMenuItemSelectedListener = object : CloudClickPopupWindow.PopMenuItemSelectedListener {
                override fun onItemClicked(itemInfo: Any?, menuStr: String, position: Int) {
                    handlePopMenuItemClick(itemInfo, menuStr, position, false)
                }
            }

            mBottomPopMenuItemSelectedListener = object : CloudClickPopupWindow.PopMenuItemSelectedListener {
                override fun onItemClicked(itemInfo: Any?, menuStr: String, position: Int) {
                    handlePopMenuItemClick(itemInfo, menuStr, position, true)
                }
            }

            mGridAdapter?.apply {
                setOnItemClickListener(object : CloudShortcutAdapter.OnRecyclerViewItemClickListener{

                    override fun onItemLongClick(view: View?) {
                        mGridAdapter?.let { adapter->
                            val pos = view!!.tag as Int
                            if (pos >= 0 && pos < adapter.itemCount) {
                                val appInfo = mGridAdapter?.getAppInfo(pos) ?: return
                                if(appInfo.observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED && !appInfo.isPreInstallItem()) {
                                    return
                                }
                                if (null == mPopMenuWindow) {
                                    mPopMenuWindow =
                                        CloudClickPopupWindow(PalmplayApplication.getAppInstance(), appInfo, pos)
                                }
                                mPopMenuWindow?.setData(
                                    appInfo,
                                    pos,
                                    mPopMenuItemSelectedListener
                                )
                                mPopMenuWindow?.onShow(view)

                            }
                        }
                    }

                    override fun onItemClick(appInfo: AppInfo) {
                        activity?.apply {
                            if (isFinishing || isDestroyed) {
                                DownloadManager.getInstance().cancelDownload(packageName)
                                return
                            }
                            if (!NetworkUtils.NET_WIFI.equals(
                                    NetworkUtils.getNetworkState(context),true)) {
                                CloudFolderPauseDialog(
                                    this,
                                    CloudFolderPauseDialog.STYLE_PAUSE,
                                    { status ->
                                        if (status == CloudFolderPauseDialog.STATUS_CONFIRM) {
                                            DownloadManager.getInstance()
                                                .pauseDownloadForRetieveDownload(appInfo.packageName)
                                        }
                                    }).show()
                            }
                        }
                    }

                })
            }
        }
    }

    private fun initBottomRecyclerView(view: View, fixedBottomList: List<CloudAppInfo>) {
        mBottomRecyclerView = view.findViewById(R.id.recyclerBottom)
        val bottomIconLayout = view.findViewById<ConstraintLayout>(R.id.layoutBottom)
        val layoutNewBottom = view.findViewById<ConstraintLayout>(R.id.layoutNewBottom)
        val ivRefresh = view.findViewById<ImageView>(R.id.ivRefresh)
        val layoutRefresh = view.findViewById<ConstraintLayout>(R.id.layoutRefresh)
        val tvNewHeaderV = view.findViewById<TextView>(R.id.textNewHeader)
        applyBottomLayout(bottomIconLayout, layoutNewBottom)
        // 初始化布局管理器
        mBottomLayoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        mBottomRecyclerView.setLayoutManager(mBottomLayoutManager);

        tvNewHeaderV?.text = ctx().getString(R.string.text_cloud_folder_bottom_title)
        // 准备数据
        val bottomList =
            CloudFolderManager.getInstance().getBottomIconListByFolder(categoryType)
        if(bottomList.isNullOrEmpty()) {
            bottomIconLayout.visibility = View.GONE
            initNewBottomLayout(fixedBottomList)
        } else {
            setBottomModuleVisibility(layoutNewBottom, false)
            setBottomModuleVisibility(bottomIconLayout, true)
            if(bottomList.size > 4) {
                layoutRefresh.visibility = View.VISIBLE
            } else {
                layoutRefresh.visibility = View.GONE
            }
            mBottomAdapter = CloudFolderPagerAdapter(categoryType, bottomList.chunked(4))
            // 设置适配器
            mBottomRecyclerView.setAdapter(mBottomAdapter);



            setupPagination()

            layoutRefresh.setOnClickListener {
                val rotateAnimator = ObjectAnimator.ofFloat(ivRefresh, "rotation", 0f, -720f)
                // 设置动画持续时间
                rotateAnimator.setDuration(600)
                // 启动动画
                rotateAnimator.start()

                smoothScrollToNextPage()
            }
        }
    }

    private fun initNewBottomLayout(fixedBottomList: List<CloudAppInfo>) {
        val view = mRootView ?: return
        val layoutNewBottom = view.findViewById<ConstraintLayout>(R.id.layoutNewBottom)
        val recyclerNewBottom = view.findViewById<RecyclerView>(R.id.recyclerNewBottom)
        if (fixedBottomList.isEmpty()) {
            layoutNewBottom.visibility = View.GONE
        } else {
            setBottomModuleVisibility(layoutNewBottom, true)

            val layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            recyclerNewBottom.layoutManager = layoutManager
            val itemAnimator = recyclerNewBottom.itemAnimator
            if (itemAnimator is SimpleItemAnimator) {
                itemAnimator.supportsChangeAnimations =
                    false //解决刷新单个item时，该item闪烁的问题
            }

            if (recyclerNewBottom.itemDecorationCount == 0) {
                recyclerNewBottom.addItemDecoration(
                    NewBottomItemDecoration(
                        fixedBottomList.size
                    )
                )
            }

            mNewBottomAdapter = CloudBottomAppInfoAdapter(categoryType, fixedBottomList)
            mNewBottomAdapter?.layoutStyle = mLayoutStyle
            mNewBottomAdapter?.onLongClickListener = { view, pos, appInfo ->
                if (appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED || appInfo.isPreInstallItem()) {
                    if (null == mPopMenuWindow) {
                        mPopMenuWindow = CloudClickPopupWindow(PalmplayApplication.getAppInstance(), appInfo, pos)
                    }
                    mPopMenuWindow?.setData(
                        appInfo,
                        pos,
                        mBottomPopMenuItemSelectedListener
                    )
                    mPopMenuWindow?.onShow(view)
                }
            }
            recyclerNewBottom.adapter = mNewBottomAdapter
            mNewBottomAdapter?.onCreateView()
        }
    }

    private fun handlePopMenuItemClick(itemInfo: Any?, menuStr: String, position: Int, isBottom: Boolean) {
        if (itemInfo == null) {
            return
        }
        val appInfo = itemInfo as CloudAppInfo
        val sceneTag = if (isBottom) SCENE_BOTTOM_NEW else SCENE_CENTER
        val actualPos = if (isBottom || appInfo.rankViewType == BaseFolderUiModel.TYPE_RANK_SECTION) {
            position
        } else {
            computeReportPosition(position)
        }

        if(appInfo.isOtherType()) {
            val launchType = CloudFolderLauncher.launchFromOtherType(appInfo)
            CloudFolderTrackUtil.businessItemClickTrack(
                actualPos,
                CloudFolderTrackUtil.BUTTON_TYPE_INSTALL,
                appInfo.packageName,
                categoryType,
                appInfo.isOffer,
                appInfo.jumpType,
                launchType, sceneTag = sceneTag,
                cfValue = appInfo.getCloudStyleString(),
            )
            return
        }
        if(appInfo.isPreInstallItem()) {
            CloudFolderLauncher.launchFromPreinstallItem(actualPos, appInfo, menuStr, categoryType) {
                initCloudFolderData(true)
            }
            return
        }
        val eventName: String = if (TextUtils.equals(menuStr, getString(R.string.text_uninstall))) {
            DownloadManager.getInstance().cancelDownload(appInfo.packageName)
            CloudFolderTrackUtil.BUTTON_TYPE_CANCEL
        } else if(TextUtils.equals(menuStr, getString(R.string.text_install))) {
            val sign = if (categoryType == CATEGORY_APP) "A" else "G"
            val scene = if(isBottom) {
                SCENE_BOTTOM_NEW
            } else {
                SCENE_CENTER
            }
            val fromPage = "FL_${sign}_${scene}_$actualPos"
            CloudFolderManager.getInstance().startDownload(appInfo, categoryType, fromPage)
            CloudFolderTrackUtil.BUTTON_TYPE_INSTALL
        } else {
            val sign = if (categoryType == CATEGORY_APP) "A" else "G"
            val isAdx = appInfo.isAdxItem()
            val valueScene = if (isAdx) CloudFolderTrackUtil.SCENE_ADX else sceneTag
            val value = "FL_${sign}_${valueScene}_$actualPos"
            CloudFolderManager.getInstance().showAppDetailPage(
                isAdx,
                appInfo.packageName,
                categoryType,
                value,
                appInfo.getCloudStyleString(),
            )
            CloudFolderTrackUtil.BUTTON_TYPE_OPEN
        }

        // Use generic businessItemClickTrack or handle specific bottom tracking if available.
        CloudFolderTrackUtil.businessItemClickTrack(
            actualPos,
            eventName,
            appInfo.packageName,
            categoryType,
            appInfo.isOffer,
            sceneTag = sceneTag,
            cfValue = appInfo.getCloudStyleString(),
        )
    }

    //每次OnResume进入，均需要刷新底部adapter
    private var isFirst = true

    override fun onResume() {
        super.onResume()
        refreshLayoutForCurrentDevice()
        if(isFirst) {
            isFirst = false
        } else {
            mBottomAdapter?.notifyDataSetChanged()
        }
        reportBottomExposure()
        reportFixedRankExposureOnce()
        if (mFixedRankListenerRegistered) {
            mFixedRankSectionView?.registerDownloadListener()
        }
        mGridAdapter?.onStart()
        shotCutExposureHelper?.checkExposure()

        if(!loadRecentlyInstalledBottom()) {
            reportBottomExposure()
        }

    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        mRootView?.post {
            if (isAdded) {
                refreshLayoutForCurrentDevice()
            }
        }
    }

    /**
     * 异步查询并刷新底部「最近安装」。
     */
    private fun loadRecentlyInstalledBottom(): Boolean {
        if (!CloudFolderManager.getInstance()
                .isRecentlyInstalledEnabled(categoryType, mLayoutStyle)
        ) {
            LogUtils.d("RecentlyInstalled", "【云文件夹】云控wakeup.switchStatus未开启本品类($categoryType)，跳过")
            return false
        }
        val rootView = mRootView ?: return false
        val ctx = context ?: return false
        val appCtx = ctx.applicationContext
        LogUtils.d("RecentlyInstalled", "【云文件夹】onResume触发加载最近安装，categoryType=$categoryType")
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    RecentlyInstalledHelper.getPalmInstalledApps(appCtx, categoryType)
                } catch (e: Throwable) {
                    LogUtils.e(TAG, e)
                    RecentlyInstalledHelper.Result.EMPTY
                }
            }
            if (!isAdded || view == null) {
                LogUtils.d("RecentlyInstalled", "【云文件夹】fragment已分离，丢弃结果 size=${result.shownList.size}")
                return@launch
            }
            recentlyInstalledShowResult = result
            if (LogUtils.debug) {
                LogUtils.d("RecentlyInstalled", "【云文件夹】渲染底栏 size=${result.shownList.size} 包名=${result.shownList.map { it.packageName }}")
            }
            renderRecentlyInstalledBottom(rootView, result.shownList)
            tryReportRecentlyInstalledShow()
        }
        return true
    }

    private fun renderRecentlyInstalledBottom(rootView: View, recentList: List<CloudAppInfo>) {
        val layoutNewBottom = rootView.findViewById<ConstraintLayout>(R.id.layoutNewBottom)
        val recyclerNewBottom = rootView.findViewById<RecyclerView>(R.id.recyclerNewBottom)
        val tvNewHeader = rootView.findViewById<TextView>(R.id.textNewHeader)
        if (layoutNewBottom == null || recyclerNewBottom == null) return
        if (recentList.isEmpty()) {
            // 开关打开时，CDN 底栏和拉活底栏互斥；
            // 需要同时隐藏 CDN 底栏，否则首次进入时 initBottomRecyclerView 已将其置为 VISIBLE。
            LogUtils.d("RecentlyInstalled", "【云文件夹】最近安装列表为空，隐藏拉活底栏和CDN底栏")
            mNewBottomAdapter?.onDestroy()
            mNewBottomAdapter = null
            recyclerNewBottom.adapter = null
            layoutNewBottom.visibility = View.GONE
            rootView.findViewById<ConstraintLayout>(R.id.layoutBottom)?.visibility = View.GONE
            return
        }

        // 1. 隐藏旧 CDN 底栏，显示新底栏
        rootView.findViewById<ConstraintLayout>(R.id.layoutBottom)?.visibility = View.GONE
        setBottomModuleVisibility(layoutNewBottom, true)

        // 2. 文案专属替换：覆盖 CDN 下发标题
        tvNewHeader?.text = ctx().getString(R.string.recently_installed)

        // 3. 渲染新数据
        if (recyclerNewBottom.layoutManager == null) {
            recyclerNewBottom.layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            (recyclerNewBottom.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
        }
        if (recyclerNewBottom.itemDecorationCount == 0) {
            recyclerNewBottom.addItemDecoration(
                NewBottomItemDecoration(recentList.size)
            )
        }

        val existing = mNewBottomAdapter
        if (existing != null) {
            // 销毁旧 adapter 的 listener 引用，避免泄漏
            existing.onDestroy()
        }
        val newAdapter = CloudBottomAppInfoAdapter(categoryType, recentList)

        recyclerNewBottom.adapter = newAdapter
        newAdapter.onCreateView()
        mNewBottomAdapter = newAdapter
    }

    private fun ctx() = requireContext()

    override fun refreshIconStyle() {
        mGridAdapter?.notifyDataSetChanged()
        mFixedRankSectionView?.refreshIconStyle()
        mBottomAdapter?.notifyDataSetChanged()
        mNewBottomAdapter?.notifyDataSetChanged()
    }

    private fun tryReportRecentlyInstalledShow() {
        if (!isResumed || shouldHideBottomModule() || hasReportedRecentlyInstalledShow) return
        val result = recentlyInstalledShowResult ?: return
        if (result.shownList.isEmpty()) return
        RecentlyInstalledTracker.reportShow(result.shownList, result.unactivatedTotal, categoryType)
        hasReportedRecentlyInstalledShow = true
    }

    private fun reportBottomExposure() {
        if (!isResumed || shouldHideBottomModule()) return
        val adapter = mNewBottomAdapter ?: return
        for (position in 0 until adapter.itemCount) {
            val appInfo = adapter.getAppInfo(position) ?: continue
            CloudFolderTrackUtil.businessItemExposureTrack(
                position,
                appInfo.packageName,
                CloudFolderTrackUtil.getDownloadStatus(appInfo.observerStatus),
                1,
                categoryType,
                appInfo.isOffer,
                appInfo.jumpType,
                sceneTag = SCENE_BOTTOM_NEW,
                cfValue = appInfo.getCloudStyleString(),
            )
        }
    }

    private fun setupPagination() {
        // 1. 设置每页显示4个条目 (防止重复添加)
        if (mBottomRecyclerView.itemDecorationCount == 0) {
            mBottomRecyclerView.addItemDecoration(ItemDecoration(requireContext()))
        }

        // 2. 添加分页滑动效果 (防止重复绑定引发 IllegalStateException)
        if (mBottomRecyclerView.onFlingListener == null) {
            snapHelper = PagerSnapHelper()
            snapHelper.attachToRecyclerView(mBottomRecyclerView)
        }
    }

    // 自定义ItemDecoration，用于设置每个item的宽度（屏幕宽度 - padding * 2）
    class ItemDecoration(private val context: Context) : RecyclerView.ItemDecoration() {
        override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
            super.getItemOffsets(outRect, view, parent, state)

            if (DeviceProfile.getInstance().isPadLayout) {
                return
            }
            // 计算每个item的宽度
            val screenWidth = context.resources.displayMetrics.widthPixels
            val padding = DeviceProfile.getInstance().folderBottomPadding * 2 // 左右padding各8dp，共16dp
            // 设置item的宽度
            view.layoutParams.width = screenWidth - padding
        }
    }

    private fun smoothScrollToNextPage() {

        var nextPageStart = mBottomLayoutManager.findFirstVisibleItemPosition() + 1
        //滚动速度
        var speed = 100f
        if (nextPageStart >= (mBottomAdapter?.itemCount ?: 0)) {
            nextPageStart = 0
            speed = 25f
        }
        customSmoothScroller = CustomSmoothScroller(requireContext())
        customSmoothScroller.speed = speed
        customSmoothScroller.targetPosition = nextPageStart
        mBottomLayoutManager.startSmoothScroll(customSmoothScroller)
    }

    fun initCloudFolderData(isNeedRefresh : Boolean = false) {
        lifecycleScope.launchWhenCreated {
            val viewData = getCloudFolderData()
            if (mHasRendered && viewData != null && viewData.layoutStyle != mLayoutStyle) {
                LogUtils.w(TAG, "initCloudFolderData: layoutStyle mismatch! cached=$mLayoutStyle, remote=${viewData.layoutStyle}. Skip refresh to prevent layout jump.")
                return@launchWhenCreated
            }
            mHasRendered = true
            mGridAdapter?.layoutStyle = mLayoutStyle
            val folderInfo = if(categoryType == CATEGORY_APP) FOLDER.APPS else FOLDER.GAMES
            if(viewData == null || viewData.scrollableItems.isEmpty()) {
                CloudFolderManager.getInstance().showEmptyCloudFolderPreviewImage(folderInfo, folderInfo.defaultDrawable)
                mGridAdapter?.setListData(null)
                dealEmptyLayout()
                adjustRootHeightByLayoutStyle(mLayoutStyle)
            } else {
                // 判断是否需要固定榜单区域 (样式2、3 且 fixRankTile=true)
                val isFixedRank = viewData.fixRankTile &&
                    (mLayoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_GRID ||
                            mLayoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST)

                // 预览图需要包含全部应用（含固定榜单区域的应用），先用完整 scrollableItems 生成
                val previewItems = viewData.scrollableItems.mapNotNull { item ->
                    when (item) {
                        is NormalAppUiModel -> item.appInfo
                        is RankAppUiModel -> item.appInfo
                        is RankTitleUiModel -> item.appInfo
                        else -> null
                    }
                }
                val previewImageFromData =
                    CloudFolderPreviewManager.getInstance().generatePreviewImageFromData(folderInfo, previewItems, isNeedRefresh)
                if (previewImageFromData != null) {
                    withContext(Dispatchers.IO) {
                        CloudFolderManager.getInstance().updateFolder(folderInfo, previewImageFromData)
                    }
                }

                val gridItems: List<CloudAppInfo>
                if (isFixedRank) {
                    // 提取 RankTitleUiModel 条目（带皇冠的榜单应用），放到固定区域
                    val rankApps = viewData.scrollableItems.filterIsInstance<RankTitleUiModel>()
                        .mapIndexed { idx, item ->
                            item.appInfo.apply {
                                rankViewType = BaseFolderUiModel.TYPE_RANK_SECTION
                                rankIndex = idx
                            }
                        }
                    setupFixedRankSection(rankApps)
                    // onResume 时数据未就绪（rankApps 为空）会被守卫跳过，此处补报首次曝光
                    if (isResumed) {
                        reportFixedRankExposureOnce()
                    }
                    mGridAdapter?.clickPositionOffset = rankApps.size

                    // RecyclerView 只展示普通应用和普通榜单应用
                    gridItems = viewData.scrollableItems.mapNotNull { item ->
                        when (item) {
                            is NormalAppUiModel -> item.appInfo
                            is RankAppUiModel -> item.appInfo
                            else -> null
                        }
                    }
                } else {
                    // 隐藏固定榜单区域
                    mFixedRankSectionView?.hide()
                    if (mFixedRankListenerRegistered) {
                        mFixedRankSectionView?.unregisterDownloadListener()
                        mFixedRankListenerRegistered = false
                    }
                    // RecyclerView layout_below 恢复为 layoutSearch。
                    // topMargin 走 applyRecyclerViewSideMargin：Pad 非固定用独立 token，勿写死。
                    (mRecyclerView.layoutParams as? RelativeLayout.LayoutParams)?.apply {
                        addRule(RelativeLayout.BELOW, R.id.layoutSearch)
                        mRecyclerView.layoutParams = this
                    }
                    applyRecyclerViewSideMargin(mLayoutStyle)
                    mRecyclerView.requestLayout()

                    // 抽出开头连续的最多 3 个 RankTitleUiModel，打包成 RV header（VIEW_TYPE_RANK_SECTION）
                    val rankTitles = viewData.scrollableItems
                        .takeWhile { it is RankTitleUiModel }
                        .filterIsInstance<RankTitleUiModel>()
                        .take(3)
                        .map { it.appInfo.apply { rankViewType = BaseFolderUiModel.TYPE_RANK_SECTION } }
                    val rest = viewData.scrollableItems.drop(rankTitles.size)

                    val items = mutableListOf<CloudAppInfo>()
                    if (rankTitles.isNotEmpty()) {
                        items += CloudAppInfo().apply {
                            // sentinel 包名：避免被下载链路按 packageName 匹配命中
                            packageName = "__rank_section__"
                            rankViewType = BaseFolderUiModel.TYPE_RANK_SECTION
                            rankIndex = -1
                            rankSectionApps = rankTitles
                        }
                        mGridAdapter?.clickPositionOffset = rankTitles.size - 1
                    } else {
                        mGridAdapter?.clickPositionOffset = 0
                    }
                    var rankCounter = 0
                    rest.forEach { item ->
                        when (item) {
                            is NormalAppUiModel -> items += item.appInfo.apply {
                                rankViewType = 0
                                rankIndex = -1
                            }
                            is RankAppUiModel -> items += item.appInfo.apply {
                                rankViewType = BaseFolderUiModel.TYPE_RANK_APP
                                rankIndex = rankCounter++
                            }
                            is RankTitleUiModel -> {
                                // 业务约定：皇冠 app 最多 3 个，已被 takeWhile.take(3) 抽走，
                                // 不应再出现在 rest 中。若发生则丢弃。
                            }
                        }
                    }
                    gridItems = items
                }

                layoutFolderEmptyContent?.visibility = View.GONE
                // 桥接 RANK_SECTION header 的回调与曝光埋点入参
                mGridAdapter?.apply {
                    sectionOnLongClick = { v, idx, info ->
                        if (info.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
                            if (null == mPopMenuWindow) {
                                mPopMenuWindow = CloudClickPopupWindow(PalmplayApplication.getAppInstance(), info, idx)
                            }
                            mPopMenuWindow?.setData(info, idx, mPopMenuItemSelectedListener)
                            mPopMenuWindow?.onShow(v)
                        }
                    }
                }
                mGridAdapter?.setListData(gridItems)

                // 数据/榜单区域已就绪，再调整根容器高度（依赖 FixedRankSectionView 的可见性）
                adjustRootHeightByLayoutStyle(mLayoutStyle)

                // 使用 CloudFolderViewData 中的底部数据驱动新底部布局
                if (viewData.showFixedBottom) {
                    val view = mRootView ?: return@launchWhenCreated
                    initBottomRecyclerView(view, viewData.fixedBottomList)
                    reportBottomExposure()
                } else {
                    if (!CloudFolderManager.getInstance()
                            .isRecentlyInstalledEnabled(categoryType, mLayoutStyle)
                    ) {
                        val view = mRootView ?: return@launchWhenCreated
                        view.findViewById<View>(R.id.layoutBottom)?.visibility = View.GONE
                        view.findViewById<View>(R.id.layoutNewBottom)?.visibility = View.GONE
                    }
                }
                mRecyclerView.post {
                    shotCutExposureHelper?.checkExposure()
                }
            }
        }
    }

    /**
     * 根据布局样式调整 RecyclerView 的左右外边距。
     * 手机 4 列模式（LAYOUT_STYLE_RANK_LIST 普通条目）下水平空间更紧张，
     * 减小 RV margin 为 item 间距留出余量；Pad 保持常规侧边距。
     * Pad 非固定榜单：搜索到 RV 用独立 token；固定榜单仍为手机值 + padSpaceExtra。
     */
    private fun applyRecyclerViewSideMargin(layoutStyle: Int) {
        if (!::mRecyclerView.isInitialized) return
        val deviceProfile = DeviceProfile.getInstance()
        val isPadLayout = deviceProfile.isPadLayout
        val marginRes = if (
            !isPadLayout && layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST
        ) {
            R.dimen.dp_10
        } else {
            R.dimen.dp_20
        }
        val target = resources.getDimensionPixelSize(marginRes)
        val params = mRecyclerView.layoutParams as? ViewGroup.MarginLayoutParams ?: return
        val rankVisible = mFixedRankSectionView?.visibility == View.VISIBLE
        val targetTop = deviceProfile.recyclerViewTopMargin(resources, rankVisible)
        if (params.marginStart != target || params.marginEnd != target || params.topMargin != targetTop) {
            params.marginStart = target
            params.marginEnd = target
            params.topMargin = targetTop
            mRecyclerView.layoutParams = params
            // margin 变更要等 parent 下一帧重测才会反映到 parent.width；
            // ItemDecoration 的 outRect 依赖 parent.width 计算，必须等新宽度生效后再失效全部装饰，
            // 否则首帧仍按旧宽度计算，notifyItemChanged 时被刷新的 item 拿到新宽度算出的 outRect，发生跳动。
//            mRecyclerView.post { mRecyclerView.invalidateItemDecorations() }
        }
    }

    /**
     * 根据布局样式调整 layoutSearch 顶部搜索栏的 padding。
     * 手机样式 1/4 为 52dp；Pad 与样式 2 对齐，统一走 padSearchSidePadding。
     */
    private fun updateLayoutSearchPadding(layoutStyle: Int) {
        val searchView = layoutSearch ?: mRootView?.findViewById(R.id.layoutSearch) ?: return
        val deviceProfile = DeviceProfile.getInstance()
        val paddingPx = if (deviceProfile.isPadLayout) {
            deviceProfile.padSearchSidePadding(resources)
        } else if (
            layoutStyle == CloudFolderManager.LAYOUT_STYLE_SIMPLE_RANK ||
            layoutStyle == CloudFolderManager.LAYOUT_STYLE_ORIGINAL
        ) {
            dip2px(52f)
        } else {
            dip2px(40f)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            searchView.setPaddingRelative(paddingPx, searchView.paddingTop, paddingPx, searchView.paddingBottom)
        } else {
            searchView.setPadding(paddingPx, searchView.paddingTop, paddingPx, searchView.paddingBottom)
        }
    }

    private fun applyContentWidth(rootView: RelativeLayout) {
        val deviceProfile = DeviceProfile.getInstance()
        val rootParams = rootView.layoutParams
        rootParams.width = if (deviceProfile.isPadLayout) {
            deviceProfile.getDesiredWidth()
        } else {
            ViewGroup.LayoutParams.MATCH_PARENT
        }
        rootView.layoutParams = rootParams

        val searchView = layoutSearch ?: return
        val searchParams = searchView.layoutParams as? RelativeLayout.LayoutParams ?: return
        if (deviceProfile.isPadLayout) {
            val alignedWidth = deviceProfile.getPadSearchContainerWidth(resources)
            if (deviceProfile.getDesiredWidth() > alignedWidth) {
                searchParams.width = alignedWidth
                searchParams.addRule(RelativeLayout.CENTER_HORIZONTAL)
            } else {
                searchParams.width = ViewGroup.LayoutParams.MATCH_PARENT
                searchParams.removeRule(RelativeLayout.CENTER_HORIZONTAL)
            }
        } else {
            searchParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            searchParams.removeRule(RelativeLayout.CENTER_HORIZONTAL)
        }
        searchView.layoutParams = searchParams
    }

    /**
     * 旧 CDN 底栏和新底栏共用同一套场景化间距：
     * - 手机：保留 XML 定义的 55dp 水平 padding 和 30dp 顶部间距；
     * - Pad 竖屏：底栏与中间列表同宽，顶部间距为 45dp（相对手机多 15dp）；
     * - Pad 横屏：底部推荐隐藏，顶部间距收紧为 10dp。
     */
    private fun applyBottomLayout(
        bottomLayout: ConstraintLayout,
        newBottomLayout: ConstraintLayout
    ) {
        val deviceProfile = DeviceProfile.getInstance()
        applyBottomContentPadding(bottomLayout, deviceProfile)
        applyBottomContentPadding(newBottomLayout, deviceProfile)
        val topMargin = if (deviceProfile.isPadLayout) {
            deviceProfile.padBottomTopMargin(resources)
        } else {
            resources.getDimensionPixelSize(R.dimen.dp_30)
        }
        updateTopMargin(bottomLayout, topMargin)
        updateTopMargin(newBottomLayout, topMargin)
    }

    /** Pad 横屏不展示底部推荐，竖屏恢复时沿用已加载的底部数据。 */
    private fun shouldHideBottomModule(): Boolean {
        return DeviceProfile.getInstance().isPadLayout &&
                resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    private fun setBottomModuleVisibility(view: View?, shouldShow: Boolean) {
        view?.visibility = if (shouldShow && !shouldHideBottomModule()) {
            View.VISIBLE
        } else {
            View.GONE
        }
    }

    private fun refreshBottomModuleVisibility(
        bottomLayout: ConstraintLayout,
        newBottomLayout: ConstraintLayout
    ) {
        if (shouldHideBottomModule()) {
            bottomLayout.visibility = View.GONE
            newBottomLayout.visibility = View.GONE
            return
        }
        if (CloudFolderManager.getInstance().isRecentlyInstalledEnabled(categoryType, mLayoutStyle)) {
            bottomLayout.visibility = View.GONE
            setBottomModuleVisibility(newBottomLayout, mNewBottomAdapter != null)
        } else if (mNewBottomAdapter != null) {
            bottomLayout.visibility = View.GONE
            setBottomModuleVisibility(newBottomLayout, true)
        } else {
            newBottomLayout.visibility = View.GONE
            setBottomModuleVisibility(bottomLayout, mBottomAdapter != null)
        }
    }

    private fun applyBottomContentPadding(
        bottomLayout: ConstraintLayout,
        deviceProfile: DeviceProfile
    ) {
        val (paddingStart, paddingEnd) = if (deviceProfile.isPadLayout) {
            val currentWidth = resources.displayMetrics.widthPixels
            val outerOffset = ((currentWidth - deviceProfile.getAvailableWidthPx()) / 2)
                .coerceAtLeast(0)
            outerOffset + deviceProfile.bottomIconInnerPadding to
                outerOffset + deviceProfile.bottomIconInnerPaddingEnd
        } else {
            deviceProfile.folderBottomPadding to deviceProfile.folderBottomPadding
        }
        bottomLayout.setPaddingRelative(
            paddingStart,
            bottomLayout.paddingTop,
            paddingEnd,
            bottomLayout.paddingBottom
        )
    }

    private fun updateTopMargin(view: View, topMargin: Int) {
        val params = view.layoutParams as? LinearLayout.LayoutParams ?: return
        if (params.topMargin != topMargin) {
            params.topMargin = topMargin
            view.layoutParams = params
        }
    }

    private fun refreshLayoutForCurrentDevice() {
        val root = mRootView ?: return
        DeviceProfile.getInstance().initData(root.context)
        updateDarkUI()
        val content = root.findViewById<RelativeLayout>(R.id.rl_shortcut_root_view)
        applyContentWidth(content)
        applyRecyclerViewSideMargin(mLayoutStyle)
        adjustRootHeightByLayoutStyle(mLayoutStyle)
        if (::mRecyclerView.isInitialized) {
            mRecyclerView.post {
                mRecyclerView.invalidateItemDecorations()
                refreshVisibleRankSection(mRecyclerView.width)
            }
        } else {
            mFixedRankSectionView?.refreshPadItemSpacing()
        }

        val bottomLayout = root.findViewById<ConstraintLayout>(R.id.layoutBottom)
        val newBottomLayout = root.findViewById<ConstraintLayout>(R.id.layoutNewBottom)
        applyBottomLayout(bottomLayout, newBottomLayout)
        refreshBottomModuleVisibility(bottomLayout, newBottomLayout)
        tryReportRecentlyInstalledShow()
        if (!shouldHideBottomModule()) {
            reportBottomExposure()
        }
        if (::mBottomRecyclerView.isInitialized) {
            mBottomRecyclerView.invalidateItemDecorations()
        }
        root.findViewById<RecyclerView>(R.id.recyclerNewBottom).invalidateItemDecorations()
        if (!shouldHideBottomModule()) {
            mBottomAdapter?.notifyDataSetChanged()
            mNewBottomAdapter?.notifyDataSetChanged()
        }
    }

    /** 转屏后只刷新当前可见的榜单：固定区域优先，否则刷新 RV header。 */
    private fun refreshVisibleRankSection(contentHostWidth: Int) {
        val fixedRankView = mFixedRankSectionView
        if (fixedRankView != null && fixedRankView.visibility == View.VISIBLE) {
            fixedRankView.refreshPadItemSpacing(contentHostWidth)
            return
        }
        mGridAdapter?.refreshVisibleRankSection(mRecyclerView, contentHostWidth)
    }

    /**
     * 根据布局样式调整根容器高度。
     * 新样式（RANK_GRID/RANK_LIST）：高度 = 搜索栏 + 榜单 + RV 上间距 + 宫格行高。
     * Pad 样式 2/3：榜单 + 主列表 3 行（固定榜单在 RV 外，这 3 行全是可滑动宫格）。
     * 手机样式 3 仍是 4 行。其余样式保持 DeviceProfile 的 4x4 高度。
     */
    private fun adjustRootHeightByLayoutStyle(layoutStyle: Int) {
        val rootView = mRootView?.findViewById<RelativeLayout>(R.id.rl_shortcut_root_view) ?: return
        val lp = rootView.layoutParams ?: return
        val deviceProfile = DeviceProfile.getInstance()
        val isNewStyle = layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_GRID
                || layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST
        val isPadRankStyle = deviceProfile.isPadLayout && isNewStyle
        val cellCount = when {
            isPadRankStyle || layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_GRID -> 3
            else -> 4
        }
        val target = if (isNewStyle) {
            val res = resources
            val searchBarHeight = res.getDimensionPixelSize(R.dimen.dp_72)
            val recyclerMarginTop = res.getDimensionPixelSize(R.dimen.dp_20)
            val cellHeight = res.getDimensionPixelSize(R.dimen.folder_cell_height)
            val rankHeight =  res.getDimensionPixelSize(R.dimen.dp_98)
            val baseHeight = searchBarHeight + rankHeight + recyclerMarginTop + cellCount * cellHeight
            if (layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST && !deviceProfile.isPadLayout) {
                baseHeight - dip2px(18f)
            } else {
                baseHeight + dip2px(16f)
            }
        } else {
            val baseHeight = deviceProfile.getDesiredHeight()
            if (layoutStyle == CloudFolderManager.LAYOUT_STYLE_ORIGINAL) {
                baseHeight - dip2px(8f)
            } else {
                baseHeight + dip2px(8f)
            }
        } + deviceProfile.padContentHeightExtra(resources, layoutStyle)
        if (lp.height != target) {
            lp.height = target
            rootView.layoutParams = lp
        }
    }

    private suspend fun getCloudFolderData() : CloudFolderViewData? {
        return suspendCancellableCoroutine { ctn->
            ioScope.launch {
                CloudFolderManager.getInstance().getCloudFolderData(categoryType, TYPE_GET_CACHED,{
                    if(ctn.isActive) {
                        ctn.resume(null)
                    }
                }) {
                    if(ctn.isActive) {
                        ctn.resume(it)
                    }
                }
            }
        }
    }

    /**
     * 设置固定榜单区域（样式2、3 且 fixRankTile=true 时调用）
     * 委托 FixedRankSectionView 处理展示逻辑
     */
    private fun setupFixedRankSection(rankApps: List<CloudAppInfo>) {
        val rankView = mFixedRankSectionView ?: return

        // 在 bindData 之前注入样式与分类，bindRankItem 内部会读取 layoutStyle 写入 appInfo
        rankView.categoryType = categoryType
        rankView.layoutStyle = mLayoutStyle

        // 绑定数据
        rankView.bindData(
            rankApps,
            if (::mRecyclerView.isInitialized) mRecyclerView.width else 0
        )

        // 首次确认展示固定榜单时注册下载监听（异步加载完成后）
        if (!mFixedRankListenerRegistered) {
            rankView.registerDownloadListener()
            mFixedRankListenerRegistered = true
        }

        // 设置长按事件
        rankView.onRankItemLongClickListener = { view, index, appInfo ->
            if (appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
                if (null == mPopMenuWindow) {
                    mPopMenuWindow = CloudClickPopupWindow(PalmplayApplication.getAppInstance(), appInfo, index)
                }
                mPopMenuWindow?.setData(appInfo, index, mPopMenuItemSelectedListener)
                mPopMenuWindow?.onShow(view)
            }
        }

        val deviceProfile = DeviceProfile.getInstance()
        (rankView.layoutParams as? RelativeLayout.LayoutParams)?.apply {
            topMargin = deviceProfile.withPadSpaceExtra(resources, R.dimen.dp_31)
            rankView.layoutParams = this
        }
        rankView.requestLayout()

        (mRecyclerView.layoutParams as? RelativeLayout.LayoutParams)?.apply {
            addRule(RelativeLayout.BELOW, R.id.fixedRankSectionView)
            mRecyclerView.layoutParams = this
        }
        applyRecyclerViewSideMargin(mLayoutStyle)
        mRecyclerView.requestLayout()
    }

    private fun reportFixedRankExposureOnce() {
        val rankView = mFixedRankSectionView ?: return
        if (mHasReportedFixedRankExposureInResume) return
        if (rankView.visibility != View.VISIBLE || rankView.getRankItemCount() == 0) return

        rankView.reportRankExposure(enterFrom)
        mHasReportedFixedRankExposureInResume = true
    }

    private fun dealEmptyLayout() {
        CloudFolderTrackUtil.tecTrack(
            CloudFolderTrackUtil.TYPE_SHOW,
            CloudFolderTrackUtil.STATUS_SHOW_FOLDER_EMPTY,
            "1",
            categoryType.toString()
        )

        layoutFolderEmptyContent ?.apply {
            if (mGridAdapter?.itemCount == 0) {
                layoutFolderEmptyContent!!.visibility = View.VISIBLE
                //显示空页面
                if (NetworkUtils.isNetworkAvailable(TRApplicationContextUtil.getInstance())) {
                    textEmptyContent!!.visibility = View.VISIBLE
                    layoutEmptyNoNet!!.visibility = View.GONE
                } else {
                    layoutEmptyNoNet!!.visibility = View.VISIBLE
                    textEmptyContent!!.visibility = View.GONE
                }
            } else {
                layoutFolderEmptyContent!!.visibility = View.GONE
            }
        }
    }

    override fun onPause() {
        super.onPause()
        mHasReportedFixedRankExposureInResume = false
        hasReportedRecentlyInstalledShow = false
        recentlyInstalledShowResult = null
        CloudFolderTrackUtil.resetBottomExposureReported()
        mFixedRankSectionView?.onPause()
        shotCutExposureHelper?.resetExposureData()
        if (mFixedRankListenerRegistered) {
            mFixedRankSectionView?.unregisterDownloadListener()
        }
        mGridAdapter?.onStop()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mGridAdapter?.onDestroy()
        mNewBottomAdapter?.onDestroy()
    }


    class CustomSmoothScroller(context: Context) : LinearSmoothScroller(context) {

        var speed : Float = 25f

        override fun calculateSpeedPerPixel(displayMetrics: DisplayMetrics?): Float {
            return displayMetrics?.let {
                speed / it.densityDpi
            }?: 0.05f
        }
    }

}

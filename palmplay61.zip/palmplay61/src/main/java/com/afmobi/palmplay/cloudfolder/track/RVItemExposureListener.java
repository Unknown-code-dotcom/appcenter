package com.afmobi.palmplay.cloudfolder.track;

import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public final class RVItemExposureListener {
    private final List mExposureList;
    private final List mUploadList;
    private int mScrollState;private boolean checkExposure(View childView) {
        int position = this.mRecyclerView.getChildAdapterPosition(childView);
        if (position >= 0 && !this.mExposureList.contains(position)) {
            this.mExposureList.add(position);
            this.mUploadList.add(position);
            IOnExposureListener var10000 = this.mExposureListener;
            if (var10000 != null) {
                var10000.onExposure(position);
            }

            return true;
        } else {
            return false;
        }
    }
    private boolean mCheckChildViewExposure;
    private final RecyclerView mRecyclerView;
    private final IOnExposureListener mExposureListener;

    public void checkChildExposeStatus() {
        int length = this.mRecyclerView.getChildCount();
        if (length != 0) {
            View view = null;
            int i = 0;

            for(int var4 = length; i < var4; ++i) {
                view = this.mRecyclerView.getChildAt(i);
                if (view != null) {
                    Rect viewVisible = new Rect();
                    view.getLocalVisibleRect(viewVisible);
                    if (viewVisible.height() > view.getHeight() / 2 && viewVisible.top < mRecyclerView.getBottom()) {
                        this.checkExposure(view);
                    }
                }
            }
        }
    }



    public void resetExposureData() {
        this.mExposureList.clear();
        this.mUploadList.clear();
        this.mCheckChildViewExposure = true;
    }

    public void refreshFinish() {
        this.mCheckChildViewExposure = true;
    }

    public void setOffsetVertical(int offsetVertical) {
        if (offsetVertical != 0) {
            this.checkChildExposeStatus();
        }

    }

    public RVItemExposureListener(@NotNull RecyclerView mRecyclerView, @Nullable IOnExposureListener mExposureListener) {
        this.mRecyclerView = mRecyclerView;
        this.mExposureListener = mExposureListener;
        this.mExposureList = new ArrayList();
        this.mUploadList = new ArrayList();
        this.mCheckChildViewExposure = true;
        this.mRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            if (mRecyclerView.getChildCount() != 0 && mCheckChildViewExposure) {
                checkChildExposeStatus();
                mCheckChildViewExposure = false;
            }
        });
        this.mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            public void onScrollStateChanged(@NotNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                mScrollState = newState;
            }

            public void onScrolled(@NotNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (mScrollState != 2 || Math.abs(dy) <= 50) {
                    checkChildExposeStatus();
                }
            }
        });
    }

    public interface IOnExposureListener {
        void onExposure(int position);

    }
}

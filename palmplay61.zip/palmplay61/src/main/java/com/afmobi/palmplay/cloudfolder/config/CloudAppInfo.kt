package com.afmobi.palmplay.cloudfolder.config

import android.content.Intent
import android.graphics.drawable.Drawable
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderManager.Companion.LEADER_SCROLL_ON
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.model.AppInfo
import com.transsnet.launcherlib.config.Constants
import org.json.JSONObject

class CloudAppInfo : AppInfo() {

    var jumpType: Int = 0   //0 ps下载 1：其他商店下载 2：h5下载

    var storePkgName: String ?= null  //跳转包名

    var deeplink: String ?= null  //跳转deepLink

    var clickTracking : List<String> ?= null  //点击归因链接

    var showTracking : List<String> ?= null  //曝光归因链接

    var html5Url: String ?= null   //跳转的h5链接

    var drawable: Drawable?= null //硬预装应用图标
    var launchIntent: Intent? = null //硬预装应用的启动intent

    var dynamicIconUrl: String? = null // 服务端下发的动态图标链接
    var showDynamicIcon: Boolean = true // 本地计算逻辑决定是否展示动态图标

    var isEnable: Boolean = true

    /**
     * 榜单展示类型（用于 adapter 渲染 + 埋点 rk 字段）
     * 0 = 普通应用（无排名标识）
     * BaseFolderUiModel.TYPE_RANK_SECTION = 榜单皇冠（section header 占位 + section 内 3 个皇冠子项统一标记）
     * BaseFolderUiModel.TYPE_RANK_APP = 奖牌样式（样式4）
     */
    var rankViewType: Int = 0

    /** 排名位置 (0=第1名, 1=第2名, 2=第3名) */
    var rankIndex: Int = -1

    /**
     * 仅当 rankViewType == TYPE_RANK_SECTION 时使用：
     * 此 CloudAppInfo 是 RV header 占位载荷，本身不渲染单 app，
     * 真正的 3 个皇冠 app 通过此字段透传给 FixedRankSectionView.bindData()。
     */
    @Transient
    var rankSectionApps: List<CloudAppInfo>? = null

    /**
     * 当前云文件夹 UI 样式（埋点 sty 字段）。
     * 由 adapter 在 onBindViewHolder 时注入，下游埋点/下载链路直接读取即可。
     * 默认 STY_DEFAULT(1) = 不上报。
     */
    var layoutStyle: Int = CloudFolderTrackUtil.STY_DEFAULT

    @Volatile
    var isCached: Boolean = false //是否缓存在缩略图上

    var installedTime: Long = 0L  //应用安装完成时间戳，用于"最近安装"排序

    var installFromPage: String? = null  //「最近安装」拉活用：当初下载该应用的来源页面（用于区分 AC端内 / 云文件夹）

    /**
     * 是否非ps下载方式
     * 0 ps下载 1：其他商店下载 2：h5下载 5 硬预装
     * @return true 是
     */
    fun isOtherType() : Boolean {
        return jumpType == Constants.JUMP_TYPE_STORE || jumpType == Constants.JUMP_TYPE_WEB
    }

    fun isPreInstallItem() : Boolean {
        return jumpType == Constants.JUMP_TYPE_INSTALLED
    }

    fun isRecentlyInstalledItem() : Boolean {
        return jumpType == Constants.JUMP_TYPE_RECENTLY_INSTALLED
    }

    fun isLaunchOtherStore() : Boolean {
        return jumpType == Constants.JUMP_TYPE_STORE
    }

    fun isLaunchWeb() : Boolean {
        return jumpType == Constants.JUMP_TYPE_WEB
    }

    /**
     * 是否应展示动态图标（全局开关 + 本地数据双重校验）
     */
    fun isDynamicIcon(): Boolean {
        return CloudFolderManager.getInstance().getDynamicIconSwitch() == LEADER_SCROLL_ON
                && showDynamicIcon
                && !dynamicIconUrl.isNullOrEmpty()
    }

    fun getCloudStyleString(): String? {
        try {
            val js = JSONObject()
            if (layoutStyle != CloudFolderTrackUtil.STY_DEFAULT) {
                js.put("sty", layoutStyle)
            }
            val rk = if (rankViewType != 0) CloudFolderTrackUtil.RK_IS_RANK else CloudFolderTrackUtil.RK_NOT_RANK
            if (rk == CloudFolderTrackUtil.RK_IS_RANK) {
                js.put("rk", rk)
            }
            if (isDynamicIcon()) {
                js.put("dyn", CloudFolderTrackUtil.DYN_IS_DYNAMIC)
            }
            // 三个字段全部为默认值时返回 null，避免上报空 JSON
            if (js.length() == 0) return null
            return js.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as CloudAppInfo

        return packageName == other.packageName
    }

    override fun hashCode(): Int {
        var result = jumpType
        result = 31 * result + (storePkgName?.hashCode() ?: 0)
        return result
    }

    override fun toString(): String {
        return "CloudAppInfo(pkg=$packageName)"
    }



}
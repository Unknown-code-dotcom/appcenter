// TOP SECRET
package com.afmobi.palmplay.cache.v6_3;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.keeptojosn.ClientOperationRecordNode;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.network.NetworkClient;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//import io.reactivex.Observable;
//import io.reactivex.ObservableEmitter;
//import io.reactivex.ObservableOnSubscribe;
//import io.reactivex.Observer;
//import io.reactivex.disposables.Disposable;
//import io.reactivex.schedulers.Schedulers;

public class ClientOperationStatisticCache implements LocalCache {
    // private static final long MAX_TIME_SPACE = 24 * 60 * 60 * 1000;
    private static final long MAX_TIME_SPACE = 12 * 60 * 60 * 1000;
    private static final long REQUEST_TIME_SPACE = 2 * 60 * 1000;
    private static final long SAVE_FILE_SPACE = 10 * 1000;
    private static final long MAX_DATA_COUNT = 200;

    private final static String FILE_NAME = "ClientOperationRecord.txt";
    private static volatile ClientOperationStatisticCache mInstance;
    private long mLastCommitTimeMillis;
    private long mLastSaveFileTimeMillis;
    private long mLastRequestTimeMillis;
    private HashMap<String, ClientOperationRecordNode> mDataCollectionMap;
    private List<ClientOperationRecordNode> mOperationRecordList;
    private DataStatisticSaveInfo mLatestDataSaveInfo;
    private boolean isAllSaved = false;

    private ClientOperationStatisticCache() {
        mDataCollectionMap = new HashMap<String, ClientOperationRecordNode>();
        mOperationRecordList = new ArrayList<ClientOperationRecordNode>();
        mLastSaveFileTimeMillis = 0;
        loadFromCache();
    }

    public static ClientOperationStatisticCache getInstance() {
        if (mInstance == null) {
            synchronized (ClientOperationStatisticCache.class) {
                if (mInstance == null) {
                    mInstance = new ClientOperationStatisticCache();
                }
            }
        }
        return mInstance;
    }

    @Override
    public String getFileName(Object... objects) {
        // TODO Auto-generated method stub
        return FILE_NAME;
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
        // TODO Auto-generated method stub
        FilePathManager.jsonToFile(jsonBuffer, getFileName());
//        FilePathManager.jsonToFilePath(jsonBuffer, Environment.getExternalStorageDirectory()+ "/Palmplay/" + getFileName());
    }

    @Override
    public void loadFromCache(Object... objects) {
        // TODO Auto-generated method stub
        List<ClientOperationRecordNode> dataList = null;
        try {
            JsonElement jsonObject = (JsonElement) FilePathManager.fileToJson(getFileName());
//            JsonElement jsonObject = (JsonElement) FilePathManager.filePathToJson(Environment.getExternalStorageDirectory()+ "/Palmplay/" + getFileName());
            if (jsonObject != null) {
                Gson gson = new Gson();
                mLatestDataSaveInfo = gson.fromJson(jsonObject, DataStatisticSaveInfo.class);
                if (null != mLatestDataSaveInfo) {
                    dataList = mLatestDataSaveInfo.mDataList;
                    mLastCommitTimeMillis = mLatestDataSaveInfo.lastCommitTimeMillis;
                } else {
                    mLastCommitTimeMillis = System.currentTimeMillis();
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
            LogUtils.e(e);
        }
        if (null != dataList && dataList.size() > 0) {
            for (ClientOperationRecordNode dataNode : dataList) {
                if (dataNode != null && dataNode.isViewCountType()) {
                    mDataCollectionMap.put(dataNode.getComKey(), dataNode);
                }
            }
            mOperationRecordList.addAll(dataList);
        }

        if (null != mLatestDataSaveInfo) {
            mLastCommitTimeMillis = mLatestDataSaveInfo.lastCommitTimeMillis;
        } else {
            mLastCommitTimeMillis = System.currentTimeMillis();
        }
    }

    public void putOneOperationRecordNode(final ClientOperationRecordNode newDataNode) {
        //大于最大值的5倍，丢弃不保存,防止OOM
        if(mOperationRecordList != null && mOperationRecordList.size() > 5 * MAX_DATA_COUNT){
            return;
        }
        putOperationRecordNode(newDataNode, false);
    }

    /**
     * 同步方法，避免多个打点并发修改集合，出现并发修改异常
     * @param newDataNode
     * @param isBatch
     */
    public synchronized void putOperationRecordNode(ClientOperationRecordNode newDataNode, boolean isBatch) {
        if (null == newDataNode) {
            return;
        }
        LogUtils.e("putOperationRecordNode------------", newDataNode.toString());
        if (newDataNode.type != null) {

            if (newDataNode.isViewCountType()
                    || newDataNode.isLinkShareSetup()) {
                String comKey = newDataNode.getComKey();
                if (!TextUtils.isEmpty(comKey)) {
                    ClientOperationRecordNode dataNode = mDataCollectionMap.get(comKey);
                    if (null != dataNode) {
                        dataNode.addCount();
                        newDataNode = dataNode;
                        LogUtils.e(newDataNode.toString());
                    } else {
                        mOperationRecordList.add(newDataNode);
                    }
                    mDataCollectionMap.put(comKey, newDataNode);
                }
            } else {
                mOperationRecordList.add(newDataNode);
            }

            if (!isBatch) {
                if (isNeedSaveDataFile()) {
                    TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
                        @Override
                        public void doRun() {
                            saveToCacheFile();
                        }
                    }));
                    isAllSaved = true;
                }else{
                    isAllSaved = false;
                }

                if (isNeedCommitData()) {
                    commitDataStatistic();
                }
            }

        }

    }

    public void putOneOperationRecordNode(PageParamInfo pageParamInfo) {
        putOneOperationRecordNode(new ClientOperationRecordNode(PageConstants.getLastPageStr(pageParamInfo), PageConstants.getCurPageStr(pageParamInfo)));
    }

    public void putLinkShareOperationRecordNode(String shareChannel, String platform, String entryType) {
        putOneOperationRecordNode(ClientOperationRecordNode.getLinkShareSetupClientOperationRecordNod(shareChannel, platform, entryType));
    }

    private String getDataStatisticBuffer(boolean isCommitBuffer) {
        String cacheBuffer = "";
        Gson gson = new Gson();
        if (null != mOperationRecordList && mOperationRecordList.size() > 0) {
            if (isCommitBuffer) {
                Type type = new TypeToken<List<ClientOperationRecordNode>>() {
                }.getType();
                cacheBuffer = gson.toJson(mOperationRecordList, type);
            } else {
                mLatestDataSaveInfo = new DataStatisticSaveInfo();
                mLatestDataSaveInfo.lastCommitTimeMillis = mLastCommitTimeMillis;
                mLatestDataSaveInfo.mDataList = new ArrayList<ClientOperationRecordNode>(mOperationRecordList);
                cacheBuffer = gson.toJson(mLatestDataSaveInfo, DataStatisticSaveInfo.class);
            }
        }
        return cacheBuffer;
    }

    public void saveToCacheFile() {
        String buffer = getDataStatisticBuffer(false);
        if (!TextUtils.isEmpty(buffer)) {
            saveToCache(buffer);
            mLastSaveFileTimeMillis = System.currentTimeMillis();
        }
    }

    public void saveToCacheFileForce(){
        if(!isAllSaved){
            saveToCacheFile();
            isAllSaved = true;
        }
    }

    public boolean isNeedCommitData() {
        long curTimeMillis = System.currentTimeMillis();
        if (((curTimeMillis - mLastCommitTimeMillis) >= MAX_TIME_SPACE || (mOperationRecordList.size() >= MAX_DATA_COUNT))
                && ((curTimeMillis - mLastRequestTimeMillis) >= REQUEST_TIME_SPACE)) {
            return true;
        }
        return false;
    }

    public boolean isNeedSaveDataFile() {
        long curTimeMillis = System.currentTimeMillis();
        if (curTimeMillis - mLastSaveFileTimeMillis > SAVE_FILE_SPACE) {
            return true;
        }
        return false;
    }

    public void commitDataStatistic() {
        if(PalmplayApplication.getPalmplayApplicationInstance().isAbleUploadAppData()){
            String dataBuffer = getDataStatisticBuffer(true);
            mLastRequestTimeMillis = System.currentTimeMillis();
            NetworkClient.clientOperationRecordCommit(NetworkActions.ACTION_COMMIT_DATA_STATISTIC_REQUEST, dataBuffer);
        }
    }

    public void onCommitSuccessed() {
        /*
        Fatal Exception: java.util.ConcurrentModificationException
        java.util.ArrayList$Itr.next (ArrayList.java:860)
        com.google.gson.Gson.toJson (Gson.java:603)
        com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache.getDataStatisticBuffer (ClientOperationStatisticCache.java:194)
        */
        if (LogUtils.debug){
            LogUtils.e("ClientOperationStatisticCache",  "onCommitSuccessed: "+ getDataStatisticBuffer(true));
        }
        mDataCollectionMap.clear();
        mOperationRecordList.clear();
        deleteCacheFile();
        mLastCommitTimeMillis = System.currentTimeMillis();
    }

    public void onCommitFailed() {
        if (null != mLatestDataSaveInfo) {
            mLastCommitTimeMillis = mLatestDataSaveInfo.lastCommitTimeMillis;
        }
    }

    private void deleteCacheFile() {
        FilePathManager.jsonToFile("", getFileName());
//        FilePathManager.jsonToFilePath("", Environment.getExternalStorageDirectory()+ "/Palmplay/" + getFileName());
    }

    public class DataStatisticSaveInfo {
        // public int totalCount;
        public long lastCommitTimeMillis;
        public List<ClientOperationRecordNode> mDataList;
    }


}

package com.afmobi.palmplay.appdetail;

import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.detail.AppDetailsComponentFeatureViewHolder;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.util.PackageUtil;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FeatureUtil {
    private List<TaNativeInfo> mAdInfo;
    protected Map<String, Integer> mAlreadyAddList = new HashMap<>();  //记录已经展示过的包名
    protected List<String> mAlreadyAdList = new ArrayList<String>();  //记录已经展示过的广告包名
    protected AppInfo mAppInfo;
    /**
     * 每次刷新后的专题数量
     */
    private int preTotalSize = 0;

    public FeatureUtil(AppInfo mAppInfo) {
        this.mAppInfo = mAppInfo;
    }

    public void setAdInfo(List<TaNativeInfo> adInfo) {
        this.mAdInfo = adInfo;
    }

    public void showRecommendView(List<FeatureBean> listItems){
        if (listItems != null && listItems.size() > 0) {
            List<TaNativeInfo> adInfo = mAdInfo;
            if (adInfo != null) {
                int size = adInfo.size();
                for (int i = 0; i < size; i++) {
                    TaNativeInfo taNativeInfo = adInfo.get(i);
                    if (!taNativeInfo.isIconType()) {
                        //continue
                    } else {
                        //icon类广告
                        FeatureItemData appinfo = null;
                        try {
                            appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                            if (appinfo != null) {
                                appinfo.tNativeInfo = taNativeInfo;
                            }
                        } catch (GsonUtil.GsonParseException e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }

                        if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {

                            filterEWData(listItems, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn());
                            TRHomeUtil.addAdForFeatureData(listItems, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), mAlreadyAdList, SceneCode.AD_de);
                        }
                    }
                }
            }
            filterDuplicateData(listItems);

            if (mAppInfo.nfAbId > 0 || mAppInfo.nfAbExpId > 0) {//todo 拼接详情页的实现id，后续改造，需要统计处理流程，不能散在这里，目前也没有找到比这里更好的地方
//                mHomeRecyclerViewAdapter.setOfferInfo(mOfferInfo);
                for (FeatureBean featureBean : listItems) {
                    List<FeatureBaseData> dataList = featureBean.dataList;
                    if (dataList != null) {
                        for (FeatureBaseData data : dataList) {
                            if (data.reportDto != null) {
                                data.reportDto.nfAbId = mAppInfo.nfAbId;
                                data.reportDto.nfAbExpId = mAppInfo.nfAbExpId;
                            }
                        }
                    }
                }
            }
//            mHomeRecyclerViewAdapter.setData(listItems,null,null, false,false, true);
        }
    }

    /**
     * ew数据和返回列表数据比较， 如果包名一致，去除本地列表返回项
     * @param featureList
     * @param data
     * @param row
     * @param col
     */
    public void filterEWData(List<FeatureBean> featureList, FeatureItemData data, int row, int col) {

        if(featureList == null || featureList.isEmpty()) {
            return;
        }

        if (data == null || TextUtils.isEmpty(data.packageName)) {
            return;
        }

        if (row < 0 || col < 0) {
            return;
        }

        if (PackageUtil.isInstalled(data.isVa, data.packageName)) {
            return;
        }

        if (row >= featureList.size()) {
            return;
        }

        FeatureBean featureBean = featureList.get(row);
        if (featureBean == null || TextUtils.isEmpty(featureBean.style)) {
            return;
        }
        preTotalSize = 0;
        int listSize = featureList.size();
        try {
            List<FeatureBean> newFeatureList = featureList.subList(preTotalSize, listSize);
            LogUtils.d("SspSdkManager", "packageName: " + data.packageName  + "  size:" + newFeatureList.size());
            HisavanaSdkManager.getInstance().filterValidateAd(newFeatureList, data);
        }catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    /**
     * 跟主应用去重
     * @param featureList
     */
    private List<FeatureBean> filterDuplicateWithAppInfo(List<FeatureBean> featureList){
        if(!featureList.isEmpty()) {
            for (FeatureBean featureBean : featureList) {
                List<FeatureBaseData> dataList = featureBean.dataList;
                if (dataList != null) {
                    Iterator<FeatureBaseData> iterator = dataList.iterator();
                    while (iterator.hasNext()) {
                        FeatureBaseData featureBaseData = iterator.next();
                        if (featureBaseData instanceof FeatureItemData) {
                            FeatureItemData item = (FeatureItemData) featureBaseData;
                            if (mAppInfo != null) {
                                if (BuildConfig.DEBUG) {
                                    LogUtils.d("filterDuplicateWithAppInfo", "m pkg：" + mAppInfo.packageName + "  item pkg: " + item.packageName);
                                }
                                if (TextUtils.isEmpty(item.packageName) && TextUtils.equals(item.packageName, mAppInfo.packageName)) {
                                    if (BuildConfig.DEBUG) {
                                        LogUtils.d("filterDuplicateWithAppInfo", "m pkg：" + mAppInfo.packageName + "  item pkg: " + item.packageName + " remove");
                                    }
                                    iterator.remove();
                                }
                            }
                        }
                    }
                }
            }
        }
        return featureList;
    }

    /**
     * 过滤重复数据
     * @param featureList
     */
    public void filterDuplicateData(List<FeatureBean> featureList) {

        if(featureList == null) {
            return;
        }

        try {
            List<FeatureBean> filteredList = filterDuplicateWithAppInfo(featureList);
            int listSize = filteredList.size();
            mAlreadyAddList.clear();
            List<FeatureBean> preFeatureList = filteredList.subList(0, preTotalSize);
            List<FeatureBean> newFeatureList = filteredList.subList(preTotalSize, listSize);
            LogUtils.d("SspSdkManager", "onDataReceived2: " + preFeatureList.size() + "    newSize:" + newFeatureList.size());

            HisavanaSdkManager.getInstance().removeDuplicateData(preFeatureList, newFeatureList, mAlreadyAddList, SceneCode.AD_de);

            preTotalSize = listSize;
        }catch (Exception e) {
            if (BuildConfig.DEBUG){
                e.printStackTrace();
            }
        }
    }
}

package com.afmobi.palmplay.clean;

import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseEventFragment;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_6.ScanResult;
import com.afmobi.util.DisplayUtil;
import com.transsnet.store.R;

import java.io.File;

import androidx.annotation.Nullable;

/**
 * 深度清理页面下半部分--扫描中
 * Created by xiangfei.wei on 2017/11/29.
 */

public class CleanCacheScaningFragment extends BaseEventFragment {

    private final int ANIM_HANDLER_WHAT = 11;
    private Activity mActivity;
    private TextView tv_cache_size, tv_uninstall_size, tv_apk_size, tv_memory_size, tv_system_size;
    private ProgressBar cache_scaning_progress, uninstall_scaning_progress, apk_scaning_progress, memory_scaning_progress, system_scaning_progress;
    private ImageView cache_iv_checked, uninstall_iv_checked, apk_iv_checked, memory_iv_checked, system_iv_checked;
    private LinearLayout ll_container;
    private View layout_system;
    private int translationYByDistance;
    private ViewPropertyAnimator translationAnimator;
    private boolean isUsePmScan;

    public static CleanCacheScaningFragment newInstance() {
        return new CleanCacheScaningFragment();
    }

    public void setIsUsePmScan(boolean isUsePmScan) {
        this.isUsePmScan = isUsePmScan;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = (Activity) context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_clean_cache_scaning, container, false);
        tv_cache_size = (TextView) contentView.findViewById(R.id.tv_cache_size);
        tv_uninstall_size = (TextView) contentView.findViewById(R.id.tv_uninstall_size);
        tv_apk_size = (TextView) contentView.findViewById(R.id.tv_apk_size);
        tv_memory_size = (TextView) contentView.findViewById(R.id.tv_memory_size);
        tv_system_size = (TextView) contentView.findViewById(R.id.tv_system_size);
        cache_scaning_progress = (ProgressBar) contentView.findViewById(R.id.cache_scaning_progress);
        uninstall_scaning_progress = (ProgressBar) contentView.findViewById(R.id.uninstall_scaning_progress);
        apk_scaning_progress = (ProgressBar) contentView.findViewById(R.id.apk_scaning_progress);
        memory_scaning_progress = (ProgressBar) contentView.findViewById(R.id.memory_scaning_progress);
        system_scaning_progress = (ProgressBar) contentView.findViewById(R.id.system_scaning_progress);

        cache_iv_checked = (ImageView) contentView.findViewById(R.id.cache_iv_checked);
        uninstall_iv_checked = (ImageView) contentView.findViewById(R.id.uninstall_iv_checked);
        apk_iv_checked = (ImageView) contentView.findViewById(R.id.apk_iv_checked);
        memory_iv_checked = (ImageView) contentView.findViewById(R.id.memory_iv_checked);
        system_iv_checked = (ImageView) contentView.findViewById(R.id.system_iv_checked);
        layout_system = contentView.findViewById(R.id.layout_system);
        ll_container = (LinearLayout) contentView.findViewById(R.id.ll_container);

        refreshUiWhenCleanTypeChanged();

        return contentView;
    }

    public void refreshUiWhenCleanTypeChanged() {

        if (ll_container == null) {
            return;
        }

        layout_system.setVisibility(isUsePmScan ? View.VISIBLE : View.GONE);

        int margin = isUsePmScan ? DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), -240) :
                DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), -180);
        ScrollView.LayoutParams lp = (ScrollView.LayoutParams)ll_container.getLayoutParams();
        lp.topMargin = margin;
        ll_container.setLayoutParams(lp);
    }

    private Handler animHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == ANIM_HANDLER_WHAT) {
                startTranslationAnimator();
            }
        }
    };

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        translationYByDistance = DisplayUtil.dip2px(mActivity, 60);
        startTranslationAnimator();
    }

    private void startTranslationAnimator() {
        if (translationAnimator == null) {
//            translationAnimator = ObjectAnimator.ofFloat(ll_container, "translationYBy", translationYByDistance);
            translationAnimator = ll_container.animate().setDuration(500).setStartDelay(200);
            translationAnimator.setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    super.onAnimationEnd(animation);
                    //System.out.println("**********************************ll_container.getTranslationY()=" + ll_container.getTranslationY());
                    int num = isUsePmScan ? 4 : 3; //PM四类， PS三类
                    if (ll_container.getTranslationY() < translationYByDistance * num) {
                        if (animHandler != null) {
                            animHandler.sendEmptyMessage(ANIM_HANDLER_WHAT);
                        }
                    }
                }
            });
        }
        translationAnimator.translationYBy((float) translationYByDistance);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (translationAnimator != null) {
            translationAnimator.cancel();
        }
        if (animHandler != null) {
            animHandler.removeCallbacksAndMessages(null);
            animHandler = null;
        }
    }

    public void scanProgressUpdate(ScanResult scanResult, CacheListItem cacheListItem) {
        if (CacheListItem.Type.MEMORY == cacheListItem.type) {
            /*memory_scaning_progress.setVisibility(View.GONE);
            memory_iv_checked.setVisibility(View.VISIBLE);
            long memoryListSize = 0;
            if (null != scanResult.getMemoryList()) {
                for (CacheListItem item : scanResult.getMemoryList()) {
                    memoryListSize += item.getSize();
                }
            }
            if (memoryListSize > 0)
                tv_memory_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(memoryListSize, 1));
            else
                tv_memory_size.setText("0B");*/
        } else if (CacheListItem.Type.MOUNTING == cacheListItem.type) {
            /*memory_scaning_progress.setVisibility(View.GONE);
            memory_iv_checked.setVisibility(View.VISIBLE);*/
            apk_scaning_progress.setVisibility(View.GONE);
            apk_iv_checked.setVisibility(View.VISIBLE);
            long apkFilesSize = 0;
            if (null != scanResult.getApkList()) {
                for (CacheListItem apk : scanResult.getApkList()) {
                    if (isUsePmScan) {
                        apkFilesSize += apk.getSize();
                    }else {
                        if (!TextUtils.isEmpty(apk.apkPath)) {
                            File file = new File(apk.apkPath);
                            if (file.exists()) {
                                apkFilesSize += apk.getSize();
                            }
                        }
                    }
                }
            }
            if (apkFilesSize > 0)
                tv_apk_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(apkFilesSize, 1));
            else
                tv_apk_size.setText("0B");
        } else if (CacheListItem.Type.UNINSTALL == cacheListItem.type) {
            /*memory_scaning_progress.setVisibility(View.GONE);
            memory_iv_checked.setVisibility(View.VISIBLE);*/
            apk_scaning_progress.setVisibility(View.GONE);
            apk_iv_checked.setVisibility(View.VISIBLE);
            uninstall_scaning_progress.setVisibility(View.GONE);
            uninstall_iv_checked.setVisibility(View.VISIBLE);
            /*long uninstallSize = 0;
            for (CacheListItem item : scanResult.getUninstallCacheList()) {
                uninstallSize += item.getSize();
            }*/
            if (scanResult.uninstallSize > 0)
                tv_uninstall_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.uninstallSize, 1));
            else
                tv_uninstall_size.setText("0B");
        } else if (CacheListItem.Type.CACHE == cacheListItem.type) {
            resetScanState();
            /*long cacheSize = 0;
            if (null != scanResult.getAppCacheList()) {
                for (CacheListItem item : scanResult.getAppCacheList()) {
                    cacheSize += item.getSize();
                }
            }
            if (null != scanResult.getSystemCacheList()) {
                for (CacheListItem item : scanResult.getSystemCacheList()) {
                    cacheSize += item.getSize();
                }
            }*/
            if (scanResult.cacheSize > 0)
                tv_cache_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.cacheSize, 1));
            else
                tv_cache_size.setText("0B");
        } else if (CacheListItem.Type.SYSTEM == cacheListItem.type) {
            if (isUsePmScan) {
                if (scanResult.systemCacheSize > 0)
                    tv_system_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.systemCacheSize, 1));
                else
                    tv_system_size.setText("0B");
            }
        }
    }

    private void resetScanState() {
        apk_scaning_progress.setVisibility(View.GONE);
        apk_iv_checked.setVisibility(View.VISIBLE);
        uninstall_scaning_progress.setVisibility(View.GONE);
        uninstall_iv_checked.setVisibility(View.VISIBLE);
        cache_scaning_progress.setVisibility(View.GONE);
        cache_iv_checked.setVisibility(View.VISIBLE);
        if (isUsePmScan) {
            system_scaning_progress.setVisibility(View.GONE);
            system_iv_checked.setVisibility(View.VISIBLE);
        }
    }

    public void onScanComplete(ScanResult scanResult) {
        resetScanState();

        if (scanResult.apkFilesSize > 0)
            tv_apk_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.apkFilesSize, 1));
        else
            tv_apk_size.setText("0B");
        if (scanResult.uninstallSize > 0)
            tv_uninstall_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.uninstallSize, 1));
        else
            tv_uninstall_size.setText("0B");
        if (scanResult.cacheSize > 0)
            tv_cache_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.cacheSize, 1));
        else
            tv_cache_size.setText("0B");

        if (isUsePmScan) {
            /*
            if (scanResult.memorySize > 0)
                tv_memory_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.memorySize, 1));
            else
                tv_memory_size.setText("0B");
             */

            if (scanResult.systemCacheSize > 0)
                tv_system_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(scanResult.systemCacheSize, 1));
            else
                tv_system_size.setText("0B");
        }
    }
}

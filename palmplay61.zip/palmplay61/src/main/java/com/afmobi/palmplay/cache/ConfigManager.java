package com.afmobi.palmplay.cache;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.DetailPreCacheInfo;
import com.afmobi.palmplay.model.FloatballConfig;
import com.afmobi.palmplay.model.HalfScreenDetailConfig;
import com.afmobi.palmplay.model.HalfScreenDetailConfigInfo;
import com.afmobi.palmplay.model.NotifyGuideInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.newdiff.HsynzCompatKt;
import com.afmobi.palmplay.va.PsVaConstants;
import com.afmobi.palmplay.va.model.server.ServerAutoBean;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.TimeUtil;
import com.android.hundsup.utils.NetworkUtil;
import com.androidnetworking.cronet.NetHelperKt;
import com.cloud.hisavana.sdk.common.bean.PslinkInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.transsion.newphonerecommend.utils.SpUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.GsonUtils;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author: zhiqiang.hao
 * @date: 2021/1/26 16:00
 * @Desc: add your description
 */
final public class ConfigManager {

    private final static String FEATURE_TAB_DATA_MARK = "feature_tab_data_mark"; //feature_tab 更新标记

    /**
     * 半详情页展示风格(A/B)，A对应需求文档的样式3（半屏页带截图），  B是样式5 （顶部悬浮弹框）
     */
    public static String getDetailStyleRole() {
        String detailStyleRole = MMKVUtils.getMMKV().getString(Constant.KV_DETAIL_ROLE, null);
        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "Half detail style role is:" + detailStyleRole);
        return TextUtils.isEmpty(detailStyleRole) ? Constant.HALFDETAIL_STYLE_A : detailStyleRole;
    }


    /**
     * 根据来源判断是否支持半屏
     * 默认配置EW,  PM 支持半屏
     */
    private final static String supportBiz[] = new String[]{"EW", "PM", "Moviebox", "MobileCloner", "GlobalSearch"};

    public static String getSupportHalfScreenStyle(String originDetailStyle, String pkg, PslinkInfo pslinkInfo) {
        if(pslinkInfo==null || TextUtils.isEmpty(pslinkInfo.getAppPackageName()) || TextUtils.isEmpty(pkg)) {
            LogUtils.d(LogUtils.TAG_HALF_DETAIL, "pslinkInfo is null, return originDetailStyle:" + originDetailStyle);
            return originDetailStyle;
        }
        return getHalfScreenStyle(originDetailStyle);
    }

    public static boolean isSupportHalfDetail(String source) {
        if (TextUtils.isEmpty(source)) {
            LogUtils.d(LogUtils.TAG_HALF_DETAIL, "source is null, return originDetailStyle:");
            return false;
        }

        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_HALF_SCREEN_BIZS, null);
        if (set == null || set.size() <= 0) {
            // 首次启动或未获取网络配置时，取默认配置
            List<String> list = Arrays.asList(supportBiz);
            LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit supportBiz:" + list.contains(source));
            return list.contains(source);
        }

        List<String> list = new ArrayList<>(set);
        if (!list.isEmpty()) {
            for (String item : list) {
                if (TextUtils.equals(item, source)) {
                    LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit KV_HALF_SCREEN_BIZS: true");
                    return true;
                }
            }
        }
        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit KV_HALF_SCREEN_BIZS: false");
        return false;
    }


    /**
     * 获取半详情页配置
     * @param configType
     * @return
     * @param <T>
     */
    public static <T> T getHalfScreenDetailConfig(String configType) {
        String configStr = "";
        Type type = null;
        try {
            if (TextUtils.equals(configType, Constant.KV_HALF_SCREEN_DETAIL_STYLE_CONFIG_PS)) {
                configStr = MMKVUtils.getMMKV().getString(Constant.KV_HALF_SCREEN_DETAIL_STYLE_CONFIG_PS, null);
                type = new TypeToken<List<HalfScreenDetailConfig.PSConfig>>() {
                }.getType();
            }
            LogUtils.d(LogUtils.TAG_HALF_DETAIL, "getHalfScreenDetailConfig configStr:" + configStr);
            return GsonUtils.getInstance().fromJson(configStr, type);
        }catch (Exception e) {
            LogUtils.e(e);
        }
        return null;
    }

    public static HalfScreenDetailConfigInfo getHalfScreenDetailConfigInfo(String appId) {
        if (TextUtils.isEmpty(appId)) {
            return null;
        }

        Set<String> halfSet = MMKVUtils.getMMKV().getStringSet(Constant.KV_HALFSCREENDETAILCONFIG, null);
        if (halfSet == null || halfSet.size() <= 0) {
            return null;
        }

        HalfScreenDetailConfigInfo halfInfo = null;
        List<String> list = new ArrayList<>(halfSet);
        if (list != null && list.size() > 0) {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                String item = it.next();
                String[] split = item.split(",");
                if (split.length > 0 && !TextUtils.isEmpty(split[0]) && !TextUtils.isEmpty(split[1]) &&
                        !TextUtils.isEmpty(split[2]) && TextUtils.equals(split[0], appId)) {
                    halfInfo = new HalfScreenDetailConfigInfo();
                    halfInfo.appId = split[0];
                    halfInfo.style = split[1];
                    int value = 0;
                    try {
                        value = Integer.parseInt(split[2]);
                    } catch (Exception e) {
                    }
                    halfInfo.autoDownload = value;
                    return halfInfo;
                }
            }
        }

        return halfInfo;
    }

    public static int getActivateRemindShowCount() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_NOTIFY_SHOW, -1);
    }

    /**
     * 获取Status Saver开关，默认打开
     */
    public static boolean isStatusSaverSwitchOpen() {
        if(TRApplicationContextUtil.isProject()) {
            return false;
        }
        return MMKVUtils.getMMKV().getInt(Constant.KV_STATUS_SAVER_SWITCH, 1) == 1;
    }

    /**
     * Status Saver剩余空间比例，默认5%
     *
     * @return
     */
    public static int getStatusSaverLeftSpaceRatio() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_STATUS_SAVER_RATIO, 5);
    }


    /**
     * Status Saver 缓存上限
     *
     * @return
     */
    public static int getStatusSaverMaxCacheSize() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_STATUS_SAVER_MAXCACHE, 500);
    }


    public static boolean isPreLoadOn() {
        String isPreLoadOn = MMKVUtils.getMMKV().getString(Constant.KV_WEBVIEW_PRELOAD_SWITCH, null);

        return TextUtils.equals(isPreLoadOn, "T");
    }

    /**
     * 紧急情况Va广告云控
     * 本地configUpdateIndex不一样请求广告接口
     */
    public static int getVaAdConfigInfo() {
        return !AppDataManager.CONTROL_VA_GAME_CONFIG ? 0 : MMKVUtils.getMMKV().getInt(Constant.KV_VA_UPDATE_INDEX, 0);
    }


    /**
     * Va游戏云控开关
     *
     * @return //1全部true，0全部false，-1普通严重，-2超级严重
     */
    public static int getGameSwitch() {
        //当gs大开关关闭时，直接是-2，这里做下兜底处理，防止出现gs大开关关闭时，switch配置没有更新
        if (isGameSpaceEnable()) {
            return !AppDataManager.CONTROL_VA_GAME_CONFIG ? PsVaConstants.GameSwitch.FULL_CLOSE : ImmutableMMKV.getInt(Constant.KV_GAME_SWITCH, PsVaConstants.GameSwitch.FULL_CLOSE);
        } else {
            return PsVaConstants.GameSwitch.SUPER_SEVERE;
        }
    }

    /**
     * 是否支持VA
     *
     * @return
     */
    public static boolean isLocalSupportVa() {
        return BuildConfig.SUPPORT_VA;
    }

    /**
     * VA解耦版本
     *
     * @return
     */
    public static boolean isLocalSplitVa() {
        return BuildConfig.SUPPORT_VA && !BuildConfig.PROXY_VA;
    }

    /**
     * false 等同于纯净版状态
     *
     * @return
     */
    public static boolean isGameSpaceEnable() {
        return isLocalSplitVa() && ImmutableMMKV.getBoolean(Constant.KV_GAMESPACE_ENABLE, false);
    }

    /**
     * 是否保留数据卸载
     */
    public static boolean isKeepFragileData() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_KEEP_FRAGILE_DATA, 0) == 1;
    }

    /**
     * VA startup 请求配置时间间隔, 单位 h
     */
    public static long getVaStartupInterval() {
        int value = MMKVUtils.getMMKV().getInt(Constant.KV_VA_STARTUP_INTERVAL, Integer.MAX_VALUE);
        if (value <= 0) {
            value = Integer.MAX_VALUE;
        }
        return value * 1000L * 60 * 60;
    }

    /**
     * 获取云端配置的所需最小GameSpace版本号
     *
     * @return
     */
    public static int getGameSpaceMinVersion() {
        return isGameSpaceEnable() ? ImmutableMMKV.getInt(Constant.KV_GAMESPACE_MIN_VERSION, PsVaConstants.VA_FEATURE.SUPPORT_COOPERATION_VERSION) : PsVaConstants.VA_FEATURE.SUPPORT_COOPERATION_VERSION;
    }


    /**
     * false 等同于纯净版状态
     *
     * @return
     */
    public static boolean isWebGameSpaceEnable() {
        return isGameSpaceEnable() && ImmutableMMKV.getInt(Constant.KV_WEB_GAME_SWITCH, 0) != 0;
    }

    public static boolean isNeedWebGameSpace() {
        boolean enable = isWebGameSpaceEnable();
        if (!enable) {
            return false;
        }
        if (VaStaticProxy.isSupportFeature(PsVaConstants.VA_FEATURE.SUPPORT_OFFLINE_WEB_GAME_MIN_VERSION)) {
            return true;
        }
        if (NetworkUtil.isConnected(PalmplayApplication.getAppInstance())) {
            return true;
        }
        return false;
    }


    /**
     * GameSpace是否可以静默下载安装
     *
     * @return
     */
    public static boolean isGameSpaceSilentInstallEnable() {
        return isGameSpaceEnable() && ImmutableMMKV.getBoolean(Constant.KV_GAMESPACE_SILENT_STATUS, false);
    }


    public static boolean isEnablePalmSpacePreDownload() {
        return isGameSpaceEnable() && MMKVUtils.getMMKV().getBoolean(Constant.KV_GAMESPACE_SILENT_DOWNLOAD, false);
    }


    /**
     * 最近玩模块云控配置信息
     *
     * @return
     */
    public static boolean getHistoryShow() {
        return MMKVUtils.getMMKV().getBoolean(Constant.KV_HISTORY_SHOW, false);
    }

    /**
     * 卡顿优化云控配置信息
     *
     * @return false
     */
    public static boolean catonOptimizationOpen() {
        return Constants.catonOptimizationOpen;
    }

    /**
     * 游戏快捷方式开关配置
     *
     * @return 0(打开)/1(关闭)
     */
    public static int getAutoCreate() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_AUTO_CREATE, 1);
    }

    /**
     * 获取游戏快捷方式配置信息
     *
     * @return
     */
    @NonNull
    public static ServerAutoBean.ShortcutConfig getShortcutConfig() {
        String shortcutConfigStr = SPManager.getString(Constant.KEY_VA_SHORTCUT_CONFIG, "");
        ServerAutoBean.ShortcutConfig shortcutConfig;
        if (!TextUtils.isEmpty(shortcutConfigStr)) {
            shortcutConfig = new Gson().fromJson(shortcutConfigStr, ServerAutoBean.ShortcutConfig.class);
            if (shortcutConfig == null || shortcutConfig.frequency == null || shortcutConfig.frequency.isEmpty() || shortcutConfig.duration <= 0) {
                //配置不合法，使用默认值
                shortcutConfig = ServerAutoBean.ShortcutConfig.getDefaultShortcutConfig();
            }
        } else {
            shortcutConfig = ServerAutoBean.ShortcutConfig.getDefaultShortcutConfig();
        }
        if (BuildConfig.DEBUG) {
            Log.d(VaStaticProxy.TAG, "getShortcutConfig: " + shortcutConfig);
        }
        return shortcutConfig;
    }

    /**
     * 下载管理中心删除是否外露 默认为关
     */
    public static boolean getDownloadManagerDeleIsExpand() {
        return MMKVUtils.getMMKV().getBoolean(Constant.KV_MANAGE_DOWNLOAD_DELETE, false);
    }


    /**
     * X天保护期
     */
    public static int getXDayProtector() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_X_DAY_PROTECTOR, 7);
    }


    /**
     * 获取DLC校验开关 （默认 关）
     *
     * @return
     */
    public static boolean isDLCCheckOpen() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_DLC_SWITCH, 0) == 1;
    }


    /**
     * 常驻通知授权弹框提醒间隔 默认30天
     *
     * @return
     */
    public static int getNotifyToggleIntervalTime() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_NOTIFY_TOGGLE_INTERVAL, 30);
    }

    public static int geToggleMaxNotifyLimit() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_NOTIFY_TOGGLE_MAX, 3);
    }

    /**
     * 获取是否忽略系统保活，默认忽略
     *
     * @return
     */
    public static boolean isCheckKeepAliveOpen() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_NOTITY_TOGGLE_IGNORE, 1) == 0;
    }

    /**
     * tpms拉活功能开关
     *
     * @return
     */
    public static boolean isTPMSKeepAliveOpen() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_TPMS_ALIVE_SWITCH, 0) == 1;
    }

    /**
     * 获取后台配置的分段下载标志
     */
    public static int getSplitDownloadFlag() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_SPLIT_SWITCH, 1);
    }

    /**
     * 获取后台配置的分段下载最大重试次数
     */
    public static int getSplitRetryCount() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_SPLIT_RETRYCOUNT, 60); //默认60次
    }


    /**
     * 获取归因最大重试次数
     */
    public static int getAsyncRetryCount() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_ASYNC_RETRYCOUNT, 0);
    }

    /**
     * 获取举手上报最大重试次数
     */
    public static int getHandReportRetryCount() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_ASYNC_REPORTCOUNT, 0);
    }


    /**
     * 是否震动
     */
    public static boolean isVibration() {

        String start = MMKVUtils.getMMKV().getString(Constant.KV_OFFER_NOTIFY_STARTTIME, null);
        String end = MMKVUtils.getMMKV().getString(Constant.KV_OFFER_NOTIFY_ENDTIME, null);
        boolean isVibration = MMKVUtils.getMMKV().getBoolean(Constant.KV_OFFER_NOTIFY_ISVIBRATE, false);
        return isVibration && TimeUtil.timeRange(start, end);
    }

    /**
     * 通知展示间隔时间
     */
    public static int getIntervalTime() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_OFFER_NOTIFY_INTERVAL, 0);
    }

    /**
     * 获取下载安装空间锁定开关( 1： 打开；  0：关闭；   默认打开)
     */
    public static boolean isOpenSpaceLock() {
        //TODO: 此功能暂时关闭，后续关注；因此功能导致PS崩溃(频繁操作任务下载暂停时)；由于下载应用时会异步创建一个临时的与下载包大小一样的占位文件，暂停时删除（处理空间不足时候增加的功能）
        return false; //MMKVUtils.getMMKV().getBoolean(Constant.KV_SPACE_LOCK_SWITCH, true);
    }


    public static long getLoadingShowTime() {

        long time = MMKVUtils.getMMKV().getLong(Constant.KV_PRE_CACHE_LOADINGTIME, 3000);
        return time <= 0 ? 3000 : time;
    }


    public static int getBigFileDownloadSwitch() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_BIGFILE_SWITCH, 1);
    }

    /**
     * 插队间隔时间
     *
     * @return
     */
    public static int getCutInlineInterval() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_CUT_INLINE_INTERVAL, 0);
    }


    public static int getPlutoCfgSwitch() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_PLUTO_SWITCH, 1);
    }

    /**
     * 安装完成通知有效期
     *
     * @return 有效期，单位小时（h）
     */
    public static int getInstalledNotifyValidateTime() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_NOTIFY_INSTALLED_VLIDATETIME, 24);
    }

    /**
     * 半详情页安装完成后自动打开应用标记  (老)
     *
     * @return
     */
    public static boolean getAutoOpenFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_HALF_DETAIL_AUTOOPEN, false);
    }

    /**
     * 半详情页 自动下载 标记 (老)
     *
     * @return
     */
    public static boolean getAutoDownloadFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_HALF_DETAIL_AUTODOWNLOAD, false);
    }


    /**
     * 是否支持launcher下载安装管理能力（默认关）
     *
     * @return
     */
    public static boolean getLauncherSwitchFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_LAUNCHER_SWITCH, false);
    }

    /**
     * pluto老客提醒场景是否支持launcher下载管理能力开关， （默认关）
     *
     * @return
     */
    public static boolean getPlutoSwitchFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_LAUNCHER_PLUTO_SWITCH, false);
    }

    /**
     * 一键安装是否支持launcher下载管理能力开关， （默认关）
     *
     * @return
     */
    public static boolean getRecommendInstallSwitchFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_RECOMMEND_INSTALL_SWITCH, false);
    }


    /**
     * 是否支持云服务下载安装管理能力（默认关）
     *
     * @return
     */
    public static boolean getCloudBackupSwitchFlag() {
        // 入库版本默认打开
        boolean defValue = TRApplicationContextUtil.isProject();
        return MMKVUtils.getMMKV().getBoolean(Constant.KV_CLOUD_BACKUP_SWITCH, defValue);
    }

    /**
     * @return 是否展示offline
     */
    public static boolean isShowOffline() {
        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_HOME_TOOLS_COUNTRY, null);
        if (set != null && set.size() > 0) {
            Iterator<String> it = set.iterator();
            while (it.hasNext()) {
                String country = it.next();
                if (PhoneDeviceInfo.getCountryCode().equalsIgnoreCase(country)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @return offline配置是否获取到
     */
    public static boolean isOfflineConfigIsNotNull() {
        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_HOME_TOOLS_COUNTRY, null);
        return (set != null && set.size() > 0);
    }


    /**
     * 获取预加载状态请求间隔时间（单位：小时）
     */
    public static int getPreorderLoadTimeInterval() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_PREORDER_INTERVAL, 0);
    }

    /**
     * 获取下载MD5校验最大重试次数
     */
    public static int getMD5TimesMax() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_MD5_RETRY_COUNT, 0);
    }

    /**
     * 获取后台配置的下载最大线程数
     */
    public static int getConnectionCountMax() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(PalmplayApplication.getAppInstance());
        return sp.getInt("count", 0);
    }


    /**
     * 常驻通知offline红点开关， （默认关）
     *
     * @return
     */
    public static boolean getOfflineTipsFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_TOOLBAR_OFFLINE_SWITCH, false);
    }

    /**
     * 常驻通知offline红点展示间隔， （默认12小时）
     *
     * @return
     */
    public static int getOfflineTipsShowTime() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_TOOLBAR_OFFLINE_SHOWTIME, 12);
    }

    /**
     * 常驻通知StatusSaver 红点开关， （默认关）
     *
     * @return
     */
    public static boolean getStatusSaverTipsFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_TOOLBAR_STATUSAVER_SWITCH, false);
    }

    /**
     * 常驻通知StatusSaver 红点展示间隔（默认12小时）
     *
     * @return
     */
    public static int getStatusSaverTipsShowTime() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_TOOLBAR_STATUSAVE_SHOWTIME, 12);
    }

    /**
     * 常驻通知StatusSaver 红点展示间隔（默认4小时）
     *
     * @return
     */
    public static int getStatusSaverCheckUpdateTime() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_TOOLBAR_STATUSAVE_CHECKTIME, 4);
    }

    /**
     * 常驻通知垃圾清理红点开关， （默认关）
     *
     * @return
     */
    public static boolean getCleanTipsFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_TOOLBAR_CLEAN_SWITCH, false);
    }

    /**
     * 常驻通知垃圾清理红点展示间隔， （默认12小时）
     *
     * @return
     */
    public static int getCleanTipsShowTime() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_TOOLBAR_CLEAN_SHOWTIME, 12);
    }

    /**
     * 常驻通知offer红点开关， （默认关）
     *
     * @return
     */
    public static boolean getHomeTipsFlag() {

        return MMKVUtils.getMMKV().getBoolean(Constant.KV_TOOLBAR_HOME_SWITCH, false);
    }

    /**
     * 常驻通知offer红点展示间隔， （默认12小时）
     *
     * @return
     */
    public static int getHomeTipsShowTime() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_TOOLBAR_HOME_SHOWTIME, 12);
    }


    public static boolean modelBizNotNull() {
        return MMKVUtils.getMMKV().getBoolean(Constant.KV_GT_INTERRUPT, false);
    }

    /**
     * GT 专项
     *
     * @param value
     * @return
     */
    public static boolean isNeedIntercept(String value) {
        if (!MMKVUtils.getMMKV().getBoolean(Constant.KV_GT_INTERRUPT, false)) {
            return false;
        }
        switch (value) {
            case TRActivateConstant.GT_COMMON_NOTIFICATION:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_COMMON_NOTIFY);
            case TRActivateConstant.GT_OFFLINE_NOT_FLOAT:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_OFFLINE_FLOAT);

            case TRActivateConstant.GT_INSTALL_COMPLETE_NOT_FLOAT:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_INSTALL_FLOAT);

            case TRActivateConstant.GT_INSTALL_COMPLETE:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_INSTALL_NOTIFY);

            case TRActivateConstant.GT_TOOL_BAR_NOTIFY:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_TOOLBAR_NOTIFY);

            case TRActivateConstant.GT_RECALL_NOT_FLOAT:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_RECALL_FLOAT);

            case TRActivateConstant.GT_LAUNCHER_READ_DOT_TIPS:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_LAUNCHE_REDDOT);

            case TRActivateConstant.GT_GUIDE:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_NEW_GUIDE);

            case TRActivateConstant.GT_OLD_GUIDE:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_OLD_GUIDE);

            case TRActivateConstant.GT_CLEAR_SPACE_NOT_FLOAT:
                return 0 == MMKVUtils.getMMKV().getInt(Constant.KV_GT_CLEAR_FLOAT);
        }
        return false;
    }

    public static HalfScreenDetailConfig.PSConfig getHalfScreenStyleWithPSConfig(String fromPage, String originDetailStyle, String positionId, String mediaName, String sceneCode, String pkg, PslinkInfo pslinkInfo) {
        if(TextUtils.isEmpty(fromPage) || TextUtils.isEmpty(originDetailStyle)) {
            return null;
        }
        List<HalfScreenDetailConfig.PSConfig> psConfigs = ConfigManager.getHalfScreenDetailConfig(Constant.KV_HALF_SCREEN_DETAIL_STYLE_CONFIG_PS);
        if(psConfigs != null && !psConfigs.isEmpty()) {
            for (HalfScreenDetailConfig.PSConfig config : psConfigs) {
                String halfScreenStyle = config.hitConfig(fromPage, originDetailStyle, pslinkInfo,mediaName, sceneCode, pkg, positionId);
                if (!TextUtils.isEmpty(halfScreenStyle)) {
                    return config;
                }
            }
        }
        return null;
    }

    /**
     * 获取实际将要展示的半屏风格
     * @return    {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_A}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_B}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_C}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_D}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_E}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_F}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_G}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_H}
     *            {@link  com.afmobi.util.Constant#HALFDETAIL_STYLE_I}
     * */
    public static String getHalfScreenStyle(String type) {

        String defaultStyle = Constant.HALFDETAIL_STYLE_A;

        Set<String> set = MMKVUtils.getMMKV().getStringSet(Constant.KV_HALF_SCREEN_TYPES, null);
        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "halfScreenTypes=" + set);
        if (set == null || set.size() <= 0) {
            LogUtils.d(LogUtils.TAG_HALF_DETAIL, "halfScreenTypes is null or empty, return A");
            return defaultStyle; //默认A
        }

        List<String> list = new ArrayList<>(set);
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            String item = it.next();
            if (!TextUtils.isEmpty(item) && item.equalsIgnoreCase(type)) {
                String style = item.toUpperCase();  //下发类型与兜底类型一致，展示下发类型, 如果下发类型不支持则展示A风格
                switch (style) {
                    case Constant.HALFDETAIL_STYLE_A:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_A;
                    case Constant.HALFDETAIL_STYLE_B:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_B;
                    case Constant.HALFDETAIL_STYLE_C:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_C;
                    case Constant.HALFDETAIL_STYLE_D:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_D;
                    case Constant.HALFDETAIL_STYLE_E:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_E;
                    case Constant.HALFDETAIL_STYLE_F:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_F;
                    case Constant.HALFDETAIL_STYLE_G:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_G;
                    case Constant.HALFDETAIL_STYLE_H:
                        LogUtils.d(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_H;
                    case Constant.HALFDETAIL_STYLE_I:
                        LogUtils.i(LogUtils.TAG_HALF_DETAIL, "hit halfScreenStyle=" + style);
                        return Constant.HALFDETAIL_STYLE_I;
                }
            }
        }
        LogUtils.i(LogUtils.TAG_HALF_DETAIL, "not hit halfScreenStyle, return defaultStyle:"+defaultStyle );
        return defaultStyle;
    }

    /**
     * 应用打开无网络提示弹窗 - 开关
     *
     * @return
     */
    public static boolean isNoNetTipsOpen() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_NO_NET_TIPS_SWITCH, 0) == 1;
    }

    /**
     * 应用打开无网络提示弹窗 - 最大显示次数
     *
     * @return
     */
    public static int getMaxTimesNoNetTips() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_NO_NET_TIPS_TIMES, 0);
    }

    /**
     * 应用打开时有网络的次数 - 最大显示次数
     *
     * @return
     */
    public static int getMaxTimesNetworkOpen() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_BY_NET_OPEN_TIMES, 3);
    }


    /**
     * 应用打开无网络提示弹窗 - offer应用的有效期 单位 天
     *
     * @return
     */
    public static int getExpireNoNetTips() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_NO_NET_EXPIRE_DAYS, 7);
    }

    /**
     * 应用阻塞归因上报 - 最大重试次数
     *
     * @return
     */
    public static int getBlockAttributionRetryTimes() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_BLOCK_RETRY_TIMES, 0);
    }

    /**
     * 应用阻塞归因上报 - 超时时间 (s)
     *
     * @return
     */
    public static int getBlockAttributionRetryTimeout() {

        return MMKVUtils.getMMKV().getInt(Constant.KV_BLOCK_RETRY_TIMEOUT, 20);
    }


    /**
     * 获取新手引导是否展示
     *
     * @return
     */
    public static boolean getGuideShowType() {
        //若获取为false时，查看之前下发记录
        return SpUtil.getSP().getBoolean(TRAnalyticsConstant.SHOW_GUIDE_CONFIG, false);
    }


    public static long getFeatureTabDataMark() {
        long mFeatureTabDataMark = SPManager.getLong(FEATURE_TAB_DATA_MARK, 0);
        return mFeatureTabDataMark;
    }

    /**
     * 获取Cronet开关
     *
     * @return "1"开启 "0"关闭 默认关闭
     */
    public static int getNetSwitch() {
        return MMKVUtils.getMultiMMKV().getInt(NetHelperKt.KV_NET_SWITCH, NetHelperKt.KV_NET_SWITCH_DEFAULT);
    }

    /**
     * 是否需要拉取半屏详情样式配置
     * @param interval
     * @return
     */
    public static boolean enableFetchHalfDetailStyleConfig(long interval) {
        long lastTime = MMKVUtils.getMultiMMKV().getLong(Constant.KV_HALF_DETAIL_LAST_FETCH, 0);
        return System.currentTimeMillis() - lastTime > interval;
    }

    /**
     * 设置拉取半屏详情样式配置时间
     */
    public static void setFetchHalfDetailStyleConfigTime() {
        MMKVUtils.getMultiMMKV().putLong(Constant.KV_HALF_DETAIL_LAST_FETCH, System.currentTimeMillis());
    }


    /**
     * 获取newDiff开关
     *
     * @return "1"开启 "0"关闭 默认关闭
     */
    public static int getNewDiffSwitch() {
        return AppDataManager.NEW_DIFF_SWITCH ? MMKVUtils.getMultiMMKV().getInt(HsynzCompatKt.KV_NEWDIFF_SWITCH, HsynzCompatKt.KV_NEWDIFF_SWITCH_CLOSED) : 0;
    }

    /**
     * 获取newDiff开关
     *
     * @return "1"开启 "0"关闭 默认关闭
     */
    public static int getNewDiffMaxRanges() {
        return MMKVUtils.getMultiMMKV().getInt(HsynzCompatKt.KV_NEWDIFF_MAX_RANGES, HsynzCompatKt.NEWDIFF_MAX_RANGES_DEFAULT);
    }

    /**
     * 开关 （默认 关）
     */
    public static boolean isHgupOpen() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_HGUP_SWITCH, 0) == 1;
    }


    /**
     * 桌面角标开关 （默认 开）
     */
    public static boolean isLauncherDotSwitchOpen() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_LAUNCHER_DOT_SWITCH, 1) == 1;
    }

    public static boolean isOS12SkipGdpr() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_GDPR_OS12_SWITCH, 1) == 1;
    }

    /**
     * gdpr需要重新授权
     *
     * @return
     */
    public static boolean isGdprNeedReauthorize() {
        boolean isGdprNeedReauthorize = MMKVUtils.getMMKV().getInt(TRSharedPreferenceUtils.KV_GDPR_REAUTHORIZE, 0) == 1;
        LogUtils.d(LogUtils.TAG_PS_GDPR, "isGdprNeedReauthorize == " + isGdprNeedReauthorize);
        return isGdprNeedReauthorize;
    }

    /**
     *
     * 隐私体验计划开关  1 （int类型，1 打开：0 关闭）
     */
    public static boolean isPrivacyExpSwitch() {
        boolean isPrivacyExpSwitch = MMKVUtils.getMMKV().getInt(TRSharedPreferenceUtils.KV_PRIVACY_EXP_SWITCH, 0) == 1;
        LogUtils.d(LogUtils.TAG_PS_GDPR, "isPrivacyExpSwitch == " + isPrivacyExpSwitch);
        return isPrivacyExpSwitch;
    }


    /**
     * 获取老手安装云控开关  默认1 打开
     *
     * @return true 打开  false 关闭
     */
    public static boolean enableArCloudControl() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_INSTALL_AR, 1) == 1;
    }


    public static boolean enableARRealTimeControl() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_AR_REALTIME_ENABLE, 0) == 1;
    }


    /**
     * 获取新手安装云控开关  默认1 打开
     *
     * @return true 打开  false 关闭
     */
    public static boolean enableNrCloudControl() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_INSTALL_NR, 1) == 1;
    }

    /**
     * 获取配置的悬浮球数据
     *
     * @return
     */
    public static ConcurrentHashMap<String, List<Map<String, List<String>>>> getFloatballData() {
        String txt = MMKVUtils.getMMKV().getString(Constant.KV_DEEPLINK_FLOATBALL, null);
        try {
            if (!TextUtils.isEmpty(txt)) {
                FloatballConfig config = new Gson().fromJson(txt, FloatballConfig.class);
                if (config != null && config.parameterValue != null) {
                    return config.parameterValue;
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return null;
    }
    /**
     * 获取详情页预加载配置信息
     * @return
     */
    public static DetailPreCacheInfo.DetailPreCacheConfig getDetailPreCacheConfig() {
        String txt = MMKVUtils.getMMKV().getString(Constant.KV_DETAIL_PRE_CACHE_CONFIG, null);
        try {
            if (!TextUtils.isEmpty(txt)) {
                DetailPreCacheInfo config = new Gson().fromJson(txt, DetailPreCacheInfo.class);
                if (config != null && config.parameterValue != null) {
                    return config.parameterValue;
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return null;
    }

    /**
     * 通知权限引导配置信息
     * @return
     */
    public static NotifyGuideInfo getNotifyGuideInfo() {
        String txt = MMKVUtils.getMMKV().getString(Constant.KV_NOTIFY_GUIDE, null);
        try {
            if (!TextUtils.isEmpty(txt)) {
                NotifyGuideInfo config = new Gson().fromJson(txt, NotifyGuideInfo.class);
                if (config != null) {
                    return config;
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return null;
    }

    /**
     * 后台配置是否可以显示悬浮球
     *
     * @param fromPage
     * @param source
     * @param pkgName
     * @return
     */
    public static boolean canShowFloatballCloudControl(String fromPage, String source, String pkgName) {
        if (fromPage == null || source == null || pkgName == null) {
            return false;
        }

        ConcurrentHashMap<String, List<Map<String, List<String>>>> map = getFloatballData();
        if (map == null || map.isEmpty()) {
            return false;
        }

        List<Map<String, List<String>>> floatballPkgConfigList = map.get(fromPage);
        if (floatballPkgConfigList == null || floatballPkgConfigList.isEmpty()) {
            return false;
        }

        for (Map<String, List<String>> floatballPkgConfig : floatballPkgConfigList) {
            if (floatballPkgConfig == null) {
                continue;
            }

            List<String> sourceList = floatballPkgConfig.get(pkgName);
            if (sourceList != null && sourceList.contains(source)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 获取403重试域名集合
     * @return
     */
    public static List<String> getDownloadCdnRetryDomains() {
        String txt = MMKVUtils.getMMKV().getString(Constant.KV_DOWNLOAD_CDN_RETRY_DOMAINS, null);
        try {
            if (!TextUtils.isEmpty(txt)) {
                Type listType = new TypeToken<List<String>>(){}.getType();
                return GsonUtils.getInstance().fromJson(txt,listType);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return null;
    }

    /**
     * game feature页面使用旧样式或者新样式
     * @return 0：旧样式, 1：新样式：带 banner UI; 默认值 0
     */
    public static boolean isGameInstantNew() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_GAME_INSTANT_OLDORNEW, 0) == 1;
    }

    /**
     * game 沉浸式banner开启与否
     * @return 0：关闭, 1：开启; 默认值 1
     */
    public static boolean isGameImmersiveEnable() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_GAME_IMMERSIVE_BANNER, 1) == 1;
    }

    /**
     * 获取 Instant 离线资源配置信息
     * @return String of InstantOfflineResourceConfigInfo
     */
    public static String getGameInstantOfflineResourceConfig() {
        return SPManager.getString(Constant.PREFERENCES_KEY_H5_OFFLINE_GAME_CONFIG_TIME, "");
    }

    /**
     * Android14+ UpdateOwnership 抹除开关（默认关）
     */
    public static boolean isUpdateOwnershipClearEnable() {
        int result = MMKVUtils.getMMKV().getInt(Constant.KV_UPDATE_OWNERSHIP_CLEAR_ENABLE, 0);
        return (result == 1);
    }

    /**
     * 开关 （默认 开）
     */
    public static boolean isBootInterceptOpen() {
        return MMKVUtils.getMMKV().getInt(Constant.KV_SLIM_BOOT_INTERCEPT_SWITCH, 1) == 1;
    }

}

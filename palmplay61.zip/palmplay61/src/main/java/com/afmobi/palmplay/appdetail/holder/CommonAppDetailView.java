package com.afmobi.palmplay.appdetail.holder;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TypefaceSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.ViewPager;

import com.afmobi.palmplay.appdetail.AppDetailUtils;
import com.afmobi.palmplay.appdetail.DownloadHandlerInf;
import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommentInfo;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.DetailResponseData;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.viewmodel.detail.AppDetailUIPageAdapter;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.FileUtils;
import com.afmobi.util.IMessenger;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.tabs.TabLayout;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.DeviceTypeExKt;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ZActivityNewAppDetailLayoutBinding;
import com.transsnet.store.databinding.ZLayoutAppDetailsComponentHeadBinding;
import com.transsnet.store.databinding.ZLayoutAppDetailsComponentUdsBinding;

import java.util.List;
import java.util.Map;

public class CommonAppDetailView {
    private static final String TAB_HOME = "0";
    private static final String TAB_DETAIL = "1";
    private static final String TAB_REVIEW = "2";

    private FragmentActivity activity;
    private TRNewAppViewModel mAppDetailModel;//挪走
    public AppInfo mAppInfo;
    public String mType;
    private boolean isCustomized;
    public PageParamInfo mPageParamInfo;
    public String mFrom;

    public ZActivityNewAppDetailLayoutBinding mBinding;
    public ZLayoutAppDetailsComponentHeadBinding headerViewBinding;
    public ZLayoutAppDetailsComponentUdsBinding appInfoViewBinding;

//    public ShapeableImageView ivIcon;
//    public View mVaFlagView;
//    public TextView tvName;
//    public TextView tvDownloadcount, tvUdsStars, tvSize, tvSizeUnit, tvDownloadcountUnit;

    private ViewTreeObserver.OnGlobalLayoutListener mGlobalListener;
    public AppDetailUIPageAdapter mTabAdapter;

    public int currentPosition = 0;
    private boolean isFeaturedTrack = false;

    public OnViewLocationInScreen mOnViewLocationInScreen = new OnViewLocationInScreen() {

        @Override
        public Object onPreparedCallback(Object obj) {
            return null;
        }

        @Override
        public Object getObject(Object obj) {
            return mBinding.titleInclude.layoutDetailDownload;
        }

        @Override
        public int[] onEndTranslateAnimationLocationOnScreen(Object obj) {
            int[] endTranslateAnimationLocationOnScreen = new int[2];
            if (mBinding.titleInclude.layoutDetailDownload != null) {
                mBinding.titleInclude.layoutDetailDownload.getLocationOnScreen(endTranslateAnimationLocationOnScreen);
                int viewWidth = mBinding.titleInclude.layoutDetailDownload.getWidth();
                if (viewWidth > 0) {
                    endTranslateAnimationLocationOnScreen[0] = endTranslateAnimationLocationOnScreen[0] + viewWidth / 4;// 3;
                }
            }
            return endTranslateAnimationLocationOnScreen;
        }

        @Override
        public Object onAnimationEndCallback(Object obj) {
            return null;
        }

    };

    public CommonAppDetailView(FragmentActivity activity, ZActivityNewAppDetailLayoutBinding mBinding,
                               TRNewAppViewModel mAppDetailModel) {
        this.mBinding = mBinding;
        this.activity = activity;
        this.mAppDetailModel = mAppDetailModel;
        initView();
    }

    /**
     * 需要改掉，并且触发UI变动
     * @param mAppInfo
     * @param mPageParamInfo
     * @param mType
     * @param isCustomized
     * @param mFrom
     */
    public void setData(AppInfo mAppInfo, PageParamInfo mPageParamInfo, String mType, boolean isCustomized,
                        String mFrom) {
        this.mAppInfo = mAppInfo;
        this.mPageParamInfo = mPageParamInfo;
        this.mType = mType;
        this.isCustomized = isCustomized;
        this.mFrom = mFrom;
    }

    public void initHolder(boolean tipsVisible, int restoreTab){
        updateDownloadCount();
        updateSizeInfo();
        updateTitle();
        initViewPager(tipsVisible, restoreTab);
        setupPager();
    }

    private void initView(){
        LayoutInflater inflater = LayoutInflater.from(activity);
        appInfoViewBinding = DataBindingUtil.inflate(inflater, R.layout.z_layout_app_details_component_uds, null, false);
        headerViewBinding = DataBindingUtil.inflate(inflater, R.layout.z_layout_app_details_component_head, null, false);
    }

    private void initViewPager(boolean tipsVisible, int restoreTab){
        mTabAdapter = new AppDetailUIPageAdapter(activity.getSupportFragmentManager(), activity, mAppInfo, mAppDetailModel.getAppOtherModel(), mPageParamInfo,
                mOnViewLocationInScreen, isCustomized, AppDetailUtils.isUseSmallCache(mType), isFromPluto());

        mTabAdapter.setTipsVisible(tipsVisible);
        mBinding.viewpager.setAdapter(mTabAdapter);
        mBinding.tabLayout.setupWithViewPager(mBinding.viewpager);
        updateTabLayoutMode(tipsVisible);
        mBinding.viewpager.setOffscreenPageLimit(mTabAdapter.getCount());
        // adapter & count 稳定后，再恢复 currentItem
        if (restoreTab < mTabAdapter.getCount()) {
            mBinding.viewpager.setCurrentItem(restoreTab, false);
        }

        mGlobalListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mBinding.viewpager.getViewTreeObserver().removeOnGlobalLayoutListener(this);

                int[] location = new int[2];
                mBinding.layoutBottom.getLocationOnScreen(location);
                int[] pagerLocation = new int[2];
                mBinding.viewpager.getLocationOnScreen(pagerLocation);

                int contentH = Math.max(0, location[1] - pagerLocation[1]);
                if(mTabAdapter != null) {
                    mTabAdapter.onViewGlobalObserver(contentH);
                }
            }
        };
        mBinding.viewpager.getViewTreeObserver().addOnGlobalLayoutListener(mGlobalListener);
    }

    private void setupPager() {
        LayoutInflater inflater = LayoutInflater.from(activity);
        for (int i = 0; i < mBinding.tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = mBinding.tabLayout.getTabAt(i);
            if (tab != null) {
                TextView tv = getOrCreateTabTextView(inflater, tab);
                if (tv != null) {
                    if (isCustomized) {
                        ColorStateList tabColor = ContextCompat.getColorStateList(activity, R.color.detail_tab_text_color_offer);
                        tv.setTextColor(tabColor);
                    }
                    tv.setText(mTabAdapter.getPageTitle(i));
                    tv.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                }

                if(tab.getCustomView() != null && tab.getCustomView().getParent() != null) {
                    View parentView = (View) tab.getCustomView().getParent();
                    parentView.setTag(i);
                    parentView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(v.getTag() instanceof Integer) {
                                int pos = (int) v.getTag();

                                if(mAppInfo != null && mAppDetailModel != null) {
                                    String module = (pos == 0) ? TRAnalyticsConstant.DETAIL_DETAILS : (pos == 1) ? TRAnalyticsConstant.MODULE_COMMENT : (pos == 2) ? TRAnalyticsConstant.FEATURE_MODULE : TRAnalyticsConstant.TIP_SHOW_TIPSTRICK;
                                    String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, module, "", "");
                                    mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value, TRAnalyticsConstant.BUTTON, mAppInfo.itemID, mAppInfo.packageName, mAppInfo.item_type,
                                            mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);
                                }
                            }
                        }
                    });
                }
            }
        }

        if (isCustomized) {
            int mainColor = ContextCompat.getColor(activity, R.color.detail_offer_main_color);
            mBinding.tabLayout.setSelectedTabIndicatorColor(mainColor);
        }

        onTabPageChanged(0);
        mTabAdapter.clickTab(0);

        mBinding.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                onTabPageChanged(position);
                mTabAdapter.clickTab(position);
                currentPosition = position;

                if(position == 2 && !isFeaturedTrack) {
                    isFeaturedTrack = true;
                    mAppDetailModel.trackEvent(6, mAppInfo);
                    if (mTabAdapter != null) {
                        mTabAdapter.onFeaturedTabShow();
                    }
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        setTab();
    }

    private TextView getOrCreateTabTextView(LayoutInflater inflater, TabLayout.Tab tab) {
        // Cache and network refreshes call setupPager repeatedly; reuse the view to avoid stacking titles.
        View customView = tab.getCustomView();
        TextView textView = customView != null ? customView.findViewById(android.R.id.text1) : null;
        if (textView != null) {
            return textView;
        }

        View view = inflater.inflate(R.layout.layout_detail_tab_item, null);
        textView = view.findViewById(android.R.id.text1);
        if (textView != null) {
            tab.setCustomView(textView);
        }
        return textView;
    }

    private void updateTitle(){
        String title = (String) mAppDetailModel.getParam("mArgumentsTitle");//mAppDetailModel 去掉，传参数解决这种
        headerViewBinding.tvName.setText(title);
        headerViewBinding.tvName.requestFocus();
    }

    private void updateDownloadCount(){
        Map<String, String> entity = CommonUtils.getDetailDownloadCountStr((int) mAppDetailModel.getParam("downloadcount"));
        String downloadCount = entity != null ? entity.get("count") : null;
        String unit = entity != null ? entity.get("unit") : null;
        appInfoViewBinding.tvDownloadcount.setText(downloadCount);
        appInfoViewBinding.tvDownloadcountUnit.setText(unit);
    }

    private void updateSizeInfo() {
        String size = FileUtils.getSizeName((long) mAppDetailModel.getParam("size"));
        int length = size.length();
        if (length > 2) {
            appInfoViewBinding.tvSize.setText(size.substring(0, length - 2));
            appInfoViewBinding.tvSizeUnit.setText(size.substring(size.length() - 2));
        } else {
            appInfoViewBinding.tvSize.setText(size);
            appInfoViewBinding.tvSizeUnit.setText("");
        }
    }

    private boolean isFromPluto() {
        boolean isPluto = false;
        Object val = (mAppDetailModel != null) ? mAppDetailModel.getParam("isPluto") : false;
        if(val instanceof Boolean) {
            isPluto = ((Boolean) val).booleanValue();
        }
        return isPluto;
    }

    public List<DetailComponentItemData> onAppInfoChanged(DetailResponseData response, boolean isLoadData){
        List<DetailComponentItemData> componentList = response != null ? response.getComponentListByStyle(AppDetailsRecyclerViewAdapter.TAB_TYPE_DETAIL) : null;

        boolean tipsVisible = response != null && response.findFlag == 1;

        if (BuildConfig.DEBUG) {
           LogUtils.d(LogUtils.TAG_NETWORK, "tipsVisible : " + tipsVisible + "   findFlag : " + (response == null ? " newResp null" : response.findFlag));
        }

        int oldIndex = mBinding.viewpager.getCurrentItem();
        updateTabLayoutMode(tipsVisible);
        mAppDetailModel.setTipsVisible(tipsVisible);
        mTabAdapter.setTipsVisible(tipsVisible);
        int newCount = mTabAdapter.getCount();
        if (oldIndex < newCount) {
            mBinding.viewpager.setCurrentItem(oldIndex, false);
        }

        setupPager();

        mTabAdapter.onAppInfoChanged(mAppInfo, componentList, isLoadData );
        return componentList;
    }

    public void onTabPageChanged(int position) {
        if(position < 0 || position >= mBinding.tabLayout.getTabCount()) {
            return;
        }

        for(int i = 0; i < mBinding.tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = mBinding.tabLayout.getTabAt(i);
            if (tab != null && tab.getCustomView() != null) {
                TextView tv = tab.getCustomView().findViewById(android.R.id.text1);
                if (tv != null && !TextUtils.isEmpty(tv.getText())) {
                    String txt = tv.getText().toString();
                    SpannableString spannable = new SpannableString(txt);
                    String fontfamily = (position == i) ? ("sans-serif-medium") : ("sans-serif");
                    spannable.setSpan(
                            new TypefaceSpan(fontfamily),
                            0, txt.length(),
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    );
                    tv.setText(spannable);
                }
            }
        }
    }

    public void setTab(){
        if (mBinding == null || mBinding.viewpager == null) return;
        String tabId = mAppDetailModel.getTabId();
        if (tabId != null){
            switch(tabId) {
                case TAB_HOME:
                    mBinding.viewpager.setCurrentItem(0);
                    break;
                case TAB_DETAIL:
                    mBinding.viewpager.setCurrentItem(1);
                    break;
                case TAB_REVIEW:
                    mBinding.viewpager.setCurrentItem(2);
                    break;
            }

        }
    }



    public void onCommentItemClick(CommentInfo info) {
        if (info != null && mTabAdapter != null) {
            mBinding.viewpager.setCurrentItem(1, true);
            currentPosition=1;
        }
    }

    public void jump2FeatureTab() {
        // 跳转到FeatureTab（item = 2）
        mBinding.viewpager.setCurrentItem(2, false);
        currentPosition = 2;
        mBinding.viewpager.postDelayed(() -> {
            // 收起头部
            mBinding.appbarLayout.setExpanded(false, true);
        }, 200);

    }

    public void initIMessager(DownloadHandlerInf downloadHandlerInf){
        mTabAdapter.setIMessager(new IMessenger() {
            @Override
            public void onMessenger(Object... objects) {
                if(objects != null && objects.length > 0 && objects[0] instanceof Float) {
                    Float star = (Float) objects[0];
                    if(mAppInfo != null) {
                        mAppInfo.score = (float) star;
                    }
                    String sScore = String.valueOf(star);
                    updateStarDisplay(sScore);

                    DetailResponseData responseData = mAppDetailModel.getDetailResponseLiveData().getValue();
                    if (responseData != null) {
                        DetailComponentItemData component = responseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_ITEM_INFO);
                        if (component != null) {
                            component.score = sScore;
                        }
                        DetailCacheManager.getInstance().updateDetailCache(mAppInfo.packageName, mAppInfo.itemID, sScore);
                    }
                }else if(objects != null && objects.length > 0 && objects[0] instanceof String){
                    String text = (String) objects[0];
                    if (TextUtils.equals(text, AppDetailsRecyclerViewAdapter.COMPONET_WELFARE)) {
                        if (downloadHandlerInf != null){
                            downloadHandlerInf.handDownload(null, mAppInfo, mFrom);
                        }
                    }
                }else if (objects != null && objects.length > 1 && objects[0] instanceof CommentInfo) {
                    CommentInfo info = (CommentInfo) objects[0];
                    int type = (int) objects[1];
                    if (type == 1) { // comment like
                        DetailCacheManager.getInstance().updateDetailCache(mAppInfo.packageName, mAppInfo.itemID, info);
                    }else { //comment click
                        onCommentItemClick(info);
                    }
                }
            }
        });
    }

    private void updateTabLayoutMode(boolean tabVisible) {
        if (mBinding == null || mBinding.tabLayout == null || mTabAdapter == null) {
            return;
        }
        Context context = activity != null ? activity : mBinding.getRoot().getContext();
        boolean isPad = DeviceTypeExKt.isPadDisplay(context, context.getResources().getConfiguration(), DeviceTypeExKt.getContextDisplayId(context));
        //int tabCount = mTabAdapter.getCount();
        int mode = tabVisible && !isPad
                ? TabLayout.MODE_SCROLLABLE
                : TabLayout.MODE_FIXED;

        if (mBinding.tabLayout.getTabMode() != mode) {
            mBinding.tabLayout.setTabMode(mode);
        }
    }

    private void updateTipsTabVisibility(boolean tabVisible) {
        TabLayout.Tab tab =  mBinding.tabLayout.getTabAt(3);
        if (tab == null) return;

        View tabView = tab.view;

        tabView.setVisibility(tabVisible ? View.VISIBLE : View.GONE);

        // ✅ 可选保护：当前页被隐藏时，切走
        if (!tabVisible && mBinding.viewpager.getCurrentItem() == 3) {
            mBinding.viewpager.setCurrentItem(0, false);
        }
    }


    private void updateStarDisplay(String scoreText) {
        if (mAppInfo != null && mAppInfo.score > 0) {
            appInfoViewBinding.tvUdsStars.setText(scoreText);
            appInfoViewBinding.layoutStar.setVisibility(View.VISIBLE);
            appInfoViewBinding.viewStarDivider.setVisibility(View.VISIBLE);
        } else {
            appInfoViewBinding.layoutStar.setVisibility(View.GONE);
            appInfoViewBinding.viewStarDivider.setVisibility(View.GONE);
        }
    }

    public boolean onKeyDown(){
        return mTabAdapter != null && mTabAdapter.onBackPressed();
    }

    public boolean isCustomizedStyle() {
        return isCustomized;
    }

    public void onDestroy() {
        if(mGlobalListener != null) {
            mBinding.viewpager.getViewTreeObserver().removeOnGlobalLayoutListener(mGlobalListener);
        }
        mBinding.viewpager.removeCallbacks(null);
    }
}

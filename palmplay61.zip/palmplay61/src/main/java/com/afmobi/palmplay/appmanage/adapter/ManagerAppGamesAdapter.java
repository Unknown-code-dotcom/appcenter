// TOP SECRET
package com.afmobi.palmplay.appmanage.adapter;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.adapter.PalmPlayBaseDownloadAdapter;
import com.afmobi.palmplay.appmanage.ManageDownloadedActivity;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.diff.TRReflectManager;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.Constants;
import com.afmobi.util.FileUtils;
import com.google.android.material.imageview.ShapeableImageView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.glide.GlideApp;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.TRReflectConstants;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.widgetslib.widget.OSIconTextView;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.transsion.palmstorecore.util.ToastManager;

public class ManagerAppGamesAdapter extends PalmPlayBaseDownloadAdapter {
    private RecyclerView listview;
    private List<InstalledAppInfo> installedAppInfoList = new ArrayList<InstalledAppInfo>();
    private List<InstalledAppInfo> selectedApps = new ArrayList<InstalledAppInfo>();
    private HashSet<Uri> mSelectUri = new HashSet<>();
    private HashSet<String> mSelectTypes = new HashSet<>();
    private PageParamInfo mPageParamInfo;

    public static ConcurrentHashMap<String, Drawable> mLrucahe;
    private boolean mFromShare = false;
    private int mSelectedCount;
    private ManageDownloadedActivity.TextCountListener textCountListener;

    private OnClickListener mOnClickListener = new OnClickListener() {

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            if (position < 0 || position >= installedAppInfoList.size()) {
                return;
            }
            InstalledAppInfo appInfo = installedAppInfoList.get(position);

            Drawable drawable = null;
            if (mLrucahe != null) {
                drawable = mLrucahe.get(appInfo.packageName);
            }
            PsVaManager.getInstance().saveRemoveAppInfo(appInfo, drawable);
            DownloadDecorator.uninstallApp(appInfo.packageName);
            ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.deliverPageParamInfo(mPageParamInfo, PageConstants.Local_Soft_Uninstall));

            reportItemClick(appInfo.packageName, position);
        }
    };

    public void setTextCountListener(ManageDownloadedActivity.TextCountListener listener) {
        textCountListener = listener;
    }

    public void setmFromShare(boolean fromShare) {
        mFromShare = fromShare;
    }

    public ManagerAppGamesAdapter(Activity mActivity, RecyclerView listview, List<InstalledAppInfo> result) {
        super(mActivity);

        this.mActivity = mActivity;
        this.listview = listview;
        this.listview.setLayoutManager(new LinearLayoutManager(mActivity));
        if (installedAppInfoList != null) {
            installedAppInfoList.clear();
            installedAppInfoList.addAll(result);
            clearSelectedState();
        }
        this.listview.setAdapter(this);
    }

    public void setPageParamInfo(PageParamInfo pageParamInfo) {
        this.mPageParamInfo = pageParamInfo;
    }

    private void setAppData() {
        List<InstalledAppInfo> result = InstalledAppManager.getInstance().getInstalledPackageList();
        if (installedAppInfoList != null) {
            installedAppInfoList.clear();
            if (result != null) {
                for (InstalledAppInfo info : result) {
                    //可卸载列表过滤掉GameSpace
                    if (!VaStaticProxy.isInstantPluginApp(info.packageName)) {
                        installedAppInfoList.add(info);
                    }
                }
            }
        }
        notifyDataSetChanged();
    }

    public void clearSelectedState() {
        if (installedAppInfoList == null || installedAppInfoList.size() <= 0) {
            return;
        }
        for (InstalledAppInfo item : installedAppInfoList) {
            if (item.mchecked) {
                item.mchecked = false;
            }
        }
    }


    public List<InstalledAppInfo> getSelectedApps() {
        return selectedApps;
    }

    public InstalledAppInfo getItem(int position) {
        if (position < 0 || position >= getItemCount()) {
            return null;
        }
        return installedAppInfoList == null ? null : installedAppInfoList.get(position);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(mActivity).inflate(R.layout.layout_manage_installed_list_item, parent, false);
        return new ViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder1, final int position) {
        final ViewHolder holder = (ViewHolder) holder1;
        if (installedAppInfoList == null || installedAppInfoList.size() <= 0) {
            return;
        }
        final InstalledAppInfo info = installedAppInfoList.get(position);
        holder.title.setText(info.appName);
        holder.size.setText(FileUtils.getSizeName(info.size));
        holder.versions.setText("Ver" + info.versionName);
        //holder.manage_menu.setOnClickListener(mMenuClickListener);
        if (mFromShare) {
            holder.uninstall.setVisibility(View.GONE);
            holder.checkBox.setEnabled(false);
            holder.checkBox.setVisibility(View.VISIBLE);
            holder.checkBox.setOnClickListener(null);
            holder.checkBox.setChecked(info.mchecked);
            holder.mView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!info.mchecked) {//最大一次只能选10个
                        if (mSelectedCount >= 10) {
                            if (textCountListener != null) {
                                textCountListener.showToast();
                            }
                            return;
                        }
                        if (info != null && !TRStringUtil.isBlank(info.packageName)) {
                            File file = new File(info.filePath);
                            String type = TRReflectManager.getInstance().getMimeType(file.getName());
                            mSelectUri.add(Uri.fromFile(file));
                            mSelectTypes.add(type);
                            selectedApps.add(info);
                            info.mchecked = true;
                            holder.checkBox.setChecked(true);
                        }
                        mSelectedCount = mSelectedCount + 1;
                    } else {
                        if (info != null && !TRStringUtil.isBlank(info.packageName)) {
                            mSelectUri.remove(Uri.fromFile(new File(info.filePath)));
                            File file = new File(info.filePath);
                            String type = TRReflectManager.getInstance().getMimeType(file.getName());
                            mSelectTypes.remove(type);
                            selectedApps.remove(info);
                            info.mchecked = false;
                            holder.checkBox.setChecked(false);
                        }
                        mSelectedCount = mSelectedCount - 1;
                    }
                    if (textCountListener != null) {
                        textCountListener.updateCount(mSelectedCount);
                    }
                }
            });
        } else {
            holder.uninstall.setVisibility(View.VISIBLE);
            holder.checkBox.setVisibility(View.GONE);

            holder.uninstall.setTag(position);
            holder.uninstall.setOnClickListener(mOnClickListener);
            if (info.isVa) {
                //VA游戏显示Delete
                holder.uninstall.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                holder.uninstall.setText(R.string.text_delete);
            } else {
                //普通游戏显示Uninstall
                holder.uninstall.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                holder.uninstall.setText(R.string.text_uninstall);
            }
        }
        holder.image.setTag(R.id.id_installed_pos_key, position);
        if (info.isVa) {
            if (BuildConfig.PROXY_VA) {
                holder.image.setImageDrawable(VaStaticProxy.getGameIcon(info.packageName));
            } else {
                String vaGameIconUrl = PsVaManager.getInstance().getVaGameIconUrl(info.packageName);
                if (!TextUtils.isEmpty(vaGameIconUrl)) {
                    GlideApp.with(holder.image.getContext()).load(vaGameIconUrl)
                            .placeholder(R.drawable.layer_list_app_default_01_bg)
                            .into(holder.image);
                } else {
                    holder.image.setImageResource(R.drawable.layer_list_app_default_01_bg);
                }
            }
        } else {
            if (mLrucahe == null) {
                mLrucahe = new ConcurrentHashMap<>();
            }
            if (mLrucahe != null) {
                Drawable iconDrawable = mLrucahe.get(info.packageName);
                if (iconDrawable != null) {
                    holder.image.setImageDrawable(iconDrawable);
                } else {
                    TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
                        @Override
                        public void doRun() {
                            final Drawable drawable = TRBitmapManager.getApkIcon(PalmplayApplication.getAppInstance(), info.getApkGlideSimpleInfo().getApkFilePath());
                            listview.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (holder.image == null || (mActivity != null && (mActivity.isFinishing() || mActivity.isDestroyed()))) {
                                        return;
                                    }
                                    try {
                                        if (drawable == null) {
                                            holder.image.setImageResource(R.drawable.ic_launcher);
                                        } else {
                                            Object tag = holder.image.getTag(R.id.id_installed_pos_key);
                                            int tagPosition = (tag instanceof Integer) ? (int) tag : -1;
                                            if (position == tagPosition) {
                                                holder.image.setImageDrawable(drawable);
                                                if (mLrucahe != null && !mLrucahe.containsKey(info.packageName)) {
                                                    mLrucahe.put(info.packageName, drawable);
                                                }
                                            }
                                        }
                                    } catch (Exception e) {

                                    }
                                }
                            });
                        }
                    }));
                }
            }
        }

        reportPv(info.packageName, position);

    }

    // 埋点：非VA模式下单应用/游戏的点击上报
    private void reportItemClick(String packageName, int position) {
        String from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.MY_APP, "", "");
        String value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_APPS_GAMES, "", String.valueOf(position));
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(value)
                .setFrom(from)
                .setIsVa(false)
                .setItemValue(packageName)
                .setButtonType(TRAnalyticsConstant.BUTTON_Uninstall);

        TRAnalysticsUtil.trackClick(builder);
    }

    // 埋点：非VA模式下单应用/游戏的曝光
    private void reportPv(String packageName, int position) {
        String from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.MY_APP, "", "");
        String value = TRStringUtil.generateString(TRAnalyticsConstant.MY_APP, TRAnalyticsConstant.MY_APP_APPS_GAMES, "", String.valueOf(position));
        PagePvBuilder builder = new PagePvBuilder();
        builder.setValue(value)
                .setItemValue(packageName)
                .setIsVa(false)
                .setFrom(from);
        TRAnalysticsUtil.trackPV(builder);
    }

    private void confirmSend(HashSet<Uri> uri, HashSet<String> types) {
        if (TRReflectManager.getInstance().isAtLeastQ()) {
            if (!TRReflectManager.getInstance().isLocationServiceEnable(mActivity)) {
                ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.warning_open_location_service);
                return;
            }
        }
        ArrayList<String> typeList = new ArrayList<>();
        TRReflectManager.getInstance().save(uri);
        typeList.addAll(types);
        try {
            Intent intent = new Intent(mActivity, TRReflectManager.getInstance().getDesClass(TRReflectConstants.P2P_MODEL, TRReflectConstants.P2P_SEND_MODEL));
            intent.putExtra("fromPage", Constants.MyApp);
            intent.setAction(Constants.XSHARE_SEND_ACTION);
            intent.putExtra("is_send", true);
            intent.putStringArrayListExtra("types", typeList);
            mActivity.startActivity(intent);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return installedAppInfoList == null ? 0 : installedAppInfoList.size();
    }

    public HashSet<Uri> getmSelectedAapps() {
        return mSelectUri;
    }

    public HashSet<String> getTypes() {
        return mSelectTypes;
    }

    @Override
    public int loaderDetailType() {
        return DetailType.TYPE_INVALID;
    }

    @Override
    public InterfaceStatusChange loaderInterfaceStatusChange() {
        return new InterfaceStatusChange() {

            @Override
            public void onDownloadStart(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadResume(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {

            }

            @Override
            public void onDownloadPause(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadError(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadDelete(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onDownloadComplete(FileDownloadInfo downloadInfo) {

            }

            @Override
            public void onActivated(FileDownloadInfo downloadInfo) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
                for (int i = 0; i < installedAppInfoList.size(); i++) {
                    InstalledAppInfo installedAppInfo = installedAppInfoList.get(i);
                    //当普通应用卸载时，仅移除非VA应用，避免同包名的VA应用被异常
                    if (!installedAppInfo.isVa && installedAppInfo.packageName.equals(packageName)) {
                        installedAppInfoList.remove(i);
                        break;
                    }
                }

                notifyDataSetChanged();
            }

            @Override
            public void onAppPackageAdded(String packageName, int versionCode) {
                setAppData();
            }
        };
    }


    @Override
    public Object loaderInterfaceStatusChangeObjectKey() {
        return this;
    }

    private class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView subscriptVa;
        public ShapeableImageView image;
        public TextView title;
        public TextView size;
        public TextView versions;
        public TextView uninstall;
        public CheckBox checkBox;
        public OSIconTextView share;
        public View mView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.item_for_applist_image);
            title = itemView.findViewById(R.id.item_for_applist_title);
            size = itemView.findViewById(R.id.item_for_applist_size);
            versions = itemView.findViewById(R.id.item_for_applist_versions);
            uninstall = itemView.findViewById(R.id.manage_menu);
            checkBox = itemView.findViewById(R.id.check);
            subscriptVa = (ImageView) itemView.findViewById(R.id.iv_subscript_va);
            mView = itemView;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (installedAppInfoList != null) {
            installedAppInfoList.clear();
            installedAppInfoList = null;
        }
    }
}

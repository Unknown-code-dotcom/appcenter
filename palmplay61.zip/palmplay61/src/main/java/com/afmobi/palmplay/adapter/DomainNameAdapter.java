package com.afmobi.palmplay.adapter;

import com.afmobi.palmplay.configs.UrlConfig;
import com.transsion.gslb.GslbSdk;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.handsup.http.AsyncHttp;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DomainNameAdapter {
    private static volatile DomainNameAdapter sInstance;
    private String[] mDomainArray;
    private String mPreStr = "https://";
    private ConcurrentHashMap<String,String> mDomainNameHashMap;
    public static DomainNameAdapter getInstance() {
        if(sInstance == null) {
            synchronized (DomainNameAdapter.class) {
                if(sInstance == null) {
                    sInstance = new DomainNameAdapter();
                }
            }
        }
        return sInstance;
    }
    public DomainNameAdapter() {
        initDomainName();
    }

    public void initDomainName() {
        String tempStr = "";
        mDomainNameHashMap = new ConcurrentHashMap<>();
        if(BuildConfig.DEBUG) {
            mDomainArray = new String[1];
            mDomainArray[0] = UrlConfig.BASE_URL_UAT;
            tempStr = UrlConfig.BASE_URL_UAT;
            mPreStr = "http://";
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_URL_UAT,tempStr);
        } else {
            tempStr = UrlConfig.FIRST_URL_RELEASE;
            mPreStr = "https://";
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.FIRST_URL_RELEASE,tempStr);

            tempStr = UrlConfig.SECOND_URL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.SECOND_URL_RELEASE,tempStr);

            tempStr = UrlConfig.THIRD_URL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.THIRD_URL_RELEASE,tempStr);

            //todo 以下是新域名
            tempStr = UrlConfig.URL_RELEASE_NEW;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_NEW,tempStr);

            tempStr = UrlConfig.URL_RELEASE_NEW_TWO;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_NEW_TWO,tempStr);

            tempStr = UrlConfig.URL_RELEASE_NEW_THREE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_NEW_THREE,tempStr);

            tempStr = UrlConfig.URL_RELEASE_NEW_TIMER;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_NEW_TIMER,tempStr);

            tempStr = UrlConfig.URL_RELEASE_NEW_TWO_TIMER;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_NEW_TWO_TIMER,tempStr);

            tempStr = UrlConfig.URL_RELEASE_NEW_THREE_TIMER;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_NEW_THREE_TIMER,tempStr);

            tempStr = UrlConfig.BASE_FEATURE_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_FEATURE_RELEASE,tempStr);

            tempStr = UrlConfig.BASE_FEATURE_RELEASE_TWO;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_FEATURE_RELEASE_TWO,tempStr);

            tempStr = UrlConfig.BASE_FEATURE_RELEASE_THREE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_FEATURE_RELEASE_THREE,tempStr);

            tempStr = UrlConfig.BASE_RECOMMEND_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RECOMMEND_RELEASE,tempStr);

            tempStr = UrlConfig.BASE_RECOMMEND_RELEASE_TWO;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RECOMMEND_RELEASE_TWO,tempStr);

            tempStr = UrlConfig.BASE_RECOMMEND_RELEASE_THREE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RECOMMEND_RELEASE_THREE,tempStr);

            tempStr = UrlConfig.BASE_DETAIL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_DETAIL_RELEASE,tempStr);

            tempStr = UrlConfig.BASE_DETAIL_RELEASE_TWO;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_DETAIL_RELEASE_TWO,tempStr);

            tempStr = UrlConfig.BASE_DETAIL_RELEASE_THREE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_DETAIL_RELEASE_THREE,tempStr);

            tempStr = UrlConfig.SEARCH_BASE_URL_RELEASE_NEW;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.SEARCH_BASE_URL_RELEASE_NEW,tempStr);

            tempStr = UrlConfig.SEARCH_BASE_TWO_RELEASE_NEW;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.SEARCH_BASE_TWO_RELEASE_NEW,tempStr);

            tempStr = UrlConfig.SEARCH_BASE_THREE_RELEASE_NEW;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.SEARCH_BASE_THREE_RELEASE_NEW,tempStr);

            tempStr = UrlConfig.BASE_MORE_FEATURE_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_MORE_FEATURE_RELEASE,tempStr);

            tempStr = UrlConfig.BASE_MORE_FEATURE_RELEASE_TWO;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_MORE_FEATURE_RELEASE_TWO,tempStr);

            tempStr = UrlConfig.BASE_MORE_FEATURE_RELEASE_THREE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_MORE_FEATURE_RELEASE_THREE,tempStr);

            tempStr = UrlConfig.URL_RELEASE_FEATURE_TIMER;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_FEATURE_TIMER,tempStr);

            tempStr = UrlConfig.URL_RELEASE_FEATURE_TWO_TIMER;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_FEATURE_TWO_TIMER,tempStr);

            tempStr = UrlConfig.URL_RELEASE_FEATURE_THREE_TIMER;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.URL_RELEASE_FEATURE_THREE_TIMER,tempStr);

            tempStr = UrlConfig.BASE_RELEASE_DOWNLOAD_URL;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RELEASE_DOWNLOAD_URL,tempStr);

            tempStr = UrlConfig.BASE_RELEASE_DOWNLOAD_TWO_URL;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RELEASE_DOWNLOAD_TWO_URL,tempStr);

            tempStr = UrlConfig.BASE_RELEASE_DOWNLOAD_THREE_URL;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RELEASE_DOWNLOAD_THREE_URL,tempStr);

            tempStr = UrlConfig.CHECK_VERSION_URL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.CHECK_VERSION_URL_RELEASE,tempStr);

            tempStr = UrlConfig.CHECK_VERSION_URL_RELEASE_1;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.CHECK_VERSION_URL_RELEASE_1,tempStr);

            tempStr = UrlConfig.CHECK_VERSION_URL_RELEASE_2;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.CHECK_VERSION_URL_RELEASE_2,tempStr);

            mDomainNameHashMap.put("https://feature-api-dcdn-aws.palmplaystore.com", "feature-api-dcdn-aws.palmplaystore.com");//支持gslb，尽量不要定义常量，这两个域名，根据配置下发来使用
            mDomainNameHashMap.put("https://feature-api-dcdn-gcp.palmplaystore.com", "feature-api-dcdn-gcp.palmplaystore.com");

            tempStr = UrlConfig.BASE_TAIL_STOP_URL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_TAIL_STOP_URL_RELEASE,tempStr);

            tempStr = UrlConfig.GIFTRAIN_BASE_URL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.GIFTRAIN_BASE_URL_RELEASE,tempStr);

            tempStr = UrlConfig.BASE_URL_NEW_CONFIG_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_URL_NEW_CONFIG_RELEASE,tempStr);

            tempStr = AsyncHttp.ATTRIBUTE_HOST_NAME;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(AsyncHttp.ATTRIBUTE_HOST_NAME,tempStr);

            tempStr = UrlConfig.BASE_RESTART_URL_RELEASE;
            tempStr = tempStr.replaceFirst(mPreStr,"");
            mDomainNameHashMap.put(UrlConfig.BASE_RESTART_URL_RELEASE,tempStr);

        }
        mDomainArray = new String[mDomainNameHashMap.size()];
        int i = 0;
        for (String key : mDomainNameHashMap.keySet()) {
            mDomainArray[i] = key;
            i++;
        }
    }

    public String[] getDomainNameList() {
        return mDomainArray;
    }

    /**
     * 更新域名信息
     * @param domainMap
     */
    public void updateDomainName(Map<String, String> domainMap) {
     //{dsc.shalltry.com=ire-dsc.shalltry.com, android.palmplaystore.com=android.palmplaystore.com, android.palmst0re.com=android.palmst0re.com, api.twibida.com=irl-api.twibida.com, dsc-test.shalltry.com=dsc-test.shalltry.com, dsu.shalltry.com=ire-dsu.shalltry.com, android.pa1mstore.com=android.pa1mstore.com, dsu-test.shalltry.com=dsu-test.shalltry.com}
    //todo 与glsb sdk开发沟通如无必要则无需处理返回结果
    /*   if(domainMap == null || domainMap.size() == 0) {
           return;
       }
       for(String key:domainMap.keySet()) {
           for(String value: mDomainNameHashMap.values()) {
               if(TextUtils.equals(key,value)) {
                   mDomainNameHashMap.put(mPreStr+key,domainMap.get(key));
                   break;
               }
           }
       }
      */
    }

    /**
     * 转换当前访问的URL链接
     * @param url
     * @return
     */
    public String getCurDomainName(String url) {
        boolean isInit = GslbSdk.isInitSuccess(url);
        if(isInit) {
            return GslbSdk.getDomain(url,true);
        }
        return url;
    }
}

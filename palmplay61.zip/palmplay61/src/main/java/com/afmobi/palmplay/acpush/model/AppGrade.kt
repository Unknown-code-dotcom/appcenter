package com.afmobi.palmplay.acpush.model

/**
 * AC-PUSH 应用分级常量。
 *
 * 用于 PM 通过 deliver_push 下发的 [PushRecordItem.appGrade] 字段。
 *
 * 这是 PM↔AC 协议字面值，**不要轻易改**。
 */
object AppGrade {
    /** S 级（最高优先级，悬浮通知，单应用样式） */
    const val S = "S"

    /** A 级（中优先级，悬浮通知，多应用打包样式） */
    const val A = "A"

    /** 其他（折叠通知，多应用打包样式） */
    const val OTHER = "OTHER"

    /** @return true 表示需要走 HIGH 通道（悬浮通知） */
    @JvmStatic
    fun isHighChannel(grade: String?): Boolean = grade == S || grade == A
}

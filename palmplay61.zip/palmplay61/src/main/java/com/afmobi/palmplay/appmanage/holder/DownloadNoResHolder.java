package com.afmobi.palmplay.appmanage.holder;

import android.content.res.Resources;
import android.text.TextUtils;
import android.view.View;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.adapter.DownloadNoResAdapter;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.TRNoDoubleClickListener;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutManageDownloadingListItemNoResBinding;

public class DownloadNoResHolder extends RecyclerView.ViewHolder {
    private LayoutManageDownloadingListItemNoResBinding binding;

    private DownloadNoResAdapter.OnItemDeleteListener onItemDeleteListener;

    Resources resources;

    public DownloadNoResHolder(View itemView, DownloadNoResAdapter.OnItemDeleteListener listener) {
        super(itemView);
        onItemDeleteListener = listener;
        binding = DataBindingUtil.getBinding(itemView);
        if (binding != null) {
            resources = binding.getRoot().getResources();
            binding.ivDeleteNoResoures.setOnClickListener(new TRNoDoubleClickListener() {
                @Override
                public void onNoDoubleClick(View v) {
                    int pos = (int) v.getTag();
                    if (onItemDeleteListener != null){
                        onItemDeleteListener.onItemDelete(pos);
                    }
                }
            });
        }
    }

    public void bind(FileDownloadInfo downloadingInfo, final int position) {
        if (binding == null || downloadingInfo == null) {
            return;
        }

        binding.ivDeleteNoResoures.setTag(position);
        binding.tvName.setText(downloadingInfo.name);

        int defaultIcon = R.drawable.layer_list_app_default_01_bg;
        if (!TextUtils.isEmpty(downloadingInfo.iconUrl)) {
            GlideUtils.setImageUrl(binding.ivIcon, downloadingInfo.iconUrl, defaultIcon, defaultIcon);
        } else {
            binding.ivIcon.setImageDrawable(PalmplayApplication.getAppInstance().getDrawable(defaultIcon));
        }

        binding.ivLayer.setVisibility(View.VISIBLE);
        binding.ivDeleteNoResoures.setVisibility(View.VISIBLE);
        String err = "";
        if (downloadingInfo.extraInfo != null) {
            err = downloadingInfo.extraInfo.noResReason;
        }
        if (downloadingInfo.extraInfo != null && downloadingInfo.extraInfo.isRetryInstallFail) {
            err = CommonUtils.getInstallFailMsg(downloadingInfo.extraInfo.installErrorCode);
        }
        if (TextUtils.isEmpty(err)) {
            err = PalmplayApplication.getAppInstance().getString(R.string.no_resource);
        }
        binding.tvName.setTextColor(resources.getColor(R.color.pluto_item_desc_color));
        binding.tvReason.setTextColor(resources.getColor(R.color.pluto_item_desc_color));
        binding.tvReason.setText(err);
    }
}


package com.afmobi.palmplay.cloudfolder

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.utils.ADD_WIDGET_SUCCESS_ACTION
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.FOLDER_STATUS
import com.afmobi.palmplay.cloudfolder.utils.KEY_CLOUD_FOLDER_USE_LAUNCHER_BG
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.services.DispenseDataManager


class  AppFolderProvider : BaseWidgetProvider(FOLDER.APPS)

class GameFolderProvider : BaseWidgetProvider(FOLDER.GAMES)

open class BaseWidgetProvider(private val currentFolder: FOLDER) : AppWidgetProvider() {

    private val TAG = "BaseWidgetProvider"

    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        intent?.apply {
            LogUtils.d(TAG, "Folder :  ${currentFolder.title}    onReceive ->>>    $action")
            if(TextUtils.equals(action, ADD_WIDGET_SUCCESS_ACTION)) {
                //添加控件成功
                if(currentFolder == FOLDER.APPS) {
                    CloudFolderManager.getInstance().createWidgetCloudFolder(FOLDER.GAMES)
                }
            } else if(TextUtils.equals(action, Intent.ACTION_LOCALE_CHANGED)) {
                CloudFolderManager.getInstance().updateWidgetRemoteView(context, currentFolder)
            }
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {

        // 在小组件需要更新内容时调用，你可以在这里更新小组件的视图
        for (appWidgetId in appWidgetIds) {
            LogUtils.d(TAG, "Folder :  ${currentFolder.title}    onUpdate")
            CloudFolderManager.getInstance().updateWidgetRemoteView(context, currentFolder, appWidgetManager, appWidgetId)
        }
    }

    override fun onEnabled(context: Context?) {
        super.onEnabled(context)
        LogUtils.i(TAG, "Folder :  ${currentFolder.title}    onEnabled")
        CloudFolderPreviewManager.getInstance().resetPreviewImage(currentFolder)
        CloudFolderManager.getInstance().updateWidgetRemoteView(context, currentFolder)
        DispenseDataManager.getInstance().fileFolderRequestType = Constants.STATUS_FILE_FOLDER_REQUEST_TYPE_PROJECT
        DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
            FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT

        context?.let {
            val manager = CloudFolderManager.getInstance()
            // Android 17+ 默认使用桌面背景；低版本仍看 Launcher 能力开关
            if (manager.isAndroid17OrAbove() || manager.isLauncherSupportBackground) {
                manager.saveWidgetState(it, currentFolder.widgetClass, true)
                MMKVUtils.getMultiMMKV().putBoolean(KEY_CLOUD_FOLDER_USE_LAUNCHER_BG, true)
                manager.isLauncherShowBg = true
            }
        }

        CloudFolderTrackUtil.tecTrack(
            CloudFolderTrackUtil.TYPE_FOLDER_CREATE,
            currentFolder.categoryType,
            "",
            CloudFolderTrackUtil.TYPE_CREATE
        )

    }

    override fun onDisabled(context: Context?) {
        super.onDisabled(context)
        LogUtils.d(TAG, "Folder :  ${currentFolder.title}    onDisabled")

        val originSplit = CloudFolderManager.getInstance().isOriginSplit()
        if(originSplit) {
            CloudFolderManager.getInstance().checkFolderStatus(currentFolder)
        } else {
            if (CloudFolderRemoteController.getInstance().isCloudFolderShow(currentFolder)) {
                CloudFolderManager.getInstance().removeAllCloudFolder()
                DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
                    FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT
            }
        }

        if(currentFolder == FOLDER.APPS) {
            CloudFolderManager.getInstance().moveAllItemToHomeScreen()
            CloudFolderTrackUtil.tecTrack(
                CloudFolderTrackUtil.TYPE_DISBAND,
                CloudFolderTrackUtil.STATUS_DEFAULT,
                "",
                ""
            )
        } else if(originSplit) {
            CloudFolderTrackUtil.tecTrack(
                CloudFolderTrackUtil.TYPE_DISBAND,
                CloudFolderTrackUtil.STATUS_DEFAULT,
                "2",
                ""
            )
        }
    }

    override fun onDeleted(context: Context?, appWidgetIds: IntArray?) {
        super.onDeleted(context, appWidgetIds)
        LogUtils.d(TAG, "Folder :  ${currentFolder.title}    onDeleted")
    }

    override fun onAppWidgetOptionsChanged(
        context: Context?,
        appWidgetManager: AppWidgetManager?,
        appWidgetId: Int,
        newOptions: Bundle?
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        LogUtils.d(TAG, "Folder :  ${currentFolder.title}    onAppWidgetOptionsChanged")

    }

}
package com.afmobi.palmplay.cloudfolder.adapter

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import kotlin.math.roundToInt


/**
 * 云文件夹宫格的间距装饰：将固定宽度 itemSize=76dp 的条目按视觉等间距摆放到 GridLayoutManager 的等宽 cell 内。
 *
 * 背景：GridLayoutManager 会把可用宽度等分成 N 个 cell（N=3 或 4），把每个 item 居左放进 cell。
 * 由于 item 的实际宽度（76dp）小于 cell 宽度，直接展示会出现左对齐、行尾留白。
 * 本装饰通过给每个 cell 设置 outRect.left/right，把 item 在 cell 内推到「期望位置」，
 * 让 4 个或 3 个条目在整行内视觉上完全均匀。
 *
 * 计算思路（以 4 列为例）：
 *   actualWidth 分成 5 段空白 + 4 个 item：[margin][item][gap][item][gap][item][gap][item][margin]
 *   - remaining = actualWidth - 4 * itemSize  → 5 段空白的总和
 *   - unit = remaining / 5                    → 每段空白宽度（margin == gap == unit）
 *   - idealLeft  = item 在 actualWidth 坐标系下的目标左边距
 *   - cellLeft   = GridLayoutManager 给这一列分配的 cell 左边距
 *   - outRect.left = idealLeft - cellLeft     → 把 item 从 cell 左边推到目标位置
 *   - outRect.right = cellRight - idealRight  → 占住剩余空间，避免 item 被拉伸
 *
 * 3 列模式同理，区别仅在于 margin 与 gap 不同（margin = padding - space，gap 重新计算）。
 */
class ShortcutsSpaceItemDecoration(private val mBottomSpacePx: Int, private val mHorizontalSpacePx: Int) :
    RecyclerView.ItemDecoration() {

        // 默认的可用宽度 = 全屏幕宽度 - RecyclerView 的左右外边距ShortcutsSpaceItemDecoration
    private var availableWidthPx = DeviceProfile.getInstance().getAvailableWidthPx() - 2 * DeviceProfile.getInstance().cloudFolderRvMargin
    //item wrap_content时, 默认条目会向左边对齐(第一个贴着左侧屏幕)， 条目的间距计算规则如下
    val padding : Float = (availableWidthPx - dip2px(76f) * 3).toFloat() / 3
    //两侧两个条目距离中间的间距
    var space = dip2px(0f)


    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        val params = view.layoutParams as? GridLayoutManager.LayoutParams ?: return
        val spanSize = params.spanSize

        // 优先使用 RecyclerView 当前实测宽度，但在首次布局/转屏/未稳定测量时，parent.width 会经历
        // 从 MATCH_PARENT 换算出的临时宽度（如 650px）到 customDensity 稳定宽度（如 640px）的中间态，
        // 从而引发水平抖动。因此当 parent.width 与根据列数 margin 算得的稳定期望宽度差异较大时，
        // 优先回退到稳定期望值，避免抖动。
        val deviceProfile = DeviceProfile.getInstance()
        val marginDp = if (spanSize == 3) 10f else 20f
        val stableWidth = deviceProfile.getAvailableWidthPx() - 2 * dip2px(marginDp)
        val parentWidth = parent.width - parent.paddingLeft - parent.paddingRight
        val isPadThreeColumn = deviceProfile.isPadLayout && spanSize == 4 && parentWidth > 0
        // Pad 三列（样式 1/2/4）与四列（样式 3）均与搜索框+icon 同宽居中。
        val isPadFourColumnRankList = deviceProfile.isPadLayout && spanSize == 3 && parentWidth > 0
        val isPadConstrainedGrid = isPadThreeColumn || isPadFourColumnRankList
        val actualWidth = if (isPadConstrainedGrid) {
            minOf(
                parentWidth,
                deviceProfile.getPadSearchAlignedContentWidth(parent.resources)
            )
        } else if (parentWidth > 0 && Math.abs(parent.width - stableWidth) < dip2px(2f)) {
            parentWidth
        } else {
            stableWidth
        }

        // SECTION header 占整行（spanSize=12），自身已通过 LinearLayout 处理水平居中和 8dp gap，
        // ItemDecoration 不再附加横向 outRect
        if (spanSize == 12) {
            outRect.bottom = itemBottomSpace(parent)
            return
        }

        if (spanSize == 4) { // 3 items per row (spanSize 4 out of 12)
            // ---------- 3 列模式 ----------
            // column         : item 所在列号（0/1/2）
            // itemSize       : item 固定宽度 76dp
            // currentPadding : 等分 3 段空白后每段的宽度（按 item 居左、行尾留白的等分布局）
            // margin         : 左右外边距 = currentPadding - space（向中间偏移 10dp，让两侧贴边更紧凑）
            // gap            : 调整 margin 后，剩余空间在两个 item 间隙中均分
            // cellWidth      : GridLayoutManager 实际分给每个 item 的 cell 宽（actualWidth / 3）
            val column = params.spanIndex / 4
            val itemSize = dip2px(76f).toFloat()
            val remaining = (actualWidth - itemSize * 3).coerceAtLeast(0f)
            // Pad 三列（样式 1/2/4）：左右贴齐搜索框+icon，剩余空间全部分到条目间距。
            // 手机仍用原公式，两侧略收、中间稍松。
            val margin: Float
            val gap: Float
            if (isPadThreeColumn) {
                margin = 0f
                gap = remaining / 2f
            } else {
                space = dip2px(2f)
                val currentPadding = remaining / 3f
                margin = currentPadding - space
                gap = (remaining - margin * 2) / 2f
            }
            val contentStart = if (isPadThreeColumn) {
                (parentWidth - actualWidth) / 2f
            } else {
                0f
            }
            val cellWidth = if (isPadThreeColumn) {
                parentWidth / 3f
            } else {
                actualWidth / 3f
            }

            // 期望位置：item 在 actualWidth 坐标系下应处于 [idealLeft, idealRight]
            val idealLeft = contentStart + margin + column * (itemSize + gap)
            val idealRight = idealLeft + itemSize
            // 实际位置：GridLayoutManager 把 item 放进 [cellLeft, cellRight]
            val cellLeft = column * cellWidth
            val cellRight = (column + 1) * cellWidth

            // outRect 充当「期望位置 - 实际位置」的偏移补偿，把 item 在 cell 内推到目标位置
            outRect.left = (idealLeft - cellLeft).roundToInt()
            outRect.right = (cellRight - idealRight).roundToInt()
        } else if (spanSize == 3) { // 4 items per row (spanSize 3 out of 12)
            // ---------- 4 列模式 ----------
            // remaining : 4 个 item 占完后剩下的总空白
            val column = params.spanIndex / 3
            val itemSize = dip2px(64f).toFloat()
            val remaining = (actualWidth - itemSize * 4).coerceAtLeast(0f)
            val margin: Float
            val gap: Float
            if (isPadFourColumnRankList) {
                // Pad 样式 3：左右贴齐榜单，剩余空间均分到 3 个条目间距。
                margin = 0f
                gap = remaining / 3f
            } else {
                // 手机：两侧略收、中间更紧凑，gap 上限 14dp。
                val unit = remaining / 5f
                val shift = dip2px(12f).toFloat()
                var computedMargin = unit + shift
                var computedGap = ((remaining - computedMargin * 2) / 3f).coerceAtLeast(0f)
                val targetGap = dip2px(14f).toFloat()
                if (computedGap > targetGap) {
                    computedGap = targetGap
                    computedMargin = ((remaining - computedGap * 3f) / 2f).coerceAtLeast(0f)
                }
                margin = computedMargin
                gap = computedGap
            }
            val contentStart = if (isPadFourColumnRankList) {
                (parentWidth - actualWidth) / 2f
            } else {
                0f
            }
            val cellWidth = if (isPadFourColumnRankList) {
                parentWidth / 4f
            } else {
                actualWidth / 4f
            }

            // 期望位置 & 实际位置同 3 列模式：item 在 actualWidth 中应处于 [idealLeft, idealRight]，
            // 但 GridLayoutManager 把它放进 [cellLeft, cellRight]，靠 outRect 偏移补齐差值。
            val idealLeft = contentStart + margin + column * (itemSize + gap)
            val idealRight = idealLeft + itemSize
            val cellLeft = column * cellWidth
            val cellRight = (column + 1) * cellWidth

            outRect.left = (idealLeft - cellLeft).roundToInt()
            outRect.right = (cellRight - idealRight).roundToInt()
        }

        outRect.bottom = itemBottomSpace(parent)
    }

    /** Pad 中部行距使用 DeviceProfile.padSpaceExtra。 */
    private fun itemBottomSpace(parent: RecyclerView): Int {
        return mBottomSpacePx + DeviceProfile.getInstance().padSpaceExtra(parent.resources)
    }
}

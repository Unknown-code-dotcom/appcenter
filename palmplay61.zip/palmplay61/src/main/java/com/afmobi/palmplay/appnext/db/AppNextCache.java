package com.afmobi.palmplay.appnext.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 15:05
 * @Desc: add your description
 */
@Entity(tableName = "AppNextCache")
public class AppNextCache {

    @NonNull
    @PrimaryKey
    public String packageNameWithAction;
    public String reportUrl;
    public int status = 0; // 0失败 1 成功
    public int retryCount = 0; //最大3次
    public long createTime = System.currentTimeMillis();


    @NonNull
    public String getPackageNameWithAction() {
        return packageNameWithAction;
    }

    public void setPackageNameWithAction(@NonNull String packageNameWithAction) {
        this.packageNameWithAction = packageNameWithAction;
    }

    public String getReportUrl() {
        return reportUrl;
    }

    public void setReportUrl(String reportUrl) {
        this.reportUrl = reportUrl;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }
}

package com.afmobi.palmplay.category;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.cache.CategoryCache;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.model.CategoryInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.viewmodel.category.CategoryViewModel;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.google.android.material.tabs.TabLayout;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.widgetslib.widget.OSIconTextView;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ActivityCategoryBinding;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import xyz.doikki.videoplayer.util.PlayerUtils;

/**
 * @author: zhiqiang.hao
 * @date: 2021/3/10 13:56
 * @Desc: 分类页
 */
public class CategoryActivity extends BaseEventFragmentActivity implements View.OnClickListener {

    public static final String KEY_CATEGORY_TYPE = "categoryType";
    public static final String KEY_CATEGORY_ID = "categoryId";
    public static final String KEY_CATEGORY_NAME = "categoryName";
    public static final String KEY_CATEGORY_TAG = "categoryTag";

    private UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();

    private String mCategoryType;
    private String mCategoryId;
    private String mCategoryName;

    private String mFrom;
    private String mValue;

    private ActivityCategoryBinding mDataBinding;

    private CategoryPageAdapter mCategoryPageAdapter;
    private CategoryViewModel mCategoryViewModel;
    private PageParamInfo mPageParamInfo = new PageParamInfo();

    private ArrayList<CategoryInfo> mCategoryList = new ArrayList<>();

    private Typeface mTypefaceMedium;
    private Typeface mTypefaceNormal;
    private int mPosition = 0;
    private TextView tvVaDownloadingCount;

    @Override
    protected void onCreate(Bundle onSaveInstanceState) {
        super.onCreate(onSaveInstanceState);
        TRStatusBarUtil.setStatusBarTextColor(getWindow(), true);
        mDataBinding = DataBindingUtil.setContentView(this, R.layout.activity_category);
        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }
        initParams(intent);
        initView();
        init();
        setEmptyViewCenter();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.remove("android:support:fragments");
    }

    /**
     * 空态页居中显示
     */
    private void setEmptyViewCenter() {
        int height = DisplayUtil.getScreenHeight(this);
        int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.empty_view_height);
        int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
        int tabLayoutHeight = getResources().getDimensionPixelSize(R.dimen.dp_42);
        int halfMarginTop = (height - emptyLayoutHeight) / 2;
        int statusBarHeight = (int) PlayerUtils.getStatusBarHeight(this);
        int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight - tabLayoutHeight;
        if (finalMarginTop <= 0) {
            finalMarginTop = 0;
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mDataBinding.layoutEmptyView.layoutEmptyViewRoot.getLayoutParams();
        params.topMargin = finalMarginTop;
        mDataBinding.layoutEmptyView.layoutEmptyViewRoot.setLayoutParams(params);
    }

    private void initParams(Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle == null || !bundle.containsKey(CategoryActivity.KEY_CATEGORY_TYPE)) {
            finish();
            return;
        }
        mCategoryType = bundle.getString(CategoryActivity.KEY_CATEGORY_TYPE);
        mCategoryId = bundle.getString(CategoryActivity.KEY_CATEGORY_ID);
        mCategoryName = bundle.getString(CategoryActivity.KEY_CATEGORY_NAME);

        mFrom = bundle.getString(TRAnalyticsConstant.VALUE);
        mPageParamInfo.setLastPage(bundle.getString(PageConstants.PAGE_KEY_LASTPAGE));
        mPageParamInfo.setCurPage(PageConstants.CATEGORY);
    }

    private void initView() {

        mUILoadingGifUtil.inflate(this, mDataBinding.rlContainer);
        mUILoadingGifUtil.setVisibility(View.VISIBLE);

        mDataBinding.layoutTitle.layoutTitleBack.setOnClickListener(this);
        mDataBinding.layoutTitle.layoutTitleContent.setText(mCategoryName);
        mDataBinding.layoutTitle.layoutTitleRightSearch.setVisibility(View.VISIBLE);
        mDataBinding.layoutTitle.layoutTitleRightSearch.setOnClickListener(this);
        mDataBinding.layoutTitle.layoutTitleRight.setVisibility(View.VISIBLE);
        mDataBinding.layoutTitle.ivDownload.setOnClickListener(this);
        mDataBinding.layoutTitle.layoutVaTitleRight.setOnClickListener(this);
        mDataBinding.layoutTitle.layoutVaTitleRight.setVisibility(View.VISIBLE);

        mTypefaceMedium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        mTypefaceNormal = Typeface.create("sans-serif", Typeface.NORMAL);

        setupPager();
        tvVaDownloadingCount = findViewById(R.id.tv_va_downloading_count);

    }


    private void init() {
        mValue = generateValue();

        mCategoryViewModel = new ViewModelProvider(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(CategoryViewModel.class);

        mCategoryViewModel.getCategoryList(mCategoryType, mPageParamInfo);

        mCategoryViewModel.getCateGoryListLiveData().observe(this, new Observer<List<CategoryInfo>>() {
            @Override
            public void onChanged(List<CategoryInfo> categoryInfo) {

                if (categoryInfo != null && categoryInfo.size() > 0) {
                    mCategoryList.clear();
                    mCategoryList.addAll(categoryInfo);
                    mCategoryPageAdapter.setCategoryList(mCategoryList);
                    final int position = getCurrentTabPosition();
                    mPosition = position;
                    initTabCustomView();
                    mDataBinding.tabLayout.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mDataBinding.tabLayout.setScrollPosition(position, 0, true);
                        }
                    }, 10);
                    mDataBinding.viewPager.setCurrentItem(position, false);

                }
                mUILoadingGifUtil.setVisibility(View.GONE);
            }
        });
    }


    private String generateValue() {
        String categoryPage = "";
        if (Constant.SOFTTYPE_APP.equals(mCategoryType)) {
            categoryPage = TRAnalyticsConstant.APP_CATEGORY;
        } else {
            categoryPage = TRAnalyticsConstant.GAME_CATEGORY;
        }
        return TRStringUtil.generateString(categoryPage, "", "", "");
    }

    public String getFrom() {
        return mFrom;
    }

    public PageParamInfo getPageParamInfo() {
        return mPageParamInfo;
    }

    public String getLastPage() {
        return mPageParamInfo.getLastPage();
    }

    private int getCurrentTabPosition() {
        int position = 0;

        CategoryInfo info;
        for (int i = 0; i < mCategoryList.size(); i++) {
            info = mCategoryList.get(i);
            if (info != null && info.categoryID.equals(mCategoryId)) {
                position = i;
                break;
            }
        }
        return Math.max(position, 0);
    }

    private void initTabCustomView() {
        for (int i = 0; i < mDataBinding.tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = mDataBinding.tabLayout.getTabAt(i);
            if (tab != null) {
                tab.setCustomView(getTabView(i));
            }
        }
    }


    private void setupPager() {

        mCategoryPageAdapter = new CategoryPageAdapter(this, mCategoryType, mCategoryList, mCategoryId, mFrom);
        mDataBinding.viewPager.setAdapter(mCategoryPageAdapter);
        mDataBinding.viewPager.setSaveEnabled(false);
        mDataBinding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View view = tab.getCustomView();
                if (view != null) {
                    ((TextView) view.getTag()).setTypeface(mTypefaceMedium, Typeface.NORMAL);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View view = tab.getCustomView();
                if (view != null) {
                    ((TextView) view.getTag()).setTypeface(mTypefaceNormal, Typeface.NORMAL);
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        mDataBinding.tabLayout.setupWithViewPager(mDataBinding.viewPager);
        mDataBinding.viewPager.setOffscreenPageLimit(2);

        mDataBinding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mPosition = position;
                final String pageTitle = mCategoryPageAdapter.getPageTitle(position);
                mDataBinding.layoutTitle.layoutTitleContent.setText(pageTitle);
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(mValue)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId(mCategoryPageAdapter.getCategoryId(position))
                        .setItemType("")
                        .setItemId("")
                        .setButtonType(TRAnalyticsConstant.BUTTON)
                        .setItemValue(pageTitle)
                        .setExtraValue("");
                TRAnalysticsUtil.trackClick(builder);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private View getTabView(final int position) {
        View v = LayoutInflater.from(this).inflate(R.layout.layout_custom_tab_new, null);
        TextView tv = v.findViewById(R.id.tab_name);
        final String pageTitle = mCategoryPageAdapter.getPageTitle(position);
        tv.setText(pageTitle);

        if (0 == position) {
            tv.setPadding(DisplayUtil.dip2px(this, 4), 0, 0, 0);
            tv.setTypeface(mTypefaceMedium, Typeface.NORMAL);
        }
        v.setTag(tv);
        return v;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        //刷新UI
        initParams(intent);

        if (mCategoryViewModel == null) {
            mCategoryViewModel = new ViewModelProvider(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(CategoryViewModel.class);
        }
        mCategoryViewModel.getCategoryList(mCategoryType, mPageParamInfo);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpdatedAppCount();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CategoryTabFragment.sIsFirstTime = true;
        CategoryCache.getInstance().clearCategoryDataCache();
        if (mUILoadingGifUtil != null) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }
    }

    private void setUpdatedAppCount() {
        TRHomeUtil.refreshAppCount(mDataBinding.layoutTitle.tvDownloadingCount, mDataBinding.layoutTitle.downloadingAnimView);
        TRHomeUtil.refreshVaAppCount(tvVaDownloadingCount);
    }

    public void refreshDownLoadCount() {
        setUpdatedAppCount();
    }

    public OSIconTextView getIvDownLoad() {
        return mDataBinding.layoutTitle.ivDownload;
    }

    public int[] getIvDownLoadPosition() {
        int[] endTranslateAnimationLocationOnScreen = new int[2];
        mDataBinding.layoutTitle.ivDownload.getLocationOnScreen(endTranslateAnimationLocationOnScreen);
        return endTranslateAnimationLocationOnScreen;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.layout_title_back:
                finish();
                backButtonTrack();
                break;
            case R.id.layout_title_right_search:
                TRJumpUtil.switchToSearchActivity(CategoryActivity.this, TabType.SOFT, "", false, "", false, "",
                        mPageParamInfo, mValue, TRAnalyticsConstant.BUTTON_SEARCH_IMG, mFrom);

                break;
            case R.id.iv_download:
                TRJumpUtil.into(this, false, mPageParamInfo, mValue);
                break;
            case R.id.layout_va_title_right:
                TRJumpUtil.intoMyGames(this, false, mPageParamInfo, mValue);
                break;
            default:
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        backButtonTrack();
    }

    private void backButtonTrack() {
        String categoryId = mCategoryPageAdapter.getCategoryId(mPosition);
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(mValue)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId(categoryId)
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public String getValue() {
        return mValue;
    }
    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        super.onEventMainThread(mEventMainThreadEntity);
        if (TextUtils.equals(mEventMainThreadEntity.getAction(), PsVaManager.ACTION_VA_GAME_INSTALL)) {
            String iconUrl = (String) mEventMainThreadEntity.get(PsVaManager.KEY_ICON_URL);
            if (!TextUtils.isEmpty(iconUrl) && mDataBinding.layoutTitle.layoutVaTitleRight != null) {
                mDataBinding.layoutTitle.layoutVaTitleRight.startAnim(iconUrl);
            }
        }
    }
}

package com.afmobi.palmplay.az.attribution;

import android.text.TextUtils;

import com.afmobi.palmplay.cloudfolder.AttributionUploadManager;
import com.android.hundsup.data.model.bean.az.AzAttrConfigBean;
import com.android.hundsup.utils.AppExecutors;
import com.transsion.palmstorecore.log.LogUtils;

import java.util.Collections;

/**
 * AZ 归因上报器（Launcher 侧点击通知后触发）
 *
 * 职责：
 *  1. 总开关判定（reportEnabled=0 直接不上报）
 *  2. 点击 CD 判定（同一包 CD 内不重复上报）
 *  3. 包维度上报次数上限过滤
 *  4. 替换归因链接 clickid 占位符
 *  5. 交给 AttributionUploadManager 入队（MMKV 持久化 + 联网重试由该类保证）
 *  6. 上报发出后 +1 计数
 */
public class AzAttrReporter {

    private static final String TAG = "AzAttrReporter";
    private static final String LOG_PREFIX = "[AZ_ATTR] ";

    private static volatile AzAttrReporter sInstance;

    public static AzAttrReporter getInstance() {
        if (sInstance == null) {
            synchronized (AzAttrReporter.class) {
                if (sInstance == null) {
                    sInstance = new AzAttrReporter();
                }
            }
        }
        return sInstance;
    }

    /** 公共线程池可复用，锁用于保证同一时刻只有一笔归因完成判定和记账。 */
    private final Object mReportLock = new Object();

    /**
     * 收到 Launcher 侧点击通知（fire-and-forget）
     */
    public void onClickReceived(final String pkg, final String clickId) {
        LogUtils.i(TAG, LOG_PREFIX + "收到AZ点击通知，pkg=" + pkg);
        if (TextUtils.isEmpty(pkg) || TextUtils.isEmpty(clickId)) {
            LogUtils.d(TAG, LOG_PREFIX + "点击通知跳过：pkg或点击ID为空，pkg=" + pkg);
            return;
        }
        AppExecutors.getInstance().work().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    LogUtils.i(TAG, LOG_PREFIX + "归因上报任务开始，pkg=" + pkg);
                    synchronized (mReportLock) {
                        doReport(pkg, clickId);
                    }
                } catch (Exception e) {
                    LogUtils.d(TAG, LOG_PREFIX + "归因上报任务异常: " + e.getMessage());
                }
            }
        });
    }

    private void doReport(String pkg, String clickId) {
        AzAttrRepository repo = AzAttrRepository.getInstance();
        LogUtils.i(TAG, LOG_PREFIX + "开始处理归因上报，pkg=" + pkg);

        // 1. 总开关
        if (!repo.isReportEnabled()) {
            LogUtils.d(TAG, LOG_PREFIX + "上报被过滤：总开关关闭，pkg=" + pkg);
            AzAttrTracker.trackReportFiltered(pkg, AzAttrTracker.REASON_DISABLED);
            return;
        }
        LogUtils.i(TAG, LOG_PREFIX + "总开关允许上报，pkg=" + pkg);

        // 2. CD 判定
        long now = System.currentTimeMillis();
        long last = repo.getLastClickTs(pkg);
        long cd = repo.getClickCdMs();
        LogUtils.i(TAG, LOG_PREFIX + "开始点击CD校验，pkg=" + pkg + ", now=" + now
                + ", last=" + last + ", gap=" + (now - last) + ", cd=" + cd);
        if (now - last < cd) {
            LogUtils.d(TAG, LOG_PREFIX + "上报被过滤：点击CD未通过，pkg=" + pkg
                    + ", gap=" + (now - last) + ", cd=" + cd);
            AzAttrTracker.trackReportFiltered(pkg, AzAttrTracker.REASON_CD);
            return;
        }
        // 3. 查归因项
        AzAttrConfigBean.AzAttrItemBean item = repo.queryByPackage(pkg);
        if (item == null) {
            LogUtils.d(TAG, LOG_PREFIX + "上报被过滤：未找到包对应归因项，pkg=" + pkg);
            AzAttrTracker.trackReportFiltered(pkg, AzAttrTracker.REASON_NO_ITEM);
            return;
        }
        boolean hasAttributeUrl = !TextUtils.isEmpty(item.attributeUrl);
        LogUtils.i(TAG, LOG_PREFIX + "匹配到归因项，pkg=" + pkg
                + ", rawUrlLength=" + (hasAttributeUrl ? item.attributeUrl.length() : 0)
                + ", endDay=" + item.endDay);

        // 4. 包上限过滤
        int limit = repo.getPkgReportLimit();
        int count = repo.getReportCount(pkg);
        LogUtils.i(TAG, LOG_PREFIX + "开始包维度上限校验，pkg=" + pkg + ", count=" + count + ", limit=" + limit);
        if (limit <= 0) {
            LogUtils.d(TAG, LOG_PREFIX + "上报跳过：包维度上限配置无效，pkg=" + pkg + ", limit=" + limit);
            return;
        }
        if (count >= limit) {
            LogUtils.d(TAG, LOG_PREFIX + "上报被过滤：包维度次数达到上限，pkg=" + pkg
                    + ", count=" + count + ", limit=" + limit);
            AzAttrTracker.trackReportFiltered(pkg, AzAttrTracker.REASON_PKG_LIMIT);
            return;
        }

        String reportClickId = "";
        if (hasAttributeUrl) {
            // 5. 替换 clickid 占位符
            boolean hasClickidPlaceholder = item.attributeUrl.contains(AzAttrConstants.PH_CLICKID);
            String finalUrl = item.attributeUrl.replace(AzAttrConstants.PH_CLICKID, clickId);
            LogUtils.i(TAG, LOG_PREFIX + "归因链接已准备，pkg=" + pkg
                    + ", clickid=" + clickId
                    + ", placeholderFound=" + hasClickidPlaceholder
                    + ", finalUrl=" + finalUrl);

            // 6. 入队上报（AttributionUploadManager 内部：MMKV 持久化 + 无网重试）
            AttributionUploadManager.Companion.getInstance()
                    .enqueueNewRequest(Collections.singletonList(finalUrl), AzAttrConstants.UPLOAD_NAME);
            reportClickId = clickId;
            LogUtils.i(TAG, LOG_PREFIX + "归因链接已交给上传队列，pkg=" + pkg + ", name=" + AzAttrConstants.UPLOAD_NAME);
        } else {
            LogUtils.i(TAG, LOG_PREFIX + "归因链接为空，跳过链接上报，继续执行点击计费，pkg=" + pkg);
        }

        // 7. 完成点击计费处理后写入 CD 和计数。
        repo.updateLastClickTs(pkg, now);
        repo.incReportCount(pkg);

        // 8. 埋点：发出上报
        AzAttrTracker.trackReportSent(pkg, reportClickId);

        LogUtils.i(TAG, LOG_PREFIX + "归因上报流程完成，pkg=" + pkg + ", count=" + (count + 1) + "/" + limit);
    }
}

package com.afmobi.palmplay.activate

import android.app.Activity
import android.app.Dialog
import android.content.DialogInterface
import android.view.View
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.pet.manager.XMPetManager
import com.afmobi.palmplay.pet.manager.XMPetSwitcher
import com.transsion.palmstorecore.api.pet.IPetHomeGuideDialogCallback

class TRIntantGameExecutor : TRBaseExecutor<Any?>() {

    private var mGuideDialog: Dialog? = null

    override fun isCanShow(fromType: String?): Boolean {
        if (!XMPetSwitcher.isMainEnable()) {
            return false
        }
        if (!XMPetManager.shouldShowHomeGuide()) {
            return false
        }
        return TRNewManager.instance.canShow()
    }

    override fun dismiss(): Boolean {
        if (mGuideDialog != null) {
            try {
                mGuideDialog?.dismiss()
            } catch (e: Exception) {
                return false
            }
        }
        return true
    }

    override fun show(fromType: String?, activity: Activity, clickListener: View.OnClickListener, dismissListener: DialogInterface.OnDismissListener): Boolean {
        if (activity.isDestroyed || activity.isFinishing) {
            return false
        }
        if (isCanShow(fromType)) {
            mGuideDialog?.dismiss()
            mGuideDialog = XMPetManager.createHomeGuide(activity, object : IPetHomeGuideDialogCallback {
                override fun onDialogShown() { TRNewManager.instance.markAsShown() }
                override fun onDialogClosed() { TRNewManager.closeListener.onDialogClosed() }
                override fun onDismiss(dialog: Dialog?) {
                    dismissListener.onDismiss(dialog)
                }
                override fun onClick(view: View) {
                    clickListener.onClick(view)
                }
            })
            mGuideDialog?.show()
        }
        return false
    }

    override fun isShowing(): Boolean {
        return mGuideDialog?.isShowing == true
    }
}

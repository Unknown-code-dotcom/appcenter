package com.afmobi.palmplay.alive;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Bundle;

import com.afmobi.apk.ApkInstallUtils;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.alive.sync.GenericAccountService;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.util.NetworkState;
import com.afmobi.util.NetworkUtils;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.util.Calendar;


public class SyncUtils {

    private static final String TAG = "Alive";

    //account (存在误差延迟)
    private static final long SYNC_FREQUENCY = 2 * 60 * 60;  // 2 hour (in seconds)

    private static final String CONTENT_AUTHORITY = "com.transsnet.store.provider";

    // Value below must match the account type specified in res/xml/syncadapter.xml
    private static final String ACCOUNT_TYPE = "com.transsnet.store.account";

    /**
     * 创建同步账号
     */
    public static void syncAccount(Context context) {
        try {
            // Create account, if it's missing. (Either first run, or user has deleted account.)
            Account account = GenericAccountService.GetAccount(ACCOUNT_TYPE);
            AccountManager accountManager =
                    (AccountManager) context.getSystemService(Context.ACCOUNT_SERVICE);
            if (accountManager != null && accountManager.addAccountExplicitly(account, null, null)) {
                // Inform the system that this account supports sync
                ContentResolver.setIsSyncable(account, CONTENT_AUTHORITY, 1);
                // Inform the system that this account is eligible for auto sync when the network is up
                ContentResolver.setSyncAutomatically(account, CONTENT_AUTHORITY, true);
                // Recommend a schedule for automatic synchronization. The system may modify this based
                // on other scheduled syncs and network utilization.
                ContentResolver.addPeriodicSync(account, CONTENT_AUTHORITY, new Bundle(), SYNC_FREQUENCY);
            }
        } catch (Exception e) {
            LogUtils.e(TAG, e.toString());

        }
    }


    /**
     *
     */
    public static void doBusinessSync(/*Context context*/) {
        Calendar Cld = Calendar.getInstance();
        int HH = Cld.get(Calendar.HOUR_OF_DAY);

        if(ApkInstallUtils.isUsingSilentInstall() && NetworkState.WIFI.equals(NetworkUtils.getNetworkState(PalmplayApplication.getAppInstance()))){
            if(BuildConfig.DEBUG) {
                LogUtils.e(TAG,"ready download");
            }
            try {
                DownloadManager.getInstance().networkConnectedStartdownload();
            } catch (Exception e) {

            }

        }
    }


}

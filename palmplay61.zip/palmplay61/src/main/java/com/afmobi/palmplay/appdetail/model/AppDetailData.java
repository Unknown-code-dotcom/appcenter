package com.afmobi.palmplay.appdetail.model;

public class AppDetailData {
    private boolean isFeatureRequestFinished = false;

    private static volatile AppDetailData instance;

    private AppDetailData() {}

    public static AppDetailData getInstance() {
        if (instance == null) {
            synchronized (AppDetailData.class) {
                if (instance == null) {
                    instance = new AppDetailData();
                }
            }
        }
        return instance;
    }

    public boolean isFeatureRequestFinished() {
        return isFeatureRequestFinished;
    }

    public void setFeatureRequestFinished(boolean featureRequestFinished) {
        isFeatureRequestFinished = featureRequestFinished;
    }
}

package com.afmobi.palmplay.customview;

import static com.transsion.palmstorecore.analytics.TRAnalyticsConstant.MODULE_FEEDBACK;

import android.app.Activity;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;

import com.afmobi.palmplay.manager.AtyManager;
import com.transsion.core.utils.ScreenUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import java.lang.ref.WeakReference;

public class BackFloatBallView implements DefaultLifecycleObserver {

    private static final int SHOW_DELAY_MS = 100;

    private final Context mContext;
    private WindowManager mWindowManager;
    private View mView;
    private WeakReference<Activity> mActivityRef;
    private String from = "";
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    private float mDownX, mDownY, mStartX, mStartY;

    private LifecycleOwner mBoundLifecycleOwner;
    private boolean mDestroyed;

    public BackFloatBallView(Context context) {
        mContext = context;
    }

    public void show(Activity activity, String from) {
        if (activity == null || activity.isFinishing() || mDestroyed) return;
        this.mActivityRef = new WeakReference<>(activity);
        this.from = from;

        if (activity instanceof ComponentActivity componentActivity) {
            componentActivity.getLifecycle().removeObserver(this);
            componentActivity.getLifecycle().addObserver(this);
            mBoundLifecycleOwner = componentActivity;
        }

        if (mView == null) {
            createView();
        }
        if (mView == null) {
            return;
        }
        mHandler.postDelayed(() -> {
            if (mDestroyed) {
                return;
            }
            if (mView != null && !mView.isShown()) {
                mView.setVisibility(View.VISIBLE);
                trackExposure();
            }
        }, SHOW_DELAY_MS);
    }

    public void hide() {
        if (mView != null && mView.isShown()) {
            mView.setVisibility(View.GONE);
        }
    }

    public void destroy() {
        mDestroyed = true;
        mHandler.removeCallbacksAndMessages(null);
        if (mBoundLifecycleOwner != null) {
            mBoundLifecycleOwner.getLifecycle().removeObserver(this);
            mBoundLifecycleOwner = null;
        }
        hide();
        if (mWindowManager != null && mView != null) {
            if (mView.isAttachedToWindow()) {
                try {
                    mWindowManager.removeViewImmediate(mView);
                } catch (Throwable e) {
                    LogUtils.e("BackFloatBallView", "removeView error: " + e.getMessage());
                }
            }
        }
        mView = null;
        mWindowManager = null;
        mActivityRef = null;
    }

    public boolean isDestroyed() {
        return mDestroyed;
    }

    @Override
    public void onPause(@NonNull LifecycleOwner owner) {
        // 被来电/下拉通知栏等半透明遮挡时先隐藏，避免其它页面上残留
        if (mView != null && mView.isShown()) {
            mView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        destroy();
    }

    @Override
    public void onDestroy(LifecycleOwner owner) {
        destroy();
    }

    private void createView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(mContext)) {
            return;
        }
        mView = LayoutInflater.from(mContext).inflate(R.layout.ps_back_floatview, null);

        mWindowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        params.width = WindowManager.LayoutParams.WRAP_CONTENT;
        params.height = WindowManager.LayoutParams.WRAP_CONTENT;
        params.format = PixelFormat.TRANSLUCENT;
        params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            params.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }

        int layoutDirection = mContext.getResources().getConfiguration().getLayoutDirection();
        if (layoutDirection == View.LAYOUT_DIRECTION_RTL) {
            params.gravity = Gravity.TOP | Gravity.END;
        } else {
            params.gravity = Gravity.TOP | Gravity.START;
        }
        params.x = 0;
        params.y = ScreenUtil.dip2px(146);

        mView.setVisibility(View.GONE);
        mView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    mDownX = event.getRawX();
                    mDownY = event.getRawY();
                    mStartX = params.x;
                    mStartY = params.y;
                    break;
                case MotionEvent.ACTION_MOVE:
                    float moveY = event.getRawY() - mDownY;
                    params.y = (int) (mStartY + moveY);
                    if (params.y < 0) params.y = 0;
                    if (mWindowManager != null && mView != null) {
                        mWindowManager.updateViewLayout(mView, params);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(event.getRawX() - mDownX) < 5
                            && Math.abs(event.getRawY() - mDownY) < 5) {
                        performClick();
                    }
                    break;
            }
            return true;
        });

        try {
            // 安全添加 View，检查是否已经附加
            if (mView.getParent() != null) {
                mWindowManager.removeViewImmediate(mView);
            }
            mWindowManager.addView(mView, params);
        } catch (Exception ignored) {}
    }

    private void performClick() {
        Activity activity = mActivityRef != null ? mActivityRef.get() : null;
        trackClick();
        hide();
        if (activity != null && !activity.isFinishing()) {
            AtyManager.getAtyManager().moveTaskToBack();
        }
    }

    private void trackExposure() {
        try {
            String value = TRStringUtil.generateString(TRAnalyticsConstant.FLOATBALL_R_FB, MODULE_FEEDBACK, "", "");
            ComponentExposureBuilder builder = new ComponentExposureBuilder();
            builder.setValue(value);
            builder.setItemValue(TRAnalyticsConstant.BUTTON_BACK);
            builder.setFrom(from);
            TRAnalysticsUtil.trackExposure(builder);
        } catch (Exception e) {
            LogUtils.e("BackFloatBallView", "Exposure tracking failed: " + from, e);
        }
    }

    private void trackClick() {
        try {
            String value = TRStringUtil.generateString(TRAnalyticsConstant.FLOATBALL_R_FB, MODULE_FEEDBACK, "", "");
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value);
            builder.setButtonType(TRAnalyticsConstant.BUTTON_BACK);
            builder.setFrom(from);
            TRAnalysticsUtil.trackClick(builder);
        } catch (Exception e) {
            LogUtils.e("BackFloatBallView", "Exposure tracking failed: " + from, e);
        }
    }
}

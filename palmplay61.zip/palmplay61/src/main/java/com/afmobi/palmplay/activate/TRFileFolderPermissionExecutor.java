package com.afmobi.palmplay.activate;

import static com.afmobi.palmplay.main.NotificationToggleActivity.setToggleChangeTime;

import android.content.Intent;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.main.FileFolderPermissionActivity;
import com.afmobi.palmplay.main.NotificationToggleActivity;
import com.transsion.palmstorecore.log.LogUtils;

/***
 * created by yongli.li
 * 装机必备的执行者
 */
public class TRFileFolderPermissionExecutor extends TRBaseExecutor{
    public static volatile boolean STATUS = false;//代表本身是否正在显示

    @Override
    public boolean isCanShow(String fromType) {
        return TRDialogUtil.fileFolderPermissionCanShow();
    }

    @Override
    public boolean show(String fromType) {
        if (TRDialogUtil.hasDialogShowing()) {//真正show的时候判断是否已有弹框先于自己展现了。
            return false;
        }
        if (TRFileFolderPermissionExecutor.STATUS) {
            LogUtils.d("TRFileFolderDialog will not show,because disk space limit activity is showing");
            return false;
        }
        TRFileFolderPermissionExecutor.STATUS = true;
        try {
            Intent intent = new Intent(PalmplayApplication.getAppInstance(), FileFolderPermissionActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PalmplayApplication.getAppInstance().startActivity(intent);
//            setToggleChangeTime();
            LogUtils.d("start file folder toggle activity");
        } catch (Exception e) {
        }
        return true;
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }
}

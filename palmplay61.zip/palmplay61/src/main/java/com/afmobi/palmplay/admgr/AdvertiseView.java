package com.afmobi.palmplay.admgr;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.activate.TRManager;
import com.afmobi.palmplay.cache.AdCache;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.language.LanguageSelectActivity;
import com.afmobi.palmplay.model.LogoInfo;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.ActivityLifecycleUtil;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.statusbar.TRNavigationBarUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.LanguageSelectManager;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AdvertiseView extends FrameLayout {


    private FrameLayout ad_container;
    private RelativeLayout layout_bottom_logo;

    private AdsLoadProxy mAdsLoadProxy;

    private PageParamInfo mPageParamInfo;
    private int mDealType = AdsLoadProxy.TYPE_NORMAL;
    private String mScreenPageName;
    private boolean hasTrackClickEvent = false;
    private String mFromPage;
    private boolean isStartActivity = false;

    public AdvertiseView(@NonNull Context context) {
        this(context, null);
    }

    public AdvertiseView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AdvertiseView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setPageParam(String fromPage) {
        this.mFromPage = fromPage;
    }

    public void setStartActivity(boolean startActivity) {
        this.isStartActivity = startActivity;
    }

    private void initViews(boolean showSelfAd) {
        View contentView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_ad_native_layout, null);

        ad_container = contentView.findViewById(R.id.ad_container);//广告位
        layout_bottom_logo = contentView.findViewById(R.id.layout_bottom_logo);//品牌logo位

        LogoInfo logoInfo = CommonUtils.getLogoInfoByScreenScale();
        RelativeLayout.LayoutParams logoParams = (RelativeLayout.LayoutParams)layout_bottom_logo.getLayoutParams();
        logoParams.height = logoInfo.getHeight();
        layout_bottom_logo.setLayoutParams(logoParams);

/*        ImageView logo = contentView.findViewById(R.id.iv_logo_fragment_ad_native_layout);
        logo.setImageResource(logoInfo.getLogoId());*/
        TextView logoTv = contentView.findViewById(R.id.logo_tv);
        logoTv.setText(logoInfo.getBrand().toUpperCase());

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        try {
            this.removeAllViews();
            this.addView(contentView, lp);
        } catch (Throwable e) {
            //ignore
        }

        getViewTreeObserver().addOnGlobalLayoutListener(mOnGlobalLayout);

        mAdsLoadProxy = new AdsLoadProxy(getContext());
        mAdsLoadProxy.setAdDealType(mDealType);
        mAdsLoadProxy.setAdsLoadListener(new AdsListener() {
            @Override
            public void onAdLoaded(int adFrom, View adView) {
                if (ad_container != null && adView != null) {
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
                    try {
                        ad_container.removeAllViews();
                        ad_container.addView(adView, lp);
                    } catch (Throwable e) {
                        //ignore
                    }
                } else {
                    dealwithJumpAfterAdCallback();
                }
            }

            @Override
            public void onAdLoadFailed(int adFrom, int errorCode) {
                dealwithJumpAfterAdCallback();
            }

            @Override
            public void onClicked(int adFrom, Object object) {
                onAdClicked(adFrom, object);
            }

            @Override
            public void onAdShow(int adFrom, Object object) {
                if (AdsListener.AD_FROM_OWN == adFrom && object instanceof OwnAdBean) {
                    OwnAdBean ownAdBean = (OwnAdBean) object;
                    String value = TRStringUtil.generateString(mScreenPageName, TRAnalyticsConstant.SPLASH_PV, "", "");

                    TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_EXPOSE, TRAnalyticsConstant.SP_AD_EXPOSE_YES);
                    String nativeId = ownAdBean.nativeId;
                    if(TextUtils.isEmpty(ownAdBean.nativeId)) {
                        nativeId = CommonUtils.generateSerialNum();
                        ownAdBean.nativeId = nativeId;
                    }
                    ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
                    builder.setValue(value)
                            .setFrom("x_x_x_x")
                            .setTopicType(TRAnalyticsConstant.ADVERTISE)
                            .setTopicId(ownAdBean.getId())
                            .setItemType(ownAdBean.getJumpType())
                            .setItemId(ownAdBean.getJumpUrl())
                            .setItemValue(ownAdBean.getPck())
                            .setReportSource(ownAdBean.getReportSource())
                            .setCfgId(ownAdBean.getCfgId())
                            .setNativeId(nativeId)
                            .setTaskId(ownAdBean.getTaskId())
                            .setExtraValue(ownAdBean.getLimitClickArea() + "");
                    TRAnalysticsUtil.trackExposure(builder);

                    AdCache.getInstance().updateAdAfterShow(ownAdBean);
                }
            }

            @Override
            public void onAdSkip(int adFrom,Object object) {
                if (AdsListener.AD_FROM_OWN == adFrom && object!=null && object instanceof OwnAdBean) {
                    OwnAdBean ownAdBean = (OwnAdBean) object;
                    String value = TRStringUtil.generateString(mScreenPageName, TRAnalyticsConstant.SPLASH_PV, "", "");
                    ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                    builder.setValue(value)
                            .setFrom("x_x_x_x")
                            .setTopicType(TRAnalyticsConstant.ADVERTISE)
                            .setTopicId(ownAdBean.getId())
                            .setItemType(ownAdBean.getJumpType())
                            .setItemId(ownAdBean.getJumpUrl())
                            .setButtonType(TRAnalyticsConstant.SKIP)
                            .setItemValue(ownAdBean.getPck())
                            .setNativeId(ownAdBean.nativeId)
                            .setReportSource(ownAdBean.getReportSource())
                            .setCfgId(ownAdBean.getCfgId())
                            .setExtraValue("");
                    TRAnalysticsUtil.trackClick(builder);
                }

                TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_CLICK, TRAnalyticsConstant.SP_AD_CLICK_SKIP);

                dealwithJumpAfterAdCallback();
            }

            @Override
            public void onTimeReach(int adFrom) {
                if (!hasTrackClickEvent) {
                    if (ActivityLifecycleUtil.visibleActivityCount > 0) {
                        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_CLICK, TRAnalyticsConstant.SP_AD_CLICK_NO_CLICK);
                    } else {
                        TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_CLICK, TRAnalyticsConstant.SP_AD_CLICK_EXIT_APP);
                    }
                }

                dealwithJumpAfterAdCallback();
            }

            @Override
            public void onAdClose(int adFrom) {

            }

        });

        if(showSelfAd) {
            mAdsLoadProxy.onAdLoad();
        }

    }

    public void onLoadSelfAd() {
        mAdsLoadProxy.onAdLoad();
    }

    public void setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
    }

    public void setPageParamInfo(PageParamInfo mPageParamInfo) {
        this.mPageParamInfo = mPageParamInfo;
    }

    public void setDealType(int mDealType) {
        this.mDealType = mDealType;
    }

    public PageParamInfo getPageParamInfo() {
        return mPageParamInfo;
    }

    public int getDealType() {
        return mDealType;
    }

    private Activity getActivity() {
        Activity activity = null;
        if (this.getContext() instanceof Activity) {
            activity = (Activity) getContext();
        }
        return activity;
    }

    private void dealwithJumpAfterAdCallback() {
        Activity activity = getActivity();
        if(activity != null) {
            if (isStartActivity) {
                if (LanguageSelectActivity.canShow() && LanguageSelectManager.notSelectFromStartActivity()) {
                    Intent langIntent = new Intent(activity, LanguageSelectActivity.class);
                    langIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    langIntent.putExtra(Constant.FROMPAGE, mFromPage); // 来源标记，用于统计启动耗时
                    activity.startActivity(langIntent);
                    activity.finish();
                    LanguageSelectManager.markLangSelectFromStartActivity();
                    return;
                }
            }
            if(AdsLoadProxy.TYPE_NORMAL == mDealType) {
                Intent restartIntent = new Intent();
                restartIntent.setClass(activity, MainActivity.class);
                restartIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activity.startActivity(restartIntent);
            }
            activity.finish();
        }
    }

    public FrameLayout getAdContainerView() {
        return ad_container;
    }

    public RelativeLayout getAdBottomLog() {return layout_bottom_logo;}

    public void onDestroy() {
        if (mOnGlobalLayout != null) {
            getViewTreeObserver().removeOnGlobalLayoutListener(mOnGlobalLayout);
        }
        if (mAdsLoadProxy != null) {
            mAdsLoadProxy.onDestroy();
        }
        //AD退出的时候弹框的总控恢复默认值
        TRManager.getInstance().resetShowStatus();
    }

    private void onAdClicked(int adFrom, Object object) {
        if (AdsListener.AD_FROM_OWN == adFrom && object instanceof OwnAdBean) {
            OwnAdBean bean = (OwnAdBean) object;
            String value = TRStringUtil.generateString(mScreenPageName, TRAnalyticsConstant.SPLASH_PV, "", "");
            bean.setValue(value);
            bean.setDealType(mDealType);
            TRManager.getInstance().dispatchEvent(TRActivateConstant.SPLASH_AD, bean);
            if (!hasTrackClickEvent) {
                TRAnalysticsUtil.trackSpAd(TRAnalyticsConstant.SP_AD_CLICK, TRAnalyticsConstant.SP_AD_CLICK_ADS);
                hasTrackClickEvent = true;
            }

            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom("x_x_x_x")
                    .setTopicType(TRAnalyticsConstant.ADVERTISE)
                    .setTopicId(bean.getId())
                    .setItemType(bean.getJumpType())
                    .setItemId(bean.getJumpUrl())
                    .setButtonType(TRAnalyticsConstant.ICON)
                    .setItemValue(bean.getPck())
                    .setReportSource(bean.getReportSource())
                    .setNativeId(bean.nativeId)
                    .setCfgId(bean.getCfgId())
                    .setExtraValue(bean.getLimitClickArea() + "");
            TRAnalysticsUtil.trackClick(builder);

            if (bean.isFromStartup() && mAdsLoadProxy != null) {
                mAdsLoadProxy.stopSkipTimer();

                Activity activity = getActivity();
                if (activity != null && !activity.isDestroyed() && !activity.isFinishing()) {
                    activity.finish();
                }
            }
        }
    }


    private ViewTreeObserver.OnGlobalLayoutListener mOnGlobalLayout = new ViewTreeObserver.OnGlobalLayoutListener() {
        @Override
        public void onGlobalLayout() {
            getViewTreeObserver().removeOnGlobalLayoutListener(this);
            //initLayout();//新UI不需要底部margin了
        }
    };







    public static class Builder {
        private Context mContext;

        public Builder(Context context) {
            this.mContext = context;
        }
        public AdvertiseView build(int dealType, PageParamInfo pageParamInfo, String screenName,boolean showSlefAd) {
            final AdvertiseView adView = new AdvertiseView(mContext);
            adView.setDealType(dealType);
            adView.initViews(showSlefAd);
            adView.setPageParamInfo(pageParamInfo);
            adView.setScreenPageName(screenName);
            return adView;
        }
        public AdvertiseView build(int dealType, PageParamInfo pageParamInfo, String screenName) {
            final AdvertiseView adView = new AdvertiseView(mContext);
            adView.setDealType(dealType);
            adView.initViews(true);
            adView.setPageParamInfo(pageParamInfo);
            adView.setScreenPageName(screenName);
            return adView;
        }
    }


}
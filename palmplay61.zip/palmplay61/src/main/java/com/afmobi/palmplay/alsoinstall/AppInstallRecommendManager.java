package com.afmobi.palmplay.alsoinstall;

import android.graphics.Rect;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.customview.MyFrameLayout;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.FeatureRankThreeLineData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.DecorateInfo;
import com.afmobi.palmplay.model.FeatureSinglePageItemData;
import com.afmobi.palmplay.model.HotWordFeatureData;
import com.afmobi.palmplay.model.ItemDetailSearchData;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.TermInfo;
import com.afmobi.palmplay.search.v6_4.BaseSearchAdapter;
import com.afmobi.util.DisplayUtil;
import com.google.gson.reflect.TypeToken;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.widgetslib.widget.OSIconTextView;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

public class AppInstallRecommendManager {

    public final static int H_STYLE_LINE_DEFAULT = 4; //横向布局默认展示4个
    public final static int V_STYLE_LINE_DEFAULT = 3; //纵向布局默认展示3个

    public final static String SUFFIX_EXPAND = "_Expand";
    public final static String FEATURE_RECOMMEND_TAG = "featureRecommend";

    public static void onAppInstallRecommendLayout(View layout_also_install, FeatureBean featureBean, int position,
                                                   String screenName, String featureName, String fromPage, String from, boolean gdprHasAllowed,
                                                   OfferInfo offerInfo, TermInfo termInfo, int clickPosition, FeatureItemData itemData,
                                                   CountDownTimer countdownTimer) {
        if (layout_also_install == null) {
            return;
        }

        String style = (featureBean != null) ? (featureBean.style) : null;
        DecorateInfo decorate = null;
        String topicPlace = null, placementId = null;

        if (TextUtils.equals(RankStyleType.H_ROLL_TITLE, style)
           || TextUtils.equals(RankStyleType.H_ROLL_NO_TITLE, style)
                || TextUtils.equals(RankStyleType.H_ROLL_TITLE_LITE, style)
                || TextUtils.equals(RankStyleType.H_ROLL_TITLE_LARGE, style)) { //单行横向滑动样式
            if (featureBean != null && featureBean.dataList != null) {
                List<FeatureBaseData> list = featureBean.dataList;
                if (clickPosition >= 0 && clickPosition < list.size()) {
                    FeatureBaseData data = featureBean.dataList.get(clickPosition);
                    if (data instanceof FeatureItemData) {
                        FeatureItemData item = (FeatureItemData) data;
                        decorate = item.decorate;
                        topicPlace = item.topicPlace;
                        placementId = item.placementId;
                    }
                }
            }
        }else if (TextUtils.equals(RankStyleType.V_ROLL_TITLE, style)
               || TextUtils.equals(RankStyleType.V_ROLL_NO_TITLE, style)
                || TextUtils.equals(RankStyleType.H_ROLL_TITLE_TAG_NEW, style)) { //三行横向滑动

            if (featureBean != null && featureBean.threeLineDataList != null) {
                List<FeatureRankThreeLineData> list = featureBean.threeLineDataList;
                int colPos = clickPosition / 3; //列表第几项
                int colIndex = clickPosition % 3; //项的第几个(最多三行)
                if (colPos >= 0 && colPos < list.size()) {
                    FeatureRankThreeLineData threeLineData = featureBean.threeLineDataList.get(colPos);
                    if (threeLineData != null && threeLineData.itemList != null
                            && colIndex >= 0 && colIndex < threeLineData.itemList.size()) {
                        FeatureBaseData data = threeLineData.itemList.get(colIndex);
                        if (data instanceof FeatureItemData) {
                            FeatureItemData item = (FeatureItemData) data;
                            decorate = item.decorate;
                            topicPlace = item.topicPlace;
                            placementId = item.placementId;
                        }
                    }
                }
            }
        }else if (TextUtils.equals(RankStyleType.V_TITLE, style)
                || TextUtils.equals(RankStyleType.V_NO_TITLE, style)
                || TextUtils.equals(RankStyleType.V_ROLL_TITLE_TAG_NEW, style)) { //长列表样式

            if (itemData != null) {
                decorate = itemData.decorate;
                topicPlace = itemData.topicPlace;
                placementId = itemData.placementId;
            }
        }else if (TextUtils.isEmpty(style)) {  //独立专题页->纵向列表样式

            if (itemData != null) {
                decorate = itemData.decorate;
                topicPlace = itemData.topicPlace;
                placementId = itemData.placementId;
            }

        }

        //onViewDetachedWindowListener(layout_also_install, countdownTimer);

        if (decorate != null && decorate.dataList != null && decorate.isShowRecommend) {

            if (TextUtils.equals(decorate.decorateStyle, DecorateInfo.DECORATE_STYLE_H)
                    && decorate.dataList.size() < H_STYLE_LINE_DEFAULT) {

                layout_also_install.setVisibility(View.GONE);
                return;

            }else if (TextUtils.equals(decorate.decorateStyle, DecorateInfo.DECORATE_STYLE_V)
                    && decorate.dataList.size() <= 0) {

                layout_also_install.setVisibility(View.GONE);
                return;

            }


            int visibility = layout_also_install.getVisibility();
            Object i = layout_also_install.getTag();
            String lastPosition = (i instanceof String) ? (String) i : null;
            int orientation = layout_also_install.getResources().getConfiguration().orientation;
            String currPosition = position + "_" + clickPosition + "_" + orientation;
            if (visibility == View.VISIBLE && TextUtils.equals(lastPosition, currPosition)) {
                return;
            }

//            if (visibility != View.VISIBLE) {
//                Animation mShowAction = new AlphaAnimation(0, 1);
//                mShowAction.setDuration(2000);
//                layout_also_install.setAnimation(mShowAction);
//            }

            layout_also_install.setVisibility(View.VISIBLE);
            layout_also_install.setTag(currPosition);

            ViewGroup layout_h = layout_also_install.findViewById(R.id.layout_h);
            TextView tv_title = layout_also_install.findViewById(R.id.tv_title);
            OSIconTextView iv_refresh = layout_also_install.findViewById(R.id.iv_refresh);
            RecyclerView recyclerView = layout_also_install.findViewById(R.id.id_recyclerview);
            LinearLayoutManager lm = new LinearLayoutManager(layout_also_install.getContext());
            ViewGroup.LayoutParams lp = recyclerView.getLayoutParams();
            if (offerInfo != null && offerInfo.isOfferStyle()) {
                tv_title.setTextColor(offerInfo.mainColor);
            }

            RecyclerView.ItemAnimator itemAnimator = recyclerView.getItemAnimator();
            if(itemAnimator instanceof SimpleItemAnimator) {
                SimpleItemAnimator simpleItemAnimator = (SimpleItemAnimator) itemAnimator;
                simpleItemAnimator.setSupportsChangeAnimations(false);
            }

            if (TextUtils.equals(decorate.decorateStyle, DecorateInfo.DECORATE_STYLE_H)
                    || TextUtils.equals(decorate.decorateStyle, DecorateInfo.DECORATE_STYLE_H_SCROLL)) {

                if(lp instanceof RelativeLayout.LayoutParams) {
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) lp;
                    layoutParams.topMargin = 0;
                    recyclerView.setLayoutParams(layoutParams);
                }

                layout_h.setBackgroundResource(R.drawable.selector_also_install_h_bg);

                lm.setOrientation(RecyclerView.HORIZONTAL);
                recyclerView.setLayoutManager(lm);

                if (decorate.dataList.size() == H_STYLE_LINE_DEFAULT) {
                    iv_refresh.setVisibility(View.GONE);
                }else {
                    if (TextUtils.equals(decorate.decorateStyle, DecorateInfo.DECORATE_STYLE_H_SCROLL)) {
                        iv_refresh.setVisibility(View.GONE);
                    }else {
                        iv_refresh.setVisibility(View.VISIBLE);
                    }
                }

            }else if (TextUtils.equals(decorate.decorateStyle, DecorateInfo.DECORATE_STYLE_V)) {

                if(lp instanceof RelativeLayout.LayoutParams) {
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) lp;
                    layoutParams.topMargin = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 2);
                    recyclerView.setLayoutParams(layoutParams);
                }

                layout_h.setBackground(null);

                lm.setOrientation(RecyclerView.VERTICAL);
                recyclerView.setLayoutManager(lm);

                if (decorate.dataList.size() <= V_STYLE_LINE_DEFAULT) {
                    iv_refresh.setVisibility(View.GONE);
                }else {
                    iv_refresh.setVisibility(View.VISIBLE);
                }
            }

            String extras = null;
            if (termInfo != null) {
                try {
                    JSONObject js = new JSONObject();
                    js.put("character", termInfo.termNature);
                    js.put("final_outcome", termInfo.changeTerm);
                    js.put("term", termInfo.term);
                    js.put("associatedTerm", termInfo.associatedTerm);

                    extras = js.toString();
                }catch(Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }

            String fromPageExpand = fromPage + SUFFIX_EXPAND;
            String searchWord = "";
            if (itemData != null && !TextUtils.isEmpty(itemData.searchWord)) {
                searchWord = itemData.searchWord;
            }
            final AppInstallRecommendAdapter adapter;
            if (recyclerView.getAdapter() == null) {
                decorate.showIndex = 0;
                adapter = new AppInstallRecommendAdapter(featureBean, decorate, recyclerView);
                adapter.setOfferInfo(offerInfo);
                adapter.setScreenPageName(screenName);
                adapter.setFeatureName(featureName);
                adapter.setFromPage(fromPageExpand);
                adapter.setFrom(from);
                adapter.setTopicPlace(topicPlace);
                adapter.setPlacementId(placementId);
                adapter.setGdprHasAllowed(gdprHasAllowed);
                adapter.setExtraValue(searchWord);
                adapter.setExtras(extras);
                recyclerView.setAdapter(adapter);
            }else {
                adapter = (AppInstallRecommendAdapter)recyclerView.getAdapter();
                adapter.setOfferInfo(offerInfo);
                adapter.setScreenPageName(screenName);
                adapter.setFeatureName(featureName);
                adapter.setFromPage(fromPageExpand);
                adapter.setFrom(from);
                adapter.setTopicPlace(topicPlace);
                adapter.setPlacementId(placementId);
                adapter.setGdprHasAllowed(gdprHasAllowed);
                adapter.setExtraValue(searchWord);
                adapter.setExtras(extras);
                adapter.setData(featureBean, decorate, true);
            }

            final FeatureBean srcFeatureBean = featureBean;
            final DecorateInfo decorateInfo = decorate;
            final String mFrom = from;
            final String value = TRStringUtil.generateString(screenName, featureName, topicPlace, placementId,"");
            final String extrasTrack = extras;
            final String finalSearchWord = searchWord;
            iv_refresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //TODO:refresh data
                    if (adapter != null) {
                        adapter.onRefreshClicked();
                        String extraValue;
                        if(screenName.equals(TRAnalyticsConstant.PAGE_SEARCH_RESULT)) {
                            extraValue = finalSearchWord;
                        } else {
                            extraValue = "";
                        }
                        trackRefreshClick(srcFeatureBean, decorateInfo, mFrom, value, extrasTrack, extraValue);
                    }
                }
            });

        } else {

            boolean isHaveShowedDecorate = false;

            if (TextUtils.equals(RankStyleType.H_ROLL_TITLE, style)
             || TextUtils.equals(RankStyleType.H_ROLL_NO_TITLE, style)
             || TextUtils.equals(RankStyleType.H_ROLL_TITLE_LITE, style)
             || TextUtils.equals(RankStyleType.H_ROLL_TITLE_LARGE, style)) { //单行可横向滚动的样式

                Iterator<FeatureBaseData> it = (featureBean != null && featureBean.dataList != null) ? featureBean.dataList.iterator() : null;
                while (it != null && it.hasNext()) {
                    FeatureBaseData baseData = it.next();
                    if (baseData instanceof FeatureItemData) {
                        FeatureItemData item = (FeatureItemData) baseData;
                        if (item.decorate != null && item.decorate.isShowRecommend) {
                            isHaveShowedDecorate = true;
                            break;
                        }
                    }
                }

            } else if (TextUtils.equals(RankStyleType.V_ROLL_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_ROLL_NO_TITLE, style)
                    || TextUtils.equals(RankStyleType.H_ROLL_TITLE_TAG_NEW, style)) { //三行横向滑动样式

                List<FeatureRankThreeLineData> list = (featureBean != null) ? featureBean.threeLineDataList : null;
                Iterator<FeatureRankThreeLineData> it = (list != null) ? list.iterator() : null;
                while (it != null && it.hasNext()) {
                    FeatureRankThreeLineData threeLineData = it.next();
                    if (threeLineData != null && threeLineData.size() > 0) {

                        Iterator<FeatureBaseData> iterator = threeLineData.itemList.iterator();
                        while (iterator != null && iterator.hasNext()) {
                            FeatureBaseData baseData = iterator.next();
                            if (baseData instanceof FeatureItemData) {
                                FeatureItemData item = (FeatureItemData) baseData;
                                if (item.decorate != null && item.decorate.isShowRecommend) {
                                    isHaveShowedDecorate = true;
                                    break;
                                }
                            }
                        }
                    }
                }

            } else if (TextUtils.equals(RankStyleType.V_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_NO_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_ROLL_TITLE_TAG_NEW, style)) { //单行长列表样式

            }else if (TextUtils.isEmpty(style)) { //独立专题页->纵向列表样式

            }

            if (isHaveShowedDecorate) {
                return;
            }

            layout_also_install.setVisibility(View.GONE);
        }
    }

    /**
     *  监听view detachWindow时清理监听，停止CountdownTimer
     * */
    public static void onViewDetachedWindowListener(View layout_also_install, CountDownTimer countDownTimer) {

        if (layout_also_install instanceof MyFrameLayout) {
            final MyFrameLayout layout = (MyFrameLayout) layout_also_install;
            layout.setOnDetachedWindowListener(new MyFrameLayout.OnDetachedWindowListener() {
                @Override
                public void onDetachedWindow() {
                    RecyclerView recyclerView = layout.findViewById(R.id.id_recyclerview);
                    if (recyclerView != null && recyclerView.getAdapter() != null) {
                        RecyclerView.Adapter<?> adapter = recyclerView.getAdapter();
                        if (adapter instanceof AppInstallRecommendAdapter) {
                            AppInstallRecommendAdapter appInstallAdapter = (AppInstallRecommendAdapter)adapter;
                            appInstallAdapter.onDestroy();
                        }
                    }

                    if (countDownTimer != null) {
                        countDownTimer.cancel();
                    }
                }
            });
        }

    }

    private static void trackRefreshClick(FeatureBean featureBean, DecorateInfo decorate, String from, String value, String extras, String extraValue) {

        String style = null, topicId = null, itemType = null, itemId = null, name = null, featureId = null;

        long taskId = 0;
        String expId = null, resportSource = null, cfgId = null, varId = null;
        String topicType = (decorate != null) ? decorate.decorateStyle : null;

        if (featureBean != null) {
            style = featureBean.style;
            topicId = featureBean.getId();
            itemType = featureBean.itemType;
            itemId = featureBean.getId();
            name = featureBean.name;
            featureId = featureBean.featureId;
        }

        if (decorate != null && decorate.dataList != null && decorate.dataList.size() > 0) {
            FeatureBaseData baseData = decorate.dataList.get(0);
            if (baseData instanceof FeatureItemData) {
                FeatureItemData item = (FeatureItemData) baseData;
                taskId = item.getTaskId();
                expId = item.getExpId();
                resportSource = item.getReportSource();
                cfgId = item.getCfgId();
                varId = item.getVarId();
            }
        }
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(value)
                .setFrom(from)
                .setTopicType(topicType)
                .setTopicId(topicId)
                .setItemType(itemType)
                .setItemId(itemId)
                .setButtonType(TRAnalyticsConstant.REFRESH)
                .setItemValue(name)
                .setExtraValue(extraValue)
                .setExtras(extras)
                .setTaskId(taskId)
                .setExpId(expId)
                .setReportSource(resportSource)
                .setCfgId(cfgId)
                .setVarId(varId)
                .setFeatureId(featureId);
        TRAnalysticsUtil.trackClick(builder);
    }

    /**
     * 榜单页点击推荐互斥
     * */
    public static boolean onAppInstallRecommendClick(FeatureBean srcFeatureBean, FeatureItemData srcItemData, List<FeatureBean> mFeatureBeanList) {
        if (srcItemData == null || srcFeatureBean == null || TextUtils.isEmpty(srcFeatureBean.featureId)) {
            return false;
        }

        if (TextUtils.isEmpty(srcFeatureBean.style)) {
            return false;
        }

        if (mFeatureBeanList == null || mFeatureBeanList.isEmpty()) {
            return false;
        }

        boolean ret = false;
        Iterator<FeatureBean> it = mFeatureBeanList.iterator();
        while (it.hasNext()) {
            FeatureBean info = it.next();

            if (info.dataList == null || info.dataList.isEmpty()) {
                continue;
            }
            switch (info.style) {
                case RankStyleType.V_TITLE:
                case RankStyleType.V_NO_TITLE:  //单行长列表样式
                case RankStyleType.V_ROLL_TITLE_TAG_NEW:
                    Iterator<FeatureBaseData> itemIt = info.dataList.iterator();
                    while (itemIt.hasNext()) {
                        FeatureBaseData baseData = itemIt.next();
                        if (baseData instanceof FeatureItemData) {
                            FeatureItemData item = (FeatureItemData) baseData;
                            if (TextUtils.equals(info.featureId, srcFeatureBean.featureId)
                                    && TextUtils.equals(item.placementId, srcItemData.placementId)) {
                                continue;
                            } else {
                                if (item.decorate != null) {
                                    if (item.decorate.isShowRecommend) {
                                        item.decorate.isShowRecommend = false;
                                        ret = true;
                                    }
                                }
                            }
                        }
                    }
                    break;


                case RankStyleType.V_ROLL_TITLE:
                case RankStyleType.V_ROLL_NO_TITLE: //三行可横向滚动的样式
                case RankStyleType.H_ROLL_TITLE_TAG_NEW:
                case RankStyleType.H_ROLL_TITLE_LITE: //单行横向滑动（带标签）
                case RankStyleType.H_ROLL_TITLE_LARGE: //单行横向滑动（一行展示3.5个）
                case RankStyleType.H_ROLL_TITLE:
                case RankStyleType.H_ROLL_NO_TITLE: ///单行横向滑动
                    if (TextUtils.equals(info.featureId, srcFeatureBean.featureId)) {
                        continue;
                    }else {
                        if (info.dataList != null) {
                            Iterator<FeatureBaseData> dataIt = info.dataList.iterator();
                            while (dataIt.hasNext()) {
                                FeatureBaseData baseData = dataIt.next();
                                if (baseData instanceof FeatureItemData) {
                                    FeatureItemData item = (FeatureItemData) baseData;
                                    if (item.decorate != null) {
                                        if (item.decorate.isShowRecommend) {
                                            item.decorate.isShowRecommend = false;
                                            ret = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;

                default:
                    break;
            }

        }

        return ret;
    }

    /**
     * 独立专题页点击item的install按钮隐藏其他项的推荐项
     * */
    public static boolean onAppInstallRecommendClick(FeatureSinglePageItemData data, List<FeatureBaseData> mFeatureList) {

        if (data == null) {
            return false;
        }

        if (mFeatureList == null || mFeatureList.isEmpty()) {
            return false;
        }

        boolean ret = false;
        Iterator<FeatureBaseData> it = mFeatureList.iterator();
        while (it.hasNext()) {
            FeatureBaseData obj = it.next();
            if (obj instanceof FeatureSinglePageItemData) {
                FeatureSinglePageItemData item  = (FeatureSinglePageItemData) obj;
                if (TextUtils.equals(item.packageName, data.packageName)) {
                    continue;
                }else {
                    if (item.decorate != null) {
                        if (item.decorate.isShowRecommend) {
                            item.decorate.isShowRecommend = false;
                            ret = true;
                        }
                    }
                }
            }
        }

        return ret;
    }

    private static int getRecommendPosition(List<FeatureBean> featureBeanList) {
        List<FeatureBean> mFeatureBeanList = new ArrayList<>(featureBeanList);
        if (mFeatureBeanList == null || mFeatureBeanList.size() <= 0) {
            return -1;
        }

        for (int i = 0;i < mFeatureBeanList.size(); i++) {
            FeatureBean data = mFeatureBeanList.get(i);
            if (data == null) {
                continue;
            }

            if (RankStyleType.V_TITLE.equalsIgnoreCase(data.style)
                    || RankStyleType.V_NO_TITLE.equalsIgnoreCase(data.style)
                    || RankStyleType.H_ROLL_TITLE.equals(data.style)
                    || RankStyleType.H_ROLL_NO_TITLE.equals(data.style)
                    || RankStyleType.V_ROLL_TITLE_TAG_NEW.equals(data.style)
                    || RankStyleType.H_ROLL_TITLE_LITE.equals(data.style)
                    || RankStyleType.H_ROLL_TITLE_LARGE.equals(data.style)) {

                List<FeatureBaseData> list = data.dataList;
                if (list == null || list.isEmpty()) {
                    continue;
                }

                Iterator<FeatureBaseData> it = list.iterator();
                while (it.hasNext()) {
                    FeatureBaseData obj = (FeatureBaseData) it.next();
                    if (obj instanceof FeatureItemData) {
                        FeatureItemData item = (FeatureItemData) obj;
                        if (item.decorate != null && item.decorate.dataList != null && item.decorate.dataList.size() > 0
                                && item.decorate.isShowRecommend) {
                            return i;
                        }
                    }
                }
            }else if (RankStyleType.V_ROLL_TITLE.equals(data.style)
                    || RankStyleType.V_ROLL_NO_TITLE.equals(data.style)
                    || RankStyleType.H_ROLL_TITLE_TAG_NEW.equals(data.style)) {


                List<FeatureRankThreeLineData> list = data.threeLineDataList;
                if (list == null || list.size() <= 0) {
                    continue;
                }

                Iterator<FeatureRankThreeLineData> it = list.iterator();
                while (it.hasNext()) {
                    FeatureRankThreeLineData obj = (FeatureRankThreeLineData) it.next();
                    if(obj == null || obj.size()<=0) {
                        continue;
                    }

                    Iterator<FeatureBaseData> iterator = obj.itemList.iterator();
                    while (iterator.hasNext()) {
                        FeatureBaseData baseObj = iterator.next();
                        if (baseObj instanceof FeatureItemData) {
                            FeatureItemData item = (FeatureItemData) baseObj;
                            if (item.decorate != null && item.decorate.dataList != null && item.decorate.dataList.size() > 0
                                    && item.decorate.isShowRecommend) {
                                return i;
                            }
                        }
                    }
                }
            }
        }

        return -1;
    }

    /**
     * 获取某个风格装饰数据展示子位置
     * */
    private static int getChildIndexByFeatureBean(FeatureBean featureBean) {
        if (featureBean == null) {
            return -1;
        }

        if (featureBean.dataList != null && featureBean.dataList.size() > 0) {
            int index = 0;
            Iterator<FeatureBaseData> it = featureBean.dataList.iterator();
            while (it.hasNext()) {
                FeatureBaseData baseData = it.next();
                if (baseData instanceof FeatureItemData) {
                    FeatureItemData item = (FeatureItemData) baseData;
                    if (item.decorate != null && item.decorate.isShowRecommend) {
                        return index;
                    }
                }

                index++;
            }
        }

        return -1;
    }

    /**
     * 监听RecyclerView判断是否划出屏幕，展示或隐藏下了又下的推荐布局
     * */
    public static void onRecyclerViewScroll(RecyclerView recyclerView, List<FeatureBean> featureBeanList, RecyclerView.Adapter adapter) {
        if (recyclerView == null || featureBeanList == null || featureBeanList.isEmpty()) {
            return;
        }

        RecyclerView.LayoutManager lm = recyclerView.getLayoutManager();
        if (!(lm instanceof LinearLayoutManager)) {
            return;
        }

        int pos = getRecommendPosition(featureBeanList);
        if (pos == -1) {
            return;
        }

        final int viewIndex = (recyclerView instanceof XRecyclerView) ? (pos + 1) : pos;
        LinearLayoutManager layoutManager = (LinearLayoutManager) lm;
        int start = layoutManager.findFirstVisibleItemPosition();
        int end = layoutManager.findLastVisibleItemPosition();

        boolean isChanged = false;
        if (viewIndex < start || viewIndex > end) {
            FeatureBean data = (pos >= 0 && pos < featureBeanList.size()) ? featureBeanList.get(pos) : null;
            String style = (data != null) ? data.style : null;
            if (TextUtils.equals(RankStyleType.V_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_NO_TITLE, style)
                    || TextUtils.equals(RankStyleType.H_ROLL_TITLE, style)
                    || TextUtils.equals(RankStyleType.H_ROLL_NO_TITLE, style)
                    || TextUtils.equals(RankStyleType.H_ROLL_TITLE_LITE, style)
                    || TextUtils.equals(RankStyleType.H_ROLL_TITLE_LARGE, style)) {

                List<FeatureBaseData> list = data.dataList;
                if (list == null || list.size() <= 0) {
                    return;
                }

                Iterator<FeatureBaseData> it = list.iterator();
                while (it.hasNext()) {
                    FeatureBaseData obj = (FeatureBaseData) it.next();
                    if (obj instanceof FeatureItemData) {
                        FeatureItemData item = (FeatureItemData) obj;
                        if (item.decorate != null && item.decorate.dataList != null && item.decorate.dataList.size() > 0
                                && item.decorate.isShowRecommend) {
                            item.decorate.isShowRecommend = false;
                            isChanged = true;
                            break;
                        }
                    }
                }
            }else if (TextUtils.equals(RankStyleType.V_ROLL_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_ROLL_NO_TITLE, style)
                    || TextUtils.equals(RankStyleType.H_ROLL_TITLE_TAG_NEW, style)) { //三行横向滑动

                List<FeatureRankThreeLineData> list = new ArrayList<>(data.threeLineDataList);
                if (list == null || list.size() <= 0) {
                    return;
                }

                Iterator<FeatureRankThreeLineData> it = list.iterator();
                while (it.hasNext()) {
                    FeatureRankThreeLineData obj = (FeatureRankThreeLineData) it.next();
                    if(obj == null || obj.size()<=0) {
                        continue;
                    }

                    Iterator<FeatureBaseData> iterator = obj.itemList.iterator();
                    while (iterator.hasNext()) {
                        FeatureBaseData baseObj = iterator.next();
                        if (baseObj instanceof FeatureItemData) {
                            FeatureItemData item = (FeatureItemData) baseObj;
                            if (item.decorate != null && item.decorate.dataList != null && item.decorate.dataList.size() > 0
                                    && item.decorate.isShowRecommend) {
                                item.decorate.isShowRecommend = false;
                                isChanged = true;
                                break;
                            }
                        }
                    }
                }
            }
        }else {

            FeatureBean data = (pos >= 0 && pos < featureBeanList.size()) ? featureBeanList.get(pos) : null;
            String style = (data != null) ? data.style : null;
            if (TextUtils.equals(RankStyleType.V_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_NO_TITLE, style)
                    || TextUtils.equals(RankStyleType.V_ROLL_TITLE_TAG_NEW, style)) { //长列表样式
                int index = getChildIndexByFeatureBean(data);
                if (index == -1) {
                    return;
                }

                View child = lm.findViewByPosition(viewIndex);
                if (child == null) {
                    return;
                }

                RecyclerView childRecycler = child.findViewById(R.id.bv_home_recycleview);
                if (childRecycler == null) {
                    return;
                }

                View childChild = childRecycler.getChildAt(index);
                if (childChild == null) {
                    return;
                }

                Rect rect = new Rect();
                childChild.getGlobalVisibleRect(rect);
                if (rect.bottom <= 0 || rect.top >= DisplayUtil.getScreenHeightPx(PalmplayApplication.getAppInstance())) {
                    if (data != null && data.dataList != null && index < data.dataList.size()) {
                        FeatureBaseData baseData = data.dataList.get(index);
                        if (baseData instanceof FeatureItemData) {
                            FeatureItemData itemData = (FeatureItemData) baseData;
                            if (itemData.decorate != null && itemData.decorate.isShowRecommend) {
                                itemData.decorate.isShowRecommend = false;
                                isChanged = true;
                            }
                        }
                    }
                }
            }
        }

        if (isChanged) {
            if (adapter != null) {
                adapter.notifyItemChanged(viewIndex, "hRecommend");
            }
        }
    }

    /**
     * 监听独立专题页RecyclerView判断是否划出屏幕，展示或隐藏推荐布局
     * */
    public static void onRecyclerViewScroll(XRecyclerView recyclerView, List<FeatureBaseData> mFeatureList, RecyclerView.Adapter adapter) {
        if (recyclerView == null || mFeatureList == null || mFeatureList.isEmpty()) {
            return;
        }

        RecyclerView.LayoutManager lm = recyclerView.getLayoutManager();
        if (!(lm instanceof LinearLayoutManager)) {
            return;
        }

        int pos = -1;
        for (int i = 0;i < mFeatureList.size();i++) {
            FeatureBaseData data = mFeatureList.get(i);
            if (data instanceof FeatureSinglePageItemData) {
                FeatureSinglePageItemData item = (FeatureSinglePageItemData)data;
                if (item.decorate != null && item.decorate.dataList != null && item.decorate.dataList.size() > 0
                        && item.decorate.isShowRecommend) {
                    pos = i;
                    break;
                }
            }
        }

        if (pos == -1) {
            return;
        }

        LinearLayoutManager layoutManager = (LinearLayoutManager) lm;
        int start = layoutManager.findFirstVisibleItemPosition();
        int end = layoutManager.findLastVisibleItemPosition();

        int viewPosition = pos + 1; //XRecyclerView带刷新布局，view位置与数据位置多1
        if (viewPosition < start || viewPosition > end) {
            FeatureBaseData data = (pos >= 0 && pos < mFeatureList.size()) ? mFeatureList.get(pos) : null;
            if (data instanceof FeatureSinglePageItemData) {
                FeatureSinglePageItemData item = (FeatureSinglePageItemData) data;
                if (item.decorate != null) {
                    item.decorate.isShowRecommend = false;
                    if (adapter != null) {
                        adapter.notifyItemChanged(viewPosition, "recommend");
                    }
                }
            }
        }
    }

    /**
     * 监听搜索结果页RecyclerView判断是否划出屏幕，展示或隐藏推荐布局
     * */
    public static void onSearchRecyclerViewScroll(XRecyclerView recyclerView, List<Object> mFeatureList, BaseSearchAdapter adapter) {
        if (recyclerView == null || mFeatureList == null || mFeatureList.isEmpty()) {
            return;
        }

        TRLinearLayoutManager lm = (TRLinearLayoutManager) recyclerView.getLayoutManager();
        if (!(lm instanceof TRLinearLayoutManager)) {
            return;
        }

        int pos = -1;
        for (int i = 0;i < mFeatureList.size();i++) {
            Object data = mFeatureList.get(i);
            if (data instanceof ItemDetailSearchData) {
                ItemDetailSearchData item = (ItemDetailSearchData)data;
                if (item.decorate != null && item.decorate.dataList != null && item.decorate.dataList.size() > 0
                        && item.decorate.isShowRecommend) {
                    pos = i;
                    break;
                }
            } else if (data instanceof FeatureBean) {
                FeatureBean item  = (FeatureBean) data;
                List<FeatureBaseData> dataList = item.dataList;
                if (dataList != null && dataList.size() > 0) {
                    for (FeatureBaseData featureBaseData : dataList) {
                        if (featureBaseData instanceof FeatureItemData) {
                            FeatureItemData fd = (FeatureItemData) featureBaseData;
                            if (fd.decorate != null && fd.decorate.dataList != null && fd.decorate.dataList.size() > 0
                                    && fd.decorate.isShowRecommend) {
                                pos = i;
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (pos == -1) {
            return;
        }

        TRLinearLayoutManager layoutManager = (TRLinearLayoutManager) lm;
        int start = layoutManager.findFirstVisibleItemPosition();
        int end = layoutManager.findLastVisibleItemPosition();

        int viewPosition = pos + 1; //XRecyclerView带刷新布局，view位置与数据位置多1
        if (viewPosition < start || viewPosition > end) {
            Object data = (pos >= 0 && pos < mFeatureList.size()) ? mFeatureList.get(pos) : null;
            if (data instanceof ItemDetailSearchData) {
                ItemDetailSearchData item = (ItemDetailSearchData) data;
                if (item.decorate != null) {
                    item.decorate.isShowRecommend = false;
                    if (adapter != null) {
                        adapter.clearPoolNotifyItemChanged(viewPosition, "recommend");
                    }
                }
            } else if (data instanceof FeatureBean) {
                FeatureBean item  = (FeatureBean) data;
                List<FeatureBaseData> dataList = item.dataList;
                if (dataList != null && dataList.size() > 0) {
                    for (FeatureBaseData featureBaseData : dataList) {
                        if (featureBaseData instanceof FeatureItemData) {
                            FeatureItemData fd = (FeatureItemData) featureBaseData;
                            if (item.decorate != null) {
                                item.decorate.isShowRecommend = false;
                                if (adapter != null) {
                                    adapter.clearPoolNotifyItemChanged(viewPosition, "recommend");
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 获取DataList的具体类型
     * @param decorateType
     * @return
     */
    public static Type getDecorateDataType(String decorateType){
        if (TextUtils.isEmpty(decorateType)) {
            return null;
        }

        Type type = null;
        switch (decorateType){
            case TRHomeUtil.FEATURE_TYPE_ITEM:
                type = new TypeToken<List<FeatureItemData>>() {}.getType();
                break;
            case TRHomeUtil.FEATURE_TYPE_HOT_WORD:
                type = new TypeToken<List<HotWordFeatureData>>() {}.getType();
                break;
            default:
                break;
        }
        return type;
    }
}

package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRThreadPool;

import java.io.File;

import androidx.collection.LruCache;

/**
 * @author suijiang.du
 */
public class PsCommonCache {
    private LruCache<String, String> mCache = new LruCache(25);
    private static volatile PsCommonCache mInstance;
    public static String COMMON_CACHE_URI = "common_cache_name";
    public static final String KEY_FIND_LIST = "find_list";
    public static final String DETAIL_KEY_FIND_LIST = "detail_find_list";

    //缓存最大时间 14day
    public static final long CACHE_MAX_TIME = 14 * 24 * 60 * 60 * 1000;

    public static PsCommonCache getInstance() {
        if (mInstance == null) {
            synchronized (PsCommonCache.class) {
                if (mInstance == null) {
                    mInstance = new PsCommonCache();
                }
            }
        }
        return mInstance;
    }

    /**
     * 内存缓存
     *
     * @param key
     * @param t
     * @param cls
     * @param <T>
     */
    public <T> void saveToMemoryCache(String key, T t, Class<T> cls) {
        mCache.put(getKeyName(key, cls), new Gson().toJson(t, cls));
    }

    /**
     * 双缓冲
     *
     * @param key
     * @param t
     * @param cls
     * @param <T>
     */
    public <T> void saveToDoubleCache(String key, T t, Class<T> cls) {
        try {
            this.saveToMemoryCache(key, t, cls);
            this.saveToDiskCache(key, t, cls);
        } catch (Exception e) {
            LogUtils.d(e);
        }
    }

    /**
     * 下面两个接口是为了适配首页缓存
     * @param featuredModel
     * @param featuredType
     */
    public void saveToDiskCache(FeaturedModel featuredModel, final String featuredType) {
        TRHomeUtil.saveToCache(featuredModel, featuredType, "");
    }

    public FeaturedModel loadFromDiskCache(String featuredType) {
        return TRHomeUtil.loadFromCache(featuredType, "");
    }

    public <T> void saveToDiskCache(String key, T data, Class<T> cls) {
        String fileName = getKeyName(key, cls);
        if (data != null) {
            TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new TRRunnable(() -> {
                try {
                    Gson gson = new Gson();
                    String text = gson.toJson(data, cls);
                    FilePathManager.jsonToFile(text, fileName);
                } catch (Exception e) {
                    LogUtils.d(e);
                }
            }));
        }
    }

    public void removeToMemoryCache(String key) {
        mCache.remove(key);
    }

    /**
     * 加载缓存
     *
     * @param key
     * @param cls
     * @param <T>
     * @return
     */
    public <T> T loadFromCache(String key, Class<T> cls) {
        T t = null;
        try {
            String str = mCache.get(getKeyName(key, cls));
            if (!TextUtils.isEmpty(str)) {
                t = new Gson().fromJson(str, cls);
            }
            if (t == null) {
                t = loadFromDiskCache(key, cls);
            }
        } catch (Exception e) {
            LogUtils.e(e);
        }
        return t;
    }

    /**
     * 加载磁盘缓存
     *
     * @param name
     * @param cls
     * @param <T>
     * @return
     */
    public <T> T loadFromDiskCache(String name, Class<T> cls) {
        T t = null;
        String fileName = getKeyName(name, cls);
        if (!TextUtils.isEmpty(fileName) && deleteInvalidCache(fileName)) {
            return null;
        }
        if (!TextUtils.isEmpty(fileName)) {
            JsonElement jsonObject = FilePathManager.fileToJson(fileName);
            if (jsonObject != null) {
                t = parse(jsonObject, cls);
            }
        }
        return t;
    }

    private <T> T parse(JsonElement jsonElement, Class<T> cls) {
        T t = null;
        try {
            if (jsonElement != null && jsonElement.isJsonObject()) {
                t = new Gson().fromJson(jsonElement, cls);
            }
        } catch (Exception e) {
            LogUtils.e(e);
        }
        return t;
    }

    public  <T> String getKeyName(String name, Class<T> cls) {
        return COMMON_CACHE_URI + "_" + cls.getSimpleName() + "_" + name;
    }

    /**
     * 删除无效缓存
     *
     * @param name
     * @return
     */
    public static boolean deleteInvalidCache(String name) {
        File file = new File(PalmplayApplication.getAppInstance().getFilesDir() + File.separator + name);
        boolean isInvalid = false;
        if (file.exists()) {
            isInvalid = System.currentTimeMillis() - file.lastModified() > CACHE_MAX_TIME;
        }
        if (isInvalid) {
            file.delete();
        }
        return isInvalid;
    }
}

package com.afmobi.palmplay.appmanage.v2.model

import androidx.annotation.IntDef
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo

sealed class DownloadItem {
    data class DownloadTitle(val title: String, @BtnAllType val btnAllType: Int) : DownloadItem()
    data class DownloadItemInfo(val info: FileDownloadInfo, val installed: Boolean) : DownloadItem()
    object DownloadEmpty : DownloadItem()
}

data class DownloadStatus(val downloadInfo: FileDownloadInfo?, val speed: Int = -1)

@Retention(AnnotationRetention.SOURCE)
@IntDef(BTN_GONE, BTN_ALL_CONTINUE, BTN_ALL_PAUSE)
annotation class BtnAllType

const val BTN_GONE = 0   // 不显示全部按钮
const val BTN_ALL_CONTINUE = 1     // 显示全部按钮，文案全部继续
const val BTN_ALL_PAUSE = 2     // 显示全部按钮，文案全部暂停

const val MIN_CLICK_DURATION = 500   // 点击防抖检查最小时差

const val REFRESH_ALL = "refreshAll"
const val REFRESH_BTN_TYPE = "refreshBtn"

/**
 * 下载管理页面UI状态数据类
 * 用于统一管理页面所有状态数据
 */
data class DownloadUiState(
    // 安装中列表（下载中 & 已下载）
    val installingList: List<DownloadItem.DownloadItemInfo> = emptyList(),
    // 已安装列表
    val installedList: List<DownloadItem.DownloadItemInfo> = emptyList(),

    // 不可下载列表
    val noResList: List<FileDownloadInfo> = emptyList(),

    // 全部按钮状态
    val btnAllType: Int = BTN_GONE,

    // 加载状态
    val isLoading: Boolean = true,

    // 不可下载列表是否折叠
    val isNoResListFold: Boolean = true
) {

    // 便利方法
    fun hasInstallingItems(): Boolean = installingList.isNotEmpty()

    fun hasInstalledItems(): Boolean = installedList.isNotEmpty()

    fun hasNoResItems(): Boolean = noResList.isNotEmpty()

    fun installingCount(): Int = installingList.size

    fun hasAnyDownloadItems(): Boolean =
        hasInstallingItems() || hasInstalledItems()

    fun isDownloadDataEmpty(): Boolean =
        !(hasAnyDownloadItems() || hasNoResItems())
}
package com.afmobi.palmplay.appdetail.model;

import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.firebase.FirebaseAnalyticsTool;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.push.TRPushMsgsManager;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.TRAnalyticsManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;

import java.util.ArrayList;

/***
 * 统计相关和部分intent得数据处理model，来自TRAppOtherModel
 */
public class TRAppOtherData {

    public static final String KEY_AUTO_DOWNLOAD = "isAutoDownload";

    // depplink SDP
    private Uri uri;
    private String utm_source; // 当商店判断到deeplink中包含utm_source参数且值等于transsiondsp，代表此次点击由DSP带来，则需要将此次点击带来的下载通过postback url进行网络请求（postback url会携带对应的参数）
    private String utm_click; //唯一clickid，用作效果回传的URL的唯一标识，商店侧需要记录，用于后续对比数据
    private String postback; //商店将效果回传的目标地址，此地址中会携带参数，需要一并请求
    private String utm_campaign; //DSP推广计划ID，商店侧需要记录，用于后续对比数据
    private String utm_creative; //DSP创意ID，商店侧需要记录，用于后续对比数据
    private String utm_ga; //广告受众用户ID，商店侧需要记录，用于后续对比数据
    private boolean mRequestDSP = false; // dsp的回传请求调起过
    private String _mediatype;
    private String _source;
    private long mStartTime;

    private String mItemID;
    private String mPackageName;
    private String mName;
    private String fromPageID;
    private boolean formNotify;
    private String msgId;
    private String mArgumentsTitle;
    private String imgUrl;
    private PageParamInfo mPageParamInfo;

    public int downloadCount;
    public String versionName; //add for Palmpaly6.0 20160513
    public long size;
    public int observerStatus;
    public String downloadUrl;
    public String downloadID;
    public String star;
    public float score;
    public String verifyGoogle;
    public String showPlay;
    public String outerUrl;
    public String topicID;
    public String topicPlace;
    public String mFrom;
    public boolean isPluto = false;
    public boolean isAutoDownload;

    public int externalId;
    public String varId;
    public String expId;
    public String cfgId;
    public String reportSource;
    public String mClickReportUrl;
    public String mSearchKeyWord;
    public String mSearchType;
    public String siteId;
    public String subSiteId;
    public String pid;
    public long taskId = 0;
    public String referrer;
    public String nativeId;
    public String adPositionId;
    public String pageSign;
    public boolean backFloatball;
    public int track_type=2;
    public ArrayList<String> trackUrls;
    public boolean isVa;
    public String category2;
    private int versionCode;
    public String tabId;
    public long nfAbId = 0L;//应用更新信息 命中实验Id
    public long nfAbExpId = 0L;//应用更新信息 命中实验ExpId

    public void analysisIntentData(Bundle bundle, PageParamInfo mPageParamInfo) {
        if (bundle == null) {
            return;
        }
        this.mPageParamInfo = mPageParamInfo;
        String url = bundle.getString("url");
        if (!TRStringUtil.isBlank(url)) {
            uri = Uri.parse(url);
            if (uri != null) {
                mStartTime = System.currentTimeMillis();
                utm_source = uri.getQueryParameter("utm_source");
                _mediatype = uri.getQueryParameter("_mediatype");
                _source = uri.getQueryParameter("_source");
                utm_click = uri.getQueryParameter("utm_click");
                utm_campaign = uri.getQueryParameter("utm_campaign");
                utm_creative = uri.getQueryParameter("utm_creative");
                utm_ga = uri.getQueryParameter("utm_ga");
                postback = uri.getQueryParameter("postback");
                mName = uri.getQueryParameter("name");
                try {
                    String id = uri.getQueryParameter("externalId");
                    if (id != null) {
                        externalId = Integer.parseInt(id);
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                String mbackFloatball = uri.getQueryParameter("backFloatball");
                backFloatball = "true".equalsIgnoreCase(mbackFloatball);
                tabId = uri.getQueryParameter("tabId");
            }
        }
        nativeId = bundle.getString(TRAnalyticsConstant.NATIVE_ID_EW,"");
        //处理push而来的打点
        String str = bundle.getString("fromPage", "");//push相关都带进了frompage，因此需要解析frompage

        LogUtils.d(LogUtils.TAG_PUSH, "fromPage:" + str);

        if (!TRStringUtil.isBlank(str) && str.startsWith("Push")) {
            String[] strs = str.split(":");

            if (strs != null && strs.length >= 4) {

                int fromTypeInt = 0;
                try {
                    fromTypeInt = Integer.parseInt(strs[2]);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
                String fromType = TRPushMsgsManager.getInstance().getFromType(fromTypeInt);
                fromPageID = fromType +"_"+strs[1]+ "_"+strs[3];
                boolean isSuppportBig = strs[3].equals("1") ? true : false;
                TRPushMsgsManager.getInstance().trackByAthena(isSuppportBig ? 1: 0,fromType, "", 3, strs[1],"",nativeId,TRAnalysticsUtil.getFromSite());
            }
        } else {
            fromPageID = bundle.getString("fromPage");
        }

        if(bundle.containsKey("pageSign")) {
            pageSign = bundle.getString("pageSign");
        }
        // end

        formNotify = bundle.getBoolean(FromPageType.Notify, false);
        msgId = bundle.getString("msgId", "-1");
        downloadCount = bundle.getInt("downloadCount");
        versionName = bundle.getString("version");
        versionCode = bundle.getInt("versionCode");
        size = bundle.getLong("size");
        observerStatus = bundle.getInt("observerStatus");
        downloadUrl = bundle.getString("downloadUrl");
        downloadID = bundle.getString("downloadID");
        star = bundle.getString("star");
        score = bundle.getFloat("score");
        outerUrl = bundle.getString("outerUrl");
        verifyGoogle = bundle.getString("verifyGoogle");
        showPlay = bundle.getString("showPlay");
        mItemID = bundle.getString("ItemID");
        fromPageID = bundle.getString("fromPage");
        mPageParamInfo.setLastPage(bundle.getString(PageConstants.PAGE_KEY_LASTPAGE));
        mPageParamInfo.setCurPage(PageConstants.Detail_Soft_xxxx + mItemID);
        mArgumentsTitle = bundle.getString("title");
        imgUrl = bundle.getString("imgUrl");
        mPackageName = bundle.getString("packageName");
        if (mArgumentsTitle == null) {
            mArgumentsTitle = "";
        }
        topicID = bundle.getString("topicid");
        topicPlace = bundle.getString("topic_place");
        mFrom = bundle.getString("value","");
        isAutoDownload = bundle.getBoolean(KEY_AUTO_DOWNLOAD);
        varId = bundle.getString(TRAnalyticsConstant.VARID);
        expId = bundle.getString(TRAnalyticsConstant.KEY_EXP_ID);
        cfgId = bundle.getString(TRAnalyticsConstant.CFG_ID,"");
        reportSource = bundle.getString(TRAnalyticsConstant.REPORT_SOURCE,"");
        mClickReportUrl = bundle.getString(TRAnalyticsConstant.CLICK_REPORT_URL,"");
        mSearchType = bundle.getString(TRAnalyticsConstant.TYPE_KEYWORD,"");
        mSearchKeyWord = bundle.getString(TRAnalyticsConstant.SEARCH_KEYWORD,"");
        siteId = bundle.getString(TRAnalyticsConstant.SITE_ID,"");
        subSiteId = bundle.getString(TRAnalyticsConstant.SUB_SITE_ID,"");
        pid = bundle.getString(TRAnalyticsConstant.PID,"");
        taskId = bundle.getLong(TRAnalyticsConstant.KEY_TASK_ID, 0L);
        referrer = bundle.getString(TRAnalyticsConstant.REFERRER,"");

        adPositionId = bundle.getString(TRAnalyticsConstant.AD_POSITION_ID,"");
        if(bundle.containsKey("track_type")) {
            try {
                track_type = Integer.valueOf(bundle.getString("track_type"));
            }catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
        trackUrls=bundle.getStringArrayList("trackUrls");
        isVa = bundle.getBoolean("isVa");
        category2 = bundle.getString("category2");
        //isPluto
        FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadingInfobyPackageName(mPackageName);
        if(fileDownloadInfo == null) {
            fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(mPackageName);
        }
        if(fileDownloadInfo != null && fileDownloadInfo.extraInfo != null) {
            isPluto = fileDownloadInfo.extraInfo.isPlutoOffer;
        }
    }

    public Object getParam(String name) {
        if (TRStringUtil.isBlank(name)) {
            return null;
        }
        if (name.equals("mItemID")) {
            return mItemID;
        } else if (name.equals("mPackageName")) {
            return mPackageName;
        } else if (name.equals("mArgumentsTitle")) {
            return mArgumentsTitle;
        } else if (name.equals("mRequestDSP")) {
            return mRequestDSP;
        } else if (name.equals("imgUrl")) {
            return imgUrl;
        } else if (name.equals("fromPageID")) {
            return fromPageID;
        } else if (name.equals("mPageParamInfo")) {
            return mPageParamInfo;
        } else if (name.equals("score")) {
            return score;
        } else if (name.equals("star")) {
            return  star;
        } else if (name.equals("downloadID")) {
            return downloadID;
        }  else if (name.equals("downloadUrl")) {
            return downloadUrl;
        }  else if (name.equals("status")) {
            return observerStatus;
        }  else if (name.equals("downloadcount")) {
            return downloadCount;
        }  else if (name.equals("size")) {
            return  size;
        }  else if (name.equals("version")) {
            return versionName;
        }  else if (name.equals("versionCode")) {
            return versionCode;
        } else if (name.equals("google")) {
            return verifyGoogle;
        } else if (name.equals("showplay")) {
            return showPlay;
        } else if (name.equals("outurl")) {
            return outerUrl;
        } else if (name.equals("nofity")) {
            return formNotify;
        } else if (name.equals("topicId")) {
            return topicID;
        } else if (name.equals("topicPlace")) {
            return topicPlace;
        } else if (name.equals("value")) {
            return mFrom;
        } else if ("isPluto".equals(name)) {
            return isPluto;
        } else if (TRAnalyticsConstant.ITEM_FROM.equals(name)){
            //reportSource和itemFrom内容一致
            return reportSource;
        } else if (name.equals("externalId")) {
            return externalId;
        } else if(name.equals(TRAnalyticsConstant.REPORT_SOURCE)) {
            return reportSource;
        } else if(name.equals(TRAnalyticsConstant.CFG_ID)) {
            return cfgId;
        } else if(name.equals(TRAnalyticsConstant.SITE_ID)) {
            return siteId;
        } else if(name.equals(TRAnalyticsConstant.SUB_SITE_ID)) {
            return subSiteId;
        } else if(name.equals(TRAnalyticsConstant.PID)){
            return pid;
        } else if (name.equals(TRAnalyticsConstant.KEY_TASK_ID)) {
            return taskId;
        } else if(name.equals(TRAnalyticsConstant.REFERRER)){
            return referrer;
        } else if(name.equals(TRAnalyticsConstant.NATIVE_ID_EW)) {
            return nativeId;
        } else if(name.equals(TRAnalyticsConstant.AD_POSITION_ID)) {
            return adPositionId;
        } else if(name.equals("pageSign")) {
            return pageSign;
        } else if(name.equals("backFloatball")) {
            return backFloatball;
        }
        return null;
    }

    public void setParam(Object o) {
        if (o == null) {
            return;
        }
        if (o instanceof String) {
            if ("mItemID".equals(o)) {
                mItemID = (String) o;
            } else if ("fromPageID".equals(o)) {
                fromPageID = (String) o;
            } else if ("mPackageName".equals(o)) {
                mPackageName = (String) o;
            }
        }
    }

    public void setParam(String name, Object value){
        if("mItemID".equals(name)){
            mItemID = (String) value;
        }
    }

    public void setBooleanParam(String name, boolean flag) {
        if (TRStringUtil.isBlank(name)) {
            return;
        }
        if (name.equals("mRequestDSP")) {
            mRequestDSP = flag;
        }
    }

    public void statusClickAnalytics(boolean isVa, String value, String buttonType, String itemId, String itemValue, String itemType,
                                     String topicId, String topicType, String expId) {
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType(topicType)
                .setTopicId(topicId)
                .setItemType(itemType)
                .setItemId(itemId)
                .setButtonType(buttonType)
                .setItemValue(itemValue)
                .setExtraValue("")
                .setItemFrom(reportSource)
                .setVarId(varId)
                .setExpId(expId)
                .setCfgId(cfgId)
                .setSiteId(siteId)
                .setPid(pid)
                .setTaskId(taskId)
                .setSubSiteId(subSiteId)
                .setReferrer(referrer)
                .setReportSource(reportSource)
                .setNativeId(nativeId)
                .setAdPositionId(adPositionId)
                .setFromPage(fromPageID)
                .setIsVa(isVa);
        if (TRAnalyticsConstant.OPEN.equals(buttonType)) {
            builder.setExtraValue(DeeplinkManager.getDeeplink(itemValue));
        }
        if (nfAbId > 0){
            builder.setNfAbId(nfAbId);
        }
        if (nfAbExpId > 0){
            builder.setNfAbExpId(nfAbExpId);
        }

        TRAnalysticsUtil.trackClick(builder);

    }

    public void trackEvent(int type, AppInfo appInfo) {
        switch (type) {
            case 1:
                if (formNotify) {
                    Bundle bundle = new Bundle();
                    bundle.putString(FirebaseConstants.PARAM_MSG_ID, msgId);
                    TRAnalyticsManager.getmInstance().postCommonEvent(FirebaseConstants.EVENT_PUSH_DETAIL_SHOW, bundle);
                }

                if(TRAnalyticsConstant.MARKET.equals(fromPageID)) {
                    _source = TRAnalyticsConstant.FROM_SITE_MARKET;
                }

                String buttonType = TRAnalyticsConstant.INSTALL;
                AppInfo info = new AppInfo();
                info.packageName = mPackageName;

                PagePvBuilder pagePvBuilder = new PagePvBuilder();
                pagePvBuilder.setValue(TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, "", "", ""))
                        .setFrom(mFrom)
                        .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                        .setItemId(mItemID).setFromSite(_source)
                        .setTopicId(topicID)
                        .setItemFrom(reportSource)
                        .setVarId(varId)
                        .setExpId(appInfo.expId)
                        .setReportSource(reportSource)
                        .setCfgId(cfgId)
                        .setSiteId(siteId)
                        .setSubSiteId(subSiteId)
                        .setButtonType(buttonType)
                        .setAdPositionId(adPositionId)
                        .setItemValue(mPackageName)
                        .setTaskId(taskId)
                        .setIsVa(appInfo != null ? appInfo.isVa : false);
                TRAnalysticsUtil.trackPV(pagePvBuilder);
                break;
            case 3:
                if (appInfo == null) {
                    break;
                }

                break;
            case 4:
                TRAnalyticsManager.getmInstance().postClickEvent(FirebaseConstants.EVENT_HP_DOWNLOAD_CLICK, FirebaseAnalyticsTool.getCommonParamBundle(), true);
                break;

            case 5://detail tab

                PagePvBuilder pagePvBuilderDetail = new PagePvBuilder();
                pagePvBuilderDetail.setValue(TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.DETAIL_DETAILS,"",""))
                        .setFrom(mFrom).setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG).setItemId(mItemID).setFromSite(_source)
                        .setItemFrom(reportSource)
                        .setVarId(varId)
                        .setExpId(appInfo.expId)
                        .setTopicId(topicID)
                        .setIsVa(appInfo != null ? appInfo.isVa : false);
                TRAnalysticsUtil.trackPV(pagePvBuilderDetail);
                break;

            case 6://featured tab

                PagePvBuilder pagePvBuilderFeature = new PagePvBuilder();
                pagePvBuilderFeature.setValue(TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.FEATURE_MODULE,"",""))
                        .setFrom(mFrom).setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG).setItemId(mItemID).setFromSite(_source)
                        .setItemFrom(reportSource)
                        .setVarId(varId)
                        .setExpId(appInfo.expId)
                        .setTopicId(topicID)
                        .setIsVa(appInfo != null ? appInfo.isVa : false);
                TRAnalysticsUtil.trackPV(pagePvBuilderFeature);
                break;

            case 7://comments tab
                PagePvBuilder pagePvBuilderComment = new PagePvBuilder();
                pagePvBuilderComment.setValue(TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE,
                        TRAnalyticsConstant.MODULE_COMMENT,"",""))
                        .setFrom(mFrom).setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG).setItemId(mItemID).setFromSite(_source)
                        .setItemFrom(reportSource)
                        .setVarId(varId)
                        .setExpId(appInfo.expId)
                        .setTopicId(topicID)
                        .setIsVa(appInfo != null ? appInfo.isVa : false);
                TRAnalysticsUtil.trackPV(pagePvBuilderComment);
                break;
            default:
                break;
        }
    }

    public void trackCommon(String eventName) {
        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(eventName, null);
        TRAnalyticsManager.getmInstance().postClickEvent(eventName, FirebaseAnalyticsTool.getCommonParamBundle(), true);
    }

    public Object buildObject(Object o) {
        if (o instanceof AppInfo) {
            ((AppInfo)o).itemID = mItemID;
            ((AppInfo)o).name = TextUtils.isEmpty(mName) ? mArgumentsTitle : mName;
            ((AppInfo)o).showPlay = showPlay;
            ((AppInfo)o).verifyGoogle = verifyGoogle;
            ((AppInfo)o).outerUrl = outerUrl;
            ((AppInfo)o).observerStatus = observerStatus;
            ((AppInfo)o).size = size;
            ((AppInfo)o).downloadCount = downloadCount;
            ((AppInfo)o).iconUrl = imgUrl;
            ((AppInfo)o).packageName = mPackageName;
            ((AppInfo)o).versionName = versionName;
            ((AppInfo)o).version = versionCode;
            ((AppInfo)o).score = score;
            ((AppInfo)o).topicID = topicID;
            ((AppInfo)o).topicPlace = topicPlace;
            ((AppInfo)o).externalId = externalId;
            ((AppInfo)o).reportSource = reportSource;
            ((AppInfo)o).cfgId = cfgId;
            ((AppInfo)o).pid = pid;
            ((AppInfo)o).taskId = taskId;
            ((AppInfo)o).siteId = siteId;
            ((AppInfo)o).subSiteId = subSiteId;
            ((AppInfo)o).referrer = referrer;
            ((AppInfo)o).nativeId = nativeId;
            ((AppInfo)o).adPositionId = adPositionId;
            ((AppInfo)o).track_type = track_type;
            ((AppInfo)o).trackUrls = trackUrls;
            ((AppInfo)o).isVa = isVa;
            ((AppInfo)o).category2 = category2;
            ((AppInfo)o).expId = expId;
            try {
                ((AppInfo)o).varId = Long.parseLong(varId);
            } catch (Exception e) {
                ((AppInfo)o).varId = -1;
            }
            return o;
        }
        return o;
    }

    public boolean isAutoDownload() {
        return isAutoDownload;
    }
}

package com.afmobi.palmplay.cloudfolder.page

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

// 这个 Receiver 只是个“容器”，用来承载硬预装 enabled/disabled 状态
class CloudFolderFlagReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // 不需要做任何事
    }

}

fun setFlagState(context: Context, isFlagged: Boolean) {
    val packageManager = context.packageManager
    val componentName = ComponentName(context, CloudFolderFlagReceiver::class.java)

    // 如果 isFlagged 为 true，我们将组件设置为 "禁用" (作为一种标记状态)
    // 当然，你也可以反过来逻辑
    val newState = if (isFlagged) {
        PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    } else {
        PackageManager.COMPONENT_ENABLED_STATE_ENABLED
    }

    // DONT_KILL_APP 很重要，防止设置状态时系统杀掉你的应用进程
    packageManager.setComponentEnabledSetting(
        componentName,
        newState,
        PackageManager.DONT_KILL_APP
    )
}

fun getFlagState(context: Context): Boolean {
    val packageManager = context.packageManager
    val componentName = ComponentName(context, CloudFolderFlagReceiver::class.java)

    val setting = packageManager.getComponentEnabledSetting(componentName)

    // 检查组件状态
    return when (setting) {
        PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> true // 对应上面的 "禁用" 代表被标记
        PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> false
        PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> false // 默认状态（即 Manifest 里的状态）
        else -> false
    }
}
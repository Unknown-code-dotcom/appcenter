package com.afmobi.palmplay.comment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.main.adapter.viewholder.BaseRecyclerViewAdapter;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.databinding.library.baseAdapters.BR;
import androidx.recyclerview.widget.RecyclerView;

public class UserAvatarAdapter extends BaseRecyclerViewAdapter {

    private List<String> mList = new ArrayList<>();
    private int mSelectPosition = 0; //用户图像默认选中第一个
    private onAvatarSelectChanged mListener;

    public UserAvatarAdapter() {
        mList.clear();
        for (int i=0;i<10;i++) {
            mList.add(String.valueOf(i+1));
        }
    }

    public void setOnAvatarSelectChanged(onAvatarSelectChanged mListener) {
        this.mListener = mListener;
    }

    public void setSelectPosition(String avatar) {
        int index = 0;
        int position = -1;
        try {
            if(!TextUtils.isEmpty(avatar)) {
                index = Integer.parseInt(avatar);
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        if(index > 0) {
            position = index - 1;
        }

        position = Math.max(position, 0);
        onAvatarClick(null, position);
    }

    public String getUserAvatar() {
        return getItemByPosition(mSelectPosition);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ViewDataBinding dataBinding = DataBindingUtil.inflate(inflater, R.layout.layout_avatar_item, parent, false);
        dataBinding.setVariable(BR.avatarAdapter, this);
        return new UserAvatarViewHolder(dataBinding, parent.getContext());
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof UserAvatarViewHolder) {
            UserAvatarViewHolder viewHolder = (UserAvatarViewHolder)holder;
            String item = getItemByPosition(position);
            viewHolder.bind(item, position, mSelectPosition);
        }
    }

    @Override
    public int getItemCount() {
        return mList != null ? mList.size() : 0;
    }

    public String getItemByPosition(int pos) {
        if(pos < 0 || pos >= getItemCount()) {
            return null;
        }
        return mList.get(pos);
    }

    public void onAvatarClick(View view, int position) {
        this.mSelectPosition = position;
        notifyDataSetChanged();

        if(this.mListener != null) {
            this.mListener.onAvatarChanged();
        }
    }

    public boolean isAvatarSelected() {
        if(mSelectPosition >= 0 && mSelectPosition < getItemCount()) {
            return true;
        }
        return false;
    }

}

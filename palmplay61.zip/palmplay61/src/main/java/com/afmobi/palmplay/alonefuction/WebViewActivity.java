// TOP SECRET
package com.afmobi.palmplay.alonefuction;
import static com.transsion.palmstorecore.util.TrWebDomainUtils.isHttpsRequest;
import static com.transsion.palmstorecore.util.TrWebDomainUtils.isCheckedDomain;
import static com.transsion.palmstorecore.util.TrWebDomainUtils.isFbRequest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import com.androidnetworking.utils.WebViewSslDebugHelper;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.util.PadUtils;
import com.afmobi.palmplay.StartActivity;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.clean.CleanNativeMemoryActivity;
import com.afmobi.palmplay.diff.TRReflectManager;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.download.InterfaceStatusChangeImpl;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.h5.ActionInterfaceImpl;
import com.afmobi.palmplay.h5.JsParamsBean;
import com.afmobi.palmplay.h5.offline.H5OfflineManager;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.manager.PointsManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.NavTabInfo;
import com.afmobi.palmplay.model.keeptojosn.ClientOperationRecordNode;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.model.v7_x.AppDeviceInfo;
import com.afmobi.palmplay.model.v7_x.SimpleInstalledAppInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.service.UpdateService;
import com.afmobi.util.ActivityUtility;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UpdateSelfUtil;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.didi.drouter.annotation.Router;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.SystemUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRReflectConstants;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsion.palmstorecore.util.UriExtKt;
import com.transsion.xwebview.Constants;
import com.transsion.xwebview.utils.WebViewUtil;
import com.transsnet.store.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;

import de.greenrobot.event.EventBus;

import static com.afmobi.palmplay.h5.JsCallFunctions.H5_SCENE_MONEY_LOAN;
import static com.afmobi.palmplay.home.TRHomeUtil.KEY_FROM_WEBVIEW;
import static com.afmobi.palmplay.home.TRHomeUtil.requestCode_ForceUpgrade;
import static com.transsion.xwebview.activity.TrWebViewActivity.KEY_HIDE_TITLE_RIGHT_LAYOUT;
import static com.transsion.xwebview.activity.TrWebViewActivity.KEY_SHOW_TITLE;
import static com.transsion.xwebview.activity.TrWebViewActivity.KEY_WEB_SITE;

@Router(path = "/page/webview")
public class WebViewActivity extends BaseEventFragmentActivity implements OnClickListener {
    private static final String H5TAG = "h5Web";
    public static final String KEY_FROM_START = "IS_FROM_START";
    public static final String KEY_FROM = "KEY_FROM";
    public static final String KEY_OUT_URL_ALREADY_RECORD = "already_record"; //产品列表已经带点
    private boolean isShowTitle;
    private boolean isHideTitleRightLayout;

    private WebView mWebView;
    private ProgressBar mProgressBar;
    private final String MARKET_URL_HEAD = "market://details?id=";
    private final String AHA_URL_HEAD = "aha://smallGame?id=";
    private String mReSourceUrl;
    private String mOnlineLink;
    private RelativeLayout mProcessingLayout;

    private TextView tv_title;
    private TextView tv_download_count;
    private Button title_close;
    /**
     * 网络错误UI
     */
    private ScrollView rl_error;
    private TextView go_settings;
    private LinearLayout btn_retry;
    private boolean isError;

    private String mTitleStr = "";

    private boolean isOnPause;

    /**
     * 保存当前titile与url对应
     */
    private HashMap<String, String> mHashMap = new HashMap<String, String>();

    private static final String JS_CODE = "js_code:";
    private static final String URL_REDIRECT = "url_redirect";

//    private List<String> urlHistoryList = new ArrayList<>();
    private boolean hasRecord;
    private RelativeLayout main_toolbar;
    private LinearLayout mTitleRightLayout;
    private boolean isOnResume = false;
    private String mFromPage = "";
    private boolean mPageFinished = false;
    private int mCurrentProgress = 0;
    private String TITLE_BACK = "title_back";
    private String KEY_BACK = "key_back";
    private long mStartTime = 0;
    private boolean mPrivPressBack = false;
    private int mH5TaskId = -1;
    private int mH5TaskType = -1;
    private long mH5TaskRunTime = -1;
    private Handler mTaskHandler;
    private boolean isRefreshFreeshareStatus = false;
    private boolean isRefreshCeanTaskStatus = false;
    private String mType = TRAnalyticsConstant.INNER_URL;
    private String mFrom;

    private HashMap<String,JsParamsBean> mInstallActionCallMap;
    private String mOfflineUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //如果是跑monkey不再执行webview， 7.1.4.2出现bug:MIPROAEE-5496
        if (CommonUtils.isMonkeyRunning()){
            return;
        }

        mStartTime = System.currentTimeMillis();
        mInstallActionCallMap = ActionInterfaceImpl.getInstance().getActionCallForOldWebView();
        if (getIntent() != null) {
            mReSourceUrl = getIntent().getStringExtra(KEY_WEB_SITE);
            mTitleStr = getIntent().getStringExtra("titleStr");
            isShowTitle = getIntent().getBooleanExtra(KEY_SHOW_TITLE, true);
            isHideTitleRightLayout = getIntent().getBooleanExtra(KEY_HIDE_TITLE_RIGHT_LAYOUT,false);
            hasRecord = getIntent().getBooleanExtra(KEY_OUT_URL_ALREADY_RECORD, false);

            mPageParamInfo.setCurPage(getIntent().getStringExtra(PageConstants.PAGE_KEY_CURPAGE));
            mPageParamInfo.setLastPage(getIntent().getStringExtra(PageConstants.PAGE_KEY_LASTPAGE));
            mFromPage = getIntent().getStringExtra(KEY_FROM);
            mType = getIntent().getStringExtra(TRAnalyticsConstant.TYPE);
            mFrom = getIntent().getStringExtra(TRAnalyticsConstant.VALUE);
            if(TextUtils.equals(mFromPage, "FROM_ACT")){
                FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(FirebaseConstants.ACTIVITY_PAGE_SHOW, null);
            }
        }
        //mReSourceUrl = "market://details?id=com.facebook.katana";//https://play.google.com/store/apps/details?id=com.facebook.katana&hl=en
        if (TextUtils.isEmpty(mReSourceUrl)) {
            finish();
            return;
        }

        if(!hasRecord){
            ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(ClientOperationRecordNode.newClickOuterNode(mPageParamInfo, mReSourceUrl, null, null, null));
        }

        if (jumpToMarket()) {//是否要跳市场过外部浏览器
            return;
        }

        setContentView(R.layout.activity_web_view);

        mTaskHandler = new Handler();

        parseTitleParam(mReSourceUrl);

        initViews();
        WebSettings mWebSettings = mWebView.getSettings();
        // mWebView.setBackgroundColor(Color.TRANSPARENT);
        mWebView.setFocusable(true);
        mWebView.requestFocus();
        mWebSettings.setJavaScriptEnabled(true);
        mOfflineUrl = H5OfflineManager.getInstance().getH5LocalPath(mReSourceUrl);
        mWebSettings.setUseWideViewPort(true);  //将图片调整到适合webview的大小
        mWebSettings.setLoadWithOverviewMode(true); // 缩放至屏幕的大小
        mWebSettings.setSupportZoom(true);  //支持缩放，默认为true。是下面那个的前提。
        mWebSettings.setBuiltInZoomControls(true); //设置内置的缩放控件。
        //若上面是false，则该WebView不可缩放，这个不管设置什么都不能缩放。
        mWebSettings.setDisplayZoomControls(false); //隐藏原生的缩放控件
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN); //支持内容重新布局
        mWebSettings.supportMultipleWindows();  //多窗口
        boolean allowFileAccess = !TextUtils.isEmpty(mOfflineUrl);
        mWebSettings.setAllowFileAccess(allowFileAccess);  //设置可以访问文件
        mWebSettings.setAllowFileAccessFromFileURLs(allowFileAccess);//是否允许运行在一个URL环境中的JavaScript访问来自其他URL环境的内容
        mWebSettings.setAllowUniversalAccessFromFileURLs(allowFileAccess);
        mWebSettings.setNeedInitialFocus(true); //当webview调用requestFocus时为webview设置节点
        mWebSettings.setJavaScriptCanOpenWindowsAutomatically(true); //支持通过JS打开新窗口
        mWebSettings.setLoadsImagesAutomatically(true);  //支持自动加载图片
        mWebSettings.setDefaultTextEncodingName("utf-8");//设置编码格式
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        mWebSettings.setDomStorageEnabled(true);

        if (mReSourceUrl.contains("noCache=yes") || mReSourceUrl.contains("noCache%3Dyes")) {
            mWebSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);  //关闭webview中缓存
        } else {
            mWebSettings.setCacheMode(WebSettings.LOAD_DEFAULT);  //关闭webview中缓存
        }

        mWebView.addJavascriptInterface(new JSKit(), "android");

       Looper.myQueue().addIdleHandler(() -> {
//           mReSourceUrl = CommonUtils.addExtraParams(mReSourceUrl, mPageParamInfo, getWindowManager());
           LogUtils.d("add pageInfo mReSourceUrl:" + mReSourceUrl);
           boolean isNetOK = NetworkUtils.isNetworkAvailable(TRApplicationContextUtil.getInstance());
           if (!TextUtils.isEmpty(mOfflineUrl) && (!isNetOK || WebViewUtil.isOfflineFirst(mOfflineUrl))) {
               mOnlineLink = mReSourceUrl;
               String params = parseParams();
               mOfflineUrl += "&isNetOK=" + isNetOK;
               if (!TextUtils.isEmpty(params)) {
                   mOfflineUrl = mOfflineUrl + "&"+ params;
               }
               LogUtils.d(LogUtils.TAG_XWEBVIEW_ACTIVITY, "offlineUrl: " + mOfflineUrl);
               mReSourceUrl = mOfflineUrl;
           }
           TRAnalysticsUtil.trackWebRequest(mReSourceUrl,mFrom,mType, 0);

           mWebView.loadUrl(mReSourceUrl);
           return false;
       });
//        urlHistoryList.add(mReSourceUrl);
//        mWebView.loadUrl("file:///android_asset/java_js_test.html");
        mWebView.setWebViewClient(new DetailsWebViewClicent());
        mWebView.setWebChromeClient(mWebCClient);

//        WebUtils webUtils = new WebUtils(mWebView, mPageParamInfo);
        DownloadStatusManager.getInstance().putStatusChangeListener(this, mInterfaceStatusChange);

    }

    private String parseParams(){
        String param = "";
        if (!TextUtils.isEmpty(mReSourceUrl)) {
            String[] split = mReSourceUrl.split("\\?");
            if (split.length >= 2) {
                param = split[1];
                LogUtils.d(LogUtils.TAG_XWEBVIEW_ACTIVITY, "parseParams: " + param);
            }
        }
        return param;
    }

    private void parseTitleParam(String url) {
        // http://52.76.170.110:9102/url_redirect/?urlCategory=banner&url=http%3A//52.76.170.110%3A8800/h5/shareActivity/index%3FshowTitle%3DF
        // http://52.76.170.110:9102/url_redirect/?urlCategory=banner&url=http%3A//52.76.170.110%3A8800/h5/shareActivity/download%3FshowTitle%3DF
        try {
            if (TextUtils.isEmpty(url))
                return;
            String tempUrl = Uri.decode(url);
            if (tempUrl.contains(URL_REDIRECT)) {
                // tempUrl = Uri.parse(tempUrl).getQueryParameter("url");//这种方式解析出来的URL只带有一个参数，其它的请求参数会被漏掉；
                tempUrl = tempUrl.substring(tempUrl.lastIndexOf("url=http") + "url=".length());
            }
            if (TextUtils.isEmpty(tempUrl))
                return;
            Uri uri = Uri.parse(tempUrl);
            String value = uri.getQueryParameter("showTitle");

            if (TextUtils.isEmpty(value))
                return;
            if ("T".equalsIgnoreCase(value)) {
                isShowTitle = true;
            } else if ("F".equalsIgnoreCase(value)) {
                isShowTitle = false;
            }

            String hideTitleRightLayout = uri.getQueryParameter("hideTitleRightLayout");
            if (TextUtils.isEmpty(hideTitleRightLayout))
                return;
            if ("false".equalsIgnoreCase(hideTitleRightLayout)) {
                isHideTitleRightLayout = false;
            } else if ("true".equalsIgnoreCase(hideTitleRightLayout)) {
                isHideTitleRightLayout = true;
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private void initViews() {

        mProgressBar = (ProgressBar) findViewById(R.id.loading_progressbar);

        tv_title = (TextView) findViewById(R.id.layout_title_content);
        if (TextUtils.isEmpty(mTitleStr)) {
//            tv_title.setVisibility(View.GONE);
        } else {
            tv_title.setText(mTitleStr == null ? "" : mTitleStr);
        }
        ImageView layout_title_back = (ImageView) findViewById(R.id.layout_title_back);
        layout_title_back.setOnClickListener(this);
        View layout_title_right = findViewById(R.id.layout_title_right);
        layout_title_right.setVisibility(View.VISIBLE);
        layout_title_right.setOnClickListener(this);

        tv_download_count = (TextView) findViewById(R.id.tv_downloading_count);
        ImageView iv_title_right_search = (ImageView) findViewById(R.id.layout_title_right_search);
        iv_title_right_search.setVisibility(View.VISIBLE);
        iv_title_right_search.setOnClickListener(this);

        title_close = (Button) findViewById(R.id.title_close);
        title_close.setOnClickListener(this);

        mWebView = (WebView) findViewById(R.id.wv_content);
        mProcessingLayout = (RelativeLayout) findViewById(R.id.rl_processing);

        ImageView mGifView = findViewById(R.id.gif);
        mGifView.setImageResource(R.drawable.wap_loading);

        rl_error = (ScrollView) findViewById(R.id.rl_error);
        go_settings = (TextView) findViewById(R.id.go_settings);
        go_settings.setOnClickListener(this);
        btn_retry = (LinearLayout) findViewById(R.id.btn_retry);
        btn_retry.setOnClickListener(this);

        mTitleRightLayout = findViewById(R.id.ll_right);

        if(isHideTitleRightLayout){
            mTitleRightLayout.setVisibility(View.GONE);
        } else {
            mTitleRightLayout.setVisibility(View.VISIBLE);
            layout_title_right.setVisibility(View.VISIBLE);
            iv_title_right_search.setVisibility(View.VISIBLE);
        }

        main_toolbar = findViewById(R.id.main_toolbar);
        if (!isShowTitle) {
            main_toolbar.setVisibility(View.GONE);
        }
    }

    private void setUpdatedAppCount() {
        TRHomeUtil.refreshAppCount(tv_download_count, null);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.layout_title_right:

                TRJumpUtil.into(WebViewActivity.this, false, mPageParamInfo,"");

                break;
            case R.id.layout_title_right_search:
                TRJumpUtil.switchToSearchActivity(WebViewActivity.this, String.valueOf(TabType.SOFT), "", false,
                        "", false, "", mPageParamInfo,"", TRAnalyticsConstant.BUTTON_SEARCH_IMG);
                break;

            case R.id.title_close:
                finish();
                break;

            case R.id.layout_title_back:
                /*if (mWebView.canGoBack()) {
                    mWebView.goBack();
                } else if (!clickBackEvent()) {
                    finish();
                }*/
                processBackEvent(TITLE_BACK);
                break;

            case R.id.go_settings:
                startActivity(new Intent(Settings.ACTION_SETTINGS));
                break;

            case R.id.btn_retry:
                if (!NetworkUtils.isNetworkAvailable(this)) {
                    if (rl_error != null && rl_error.getVisibility() == View.VISIBLE) {
                        ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), getString(R.string.tip_no_network));
                        return;
                    } else if (rl_error != null) {
                        rl_error.setVisibility(View.GONE);
                        return;
                    }
                }
                isError = false;
                rl_error.setVisibility(View.GONE);
                mWebView.clearCache(true);
                mWebView.reload();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isOnResume = true;
        setUpdatedAppCount();

        if(isRefreshCeanTaskStatus) {
            isRefreshCeanTaskStatus = false;
            notifyH5UpdateStatus(AppDataManager.H5_TYPE_2);
        }
        if(isRefreshFreeshareStatus) {
            isRefreshFreeshareStatus = false;
            notifyH5UpdateStatus(AppDataManager.H5_TYPE_1);
        }
        try {
            if (isOnPause) {
                if (mWebView != null) {
                    mWebView.getClass().getMethod("onResume").invoke(mWebView, (Object[]) null);
                }
                isOnPause = false;
            }
        } catch (Exception e) {
            LogUtils.d(e.toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if(mTaskHandler!=null) {
            mTaskHandler.removeCallbacksAndMessages(null);
            mTaskHandler = null;
        }

        DownloadStatusManager.getInstance().removeStatusChangeListener(this);
        try {
            if (mWebView != null) {
                ViewParent parent = mWebView.getParent();
                if (parent != null) {
                    ((ViewGroup) parent).removeView(mWebView);
                }
                mWebView.stopLoading();
                // 退出时调用此方法，移除绑定的服务，否则某些特定系统会报错
                mWebView.getSettings().setJavaScriptEnabled(false);
                mWebView.setWebViewClient(null);
                mWebView.setWebChromeClient(null);
                mWebView.clearCache(true);
                mWebView.clearHistory();
                mWebView.clearView();
                mWebView.removeAllViews();
                mWebView.destroy();
                //mWebView = null;
            }
        } catch (Exception e) {
            LogUtils.d(e);
        }
        isOnPause = false;
    }

    @Override
    public void onPause() {
        super.onPause();
        isOnResume = false;
        try {
            if (mWebView != null) {
                mWebView.getClass().getMethod("onPause").invoke(mWebView, (Object[]) null);
                isOnPause = true;
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    public void processBackEvent(String backType) {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else if (!clickBackEvent(backType)) {
            trackWebResponseForClose(backType);
            finish();
        }
    }

    public void trackWebResponseForClose(String backType) {
        if(!mPageFinished) {
            long time = System.currentTimeMillis() - mStartTime;
            LogUtils.d(H5TAG,"trackWebResponseForClose cost time = "+time);
            TRAnalysticsUtil.trackWebResponse(0, mType, ""+mCurrentProgress,time,mReSourceUrl,mFromPage,backType);
        } else {
            LogUtils.d(H5TAG,"trackWebResponseForClose not record");
        }
    }

    // add by HJG 2016-10-09
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mWebCClient.getLoaded()) {
            if (rl_error != null && rl_error.getVisibility() == View.VISIBLE) {
                mPrivPressBack = true;
                trackWebResponseForClose(KEY_BACK);
                return super.onKeyDown(keyCode, event);
            }
            try {
                // js执行过alert后，会回调WebChromeClient的onJsAlert方法，在onJsAlert里我们再次判断是否Java处理返回键；
                // 此处实际上并不会抛出异常
                mWebView.loadUrl("javascript:alert('" + JS_CODE + "'+(window.onAndroidBackEvent&&onAndroidBackEvent()))");
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            return true;
        } else if(keyCode == KeyEvent.KEYCODE_BACK) {
            LogUtils.d(H5TAG,"onKeyDown back");
            mPrivPressBack = true;
            trackWebResponseForClose(KEY_BACK);
        }

        return super.onKeyDown(keyCode, event);
    }

    private boolean clickBackEvent(String backType) {
        if ( isFromNotify && !AtyManager.getAtyManager().isExistsActivity(StartActivity.class)) {
            if (!AtyManager.getAtyManager().isExistsActivity(MainActivity.class)) {
                // TODO if has guilde UI page, you need handler it
                ActivityUtility.switchTo(this, MainActivity.class
                        , new com.afmobi.util.ActivityUtility.Params().put(KEY_FROM_WEBVIEW, true));
                trackWebResponseForClose(backType);
                finish();
                return true;
            }
        }

        return false;
    }

    public void startGooglePlay() {
        String packName = mReSourceUrl.substring(MARKET_URL_HEAD.length());
        Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packName));
        boolean marketExist = false;
        final List<ResolveInfo> otherApps = getPackageManager().queryIntentActivities(mIntent, 0);
        for (ResolveInfo otherApp : otherApps) {
            if (otherApp.activityInfo.applicationInfo.packageName.equals("com.android.vending")) {
                ActivityInfo otherAppActivity = otherApp.activityInfo;
                ComponentName componentName = new ComponentName(otherAppActivity.applicationInfo.packageName, otherAppActivity.name);
                //mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                mIntent.setComponent(componentName);
                try {
                    startActivity(mIntent);
                } catch (Exception e) {
                    try {
                        mIntent.setPackage(otherAppActivity.applicationInfo.packageName);
                        startActivity(mIntent);
                    } catch (Exception ignored) {
                    }
                }
                marketExist = true;
                break;
            }
        }
        if (!marketExist) {
            LogUtils.d(H5TAG, "openApp的数据" + Uri.parse("https://play.google.com/store/apps/details?id=" + packName).toString());
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + packName));
            try {
                startActivity(webIntent);
            } catch (Exception e) {
                try {
                    webIntent.setPackage("com.android.chrome");
                    startActivity(webIntent);
                } catch (Exception ignored) {
                }
            }
        }
    }

    //启动谷歌市场
    public void startGooglePlay2() {
        String packName = mReSourceUrl.substring(MARKET_URL_HEAD.length());
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.parse("market://details?id=" + packName);
            intent.setData(uri);
            intent.setPackage("com.android.vending");
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + packName)));
        }
    }

    private void updateH5TaskRecord(Uri uri) {
        if(uri == null) {
            return;
        }
        String taskid = uri.getQueryParameter("h5_taskid");
        String taksType = uri.getQueryParameter("h5_type");
        String taskRunTime = uri.getQueryParameter("h5_time");

        if(!TextUtils.isEmpty(taskid) && !TextUtils.isEmpty(taksType) && !TextUtils.isEmpty(taskRunTime)) {
            mH5TaskId = Integer.parseInt(taskid);
            mH5TaskType = Integer.parseInt(taksType);
            mH5TaskRunTime = Long.parseLong(taskRunTime);
        } else {
            // 数据为空直接返回
            return;
        }
        if(BuildConfig.DEBUG) {
            LogUtils.d(H5TAG,"mH5TaskId = "+mH5TaskId+" mH5TaskType = "+mH5TaskType +" mH5TaskRunTime= "+mH5TaskRunTime);
        }

        if(mH5TaskRunTime > 0 && mH5TaskType > 0) {
            mTaskHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    PalmplayApplication.getAppInstance()
                            .getAppDataManager()
                            .updateTaskInfo(mH5TaskType);
                    if(BuildConfig.DEBUG) {
                        LogUtils.d(H5TAG,"used time is ok");
                    }
                }
            },mH5TaskRunTime);
        }
    }

    private void notifyH5UpdateStatus(int type) {
        String callBack = PalmplayApplication.getAppInstance().getAppDataManager().getCallBackTypeStr(type);
        if (BuildConfig.DEBUG) {
            LogUtils.d(H5TAG,"notify: "+callBack);
        }
        if(mWebView!=null && !TextUtils.isEmpty(callBack)) {
            mWebView.evaluateJavascript(callBack,
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String s) {

                        }
                    });
        }
    }
    /**
     * 第三方合作的应用商 会跳转
     *
     * @return
     */
    private boolean jumpToMarket() {
        if (!TextUtils.isEmpty(mReSourceUrl)) {
            if (mReSourceUrl.endsWith(".apk")) {// 5.4需求，如果是.apk结尾的跳外部浏览器
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                Uri content_url = Uri.parse(mReSourceUrl);
                intent.setData(content_url);
                startActivity(intent);
                finish();// 关闭当前这个过滤跳转用的Activity
                return true;
            } else if (mReSourceUrl.startsWith(MARKET_URL_HEAD)) {// 是Google市场的应用
                // 这里开始执行一个应用市场跳转逻辑，
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(mReSourceUrl)); // 跳转到应用市场，非Google
//                // Play市场一般情况也实现了这个接口
//                // 存在手机里没安装应用市场的情况，跳转会包异常，做一个接收判断
//                if (intent.resolveActivity(getPackageManager()) != null) { // 可以接收
//                    startActivity(intent);
//                } else { // 没有应用市场，我们通过浏览器跳转到Google Play
//                    String packageName = mReSourceUrl.substring(MARKET_URL_HEAD.length());
//                    intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
//                    // 这里存在一个极端情况就是有些用户浏览器也没有，再判断一次
//                    if (intent.resolveActivity(getPackageManager()) != null) { // 有浏览器
//                        startActivity(intent);
//                    } else {
//                        // 浏览器也没
//                    }
//                }
//                finish();// 关闭当前这个过滤跳转用的Activity

                try {
                    startGooglePlay();
//                startGooglePlay2();
                } catch (Exception e) {
                    String packageName = mReSourceUrl.substring(MARKET_URL_HEAD.length());
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
                    try {
                        startActivity(webIntent);
                    } catch (Exception ex) {
                        try {
                            webIntent.setPackage("com.android.chrome");
                            startActivity(webIntent);
                        } catch (Exception ignored) {
                        }
                    }
                }
                finish();

                PageParamInfo pageParamInfo = new PageParamInfo();
                pageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.MarketUrl);
                ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(pageParamInfo);
                return true;
            }else if(mReSourceUrl.startsWith(AHA_URL_HEAD)) {
                TRJumpUtil.jumplink(mReSourceUrl,this,"");
                finish();
                return true;
            }
        }
        return false;
    }

    private void showErrorTipsLayer() {
        rl_error.setVisibility(View.VISIBLE);
        ClientOperationRecordNode node = new ClientOperationRecordNode(ClientOperationRecordNode.TYPE_NO_NETWORK,
                new ClientOperationRecordNode.OperationShareArgs(null, null, null, null, null, null, null));
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(node);
    }

    private void hideErrorTipsLayer() {
        rl_error.setVisibility(View.GONE);
    }

    public class DetailsWebViewClicent extends WebViewClient {

        //6.0及以上，该方法不会触发；
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            LogUtils.d(H5TAG, "------------------------------------------onReceivedError(old) errorCode=" + errorCode);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) return;
            isError = true;
        }

        @TargetApi(Build.VERSION_CODES.M)
        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            /*LogUtils.v(TAG, "------------------------------------------onReceivedError(new) errorCode=" + error.getErrorCode());
            LogUtils.v(TAG, "-------------------------onReceivedError(new) mWebView.url=" + mWebView.getUrl());
            LogUtils.v(TAG, "-------------------------onReceivedError(new) request.url=" + request.getUrl());*/
            if(mWebView == null) {
                return;
            }
            String url = request.getUrl().toString();
            if (request.isForMainFrame() || url.equalsIgnoreCase(mWebView.getUrl())) {
                isError = true;
//                showErrorTipsLayer();
            }
            long costTime = System.currentTimeMillis() - mStartTime;
            String errorDesc = error.getDescription() == null ? "null" : error.getDescription().toString();

            TRAnalysticsUtil.trackWebResponse(0, mType, ""+mCurrentProgress,costTime,url,mFromPage,errorDesc);
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            if (WebViewSslDebugHelper.tryProceedCharlesSslError(handler, error)) {
                return;
            }
            handler.cancel();
            super.onReceivedSslError(view, handler, error);
        }

        //如果提交的时表单结果页，goback可能不起作用，因此要重写这个方法
        @Override
        public void onFormResubmission(WebView view, Message dontResend, Message resend) {
            resend.sendToTarget();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // LogUtils.v(TAG, "------------------------------------------shouldOverrideUrlLoading");
            if (jumpToMarket()) {//是否要跳市场过外部浏览器
                return true;
            }
            // Otherwise allow the OS to handle things like tel, mailto, etc.
            if (parseSchemeHttp(url)) {
                try {
                    //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?text=Hi  PalmPlayer ,do you like my Valentine's card?https://shar.es/19wEcy")));
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    intent.addCategory("android.intent.category.BROWSABLE");
                    intent.setComponent(null);
                    intent.setSelector(null);
                    startActivity(intent);
                } catch (Exception e) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        intent.addCategory("android.intent.category.BROWSABLE");
                        intent.setComponent(null);
                        intent.setSelector(null);
                        intent.setPackage("com.android.chrome");
                        startActivity(intent);
                    } catch (Exception ignored) {
                    }
                }
            } else {
                view.loadUrl(url);
            }
            return true;
        }

        private boolean parseScheme(String url) {
            boolean isAndroidScheme = false;

            try {
                Uri uri = Uri.parse(url);
                String scheme = null;
                if (null != uri) {
                    scheme = uri.getScheme();
                }
                if (UriExtKt.isSchemaHttp(scheme)) {
                    isAndroidScheme = false;
                } else {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(uri);
                    if (intent.resolveActivity(getPackageManager()) != null) { // 可以接收
                        isAndroidScheme = true;
                    }
                }
            } catch (Exception e) {

            }
            return isAndroidScheme;
        }

        private boolean parseSchemeHttp(String url) {
            boolean isAndroidScheme = false;
            try {
                Uri uri = Uri.parse(url);
                String scheme = null;
                if (null != uri) {
                    scheme = uri.getScheme();
                }

                if (!UriExtKt.isSchemaHttp(scheme)) {
                    isAndroidScheme = true;
                } else {
                    isAndroidScheme = false;
                }
            } catch (Exception e) {

            }
            return isAndroidScheme;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            // TODO Auto-generated method stub
            super.onPageFinished(view, url);
            // LogUtils.v(TAG, "------------------------------------------onPageFinished");

            if (view != null && !isShowTitle) {
                String title = view.getTitle();
                if (!TextUtils.isEmpty(title) && TextUtils.isEmpty(mTitleStr)) {
                    tv_title.setText(view.getTitle());
                }
            }
            LogUtils.d(H5TAG,"onPageFinished ~~");
            mPageFinished = true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            // TODO Auto-generated method stub
            mReSourceUrl = mWebView.getUrl();
            MMKVUtils.getMMKV().putString(Constants.KV_CURRENT_URL,mWebView.getUrl());
            super.onPageStarted(view, url, favicon);
            // LogUtils.v(TAG, "------------------------------------------onPageStarted");
        }

        @Override
        public void onLoadResource(WebView view, String url) {
            super.onLoadResource(view, url);
        }

    }

    private class XClient extends WebChromeClient {
        protected boolean loaded = false;

        public boolean getLoaded() {
            return loaded;
        }
    }

    private XClient mWebCClient = new XClient() {
        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            if (rl_error.getVisibility() != View.VISIBLE && !isShowTitle && TextUtils.isEmpty(mTitleStr)) {
                tv_title.setText(title);
            }
            mHashMap.put(mReSourceUrl, title);
            //多级页面时，显示close按钮；
            if (mWebView.canGoBack() && !isShowTitle) {
                title_close.setVisibility(View.VISIBLE);
            } else {
                title_close.setVisibility(View.GONE);
            }

        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            // LogUtils.v(TAG, "------------------------------------------onProgressChanged, newProgress=" + newProgress);
            if (100 == newProgress || 0 == newProgress) {
                loaded = true;
                mProgressBar.setVisibility(View.GONE);
                mProcessingLayout.setVisibility(View.GONE);
            } else {
                loaded = false;
                if (newProgress >= 40) {
                    mProcessingLayout.setVisibility(View.GONE);
                } else {
                    mProcessingLayout.setVisibility(View.VISIBLE);
                }
                mProgressBar.setVisibility(View.VISIBLE);
                mProgressBar.setProgress(newProgress);
            }
            // 仅处理第一个链接
            if(mCurrentProgress != 100) {
                mCurrentProgress = newProgress;
                if(mCurrentProgress == 100 && !mPrivPressBack) {
                    long costTime = System.currentTimeMillis() - mStartTime;
                    LogUtils.d(H5TAG,"cost time = "+costTime);
                    String errorDesc = "";
                    TRAnalysticsUtil.trackWebResponse(1, mType, "100",costTime,view.getUrl(),mFromPage,errorDesc);
                }
            }



            //onPageFinished方法回调的太早，放到这里
            if (100 == newProgress) {
                if (isError) {
                    showErrorTipsLayer();
                } else {
                    hideErrorTipsLayer();
                }
            }
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            if (!TextUtils.isEmpty(message) && message.startsWith(JS_CODE)) {
                String temp = message.substring(JS_CODE.length());
                if (!"T".equalsIgnoreCase(temp)) {
                    processBackEvent(KEY_BACK);
                }
                result.cancel();
                return true;
            }

            return super.onJsAlert(view, url, message, result);
        }
    };

    public void saveH5ActionCallBack(String pkgName, JsParamsBean jsParamsBean){
        if(TextUtils.isEmpty(pkgName) || jsParamsBean == null){
            return;
        }
        if(mInstallActionCallMap == null) {
            mInstallActionCallMap = new HashMap<>();
        }
        mInstallActionCallMap.put(pkgName,jsParamsBean);

    }

    public void updateDownloadProgress(String progressCallback,FileDownloadInfo fileDownloadInfo){
        try {
            JSONObject json = new JSONObject();
            json.put("packageName", fileDownloadInfo.packageName);
            json.put("downloadedSize",fileDownloadInfo.downloadedSize);
            json.put("totalSize",fileDownloadInfo.sourceSize);

            LogUtils.d(H5TAG, "updateDownloadProgress: " + json);
           callJsFunc(progressCallback,json.toString());
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private void callJsFunc(String callback, String params){
        mTaskHandler.post(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    mWebView.evaluateJavascript(buildCallJsStr(callback,params), null);
                } else {
                    mWebView.loadUrl(buildCallJsStr(callback,params));
                }
            }
        });
    }

    private String buildCallJsStr(String callbackName, String result) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("javascript:");
        stringBuilder.append(callbackName);
        stringBuilder.append("('");
        stringBuilder.append(result);
        stringBuilder.append("');");
        return stringBuilder.toString();
    }

    private InterfaceStatusChange mInterfaceStatusChange = new InterfaceStatusChangeImpl(new InterfaceStatusChangeImpl.InterfaceStatusChangeListener() {

        @Override
        public void onProgressChanged(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {
            LogUtils.d(H5TAG, mInstallActionCallMap + "onProgressChanged: " + downloadInfo + " ; downloadedBytes = " + downloadedBytes  + "  downloadedBytes = " + fileLength + "  speed= " + speed);
            if (downloadInfo != null) {
                if (mInstallActionCallMap != null && mInstallActionCallMap.containsKey(downloadInfo.packageName)){
                    JsParamsBean jsParamsBean = mInstallActionCallMap.get(downloadInfo.packageName);
                    if (jsParamsBean != null && !TextUtils.isEmpty(jsParamsBean.progressCallback)){
                        updateDownloadProgress(jsParamsBean.progressCallback, downloadInfo);
                    }
                }
            }
        }

        @Override
        public void onPackageChange(String packageName, int versionCode, boolean isAdded) {
            LogUtils.d(H5TAG, mInstallActionCallMap + "onPackageChange: packageName = " + packageName + " versionCode = " + versionCode + " isAdded = " + isAdded);

            //安装成功后 埋点
            if (isAdded) {
                if (mInstallActionCallMap != null && mInstallActionCallMap.containsKey(packageName)){
                    JsParamsBean jsParamsBean = mInstallActionCallMap.get(packageName);
                    mInstallActionCallMap.remove(packageName);

                    if (jsParamsBean != null) {
                        try {
                            JSONObject jsonParams = new JSONObject(jsParamsBean.params);
                            int version = jsonParams.optInt("version",-1);

                            LogUtils.d(H5TAG, "onPackageChange: packageName = " + packageName +  " version = " + version);
                            if (!TextUtils.isEmpty(jsParamsBean.callback) && (version == -1 || versionCode == version)) {
                                callJsFunc(jsParamsBean.callback,"");
                            }
                        } catch (Exception e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }

                    }
                }
            }

            setUpdatedAppCount();
        }

        @Override
        public void onDataSetChanged(FileDownloadInfo downloadInfo, int state) {
            if (downloadInfo != null && mWebView != null) {
                int observerStatus = DownloadStatusManager.getInstance().getDownloadStatus(downloadInfo);
                //mWebView.loadUrl("javascript:onStatusChangeListener('" + downloadInfo.itemID + "'," + "'" + observerStatus + "')");
                //mWebView.loadUrl("javascript:onDownloadStatusChangeListener('" + downloadInfo.packageName + "'," + "'" + observerStatus + "')");
                if(observerStatus == FileDownloadInfo.STATUS_DOWNLOADED ||
                    observerStatus == FileDownloadInfo.STATUS_INSTALLING ||
                    state == InterfaceStatusChange.LISTENER_Download_Complete) {
                    // todo list 查询 taskid
                    String pkg = downloadInfo.packageName;
                    H5TaskInfo info = PalmplayApplication.getAppInstance()
                            .getAppDataManager().updateH5TaskForPkg(pkg);
                    if(info == null) {
                        return;
                    }
                    info.state = 1;
                    String roundId = ""+ PalmplayApplication.getAppInstance().getAppDataManager().getTaskRoundId();
                    String taskId = info.id+"";
                    if(TextUtils.equals("0",roundId)){
                        return;
                    }
                    String callBack = "javascript:h5UpdateTaskStatus('"+ roundId +","+ taskId + "')";
                    mWebView.evaluateJavascript(callBack,
                            new ValueCallback<String>() {
                                @Override
                                public void onReceiveValue(String s) {

                                }
                            });

                    if(BuildConfig.DEBUG) {
                        LogUtils.d(H5TAG,"state = "+state+" pkg = "+pkg);
                    }
                }

            }
            setUpdatedAppCount();
        }
    });


    public class ShowTitleRunnable implements Runnable{
        boolean show;

        public ShowTitleRunnable(boolean show){
            this.show = show;
        }

        @Override
        public void run() {
            if(main_toolbar != null){
                main_toolbar.setVisibility(show ? View.VISIBLE : View.GONE);
//                main_toolbar.postInvalidate();
            }
        }
    }

    private Dialog checkingDialog;

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        if (mEventMainThreadEntity.getAction().equals(NetworkActions.ACTION_ONLINE_CHECK_VERSION + WebViewActivity.class.getSimpleName())){
            //用户通过侧滑菜单栏主动发起的检查更新到这里
            if(!isOnResume){
                return;
            }

            if (null != checkingDialog && checkingDialog.isShowing()) {
                checkingDialog.dismiss();
            }

            ClientVersion clientVersion = PalmPlayVersionManager.getInstance().getNewClientVersionInfo();
            if (null != clientVersion ) {
                if(clientVersion.updateType == ClientVersion.UPDATE_TYPE_SILENT || clientVersion.updateType == ClientVersion.UPDATE_TYPE_NOT_FORCE){
                    NewVersionTipActivity.into(WebViewActivity.this, false, mPageParamInfo);
                }else if(clientVersion.updateType == ClientVersion.UPDATE_TYPE_FORCE){
                    AtyManager.getAtyManager().popAllActivityExceptOne(MainActivity.class);
                    try {
                        startActivityForResult(new Intent(PalmplayApplication.getAppInstance(), ForceUpgradeActivity.class), requestCode_ForceUpgrade);
                    } catch (Exception ignored) {
                    }
                }else {
                    ToastManager.getInstance().showS(WebViewActivity.this, R.string.text_update_latest_versionstatus);
                }
            } else if (!mEventMainThreadEntity.isSuccess) {
                ToastManager.getInstance().showS(WebViewActivity.this, R.string.tip_no_network);
            } else {
                ToastManager.getInstance().showS(WebViewActivity.this, R.string.text_update_latest_versionstatus);
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_REFRESH_TAB_RED_POINT)) { //刷新角标
            setUpdatedAppCount();
        }
    }

    public class JSKit {

        @JavascriptInterface
        public int getFileDownloadInfo(String itemId, String name, String packageName, String version, String detailType) {
            return CommonUtils.queryDownloadStatus(itemId, name, packageName, version, detailType);
        }

        @JavascriptInterface
        public void startDownloading(final String iconUrl, final String itemId, final String name, final String packageName, final String version, final String detailType, final int status, final String fromPage) {
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl) && !isFbRequest(currentUrl)) {
                PageParamInfo pageParamInfo = PageConstants.deliverPageParamInfo(mPageParamInfo, mReSourceUrl);
                CommonUtils.startDownloadingForWebView(WebViewActivity.this, mWebView, iconUrl, pageParamInfo, itemId, name, packageName, version, detailType, status, fromPage);
            }
        }

        /**
         * 老版本用
         * @param itemId
         * @param name
         * @param packageName
         * @param version
         * @param detailType
         * @param status
         */
        @JavascriptInterface
        public void startDownloading(final String itemId, final String name, final String packageName, final String version, final String detailType, final int status) {
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl) && !isFbRequest(currentUrl)) {
                PageParamInfo pageParamInfo = PageConstants.deliverPageParamInfo(mPageParamInfo, mReSourceUrl);
                CommonUtils.startDownloadingForWebView(WebViewActivity.this, mWebView, "", pageParamInfo, itemId, name, packageName, version, detailType, status, "webview");
            }
        }

        /**
         * 新版本用
         * @param iconUrl
         * @param itemId
         * @param name
         * @param packageName
         * @param version
         * @param detailType
         * @param status
         */
        @JavascriptInterface
        public void startDownloading(final String iconUrl, final String itemId, final String name, final String packageName, final String version, final String detailType, final int status) {
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl) && !isFbRequest(currentUrl)) {
                PageParamInfo pageParamInfo = PageConstants.deliverPageParamInfo(mPageParamInfo, mReSourceUrl);
                CommonUtils.startDownloadingForWebView(WebViewActivity.this, mWebView, iconUrl, pageParamInfo, itemId, name, packageName, version, detailType, status, "webview");
            }
        }

        @JavascriptInterface
        public void startDownloading(String params) {
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl) && !isFbRequest(currentUrl)) {
                try {
                    Gson gson = new Gson();
                    JsParamsBean jsParamsBean = gson.fromJson(params, new TypeToken<JsParamsBean>() {}.getType());

                    LogUtils.d(H5TAG, "startDownloading " + params);

                    if (jsParamsBean == null) {
                        return;
                    }

                    JSONObject jsonParams = new JSONObject(jsParamsBean.params);

                    if (jsonParams != null) {
                        String curPage = jsonParams.optString("curPage");
                        String lastPage = jsonParams.optString("lastPage");
                        String url = jsonParams.optString("url");

                        String iconUrl = jsonParams.optString("iconUrl", "");
                        String itemId = jsonParams.optString("itemID");
                        String name = jsonParams.optString("name");
                        String packageName = jsonParams.optString("packageName");
                        String version = jsonParams.optString("version");
                        String detailType = jsonParams.optString("detailType");
                        String fromPage = jsonParams.optString("fromPage", "webview");
                        int isOffer = jsonParams.optInt("isOffer", 0);
                        int status = jsonParams.optInt("status");

                        PageParamInfo pageParamInfo = PageConstants.deliverPageParamInfo(new PageParamInfo(lastPage, curPage), url);
                        CommonUtils.startDownloadingForWebView(PalmplayApplication.getAppInstance(), null, iconUrl, pageParamInfo, itemId, name, packageName, version, detailType, status, fromPage, isOffer);

                        if (jsParamsBean.needFollowUpAction()) {
                            saveH5ActionCallBack(packageName, jsParamsBean);
                        }

                        if (jsParamsBean.needAthenaTrack && H5_SCENE_MONEY_LOAN.equals(fromPage)) {
                            LogUtils.d(H5TAG, "trackH5RequestInstallApp fromPage = " + fromPage);
                            TRAnalysticsUtil.trackH5RequestInstallApp(packageName);
                        }
                    }

                } catch (JSONException e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }

        @JavascriptInterface
        public void jumpToH5Page(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    Intent intent = new Intent(WebViewActivity.this, WebViewActivity.class);
                    intent.putExtra("WebSite", url);
                    intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, PageConstants.getLastPageStr(mPageParamInfo));
                    intent.putExtra(PageConstants.PAGE_KEY_CURPAGE, PageConstants.getCurPageStr(mPageParamInfo));
                    startActivity(intent);
                }

            });

        }

        @JavascriptInterface
        public void finishWebActivity() {
            finish();
        }

        @JavascriptInterface
        public void openNativeBrowser(final String url) {
            if (TextUtils.isEmpty(url))
                return;

            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    Uri uri = Uri.parse(url);
                    intent.setData(uri);
                    startActivity(intent);
                }

            });
        }

        @JavascriptInterface
        public void performWebViewGoBack() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mWebView.canGoBack()) {
                        mWebView.goBack();
//                    if (urlHistoryList.size() > 0) {
//                        urlHistoryList.remove(urlHistoryList.size() - 1);
//                    }
                    }
                }
            });
        }

        /**
         * 打开home页
         */
        @JavascriptInterface
        public void openHomeActivity() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                /*Intent mainIntent = new Intent(WebViewActivity.this, MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);*/
                    Activity mainActivity = AtyManager.getAtyManager().getActivity(MainActivity.class);
                    Intent mainIntent = new Intent(WebViewActivity.this, MainActivity.class);
                    mainIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    if (null != mainActivity) {
                        EventMainThreadEntity entity = new EventMainThreadEntity();
                        entity.setAction(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION);
                        entity.put(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION, NavTabInfo.HOME_KEY);
                        EventBus.getDefault().postSticky(entity);
                    } else {
                        mainIntent.putExtra(Constant.ACTION_LOCTION_MIANACTIVITY_POSTION, NavTabInfo.HOME_KEY);
                    }
                    startActivity(mainIntent);
                    finishWebActivity();
                }
            });

        }


        @JavascriptInterface
        public void onClickBack(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    processBackEvent(KEY_BACK);
                }
            });
        }

        @JavascriptInterface
        public String getInstalledApp(){
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl)) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<SimpleInstalledAppInfo>>(){}.getType();
                String jsonString = gson.toJson(InstalledAppManager.getSimpleInstalledAppInfo(), type);

                LogUtils.d(H5TAG,"getInstalledApp : " + jsonString);
                return jsonString;
            }
            return "";
        }

        @JavascriptInterface
        public String getAppDeviceInfo(){
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl)) {
                Gson gson = new Gson();
                Type type = new TypeToken<AppDeviceInfo>(){}.getType();
                String result = gson.toJson(PhoneDeviceInfo.getAppDeviceInfo(), type);
                LogUtils.d(H5TAG,"getAppDeviceInfo : " + result);
                return result;
            }
            return "";
        }

        @JavascriptInterface
        public void checkVersionUpdate(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    UpdateSelfUtil.cancelSilentUpdateDownload();
                    if (PalmPlayVersionManager.getInstance().isUpdating()) {

                        Intent startUpdateIntent = new Intent(WebViewActivity.this, UpdateService.class);
                        try {
                            WebViewActivity.this.startService(startUpdateIntent);
                        } catch (Exception e) {
                            LogUtils.d(e);
                        }

                        ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tips_downloading);
                    } else {
                        if (checkingDialog == null) {
                            checkingDialog = new Dialog(WebViewActivity.this, R.style.myDialogTheme);
                        }
                        if (checkingDialog.isShowing()) {
                            return;
                        }
                        checkingDialog.setContentView(R.layout.dialog_check_update_waitiing);
                        checkingDialog.show();
                        PadUtils.applyPadDialog(checkingDialog);
                        NetworkClient.checkClientVersionHttpRequest(NetworkActions.ACTION_ONLINE_CHECK_VERSION + WebViewActivity.class.getSimpleName());
                    }
                }
            });
        }

        /**
         * 打开App详情页；
         *
         * @param itemName
         * @param itemId
         * @param packageName
         * @param currentPage
         */
        @JavascriptInterface
        public void goToAppDetailPage(final String itemName, final String itemId, final String packageName, final String currentPage) {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    AppBuilder appBuilder = new AppBuilder()
                            .setAppName(itemName)
                            .setItemId(itemId)
                            .setPackageName(packageName)
                            .setFromPage(currentPage)
                            .setLastPage(currentPage)
                            .setUri(null)
                            .setValue("")
                            .setTaskId(0)
                            .setAutoDownload(false);
                    TRJumpUtil.switcToAppDetailOptions(WebViewActivity.this, appBuilder);
                }
            });
        }

        @JavascriptInterface
        public void launchSpecialActivity(String pkg, String className) {
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl)) {
                TRJumpUtil.jumpSpecialActivity(pkg,className);
            }
        }

        @JavascriptInterface
        public void showActivityTitle(boolean show) {
            runOnUiThread(new ShowTitleRunnable(show));
        }

        @JavascriptInterface
        public void launchCleanFile() {
            try{
                Intent intent = new Intent(PalmplayApplication.getAppInstance(), CleanNativeMemoryActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                isRefreshCeanTaskStatus = true;
                startActivity(intent);
            }catch (Exception e){
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        @JavascriptInterface
        public void launchFreeShare() {
            //todo 默认不移植 shuaiqing
            if (TRApplicationContextUtil.isProject()) {
                return;
            }
            try{
                Intent intent = new Intent(PalmplayApplication.getAppInstance(), TRReflectManager.getInstance().getDesClass(TRReflectConstants.P2P_MODEL, TRReflectConstants.P2P_MAIN_MODEL));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                isRefreshFreeshareStatus = true;
                startActivity(intent);
            }catch (Exception e){
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }



        @JavascriptInterface
        public void addTaskInfo(int roundId, int taskId, int type, String pkg) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().addH5Task(roundId,taskId,type,pkg);
            if(BuildConfig.DEBUG) {
                LogUtils.d(H5TAG,"addTaskInfo = "+ roundId + "taskid= "+taskId +" type="+type+" pkg="+pkg);
            }
        }

        @JavascriptInterface
        public String getTaskInfo(int roundId) {
            String jsonStr = PalmplayApplication.getAppInstance()
                    .getAppDataManager()
                    .queryH5TaskInfo(roundId);
            if(BuildConfig.DEBUG) {
                LogUtils.d(H5TAG,"getTaskInfo = "+ jsonStr);
            }
            if(TextUtils.isEmpty(jsonStr)) {
                jsonStr = "[]";
            }
            return jsonStr;
        }

        @JavascriptInterface
        public int getDownloadStatus(String itemId) {
            int status = 0;
            FileDownloadInfo info = DownloadManager.getInstance().getDownloadedInfoForH5(itemId);
            if(info!=null) {
                status = 1;
            }

            if(BuildConfig.DEBUG) {
                LogUtils.d(H5TAG,"itemId = "+ itemId +" status = "+status);
            }
            return status;
        }

        @JavascriptInterface
        public void startRecordTime(int roundId, int taskId, final int type, long gapTime) {
            if(mTaskHandler!=null && type > 0 && gapTime >= 1000) {
                mTaskHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        PalmplayApplication.getAppInstance()
                                .getAppDataManager()
                                .updateTaskInfo(type);
                        if(BuildConfig.DEBUG) {
                            LogUtils.d(H5TAG,"used time is ok");
                        }
                    }
                },gapTime);
            }
        }

        @JavascriptInterface
        public void stopRecordTime() {
            if(mTaskHandler!=null) {
                mTaskHandler.removeCallbacksAndMessages(null);
            }
        }

        /**
         * 返回Simo支持和开启状态以及Simo配置id 通过@拼接返回字串
         * @return
         */
        @JavascriptInterface
        public String getSimoSupportAndStatus() {
            return "";
        }
        /**
         * 根据包名启动第三方App
         * @param packageName
         */
        @JavascriptInterface
        public void launchOtherApp(String packageName) {
            String currentUrl = MMKVUtils.getMMKV().getString(Constant.KV_CURRENT_URL, "");
            LogUtils.d(H5TAG, "WebViewActivity startDownloading currentUrl:" + currentUrl);
            if (!TextUtils.isEmpty(currentUrl) && isHttpsRequest(currentUrl) && isCheckedDomain(currentUrl)) {
                try {
                    // "com.skyroam.app"
                    DownloadDecorator.launchApp(packageName, packageName);
                    trackClick(packageName);

                } catch (Exception e) {

                }
            }
        }

        /**
         * 兑换流量之后回调，通知客户端
         * @param availableTrafficSize -> 可领取流量，单位byte
         * */
        @JavascriptInterface
        public void onAvailableTrafficSizeNotify(final long availableTrafficSize) {

        }


        //TODO:for points
        /**
         * 返回手机的基本参数：语言，机型，品牌等
         * */
        @JavascriptInterface
        public String getDeviceArgumens(){
            return PointsManager.getInstance().getDeviceArguments();
        }

        /**
         * 签到接口 -> 类型为 1
         * */
        @JavascriptInterface
        public void onPointsCheckinHttpRequest() {
            NetworkClient.requestPointsCheckin(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    onPointsHttpCallback(1, response);

                    PointsManager.getInstance().setPointDataByCheckin(response);
                }

                @Override
                public void onError(ANError anError) {
                    onPointsHttpCallback(1, null);

                    PointsManager.getInstance().setPointDataByCheckin(null);
                }
            });
        }
        /**
         * 抽奖接口 -> 类型为 2
         * */
        @JavascriptInterface
        public void onPointsDrawHttpRequest() {
            NetworkClient.requestPointsDraw(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    onPointsHttpCallback(2, response);
                }

                @Override
                public void onError(ANError anError) {
                    onPointsHttpCallback(2, null);
                }
            });
        }

        /**
         * 查询中奖用户接口  -> 类型为 3
         * */
        @JavascriptInterface
        public void onPointsWinUserHttpRequest() {
            NetworkClient.requestPointsWinUser(false, new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    onPointsHttpCallback(3, response);
                }

                @Override
                public void onError(ANError anError) {
                    onPointsHttpCallback(3, null);
                }
            });
        }

        /**
         * 签到历史接口  -> 类型为 4
         * */
        @JavascriptInterface
        public void onPointsListHttpRequest() {
            NetworkClient.requestPointsList(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    onPointsHttpCallback(4, response);

                    PointsManager.getInstance().setPointDataByCheckinDetail(response);
                }

                @Override
                public void onError(ANError anError) {
                    onPointsHttpCallback(4, null);
                }
            });
        }

        /**
         * 查询用户积分接口  -> 类型为 5
         * */
        @JavascriptInterface
        public void onPointsQueryHttpRequest() {
            NetworkClient.requestPointsForUser(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    onPointsHttpCallback(5, response);

                    PointsManager.getInstance().setPointsDataByCheckInfo(response);
                }

                @Override
                public void onError(ANError anError) {
                    onPointsHttpCallback(5, null);
                }
            });
        }

        /**
         * 获取签到列表 & 总积分数
         * */
        @JavascriptInterface
        public String getPointsData() {
            String txt = PointsManager.getInstance().getPointsData();
            return txt;
        }

        /**
         * 请求结果回调
         * @param type  签到 1，  抽奖 2，  查询中奖用户 3， 签到列表 4
         * @param txt   返回结果的json字符串
         * */
        public void onPointsHttpCallback(int type, String txt) {
            if(mWebView != null) {
                mWebView.loadUrl("javascript:onJSPointsCallback('" + type + "','" + txt + "')");
            }
        }

        /**
         * 页面曝光埋点
         * */
        @JavascriptInterface
        public void onTrackPv() {
            String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_PAGE, TRAnalyticsConstant.MODULE_H5_CHECKIN, "", "");
            PagePvBuilder<?> pagePvBuilder = new PagePvBuilder<>();
            pagePvBuilder.setValue(value)
                    .setFrom(mFrom);
            TRAnalysticsUtil.trackPV(pagePvBuilder);
        }

        /**
         * 页面点击埋点
         * */
        @JavascriptInterface
        public void onTrackClick(String position) {
            String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_PAGE, TRAnalyticsConstant.MODULE_H5_CHECKIN, "", position);
            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType("")
                    .setItemId("")
                    .setButtonType(TRAnalyticsConstant.H5_CI_BUTTON)
                    .setItemValue("")
                    .setTaskId(0)
                    .setExpId(null)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);
        }

        @JavascriptInterface
        public void athenaTrack(String jsonParam){
            TRAnalysticsUtil.trackAthenaForH5(jsonParam);
        }
    }

    @JavascriptInterface
    public String getNetworkState(){
        String netState = com.transsion.palmstorecore.util.NetworkUtils.getNetworkState(PalmplayApplication.getAppInstance());
        LogUtils.d(LogUtils.TAG_XWEBVIEW_JSINTERFACE, "getNetworkState : " + netState);
        return netState;
    }

    @JavascriptInterface
    public void goWifiSettingPage(){
        LogUtils.d(H5TAG, "goWifiSettingPage");
        try {
            SystemUtils.openSystemMobileNetworkSettings(PalmplayApplication.getAppInstance());
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private void trackClick(String packageName) {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_PAGE, TRAnalyticsConstant.MODULE_H5_CHECKIN, "", "");
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.OPEN)
                .setItemValue(packageName)
                .setTaskId(0)
                .setExpId(null)
                .setExtraValue(DeeplinkManager.getDeeplink(packageName));
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public String getValue() {
        return "";
    }
}
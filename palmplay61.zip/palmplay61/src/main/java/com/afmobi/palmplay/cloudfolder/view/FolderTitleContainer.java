/*Transsion Top Secret*/
package com.afmobi.palmplay.cloudfolder.view;

import static com.afmobi.palmplay.cloudfolder.utils.CommonUtilsKt.dip2px;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.viewpager2.widget.ViewPager2;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile;
import com.afmobi.palmplay.cloudfolder.utils.PaletteControls;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;

public class FolderTitleContainer extends FrameLayout implements View.OnClickListener {

    private static final String TAG = "FolderTitleContainer";

    private final static boolean FOLDER_TITLE_DEBUG = BuildConfig.DEBUG;

    private static final float LEFT_AND_RIGHT_FADING_EDGE_STRENGTH = 0.7f;
    private View mFolderPageShade;

    private LinearLayout mTitles;
    ViewPager2 mFolderPage;

    private static String sDefaultFolderName;

    ArrayList<String> titles;

    private FolderTitleAdapter mFolderTitleAdapter;

    private int titleCount;

    //add by tao.xu2 for Palette_Controls
    private int titleNormalColor;
    private int titleHighlightColor;

    private int mFolderCellMarginStartEnd;

    private int mFolderTitleAddPadding;


    public FolderTitleContainer(Context context, AttributeSet attrs) {
        super(context, attrs);
        try{
            Resources res = context.getResources();
            if (sDefaultFolderName == null) {
                sDefaultFolderName = "";//res.getString(R.string.folder_name);
            }

            mFolderTitleAdapter = new FolderTitleAdapter(context);

            mFolderCellMarginStartEnd = DeviceProfile.Companion.getInstance().folderCellMarginStartEnd;
            mFolderTitleAddPadding = res.getDimensionPixelSize(R.dimen.folder_title_padding_add);

            setWillNotDraw(false);
            setHorizontalFadingEdgeEnabled(true);
            setFadingEdgeLength(getResources().getDimensionPixelSize(R.dimen.folder_fading_edge_length));
        }catch (Throwable e){
            LogUtils.e(TAG,"FolderTitleContainer create error  " + Log.getStackTraceString(e));
        }
    }

    public void setFolderPageShade(View folderPageShade) {
        mFolderPageShade = folderPageShade;
    }

    private int currentPage = 0;

    public void setFolderCore(ViewPager2 viewPager2) {
        mFolderPage = viewPager2;
        mFolderPage.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int page, float scrollPercent, int scrollPx) {
                FolderTitleContainer.this.onPageScrolled(page, scrollPercent, currentPage);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                currentPage = position;
                FolderTitleContainer.this.onPageSelected(position);
            }
        });
    }

    @Override
    protected void onFinishInflate() {
        mTitles =  findViewById(R.id.folder_titles);
        super.onFinishInflate();

        updatePalette();
    }

    private void changeTitleSizeAndColor(int index, int currentIndex, View v) {
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            // Pad 标题字号按设计稿使用 24dp，手机保持 18dp
            int titleSizeRes = DeviceProfile.getInstance().isPadLayout()
                    ? R.dimen.folder_title_text_size_pad
                    : R.dimen.folder_title_text_size;
            float titleSizePx = getContext().getResources().getDimension(titleSizeRes);
            tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, titleSizePx);
            tv.setTypeface(null, android.graphics.Typeface.NORMAL);
            if (index == currentIndex) {
                tv.setTextColor(titleHighlightColor);
            } else {
                tv.setTextColor(titleNormalColor);
            }
            tv.setHeight(getContext().getResources().getDimensionPixelSize(R.dimen.folder_title_area_height));
        }
    }

    private void setUpTitleView(ArrayList<String> titles, int currentIndex) {
        this.titles = titles;
        mFolderTitleAdapter.setFolderTitles(titles);
        titleCount = mFolderTitleAdapter.getCount();
        ArrayList<View> titleViews = new ArrayList<>();
        for (int i = 0; i < titleCount; i++) {
            View titleView = mFolderTitleAdapter.getView(i,
                    mTitles.getChildAt(i), null);
            titleViews.add(titleView);
        }
        mTitles.removeAllViews();
        mTitles.setTranslationX(0);
        int index = 0;
        for (View v : titleViews) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            lp.gravity = Gravity.CENTER_VERTICAL;
            if (index > 0) {
                lp.leftMargin = dip2px(27f);
            }
            changeTitleSizeAndColor(index, currentIndex, v);
            mTitles.addView(v, index++, lp);
        }
        mTitles.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.EXACTLY);
    }

    public void setSecondTitleIVisible(boolean visible) {
        int childCount = mTitles.getChildCount();
        if (childCount >= 2) {
            if (visible) {
                for (int i = 0; i < childCount; i++) {
                    View child = mTitles.getChildAt(i);
                    if (child.getVisibility() != View.VISIBLE) {
                        child.setVisibility(View.VISIBLE);
                    }
                }
            } else {
                for (int i = 1; i < childCount; i++) {
                    View child = mTitles.getChildAt(i);
                    if (child.getVisibility() != View.INVISIBLE) {
                        child.setVisibility(View.INVISIBLE);
                    }
                }
            }
        }
    }

    public void setCurrentTitleVisible(int index) {
        for (int i = 0; i < mTitles.getChildCount(); i++) {
            mTitles.getChildAt(i).setVisibility(i == index ? VISIBLE : INVISIBLE);
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        if (titles != null) {
            int titleWidth = titles.size() * getContext().getResources().getDisplayMetrics().widthPixels / 2;
            int titleMeasureSpec = MeasureSpec.makeMeasureSpec(titleWidth,
                    MeasureSpec.UNSPECIFIED);
            if (titleWidth > width) {
                mTitles.measure(titleMeasureSpec, heightMeasureSpec);
            } else {
                mTitles.measure(MeasureSpec.makeMeasureSpec(getContext().getResources().getDisplayMetrics().widthPixels,
                        MeasureSpec.EXACTLY), heightMeasureSpec);
            }
        }
    }

    public void onPageScrolled(int page, float scrollPercent, int currentPage) {
        if (mTitles.getChildCount() == 0) return;
        int currentTranslation = getPageTranslationX(currentPage);//(-currentPage + 1) * mTitleWidth;
        int desTranslation = 0;
        float percent = 0f;
        int nextPage = 0;
        if (page < currentPage) {
            nextPage = page;
            desTranslation = getPageTranslationX(nextPage);//(-page + 1) * mTitleWidth;
            percent = 1 - scrollPercent;
        } else if (page == currentPage) {
            nextPage = currentPage + 1;
            desTranslation = getPageTranslationX(Math.min(nextPage, titles.size() - 1));//(-currentPage + 2) * mTitleWidth;
            percent = scrollPercent;
        }
        int translationOffset = desTranslation - currentTranslation;

        if (FOLDER_TITLE_DEBUG) {
            LogUtils.d("FOLDER_TITLE_DEBUG onPageScrolled translationOffset : " + translationOffset);
        }

        mTitles.setTranslationX(currentTranslation + translationOffset * percent);
        if (page == currentPage) { //for title scale
            percent = -percent;
        }
        TextView textView;
        View child = mTitles.getChildAt(currentPage);
        if (child != null && child instanceof TextView) {
            textView = (TextView) child;
        }
        child = mTitles.getChildAt(nextPage);
        if (child != null && child instanceof TextView) {
            textView = (TextView) child;
        }
    }

    public void onPageSelected(int position) {
        for (int i = 0; i < titleCount; i++) {
            changeTitleSizeAndColor(i, position, mTitles.getChildAt(i));
        }
    }

    public void updatePalette() {
        titleHighlightColor = Color.parseColor("#FFFFFF");
        titleNormalColor = Color.parseColor("#80FFFFFF");
    }

    class FolderTitleAdapter extends BaseAdapter {
        private final Context context;
        ArrayList<String> titles;

        public FolderTitleAdapter(Context context) {
            this.context = context;
        }

        void setFolderTitles(ArrayList<String> titles) {
            this.titles = titles;
        }

        @Override
        public int getCount() {
            if (titles != null) {
                return titles.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return titles != null ? titles.get(position) : null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TitleHolder mTitleHolder;
            View view = convertView;
            if (view == null) {
                TextView mTitleView = (TextView) LayoutInflater.from(context)
                        .inflate(R.layout.cloud_folder_title, null);
                mTitleHolder = new TitleHolder();
                PaletteControls.getInstance(PalmplayApplication.getAppInstance()).updateTextShadow(mTitleView);
                mTitleHolder.mTitleView = mTitleView;
                view = mTitleView;
                view.setTag(mTitleHolder);
                view.setPadding(0, view.getPaddingTop(), 0, view.getPaddingBottom());
            } else {
                mTitleHolder = (TitleHolder) convertView.getTag();
            }

            CharSequence title = (CharSequence) getItem(position);
            if (title != null) {
                mTitleHolder.mTitleView.setText(title);
            } else {
                mTitleHolder.mTitleView.setText("");
            }
            mTitleHolder.position = position;
            mTitleHolder.mTitleView
                    .setOnClickListener(FolderTitleContainer.this);
            return view;
        }
    }

    class TitleHolder {
        TextView mTitleView;
        int position;
    }

    public void setCurrentItem(int page, boolean smoothScroll) {
        int translationX = getPageTranslationX(page);//(-page + 1) * mTitleWidth;
        if (smoothScroll) {
            mTitles.animate().translationX(translationX).start();
        } else {
            mTitles.setTranslationX(translationX);
        }
        // nieweiqi add 2016-01-19 below
        titleCount = mFolderTitleAdapter.getCount();

        for (int i = 0; i < titleCount; i++) {
            changeTitleSizeAndColor(i, page, mTitles.getChildAt(i));
        }
    }

    public void updateCellMarginStartEnd(int marginStartEnd) {
        mFolderCellMarginStartEnd = marginStartEnd;
    }

    private int getPageTranslationX(int page) {
        return 0;
    }

    public void updateTitles(ArrayList<String> titles, int currentIndex) {
        this.titles = titles;
        LogUtils.i("<updateTitles titles:" + titles + "index: " + currentIndex);
        setUpTitleView(titles, currentIndex);
        currentPage = currentIndex;
    }

    @Override
    public void onClick(View v) {
        LogUtils.i(">FolderTitleContainer--onClick v :" + v);
        TitleHolder mTitleHolder = (TitleHolder) v.getTag();
        int position = mTitleHolder.position;
        mFolderPage.setCurrentItem(position);
    }

    @Override
    protected float getLeftFadingEdgeStrength() {
        return 0.0f;
    }

    @Override
    protected float getRightFadingEdgeStrength() {
        return LEFT_AND_RIGHT_FADING_EDGE_STRENGTH;
    }

    @Override
    public int getSolidColor() {
        return Color.TRANSPARENT;
    }

}

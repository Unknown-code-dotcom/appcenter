package com.afmobi.palmplay.activate

import com.afmobi.palmplay.cache.widgetprocess.DeskWidgetProcessor
import com.afmobi.palmplay.dialog.TRDialogUtil

class TRWidgetGuideExecutor:TRBaseExecutor<Any>() {

    override fun isCanShow(fromType: String?): Boolean {
        return DeskWidgetProcessor.isCanShowDeskWidget()
    }

    override fun show(fromType: String?): Boolean {
        if (TRDialogUtil.hasDialogShowing()) { //真正show的时候判断是否已有弹框先于自己展现了。
            return false
        }
        DeskWidgetProcessor.showDialog()
        return true
    }
}
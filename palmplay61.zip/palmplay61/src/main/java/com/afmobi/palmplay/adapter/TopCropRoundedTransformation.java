package com.afmobi.palmplay.adapter;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

import androidx.annotation.NonNull;

import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation;

import java.security.MessageDigest;

/**
 * Glide 自定义 Transformation：
 * 将原始图片等比缩放至目标宽度（顶部对齐），输出 bitmap 固定为 targetWidth × targetHeight。
 * 超出部分由 RecyclerView clipChildren=true 裁切。
 *
 * topCornersOnly=true：只对左上、右上两角圆角（竖图场景，底部已被 clip，不画底部圆角）。
 * topCornersOnly=false：四角均圆角（横图/视频封面场景，底部圆角在可视区内）。
 */
public class TopCropRoundedTransformation extends BitmapTransformation {

    private static final String ID = "com.afmobi.palmplay.adapter.TopCropRoundedTransformation.v3";

    private final int mTargetWidth;
    private final int mTargetHeight;
    private final int mCornerRadius;
    private final boolean mTopCornersOnly;

    public TopCropRoundedTransformation(int targetWidth, int targetHeight,
                                        int cornerRadius, boolean topCornersOnly) {
        mTargetWidth = targetWidth;
        mTargetHeight = targetHeight;
        mCornerRadius = cornerRadius;
        mTopCornersOnly = topCornersOnly;
    }

    @Override
    protected Bitmap transform(@NonNull BitmapPool pool, @NonNull Bitmap toTransform,
                               int outWidth, int outHeight) {
        int srcW = toTransform.getWidth();
        int srcH = toTransform.getHeight();
        if (srcW <= 0 || srcH <= 0) return toTransform;

        float scale = mTargetWidth / (float) srcW;
        int scaledH = Math.max(1, Math.round(srcH * scale));
        int drawH = Math.min(scaledH, mTargetHeight);

        Bitmap result = pool.get(mTargetWidth, mTargetHeight, Bitmap.Config.ARGB_8888);
        result.setHasAlpha(true);

        Canvas canvas = new Canvas(result);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        BitmapShader shader = new BitmapShader(toTransform, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        Matrix shaderMatrix = new Matrix();
        shaderMatrix.setScale(scale, scale);
        shader.setLocalMatrix(shaderMatrix);
        paint.setShader(shader);

        if (mTopCornersOnly) {
            // 只裁切左上、右上圆角：底部两角保持直角
            float r = mCornerRadius;
            Path path = new Path();
            path.moveTo(0, drawH);                        // 左下直角
            path.lineTo(0, r);
            path.quadTo(0, 0, r, 0);                     // 左上圆角
            path.lineTo(mTargetWidth - r, 0);
            path.quadTo(mTargetWidth, 0, mTargetWidth, r); // 右上圆角
            path.lineTo(mTargetWidth, drawH);             // 右下直角
            path.close();
            canvas.drawPath(path, paint);
        } else {
            canvas.drawRoundRect(new RectF(0, 0, mTargetWidth, drawH),
                    mCornerRadius, mCornerRadius, paint);
        }

        return result;
    }

    @Override
    public void updateDiskCacheKey(@NonNull MessageDigest messageDigest) {
        messageDigest.update((ID + "_" + mTargetWidth + "_" + mTargetHeight
                + "_" + mCornerRadius + "_" + mTopCornersOnly).getBytes());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TopCropRoundedTransformation)) return false;
        TopCropRoundedTransformation that = (TopCropRoundedTransformation) o;
        return mTargetWidth == that.mTargetWidth
                && mTargetHeight == that.mTargetHeight
                && mCornerRadius == that.mCornerRadius
                && mTopCornersOnly == that.mTopCornersOnly;
    }

    @Override
    public int hashCode() {
        int result = ID.hashCode();
        result = 31 * result + mTargetWidth;
        result = 31 * result + mTargetHeight;
        result = 31 * result + mCornerRadius;
        result = 31 * result + (mTopCornersOnly ? 1 : 0);
        return result;
    }
}

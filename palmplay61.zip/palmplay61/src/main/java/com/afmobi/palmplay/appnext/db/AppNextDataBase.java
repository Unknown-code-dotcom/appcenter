package com.afmobi.palmplay.appnext.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 15:02
 * @Desc: add your description
 */

@Database(entities = {AppNextCache.class}, version = 1)
public abstract class AppNextDataBase extends RoomDatabase {

    private static AppNextDataBase sInstance;
    private static final String DB_NAME = "Cache_.db";

    public static AppNextDataBase getDatabase(Context context) {
        if (sInstance == null) {
            synchronized (AppNextDataBase.class) {
                sInstance = Room.databaseBuilder(context.getApplicationContext(),
                        AppNextDataBase.class, DB_NAME)
                        .setJournalMode(RoomDatabase.JournalMode.TRUNCATE)
                        .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build();
            }
        }
        return sInstance;
    }

    public abstract AppNextCacheDao getAppNextCacheDao();
}

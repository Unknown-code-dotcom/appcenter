package com.afmobi.palmplay.appmanage.holder;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

import com.afmobi.palmplay.appmanage.ManageDownloadedActivity;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * installed模块中的more apps；
 */
public class InstalledSeeMoreViewHolder extends RecyclerView.ViewHolder {
    private Context mContext;
    private PageParamInfo mPageParamInfo;
    /**
     * 新型打点的from值
     */
    public String mFrom;
    protected String mScreenPageName;
    protected String mFeatureName;
    private LinearLayout containerView;

    public InstalledSeeMoreViewHolder(@NonNull View itemView) {
        super(itemView);
        containerView = itemView.findViewById(R.id.ll_see_more_app);
    }

    public InstalledSeeMoreViewHolder bind() {
        containerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ManageDownloadedActivity.class);
                PageConstants.putPageParamInfo(intent, mPageParamInfo);
                mContext.startActivity(intent);

                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "0", "0");
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId("")
                        .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                        .setItemId("")
                        .setButtonType(TRAnalyticsConstant.MORE_TYPE)
                        .setItemValue("")
                        .setExtraValue("");
                TRAnalysticsUtil.trackClick(builder);
            }
        });
        return this;
    }


    public InstalledSeeMoreViewHolder setContext(Context context) {
        mContext = context;
        return this;
    }

    public InstalledSeeMoreViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        mPageParamInfo = pageParamInfo;
        return this;
    }

    public InstalledSeeMoreViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public InstalledSeeMoreViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    public InstalledSeeMoreViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }

}

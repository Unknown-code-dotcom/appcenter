package com.afmobi.palmplay.activitycenter;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.main.dialog.TipNetworkDialog;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.main.v6_7.NetworkChangeListener;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.mvvm.BaseActivity;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.didi.drouter.annotation.Router;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.trans.common.netstate.AppNetState;
import com.trans.common.netstate.NetTypeKt;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BR;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ActivityActivityCenterBinding;

import java.util.List;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

@Router(path = "/page/activityCenter")
public class TRActivityCenterActivity extends BaseActivity<ActivityActivityCenterBinding, TRActivityCenterViewModel> {

    private TRActivityCenterViewModel viewModel;
    ActivityActivityCenterBinding activityCenterBinding;
    TRActivityCenterAdapter mAdapter;
    private String fromPage;
    private String mFrom;
    private PageParamInfo mPageParamInfo = new PageParamInfo();

    protected UILoadingGifUtil mLoadingUi = UILoadingGifUtil.create();
    protected UINetworkErrorUtil mNetworkErrorUi = UINetworkErrorUtil.create();

    @Override
    public String getValue() {
        return TRStringUtil.generateString(TRAnalyticsConstant.PAGE_ACTIVITY_CENTER, "", "", "");
    }

    @Override
    public int getBindingVariable() {
        return BR.vm;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_activity_center;
    }

    @Override
    public TRActivityCenterViewModel getViewModel() {
        viewModel = new ViewModelProvider(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(TRActivityCenterViewModel.class);
        viewModel.setNavigator(this);
        getLifecycle().addObserver(viewModel);
        return viewModel;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityCenterBinding = getViewDataBinding();
        if (getIntent() != null) {
            fromPage = getIntent().getStringExtra(PageConstants.PAGE_KEY_LASTPAGE);
            mFrom = getIntent().getStringExtra(TRAnalyticsConstant.VALUE);
        }
        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.Activity_Center);
        mPageParamInfo.setLastPage(fromPage);

        initView();
        loadData();
        createNetView();
        PagePvBuilder<?> pagePvBuilder = new PagePvBuilder<>();
        pagePvBuilder.setValue(getValue())
                .setFromPage(fromPage)
                .setFrom(mFrom);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private void createNetView() {
        mNetworkErrorUi.inflate(this, (ViewGroup) activityCenterBinding.getRoot(), true)
                .setFrom(mFrom)
                .setVisibility(View.GONE)
                .setNetworkConfigureVisibility(View.GONE)
                .setUINetworkErrorOnClickListener(new UINetworkErrorUtil.UINetworkErrorOnClickListener() {

                    @Override
                    public void onUINetworkErrorClick(View v) {
                        if (v == null)
                            return;
                        if (v.getId() == R.id.tv_retry) {
                            if (CommonUtils.isInstantAvailable()) {
                                TRJumpUtil.jumpInstantTab(TRActivityCenterActivity.this);
                            } else {
                                mNetworkErrorUi.setVisibility(View.GONE);
                                mLoadingUi.setVisibility(View.VISIBLE);
                                viewModel.refresh();
                            }
                        } else if (v.getId() == R.id.tv_setting) {
                            SysUtils.openSystemMobileNetworkSettings(TRActivityCenterActivity.this, TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
                        }
                    }
                });


        //监听网络波动，判断是否需要刷新数据
        AppNetState.INSTANCE.getNetType().observe(this, netType -> {
            onNetChange(NetTypeKt.connected(netType));
        });
    }

    private void onNetChange(boolean isConnected) {
        if (isConnected) {
            if (mNetworkErrorUi.getVisibility() == View.VISIBLE) {
                mNetworkErrorUi.setVisibility(View.GONE);
                mLoadingUi.setVisibility(View.VISIBLE);
                viewModel.refresh();
            }
            onTipNetworkDialogDismiss();
        } else {
            if (mAdapter!=null) {
                List<ACBean> mList = mAdapter.getAcBeanList();

                if (mList == null || mList.isEmpty()) {
                    mNetworkErrorUi.setVisibility(View.VISIBLE);
                } else {
                    TipNetworkDialog.setDialog(TRActivityCenterActivity.this, false);
                    onTipNetworkDialogShow();
                }
            }
        }
    }

    private void initView() {
        mLoadingUi.inflate(this, (ViewGroup) activityCenterBinding.getRoot()).setVisibility(View.VISIBLE);



        TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        activityCenterBinding.xrecyclerview.setLayoutManager(linearLayoutManager);
        activityCenterBinding.xrecyclerview.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
        activityCenterBinding.xrecyclerview.setPullRefreshEnabled(true);
        activityCenterBinding.xrecyclerview.isHeaderRefreshLayoutLimitHeight(true);
        activityCenterBinding.xrecyclerview.setLoadingMoreEnabled(true);


        mAdapter = new TRActivityCenterAdapter(this, null);
        activityCenterBinding.xrecyclerview.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                viewModel.refresh();
            }

            @Override
            public void onLoadMore() {
                viewModel.loadMore();

            }
        });
        mAdapter.setFrom(mFrom);
        mAdapter.setFromPage(fromPage);
        mAdapter.setPageParamInfo(mPageParamInfo);
        mAdapter.setValue(getValue());
        mAdapter.setScreenPageName(TRAnalyticsConstant.PAGE_ACTIVITY_CENTER);

        activityCenterBinding.xrecyclerview.setAdapter(mAdapter);
        activityCenterBinding.btnTitleBack.setOnClickListener(v ->
                {
                    ComponentClickBuilder builder = new ComponentClickBuilder();
                    builder.setValue(getValue())
                            .setFrom(mFrom)
                            .setTopicType("")
                            .setTopicId("")
                            .setItemType("")
                            .setItemId("")
                            .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                            .setItemValue("");
                    TRAnalysticsUtil.trackClick(builder);
                    onBackPressed();
                }
        );

        viewModel.getLiveData().observe(this, mlist ->
            onDataReceived(mlist)
        );
    }

    private void loadData() {
        viewModel.loadAdData(false);
    }

    private void onDataReceived(List<ACBean> list) {

        if(TRStringUtil.listIsEmpty(list)){
            if (NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                activityCenterBinding.includeEmptyView.layoutEmptyViewRoot.setVisibility(View.VISIBLE);
            }
        }else {
            mAdapter.setData(list);
            activityCenterBinding.includeEmptyView.layoutEmptyViewRoot.setVisibility(View.GONE);
            if(list.size()>0){
                activityCenterBinding.xrecyclerview.setNoMore(viewModel.isPageLast());
            }
        }
        refreshUI();

    }

    protected void refreshUI() {
        setState();
        switchNetworkErrorLayoutVisibility();
    }

    private void switchNetworkErrorLayoutVisibility() {
        if (viewModel == null) {
            return;
        }
        if (viewModel.isRequesting()) {
            if (!viewModel.isNotEmptyDataList()) {
                mLoadingUi.setVisibility(View.VISIBLE);
            }
            onTipNetworkDialogDismiss();
        } else {
            if (!viewModel.hasRequest||!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                if (mAdapter!=null) {
                    List<ACBean> mList = mAdapter.getAcBeanList();

                    if (mList == null || mList.isEmpty()) {
                        mNetworkErrorUi.setVisibility(View.VISIBLE);
                    } else {
                        onTipNetworkDialogShow();
                    }
                }

            } else {
                onTipNetworkDialogDismiss();
                mNetworkErrorUi.setVisibility(View.GONE);
            }
        }
    }

    protected void setState() {
        if (viewModel != null && !viewModel.isRequesting()) {
            mLoadingUi.setVisibility(View.GONE);
            if (viewModel.isOnRefreshing()) {
                activityCenterBinding.xrecyclerview.refreshComplete();
            } else {
                activityCenterBinding.xrecyclerview.loadMoreComplete();
            }
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}

package com.afmobi.palmplay.cloudfolder.view

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import com.afmobi.palmplay.cloudfolder.utils.getSafeString
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.util.DisplayUtil
import com.transsnet.store.R

class CloudClickPopupWindow(private val mContext: Context, appInfo: AppInfo?, private val position: Int) : PopupWindow(
    mContext
) {
    private var mItemOnClikcListener: PopMenuItemSelectedListener? = null
    private var mSelectedItemInfo: Any? = null
    private val rootView: View
    private val layoutParent: View
    private val layoutAppInfo: View
    private val layoutInstall: View
    private val itemNameAppInfo: TextView
    private val itemNameInstall: TextView
    private val iconInstall: ImageView
    private val arrowView: ImageView

    private var mAlignedRect: Rect = Rect()
    private var mLocationRect: Rect = Rect()

    private val offsetY : Int = dip2px(4f)

    private var windowWidth : Int = 0

    private var isDownload : Boolean = false

        private var mIsLeftAligned = false
    private var mAlignType = 0
    val ALIGN_TYPE_LEFT = 0
    val ALIGN_TYPE_CENTER = 1
    val ALIGN_TYPE_RIGHT = 2
    val ALIGN_TYPE_AUTO = 3

    init {
        rootView = LayoutInflater.from(mContext).inflate(R.layout.layout_cloud_folder_popup, null)
        contentView = rootView
        val convertView = contentView
        layoutParent = convertView.findViewById<View>(R.id.layoutParent) as View
        layoutAppInfo = convertView.findViewById<View>(R.id.layout_item_appinfo) as View
        layoutInstall = convertView.findViewById<View>(R.id.layout_item_install) as View
        itemNameAppInfo = convertView.findViewById<View>(R.id.name_app_info) as TextView
        itemNameInstall = convertView.findViewById<View>(R.id.name_install) as TextView
        iconInstall = convertView.findViewById<View>(R.id.icon_install) as ImageView
        arrowView = convertView.findViewById<ImageView>(R.id.iv_arrow) as ImageView
        itemNameAppInfo.text = mContext.getSafeString(R.string.shortcut_pop_appinfo, useSystemLanguage = true)
        isOutsideTouchable = true
        isFocusable = true
        animationStyle = R.style.CloudFolderPopupStyle
        setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        height = dip2px(71f)
        windowWidth = mContext.resources.displayMetrics.widthPixels;

    }

    fun setData(
        selectedItemInfo: CloudAppInfo?,
        pos: Int,
        itemOnClikcListener: PopMenuItemSelectedListener?
    ): CloudClickPopupWindow {
        mItemOnClikcListener = itemOnClikcListener
        mSelectedItemInfo = selectedItemInfo
        layoutAppInfo.setOnClickListener(PopupItemClickListener(itemNameAppInfo, pos))
        layoutInstall.setOnClickListener(PopupItemClickListener(itemNameInstall, pos))

        if(selectedItemInfo?.isOtherType() == true) {
            layoutInstall.visibility = View.GONE
            layoutParent.minimumWidth = dip2px(100f)
        } else if(selectedItemInfo?.isPreInstallItem() == true) {
            layoutInstall.visibility = View.VISIBLE
            layoutParent.minimumWidth = dip2px(260f)
        } else {
            layoutInstall.visibility = View.VISIBLE
            layoutParent.minimumWidth = dip2px(200f)
        }

        selectedItemInfo?.let {
            if(it.isPreInstallItem()) {
                //预缓存
                iconInstall.setImageResource(R.drawable.ic_cloud_send_to_desktop)
                itemNameInstall.text = mContext.getSafeString(R.string.string_file_folder_move_app, useSystemLanguage = true)
            } else {
                isDownload =
                    FileDownloadInfo.isDownloading(it.observerStatus) || FileDownloadInfo.isPauseOrError(
                        it.observerStatus
                    )
                if (isDownload) {
                    iconInstall.setImageResource(R.drawable.ic_cloud_folder_uninstall)
                    itemNameInstall.text = mContext.getSafeString(R.string.text_uninstall, useSystemLanguage = true)
                } else {
                    iconInstall.setImageResource(R.drawable.ic_cloud_folder_install)
                    itemNameInstall.text = mContext.getSafeString(R.string.text_install, useSystemLanguage = true)
                }
            }
        }
        return this
    }

    /**
     * pop自动调整位置显示在左右两侧
     *
     * @param anchorView  呼出window的view
     * @param contentView window的内容布局
     * @return window显示的左上角的xOff, yOff坐标
     */
    fun calculatePopWindow(context: Context?, anchorView: View, contentView: View, arrowView: View): IntArray {
        val windowPos = IntArray(2)
        val anchorLoc = IntArray(2)
        // 获取锚点View在屏幕上的左上角坐标位置
        anchorView.getLocationOnScreen(anchorLoc)

        mAlignedRect = Rect(anchorLoc[0], anchorLoc[1], anchorLoc[0] + anchorView.measuredWidth, anchorLoc[1] + anchorView.measuredHeight)

        contentView.measure(0, 0)
        val containerWidth: Int = contentView.measuredWidth
        val containerHeight: Int = dip2px(71f)

        //handle x coordinate
        if (mAlignedRect.centerX() - containerWidth / 2 >= 0
            && mAlignedRect.centerX() + containerWidth / 2 <= windowWidth
        ) {
            mAlignType = ALIGN_TYPE_CENTER
            mIsLeftAligned = false
        } else if (mAlignedRect.left + containerWidth <= windowWidth) {
            mIsLeftAligned = true
            mAlignType = ALIGN_TYPE_LEFT
        } else if (mAlignedRect.right - containerWidth >= 0) {
            mIsLeftAligned = false
            mAlignType = ALIGN_TYPE_RIGHT
        } else {
            mAlignType = ALIGN_TYPE_AUTO
            mIsLeftAligned = false
        }


        val x: Int
        when (mAlignType) {
            ALIGN_TYPE_LEFT -> x =
                mAlignedRect.left

            ALIGN_TYPE_RIGHT -> x =
                mAlignedRect.right - containerWidth

            ALIGN_TYPE_AUTO -> {
                val isIconLeft: Boolean =
                    mAlignedRect.centerX() <= Math.abs(mAlignedRect.centerX()- windowWidth)
                x = if (isIconLeft) {
                    0
                } else {
                    windowWidth - containerWidth
                }
            }
            ALIGN_TYPE_CENTER -> x =
                mAlignedRect.centerX() - containerWidth / 2

            else -> x = mAlignedRect.centerX() - containerWidth / 2
        }


        val anchorHeight = anchorView.height
        val anchorWidth = anchorView.width
        val anchorPaddingTop = anchorView.paddingTop
        val anchorPaddingLeft = anchorView.paddingLeft
        // 获取屏幕的高宽
        val screenHeight = DisplayUtil.getScreenHeightPx(context)
        val screenWidth = DisplayUtil.getScreenWidthPx(context)
        // 测量contentView
        contentView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        // 计算contentView的高宽
        val windowHeight = dip2px(71f)
        val windowWidth = contentView.measuredWidth
        // 判断需要向上弹出还是向下弹出显示
        windowPos[1] = anchorLoc[1] - windowHeight - offsetY

        windowPos[0] = x
        val y = windowPos[1]
        mLocationRect.left = x
        mLocationRect.top = y
        mLocationRect.right = x + containerWidth
        mLocationRect.bottom = y + containerHeight

        //arrow
        val arrowParams = arrowView.layoutParams as LinearLayout.LayoutParams
        var margin: Int
        var paddingLeft = dip2px(7f)
        if (mIsLeftAligned) {
            arrowParams.gravity = Gravity.LEFT
            margin =
                (mAlignedRect.right + mAlignedRect.left) / 2 - mLocationRect.left - paddingLeft - width / 2
            arrowParams.leftMargin = margin
        } else {
            arrowParams.gravity = Gravity.RIGHT
            margin =
                mLocationRect.right - (mAlignedRect.right + mAlignedRect.left) / 2 - paddingLeft - width / 2
            arrowParams.rightMargin = margin
        }

//        val arrowLeftMargin = anchorLeftPos - popLeftPos + anchorView.width / 2 - arrowView.width / 2
//        val arrowParams = arrowView.layoutParams as LinearLayout.LayoutParams
//        arrowParams.marginStart = arrowLeftMargin
        return windowPos
    }

    fun onShow(v: View) {
        try {
            val windowPos = calculatePopWindow(mContext, v, contentView, arrowView)
            showAtLocation(v, Gravity.NO_GRAVITY, windowPos[0], windowPos[1])

        } catch (e:Throwable) {
            //ignore
        }
    }

    private inner class PopupItemClickListener(private val tv: TextView, private val position: Int) : View.OnClickListener {
        override fun onClick(v: View) {
            try {
                dismiss()
            }catch (e:Throwable) {
                //ignore
            }
            if (null != mItemOnClikcListener) {
                mItemOnClikcListener!!.onItemClicked(
                    mSelectedItemInfo,
                    tv.text.toString(),
                    position
                )
            }
        }
    }


    interface PopMenuItemSelectedListener {
        fun onItemClicked(itemInfo: Any?, menuStr: String, position: Int)
    }

}

package com.afmobi.palmplay.cache.v6_3;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.configs.v6_3.AssetsConfig;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.SPKey;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.RecommendBean;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.FileUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.LanguageSelectManager;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by zz on 2017/1/9.
 */

public class RecommendInstallCache implements LocalCache {

    private static final String ASSET_ICON_PATH_PREFIX = "file:///android_asset/recommend/";//asset:///recommend/";

    private static volatile RecommendInstallCache instance;
    private static byte[] lock = new byte[0];
    private static ConcurrentHashMap<String, AppInfo> selectedData = new ConcurrentHashMap<>();

    private static CopyOnWriteArrayList<RecommendBean.NewStyle.CategoryList> mList; // 设置为静态是为了数据拉到没来的及显示，第二次启动不需要再拉数据了

    private static CopyOnWriteArrayList<RecommendBean.NewStyle.CategoryList> mListPreset;
    //旧的数据格式
    private static CopyOnWriteArrayList<AppInfo> mOldList = new CopyOnWriteArrayList<>();

    private boolean hasAddEwAds;
    private String title;
    private boolean mIsFromAutoStart;
    private final static String RECOMMEND_INSTALL_NAME = "recommend_install_name";

    private final int MAX_LIST_COUNT = 24;  // 默认最大24条数据
    private boolean isShowPresetData = false;
    private RecommendBean recommendBean;
    //推荐页样式
    public int recommendStyle = TYPE_NEW;
    //新的数据格式，包含多个分组
    private CopyOnWriteArrayList<RecommendBean.NewStyle.CategoryList> mCategoryList = new CopyOnWriteArrayList<>();
    //推荐页老样式
    public static final int TYPE_OLD = 1;
    //推荐页新样式
    public static final int TYPE_NEW = 2;
    //推荐页老样式-返回按钮带跳转功能
    public static final int TYPE_OLD_2 = 3;
    //实验ID
    private String varId = "";
    private String expId = "";
    //老的数据格式是否由预埋数据数据填充的。
    private boolean isFilterByPreset = false;
    //EW给的新手推荐页数据
    private List<AppInfo> mEwListData = new ArrayList<>();
    //标记启动Activity，一旦启动Activity，则没有必要更新数据。
    private boolean mLauncher = false;
    private boolean saveCache = true;

    private RecommendInstallCache() {
        loadFromCache();
        loadPresetDataInWorkThread();
    }

    public static RecommendInstallCache getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new RecommendInstallCache();
                }
            }
        }
        return instance;
    }

    public int getRecommendStyle() {
        return recommendStyle;
    }

    public String getVarId() {
        return varId;
    }

    public String getExpId() {
        return expId;
    }

    public void release() {
        if (mOldList != null) {
            mOldList.clear();
            mOldList = null;
        }

        if (mCategoryList != null) {
            mCategoryList.clear();
            mCategoryList = null;
        }


        instance = null;
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
        String fileName = getFileName();

        if (fileName != null) {
            FilePathManager.jsonToFile(jsonBuffer, fileName);
        }

    }

    @Override
    public void loadFromCache(Object... objects) {

        if (CommonUtils.isPrivacyPolicyHasAllowed() && SPManager.getBoolean(SPKey.key_recommend_install, false)) {
            return;
        }

        String fileName = getFileName();

        JsonElement jsonObject = FilePathManager.fileToJson(fileName);
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "loadFromCache: " + jsonObject);
        if (jsonObject instanceof JsonObject) {
            JsonObject jo = jsonObject.getAsJsonObject();
            initPageCaches(jo, false, false);
        }
    }

    @Override
    public String getFileName(Object... objects) {
        return RECOMMEND_INSTALL_NAME;
    }

    public void initPageCaches(JsonObject response, boolean isFromNetwork, boolean isFromAutoStart) {
        if (isShowPresetData && mLauncher) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Showing preset data or activity is start." + response);
            return;
        }
        if (mOldList != null) {
            mOldList.clear();
            mOldList = null;
        }

        if (mCategoryList != null) {
            mCategoryList.clear();
            mCategoryList = null;
        }
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Get the network data.");
        try {
            recommendBean = new Gson().fromJson(response, RecommendBean.class);
            if (recommendBean != null) {
                int installStyle = recommendBean.installStyle;
                if (!TextUtils.isEmpty(recommendBean.varid)) {
                    varId = recommendBean.varid;
                }
                if (!TextUtils.isEmpty(recommendBean.expId)) {
                    expId = recommendBean.expId;
                }
                LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Parse the data , the varid = " + varId + ",installStyle = " + installStyle);
                if (installStyle == 0) {
                    installStyle = TYPE_OLD;
                }

                recommendStyle = installStyle;
                updateData(recommendBean);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }


        if (isFromNetwork && saveCache) {
            response.addProperty("isFromAutoStart", isFromAutoStart);
            mIsFromAutoStart = isFromAutoStart;
            saveToCache(response.toString());
        } else {
            mIsFromAutoStart = response.get("isFromAutoStart") != null && response.get("isFromAutoStart").getAsBoolean();
        }
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, " initPageCaches  : isFromNetwork = " + isFromNetwork + response);

        //filter(mList,false);
    }

    private void cacheAppIconNew(List<RecommendBean.NewStyle.CategoryList> categoryListList) {
        if (categoryListList != null) {
            for (RecommendBean.NewStyle.CategoryList categoryList : categoryListList) {
                if (categoryList != null) {
                    List<AppInfo> itemList = categoryList.itemList;
                    if (itemList != null) {
                        for (AppInfo appInfo : itemList) {
                            TRBitmapManager.prefetchToBitmapCacheByFresco(appInfo.iconUrl, 0, 0);
                        }
                    }
                }
            }
        }
    }

    private void updateData(RecommendBean data) {
        String[] rs = null;
        if (!TextUtils.isEmpty(data.rs)) {
            rs = data.rs.split(",");
        }
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Update recommend data.");
        if (recommendStyle == TYPE_NEW) {
            RecommendBean.NewStyle newStyle = data.newStyle;
            mCategoryList = newStyle.categoryList;
            filterNew(mCategoryList, false);
            if (mCategoryList == null) {
                recommendStyle = TYPE_NEW;
                saveCache = false;
            } else {
                cacheAppIconNew(mCategoryList);
                checkTraceId(mCategoryList, rs, data.tid);
            }
            //新的没有过滤在应用启动前
        } else if (recommendStyle == TYPE_OLD || recommendStyle == TYPE_OLD_2) {
            RecommendBean.OldStyle oldStyle = data.oldStyle;
            mOldList = oldStyle.itemList;
            cacheAppIconOld(mOldList);
            checkTraceId(mOldList, rs, data.tid);
            filter(mOldList, false);
        }
    }

    private void checkTraceId(CopyOnWriteArrayList<AppInfo> mOldList, String[] rs, String traceId) {
        if (BuildConfig.DEBUG){
            int size = -1;
            if (mOldList != null) {
                size = mOldList.size();
            }
            LogUtils.d("checkTraceId", "2 新手一键安装 rs: " + Arrays.toString(rs) +
                    " tid: " + traceId + " 物料数量：" + size);
        }
        if (mOldList != null && mOldList.size() > 0 && rs != null && rs.length > 0 && !TextUtils.isEmpty(traceId)) {
            for (AppInfo baseData : mOldList) {
                if (baseData.reportDto != null) {
                    for (String rsd : rs) {
                        if (TextUtils.equals(rsd, baseData.reportSource)) {
                            baseData.reportDto.traceId = traceId;
                            baseData.reportDto.reportSource = baseData.reportSource;
                            if (BuildConfig.DEBUG){
                                LogUtils.d("checkTraceId", "新手一键安装 匹配成功");
                            }
                            break;
                        }
                    }
                }
            }
        }
    }

    private void checkTraceId(List<RecommendBean.NewStyle.CategoryList> categoryListList, String[] rs, String traceId) {
        if (BuildConfig.DEBUG){
            int size = -1;
            if (categoryListList != null) {
                size = categoryListList.size();
            }
            LogUtils.d("checkTraceId", "1 新手一键安装 rs: " + Arrays.toString(rs) +
                    " tid: " + traceId + " 物料数量：" + size);
        }
        if (categoryListList != null && rs != null && rs.length > 0 && !TextUtils.isEmpty(traceId)) {
            for (RecommendBean.NewStyle.CategoryList categoryList : categoryListList) {
                if (categoryList != null) {
                    List<AppInfo> itemList = categoryList.itemList;
                    if (itemList != null) {
                        for (AppInfo baseData : itemList) {
                            if (baseData.reportDto != null) {
                                for (String rsd : rs) {
                                    if (TextUtils.equals(rsd, baseData.reportSource)) {
                                        baseData.reportDto.traceId = traceId;
                                        baseData.reportDto.reportSource = baseData.reportSource;
                                        if (BuildConfig.DEBUG){
                                            LogUtils.d("checkTraceId", "新手一键安装 匹配成功");
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void cacheAppIconOld(CopyOnWriteArrayList<AppInfo> mOldList) {
        if (mOldList != null && mOldList.size() > 0) {
            for (AppInfo appInfo : mOldList) {
                TRBitmapManager.prefetchToBitmapCacheByFresco(appInfo.iconUrl, 0, 0);
            }
        }
    }

    public List<RecommendBean.NewStyle.CategoryList> getCategoryList() {
        if (!isCategoryListEmpty()) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Had fill data.");
            if (!isFilterByPreset) {
                isShowPresetData = false;
            }
        } else if (mListPreset != null && mListPreset.size() > 0) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Set preset data to old data.");
            isShowPresetData = true;
            mCategoryList = mListPreset;
            isFilterByPreset = true;
        }
        if (mCategoryList != null && !mCategoryList.isEmpty()){
            TRHomeUtil.resetVaStatus4AppInfoListNew(mCategoryList);
            resetCategoryName(mCategoryList);
        }
        return mCategoryList;
    }

    /**
     * 根据 defaultLocale 过滤 20种重点语言（todo 服务端翻译不足，待替换预埋）
     */
    public void resetCategoryName(List<RecommendBean.NewStyle.CategoryList> categoryLists) {
//        String defaultLocale = Locale.getDefault().toString();
        String langTag = LanguageSelectManager.getLanTag(PalmplayApplication.getAppInstance());
        langTag = CommonUtils.normalizeLangTag(langTag);

        if (TextUtils.isEmpty(langTag)){
            return;
        }
        for (RecommendBean.NewStyle.CategoryList categoryList:categoryLists) {
            Map<String,String> map = categoryList.categoryNameMap;
            if (map == null || map.isEmpty()){
                continue;
            }
            LogUtils.d("UpdateCategoryName","replace ==> langTag = " + langTag + categoryList.categoryName);
            if (!TextUtils.isEmpty(map.get(langTag))) {
                categoryList.categoryName = map.get(langTag);
                LogUtils.d("UpdateCategoryName","categoryName = " + categoryList.categoryName);
            }

        }
    }

    public List<AppInfo> getNetDataList() {
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Try to get network data.");
        return mOldList;
    }

    public List<AppInfo> getOldList() {

        if (mOldList != null && mOldList.size() > 0) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Had fill data.");
            if (!isFilterByPreset) {
                isShowPresetData = false;
            }
        }

        return mOldList;
    }

    public List<RecommendBean.NewStyle.CategoryList> getPresetData() {
        return mListPreset;
    }

    public void addAdForRecommendListOld(List<AppInfo> list, AppInfo appInfo, int row, int col) {
        if (list == null || list.size() <= 0) {
            return;
        }
        hasAddEwAds = true;
        if (appInfo == null) {
            return;
        }
        if (col < 0 || col >= list.size()) {
            return;
        }
        HisavanaSdkManager.getInstance().filterValidateAdByAppInfo(list, appInfo.packageName);
        RecommendInstallCache.getInstance().pullSelectedData(appInfo, true);
        list.add(col, appInfo);
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Insert ew app, the app name = " + appInfo.name);
    }


    public void addAdForRecommendList(List<RecommendBean.NewStyle.CategoryList> list, AppInfo appInfo, int row, int col) {
        if (list == null || list.size() <= 0) {
            return;
        }
        hasAddEwAds = true;
        if (appInfo == null) {
            return;
        }
        //新样式直接插入到应用最前面，可以不用管col

        //数据去重（移除原有数组的数据）
        HisavanaSdkManager.getInstance().filterValidateRecommendAdByAppInfo(list, appInfo.packageName);
        //新的数据格式统一在启动前整理
        //RecommendInstallCache.getInstance().pullSelectedData(appInfo, true);
        //插入最后一行
        //取到最后一个目录
        //放置到临时目录
        mEwListData.add(appInfo);
    }

    public String getTitle() {
        return title;
    }

    public String getExtraType() {
        if (isShowPresetData) {
            return TRAnalyticsConstant.RECOM_PRESET;
        }
        return (mIsFromAutoStart ? TRAnalyticsConstant.RECOM_REQ_AUTO : TRAnalyticsConstant.RECOM_REQ_NORMAL);
    }

    /**
     * 正在展示预埋数据
     */
    public boolean isShowPresetData() {
        return isShowPresetData;
    }

    /***
     * 获取成功且有数据
     * @return
     */
    public boolean isValidSuccess() {
        boolean isCategoryListEmpty = isCategoryListEmpty();
        LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "isValidSuccess: mList = " + mList + ",mListPreset = " + mListPreset + ",mCategoryList = " + isCategoryListEmpty);
        return !isCategoryListEmpty || mOldList != null && mOldList.size() > 0 || mListPreset != null && mListPreset.size() > 0;
    }

    public boolean isCategoryListEmpty() {
        if (mCategoryList == null || mCategoryList.isEmpty()){
            return true;
        }

        for (RecommendBean.NewStyle.CategoryList mCategory : mCategoryList){
            if (mCategory.itemList != null && !mCategory.itemList.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private void loadPresetDataInWorkThread() {
        if (mCategoryList != null && mCategoryList.size() > 0 || mOldList != null && mOldList.size() > 0 || CommonUtils.isPrivacyPolicyHasAllowed() && SPManager.getBoolean(SPKey.key_recommend_install, false)) {
            return;
        }
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                RecommendBean recommendBean = loadPresetData();
                if (recommendBean != null && recommendBean.newStyle != null) {
                    CopyOnWriteArrayList<RecommendBean.NewStyle.CategoryList> list = recommendBean.newStyle.categoryList;
                    LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "loadPresetData: " + mListPreset);
                    filterNew(list, true);
                    mListPreset = list;
                }
            }
        }));
    }

    public static RecommendBean loadPresetData() {
        RecommendBean recommendBean = null;
        try {
            String fileName = getPreSetDataFileName();
            if (!TextUtils.isEmpty(fileName)) {
                LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Load preset data, the file name = " + fileName);
                String str = FileUtils.getStringFromAssets(fileName, PalmplayApplication.getAppInstance());
                if (!TextUtils.isEmpty(str)) {
                    JSONObject jo = new JSONObject(str);
                    if (jo.keys().hasNext()){
                        String key = jo.keys().next();
                        String value = jo.getString(key);
                        if (!TextUtils.isEmpty(value)){
                            recommendBean = new Gson().fromJson(value, RecommendBean.class);
                        }
                    }
                }
            }

        } catch (Exception e) {
            LogUtils.e(e);
        }
        return recommendBean;
    }

    /**
     * 根据当前手机的国家码获取正确的home接口预置数据文件名；
     *
     * @return
     */
    private static String getPreSetDataFileName() {
        String fileName = null;
        String countryCode = PhoneDeviceInfo.getCountryCode();
        if (AssetsConfig.COUNTRY_CODE_BD.equals(countryCode)) {
            fileName = AssetsConfig.FILE_NAME_RECOMMEND_BD;
        } else if (AssetsConfig.COUNTRY_CODE_ID.equals(countryCode)) {
            fileName = AssetsConfig.FILE_NAME_RECOMMEND_ID;
        } else if (AssetsConfig.COUNTRY_CODE_IN.equals(countryCode)) {
            fileName = AssetsConfig.FILE_NAME_RECOMMEND_IN;
        } else if (AssetsConfig.COUNTRY_CODE_NG.equals(countryCode)) {
            fileName = AssetsConfig.FILE_NAME_RECOMMEND_NG;
        } else if (AssetsConfig.COUNTRY_CODE_PK.equals(countryCode)) {
            fileName = AssetsConfig.FILE_NAME_RECOMMEND_PK;
        }
        return fileName;
    }

    // add by HJG 2017-01-09  for "must have"
    public void filterNew(CopyOnWriteArrayList<RecommendBean.NewStyle.CategoryList> mList, boolean isPreset) {
        if (!isPreset) {
            selectedData.clear();
        }
        if (mList != null && !mList.isEmpty()) {
            List<RecommendBean.NewStyle.CategoryList> tempList = new ArrayList<>();
            try {
                int p = 0;
                for (int categorySize = 0;categorySize < mList.size(); categorySize++) {
                    RecommendBean.NewStyle.CategoryList categoryList = mList.get(categorySize);
                    if (categoryList.itemList != null && !categoryList.itemList.isEmpty()) {
                        List<AppInfo> appInfos = new ArrayList<>();
                        for (int itemSize = 0; itemSize < categoryList.itemList.size(); itemSize++) {
                            AppInfo appInfo = categoryList.itemList.get(itemSize);
                            if (appInfo != null && !TextUtils.isEmpty(appInfo.packageName)
                                    && !InstalledAppManager.isInstalledSpecialApp(appInfo.packageName)) {
                                if (!isPreset && "T".equalsIgnoreCase(appInfo.isSelect)) {
                                    pullSelectedData(appInfo, true);
                                }
                                if (isPreset) {
                                    String presetFileName = extractPresetFileName(appInfo.iconUrl);
                                    if (!TextUtils.isEmpty(presetFileName)) {
                                        appInfo.iconLocalUrl = ASSET_ICON_PATH_PREFIX + presetFileName;
                                    }
                                }
                                appInfo.orgPosition = p;
                                appInfos.add(categoryList.itemList.get(itemSize));
                                p = p + 1;
                            }
                        }
                        categoryList.itemList.clear();
                        categoryList.itemList.addAll(appInfos);
                        tempList.add(categoryList);
                    }
                }
            } catch (Exception e) {
                PalmplayApplication.getAppInstance().getAppDataManager().recomPopupApiResponseRecord(FirebaseConstants.RECOM_FILTER_EXCEPTION, 0, getExtraType());
            }
            mList.clear();
            mList.addAll(tempList);
            if (mList.size() > 0) {
                PalmplayApplication.getAppInstance().getAppDataManager().recomPopupApiResponseRecord("", 1, getExtraType());
            } else {
                PalmplayApplication.getAppInstance().getAppDataManager().recomPopupApiResponseRecord("no data", 1, getExtraType());
            }
        }
    }

    // add by HJG 2017-01-09  for "must have"
    public void filter(CopyOnWriteArrayList<AppInfo> mList, boolean isPreset) {
        selectedData.clear();
        if (mList != null && mList.size() > 0) {
            List<AppInfo> tempList = new ArrayList<>();
            try {
                int p = 0;
                for (int i = 0; i < mList.size(); i++) {
                    AppInfo appInfo = mList.get(i);
                    if (appInfo != null && !TextUtils.isEmpty(appInfo.packageName)
                            && !InstalledAppManager.isInstalledSpecialApp(appInfo.packageName)) {
                        if ("T".equalsIgnoreCase(appInfo.isSelect)) {
                            pullSelectedData(appInfo, true);
                        }
                        if (isPreset) {
                            String presetFileName = extractPresetFileName(appInfo.iconUrl);
                            if (!TextUtils.isEmpty(presetFileName)) {
                                appInfo.iconLocalUrl = ASSET_ICON_PATH_PREFIX + presetFileName;
                            }
                        }
                        appInfo.orgPosition = p;
                        tempList.add(mList.get(i));
                        p = p + 1;
                    }
                }
            } catch (Exception e) {
                PalmplayApplication.getAppInstance().getAppDataManager().recomPopupApiResponseRecord(FirebaseConstants.RECOM_FILTER_EXCEPTION, 0, getExtraType());
            }
            mList.clear();
            mList.addAll(tempList);
            if (mList.size() > 0) {
                PalmplayApplication.getAppInstance().getAppDataManager().recomPopupApiResponseRecord("", 1, getExtraType());
            } else {
                PalmplayApplication.getAppInstance().getAppDataManager().recomPopupApiResponseRecord("no data", 1, getExtraType());
            }
        }
    }

    /**
     * 截取预置icon的文件名
     *
     * @param iconUrl http://uat-cdn.palmplaystore.com/static/281/d0575ea867e44ebead806f4a15e6b995.webp
     * @return d0575ea867e44ebead806f4a15e6b995.webp
     */
    private String extractPresetFileName(String iconUrl) {
        String name = "";
        if (!TextUtils.isEmpty(iconUrl)) {
            String[] split = iconUrl.split("/");
            name = split[split.length - 1];
        }
        return name;
    }

    public void pullSelectedData(AppInfo appInfo, boolean isChecked) {
        if (selectedData == null || appInfo == null || TRStringUtil.isBlank(appInfo.itemID)) {
            return;
        }
        if (isChecked) { // 直接覆盖
            selectedData.put(appInfo.itemID, appInfo);
        } else if (selectedData.containsKey(appInfo.itemID)) {
            selectedData.remove(appInfo.itemID);
        }
    }

    public ConcurrentHashMap<String, AppInfo> getSelectedData() {
        return selectedData;
    }

    //更新插入EW数据。
    //新样式将EW数据插入到最前面。
    public void updateEwData() {
        if (recommendStyle == TYPE_NEW && mEwListData.size() > 0) {
            LogUtils.d(LogUtils.TAG_TR_RECOMMEND_INSTALL, "Ew app size = : " + mEwListData.size());
            List<RecommendBean.NewStyle.CategoryList> list = getCategoryList();
            if (list != null) {
                for (RecommendBean.NewStyle.CategoryList categoryList : list) {
                    int type = categoryList.type;
                    if (type == 2) {
                        List<AppInfo> itemList = categoryList.itemList;
                        CopyOnWriteArrayList<AppInfo> offerAndCpAndDspItemList = categoryList.offerAndCpAndDspItemList;
                        if (itemList != null) {
                            if (offerAndCpAndDspItemList != null && offerAndCpAndDspItemList.size() > 0) {
                                itemList.addAll(0, removeRepeat(offerAndCpAndDspItemList));
                            }
                            itemList.addAll(0, mEwListData);
                        }
                    }
                }
            }

        }
    }

    private List<AppInfo> removeRepeat(CopyOnWriteArrayList<AppInfo> offerAndCpAndDspItemList) {
        if (mEwListData == null || mEwListData.isEmpty()) {
            return offerAndCpAndDspItemList;
        }
        List<AppInfo> modifiableList = new ArrayList<>(offerAndCpAndDspItemList);
        Iterator<AppInfo> iterator = modifiableList.iterator();
        while (iterator.hasNext()) {
            AppInfo appInfo = iterator.next();
            for (AppInfo ew: mEwListData) {
                if (TextUtils.isEmpty(appInfo.packageName) || TextUtils.isEmpty(ew.packageName)) {
                    break;
                }
                if (TextUtils.equals(appInfo.packageName, ew.packageName)) {
                    iterator.remove();
                    break;
                }
            }
        }
        return modifiableList;
    }

    //标记启动Activity
    public void launcherActivity(boolean isLauncher) {
        mLauncher = isLauncher;
    }

    public void removeCacheAndFile() {
        if (mCategoryList != null) {
            mCategoryList.clear();
        }
        if (mEwListData != null) {
            mEwListData.clear();
        }
        if (mOldList != null) {
            mOldList.clear();
        }
        if (mListPreset != null) {
            mListPreset.clear();
        }
        FilePathManager.removeFile(getFileName());
    }
}

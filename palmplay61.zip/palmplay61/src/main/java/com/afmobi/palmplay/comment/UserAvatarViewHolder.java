package com.afmobi.palmplay.comment;

import android.content.Context;

import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.transsnet.store.databinding.LayoutAvatarItemBinding;

import androidx.databinding.ViewDataBinding;

public class UserAvatarViewHolder extends BaseRecyclerViewHolder {


    private LayoutAvatarItemBinding binding;

    public UserAvatarViewHolder(ViewDataBinding binding, Context context) {
        super(binding.getRoot());
        this.binding = (LayoutAvatarItemBinding) binding;
    }


    public void bind(String item, int position, int selectedPosition) {
        binding.setPosition(position);
        binding.setSelectPosition(selectedPosition);
        binding.setIcon(item);
        binding.executePendingBindings();

    }


}

package com.afmobi.palmplay.activate.state

import com.afmobi.palmplay.activate.state.TRActivateConstant.ShowState

class ShowStateManager  private constructor(){

    companion object {
        @Volatile
        private var instance: ShowStateManager? = null
        private var mShowState = ShowState.ACTIVATE_NEED_SHOW

        fun getInstance(): ShowStateManager {
            return instance ?: synchronized(this) {
                instance ?: ShowStateManager().also { instance = it }
            }
        }
    }

    @Synchronized
    fun canShow(): Boolean {
        return mShowState == ShowState.ACTIVATE_NEED_SHOW
    }

    @Synchronized
    fun isShowing(): Boolean {
        return mShowState == ShowState.ACTIVATE_SHOWED
    }

    @Synchronized
    fun markAdShown() {
        mShowState = ShowState.ACTIVATE_SHOWED
    }

    @Synchronized
    fun reset() {
        mShowState = ShowState.ACTIVATE_NEED_SHOW
    }

    @Synchronized
    fun block() {
        mShowState = ShowState.ACTIVATE_BLOCKED
    }

    @get:Synchronized
    val isBlocked: Boolean
        get() = mShowState == ShowState.ACTIVATE_BLOCKED
}

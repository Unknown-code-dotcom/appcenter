package com.afmobi.palmplay.customview.banner.transformer;

import androidx.viewpager2.widget.ViewPager2;

public abstract class BasePageTransformer implements ViewPager2.PageTransformer {
    public static final float DEFAULT_CENTER = 0.5f;


}

// TOP SECRET
package com.afmobi.palmplay.configs;

public interface HttpRequestState {

    String requestNone = "requestNone";
    String requesting = "requesting";
    String requestFailure = "requestFailure";
    String requestSuccess = "requestSuccess";
}

package com.afmobi.palmplay.appmanage.model;

import android.text.TextUtils;

import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameInfo;
import com.afmobi.palmplay.model.GameFavoriteInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.util.Constant;
import com.google.common.reflect.TypeToken;
import com.transsion.palmstorecore.util.GsonUtils;
import com.transsion.palmstorecore.util.MMKVUtils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class InstantGameBean implements Comparable<InstantGameBean> {
    public static final int TYPE_H5 = 1;
    public static final int TYPE_VA = 2;
    public static final int TYPE_OFFLINE = 3;

    public int type;
    public TrInstantH5GameInfo h5GameInfo;
    public FileDownloadInfo vaGameInfo;
    public GameFavoriteInfo gameFavoriteInfo;
    public String sizeName;


    public long getRecentPlayTime() {
        long time = 0L;
        if (type == TYPE_H5 && h5GameInfo != null) {
            time = h5GameInfo.lastPlayTime;
        } else if (type == TYPE_VA && vaGameInfo != null && vaGameInfo.extraInfo != null && !TextUtils.isEmpty(vaGameInfo.extraInfo.appClickTime) && TextUtils.isDigitsOnly(vaGameInfo.extraInfo.appClickTime)) {
            time = Long.parseLong(vaGameInfo.extraInfo.appClickTime);
        } else if (type == TYPE_OFFLINE && gameFavoriteInfo != null) {
            time = gameFavoriteInfo.favoriteTime;
        }
        return time;
    }

    public long getRecentPlayTimeReal() {
        String vaOpenTsJson = MMKVUtils.getMMKV().getString(Constant.VA_GAMES_OPEN_TIMES, "");
        long time = 0L;
        if (type == TYPE_H5 && h5GameInfo != null) {
            time = h5GameInfo.lastPlayTime;
        } else if (type == TYPE_VA && vaGameInfo != null && vaGameInfo.extraInfo != null && !TextUtils.isEmpty(vaGameInfo.extraInfo.appClickTime) && TextUtils.isDigitsOnly(vaGameInfo.extraInfo.appClickTime)) {
            if (!TextUtils.isEmpty(vaOpenTsJson)) {
                Map<String, String> vaGameTsMap = GsonUtils.getInstance().fromJson(vaOpenTsJson, new TypeToken<ConcurrentHashMap<String, String>>() {
                }.getType());
                if (vaGameTsMap != null && vaGameTsMap.size() > 0) {
                    for (Map.Entry<String, String> entry : vaGameTsMap.entrySet()) {
                        if (vaGameInfo.packageName.equals(entry.getKey())) {
                            try {
                                time = Long.valueOf(entry.getValue());
                            } catch (NumberFormatException ignore) {
                                // 存时异常，降级为clickTime
                                time = Long.parseLong(vaGameInfo.extraInfo.appClickTime);
                            }
                        }
                    }
                } else {
                    time = Long.parseLong(vaGameInfo.extraInfo.appClickTime);
                }
            } else {
                time = Long.parseLong(vaGameInfo.extraInfo.appClickTime);
            }
        } else if (type == TYPE_OFFLINE && gameFavoriteInfo != null) {
            time = gameFavoriteInfo.favoriteTime;
        }
        return time;
    }

    public String getIdentifier(){
        String identifier = "";
        if (type == TYPE_H5 && h5GameInfo != null) {
            identifier = h5GameInfo.name;
        }else if (type == TYPE_VA && vaGameInfo != null) {
            identifier = vaGameInfo.packageName;
        }
        return identifier;
    }


    public int compareTo(InstantGameBean o) {
        //卸载管理中，越早玩过的游戏排越前面
        return Long.compare(getRecentPlayTime(), o.getRecentPlayTime());
    }
}

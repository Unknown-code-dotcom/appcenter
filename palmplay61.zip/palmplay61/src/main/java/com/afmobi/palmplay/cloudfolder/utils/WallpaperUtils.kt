package com.afmobi.palmplay.cloudfolder.utils

import android.annotation.TargetApi
import android.app.Activity
import android.app.WallpaperInfo
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RSRuntimeException
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import androidx.annotation.ColorInt
import androidx.annotation.IntDef
import androidx.annotation.MainThread
import androidx.core.graphics.drawable.toDrawable
import androidx.palette.graphics.Palette
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsnet.store.R
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.reflect.Method
import kotlin.math.max
import kotlin.math.min
import androidx.core.net.toUri

class WallpaperUtils private constructor() {

    private val TAG = "WallpaperUtils"

    private val DEFAULT_MASK_COLOR = 0x4D000000

    private val WALLPAPER_PATH: String =
        "content://com.transsion.livewallpaper.custom.provider.WallpaperProvider/current_wallpaper"
    private val WALLPAPER_PATH_PERSON: String =
        "content://com.transsion.livewallpaper.pictorial.provider.WallpaperProvider/current_wallpaper"

    private val WALLPAPER_PATH_CUTE_PET: String =
        "content://com.transsion.cutepet.provider/current_pet_shortcut"

    private val WALLPAPER_AUTHOR: String =
        "com.transsion.livewallpaper.custompictorial.provider.WallpaperProvider"

    private val WALLPAPER_STAR_RING_PROVIDER : String =
        "content://com.transsion.livewallpaper.starring.StarRingWallpaperProvider/current_wallpaper"

    private val WALLPAPER_SUN_POINTER_PROVIDER: String = "content://com.transsion.livewallpaper.sunpointer.SunPointerWallpaperProvider/current_wallpaper"

    val PHOTOGRAPHY_MASTER = "com.transsion.livewallpaper.view.TranCustomResWallpaperService"
    val PHOTOGRAPHY_MASTER_SECOND =
        "com.transsion.livewallpaper.view.TranSecondCustomResWallpaperService"
    val CURRENT_WALLPAPER =
        "content://com.transsion.livewallpaper.custom.provider.WallpaperProvider/current_wallpaper"


    private val PHOTO_MASTER_NAME: String =
        "com.transsion.livewallpaper.photomaster.service.TranCustomResWallpaperService"
    private val PHOTO_MASTER_NAME_SECOND: String =
        "com.transsion.livewallpaper.photomaster.service.TranSecondCustomResWallpaperService"
    private val PERSON_NAME_SECOND: String =
        "com.transsion.livewallpaper.view.TranWallpaperServicePictorial"
    private val PERSON_NAME: String =
        "com.transsion.livewallpaper.view.TranWallpaperServiceSecondPictorial"
    private val CUTE_PET: String = "com.transsion.cutepet.exhibit.TestWallpaperService"

    private val CUSTOM_PICTORIAL: String =
        "com.transsion.livewallpaper.pictorial.CustomPictorialWallpaperService"
    private val STAR_RING_SERVICE: String =
        "com.transsion.livewallpaper.starring.StarRingWallpaperService"
    private val SUN_POINTER_SERVICE: String =
        "com.transsion.livewallpaper.sunpointer.SunPointerWallpaperService"
    private val LIVE_PHOTO: String =
        "com.transsion.livewallpaper.livephoto.LivePhotoWallpaperService"
    private val AI_WALLPAPER_SERVICE: String =
        "com.transsion.aiwallpaper.wallpaperservice.AIWallpaperService"
    private val FAKE_3D_SERVICE: String =
        "com.transsion.livewallpaper.fake3d.Fake3dWallpaperService"

    private val LIVE_PHOTO_AUTHOR: String =
        "com.transsion.livewallpaper.livephoto.authorities.livePhotoContentProvider"
    private val AI_WALLPAPER_AUTHOR: String =
        "com.transsion.aiwallpaper.provider.aiWallpaperProvider"
    private val FAKE_3D_AUTHOR: String =
        "com.transsion.livewallpaper.fake3d.authorities.fake3dContentProvider"


    var currentDrawable: Drawable? = null

    private var mBlurBitmap: Bitmap? = null

    private val maskDrawable: Drawable =
        ColorDrawable(DEFAULT_MASK_COLOR)


    private val HEXS = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f')

    val LITE_OS =
        "1" == SystemProperties.get("ro.os_go.support") || "2" == SystemProperties.get("ro.os_go.support") || "3" == SystemProperties.get(
            "ro.os_go.support"
        ) || "1" == SystemProperties.get("ro.tran_go_support")

    val TRAN_ANIM_PLATFORM_LEVEL =
        android.os.SystemProperties.get("ro.tr_animation.platform_level", "3")

    /**
     * ro.transsion_launch_start_exit_support
     * 1=局部静态高斯模糊【仅Recent】；2=全量静态高斯模糊；3=动态高斯模糊"
     */
    val TRAN_GAUSSIAN_BLUR_FLAG =
        android.os.SystemProperties.get("ro.transsion_launcher_gaussian_blur_support", "1")

    val TRAN_DYNAMIC_GAUSSIAN_BLUR_SUPPORT = TRAN_GAUSSIAN_BLUR_FLAG == "3" && !LITE_OS

    val TRAN_GLOBAL_STATIC_GAUSSIAN_BLUR_SUPPORT = TRAN_GAUSSIAN_BLUR_FLAG == "2" && !LITE_OS

    val TRAN_NO_GAUSSIAN_BLUR_SUPPORT = LITE_OS

    private val MAX_BITMAP_ZOOM = 1

    /**
     * 颜色转换为灰度后二值化的临界值，越大越偏白，不大于255
     */
    private val GREY_COLOR_MIDDLE = 215

    private val SHOW_NAV_BAR_RES_NAME = "config_showNavigationBar"

    private var sNavBarOverride: String? = null
    private var sHasNavbar: Boolean? = null
    private var sDarkModeFlag = 0
    private var sSupportNavbarDarkModeReflection: Boolean? = null

    private var lightMode: Int = Lightness.UNKNOWN

    private val LARGE_DISTANCE: Int = 500
    private val FLAG_GET_WALLPAPER_BY_THUMBNAIL: Int = 1
    private val FLAG_GET_WALLPAPER_BY_DRAWABLE: Int = 2
    private val FLAG_GET_WALLPAPER_BY_SCREEN_SHOT: Int = 3
    private val FLAG_GET_WALLPAPER_BY_DEFAULT: Int = 4

    private var mMethodScreenshotWallpaper: Method? = null
    private val METHOD_SCREENSHOT_WALLPAPER_NAME: String = "screenshotWallpaper"

    companion object {
        @Volatile
        private var INSTANCE: WallpaperUtils? = null

        fun getInstance(): WallpaperUtils {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: WallpaperUtils().also { INSTANCE = it }
            }
        }
    }

    private fun isSupportStaticGaussianBlur(): Boolean {
        return (!LITE_OS
                && !TRAN_DYNAMIC_GAUSSIAN_BLUR_SUPPORT
                && !TRAN_NO_GAUSSIAN_BLUR_SUPPORT)
    }

    fun isSupportGlobalStaticGaussianBlur(): Boolean {
        if(Build.VERSION.SDK_INT > 35) {
            return !LITE_OS && TRAN_ANIM_PLATFORM_LEVEL != "1"
        }
        return (isSupportStaticGaussianBlur()
                && TRAN_GLOBAL_STATIC_GAUSSIAN_BLUR_SUPPORT)
    }

    fun generateBlurWallpaper(callback : ((drawable: Drawable?) -> Unit)? = null, callback2: ((mode: Int) -> Unit)? = null) {
        ioScope.launch {
            if(callback != null) {
                if (currentDrawable != null) {
                    mainScope.launch {
                        callback.invoke(currentDrawable)
                        callback2?.invoke(lightMode)
                    }
                }
            }
            val newDrawable : Drawable? =
            try {
                if(isSupportGlobalStaticGaussianBlur()) {
                    getBlurWallpaperDrawable()
                } else {
                    getCurrentWallpaper()
                }
            }catch (e : Exception) {
                null
            }

            if(newDrawable != null) {
                currentDrawable = newDrawable
                if (callback != null) {
                    mainScope.launch {
                        callback.invoke(currentDrawable)
                    }
                }
                lightMode = getLightModeFromBitmap()
                callback2?.let {
                    mainScope.launch {
                        it.invoke(lightMode)
                    }
                }
            } else if(currentDrawable == null){
                if (callback != null) {
                    mainScope.launch {
                        callback.invoke(null)
                    }
                }
            }
        }
    }

    private fun getLightModeFromBitmap() : Int {
        val bitmap = getBitmapFromBitmapDrawable(currentDrawable)
        bitmap?.let {
            return checkPaletteTopLightness(it)
        }
        return Lightness.UNKNOWN
    }

    fun isLightMode() : Boolean {
        return lightMode == Lightness.LIGHT
    }

    private fun getCurrentWallpaper(): Drawable? {
        val appContext = TRApplicationContextUtil.getInstance()
        val wallpaperManager = WallpaperManager.getInstance(appContext)
        var currentDrawable: Drawable? = null
        var flag: Int = FLAG_GET_WALLPAPER_BY_DRAWABLE
        try {
            val wallpaperInfo = wallpaperManager.wallpaperInfo
            val customResWallpaper: Drawable? = getCustomResWallpaper(appContext, wallpaperInfo)
            if (customResWallpaper != null) {
                currentDrawable =  customResWallpaper
            }
            if(currentDrawable == null) {
                if (wallpaperInfo != null) {
                    val wallpaperBitmap = getTranScreenshotWallpaper(appContext, wallpaperInfo)
                    if (wallpaperBitmap != null) {
                        currentDrawable = wallpaperBitmap.toDrawable(appContext.resources)
                    } else {
                        currentDrawable =
                            wallpaperInfo.loadThumbnail(appContext.packageManager)
                        flag = FLAG_GET_WALLPAPER_BY_THUMBNAIL
                    }
                }
            }
            if (currentDrawable == null) {
                currentDrawable = wallpaperManager.drawable
                flag = FLAG_GET_WALLPAPER_BY_DRAWABLE
            }
            if (currentDrawable == null) {
                LogUtils.e("getCurrentWallpaper is null")
            } else {
                if (flag == FLAG_GET_WALLPAPER_BY_THUMBNAIL) {
                    if (!isValidWallpaper(appContext, currentDrawable)) {
                        // 当通过缩略图的方式获取到壁纸时，可能会获取到的缩略图宽高和屏幕严重不匹配，
                        // 无法使用, 这个时候需要采用截图的方式获取壁纸。
                        LogUtils.e(TAG, "getCurrentWallpaper: get wallpaper by screen shot")
                        val bitmap = getScreenshotWallpaper()
                        if (bitmap != null && !bitmap.isRecycled) {
                            currentDrawable = BitmapDrawable(appContext.resources, bitmap)
                        }
                    }
                } else {
                    if (currentDrawable is BitmapDrawable) {
                        var b: Bitmap? = getBitmapFromBitmapDrawable(currentDrawable)
                        if (b == null) {
                            LogUtils.e("getCurrentWallpaper is isRecycled, retry get wallpaper...")
                            currentDrawable = wallpaperManager.drawable
                            b = getBitmapFromBitmapDrawable(currentDrawable)
                            if (b == null) {
                                LogUtils.e("getCurrentWallpaper is isRecycled, retry get wallpaper...still is null!")
                                currentDrawable = appContext.resources.getDrawable(R.drawable.wallpaper_replace, null)
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            LogUtils.e("getCurrentWallpaper has exception e=$e")
        }
        return currentDrawable
    }

    fun getRealSize(context: Context): Point {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val realSize = Point()
        wm.defaultDisplay.getRealSize(realSize)
        val smallSide = min(realSize.x, realSize.y)
        val largeSide = max(realSize.x, realSize.y)
        realSize.set(smallSide, largeSide)
        return realSize
    }

    fun getScreenshotWallpaper(): Bitmap? {
        try {
            val windowManagerGlobal = Class.forName("android.view.WindowManagerGlobal")
            val getWindowManagerService = windowManagerGlobal.getDeclaredMethod("getWindowManagerService")
            val windowManagerService = getWindowManagerService.invoke(null)
            if (windowManagerService != null) {
                val iWindowManager = Class.forName("android.view.IWindowManager")
                val mMethodScreenshotWallpaper = iWindowManager.getDeclaredMethod(METHOD_SCREENSHOT_WALLPAPER_NAME)
                mMethodScreenshotWallpaper.isAccessible = true
                val srcBitmap = mMethodScreenshotWallpaper.invoke(windowManagerService) as? Bitmap
                if (srcBitmap != null) {
                    val opaqueBitmap = toOpaqueBitmap(srcBitmap)
                    if (opaqueBitmap != srcBitmap) {
                        srcBitmap.recycle()
                    }
                    return opaqueBitmap
                }
            }
        } catch (e: Exception) {
            LogUtils.e(TAG, "getScreenshotWallpaper: e = $e")
        }
        return null
    }

    private fun toOpaqueBitmap(bitmap: Bitmap): Bitmap {
        if (!bitmap.hasAlpha()) {
            return bitmap
        }
        val opaqueBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(opaqueBitmap)
        canvas.drawColor(0xFFF5F5F5.toInt())
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        return opaqueBitmap
    }

    /**
     * //适配动态壁纸
     * @return
     */
    fun getCustomResWallpaper(context: Context, wallpaperInfo: WallpaperInfo?): Drawable? {
        if (wallpaperInfo != null && wallpaperInfo.component != null) {
            if (TextUtils.equals(
                    wallpaperInfo.component.className,
                    PHOTOGRAPHY_MASTER
                ) || TextUtils.equals(
                    wallpaperInfo.component.className,
                    PHOTOGRAPHY_MASTER_SECOND
                )
            ) {
                return try {
                    val NOTIFY_URI = Uri.parse(CURRENT_WALLPAPER)
                    var uri: String? = null
                    val cursor = context.contentResolver.query(NOTIFY_URI, null, null, null, null)
                    if (cursor != null) {
                        while (cursor.moveToNext()) {
                            uri = cursor.getString(0)
                            Log.d(TAG, "preview custom wallpaper uri=$uri")
                        }
                        cursor.close()
                    }
                    val inputStream = context.contentResolver.openInputStream(Uri.parse(uri))
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    BitmapDrawable(context.resources, bitmap)
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                    null
                }
            }
        }
        return null
    }

    private fun getTranScreenshotWallpaper(context: Context, wallpaperInfo: WallpaperInfo) : Bitmap?{
        LogUtils.i("getTranScreenshotWallpaper: ${wallpaperInfo.serviceName}")
        if ((wallpaperInfo.serviceName == PHOTO_MASTER_NAME
                    || wallpaperInfo.serviceName == PHOTO_MASTER_NAME_SECOND)
        ) {
            return getPicFromPhotoMaster(
                    context,
                    WALLPAPER_PATH
                )
        } else if ((wallpaperInfo.serviceName == PERSON_NAME_SECOND
                    || wallpaperInfo.serviceName == PERSON_NAME)
        ) {
            return getPicFromPhotoMaster(
                    context,
                    WALLPAPER_PATH_PERSON
                )
        } else if (wallpaperInfo.serviceName == CUTE_PET) {
            return getPicFromPhotoMaster(
                    context,
                    WALLPAPER_PATH_CUTE_PET
                )
        }else if (wallpaperInfo.serviceName == CUSTOM_PICTORIAL) {
                return getCustomPictorialWallpaper(
                        context,
                        WALLPAPER_AUTHOR
                )
        } else if(wallpaperInfo.serviceName == STAR_RING_SERVICE) {
            return getPicFromStarRing(
                context,
                WALLPAPER_STAR_RING_PROVIDER
            )
        } else if(wallpaperInfo.serviceName == SUN_POINTER_SERVICE) {
            return getPicFromStarRing(
                context,
                WALLPAPER_SUN_POINTER_PROVIDER
            )
        } else if (wallpaperInfo.serviceName == LIVE_PHOTO) {
            return getLivePhotoWallpaper(context, LIVE_PHOTO_AUTHOR)
        } else if (wallpaperInfo.serviceName == AI_WALLPAPER_SERVICE) {
            return getLivePhotoWallpaper(context, AI_WALLPAPER_AUTHOR)
        } else if (wallpaperInfo.serviceName == FAKE_3D_SERVICE) {
            return getLivePhotoWallpaper(context, FAKE_3D_AUTHOR)
        }
        return null
    }

    private fun getPicFromPhotoMaster(context: Context, path: String?): Bitmap? {
        val NOTIFY_URI = Uri.parse(path)
        var uri: String? = null
        val cursor = context.contentResolver.query(NOTIFY_URI, null, null, null, null)
        if (cursor != null) {
            while (cursor.moveToNext()) {
                uri = cursor.getString(0)
                Log.d(
                    TAG,
                    "preview custom wallpaper uri=$uri"
                )
            }
            cursor.close()
        }
        try {
            context.contentResolver.openInputStream(Uri.parse(uri)).use { inputStream ->
                return BitmapFactory.decodeStream(inputStream)
            }
        } catch (e: java.lang.Exception) {
            LogUtils.e(e.message)
            return null
        }
    }

    private fun getPicFromStarRing(context: Context, path: String?): Bitmap? {
        try {
            val NOTIFY_URI = path?.toUri() ?: return null
            var imageByte: ByteArray ?= null
            val cursor = context.contentResolver.query(NOTIFY_URI, null, null, null, null)
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    imageByte = cursor.getBlob(0)
                }
                cursor.close()
            }
            return imageByte?.run {
                BitmapFactory.decodeByteArray(this, 0, size)
            }
        } catch (e: java.lang.Exception) {
            LogUtils.e(e.message)
            return null
        }
    }

    private fun getCustomPictorialWallpaper(context: Context, author: String): Bitmap? {
        var uri: Uri? = null
        val bundle = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.contentResolver.call(
                author,
                "getLauncherWallpaper", null, null
            )
        } else {
            return null
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && bundle != null) {
            uri = bundle.getParcelable("current_wallpaper", Uri::class.java)
        }
        if (uri == null) {
            LogUtils.e(
                TAG,
                "getCustomPictorialWallpaper: uri is null, return null"
            )
            return null
        }

        var result: Bitmap? = null
        try {
            context.contentResolver.openInputStream(uri).use { inputStream ->
                result = BitmapFactory.decodeStream(inputStream)
            }
        } catch (e: Exception) {
            LogUtils.e(
                TAG,
                "getCustomPictorialWallpaper: e = $e"
            )
        }
        return result
    }

    private fun getLivePhotoWallpaper(context: Context, author: String): Bitmap? {
        var uri: Uri? = null
        val bundle = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.contentResolver.call(author, "getLauncherWallpaper", null, null)
        } else {
            return null
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && bundle != null) {
            uri = bundle.getParcelable("current_wallpaper", Uri::class.java)
        }
        if (uri == null) {
            LogUtils.e(TAG, "getLivePhotoWallpaper: uri is null, author=$author")
            return null
        }
        var result: Bitmap? = null
        try {
            context.contentResolver.openInputStream(uri).use { inputStream ->
                result = BitmapFactory.decodeStream(inputStream)
            }
        } catch (e: Exception) {
            LogUtils.e(TAG, "getLivePhotoWallpaper: e = $e")
        }
        return result
    }

    private fun getBitmapFromBitmapDrawable(d: Drawable?): Bitmap? {
        if (d is BitmapDrawable) {
            val bitmap = d.bitmap
            if (bitmap != null && !bitmap.isRecycled) {
                return bitmap
            }
        }
        return null
    }

    private fun computeImageHash(bitmap: Bitmap?): String {
        if (bitmap == null || bitmap.isRecycled) {
            return ""
        }
        try {
            val bitmap8 = ThumbnailUtils.extractThumbnail(bitmap, 8, 8) // 缩小
            val bitmapG: Bitmap? =
                convertGreyImg(bitmap8) // 灰度图像
            bitmapG?.let {
                val avgColor: Int =
                    getAvg(bitmapG)
                return bs2hex2(
                    getBinary(
                        bitmapG,
                        avgColor
                    )
                ) + Integer.toHexString(
                    avgColor and 0xFF
                )
            }
        } catch (e: java.lang.Exception) {
            Log.e(
                TAG,
                "computImageHash exception-->$e"
            )
        }
        return ""
    }

    /**
     * 将彩色图转换为灰度图
     *
     * @param img 位图
     * @return 返回转换好的位图
     */
    private fun convertGreyImg(img: Bitmap): Bitmap? {
        val width = img.width //获取位图的宽
        val height = img.height //获取位图的高
        val pixels = IntArray(width * height) //通过位图的大小创建像素点数组
        img.getPixels(pixels, 0, width, 0, 0, width, height)
        val alpha = 0xFF shl 24
        for (i in 0 until height) {
            for (j in 0 until width) {
                val original = pixels[width * i + j]
                val red = original and 0x00FF0000 shr 16
                val green = original and 0x0000FF00 shr 8
                val blue = original and 0x000000FF
                var grey =
                    (red.toFloat() * 0.3 + green.toFloat() * 0.59 + blue.toFloat() * 0.11).toInt()
                grey = alpha or (grey shl 16) or (grey shl 8) or grey
                pixels[width * i + j] = grey
            }
        }
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        result.setPixels(pixels, 0, width, 0, 0, width, height)
        return result
    }

    private fun getAvg(img: Bitmap): Int {
        val width = img.width
        val height = img.height
        val pixels = IntArray(width * height)
        img.getPixels(pixels, 0, width, 0, 0, width, height)
        var avgPixel = 0
        for (pixel in pixels) {
            avgPixel += pixel
        }
        return avgPixel / pixels.size
    }

    private fun getBinary(img: Bitmap, average: Int): String? {
        val sb = StringBuilder()
        val width = img.width
        val height = img.height
        val pixels = IntArray(width * height)
        img.getPixels(pixels, 0, width, 0, 0, width, height)
        for (i in 0 until height) {
            for (j in 0 until width) {
                val index = width * i + j
                val original = pixels[index]
                val diff = if (original >= average) 1 else 0
                sb.append(diff)
            }
        }
        return sb.toString()
    }

    private fun bs2hex2(bs: String?): String? {
        if (bs == null || bs == "" || bs.length % 8 != 0) {
            return null
        }
        val sb = java.lang.StringBuilder()
        var i = 0
        while (i < bs.length) {
            val `in` = bs.substring(i, i + 4).toInt(2)
            sb.append(HEXS[`in`])
            i += 4
        }
        return sb.toString()
    }

    private fun getBlurWallpaperFile(context: Context): File? {
        val files: Array<out File>? = getBlurWallpaperDir(context).listFiles()
        return if (files != null && files.isNotEmpty()) files[0] else null
    }

    private fun getBlurWallpaperDir(context: Context): File {
        val dirPath = context.filesDir.toString() + File.separator + "bluredWallpaper"
        val dir = File(dirPath)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * 裁剪图片
     * @param srcBitmap
     * @param targetWidth
     * @param targetHeight
     * @param alienLocal true:根据语言裁剪 。 false：居中裁剪
     * @param isTextRtl  若alienLocal true，才用到该属性。isTextRtl true：反向向语言裁剪右边，isTextRtl false：正向语言裁剪左边
     * @return
     */
    private fun cropWallpaperAlignLocale(
        srcBitmap: Bitmap,
        targetWidth: Int,
        targetHeight: Int,
        alienLocal: Boolean,
        isTextRtl: Boolean
    ): Bitmap? {
        if (isBitmapRecycled(srcBitmap)) {
            return null
        }
        var result: Bitmap? = srcBitmap
        val srcWidth = srcBitmap.width
        val srcHeight = srcBitmap.height
        val scaleWidth = targetWidth.toFloat() / srcWidth
        val scaleHeight = targetHeight.toFloat() / srcHeight
        val scaledWidth: Int
        val scaledHeight: Int
        if (scaleWidth >= scaleHeight) {
            scaledWidth = targetWidth
            scaledHeight = srcHeight * targetWidth / srcWidth
        } else {
            scaledWidth = srcWidth * targetHeight / srcHeight
            scaledHeight = targetHeight
        }
        result = Bitmap.createScaledBitmap(
            srcBitmap,
            scaledWidth, scaledHeight, true
        )
        var x = 0
        var y = 0
        var width = 0
        var heigth = 0
        if (targetWidth > scaledWidth) {
            width = scaledWidth
        } else {
            width = targetWidth
            if (alienLocal) {
                if (isTextRtl) {
                    x = scaledWidth - targetWidth
                }
            } else {
                x = (scaledWidth - targetWidth) / 2
            }
        }
        if (targetHeight > scaledHeight) {
            heigth = scaledHeight
        } else {
            heigth = targetHeight
            y = (scaledHeight - targetHeight) / 2
        }
        val original: Bitmap = result
        result = Bitmap.createBitmap(original, x, y, width, heigth)
        return result
    }

    private fun isBitmapRecycled(bitmap: Bitmap?): Boolean {
       return bitmap == null || bitmap.isRecycled
    }

    private fun isValidWallpaper(context: Context, drawable: Drawable?): Boolean {
        if (drawable == null) return false
        return try {
            val realSize = getRealSize(context)
            LogUtils.d(TAG, "isValidWallpaper: realSize.x = ${realSize.x}, realSize.y = ${realSize.y}" +
                    ", wallpaper width = ${drawable.intrinsicWidth}, wallpaper height = ${drawable.intrinsicHeight}")
            if (realSize.x > 0 && realSize.y > 0) {
                !(realSize.x - drawable.intrinsicWidth >= LARGE_DISTANCE
                        || realSize.y - drawable.intrinsicHeight >= LARGE_DISTANCE)
            } else true
        } catch (e: Exception) {
            LogUtils.e(TAG, "isValidWallpaper: e = $e")
            true
        }
    }

    private fun saveBitmap(parent: File, name: String, bitmap: Bitmap?) {
        if (bitmap == null || bitmap.isRecycled) {
            return
        }
        if (!parent.exists()) {
            parent.mkdirs()
        }
        var out: FileOutputStream? = null
        try {
            for (file in parent.listFiles()) {
                file?.delete()
            }
            val file = File(parent, name)
            out = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
            out.close()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        } finally {
            if (out != null) {
                try {
                    out.close()
                } catch (_: IOException) {
                }
            }
        }
    }


    private fun getBlurWallpaperDrawable(): Drawable? {
        val drawable = getCurrentWallpaper()
        drawable?.let {
            val bitmap = getBitmapFromBitmapDrawable(it)
            bitmap?.let { bm ->
                if (!bm.isRecycled) {
                    val bitmapHash: String = computeImageHash(bm)
                    val blurWallpaperFile: File? =
                        getBlurWallpaperFile(TRApplicationContextUtil.getInstance())
                    if (blurWallpaperFile == null || bitmapHash != blurWallpaperFile.name) {
                        var bitmap: Bitmap?
                        try {
                            val realSize: Point = DeviceProfile.getInstance()
                                .getRealSize(TRApplicationContextUtil.getInstance())
                            var cropBitmap: Bitmap? = null
                            if (realSize.x > 0 && realSize.y > 0) {
                                //图片等比缩放后,居中裁剪
                                cropBitmap = cropWallpaperAlignLocale(
                                    bm,
                                    realSize.x,
                                    realSize.y,
                                    false,
                                    false
                                )
                            }
                            if (cropBitmap == null) {
                                cropBitmap = bm
                            }
                            bitmap = BlurUtil.blur(
                                TRApplicationContextUtil.getInstance(),
                                cropBitmap,
                                cropBitmap.width,
                                cropBitmap.height
                            )
                        } catch (e: java.lang.Exception) {
                            bitmap = BlurUtil.blur(
                                TRApplicationContextUtil.getInstance(), bm,
                                bm.getWidth(), bm.getHeight()
                            )
                            LogUtils.d("blur wallpaper:$e")
                        }

                        bitmap?.let { blurBitmap ->
                            mBlurBitmap = blurBitmap
                            saveBitmap(
                                getBlurWallpaperDir(TRApplicationContextUtil.getInstance()),
                                bitmapHash,
                                blurBitmap
                            )
                            return BitmapDrawable(blurBitmap)
                        }
                    } else {
                        mBlurBitmap = BitmapFactory.decodeFile(blurWallpaperFile.absolutePath)
                        if (!isBitmapRecycled(mBlurBitmap)) {
                            return LayerDrawable(
                                arrayOf(
                                    BitmapDrawable(
                                        TRApplicationContextUtil.getInstance().resources,
                                        mBlurBitmap
                                    ), maskDrawable
                                )
                            )
                        } else {
                            LogUtils.d("getBlurDrawable #show file decode error")
                        }
                    }
                }
            }
        }
        return null
    }

    fun checkPaletteTopLightness(bitmap: Bitmap): Int {
        return try {
            val width: Int =
                bitmap.width / MAX_BITMAP_ZOOM
            val height: Int =
                bitmap.height / MAX_BITMAP_ZOOM
            val oneTenthHeight = height / 10
            val oneTenthWidth = height / 2
            val area = width * height
            //Rect mid = new Rect(0, oneTenthHeight, width, height - oneTenthHeight);
            val top = Rect(0, 0, oneTenthWidth, oneTenthHeight)
            // Rect bottom = new Rect(0, oneTenthHeight * 9, width, height);
            // int midRgb = getRectRgb(bitmap, mid, area);
            val topRgb: Int = getRectRgb(
                bitmap,
                top,
                area
            )
            // int bottomRgb = getRectRgb(bitmap, bottom, area);
            //Log.d("checkPaletteLightness", ",topRgb:" + topRgb + ",midRgb :" + midRgb + ", bottomRgb:" + bottomRgb);
            Log.d("checkPaletteLightness", ",topRgb:$topRgb")
            //暂时要求顶部&底部&中间全都需满足阈值条件，后续上中下分别区分颜色值。
            if (topRgb > GREY_COLOR_MIDDLE) Lightness.LIGHT else Lightness.DARK
            //return midRgb > GREY_COLOR_MIDDLE && topRgb > GREY_COLOR_MIDDLE && bottomRgb > GREY_COLOR_MIDDLE ? Lightness.LIGHT : Lightness.DARK;
        } catch (e: Throwable) {
            Lightness.UNKNOWN
        }
    }

    private fun getRectRgb(bitmap: Bitmap, rect: Rect, area: Int): Int {
        return try {
            val palette = Palette.from(bitmap)
                .clearFilters()
                .resizeBitmapArea(area)
                .setRegion(rect.left, rect.top, rect.right, rect.bottom)
                .generate()
            val swatch = palette.dominantSwatch
            if (swatch != null) covertGreyColor(
                swatch.rgb
            ) else 0
        } catch (e: Throwable) {
            Log.d("getRectRgb", e.toString())
            0
        }
    }

    /**
     * 转换成灰度颜色
     * @param color
     * @return
     */
    private fun covertGreyColor(@ColorInt color: Int): Int {
        return (Color.red(color) * 0.3 + Color.green(color) * 0.59 + Color.blue(color) * 0.11).toInt()
    }

    /**
     * 设置状态栏导航栏反色,必须在Activity onWindowFocusChanged存在焦点时调用
     * @param activity
     * @param darkMode
     */
    @MainThread
    fun setDarkMode(activity: Activity?, darkMode: Boolean) {
        if (activity == null) {
            Log.e(
                TAG,
                "setDarkMode activity is null!! "
            )
            return
        }
        val window = activity.window ?: return
        if (!activity.hasWindowFocus()) {
            Log.d(
                TAG,
                "setDarkMode activity do not hasWindowFocus! $activity"
            )
        }
        val decorView = window.decorView
        val oldUiVisibility = decorView.systemUiVisibility
        var newUiVisibility = oldUiVisibility

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            newUiVisibility = if (darkMode) {
                newUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            } else {
                newUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            }
        }

        if (hasNavBar(window.context) == true) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                newUiVisibility = if (darkMode) {
                    newUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                } else {
                    newUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                }
            } else if (supportNavbarDarkModeReflection() == true) {
                newUiVisibility = if (darkMode) {
                    newUiVisibility or sDarkModeFlag
                } else {
                    newUiVisibility and sDarkModeFlag.inv()
                }
            }
        }
        if (oldUiVisibility != newUiVisibility) {
            decorView.systemUiVisibility = newUiVisibility
        }
    }

    fun hasNavBar(context: Context): Boolean? {
        if (sHasNavbar != null) {
            return sHasNavbar
        }
        val res = context.resources
        val resourceId = res.getIdentifier(
            SHOW_NAV_BAR_RES_NAME,
            "bool",
            "android"
        )
        return if (resourceId != 0) {
            var hasNav = res.getBoolean(resourceId)
            // check override flag (see static block)
            if ("1" == sNavBarOverride) {
                hasNav = false
            } else if ("0" == sNavBarOverride) {
                hasNav = true
            }
            sHasNavbar = hasNav
            sHasNavbar
        } else { // fallback
            sHasNavbar =
                !ViewConfiguration.get(context).hasPermanentMenuKey()
            sHasNavbar
        }
    }

    private fun supportNavbarDarkModeReflection(): Boolean? {
        if (sSupportNavbarDarkModeReflection == null) {
            try {
                val filed = View::class.java.getField("SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR")
                sDarkModeFlag = filed.getInt(
                    View::class.java
                )
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
                sDarkModeFlag = 0
            }
            sSupportNavbarDarkModeReflection = sDarkModeFlag != 0
        }
        return sSupportNavbarDarkModeReflection
    }

}


object BlurUtil {
    private const val TAG = "BlurUtil"
    const val DEFAULT_BLUR_RADIUS = 25
    const val DEFAULT_BLUR_SCALE = 8
    @JvmOverloads
    fun blur(
        context: Context?,
        bitmap: Bitmap?,
        width: Int,
        height: Int,
        radius: Int = DEFAULT_BLUR_RADIUS,
        scaleFactor: Int = DEFAULT_BLUR_SCALE
    ): Bitmap? {
        var bitmap = bitmap ?: return null
        return try {
            bitmap = Bitmap.createScaledBitmap(
                bitmap, width / scaleFactor,
                height / scaleFactor, true
            )
            var overlay = Bitmap.createBitmap(
                width / scaleFactor,
                height / scaleFactor, Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(overlay)
            cropCanvas(canvas, bitmap, overlay)
            val paint = Paint()
            paint.flags = Paint.FILTER_BITMAP_FLAG
            canvas.drawBitmap(bitmap, 0f, 0f, paint)
            //overlay = doBlur(overlay,radius);
            overlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                try {
                    RSBlur.blur(context, overlay, radius)
                } catch (e: RSRuntimeException) {
                    FastBlur.blur(overlay, radius, true)
                }
            } else {
                FastBlur.blur(overlay, radius, true)
            }
            overlay
        } catch (e: java.lang.Exception) {
            LogUtils.e("BlurUtil blur error : $e")
            null
        }
    }

    private fun cropCanvas(canvas: Canvas, bitmap: Bitmap, overlay: Bitmap) {
        val bWidth = bitmap.width
        val bHeight = bitmap.height

        //目标长宽
        val oWidth = overlay.width
        val oHeight = overlay.height
        var scaledWidth = bWidth * oHeight / bHeight //按高度缩放后的宽度值
        var scaledHeight = bHeight * oWidth / bWidth //按宽度缩放后的高度值
        if (scaledWidth <= oWidth) { //按宽度进行缩放
            scaledWidth = oWidth
        } else {
            scaledHeight = oHeight
        }
        val scale = scaledWidth.toFloat() / bWidth
        val x = if (scaledWidth > oWidth) (scaledWidth - oWidth) / 2 else 0
        val y = if (scaledHeight > oHeight) (scaledHeight - oHeight) / 2 else 0
        canvas.translate(-x.toFloat(), -y.toFloat())
        canvas.scale(scale, scale)
    }
}


object RSBlur {
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Throws(
        RSRuntimeException::class
    )
    fun blur(context: Context?, bitmap: Bitmap, radius: Int): Bitmap {
        var rs: RenderScript? = null
        var input: Allocation? = null
        var output: Allocation? = null
        var blur: ScriptIntrinsicBlur? = null
        try {
            rs = RenderScript.create(context)
            rs.messageHandler = RenderScript.RSMessageHandler()
            input = Allocation.createFromBitmap(
                rs, bitmap, Allocation.MipmapControl.MIPMAP_NONE,
                Allocation.USAGE_SCRIPT
            )
            output = Allocation.createTyped(rs, input.type)
            blur = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
            blur.setInput(input)
            blur.setRadius(radius.toFloat())
            blur.forEach(output)
            output.copyTo(bitmap)
        } catch (e: java.lang.Exception) {
            LogUtils.e("blur err:$e")
        } finally {
            rs?.destroy()
            input?.destroy()
            output?.destroy()
            blur?.destroy()
        }
        return bitmap
    }

}


object FastBlur {
    fun blur(sentBitmap: Bitmap, radius: Int, canReuseInBitmap: Boolean): Bitmap {

        // Stack Blur v1.0 from
        // http://www.quasimondo.com/StackBlurForCanvas/StackBlurDemo.html
        //
        // Java Author: Mario Klingemann <mario at quasimondo.com>
        // http://incubator.quasimondo.com
        // created Feburary 29, 2004
        // Android port : Yahel Bouaziz <yahel at kayenko.com>
        // http://www.kayenko.com
        // ported april 5th, 2012

        // This is a compromise between Gaussian Blur and Box blur
        // It creates much better looking blurs than Box Blur, but is
        // 7x faster than my Gaussian Blur implementation.
        //
        // I called it Stack Blur because this describes best how this
        // filter works internally: it creates a kind of moving stack
        // of colors whilst scanning through the image. Thereby it
        // just has to add one new block of color to the right side
        // of the stack and remove the leftmost color. The remaining
        // colors on the topmost layer of the stack are either added on
        // or reduced by one, depending on if they are on the right or
        // on the left side of the stack.
        //
        // If you are using this algorithm in your code please add
        // the following line:
        //
        // Stack Blur Algorithm by Mario Klingemann <mario@quasimondo.com>
        val bitmap: Bitmap = if (canReuseInBitmap) {
            sentBitmap
        } else {
            sentBitmap.copy(sentBitmap.config ?: Bitmap.Config.ARGB_8888, true)
        }
        if (radius < 1) {
            return sentBitmap
        }
        val w = bitmap.width
        val h = bitmap.height
        val pix = IntArray(w * h)
        bitmap.getPixels(pix, 0, w, 0, 0, w, h)
        val wm = w - 1
        val hm = h - 1
        val wh = w * h
        val div = radius + radius + 1
        val r = IntArray(wh)
        val g = IntArray(wh)
        val b = IntArray(wh)
        var rsum: Int
        var gsum: Int
        var bsum: Int
        var x: Int
        var y: Int
        var i: Int
        var p: Int
        var yp: Int
        var yi: Int
        var yw: Int
        val vmin = IntArray(Math.max(w, h))
        var divsum = div + 1 shr 1
        divsum *= divsum
        val dv = IntArray(256 * divsum)
        i = 0
        while (i < 256 * divsum) {
            dv[i] = i / divsum
            i++
        }
        yi = 0
        yw = yi
        val stack = Array(div) {
            IntArray(
                3
            )
        }
        var stackpointer: Int
        var stackstart: Int
        var sir: IntArray
        var rbs: Int
        val r1 = radius + 1
        var routsum: Int
        var goutsum: Int
        var boutsum: Int
        var rinsum: Int
        var ginsum: Int
        var binsum: Int
        y = 0
        while (y < h) {
            bsum = 0
            gsum = bsum
            rsum = gsum
            boutsum = rsum
            goutsum = boutsum
            routsum = goutsum
            binsum = routsum
            ginsum = binsum
            rinsum = ginsum
            i = -radius
            while (i <= radius) {
                p = pix[yi + Math.min(wm, Math.max(i, 0))]
                sir = stack[i + radius]
                sir[0] = p and 0xff0000 shr 16
                sir[1] = p and 0x00ff00 shr 8
                sir[2] = p and 0x0000ff
                rbs = r1 - Math.abs(i)
                rsum += sir[0] * rbs
                gsum += sir[1] * rbs
                bsum += sir[2] * rbs
                if (i > 0) {
                    rinsum += sir[0]
                    ginsum += sir[1]
                    binsum += sir[2]
                } else {
                    routsum += sir[0]
                    goutsum += sir[1]
                    boutsum += sir[2]
                }
                i++
            }
            stackpointer = radius
            x = 0
            while (x < w) {
                r[yi] = dv[rsum]
                g[yi] = dv[gsum]
                b[yi] = dv[bsum]
                rsum -= routsum
                gsum -= goutsum
                bsum -= boutsum
                stackstart = stackpointer - radius + div
                sir = stack[stackstart % div]
                routsum -= sir[0]
                goutsum -= sir[1]
                boutsum -= sir[2]
                if (y == 0) {
                    vmin[x] = Math.min(x + radius + 1, wm)
                }
                p = pix[yw + vmin[x]]
                sir[0] = p and 0xff0000 shr 16
                sir[1] = p and 0x00ff00 shr 8
                sir[2] = p and 0x0000ff
                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]
                rsum += rinsum
                gsum += ginsum
                bsum += binsum
                stackpointer = (stackpointer + 1) % div
                sir = stack[stackpointer % div]
                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]
                rinsum -= sir[0]
                ginsum -= sir[1]
                binsum -= sir[2]
                yi++
                x++
            }
            yw += w
            y++
        }
        x = 0
        while (x < w) {
            bsum = 0
            gsum = bsum
            rsum = gsum
            boutsum = rsum
            goutsum = boutsum
            routsum = goutsum
            binsum = routsum
            ginsum = binsum
            rinsum = ginsum
            yp = -radius * w
            i = -radius
            while (i <= radius) {
                yi = Math.max(0, yp) + x
                sir = stack[i + radius]
                sir[0] = r[yi]
                sir[1] = g[yi]
                sir[2] = b[yi]
                rbs = r1 - Math.abs(i)
                rsum += r[yi] * rbs
                gsum += g[yi] * rbs
                bsum += b[yi] * rbs
                if (i > 0) {
                    rinsum += sir[0]
                    ginsum += sir[1]
                    binsum += sir[2]
                } else {
                    routsum += sir[0]
                    goutsum += sir[1]
                    boutsum += sir[2]
                }
                if (i < hm) {
                    yp += w
                }
                i++
            }
            yi = x
            stackpointer = radius
            y = 0
            while (y < h) {

                // Preserve alpha channel: ( 0xff000000 & pix[yi] )
                pix[yi] =
                    -0x1000000 and pix[yi] or (dv[rsum] shl 16) or (dv[gsum] shl 8) or dv[bsum]
                rsum -= routsum
                gsum -= goutsum
                bsum -= boutsum
                stackstart = stackpointer - radius + div
                sir = stack[stackstart % div]
                routsum -= sir[0]
                goutsum -= sir[1]
                boutsum -= sir[2]
                if (x == 0) {
                    vmin[y] = Math.min(y + r1, hm) * w
                }
                p = x + vmin[y]
                sir[0] = r[p]
                sir[1] = g[p]
                sir[2] = b[p]
                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]
                rsum += rinsum
                gsum += ginsum
                bsum += binsum
                stackpointer = (stackpointer + 1) % div
                sir = stack[stackpointer]
                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]
                rinsum -= sir[0]
                ginsum -= sir[1]
                binsum -= sir[2]
                yi += w
                y++
            }
            x++
        }
        bitmap.setPixels(pix, 0, w, 0, 0, w, h)
        return bitmap
    }
}

object Lightness {
    const val LIGHT = 0
    const val DARK = 1
    const val UNKNOWN = 2

    @Retention(AnnotationRetention.SOURCE)
    @IntDef(LIGHT, DARK, UNKNOWN)
    annotation class LightnessValues

    @Retention(AnnotationRetention.SOURCE)
    @IntDef(LIGHT, DARK)
    annotation class LightnessNoUnknown
}
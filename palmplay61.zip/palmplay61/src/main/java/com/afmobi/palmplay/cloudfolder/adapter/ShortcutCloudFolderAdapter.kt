package com.afmobi.palmplay.cloudfolder.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_CENTER
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.PaletteControls
import com.afmobi.palmplay.cloudfolder.utils.drawableToBitmap
import com.afmobi.palmplay.customview.DownloadStatusView
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.download.DownloadUtil
import com.afmobi.palmplay.download.InterfaceStatusChange
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.transsion.palmstorecore.glide.GlideApp
import com.transsion.palmstorecore.glide.GlideUtils
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.launcherlib.config.Constants.FILE_FOLDER_FROM_SITE_APP
import com.transsnet.launcherlib.config.Constants.FILE_FOLDER_FROM_SITE_GAME
import com.transsnet.store.BuildConfig
import com.transsnet.store.R


class ShortcutCloudFolderAdapter(context: Context, val categoryType: Int) :
    PalmBaseDownloadRecyclerViewAdapter(), View.OnLongClickListener {
    private val mContext: Context
    private var mListData: MutableList<CloudAppInfo> = ArrayList() //数据
    private var gridLayoutManager: GridLayoutManager? = null

    private val isShowMark : Boolean by lazy {
        CloudFolderManager.getInstance().isIconMaskShow()
    }

    private val markAlpha : Float by lazy {
        CloudFolderManager.getInstance().getCloudFolderDownAlpha()
    }

    private val paletteControls : PaletteControls by lazy {
        PaletteControls.getInstance(PalmplayApplication.getAppInstance())
    }

    //自定义监听事件
    interface OnRecyclerViewItemClickListener {
        fun onItemLongClick(view: View?)

        fun onItemClick(appInfo: AppInfo)
    }

    private var mOnItemClickListener: OnRecyclerViewItemClickListener? = null
    fun setOnItemClickListener(listener: OnRecyclerViewItemClickListener?) {
        mOnItemClickListener = listener
    }

    //适配器初始化
    init {
        mContext = context.applicationContext
        mFrom = if(categoryType == CATEGORY_APP) FILE_FOLDER_FROM_SITE_APP else FILE_FOLDER_FROM_SITE_GAME
    }

    fun setListData(list: List<CloudAppInfo>?) {
        if (!list.isNullOrEmpty()) {
            mListData.clear()
            mListData.addAll(list)
        }
        notifyDataSetChanged()
    }

    fun getAppInfo(position: Int): CloudAppInfo? {
        return if (position < mListData.size) {
            mListData[position]
        } else null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View =
            LayoutInflater.from(mContext).inflate(R.layout.cloud_folder_shortcut_items, parent, false)
        return ShortcutsViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val appInfo = getAppInfo(position) ?: return
        appInfo.placementId = position.toString()
        val imgUrl = appInfo.iconUrl

        holder as ShortcutsViewHolder
        paletteControls.updateTextShadow(holder.itemName)
        LogUtils.d("CloudShortcutAdapter ----- onBindViewHolder ：  ${appInfo.observerStatus}   ---   ${appInfo.packageName}")
        if(appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
            holder.itemIcon.setBackgroundResource(R.drawable.shortcut_icon_bg)
            if(isShowMark) {
                holder.viewMark.visibility = View.VISIBLE
                holder.viewMark.alpha = markAlpha
            } else {
                holder.viewMark.visibility = View.GONE
            }
        } else {
            holder.itemIcon.setBackgroundResource(0)
            holder.viewMark.visibility = View.GONE

        }
        GlideApp.with(PalmplayApplication.getAppInstance())
            .load(imgUrl)
            .apply(GlideUtils.newCommonRequestOptions())
            .addListener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    if (resource == null) {
                        return false
                    }
                    val resultBitmap = drawableToBitmap(resource)
                    holder.itemIcon.setImageBitmap(resultBitmap)
                    appInfo.hasLoaded = true
                    if (appInfo.observerStatus == FileDownloadInfo.STATUS_NONE || appInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
                        holder.ivDefaultIcon.visibility =
                            View.VISIBLE
                    } else {
                        holder.ivDefaultIcon.visibility =
                            View.GONE
                    }
                    return true
                }

            })
            .into(holder.itemIcon)
        checkStatus(
            appInfo,
            holder.itemName,
            holder.ivDefaultIcon,
            holder.statusView,
            holder.viewMark
        )
        holder.itemView.tag = position
        holder.itemView.setOnLongClickListener { v ->
            mOnItemClickListener?.onItemLongClick(v)
            true
        }
        holder.itemView.setOnClickListener(View.OnClickListener { v ->
            if (appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING) {
                return@OnClickListener
            }
            if (FileDownloadInfo.isDownloading(appInfo.observerStatus)) {
                DownloadManager.getInstance().onDownloadingPauseByUser(appInfo.packageName, false, true)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_PAUSE, appInfo, position)
                mOnItemClickListener?.onItemClick(appInfo)
            } else if (FileDownloadInfo.STATUS_PAUSE == appInfo.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == appInfo.observerStatus) {
                DownloadUtil.resumeDownload(mContext, appInfo.packageName)
                trackClickWithParams(
                    CloudFolderTrackUtil.BUTTON_TYPE_RESUME,
                    appInfo,
                    position
                )
            } else {
                if (FileDownloadInfo.STATUS_NONE == appInfo.observerStatus) { //下载
                    trackClickWithParams(
                        CloudFolderTrackUtil.BUTTON_TYPE_INSTALL,
                        appInfo,
                        position
                    )
                }
                val sign = if (categoryType == CATEGORY_APP) "A" else "G"
                val fromPage = "FL_${sign}_${SCENE_CENTER}_$position"
                CloudFolderManager.getInstance().startDownload(appInfo, categoryType, fromPage)
            }
        })
    }

    private fun trackClickWithParams(eventName: String, appInfo: AppInfo?, position: Int) {
        if (appInfo == null) {
            return
        }
        CloudFolderTrackUtil.businessItemClickTrack(
            position,
            eventName,
            appInfo.packageName,
            categoryType,
            appInfo.isOffer
        )

    }

    private fun checkStatus(
        appInfo: AppInfo?,
        itemName: TextView,
        iv_default_icon: ImageView,
        statusView: DownloadStatusView,
        markView: View
    ) {
        DownloadStatusManager.getInstance().registerInfoInstance(appInfo)
        if (appInfo?.observerStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
            // 文件下载完成，正在进行校验，此时不处理点击事件，页面显示进度100%
            if (BuildConfig.DEBUG) {
                Log.e("checkDownloadInfo", "文件下载完成，校验中...", Throwable("who call me"))
            }
            return
        }
        if (appInfo!!.observerStatus == FileDownloadInfo.STATUS_NONE) {
            itemName.text = appInfo.name
            statusView.setProgress(0f)
        } else if(appInfo.observerStatus == FileDownloadInfo.STATUS_WAIT) {
            itemName.text =
                PalmplayApplication.getAppInstance().getString(R.string.waiting)
        }else if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
            itemName.text =
                PalmplayApplication.getAppInstance().getString(R.string.text_downloading)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_PAUSE) {
            itemName.text = PalmplayApplication.getAppInstance().getString(R.string.paused)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED) {
            itemName.text = PalmplayApplication.getAppInstance().getString(R.string.click_install)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING) {
            itemName.text = PalmplayApplication.getAppInstance().getString(R.string.text_installing)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED) {
            itemName.text = appInfo.name
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
            itemName.text = appInfo.name
        }
        if (appInfo.observerStatus != FileDownloadInfo.STATUS_NONE && appInfo.observerStatus != FileDownloadInfo.STATUS_APP_UPDATE) {
            iv_default_icon.visibility = View.GONE
        } else {
            if (appInfo.hasLoaded) {
                iv_default_icon.visibility = View.VISIBLE
            }
        }
        if (appInfo.observerStatus == FileDownloadInfo.STATUS_WAIT || appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_PAUSE || appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED || appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
            statusView.visibility = View.VISIBLE
            markView.visibility = View.GONE
            statusView.setStatus(appInfo.observerStatus, true)
            if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) { //下载中出现网络错误，要保持下载中的UI样子不变
                statusView.setProgress(appInfo.progress)
            }
        } else {
            statusView.visibility = View.GONE
            if(isShowMark && appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
                markView.visibility = View.VISIBLE
            } else {
                markView.visibility = View.GONE
            }
        }
    }

    fun setGridLayoutManager(gridLayoutManager: GridLayoutManager?) {
        this.gridLayoutManager = gridLayoutManager
    }

    override fun loaderInterfaceStatusChangeObjectKey(): Any {
        return this
    }

    override fun loaderInterfaceStatusChange(): InterfaceStatusChange {
        return object : InterfaceStatusChange {
            override fun onDownloadStart(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadProgressUpdate(
                downloadInfo: FileDownloadInfo,
                downloadedBytes: Long,
                fileLength: Long,
                speed: Int
            ) {
                downloadProgressUpdate(downloadInfo, downloadedBytes, fileLength, speed)
            }

            override fun onDownloadComplete(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onActivated(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadError(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadPause(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadResume(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadDelete(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onAppPackageAdded(packageName: String, versionCode: Int) {
                notifyDataSetChangedWithInterfaceStatusChange(null, packageName)
            }

            override fun onAppPackageRemoved(
                packageName: String,
                versionCode: Int,
                modifyStatusFrom: Int
            ) {
                notifyDataSetChangedWithInterfaceStatusChange(null, packageName)
            }
        }
    }

    private fun downloadProgressUpdate(
        downloadInfo: FileDownloadInfo,
        downloadedBytes: Long,
        fileLength: Long,
        speed: Int
    ) {
        if (mListData.size > 0) {
            var item: AppInfo?
            for (i in mListData.indices) {
                item = mListData[i]
                if (!TextUtils.isEmpty(item.packageName) && item.packageName == downloadInfo.packageName) {
                    val view = gridLayoutManager!!.findViewByPosition(i)
                    if (view != null) {
                        val progress =
                            downloadInfo.downloadedSize / downloadInfo.sourceSize.toFloat()
                        item.progress = progress
                        (view.findViewById<View>(R.id.statusView) as DownloadStatusView).setProgress(
                            progress
                        )
                    }
                    break
                }
            }
        }
    }

    private fun notifyDataSetChangedWithInterfaceStatusChange(
        downloadInfo: FileDownloadInfo?,
        packageName: String?
    ) {
        /*if (mIMessenger != null)
            mIMessenger.onMessenger();*/
        val position: Int
        position = if (downloadInfo != null) {
            DownloadStatusManager.checkObserverData(mListData, downloadInfo, true)
        } else {
            DownloadStatusManager.checkObserverDataWithTypeApp(mListData, packageName, true)
        }
        if (position >= 0 && position < mListData.size) {
            val mAppInfo = mListData[position]
            val observerStatus = mAppInfo.observerStatus
            DownloadStatusManager.getInstance().registerInfoInstance(mAppInfo)
//            if (observerStatus == FileDownloadInfo.STATUS_WAIT && mAppInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING) {
//                //暂停后继续下载，两个状态，刷新两遍，可能导致icon不显示
//            } else {
//                notifyItemChanged(position)
//            }
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int {
        var count = 0
        if (mListData == null) {
            return count
        }
        count = mListData.size
        return count
    }

    override fun onLongClick(v: View): Boolean {
        if (mOnItemClickListener != null) {
            mOnItemClickListener!!.onItemLongClick(v)
        }
        return false
    }

    internal inner class ShortcutsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
         val itemName: TextView
         val itemIcon: ImageView
         val ivDefaultIcon: ImageView
         val viewMark: ImageView
         val statusView: DownloadStatusView

        init {
            itemName = view.findViewById<View>(R.id.tv_item_name) as TextView
            itemIcon = view.findViewById<View>(R.id.img_item_icon) as ImageView
            ivDefaultIcon = view.findViewById(R.id.iv_default_icon)
            viewMark = view.findViewById(R.id.view_mark)
            statusView = view.findViewById(R.id.statusView)
        }
    }
}
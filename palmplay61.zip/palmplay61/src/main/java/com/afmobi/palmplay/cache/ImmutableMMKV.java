package com.afmobi.palmplay.cache;

import android.util.Log;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.va.PsVaConstants;
import com.afmobi.util.Constant;
import com.tencent.mmkv.MMKV;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsnet.store.BuildConfig;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 基于MMKV的不可变配置
 * <p>
 * VA 全局配置，进程生命周期内不可变
 * <p>
 * VA客户端下发判断        gameSwitch
 * VA解耦能力下发        gameSpaceConfigInfo
 * H5是否支持VA        webGameSwitch
 */
public class ImmutableMMKV {

    private final static ConcurrentHashMap<String, Object> sConfigs = new ConcurrentHashMap<>();

    static {
        MMKV mmkv = MMKVUtils.getMMKV();
        sConfigs.put(Constant.KV_GAMESPACE_ENABLE, mmkv.getBoolean(Constant.KV_GAMESPACE_ENABLE, false));
        sConfigs.put(Constant.KV_GAMESPACE_SILENT_STATUS, mmkv.getBoolean(Constant.KV_GAMESPACE_SILENT_STATUS, false));
        sConfigs.put(Constant.KV_GAME_SWITCH, mmkv.getInt(Constant.KV_GAME_SWITCH, PsVaConstants.GameSwitch.SUPER_SEVERE));
        sConfigs.put(Constant.KV_GAMESPACE_MIN_VERSION, mmkv.getInt(Constant.KV_GAMESPACE_MIN_VERSION, PsVaConstants.VA_FEATURE.SUPPORT_COOPERATION_VERSION));
        sConfigs.put(Constant.KV_WEB_GAME_SWITCH, mmkv.getInt(Constant.KV_WEB_GAME_SWITCH, 0));
        if (BuildConfig.DEBUG) {
            Log.d("ImmutableMMKV", PalmplayApplication.getCurrentProcessName(PalmplayApplication.getAppInstance()) + " init: " + sConfigs.toString());
        }
    }


    public static int getInt(String key, int defaultValue) {
        return getImmutableValue(MMKVUtils.getMMKV(), key, defaultValue, Integer.class);
    }

    public static boolean getBoolean(String key, boolean defaultValue) {
        return getImmutableValue(MMKVUtils.getMMKV(), key, defaultValue, Boolean.class);
    }

    public static String getString(String key, String defaultValue) {
        return getImmutableValue(MMKVUtils.getMMKV(), key, defaultValue, String.class);
    }


    private static <T> T getImmutableValue(MMKV mmkv, String key, T defaultValue, Class<T> cls) {
        Object value = sConfigs.get(key);
        if (value != null) {
            if (cls == value.getClass()) {
                return (T) value;
            }
            return defaultValue;
        }
        synchronized (sConfigs) {
            value = sConfigs.get(key);
            if (value == null) {
                if (cls == int.class) {
                    value = mmkv.getInt(key);
                } else if (cls == boolean.class) {
                    value = mmkv.getBoolean(key, defaultValue == Boolean.TRUE);
                } else if (cls == String.class) {
                    value = mmkv.getString(key, (String) defaultValue);
                }
                sConfigs.put(key, value);
            }
        }
        if (BuildConfig.DEBUG) {
            LogUtils.d("read immutable config cache  key=" + key + " value=" + value + " type=" + cls.getSimpleName());
        }
        return (T) value;
    }
}

// TOP SECRET
package com.afmobi.palmplay.cache.v6_0;

import android.text.TextUtils;
import android.util.LruCache;

import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.model.ItemDetailSearchData;
import com.afmobi.palmplay.model.ScreenShotInfo;
import com.afmobi.palmplay.model.SearchRespInfo;
import com.afmobi.palmplay.model.TermInfo;
import com.afmobi.palmplay.model.CardContent;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.search.v6_4.SearchNoneEntity;
import com.afmobi.palmplay.search.v6_4.SearchType;
import com.transsnet.store.BuildConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SearchResultCache {

    private static String CACHE_URI = NetworkActions.ACTION_KEY_SERACH_ACTIVITY;

    private static volatile SearchResultCache mInstance;
    private static byte[] lock = new byte[0];

    private static final int MAX_CACHE_SIZE = 5;
    public static final int MAX_PAGE_SIZE = 24;//12;
    //是否是语音搜索类型，1：是，0不是
    public int searchType = 0;

    //Note: 暂时没有做根据类型区分, 需要的时候再实现根据DetailType来区分。
    private LruCache<String, SearchRespInfo> mAppListCache;

    private Map<String, SearchRespInfo> mPageIndexSearchRespInfo;

    private SearchResultCache() {
        mAppListCache = new LruCache<>(MAX_CACHE_SIZE);
        mPageIndexSearchRespInfo = new HashMap<>();
    }

    public static SearchResultCache getInstance() {
        if (mInstance == null) {
            synchronized (lock) {
                if (mInstance == null) {
                    mInstance = new SearchResultCache();
                }
            }
        }

        return mInstance;
    }

    public static void resetInstance() {
        mInstance = null;
    }


    private boolean isItemExist(SearchRespInfo respInfo, String pkg) {

        if (respInfo == null || respInfo.searchData == null || TextUtils.isEmpty(pkg)) {
            return false;
        }

        Iterator<ItemDetailSearchData> it = respInfo.searchData.iterator();
        while (it.hasNext()) {
            Object featureBeanObj = it.next();
            if (featureBeanObj instanceof FeatureBean) {
                FeatureBean fb = (FeatureBean) featureBeanObj;
                if (fb.dataList != null && !fb.dataList.isEmpty()) { //有结果推荐
                    int dataListSize = fb.dataList.size();
                    for (int i = 0; i < dataListSize; i++) {
                        FeatureItemData item = (FeatureItemData) fb.dataList.get(i);
                        if (TextUtils.equals(item.packageName, pkg)) {
                            return true;
                        }
                    }
                }
            } else if (featureBeanObj instanceof  ItemDetailSearchData) {
                ItemDetailSearchData item = (ItemDetailSearchData) featureBeanObj;
                if (TextUtils.equals(item.packageName, pkg)) {
                    return true;
                }
            }
        }

        return false;
    }

    private int getScreenShotMode(List<Integer> list, int pos) {
        if (list == null || list.isEmpty() || pos < 0) {
            return 0;
        }

        int len = list.size();

        return list.get(pos % len);
    }

    private void generateAndAddScreenShot(ItemDetailSearchData item, List<String> smallList, List<String> bigList, List<Integer> modeList) {

        if (smallList == null || smallList == null) {
            return;
        }

        if (item.screenShotList == null) {
            item.screenShotList = new ArrayList<>();
        }
        item.screenShotList.clear();

        int smallLen = smallList.size();
        int bigLen = bigList.size();
        for (int i = 0;i < smallLen && i < bigLen; i++) {
            String smallUrl = null;
            String bigUrl = null;
            try {
                smallUrl = smallList.get(i % smallLen);
                bigUrl = bigList.get(i % bigLen);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            ScreenShotInfo shotItem = new ScreenShotInfo();
            shotItem.type = getScreenShotMode(modeList, i);
            shotItem.smallImgUrl = smallUrl;
            shotItem.bigImgUrl = bigUrl;
            item.screenShotList.add(shotItem);
        }
    }

    /**
     * 为 cardContentList 中每个 screenImages 条目设置 imageOrientation。
     * <p>
     * orientation 不由服务端下发，而是按 screenImages 条目在列表中的顺序，
     * 从 {@link ItemDetailSearchData#imgModeList} 中依次取值，与
     * {@link #generateAndAddScreenShot} 中 {@link ScreenShotInfo#type} 的取值逻辑完全对称。
     * imgModeList 为空时 {@link #getScreenShotMode} 默认返回 0（竖屏）。
     */
    private void initCardContentOrientation(ItemDetailSearchData item) {
        if (item.cardContentList == null) return;
        int screenshotIndex = 0;
        for (CardContent card : item.cardContentList) {
            if (CardContent.DATA_TYPE_SCREEN_IMAGES.equals(card.dataType)) {
                card.imageOrientation = getScreenShotMode(item.imgModeList, screenshotIndex++);
            }
        }
    }

    private void initSearchItemData(SearchRespInfo respInfo, int pageIndex) {

        if (respInfo == null) {
            return;
        }

        //TODO: 将详情类型的图片构造出对应的队列
        if (respInfo.searchData != null) {
            List<String> smallList = new ArrayList<>();
            List<String> bigList = new ArrayList<>();
            Iterator<ItemDetailSearchData> it = respInfo.searchData.iterator();
            while (it.hasNext()) {
                ItemDetailSearchData item = it.next();
                item.pageIndex = pageIndex;
                item.translateType = respInfo.translateType;

                // cardContentList 中 screenImages 条目的方向由 imgModeList 决定，
                // 与 screenShotList 的 type 取值逻辑相同，客户端拼装，非服务端下发。
                initCardContentOrientation(item);

                if (!TextUtils.equals(item.dataStyle, ItemDetailSearchData.DATA_STYLE_DETAIL)) {
                    continue;
                }

                if (item.imgModeList == null) {
                    continue;
                }

                if (item.smallImgList == null && item.imgList == null) {
                    continue;
                }


                smallList.clear();
                bigList.clear();
                if (item.smallImgList == null) {
                    smallList.addAll(item.imgList);
                    bigList.addAll(item.imgList);
                }else if (item.imgList == null) {
                    smallList.addAll(item.smallImgList);
                    bigList.addAll(item.smallImgList);
                }else {
                    smallList.addAll(item.smallImgList);
                    bigList.addAll(item.imgList);
                }

                generateAndAddScreenShot(item, smallList, bigList, item.imgModeList);

            }
        }
    }

    public void initCache(SearchRespInfo respInfo, String searchKey, int pageIndex, int detailType) {
        if (respInfo == null || TextUtils.isEmpty(searchKey)) {
            return;
        }

        initSearchItemData(respInfo, pageIndex);

        mPageIndexSearchRespInfo.put(pageIndex + "", respInfo);

        String key = getCacheKey(searchKey, detailType);
        SearchRespInfo tagRespInfo = mAppListCache.get(key);

        if (pageIndex == 0) {

            if (tagRespInfo != null) {
                mAppListCache.remove(key);
            }
            tagRespInfo = respInfo;
            mAppListCache.put(key, tagRespInfo);

        }else {

            if (tagRespInfo == null) {
                tagRespInfo = new SearchRespInfo();
            }
            mAppListCache.put(key, tagRespInfo);

            if (respInfo.searchData != null) {
                Iterator<ItemDetailSearchData> it = respInfo.searchData.iterator();
                while (it.hasNext()) {
                    ItemDetailSearchData commonInfo = it.next();
                    if (isItemExist(tagRespInfo, commonInfo.packageName)) {
                        it.remove();
                        break;
                    }
                }


                if (respInfo.searchData.size() > 0) {
                    tagRespInfo.searchData.addAll(respInfo.searchData);
                }
            }

            tagRespInfo.pageIndex = respInfo.pageIndex;
            tagRespInfo.pageSum = respInfo.pageSum;
        }

        int size = respInfo.total;
        if (size < MAX_PAGE_SIZE && tagRespInfo.pageIndex >= respInfo.pageSum) {
            tagRespInfo.isPageLast = true;
        }
    }

    public List<?> getIndexAppInfoList(int pageIndex) {
        List srcList = null;//new ArrayList();

        if (mPageIndexSearchRespInfo != null) {
            SearchRespInfo tagItemList = mPageIndexSearchRespInfo.get(pageIndex + "");
            if (tagItemList != null && tagItemList.searchData != null) {
                srcList = tagItemList.searchData;
            }else {
                srcList = new ArrayList<ItemDetailSearchData>();
                if (tagItemList != null) {
                    tagItemList.searchData = srcList;
                }
            }

            if (tagItemList != null && tagItemList.searchRecommed != null && pageIndex == 0) {
                int extraType = tagItemList.getExtraType();
                List list = new ArrayList();
                if (extraType == 2) { //少结果 (展示搜索结果 + 推荐列表)
                    srcList.addAll(list);
                } else { //正常
                    int insertPosition = tagItemList.searchRecommed.position;
                    if (insertPosition < 0 || insertPosition >= srcList.size()) {
                        srcList.addAll(list);
                    }else {
                        srcList.addAll(insertPosition, list);
                    }
                }
            }
        }

        return srcList;
    }


    @SuppressWarnings("unchecked")
    public List<?> getAppInfoList(String key, int detailType) {
        List srcList = null;//new ArrayList();

        if (mAppListCache != null) {
            SearchRespInfo tagItemList = mAppListCache.get(getCacheKey(key, detailType));
            if (tagItemList != null && tagItemList.searchData != null) {
                srcList = tagItemList.searchData;
            }else {
                srcList = new ArrayList<ItemDetailSearchData>();
                if (tagItemList != null) {
                    tagItemList.searchData = srcList;
                }
            }

            if (tagItemList != null && tagItemList.searchRecommed != null && tagItemList.pageIndex == 0) {
                int extraType = tagItemList.getExtraType();
                List list = new ArrayList();
                if (tagItemList.searchRecommed.extraList != null) {
                    list.addAll(tagItemList.searchRecommed.extraList);
                }
                if (extraType == 1) { //无结果 (展示 no result for [key] + 推荐列表)

                    //add no result for [key] layout
                    SearchNoneEntity entity = new SearchNoneEntity();
                    entity.searchType = SearchType.SEARCH_RESULT_NONE;
                    entity.searchKey = key;
                    srcList.add(entity);

                    srcList.addAll(list);
                } else if (extraType == 2) { //少结果 (展示搜索结果 + 推荐列表)
                    srcList.addAll(list);
                } else { //正常
                    int insertPosition = tagItemList.searchRecommed.position;
                    if (insertPosition < 0 || insertPosition >= srcList.size()) {
                        srcList.addAll(list);
                    }else {
                        srcList.addAll(insertPosition, list);
                    }
                }
            }
        }

        return srcList;
    }

    public int getPageIndex(String key, int detailType) {

        int pageIndex = 0;

        if (mAppListCache != null) {
            SearchRespInfo tagItemList = mAppListCache.get(getCacheKey(key, detailType));
            if (tagItemList != null) {
                pageIndex = tagItemList.pageIndex;
            }
        }

        if (pageIndex < 0) {
            pageIndex = 0;
        }

        return pageIndex;
    }

    public void setPageLast(String key, int detailType, boolean isPageLast) {
        if (mAppListCache != null) {
            SearchRespInfo tagItemList = mAppListCache.get(getCacheKey(key, detailType));
            if (tagItemList != null) {
                tagItemList.isPageLast = isPageLast;
            }
        }
    }

    public boolean isPageLast(String key, int detailType) {

        boolean mIsPageLast = false;

        if (mAppListCache != null) {
            SearchRespInfo tagItemList = mAppListCache.get(getCacheKey(key, detailType));
            if (tagItemList != null) {
                return tagItemList.isPageLast;
            }
        }
        return mIsPageLast;
    }

    public TermInfo getTermInfo(String key, int detailType) {
        if (mAppListCache != null) {
            SearchRespInfo respInfo = mAppListCache.get(getCacheKey(key, detailType));
            if (respInfo != null) {
                return respInfo.termInfo;
            }
        }

        return null;
    }

    public String getCacheKey(String key, int detailType) {
        if (TextUtils.isEmpty(key)){
            key = "";
        }
        return CACHE_URI + key + "__"+ detailType;
    }
}

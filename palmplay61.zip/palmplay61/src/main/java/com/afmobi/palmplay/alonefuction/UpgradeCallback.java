package com.afmobi.palmplay.alonefuction;

public interface UpgradeCallback {
    void onUpgradeCallback(int percent,long downloadSize, long totalSize);
    void onUpgradeFinished(boolean result);
}

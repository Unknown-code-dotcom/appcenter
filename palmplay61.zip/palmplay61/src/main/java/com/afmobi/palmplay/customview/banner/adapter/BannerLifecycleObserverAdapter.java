package com.afmobi.palmplay.customview.banner.adapter;


import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;

import com.transsion.palmstorecore.log.LogUtils;

public class BannerLifecycleObserverAdapter implements DefaultLifecycleObserver {
    private final BannerLifecycleObserver mObserver;
    private final LifecycleOwner mLifecycleOwner;

    public BannerLifecycleObserverAdapter(LifecycleOwner lifecycleOwner, BannerLifecycleObserver observer) {
        mLifecycleOwner = lifecycleOwner;
        mObserver = observer;
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        LogUtils.i("onStart");
        mObserver.onStart(mLifecycleOwner);
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        LogUtils.i("onStop");
        mObserver.onStop(mLifecycleOwner);
    }

    @Override
    public void onDestroy(@NonNull LifecycleOwner owner) {
        LogUtils.i("onDestroy");
        mObserver.onDestroy(mLifecycleOwner);
    }

}
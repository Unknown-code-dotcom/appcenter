package com.afmobi.palmplay.appdetail.holder;

import androidx.fragment.app.FragmentActivity;

import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;

public abstract class BaseAppDetailHolder {
    protected TRNewAppViewModel mAppDetailModel;
    protected FragmentActivity mActivity;
    protected CommonAppDetailView commonAppDetailView;

    public BaseAppDetailHolder(FragmentActivity activity, TRNewAppViewModel mAppDetailModel, CommonAppDetailView commonAppDetailView) {
        this.mAppDetailModel = mAppDetailModel;
        this.mActivity = activity;
        this.commonAppDetailView = commonAppDetailView;
    }

    public abstract void initHolder();
}

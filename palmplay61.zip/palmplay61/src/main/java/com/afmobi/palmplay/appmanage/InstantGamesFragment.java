package com.afmobi.palmplay.appmanage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import com.afmobi.palmplay.appmanage.adapter.ManagerInstantGamesAdapter;
import com.transsnet.store.R;

public class InstantGamesFragment extends UnInstallAppsFragment {
    private ManagerInstantGamesAdapter managerInstantGamesAdapter;
    private InstantGamesViewModel instantGamesViewModel;
    private LinearLayout emptyView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_apps_games_mgr, container, false);
        init(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        instantGamesViewModel = new ViewModelProvider(this).get(InstantGamesViewModel.class);
        instantGamesViewModel.getInstantGamesData().observe(getViewLifecycleOwner(), games -> {
            if (games == null || games.size() == 0) {
                setEmptyViewCenter(emptyView);
                emptyView.setVisibility(View.VISIBLE);
            } else {
                emptyView.setVisibility(View.GONE);
                managerInstantGamesAdapter = new ManagerInstantGamesAdapter(getActivity()
                        , (RecyclerView) view.findViewById(R.id.manage_install_list_view)
                        , games);
                managerInstantGamesAdapter.onCreate();
            }
        });
        instantGamesViewModel.loadInstantGames();
    }

    private void init(View view) {
        emptyView = view.findViewById(R.id.uninstall_empty_view);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (managerInstantGamesAdapter != null) {
            managerInstantGamesAdapter.onDestroy();
        }
    }
}

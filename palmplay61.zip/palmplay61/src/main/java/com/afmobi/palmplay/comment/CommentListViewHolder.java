package com.afmobi.palmplay.comment;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.dialog.FeedbackDialog;
import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommentInfo;
import com.afmobi.palmplay.model.keeptojosn.FeedBackData;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DateHelper;
import com.androidnetworking.error.ANError;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutCommentListItemBinding;

import androidx.core.content.ContextCompat;
import androidx.databinding.library.baseAdapters.BR;

public class CommentListViewHolder extends BaseRecyclerViewHolder {
    private final LayoutCommentListItemBinding binding;
    private Activity activity;
    private String appName;
    private String packageName;
    private AppInfo appInfo;
    private boolean isCustomized;
    private boolean isShowingAiTranslation;

    public CommentListViewHolder(LayoutCommentListItemBinding binding, Context context) {
        super(binding.getRoot());
        this.binding =  binding;
    }

    public CommentListViewHolder setActivity(Activity activity) {
        this.activity = activity;
        return this;
    }

    public CommentListViewHolder setAppName(String appName) {
        this.appName = appName;
        return this;
    }

    public CommentListViewHolder setPackageName(String packageName) {
        this.packageName = packageName;
        return this;
    }

    public CommentListViewHolder setAppInfo(AppInfo appInfo) {
        this.appInfo = appInfo;
        return this;
    }

    public CommentListViewHolder setCustomized(boolean customized) {
        isCustomized = customized;
        return this;
    }

    public CommentListViewHolder setShowingAiTranslation(boolean show) {
        isShowingAiTranslation = show;
        return this;
    }

    @Override
    public CommentListViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    @Override
    public CommentListViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    @Override
    public CommentListViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }

    public void bind(CommentInfo commentInfo, int position) {
        binding.setIsOfferStyle(isOfferStyle());
        binding.setVariable(BR.mCommentInfo, commentInfo);
        binding.setPosition(position);
        binding.setCommentListItemViewModel(this);

        if (isShowingAiTranslation && !TextUtils.isEmpty(commentInfo.aiContent)) {
            binding.tvComment.setText(commentInfo.aiContent);
        } else {
            binding.tvComment.setText(commentInfo.content);
        }
        binding.executePendingBindings();
        if (isCustomized) {
            binding.tvComment.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector_offer));
            binding.tvComment.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector_offer));
            binding.cpContent.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector_offer));
            binding.cpContent.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector_offer));
        } else {
            binding.tvComment.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector));
            binding.tvComment.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector));
            binding.cpContent.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector));
            binding.cpContent.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector));
        }


        if(commentInfo != null && !commentInfo.hasTrack) {
            commentInfo.hasTrack = true;
            String value = TRStringUtil.generateString(mScreenPageName,mFeatureName,"", String.valueOf(position));
            ComponentExposureBuilder builder = new ComponentExposureBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType("")
                    .setItemId(commentInfo.itemID)
                    .setItemValue(packageName)
                    .setExtraValue(isShowingAiTranslation && !TextUtils.isEmpty(commentInfo.aiContent) ? "1" : "0")
                    .setTaskId(0);
            TRAnalysticsUtil.trackExposure(builder);
        }
    }


    public int onBangTextColor(boolean isOfferStyle) {
        return (isOfferStyle ? R.color.selector_bang_txt_color_offer : R.color.selector_bang_txt_color);
    }


    public boolean isOfferStyle() {
        return isCustomized;
    }



    public void onBangClick(View view, CommentInfo commentInfo, int pos) {
        if(commentInfo != null) {
            Object obj = view.getTag();
            long currentTime = System.currentTimeMillis();
            if(obj instanceof Long) {
                Long lastTime = (Long) obj;
                if(Math.abs(currentTime - lastTime) < 500) {
                    return;
                }
            }
            view.setTag(currentTime);

            int type = (commentInfo.hasApprove == 1) ? (Constant.FB_TYPE_UNAPPROVE) : (Constant.FB_TYPE_APPROVE);
            onUserFeedBack(commentInfo, type);

            if(commentInfo.hasApprove == 0) {
                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", String.valueOf(pos));
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId("")
                        .setItemType("")
                        .setItemId(commentInfo.itemID)
                        .setButtonType(TRAnalyticsConstant.LIKE)
                        .setItemValue(packageName)
                        .setExtraValue(isShowingAiTranslation && !TextUtils.isEmpty(commentInfo.aiContent) ? "1" : "0");
                TRAnalysticsUtil.trackClick(builder);
            }

            //先更新UI  //FEEDBACK不先更新UI
//            FeedBackData fbData = new FeedBackData();
//            fbData.code = 10000;
//            fbData.type = type;
//            fbData.commentId = commentInfo.id;
//            fbData.pkg = packageName;
//            fbData.itemID = commentInfo.itemID;
//            fbData.commentInfo = commentInfo;
//            onFeedbackChanged(fbData);
        }
    }


    private void onUserFeedBack(final CommentInfo commentInfo, final int type) {
        NetworkClient.requestDetailFeedback(appName, commentInfo.itemID, packageName, commentInfo.id, commentInfo.content, type, new AbsRequestListener<JsonObject>() {
            @Override
            public void onResponse(JsonObject response) {
                super.onResponse(response);

                FeedBackData fbData = new FeedBackData();
                fbData.type = type;
                fbData.commentId = commentInfo.id;
                fbData.pkg = packageName;
                fbData.itemID = commentInfo.itemID;
                fbData.commentInfo = commentInfo;

                try {

                    if(response != null) {
                        LogUtils.d("App comment list feedback response:" + response.toString());

                        Gson gson = new Gson();
                        if(response.has("code")){
                            fbData.code = gson.fromJson(response.get("code"), Integer.class);
                        }
                        if(response.has("msg")){
                            fbData.msg = gson.fromJson(response.get("msg"), String.class);
                        }
                    }

                }catch (Exception e){
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }

                onFeedbackChanged(fbData);
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);

                FeedBackData fbData = new FeedBackData();
                fbData.type = type;
                fbData.commentId = commentInfo.id;
                fbData.pkg = packageName;
                fbData.itemID = commentInfo.itemID;
                fbData.code = -2;
                fbData.commentInfo = commentInfo;

                onFeedbackChanged(fbData);
            }
        });
    }

    public String getTimeFormat(String time) {
        String src = time;
        if(!TextUtils.isEmpty(time)) {
            int end = time.indexOf("+");
            if(end != -1) {
                src = time.substring(0, end);
            }
        }
        return DateHelper.getMM_dd_yyyy(src);
    }

    public String getModel(String model) {
        String dst = model;
        if (TRStringUtil.isBlank(model)) {
            dst = PalmplayApplication.getAppInstance().getResources().getString(R.string.unkonwn);
        }
        return dst;
    }

    public String getBangTotalFormat(int total) {
        return CommonUtils.getLikeTotalStr(total);
    }


    private void onFeedbackChanged(FeedBackData feedBackData) {
        if(feedBackData != null) {

            CommentInfo commentInfo = feedBackData.commentInfo;

            if(feedBackData.code == 0) {

                if(feedBackData.type == Constant.FB_TYPE_APPROVE || feedBackData.type == Constant.FB_TYPE_UNAPPROVE) {
                    if (commentInfo != null) {

                        switch (feedBackData.type) {
                            case Constant.FB_TYPE_APPROVE://点赞
                                if(commentInfo.hasApprove != 1) {
                                    commentInfo.hasApprove = 1;
                                    commentInfo.approveCnt++;
                                }
                                break;

                            case Constant.FB_TYPE_UNAPPROVE://取消点赞
                                if(commentInfo.hasApprove == 1) {
                                    commentInfo.hasApprove = 0;
                                    commentInfo.approveCnt--;
                                    if(commentInfo.approveCnt < 0) {
                                        commentInfo.approveCnt = 0;
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                        binding.setVariable(BR.mCommentInfo, commentInfo);
                        binding.executePendingBindings();
                    }
                }else if(feedBackData.type == Constant.FB_TYPE_SPAM || feedBackData.type == Constant.FB_TYPE_REPORT) {
                    //todo:tip successful dialog
                    if(feedBackData.type == Constant.FB_TYPE_SPAM || feedBackData.type == Constant.FB_TYPE_REPORT) {
                        if(activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
                            new FeedbackDialog(activity).showFeedbackTip();
                        }
                    }
                }

            }else if(feedBackData.code == -111) { //Over the limit

                ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), R.string.tip_operation_frequent);

            }else {
                String msg = feedBackData.msg;
                if(feedBackData.code == -2) {
                    msg = PalmplayApplication.getAppInstance().getString(R.string.tip_submmit_failed);
                }
                if(!TextUtils.isEmpty(msg)) {
                    ToastManager.getInstance().show(PalmplayApplication.getAppInstance().getApplicationContext(), msg);
                }

                /*  //FEEDBACK接口异步更新UI，失败无需恢复
                if(feedBackData.type == Constant.FB_TYPE_APPROVE || feedBackData.type == Constant.FB_TYPE_UNAPPROVE) {
                    if (commentInfo != null) {//如果是点赞或者取消赞失败，则还原之前数据
                        switch (feedBackData.type) {
                            case Constant.FB_TYPE_APPROVE://点赞
                                commentInfo.hasApprove = 0;
                                commentInfo.approveCnt--;
                                break;
                            case Constant.FB_TYPE_SPAM: //点踩
                                break;
                            case Constant.FB_TYPE_REPORT://举报
                                break;
                            case Constant.FB_TYPE_UNAPPROVE://取消点赞
                                commentInfo.hasApprove = 1;
                                commentInfo.approveCnt++;
                                break;
                        }

                        //update comment view
                        binding.setVariable(BR.mCommentInfo, commentInfo);
                        binding.executePendingBindings();
                    }
                }
                 */
            }
        }
    }
}

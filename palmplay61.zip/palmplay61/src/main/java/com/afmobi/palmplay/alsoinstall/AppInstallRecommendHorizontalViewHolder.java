package com.afmobi.palmplay.alsoinstall;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.activate.TRManager;
import com.afmobi.palmplay.appnext.AppNextConstants;
import com.afmobi.palmplay.appnext.AppNextProcessor;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.home.instant.IVaPlayDownloadCallback;
import com.afmobi.palmplay.home.model.FeatureDataType;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.MarkStyle;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.animations.AnimationFactory;
import com.afmobi.util.animations.AnimationFactoryParams;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ZLayoutAppInstallRecommendListItemHBinding;

import androidx.core.content.ContextCompat;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class AppInstallRecommendHorizontalViewHolder extends AppInstallRecommendBaseViewHolder{


    private ZLayoutAppInstallRecommendListItemHBinding mBinding;

    private int paddingValue4, paddingValue6;
    private int tvNameWidth;
    private String extraValue;
    private String extras;

    public AppInstallRecommendHorizontalViewHolder setExtraValue(String extraValue) {
        this.extraValue = extraValue;
        return this;
    }

    public AppInstallRecommendHorizontalViewHolder setExtras(String extras) {
        this.extras = extras;
        return this;
    }

    public AppInstallRecommendHorizontalViewHolder(ViewDataBinding binding) {
        super(binding.getRoot());

        mBinding = (ZLayoutAppInstallRecommendListItemHBinding) binding;


        paddingValue6 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 6);
        paddingValue4 = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 4);
        updateItemWidth();
    }

    private void updateItemWidth() {
        Context context = mBinding.getRoot().getContext();
        int itemWidth = (DisplayUtil.getScreenWidthPx(context)
                + DisplayUtil.getInsetsMargin(context)
                - DisplayUtil.dip2px(context, 16)) / AppInstallRecommendManager.H_STYLE_LINE_DEFAULT;
        tvNameWidth = itemWidth - paddingValue4 - paddingValue4;
    }

    @Override
    public void bind(FeatureBaseData featureItemData, int position) {

        if (featureItemData instanceof FeatureItemData) {

            FeatureItemData item = (FeatureItemData) featureItemData;

            itemView.setVisibility(View.VISIBLE);

            itemView.setTag(item);

            int defaultIcon = R.drawable.layer_list_app_default_01_bg;
            int borderColor = ContextCompat.getColor(PalmplayApplication.getAppInstance(), R.color.img_border_color);
            if (mOfferInfo != null && mOfferInfo.isOfferStyle()) {//for offer
                mBinding.tvName.setTextColor(mOfferInfo.mainColor);
                borderColor = mOfferInfo.borderColor;
                mBinding.tvSize.setTextColor(mOfferInfo.subColor);
            }
            mBinding.ivIcon.setStrokeColor(CommonUtils.createColorStateList(borderColor));
            int corner = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 9f);
            GlideUtils.setImageUrl(mBinding.ivIcon, item.iconUrl, GlideUtils.newCommonRequestOptions(), defaultIcon, defaultIcon);
            mBinding.tvName.setText(item.name);
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) mBinding.layoutContent.getLayoutParams();

            if (position == 0) {
                //左边空白16dp
                layoutParams.setMarginStart(paddingValue6);
                layoutParams.leftMargin = paddingValue6;
                mBinding.layoutContent.setLayoutParams(layoutParams);
                mBinding.layoutContent.setPadding(paddingValue4, 0, paddingValue4, 0);
                mBinding.layoutContent.setPaddingRelative(paddingValue4, 0, paddingValue4, 0);

            } else {
                layoutParams.leftMargin = 0;
                layoutParams.setMarginStart(0);
                mBinding.layoutContent.setLayoutParams(layoutParams);
                mBinding.layoutContent.setPadding(paddingValue4, 0, paddingValue4, 0);
                mBinding.layoutContent.setPaddingRelative(paddingValue4, 0, paddingValue4, 0);
                mBinding.tvName.setPadding(0, 0, 0, 0);
                mBinding.tvName.setPaddingRelative(0, 0, 0, 0);
            }
            updateItemWidth();
            ViewGroup.LayoutParams nameParams = mBinding.tvName.getLayoutParams();
            nameParams.width = tvNameWidth;
            mBinding.tvName.setLayoutParams(nameParams);
            ViewGroup.LayoutParams downloadParams = mBinding.downloadView.getLayoutParams();
            int defaultDownloadWidth = mBinding.downloadView.getResources()
                    .getDimensionPixelSize(R.dimen.download_btn_w);
            downloadParams.width = Math.min(defaultDownloadWidth, tvNameWidth);
            mBinding.downloadView.setLayoutParams(downloadParams);

            updateTextDownloadCountAndSize(item, mBinding.tvSize);

            if (MarkStyle.GP_SHOW.equals(item.showStyle) && FeatureDataType.GP_ITEM.equals(item.dataType)){
                mBinding.ivGoogle.setVisibility(View.VISIBLE);
            } else {
                mBinding.ivGoogle.setVisibility(View.GONE);
            }

            mBinding.ivGift.setVisibility(TextUtils.isEmpty(item.lableUrl) || !CommonUtils.isGiftFlagNeedShow() ? View.GONE : View.VISIBLE);
            GlideUtils.setImageUrlWithNoBorder(mBinding.ivGift, item.lableUrl);
            mBinding.downloadView.setOnClickListener(new DownloadBtnOnClickListener(item, mBinding.downloadView, position));
            mBinding.layoutContent.setOnClickListener(new NoDoubleClickListener(item, position));

            DownloadStatusManager.getInstance().registerFeatureItemInstance(item);
            CommonUtils.checkStatusItemDisplay(item, mBinding.downloadView, mOfferInfo, null);

            if (gdprHasAllowed && !item.hasTrack) {
                item.hasTrack = true;

                if(TextUtils.isEmpty(item.nativeId)) {
                    item.nativeId = CommonUtils.generateSerialNum();
                }

                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(position));
                if(!TextUtils.isEmpty(item.getShowReportUrl())) {
                    AppNextProcessor.addAsyncTask(item.packageName, AppNextConstants.ITEM_SHOW, item.getShowReportUrl());
                }
                String extra;
                if(mScreenPageName.equals(TRAnalyticsConstant.PAGE_SEARCH_RESULT)) {
                    extra = extras;
                } else {
                    extra = getExtras();
                }

                ComponentExposureBuilder builder = new ComponentExposureBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(getStyleName())
                        .setTopicId(item.topicID)
                        .setItemType(item.detailType)
                        .setItemId(item.itemID)
                        .setItemValue(item.packageName)
                        .setTaskId(item.getTaskId())
                        .setExpId(item.getExpId())
                        .setItemFrom(item.getItemFrom())
                        .setReportSource(item.getReportSource())
                        .setCfgId(item.getCfgId())
                        .setVarId(item.getVarId())
                        .setDataType(item.dataType)
                        .setFeatureId(featureId)
                        .setNativeId(item.nativeId)
                        .setIsVa(item.isVa)
                        .setExtraValue(extraValue)
                        .setExtras(extra);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                }
                TRAnalysticsUtil.trackExposure(builder);
            }
        }else {
            dismissItemView();
        }

    }


    private void updateTextDownloadCountAndSize(FeatureItemData featureData, TextView tv_download_count_and_size) {
        if (0 != featureData.size) {
            tv_download_count_and_size.setVisibility(View.VISIBLE);
            CommonUtils.setStrikeThroughSpannable(featureData.size, featureData.compSourceSize, tv_download_count_and_size);
        } else {
            tv_download_count_and_size.setVisibility(View.GONE);
        }
    }

    protected Boolean handleJumpGpLogic(FeatureBaseData featureBaseData) {
        if (featureBaseData!= null && FeatureDataType.GP_ITEM.equals(featureBaseData.dataType)){
            FeatureItemData featureItemData = null;
            if (featureBaseData instanceof FeatureItemData){
                featureItemData = (FeatureItemData) featureBaseData;
            }
            if (featureItemData != null && InstalledAppManager.getInstance().isInstalled(featureItemData.packageName)) {
                DownloadDecorator.launchApp(featureItemData.packageName,featureItemData.name);
                return true;
            }
            if (!TextUtils.isEmpty(featureBaseData.getJumpUrl())){
                TRManager.getInstance().dispatchEvent(TRActivateConstant.GP_LINK, featureBaseData);
            }
            if (featureItemData != null && !TextUtils.isEmpty(featureBaseData.getClickReportUrl())) {
                AppNextProcessor.addAsyncTask(featureItemData.packageName, AppNextConstants.ITEM_CLICK, featureBaseData.getClickReportUrl());
            }
            return true;
        }
        return false;
    }


    //防止快速点击响应多次
    private class NoDoubleClickListener implements View.OnClickListener {

        private FeatureItemData featureItemData;
        private int mPosition;

        public NoDoubleClickListener(FeatureItemData featureItemData, int position) {
            this.featureItemData = featureItemData;
            this.mPosition = position;
        }

        @Override
        @SingleClick(800)
        public void onClick(View v) {
            if (featureItemData != null && !TextUtils.isEmpty(featureItemData.itemID)) {
                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(mPosition));
                ComponentClickBuilder builder = new ComponentClickBuilder();

                String extra;
                if(mScreenPageName.equals(TRAnalyticsConstant.PAGE_SEARCH_RESULT)) {
                    extra = extras;
                } else {
                    extra = getExtras();
                }
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(getStyleName())
                        .setTopicId(featureItemData.topicID)
                        .setItemType(featureItemData.detailType)
                        .setItemId(featureItemData.itemID)
                        .setButtonType(TRAnalyticsConstant.ICON)
                        .setItemValue(featureItemData.packageName)
                        .setExtraValue(extraValue)
                        .setTaskId(featureItemData.getTaskId())
                        .setExpId(featureItemData.getExpId())
                        .setItemFrom(featureItemData.getItemFrom())
                        .setReportSource(featureItemData.getReportSource())
                        .setVarId(featureItemData.getVarId())
                        .setDataType(featureItemData.dataType)
                        .setFromPage(mFromPage)
                        .setNativeId(featureItemData.nativeId)
                        .setFeatureId(featureId)
                        .setExtras(extra)
                        .setIsVa(featureItemData.isVa);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                }
                TRAnalysticsUtil.trackClick(builder);

                if(handleJumpGpLogic(featureItemData)){
                    return;
                }

                AppBuilder appBuilder = new AppBuilder()
                        .setFromPage(mFromPage)
                        .setTopicID(featureItemData.topicID)
                        .setExpId(featureItemData.getExpId())
                        .setVarId(featureItemData.getVarId())
                        .setLastPage(PageConstants.getCurPageStr(mPageParamInfo))
                        .setValue(value)
                        .setParamsByData(featureItemData, featureId);
                TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);
            }
        }
    }

    // download click listener
    class DownloadBtnOnClickListener implements View.OnClickListener {

        private FeatureItemData featureItemData;
        private View bindClickView;
        private int mPosition;

        public DownloadBtnOnClickListener(FeatureItemData featureItemData, View bindClickView, int position) {
            this.featureItemData = featureItemData;
            this.bindClickView = bindClickView;
            this.mPosition = position;
        }

        @Override
        public void onClick(View v) {
            if (bindClickView == null || featureItemData == null)
                return;

            if (bindClickView.getId() == mBinding.downloadView.getId()) {
                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(mPosition));
                String itemFrom = featureItemData.getItemFrom();
                String reportSource = featureItemData.getReportSource();
                String cfgId = featureItemData.reportDto!=null ? featureItemData.reportDto.cfgId : "";
                String extra;
                if(mScreenPageName.equals(TRAnalyticsConstant.PAGE_SEARCH_RESULT)) {
                    extra = extras;
                } else {
                    extra = getExtras();
                }
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(getStyleName())
                        .setTopicId(featureItemData.topicID)
                        .setItemType(featureItemData.detailType)
                        .setItemId(featureItemData.itemID)
                        .setItemValue(featureItemData.packageName)
                        .setExtraValue(extraValue)
                        .setTaskId(featureItemData.getTaskId())
                        .setExpId(featureItemData.getExpId())
                        .setItemFrom(itemFrom)
                        .setReportSource(reportSource)
                        .setCfgId(cfgId)
                        .setNativeId(featureItemData.nativeId)
                        .setVarId(featureItemData.getVarId())
                        .setDataType(featureItemData.dataType)
                        .setFromPage(mFromPage)
                        .setFeatureId(featureId)
                        .setExtras(extra)
                        .setIsVa(featureItemData.isVa);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                }
                PsVaManager.getInstance().checkDownloadInfo(featureItemData, LaunchInfo.LAUNCH_FROM_ICON,mFromPage,value,
                        new IVaPlayDownloadCallback() {
                            @Override
                            public void clickVaPlay() {
                                builder.setButtonType(TRAnalyticsConstant.PLAY);
                                TRAnalysticsUtil.trackClick(builder);
                            }

                            @Override
                            public void start() {
                                startDownload(featureItemData, mBinding.ivIcon, mBinding.downloadView, builder);
                            }
                        });
            }
        }

        private void startDownload(FeatureItemData featureItemData, ImageView iv_icon, View downloadView, ComponentClickBuilder builder) {
            if (featureItemData == null) {
                return;
            }
            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(mPosition));

            //处理gp跳转逻辑
            if(handleJumpGpLogic(featureItemData)){
                builder.setButtonType(TRAnalyticsConstant.INSTALL);
                TRAnalysticsUtil.trackClick(builder);
                return;
            }


            if (FileDownloadInfo.STATUS_DOWNING == featureItemData.observerStatus) {
                DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            }  else if (FileDownloadInfo.STATUS_WAIT == featureItemData.observerStatus) {
                if ((featureItemData.isVa)) {
                    DownloadManager.getInstance().resumeDownload(featureItemData.packageName);
                } else {
                    DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                }
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_PAUSE == featureItemData.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == featureItemData.observerStatus) {
                DownloadUtil.resumeDownload(PalmplayApplication.getAppInstance(), featureItemData.packageName);
                builder.setButtonType(TRAnalyticsConstant.CONTINUE);
                TRAnalysticsUtil.trackClick(builder);
            } else {
                if (FileDownloadInfo.STATUS_NONE == featureItemData.observerStatus) {//下载

                    if (!TextUtils.isEmpty(featureItemData.getClickReportUrl())) {
                        AppNextProcessor.addAsyncTask(featureItemData.packageName, AppNextConstants.ITEM_CLICK, featureItemData.getClickReportUrl());
                    }
                    builder.setButtonType(TRAnalyticsConstant.INSTALL);
                    TRAnalysticsUtil.trackClick(builder);
                } else if (FileDownloadInfo.STATUS_APP_INSTALLED == featureItemData.observerStatus) {//打开
                    builder.setButtonType(TRAnalyticsConstant.OPEN)
                            .setExtraValue(DeeplinkManager.getDeeplink(featureItemData.packageName));
                    TRAnalysticsUtil.trackClick(builder);
                }
                if (DownloadDecorator.checkJumpToGooglePlay(PalmplayApplication.getAppInstance(), featureItemData.getOuterUrl(), featureItemData.packageName, mPageParamInfo, featureItemData.itemID, featureItemData.versionCode, featureItemData.verifyGoogle)) {
                    return;
                }

                AnimationFactory mAnimationFactory = null;
                AnimationFactoryParams param = null;

                if (mOnViewLocationInScreen != null) {
                    mAnimationFactory = AppDetailAnimationUtil.getInstance();
                    param = new AnimationFactoryParams(iv_icon, mOnViewLocationInScreen, 24);
                }

                DownloadDecorator.startDownloading(FeatureItemData.convertToCommonInfo(featureItemData, featureId), mFromPage, new PageParamInfo(mFrom, value), mAnimationFactory, param);
            }
        }
    }

    public static void updateItemProgress(View itemView, FileDownloadInfo downloadInfo, int progress, OfferInfo offerInfo) {
        RecyclerView id_recyclerview = itemView.findViewById(R.id.id_recyclerview);
        RecyclerView.Adapter adapter = id_recyclerview != null ? id_recyclerview.getAdapter() : null;
        if (adapter == null || downloadInfo == null) {
            return;
        }

        String packageName = downloadInfo.packageName;
        int childCount = adapter.getItemCount();
        LinearLayoutManager lm = (LinearLayoutManager) id_recyclerview.getLayoutManager();
        for (int i = 0; i < childCount; i++) {
            View childView = lm.findViewByPosition(i);
            Object objTag = childView != null ? childView.getTag() : null;
            if (objTag != null && objTag instanceof FeatureItemData) {
                FeatureItemData featureItemData = (FeatureItemData) objTag;
                if (!TextUtils.isEmpty(featureItemData.packageName) && featureItemData.packageName.equals(packageName)) {
                    XFermodeDownloadView downloadView = childView.findViewById(R.id.downloadView);
                    CommonUtils.updateViewHolderProgressBar(downloadInfo, downloadView, offerInfo, null);
                }
            }
        }
    }
}

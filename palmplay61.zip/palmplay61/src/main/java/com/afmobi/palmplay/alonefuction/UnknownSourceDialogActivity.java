package com.afmobi.palmplay.alonefuction;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import com.afmobi.palmplay.base.BaseFragmentActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.util.Constant;
import com.afmobi.util.PadUtils;
import com.afmobi.util.SysUtils;
import com.google.gson.Gson;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.R;

/**
 * 未知来源提醒页面
 * 20180403.
 */
public class UnknownSourceDialogActivity extends BaseFragmentActivity implements View.OnClickListener{

    private FileDownloadInfo fileDownloadInfo;
    private boolean isClickedOK = false;
    private Handler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_open_unknown_source);
        String data = getIntent().getStringExtra(Constant.KEY_URL);

        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.UnknownTips);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

        if (data != null) {
            Gson gson = new Gson();
            fileDownloadInfo = gson.fromJson(data, FileDownloadInfo.class);
        }

        findViewById(R.id.btn_ok).setOnClickListener(this);
        findViewById(R.id.btn_cancel).setOnClickListener(this);

        mHandler = new Handler(Looper.getMainLooper());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (SysUtils.isAllowedUnknownSource(this)) {
            DownloadManager.getInstance().addDownloadingInfoExcludeExist(fileDownloadInfo);
        }
        if(isClickedOK){
            finish();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_ok:
                isClickedOK = true;
                Intent intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
                ComponentName cName = new ComponentName("com.android.settings", "com.android.settings.Settings$SecuritySettingsActivity");
                intent.setComponent(cName);
                try {
                    startActivity(intent);
                }catch (Exception e){//some phone not found this Activity catch ActivityNotFoundException
                    LogUtils.d("start Setting$SecuritySettingsActivity failed, msg:" + e.getMessage());
                    try{
                        intent.setPackage("com.android.settings");
                        startActivity(intent);
                    }catch (Exception ex){}
                }
                final Intent unknownSourceintent = new Intent(UnknownSourceDialogActivity.this, OpenUnknownSourceTipsActivity.class);
                PageConstants.putPageParamInfo(unknownSourceintent, mPageParamInfo);
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(unknownSourceintent);
                    }
                }, 100);
                break;

            case R.id.btn_cancel:
                finish();
                break;

            default:
                break;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadActivityAsDialog(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(null);
        mHandler = null;
    }

    @Override
    public String getValue() {
        return "";
    }
}

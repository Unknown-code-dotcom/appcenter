package com.afmobi.palmplay.appnext;

import com.afmobi.palmplay.appnext.db.AppNextCache;
import com.afmobi.palmplay.appnext.db.AppNextDbManager;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.util.NetStateReceiver;
import com.transsion.core.CoreUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.NetworkUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;

import java.util.List;


/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 14:31
 * @Desc: appnext 归因逻辑
 */
public class AppNextCacheManager {

    private static volatile AppNextCacheManager mInstance;
    private static long durationTime = BuildConfig.DEBUG ? 2 * 60 * 1000 : 4 * 60 * 60 * 1000;// 4小时间隔时间
    private long lastTime = 0;

    private List<AppNextCache> mAppNextCacheList;

    public static AppNextCacheManager getInstance() {
        if (mInstance == null) {
            synchronized (ConfigManager.class) {
                if (mInstance == null) {
                    mInstance = new AppNextCacheManager();
                }
            }
        }
        return mInstance;
    }

    public void handleAppNextCacheLogic() {

        if(!BuildConfig.FEATURE_APP_NEXT_SWITCH){
            return;
        }

        if (lastTime == 0) {
            lastTime = TRSharedPreferenceUtils.getAppNextHandleTime();
        }
        if (System.currentTimeMillis() - lastTime < durationTime) {
            LogUtils.d(LogUtils.TAG_APP_NEXT, "handleAppNextCacheLogic < interval time");
            return;
        }

        if (!NetworkUtils.sNetworkConnected) {
            return;
        }

        mAppNextCacheList = AppNextDbManager.getAppNextCacheList();

        lastTime = System.currentTimeMillis();
        TRSharedPreferenceUtils.setAppNextHandleTime(lastTime);

        if (mAppNextCacheList != null && mAppNextCacheList.size() > 0) {
            AppNextProcessor.handleAppNextCacheList(mAppNextCacheList);
        }else {
            LogUtils.d(LogUtils.TAG_APP_NEXT, "handleAppNextCacheLogic no cache");
        }

    }

    public void saveToDb(String packageNameWithAction, String reportUrl) {
        LogUtils.d(LogUtils.TAG_APP_NEXT, "saveToDb packageName = " + packageNameWithAction + "; reportUrl =  " + reportUrl);
        AppNextDbManager.saveAppNextCache(packageNameWithAction, reportUrl);
    }

}

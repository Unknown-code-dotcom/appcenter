package com.afmobi.palmplay.appdetail;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.configs.v6_3.RankType;
import com.afmobi.palmplay.detail.AppDetailsComponentAISummaryViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentViewAllHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentCommentViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentFeatureViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentFeedBackViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentIntroduceViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentScreenShotViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentTagViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentTransitionViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentUpdateViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentWelfareViewHolder;
import com.afmobi.palmplay.detail.TrDetailShortBannerRecyclerViewHolder;
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.IMessenger;
import com.transsion.core.log.LogUtils;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

public class NewAppDetailsRecyclerViewAdapter extends TrHomeRecyclerViewAdapter<RecyclerView, LinearLayoutManager> {

    public static final String COMPONET_BANNER = "HEAD_IMAGE"; // 截图
    public static final String COMPONET_SCREENSHOT = "INTRODUCE_IMAGE"; // 截图
    public static final String COMPONET_TAG = "ITEM_TAG"; // 标签
    public static final String COMPONET_INTRODUCE = "ITEM_BRIEF"; // 应用信息介绍
    public static final String COMPONET_UPDATE = "ITEM_UPDATE"; // 应用更新信息
    public static final String COMPONET_COMMENT = "COMMENT_CARD"; // 评论
    public static final String COMPONET_WELFARE = "WELFARE"; // 福利券
    public static final String COMPONET_FEATURE = "RANK"; // 榜单推荐
    public static final String COMPONET_FEEDBACK = "REPORT_BUTTON"; // 反馈
    public static final String COMPONET_SHORT_BANNER = "DETAIL_SHORT_BANNER"; // 详情页短banner
    public static final String COMPONET_TRANSITION = "ITEM_TRANSITION";
    public static final String COMPONET_AI_SUMMARY = "ITEM_AI_SUMMARY"; // AI摘要（客户端虚拟组件）
    public static final String COMPONET_VIEW_ALL = "VIEW_ALL";           // 折叠预览+View All（客户端虚拟组件）

    public static final int VIEWTYPE_AI_SUMMARY = 100; // AI摘要
    public static final int VIEWTYPE_VIEW_ALL = 101;   // 折叠预览


    public static final String COMPONET_BASE_INFO = "TITLE_CARD"; // 基础信息
    public static final String COMPONET_ITEM_INFO = "ITEM_INFO_BLOCK"; // 大小，下载数等
    public static final String COMPONET_UDS_TRANSITION = "ITEM_UDS_TRANSITION";

    public static final String TAB_TYPE_HEAD = "HEAD_TAB";
    public static final String TAB_TYPE_DETAIL = "DETAIL_TAB";

    public static final String SAFE_SHIELD = "1";
    public static final String SAFE_OFFICIAL = "3";
    public static final String SAFE_FREE = "4";
    public static final String SAFE_NO_ADS = "5";
    public static final String SAFE_MANUAL_TEST = "6";
    public static final String SAFE_TEST_REPORT = "7";

    public static final String STYLE_TYPE_DEFAULT = "default";
    public static final String STYLE_TYPE_LIST = "LIST_STYLE";

    private String mStyle;
    private String mCategoryTag;
    private boolean mIsFromCache = false;

    protected String itemID;

    private Context mContext;
    private List<DetailComponentItemData> mList;
    private LayoutInflater mInflater;
    private Activity mActivity;
    private boolean isCustomized;
    private String appName, packageName;
    private boolean isUseSmallCache;
    private IMessenger mMessager;
    private AppDetailsComponentUpdateViewHolder.AppDetailVersionInf appDetailVersionInf;
    private AppDetailsComponentViewAllHolder.OnViewAllClickListener mOnViewAllClickListener;

    public void setOnViewAllClickListener(AppDetailsComponentViewAllHolder.OnViewAllClickListener l) {
        this.mOnViewAllClickListener = l;
    }

    public NewAppDetailsRecyclerViewAdapter(Context context, AppDetailsComponentUpdateViewHolder.AppDetailVersionInf appDetailVersionInf,
                                            List<DetailComponentItemData> list, String mFromPage, PageParamInfo mPageParamInfo,
                                            RecyclerView idRecyclerview, LinearLayoutManager layoutManager) {
        super((Activity) context, idRecyclerview, layoutManager, null,null,null
                , mFromPage, mPageParamInfo, false, 0, 0,false);
        this.mContext = context;

        mInflater = LayoutInflater.from(mContext);
        mActivity = (Activity) context;
        this.appDetailVersionInf = appDetailVersionInf;

        if (BuildConfig.DEBUG) {
            for (DetailComponentItemData item : list) {
                LogUtils.d("Before", "----init----" + item.toString());
            }
        }
        this.mList = splitAISummaryData(expandFeatureList(list));
        if (BuildConfig.DEBUG) {
            for (DetailComponentItemData item : mList) {
                LogUtils.d("After", "----init----" + item.toString());
            }
        }
    }

    public void setmList(List<DetailComponentItemData> list) {
        if (list != null && list.size() > 0) {
            if (BuildConfig.DEBUG) {
                for (DetailComponentItemData item : list) {
                    LogUtils.d("Before", "----setmList----" + item.toString());
                }
            }
            this.mList = splitAISummaryData(expandFeatureList(list));
            if (BuildConfig.DEBUG) {
                for (DetailComponentItemData item : mList) {
                    LogUtils.d("After", "----setmList----" + item.toString());
                }
            }
            this.notifyDataSetChanged();
        }
    }

    private List<DetailComponentItemData> splitAISummaryData(List<DetailComponentItemData> list) {
        if (list == null) return list;
        List<DetailComponentItemData> result = new ArrayList<>();
        for (DetailComponentItemData item : list) {
            if (TextUtils.equals(item.dataType, COMPONET_INTRODUCE)
                    && !TextUtils.isEmpty(item.overviewAI)
                    && !TextUtils.isEmpty(item.summaryConnectAI)
                    && item.featuresAI != null && !item.featuresAI.isEmpty()) {
                DetailComponentItemData aiItem = new DetailComponentItemData();
                aiItem.copyData(item);
                aiItem.dataType = COMPONET_AI_SUMMARY;
                result.add(aiItem);
            }
            result.add(item);
        }
        return result;
    }

    public List<DetailComponentItemData> expandFeatureList(List<DetailComponentItemData> originalList) {
        List<DetailComponentItemData> resultList = new ArrayList<>();

        for (DetailComponentItemData item : originalList) {
            if (COMPONET_FEATURE.equals(item.dataType) && item.featureDtoList != null) {
                FeatureUtil featureUtil =new FeatureUtil(mAppInfo);
                featureUtil.showRecommendView(item.featureDtoList);

                if (item.featureDtoList != null) {
                    for (FeatureBean feature : item.featureDtoList) {
                        // 为每个FeatureBean创建一个新的DetailComponentItemData
                        List<FeatureBean> singleFeatureList = new ArrayList<>();
                        feature.setmDetailSource(mDetailSource);
                        singleFeatureList.add(feature);
                        DetailComponentItemData newItem = new DetailComponentItemData();
                        newItem.dataType = COMPONET_FEATURE;
                        newItem.featureDtoList = singleFeatureList;
                        resultList.add(newItem);
                    }
                }
            } else {
                // 直接将原始项添加到结果列表
                resultList.add(item);
            }
        }

        return resultList;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public void setUseSmallCache(boolean isUseSmallCache) {
        this.isUseSmallCache = isUseSmallCache;
    }

    public void setIMessager(IMessenger messager) {
        this.mMessager = messager;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (RankType.VIEWTYPE_SHORT_BANNER == viewType) {

            return new TrDetailShortBannerRecyclerViewHolder(mInflater.inflate(R.layout.z_layout_app_details_short_banner, parent, false));

        } else if (VIEWTYPE_VIEW_ALL == viewType) {

            return new AppDetailsComponentViewAllHolder(mInflater.inflate(R.layout.z_layout_app_details_component_view_all, parent, false));

        } else if (VIEWTYPE_AI_SUMMARY == viewType) {

            return new AppDetailsComponentAISummaryViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_ai_summary, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_UPDATE == viewType) {

            return new AppDetailsComponentUpdateViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_update, parent, false).getRoot(), appDetailVersionInf);

        } else if (RankType.VIEWTYPE_SCREENSHOT == viewType) {

            return new AppDetailsComponentScreenShotViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_screenshot, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_TAG == viewType) {

            return new AppDetailsComponentTagViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_tag, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_INTRODUCE == viewType) {

            return new AppDetailsComponentIntroduceViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_introduce, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_COMMENT == viewType) {

            return new AppDetailsComponentCommentViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_comment, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_WELFARE == viewType) {

            return new AppDetailsComponentWelfareViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_welfare, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_FEEDBACK == viewType) {

            return new AppDetailsComponentFeedBackViewHolder(DataBindingUtil.inflate(mInflater, R.layout.z_layout_app_details_component_feedback, parent, false).getRoot());

        } else if (RankType.VIEWTYPE_TRANSITION == viewType) {

            boolean isOffer = mOfferInfo != null && mOfferInfo.isOfferStyle();
            int resId = isOffer ? R.layout.z_layout_app_details_component_transition_offer : R.layout.z_layout_app_details_component_transition;
            return new AppDetailsComponentTransitionViewHolder(DataBindingUtil.inflate(mInflater, resId, parent, false).getRoot());

        }else {
            return super.onCreateViewHolder(parent, viewType);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        DetailComponentItemData item = getItemByPosition(position);

        if (VIEWTYPE_AI_SUMMARY == viewType) {
            AppDetailsComponentAISummaryViewHolder viewHolder = (AppDetailsComponentAISummaryViewHolder) holder;
            viewHolder.setFrom(mFrom)
                    .setAppInfo(mAppInfo)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .bind(item, position);
        } else if (VIEWTYPE_VIEW_ALL == viewType) {
            AppDetailsComponentViewAllHolder viewHolder = (AppDetailsComponentViewAllHolder) holder;
            viewHolder.setOnViewAllClickListener(mOnViewAllClickListener);
            viewHolder.setFrom(mFrom)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);
        } else if (RankType.VIEWTYPE_SHORT_BANNER == viewType) {
            TrDetailShortBannerRecyclerViewHolder viewHolder = (TrDetailShortBannerRecyclerViewHolder)holder;
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_SCREENSHOT)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);
        } else if (RankType.VIEWTYPE_UPDATE == viewType){
            AppDetailsComponentUpdateViewHolder viewHolder = (AppDetailsComponentUpdateViewHolder) holder;
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_SCREENSHOT)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);
        } else if (RankType.VIEWTYPE_SCREENSHOT == viewType) {

            AppDetailsComponentScreenShotViewHolder viewHolder = (AppDetailsComponentScreenShotViewHolder) holder;
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_SCREENSHOT)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);
        } else if (RankType.VIEWTYPE_TAG == viewType) {

            AppDetailsComponentTagViewHolder viewHolder = (AppDetailsComponentTagViewHolder) holder;
            viewHolder.setTab(NewAppDetailsRecyclerViewAdapter.TAB_TYPE_DETAIL);
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_TAG)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);

        } else if (RankType.VIEWTYPE_INTRODUCE == viewType) {

            AppDetailsComponentIntroduceViewHolder viewHolder = (AppDetailsComponentIntroduceViewHolder) holder;
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_INTRODUCE)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);

        } else if (RankType.VIEWTYPE_COMMENT == viewType) {

            AppDetailsComponentCommentViewHolder viewHolder = (AppDetailsComponentCommentViewHolder) holder;
            viewHolder.setAppName(appName)
                    .setPackageName(packageName)
                    .setIMessager(mMessager);
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_COMMENT)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);

        } else if (RankType.VIEWTYPE_WELFARE == viewType) {

            AppDetailsComponentWelfareViewHolder viewHolder = (AppDetailsComponentWelfareViewHolder) holder;
            viewHolder.setUseSmallCache(isUseSmallCache);
            viewHolder.setIMessager(mMessager);
            viewHolder.setTab(NewAppDetailsRecyclerViewAdapter.TAB_TYPE_DETAIL);
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_WELFARE)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);

        } else if (RankType.VIEWTYPE_FEATURE == viewType) {
            AppDetailsComponentFeatureViewHolder viewHolder = (AppDetailsComponentFeatureViewHolder) holder;
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.COMPONENT_FEATURE)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);

        } else if (RankType.VIEWTYPE_FEEDBACK == viewType) {

            AppDetailsComponentFeedBackViewHolder viewHolder = (AppDetailsComponentFeedBackViewHolder) holder;
            viewHolder.setPackageName(packageName);
            viewHolder.setFrom(mFrom)
                    .setFromCache(mIsFromCache)
                    .setFeatureName(TRAnalyticsConstant.DETAIL_DETAILS)
                    .setScreenPageName(mScreenPageName)
                    .setItemID(itemID)
                    .setFromPage(mFromPage)
                    .setPageParamInfo(mPageParamInfo)
                    .setOnViewLocationInScreen(mOnViewLocationInScreen)
                    .setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .setAppInfo(mAppInfo)
                    .bind(item, position);

        } else if (RankType.VIEWTYPE_TRANSITION == viewType) {

            AppDetailsComponentTransitionViewHolder viewHolder = (AppDetailsComponentTransitionViewHolder) holder;
            viewHolder.setOfferInfo(mOfferInfo)
                    .setActivity(mActivity)
                    .bind(item, position);
        } else {
            if (item != null && item.featureDtoList != null && item.featureDtoList.size() == 1) {
                FeatureBean featureBean = item.featureDtoList.get(0);
                super.onBindViewHolder(holder, position, featureBean);
            }
        }
    }

    @Override
    public int getItemCount() {
        return (mList == null) ? 0 : mList.size();
    }

    @Override
    public int getItemViewType(int position) {

        DetailComponentItemData item = getItemByPosition(position);

//        if (BuildConfig.DEBUG){
//            LogUtils.d("Adapter", "----getItemViewType----" + item.toString());
//        }

        if (item != null) {
            if (TextUtils.equals(item.dataType, COMPONET_SHORT_BANNER))  {
                return RankType.VIEWTYPE_SHORT_BANNER;
            }else if (TextUtils.equals(item.dataType, COMPONET_UPDATE))  {
                return RankType.VIEWTYPE_UPDATE;
            }else if (TextUtils.equals(item.dataType, COMPONET_SCREENSHOT))  {
                return RankType.VIEWTYPE_SCREENSHOT;
            }else if (TextUtils.equals(item.dataType, COMPONET_TAG)) {
                return RankType.VIEWTYPE_TAG;
            }else if (TextUtils.equals(item.dataType, COMPONET_AI_SUMMARY)) {
                return VIEWTYPE_AI_SUMMARY;
            }else if (TextUtils.equals(item.dataType, COMPONET_VIEW_ALL)) {
                return VIEWTYPE_VIEW_ALL;
            }else if (TextUtils.equals(item.dataType, COMPONET_INTRODUCE)) {
                return RankType.VIEWTYPE_INTRODUCE;
            }else if (TextUtils.equals(item.dataType, COMPONET_COMMENT)) {
                return RankType.VIEWTYPE_COMMENT;
            }else if (TextUtils.equals(item.dataType, COMPONET_WELFARE)) {
                return RankType.VIEWTYPE_WELFARE;
            }else if (TextUtils.equals(item.dataType, COMPONET_FEATURE)) {
                if (item.featureDtoList != null && !item.featureDtoList.isEmpty()) {//这是被展开的，需要修改父类的类型
                    FeatureBean featureBean = item.featureDtoList.get(0);
                    return super.getItemViewType(featureBean);
                }
            }else if (TextUtils.equals(item.dataType, COMPONET_FEEDBACK)) {
                return RankType.VIEWTYPE_FEEDBACK;
            }else if (TextUtils.equals(item.dataType, COMPONET_TRANSITION)) {
                return RankType.VIEWTYPE_TRANSITION;
            }
        }

        return super.getItemViewType(position);
    }

    private DetailComponentItemData getItemByPosition(int pos) {
        if (pos < 0 || pos >= getItemCount()) {
            return null;
        }

        return mList.get(pos);
    }

    public NewAppDetailsRecyclerViewAdapter setCategoryTag(String categoryTag) {
        this.mCategoryTag = categoryTag;
        return this;
    }

    public NewAppDetailsRecyclerViewAdapter setIsCustomized(boolean isCustomized) {
        this.isCustomized = isCustomized;
        return this;
    }

    public String getScreenPageName() {
        return mScreenPageName;
    }

    public void setPageParamInfo(PageParamInfo pageParamInfo){
        if(null == pageParamInfo || null == pageParamInfo.getCurPage() ){
            pageParamInfo = new PageParamInfo();
        }
        this.mPageParamInfo = pageParamInfo;
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
//  View销毁时不移除监听(内存不足或者复用时可能触发view回收)
//        if (holder instanceof AppDetailsComponentFeatureViewHolder) {
//            AppDetailsComponentFeatureViewHolder viewHolder = (AppDetailsComponentFeatureViewHolder)holder;
//            viewHolder.onDetach();
//        }
        if (holder instanceof AppDetailsComponentAISummaryViewHolder) {
            ((AppDetailsComponentAISummaryViewHolder) holder).cancelAll();
        }
    }

    public void onDestroy(RecyclerView recyclerView) {
        if (recyclerView == null){
            return;
        }

        RecyclerView.LayoutManager lm = recyclerView.getLayoutManager();
        if (!(lm instanceof LinearLayoutManager)) {
            return;
        }
        int total = lm.getChildCount();
        if (total <= 0) {
            return;
        }

        for (int i = 0;i < total;i++) {
            View v = lm.getChildAt(i);
            if (v != null) {
                RecyclerView.ViewHolder holder = recyclerView.getChildViewHolder(v);
                if (holder instanceof AppDetailsComponentFeatureViewHolder) {
                    AppDetailsComponentFeatureViewHolder viewHolder = (AppDetailsComponentFeatureViewHolder)holder;
                    viewHolder.onDetach();
                }
            }
        }
    }
}

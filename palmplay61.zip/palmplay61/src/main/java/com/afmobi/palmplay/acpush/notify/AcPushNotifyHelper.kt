package com.afmobi.palmplay.acpush.notify

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.afmobi.palmplay.acpush.ipc.PushHubClient
import com.afmobi.palmplay.acpush.model.AppGrade
import com.afmobi.palmplay.acpush.model.PushRecordItem
import com.afmobi.palmplay.acpush.repo.AcPushConfigRepo
import com.afmobi.palmplay.cache.InstalledAppsUpdateCache
import com.afmobi.palmplay.model.ClientVersion
import com.afmobi.palmplay.service.DismissNotificationActivity
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler
import com.afmobi.palmplay.main.utils.NOTIFY_ID_AC_UPDATE_HIGH
import com.afmobi.palmplay.main.utils.NOTIFY_ID_AC_UPDATE_NORMAL
import com.afmobi.palmplay.main.utils.NOTIFY_TOPIC_TYPE_FOLD
import com.afmobi.palmplay.main.utils.NOTIFY_TOPIC_TYPE_MULTI_FLOAT
import com.afmobi.palmplay.main.utils.NOTIFY_TOPIC_TYPE_SINGLE_FLOAT
import com.afmobi.palmplay.main.utils.NotificationLayoutManager
import com.afmobi.palmplay.main.utils.getNewest
import com.afmobi.palmplay.setting.MsgDataExtJson
import com.afmobi.util.Constant
import com.afmobi.util.NotificationUtil
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import org.json.JSONObject

/**
 * AC-PUSH 通知渲染入口。
 *
 * 渲染优先级：
 *   S > A > OTHER，每批只弹一个通知。
 *
 *   有 S → 取 priorityScore 最高的 S 走单应用样式（forceMulti=false）
 *   无 S 有 A → 降序取前 5，强制 multi 样式（forceMulti=true，即使只有 1 个）
 *   仅 OTHER → 强制 multi 样式（forceMulti=true）
 *
 * 每次渲染后：
 *   - 写 MMKV["acpush_notif_records"][notifId] = { records_json, sendTime, messageType }
 *   - 按通知上报 IMPRESSION
 *   - 挂 contentIntent → ManageDownloadActivity（点击时同时上报 CLICK + 清 MMKV）
 */
object AcPushNotifyHelper {

    private val TAG = LogUtils.TAG_AC_PUSH

    /** 单一 MMKV key，值为 JSON map：notifId(String) → {records_json, sendTime, messageType} */
    private const val MMKV_NOTIF_RECORDS_KEY = "acpush_notif_records"

    private val gson = Gson()
    private val recordListType = object : TypeToken<List<PushRecordItem>>() {}.type

    /** 保护 MMKV read-modify-write 原子性（多线程：deliver_push / Receiver / JobService） */
    private val mmkvLock = Any()

    // ─────────────────────────────────────────────────────────────────
    // 公开入口
    // ─────────────────────────────────────────────────────────────────

    /**
     * 批量渲染入口。由 DeliverPushHandler (Task 9) 调用。
     *
     * @param context     Application Context
     * @param messageType 消息类型字符串，如 "AC_UPDATE"，用于埋点和 MMKV 记账
     * @param records     本次推送的所有记录，含 appGrade / priorityScore / packageName
     */
    fun renderBatch(context: Context, messageType: String, records: List<PushRecordItem>) {
        if (records.isEmpty()) return

        val sRecords = records.filter { it.appGrade == AppGrade.S }
        val aRecords = records.filter { it.appGrade == AppGrade.A }
        val normal = records.filter { it.appGrade == AppGrade.OTHER }

        when {
            sRecords.isNotEmpty() -> renderHigh(context, messageType, sRecords)
            aRecords.isNotEmpty() -> renderHigh(context, messageType, aRecords)
            normal.isNotEmpty() -> renderNormal(context, messageType, normal)
        }
    }

    /**
     * TRDataJobService 心跳兜底（Task 12 调用）：
     * 对比 NotificationManager 中的活跃通知，对已不在通知栏的条目补上报 DISMISS 并清除 MMKV。
     *
     * 策略：先在锁内快照所有条目（不持锁调用系统 API），再逐 notifId 调 consumeMmkv。
     * 二次确认 + 真正 remove；期间若点击链路已抢先消费，consumeMmkv 返回 null 则跳过。
     */
    fun pollDismiss(context: Context) {
        val mmkv = MMKVUtils.getMMKV()
        // 先快照所有 notifId（持锁）
        val snapshot: Map<Int, Pair<List<PushRecordItem>, String>>
        synchronized(mmkvLock) {
            val root = readRoot(mmkv)
            if (root.length() == 0) return
            val tmp = HashMap<Int, Pair<List<PushRecordItem>, String>>(root.length())
            val keys = root.keys()
            while (keys.hasNext()) {
                val keyStr = keys.next()
                val notifId = keyStr.toIntOrNull() ?: continue
                val entry = root.optJSONObject(keyStr) ?: continue
                try {
                    val records = parseRecords(entry)
                    if (records.isNotEmpty()) {
                        tmp[notifId] = records to entry.optString("messageType", PushHubClient.MESSAGE_TYPE_AC_UPDATE)
                    }
                } catch (e: Exception) {
                    LogUtils.w(TAG, "pollDismiss parse failed for notifId=$notifId", e)
                }
            }
            snapshot = tmp
        }
        if (snapshot.isEmpty()) return

        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val activeIds: Set<Int> = try {
            nm.activeNotifications.map { it.id }.toSet()
        } catch (e: Exception) {
            LogUtils.e(TAG, "getActiveNotifications failed", e)
            return
        }

        for ((notifId, _) in snapshot) {
            if (activeIds.contains(notifId)) continue  // 仍在通知栏 → 跳过
            // 二次确认 + 真正 remove；若期间被点击链路抢先消费，consumeMmkv 返回 null
            val consumed = consumeMmkv(notifId) ?: continue
            val (records, messageType) = consumed
            PushHubClient.reportEvent(context, records, PushHubClient.EventType.DISMISS, messageType)
        }
    }

    /**
     * ManageDownloadActivity / pollDismiss 调用：
     * 取出某 notifId 对应的 PushRecordItem 列表和 messageType，并从 MMKV map 中移除该条目。
     * 操作在 mmkvLock 下执行，保证 read-modify-write 原子性。
     *
     * @return Pair<records, messageType>，若 MMKV 无记录则返回 null
     */
    fun consumeMmkv(notifId: Int): Pair<List<PushRecordItem>, String>? {
        val mmkv = MMKVUtils.getMMKV()
        synchronized(mmkvLock) {
            val root = readRoot(mmkv)
            val key = notifId.toString()
            val entry = root.optJSONObject(key) ?: return null
            root.remove(key)
            // 写回精简后的 root；若为空则清 key 节省空间
            if (root.length() == 0) {
                mmkv.removeValueForKey(MMKV_NOTIF_RECORDS_KEY)
            } else {
                mmkv.encode(MMKV_NOTIF_RECORDS_KEY, root.toString())
            }
            return try {
                val records = parseRecords(entry)
                if (records.isEmpty()) null else records to entry.optString("messageType", PushHubClient.MESSAGE_TYPE_AC_UPDATE)
            } catch (e: Exception) {
                LogUtils.e(TAG, "consumeMmkv parse failed for notifId=$notifId", e)
                null
            }
        }
    }

    /**
     * 本地更新项被安装/删除后，同步 AC 更新通知里的应用列表。
     *
     * 这里不做 CLICK / DISMISS 上报：应用从通知里消失是业务数据变化，不是用户点击或划走。
     */
    @JvmStatic
    fun onUpdateItemRemoved(context: Context, packageName: String?) {
        if (packageName.isNullOrEmpty()) return

        val mmkv = MMKVUtils.getMMKV()
        val rerenderList = mutableListOf<Triple<Int, String, List<PushRecordItem>>>()
        val cancelIds = mutableListOf<Int>()
        synchronized(mmkvLock) {
            val root = readRoot(mmkv)
            var changed = false
            listOf(NOTIFY_ID_AC_UPDATE_HIGH, NOTIFY_ID_AC_UPDATE_NORMAL).forEach { notifId ->
                val key = notifId.toString()
                val entry = root.optJSONObject(key) ?: return@forEach
                val records = parseRecords(entry)
                if (records.none { it.packageName == packageName }) {
                    return@forEach
                }

                val remained = records.filterNot { it.packageName == packageName }
                changed = true
                if (remained.isEmpty()) {
                    root.remove(key)
                    cancelIds.add(notifId)
                } else {
                    val messageType = entry.optString("messageType", PushHubClient.MESSAGE_TYPE_AC_UPDATE)
                    entry.put("records_json", gson.toJson(remained))
                    entry.put("sendTime", System.currentTimeMillis())
                    root.put(key, entry)
                    rerenderList.add(Triple(notifId, messageType, remained))
                }
            }

            if (changed) {
                if (root.length() == 0) {
                    mmkv.removeValueForKey(MMKV_NOTIF_RECORDS_KEY)
                } else {
                    mmkv.encode(MMKV_NOTIF_RECORDS_KEY, root.toString())
                }
            }
        }

        cancelIds.forEach {
            NotificationUtil.cancelNotification(context, it)
            LogUtils.d(TAG, "onUpdateItemRemoved cancel notification, packageName=$packageName, notifId=$it")
        }
        rerenderList.forEach { (notifId, messageType, records) ->
            val forceMulti = notifId == NOTIFY_ID_AC_UPDATE_NORMAL || records.none { it.appGrade == AppGrade.S }
            LogUtils.d(TAG, "onUpdateItemRemoved rerender notification, packageName=$packageName, notifId=$notifId, remainCount=${records.size}")
            renderWith(
                context = context,
                messageType = messageType,
                notifId = notifId,
                records = records,
                forceMulti = forceMulti,
                topicType = NOTIFY_TOPIC_TYPE_FOLD,
                channelNotifyId = NOTIFY_ID_AC_UPDATE_NORMAL,
                reportImpression = false
            )
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // 内部分桶逻辑
    // ─────────────────────────────────────────────────────────────────

    /**
     * HIGH 桶渲染：
     *   - 含 S 等级 → 取 priorityScore 最高的单条 S，走单应用样式（forceMulti=false）
     *   - 纯 A 等级 → 取分数降序前 5，走强制 multi 样式（forceMulti=true）
     */
    private fun renderHigh(context: Context, messageType: String, high: List<PushRecordItem>) {
        val containsS = high.any { it.appGrade == AppGrade.S }
        val (selected, forceMulti) = if (containsS) {
            // 含 S：取分数最高的 S，单应用样式
            val topS = high.filter { it.appGrade == AppGrade.S }.maxByOrNull { it.priorityScore }!!
            listOf(topS) to false
        } else {
            // 纯 A：降序取前 5，强制 multi 样式
            high.sortedByDescending { it.priorityScore }.take(5) to true
        }
        renderWith(
            context = context,
            messageType = messageType,
            notifId = NOTIFY_ID_AC_UPDATE_HIGH,
            records = selected,
            forceMulti = forceMulti,
            topicType = topicTypeFor(NOTIFY_ID_AC_UPDATE_HIGH, forceMulti)
        )
    }

    /**
     * NORMAL 桶渲染：降序取前 5，强制 multi 样式。
     */
    private fun renderNormal(context: Context, messageType: String, normal: List<PushRecordItem>) {
        val selected = normal.sortedByDescending { it.priorityScore }.take(5)
        renderWith(
            context = context,
            messageType = messageType,
            notifId = NOTIFY_ID_AC_UPDATE_NORMAL,
            records = selected,
            forceMulti = true,
            topicType = NOTIFY_TOPIC_TYPE_FOLD
        )
    }

    // ─────────────────────────────────────────────────────────────────
    // 通知渲染核心
    // ─────────────────────────────────────────────────────────────────

    /**
     * 真正调用 NotificationLayoutManager.notifyAcPushUpdate 渲染通知，
     * 并在渲染成功后：写 MMKV、上报 IMPRESSION。
     */
    private fun renderWith(
        context: Context,
        messageType: String,
        notifId: Int,
        records: List<PushRecordItem>,
        forceMulti: Boolean,
        topicType: String,
        // 只用于选择通知 channel / builder。安装或卸载后刷新已有通知时，用普通 channel 初始化，
        // 避免高优先级通知内容更新再次触发悬浮；真正 notify/cancel/mmkv 仍使用 notifId。
        channelNotifyId: Int = notifId,
        reportImpression: Boolean = true
    ) {
        val uniqueRecords = distinctByPackageName(records)
        // 用 packageName 从 InstalledAppsUpdateCache 取 UpdateItem 拼装通知数据
        val wrapper    = InstalledAppsUpdateCache.getInstance().getUpdateItemList()
        val allItems   = wrapper?.updateList ?: emptyList()
        val byPkg      = allItems.associateBy { it.packageName }
        val displayPairs = uniqueRecords.mapNotNull { record ->
            byPkg[record.packageName]?.let { record to it }
        }
        val displayRecords = displayPairs.map { it.first }
        val updateItems = displayPairs.map { it.second }

        val recordPackages = records.map { it.packageName }
        val uniquePackages = uniqueRecords.map { it.packageName }
        val missingPackages = uniquePackages.filterNot { byPkg.containsKey(it) }
        LogUtils.d(
            TAG,
            "renderWith filter result, notifId=$notifId, forceMulti=$forceMulti, messageType=$messageType, " +
                "recordCount=${records.size}, uniqueRecordCount=${uniqueRecords.size}, localUpdateCount=${allItems.size}, matchedCount=${updateItems.size}, " +
                "missingCount=${missingPackages.size}, recordPackages=$recordPackages, uniquePackages=$uniquePackages, missingPackages=$missingPackages"
        )

        if (updateItems.isEmpty()) {
            LogUtils.w(TAG, "renderWith: no matching UpdateItem for records=$recordPackages, uniqueRecords=$uniquePackages, localUpdateCount=${allItems.size}")
            return
        }

        try {
            NotificationLayoutManager
                .initNotification(context, channelNotifyId)
                .notifyAcPushUpdate(
                    context     = context,
                    items       = updateItems,
                    acNotifyId  = notifId,
                    forceMulti  = forceMulti,
                    topicType   = topicType,
                    reportExposure = reportImpression
                ) { builder ->
                    // contentIntent：点击跳转下载管理，携带 notifId 供下游清账
                    builder?.setContentIntent(buildContentIntent(context, notifId, messageType, topicType, updateItems.getNewest()))
                }

            // 渲染成功后落 MMKV 记账
            writeMmkv(notifId, displayRecords, messageType)

            // 渲染后按通知上报 IMPRESSION
            if (reportImpression) {
                PushHubClient.reportEvent(context, displayRecords, PushHubClient.EventType.IMPRESSION, messageType)
            }
        } catch (e: Exception) {
            LogUtils.e(TAG, "renderWith failed for notifId=$notifId", e)
        }
    }

    private fun topicTypeFor(notifId: Int, forceMulti: Boolean): String {
        return when {
            notifId == NOTIFY_ID_AC_UPDATE_NORMAL -> NOTIFY_TOPIC_TYPE_FOLD
            forceMulti -> NOTIFY_TOPIC_TYPE_MULTI_FLOAT
            else -> NOTIFY_TOPIC_TYPE_SINGLE_FLOAT
        }
    }

    private fun distinctByPackageName(records: List<PushRecordItem>): List<PushRecordItem> {
        if (records.size <= 1) return records
        val seen = LinkedHashSet<String>()
        return records.filter { seen.add(it.packageName) }
    }

    // ─────────────────────────────────────────────────────────────────
    // Intent 构建
    // ─────────────────────────────────────────────────────────────────

    /** 点击 PendingIntent 走 DismissNotificationActivity → PalmstoreSysHandler dispatch 体系 */
    private fun buildContentIntent(
        context: Context,
        notifId: Int,
        messageType: String,
        topicType: String,
        updateItem: ClientVersion.UpdateItem?
    ): PendingIntent {
        val intent = Intent(context, DismissNotificationActivity::class.java).apply {
            action = PalmstoreSysHandler.ACTION_NOTIFICATION_AC_PUSH_CLICK
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("acpush_notif_id", notifId)
            putExtra("acpush_message_type", messageType)
            putExtra(Constant.KEY_PACKAGE_NAME, updateItem?.packageName?.ifEmpty { updateItem.itemID ?: "" })
            putExtra(Constant.KEY_ITEMID, updateItem?.itemID?.ifEmpty { "" })
            putExtra(Constant.KEY_EXTID, AcPushConfigRepo.expId())
            putExtra(TRAnalyticsConstant.VARID, AcPushConfigRepo.varId())
            putExtra(TRAnalyticsConstant.TOPICTYPE, topicType)
            putExtra(MsgDataExtJson.TASK_ID, updateItem?.taskId ?: 0L)
        }
        return PendingIntent.getActivity(
            context, notifId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // ─────────────────────────────────────────────────────────────────
    // MMKV 记账
    // ─────────────────────────────────────────────────────────────────

    /**
     * 将本次通知实际展示的 records / sendTime / messageType 写入单一 MMKV key 的 JSON map 中。
     * 在 mmkvLock 下执行，保证 read-modify-write 原子性。
     */
    private fun writeMmkv(notifId: Int, records: List<PushRecordItem>, messageType: String) {
        val mmkv = MMKVUtils.getMMKV()
        synchronized(mmkvLock) {
            val root = readRoot(mmkv)
            val entry = JSONObject()
                .put("records_json", gson.toJson(records))
                .put("sendTime", System.currentTimeMillis())
                .put("messageType", messageType)
            root.put(notifId.toString(), entry)
            mmkv.encode(MMKV_NOTIF_RECORDS_KEY, root.toString())
        }
    }

    private fun parseRecords(entry: JSONObject): List<PushRecordItem> {
        val recordsJson = entry.optString("records_json")
        if (recordsJson.isNullOrEmpty()) return emptyList()
        return try {
            gson.fromJson<List<PushRecordItem>>(recordsJson, recordListType) ?: emptyList()
        } catch (e: Exception) {
            LogUtils.w(TAG, "parseRecords failed", e)
            emptyList()
        }
    }

    /**
     * 读取 MMKV 中的通知记账 JSON root 对象；解析失败或不存在时返回空对象。
     * 调用方需持有 mmkvLock。
     */
    private fun readRoot(mmkv: com.tencent.mmkv.MMKV): JSONObject {
        val raw = mmkv.decodeString(MMKV_NOTIF_RECORDS_KEY)
        if (raw.isNullOrEmpty()) return JSONObject()
        return try {
            JSONObject(raw)
        } catch (e: Exception) {
            LogUtils.w(TAG, "readRoot parse failed, resetting", e)
            JSONObject()
        }
    }
}

package com.afmobi.palmplay.acpush.repo

import android.content.Context
import com.afmobi.palmplay.acpush.ipc.PushHubClient
import com.afmobi.palmplay.acpush.model.OnFetchedListener
import com.afmobi.palmplay.cache.InstalledAppsUpdateCache
import com.afmobi.palmplay.model.ClientVersion
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.ConcurrentModificationException

/**
 * AC-PUSH 拉取调度。
 *
 * 职责：
 *   1. 实现 OnFetchedListener：拉取成功后调 PushHubClient 上报候选包并完成 provider 注册
 *   2. 提供 tick()：由 TRDataJobService 每小时调用，按 updateCfg.fastInterval 节流，触发高频 S/A 拉取
 *
 * S/A 包名列表由 update_config 下发并单独存储，不写入 UpdateItem。
 */
@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
object AcPushUpdateRepository : OnFetchedListener {

    private val TAG = LogUtils.TAG_AC_PUSH

    private const val KEY_LOCAL_UPDATE_ITEMS_DELIVERED = "acpush_local_update_items_delivered"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO.limitedParallelism(1))

    @Volatile private var appContext: Context? = null

    /** PalmplayApplication.onCreate 调用：注入 context + 注册 listener。不立即触发任何拉取。 */
    fun bootstrap(context: Context) {
        appContext = context.applicationContext
        InstalledAppsUpdateCache.getInstance().setOnFetchedListener(this)
    }

    /**
     * OnFetchedListener 实现：常规 / 手动 / 高频拉取后都走这里，source 为 TIMER / HAND / HIGH_FREQ_SA。
     *
     * 开关为 null 表示 PM config 尚未下发；此时也需要调用 receiveMessage 完成 provider 注册，
     * 后续 PM 才能下发 update_config。
     */
    override fun onFetched(items: List<ClientVersion.UpdateItem>, source: String) {
        val ctx = appContext ?: return
        val enabledState = AcPushConfigRepo.enabledState()
        val prepared = prepareReceiveMessageItems(items)
        LogUtils.d(
            TAG,
            "update api fetched, source=$source, itemCount=${items.size}, receiveItemCount=${prepared.items.size}, " +
                "localAppendCount=${prepared.localAppendCount}, localChecked=${prepared.localChecked}, enabledState=$enabledState"
        )
        if (enabledState == false) {
            LogUtils.d(TAG, "skip pm receive_message after update api fetched, source=$source, enabledState=false")
            return
        }
        if (prepared.localChecked && prepared.items.isEmpty()) {
            LogUtils.d(
                TAG,
                "skip pm receive_message because no items need deliver, source=$source, itemCount=${items.size}, " +
                    "localChecked=${prepared.localChecked}"
            )
            return
        }
        scope.launch {
            try {
                LogUtils.d(TAG, "calling pm receive_message from onFetched, source=$source, itemCount=${prepared.items.size}, enabledState=$enabledState")
                if (!PushHubClient.receiveMessage(ctx, prepared.items)) {
                    return@launch
                }
                if (!prepared.localChecked) {
                    MMKVUtils.getMMKV().encode(KEY_LOCAL_UPDATE_ITEMS_DELIVERED, true)
                    LogUtils.d(
                        TAG,
                        "local update items checked for pm, localItemCount=${prepared.localItemCount}, localAppendCount=${prepared.localAppendCount}"
                    )
                }
            } catch (e: Exception) {
                LogUtils.e(TAG, "onFetched failed", e)
            }
        }
    }

    /**
     * 组装传给 PM receive_message 的应用列表。
     *
     * 首次接入时，更新接口可能返回空列表，但本地缓存里已经有可更新应用；如果不把这批本地数据补传给 PM，
     * PM 就无法完成 AC provider 注册，也拿不到当前已有更新应用作为 AC 侧候选数据。这里通过独立 MMKV 标记
     * [KEY_LOCAL_UPDATE_ITEMS_DELIVERED] 记录“本地缓存已检查过”：如果首次本地就没有数据，后续也不再补传；
     * 如果本地有数据，则只补传一次。只有 receive_message 成功后才会写入标记。
     *
     * 合并规则：接口返回 items 优先，本地缓存 updateList 只补 packageName 不存在的项，避免同包重复。
     */
    private fun prepareReceiveMessageItems(items: List<ClientVersion.UpdateItem>): PreparedItems {
        val localChecked = MMKVUtils.getMMKV().decodeBool(KEY_LOCAL_UPDATE_ITEMS_DELIVERED, false)
        if (localChecked) {
            return PreparedItems(items, localAppendCount = 0, localItemCount = 0, localChecked = true)
        }
        val localItems = getLocalUpdateItemsSnapshot()
        if (localItems.isEmpty()) {
            return PreparedItems(items, localAppendCount = 0, localItemCount = 0, localChecked = false)
        }
        val merged = LinkedHashMap<String, ClientVersion.UpdateItem>(items.size + localItems.size)
        for (item in items) {
            val pkg = item.packageName ?: continue
            merged[pkg] = item
        }
        var appended = 0
        for (item in localItems) {
            val pkg = item.packageName ?: continue
            if (!merged.containsKey(pkg)) {
                merged[pkg] = item
                appended++
            }
        }
        return PreparedItems(
            items = merged.values.toList(),
            localAppendCount = appended,
            localItemCount = localItems.size,
            localChecked = false
        )
    }

    private fun getLocalUpdateItemsSnapshot(): List<ClientVersion.UpdateItem> {
        return try {
            InstalledAppsUpdateCache.getInstance()
                .getUpdateItemList()
                ?.updateList
                ?.toList()
                .orEmpty()
        } catch (e: ConcurrentModificationException) {
            LogUtils.e(TAG, "read local update items failed", e)
            emptyList()
        }
    }

    private data class PreparedItems(
        val items: List<ClientVersion.UpdateItem>,
        val localAppendCount: Int,
        val localItemCount: Int,
        val localChecked: Boolean
    )

    /**
     * TRDataJobService 心跳调用。
     *
     * - 未启用 → 直接 return
     * - 距上次高频拉取不足 updateCfg.fastInterval 小时 → 节流
     * - 满足条件 → 触发高频 S/A 拉取；包名来自 update_config 下发并存储的 hight_grade_list。
     */
    fun tick() {
        val enabled = AcPushConfigRepo.isEnabled()
        LogUtils.d(TAG, "high freq tick, enabled=$enabled")
        if (!enabled) return
        scope.launch {
            try {
                val mmkv = MMKVUtils.getMMKV()
                val now = System.currentTimeMillis()
                val last = mmkv.decodeLong(InstalledAppsUpdateCache.KEY_LAST_HIGH_FREQ_MS, 0L)
                val intervalMs = AcPushConfigRepo.highFreqHour() * 3600_000L
                if (now - last < intervalMs) return@launch

                InstalledAppsUpdateCache.getInstance().sendHighGradeCheckAppsUpdateRequest()
            } catch (e: Exception) {
                LogUtils.e(TAG, "tick failed", e)
            }
        }
    }

}

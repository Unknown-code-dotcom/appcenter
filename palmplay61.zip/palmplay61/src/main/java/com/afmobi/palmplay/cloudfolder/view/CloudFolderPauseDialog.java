package com.afmobi.palmplay.cloudfolder.view;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.util.DisplayUtil;
import com.afmobi.util.PadUtils;
import com.transsion.palmstorecore.util.DeviceTypeExKt;
import com.transsnet.store.R;

import androidx.annotation.NonNull;

public class CloudFolderPauseDialog extends Dialog {

    public static final int STATUS_CONFIRM = 1;
    public static final int STATUS_CANCEL = 2;
    public static final int STATUS_KEY_BACK = 3;

    public static final int STYLE_CANCEL = 2;
    public static final int STYLE_PAUSE = 1;
    private final int downloadStyle;

    private OnDialogListener onDialogListener;

    public CloudFolderPauseDialog(@NonNull Context context, int downloadStyle, OnDialogListener onDialogListener) {
        super(context, isPadDialog(context) ? R.style.DialogPrivacyPadStyle : R.style.DialogPrivacyStyle);
        this.downloadStyle = downloadStyle;
        this.onDialogListener = onDialogListener;
    }

    private static boolean isPadDialog(Context context) {
        return DeviceTypeExKt.isPadDisplay(
                context,
                context.getResources().getConfiguration(),
                DeviceTypeExKt.getContextDisplayId(context));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_layout_folder_pause);
        setCanceledOnTouchOutside(false);

        View rootView = findViewById(R.id.dialog_root);
        View dialogCard = findViewById(R.id.dialog_card);
        TextView cancelView = findViewById(R.id.tv_cancel);
        TextView confirmView = findViewById(R.id.tv_confirm);
        TextView textTitle = findViewById(R.id.tv_title);

        if (isPadDialog(getContext())) {
            centerPadDialogCard(dialogCard);
        } else {
            rootView.setPadding(0, 0, 0, DisplayUtil.dip2px(getContext(), 28));
        }

//        CloudFolderTrackUtil.tecTrack(CloudFolderTrackUtil.TYPE_PAUSE_DIALOG, CloudFolderTrackUtil.TYPE_SHOW, String.valueOf(downloadStyle), "");
        if(downloadStyle == STYLE_CANCEL) {
            cancelView.setText(getContext().getResources().getString(R.string.shortcut_pop_cancel_install));
            textTitle.setText(getContext().getResources().getString(R.string.text_folder_dialog_cancel_content));
            cancelView.setTextSize(TypedValue.COMPLEX_UNIT_SP,15f);
            confirmView.setText(getContext().getResources().getString(R.string.txt_waiting_wifi));
        }

        confirmView.setOnClickListener(v -> {
            if (onDialogListener != null) {
                onDialogListener.onClick(STATUS_CONFIRM);
            }
//            CloudFolderTrackUtil.tecTrack(CloudFolderTrackUtil.TYPE_PAUSE_DIALOG, CloudFolderTrackUtil.TYPE_CLICK, String.valueOf(downloadStyle), "confirm");
            dismiss();
        });
        cancelView.setOnClickListener(v -> {
            if (onDialogListener != null) {
                onDialogListener.onClick(STATUS_CANCEL);
            }
//            CloudFolderTrackUtil.tecTrack(CloudFolderTrackUtil.TYPE_PAUSE_DIALOG, CloudFolderTrackUtil.TYPE_CLICK, String.valueOf(downloadStyle), "cancel");
            dismiss();
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, @NonNull KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (onDialogListener != null) {
                onDialogListener.onClick(STATUS_KEY_BACK);
//                CloudFolderTrackUtil.tecTrack(CloudFolderTrackUtil.TYPE_PAUSE_DIALOG, CloudFolderTrackUtil.TYPE_CLICK, String.valueOf(downloadStyle), "key_back");
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    public interface OnDialogListener {
        void onClick(int status);
    }
    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadDialog(this);
    }

    @Override
    public void show() {
        super.show();
        PadUtils.applyPadDialog(this);
    }

    private void centerPadDialogCard(View dialogCard) {
        if (dialogCard == null || !(dialogCard.getLayoutParams() instanceof RelativeLayout.LayoutParams)) {
            return;
        }
        RelativeLayout.LayoutParams cardParams = (RelativeLayout.LayoutParams) dialogCard.getLayoutParams();
        cardParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, 0);
        cardParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        cardParams.bottomMargin = 0;
        dialogCard.setLayoutParams(cardParams);
    }

}

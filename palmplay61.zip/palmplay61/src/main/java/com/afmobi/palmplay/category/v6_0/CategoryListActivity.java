// TOP SECRET
package com.afmobi.palmplay.category.v6_0;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.configs.ImageConfig;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.main.adapter.v6_3.CommonSoftRecyclerAdapter;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.AppSubCategoryInfo;
import com.afmobi.palmplay.model.TagItemList;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.appbar.AppBarLayout;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.R;
import com.transsnet.store.databinding.CategoryMoreBinding;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import xyz.doikki.videoplayer.util.PlayerUtils;

/**
 * GAME、APP tab下的CATEGORY tab下的分类详情页面
 */
public class CategoryListActivity extends BaseEventFragmentActivity implements OnViewLocationInScreen, View.OnClickListener, AppBarLayout.OnOffsetChangedListener {

    public static final String KEY_TAB_TYPE = "tabType";
    public static final String KEY_TAB_ID = "tabID";
    public static final String KEY_SUB_CATEGORY_INFO = "SubCategoryInfo";

    private UINetworkErrorUtil mUINetworkErrorUtil = UINetworkErrorUtil.create();
    private UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();

    private String mTabID;
    private String mTabType;
    private AppSubCategoryInfo mAppSubCategoryInfo;

    private boolean isRequesting = false;
    private boolean isOnRefreshing = false;
    private CommonSoftRecyclerAdapter mCommonSoftRecyclerAdapter;

    protected int currentOffset;

    // 头布局的高度
    protected int headerHeight;
    private int screenWidth;
    private boolean isFirstActivity = true;

    private TagItemList<AppInfo> mCategoryAppTagItemList;
    private int mPageIndex;

    private CategoryMoreBinding mDataBinding;
    private String value;
    private String mFrom;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDataBinding = DataBindingUtil.setContentView(this, R.layout.activity_category_type_more);
        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }
        Bundle bundle = intent.getBundleExtra(CategoryListActivity.class.getSimpleName());
        if (bundle == null || !bundle.containsKey(CategoryListActivity.KEY_SUB_CATEGORY_INFO)
                || !bundle.containsKey(CategoryListActivity.KEY_TAB_ID)
                || !bundle.containsKey(CategoryListActivity.KEY_TAB_TYPE)) {
            finish();
            return;
        }

        mTabID = bundle.getString(CategoryListActivity.KEY_TAB_ID);
        mTabType = bundle.getString(CategoryListActivity.KEY_TAB_TYPE);
        mAppSubCategoryInfo = (AppSubCategoryInfo) bundle.getSerializable(CategoryListActivity.KEY_SUB_CATEGORY_INFO);
        mPageParamInfo.setLastPage(bundle.getString(PageConstants.PAGE_KEY_LASTPAGE));
        mFrom = bundle.getString(TRAnalyticsConstant.VALUE);

        if (!TextUtils.isEmpty(mTabID) && mAppSubCategoryInfo != null && !TextUtils.isEmpty(mAppSubCategoryInfo.categoryID)) {
            mPageParamInfo.setCurPage(PageConstants.Category_xxxx + mAppSubCategoryInfo.categoryID);
        } else {
            finish();
            return;
        }

        screenWidth = DisplayUtil.getScreenWidthPx(PalmplayApplication.getAppInstance()) + DisplayUtil.getInsetsMargin(PalmplayApplication.getAppInstance());
        initView();
        init();

        setEmptyViewCenter();
    }

    /**
     * 空态页居中显示
     */
    private void setEmptyViewCenter() {
        int height = DisplayUtil.getScreenHeight(this);
        int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.empty_view_height);
        int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
        int halfMarginTop = (height - emptyLayoutHeight) / 2;
        int statusBarHeight = (int) PlayerUtils.getStatusBarHeight(this);
        int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight;
        if (finalMarginTop <= 0) {
            finalMarginTop = 0;
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mDataBinding.layoutEmptyView.layoutEmptyViewRoot.getLayoutParams();
        params.topMargin = finalMarginTop;
        mDataBinding.layoutEmptyView.layoutEmptyViewRoot.setLayoutParams(params);
    }

    protected void init() {
        mDataBinding.layoutTitle.layotDetailBack.setImageResource(R.drawable.selector_title_img_back);
        mDataBinding.layoutTitle.ivDownload.setImageResource(R.drawable.ic_detail_dl_count);
        mDataBinding.layoutTitle.layoutTitleRightSearch.setImageResource(R.drawable.ic_detail_search_ic);
        TRStatusBarUtil.setStatusBarTextColor(getWindow(), true);

        request();
        mUILoadingGifUtil.setVisibility(isRequesting ? View.VISIBLE : View.GONE);
    }

    private void initView() {
        mUILoadingGifUtil.inflate(this, mDataBinding.clView);
        mUILoadingGifUtil.setVisibility(isRequesting ? View.VISIBLE : View.GONE);

        mUINetworkErrorUtil.inflate(this, mDataBinding.clView, true)
                .setFrom(mFrom)
                .setVisibility(View.GONE)
                .setUINetworkErrorOnClickListener(new UINetworkErrorUtil.UINetworkErrorOnClickListener() {

                    @Override
                    public void onUINetworkErrorClick(View v) {
                        if (v == null) return;

                        if (v.getId() == R.id.tv_setting) {
                            mUINetworkErrorUtil.setVisibility(View.GONE);
                            mUILoadingGifUtil.setVisibility(View.VISIBLE);
                            request();
                            SysUtils.openSystemMobileNetworkSettings(CategoryListActivity.this, TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
                        }
                    }
                });

        setSystemBarColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
        headerHeight = ImageConfig.getImageHeight(screenWidth, ImageConfig.FEATURES_BANNER_IMG_WIDTH_HEIGHT_PERCENT);

        //Title Layout
        mDataBinding.layoutTitle.layotDetailDownload.setOnClickListener(this);
        mDataBinding.layoutTitle.layotDetailBack.setOnClickListener(this);
        mDataBinding.layoutTitle.layoutTitleRightSearch.setOnClickListener(this);

        mDataBinding.layoutTitle.layotDetailTitle.setText(mAppSubCategoryInfo.name);
        // tittle  end  --------

        mDataBinding.mainAppbar.addOnOffsetChangedListener(this);

        mDataBinding.layoutEmptyView.tvContent.setText(R.string.no_related_resource);

        TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mDataBinding.xrecyclerview.setLayoutManager(linearLayoutManager);
        mDataBinding.xrecyclerview.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
        mDataBinding.xrecyclerview.setLoadingListener(mXRecyclerViewLoadingListener);
        mCommonSoftRecyclerAdapter = new CommonSoftRecyclerAdapter(this, getAppInfoList(), mDataBinding.xrecyclerview, getFromPage(), mPageParamInfo, true, false, true);
        mDataBinding.xrecyclerview.setAdapter(mCommonSoftRecyclerAdapter);
        mCommonSoftRecyclerAdapter.setOnViewLocationInScreen(this);
        mCommonSoftRecyclerAdapter.onCreateView();
        mCommonSoftRecyclerAdapter.setIMessenger(new IMessenger() {

            @Override
            public void onMessenger(Object... objects) {
                setUpdatedAppCount();
            }
        });
        mCommonSoftRecyclerAdapter.setScreenPageName(TRAnalyticsConstant.PAGE_CATEGORY_LIST);
        mCommonSoftRecyclerAdapter.setFrom(mFrom);
        mDataBinding.xrecyclerview.setPullRefreshEnabled(false);
        addNoMore(mDataBinding.xrecyclerview, linearLayoutManager, mDataBinding.mainAppbar);
        mUILoadingGifUtil.inflate(this, mDataBinding.clView);
        value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_CATEGORY_LIST,"","","");

        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(value)
                .setFrom(mFrom);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    @Override
    public String getValue() {
        return value;
    }

    private XRecyclerView.LoadingListener mXRecyclerViewLoadingListener = new XRecyclerView.LoadingListener() {
        @Override
        public void onRefresh() {
            if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                ToastManager.getInstance().show(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
                if (mDataBinding.xrecyclerview != null) {
                    mDataBinding.xrecyclerview.refreshComplete();
                }
                return;
            }
            mPageIndex = 0;
            isOnRefreshing = true;
            request();
        }

        @Override
        public void onLoadMore() {
            mPageIndex = mCategoryAppTagItemList == null ? 0 : mCategoryAppTagItemList.pageIndex + 1;
            request();
        }
    };

    private void setUpdatedAppCount() {
        TRHomeUtil.refreshAppCount(mDataBinding.layoutTitle.tvDownloadingCount, null);
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onResume();

        if (!isRequesting) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }

        setUpdatedAppCount();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //旋转不重建：刷新缓存屏宽/头部图高度并重绑列表，使条目与头部尺寸随横竖屏自适应
        screenWidth = DisplayUtil.getScreenWidthPx(PalmplayApplication.getAppInstance())
                + DisplayUtil.getInsetsMargin(PalmplayApplication.getAppInstance());
        headerHeight = ImageConfig.getImageHeight(screenWidth, ImageConfig.FEATURES_BANNER_IMG_WIDTH_HEIGHT_PERCENT);
        if (mCommonSoftRecyclerAdapter != null) {
            mCommonSoftRecyclerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onDestroy();

        if (mDataBinding.xrecyclerview != null) {
            mDataBinding.xrecyclerview.loadMoreComplete();
            mDataBinding.xrecyclerview.refreshComplete();
        }
        mXRecyclerViewLoadingListener = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layot_detail_back:
                finish();
                backButtonTrack();
                break;

            case R.id.layot_detail_download:
                TRJumpUtil.into(this, false, mPageParamInfo,value);
                break;

            case R.id.layout_title_right_search:
                TRJumpUtil.switchToSearchActivity(this, TabType.SOFT, "", false, "", false,
                        "", mPageParamInfo, value, TRAnalyticsConstant.BUTTON_SEARCH_IMG);
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        backButtonTrack();
    }

    private void backButtonTrack() {
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        super.onEventMainThread(mEventMainThreadEntity);

        if (mEventMainThreadEntity.getAction().equals(getNetworkActionWithID())) {
            TagItemList<AppInfo> curPageTagItemList = (TagItemList<AppInfo>) mEventMainThreadEntity.get("CategoryAppTagItemList");
            mCategoryAppTagItemList = TRHomeUtil.checkHotModelData(mCategoryAppTagItemList, curPageTagItemList);

            isRequesting = false;
            if (mDataBinding.xrecyclerview != null) {
                mDataBinding.xrecyclerview.setEmptyView(mDataBinding.layoutEmptyView.layoutEmptyViewRoot);
                mDataBinding.xrecyclerview.loadMoreComplete();
            }
            if (mUILoadingGifUtil != null) {
                mUILoadingGifUtil.setVisibility(View.GONE);
            }

            List<AppInfo> appInfoList = getAppInfoList();
            if (mEventMainThreadEntity.isSuccess) {

                if (mCommonSoftRecyclerAdapter != null) {
                    mCommonSoftRecyclerAdapter.setData(getAppInfoList());
                }

                appInfoList = getAppInfoList();
                if (appInfoList != null && appInfoList.size() > 0) {
                    setHeaderView();
                }
                if (mCategoryAppTagItemList != null && mCategoryAppTagItemList.isPageLast(TRHomeUtil.MAX_PAGE_SIZE) && mDataBinding.xrecyclerview != null) {
                    mDataBinding.xrecyclerview.setNoMore(true);
                } else {
                    if (mDataBinding.xrecyclerview != null) {
                        mDataBinding.xrecyclerview.loadMoreComplete();
                    }
                }

            } else {
                if (null != appInfoList && !appInfoList.isEmpty()) {
                    CommonUtils.showToastInfo(PalmplayApplication.getAppInstance(), null);
                } else {
                    //mUINetworkErrorUtil.setVisibility(View.VISIBLE);
                    mDataBinding.layoutEmptyView.layoutEmptyViewRoot.setVisibility(View.VISIBLE);
                }
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_REFRESH_TAB_RED_POINT)) { //刷新角标
            setUpdatedAppCount();
        }
    }

    protected final String getNetworkActionWithID() {
        return NetworkActions.ACTION_CATEGORY_LIST + getTabType() + getTabID() + getCategoryID();
    }

    protected final String getTabType() {
        return TextUtils.isEmpty(mTabType) ? "" : mTabType;
    }

    protected final String getTabID() {
        return TextUtils.isEmpty(mTabID) ? "" : mTabID;
    }

    private String getCategoryID() {
        return mAppSubCategoryInfo == null ? "" : TextUtils.isEmpty(mAppSubCategoryInfo.categoryID) ? "" : mAppSubCategoryInfo.categoryID;
    }

    private String getFromPage() {
        //return Constant.NEW_FROMPAGE_CATEGORY;
        return getTabType() + getTabID();
    }

    private List<AppInfo> getAppInfoList() {
        return mCategoryAppTagItemList == null ? null : mCategoryAppTagItemList.itemList;
    }

    private void request() {
        isRequesting = true;
        NetworkClient.categoryListHttpRequest63(getNetworkActionWithID(), getCategoryID(), mPageIndex, mPageParamInfo);

        if (mDataBinding.xrecyclerview != null)
            mDataBinding.xrecyclerview.setEmptyView(null);

        if (mDataBinding.layoutEmptyView.layoutEmptyViewRoot != null)
            mDataBinding.layoutEmptyView.layoutEmptyViewRoot.setVisibility(View.GONE);
    }


    /**************************** for animation start *********************************/
    @Override
    public Object onPreparedCallback(Object obj) {
        return obj;
    }

    @Override
    public Object getObject(Object obj) {
        return mDataBinding.layoutTitle.layotDetailDownload;
    }

    @Override
    public int[] onEndTranslateAnimationLocationOnScreen(Object obj) {
        int[] endTranslateAnimationLocationOnScreen = new int[2];
        if (mDataBinding.clView != null && mDataBinding.clView.getChildCount() > 0 && mDataBinding.layoutTitle.layotDetailDownload != null && mDataBinding.layoutTitle.layotDetailDownload.getVisibility() != View.GONE) {
            mDataBinding.layoutTitle.layotDetailDownload.getLocationOnScreen(endTranslateAnimationLocationOnScreen);
            int viewWidth = mDataBinding.layoutTitle.layotDetailDownload.getWidth();
            if (viewWidth > 0)
                endTranslateAnimationLocationOnScreen[0] = endTranslateAnimationLocationOnScreen[0] + viewWidth / 4;// 3;
        }
        return endTranslateAnimationLocationOnScreen;
    }

    @Override
    public Object onAnimationEndCallback(Object obj) {
        return obj;
    }

    /**************************** for animation end *********************************/


    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        int abOffset = Math.abs(verticalOffset);
        float alpha = abOffset / (float) appBarLayout.getTotalScrollRange();//796
        /*
         * monkey空指针异常
         * java.lang.NullPointerException: Attempt to invoke virtual method 'void com.jcodecraeer.xrecyclerview.XRecyclerView.scrollToPosition(int)' on a null object reference
         */
        if (mDataBinding.xrecyclerview == null) {
            return;
        }
        if (verticalOffset == 0) {
            mDataBinding.xrecyclerview.scrollToPosition(0);
        }
        if (abOffset > currentOffset) {//上拉
            setAlphaByScroll(abOffset, alpha);
        } else if (abOffset == currentOffset) {//静止
//            setAlphaByScroll(abOffset, alpha);
//            if(alpha == 0.0){
//                iv_back.setBackgroundResource(R.drawable.selector_title_img_back);
//                iv_download.setBackgroundResource(R.drawable.selector_btn_download_2);
//            }
        } else {//下拉
            setAlphaByScroll(abOffset, alpha);
        }
        currentOffset = abOffset;
    }

    protected void setAlphaByScroll(int offset, float alpha) {
        try {
            LogUtils.e("setAlphaByScroll==>" + alpha);
            if (alpha > 0.4) {
                setSystemBarColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
                mDataBinding.layoutTitle.layotDetailBack.setImageResource(R.drawable.selector_title_img_back);
                mDataBinding.layoutTitle.ivDownload.setImageResource(R.drawable.ic_detail_dl_count);
                mDataBinding.layoutTitle.layoutTitleRightSearch.setImageResource(R.drawable.ic_detail_search_ic);
                TRStatusBarUtil.setStatusBarTextColor(getWindow(), true);
            } else {
                setSystemBarColor(0x33000000);
                mDataBinding.layoutTitle.layotDetailBack.setImageResource(R.drawable.selector_title_img_back_white);
                mDataBinding.layoutTitle.ivDownload.setImageResource(R.drawable.ic_detail_dl_count_white);
                mDataBinding.layoutTitle.layoutTitleRightSearch.setImageResource(R.drawable.ic_detail_search_white);
                TRStatusBarUtil.setStatusBarTextColor(getWindow(), false);
            }
            if (alpha == 1.0) {
                mDataBinding.layoutTitle.layotDetailTitle.setVisibility(View.VISIBLE);
            } else {
                mDataBinding.layoutTitle.layotDetailTitle.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }

    public void setHeaderView() {
        try {

            if (!isFirstActivity) {
                return;
            }
            setSystemBarColor(0x33000000);
            isFirstActivity = false;

            mDataBinding.layoutTitle.layotDetailBack.setImageResource(R.drawable.selector_title_img_back_white);
            mDataBinding.layoutTitle.ivDownload.setImageResource(R.drawable.ic_detail_dl_count_white);
            mDataBinding.layoutTitle.layoutTitleRightSearch.setImageResource(R.drawable.ic_detail_search_white);
            TRStatusBarUtil.setStatusBarTextColor(getWindow(), false);
            mDataBinding.layoutTitle.layoutDetailTitle.setBackgroundColor(getResources().getColor(android.R.color.transparent));

            mDataBinding.mainToolbar.setBackgroundResource(R.drawable.bg_title_shade);

            ImageView iv_avatar_cover = mDataBinding.clView.findViewById(R.id.iv_avatar_cover);
            android.widget.RelativeLayout.LayoutParams iv_avatar_cover_params =
                    (android.widget.RelativeLayout.LayoutParams) iv_avatar_cover.getLayoutParams();
            iv_avatar_cover_params.width = screenWidth;
            iv_avatar_cover_params.height = headerHeight;
            iv_avatar_cover.requestLayout();

            /*编译版本改成8.0的时候，appbarlayout高度的问题*/
            mDataBinding.mainAppbar.getLayoutParams().height = headerHeight + DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 3);

            String bannerUrl = mCategoryAppTagItemList == null ? null : mCategoryAppTagItemList.bannerUrl;
            String titleStr = mCategoryAppTagItemList == null ? null : mCategoryAppTagItemList.name;
            String infoDescrible = mCategoryAppTagItemList == null ? null : mCategoryAppTagItemList.info;
            mDataBinding.layoutHeaderBanner.describeTitle.setText(titleStr);
            mDataBinding.layoutHeaderBanner.describeDetail.setText(infoDescrible);
            mDataBinding.layoutTitle.layotDetailTitle.setText(titleStr);
            //bannerUrl = "http://47.106.36.61:6060/static/857/7ffe8b459b664661afc21623bf0b20aa.png";

            mDataBinding.layoutHeaderBanner.layoutHeaderDescribe.setVisibility(View.VISIBLE);
            if (TextUtils.isEmpty(bannerUrl)) {
                iv_avatar_cover.setImageResource(R.drawable.img_header_banner_applist);
            } else {
                mDataBinding.layoutHeaderBanner.layoutHeaderDescribe.setVisibility(View.INVISIBLE);
                int corner = DisplayUtil.dip2px(this, 12f);
                GlideUtils.setImageUrlByOption(iv_avatar_cover, bannerUrl, corner, GlideUtils.newCommonRequestOptions(),
                        new RequestListener<Drawable>() {
                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                mDataBinding.layoutHeaderBanner.layoutHeaderDescribe.setVisibility(View.VISIBLE);
                                return false;
                            }

                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                return false;
                            }
                        },
                        R.drawable.img_header_banner_applist, R.drawable.img_header_banner_applist);
            }
        } catch (Exception e) {
            LogUtils.e(e);
        }
    }

    protected void setSystemBarColor(int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(color);
        }
    }

    /**
     * jump to app category more fragment
     */
    public static void switcToCategoryListFragment(Context context, String tabType, String tabID, AppSubCategoryInfo mAppSubCategoryInfo, String lastPage, String value) {
        if (context != null && !TextUtils.isEmpty(tabType) && !TextUtils.isEmpty(tabID) && mAppSubCategoryInfo != null && !TextUtils.isEmpty(mAppSubCategoryInfo.categoryID)) {
            Bundle bundle = new Bundle();
            bundle.putString(CategoryListActivity.KEY_TAB_TYPE, tabType);
            bundle.putString(CategoryListActivity.KEY_TAB_ID, tabID);
            bundle.putSerializable(CategoryListActivity.KEY_SUB_CATEGORY_INFO, mAppSubCategoryInfo);
            bundle.putString(PageConstants.PAGE_KEY_LASTPAGE, lastPage);
            bundle.putString(TRAnalyticsConstant.VALUE, value);

            Intent intent = new Intent(context, CategoryListActivity.class);
            intent.putExtra(CategoryListActivity.class.getSimpleName(), bundle);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }
}

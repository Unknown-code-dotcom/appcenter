package com.afmobi.palmplay.appmanage.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.appmanage.holder.DownloadNoResHolder;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutManageDownloadingListItemNoResBinding;

import java.util.ArrayList;
import java.util.List;

public class DownloadNoResAdapter extends RecyclerView.Adapter {

    private List<FileDownloadInfo> mNoResList = new ArrayList<>();
    private Context mContext;

    private OnItemDeleteListener onItemDeleteListener;

    public DownloadNoResAdapter(Context context, List<FileDownloadInfo> list, OnItemDeleteListener listener) {
        this.mContext = context;
        this.onItemDeleteListener = listener;
        if (list != null) {
            this.mNoResList.clear();
            this.mNoResList.addAll(list);
        }
    }

    public void setData(List<FileDownloadInfo> list) {
        if (list != null) {
            this.mNoResList.clear();
            this.mNoResList.addAll(list);
        }

        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutManageDownloadingListItemNoResBinding binding = DataBindingUtil.inflate(LayoutInflater.from(mContext), R.layout.layout_manage_downloading_list_item_no_res,
                parent, false);
        return new DownloadNoResHolder(binding.getRoot(), onItemDeleteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof DownloadNoResHolder) {
            ((DownloadNoResHolder) holder).bind(getItemById(position), position);
        }
    }

    @Override
    public int getItemCount() {
        return this.mNoResList == null ? 0 : this.mNoResList.size();
    }

    public FileDownloadInfo getItemById(int position) {
        if (position < 0 || position >= getItemCount()) {
            return null;
        }

        return mNoResList.get(position);
    }

    public interface OnItemDeleteListener {
        void onItemDelete(int pos);
    }


}

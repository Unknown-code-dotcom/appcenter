package com.afmobi.palmplay.activate;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkCallBack;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.cache.v6_0.StartUpTabsCache;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.base.BaseResponseModel;
import com.afmobi.palmplay.model.keeptojosn.TipsConfigInfo;
import com.afmobi.palmplay.model.keeptojosn.TipsData;
import com.afmobi.palmplay.model.v6_5.MarketEventInfo;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.TimeUtil;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.Constants;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.callback.TRImageDownloadListener;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.NetworkUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.xwebview.preload.UrlPreLoadProcessor;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/***
 * 应用内四种类型的业务执行者
 */
public class TRTipActivateExecutor extends TRBaseExecutor<TipsData> {
    //之所以用map是因为ConcurrentHashMap是线程安全的，因为活动是一个个动态出来的，会频繁的去list活动列表
    //所以，太频繁，若使用list可能会造成读写不安全，因此把数据结构写成ConcurrentHashMap
    private static  ConcurrentHashMap<String, List<MarketEventInfo>> marketEventInfoList = new ConcurrentHashMap<>();
    private static long durationTime = BuildConfig.DEBUG ? 2 * 60 * 1000 : 8 * 60 * 60 * 1000L;//定时器的间隔时间
    private static volatile long requestTime;//请求时间存放内存
    public static volatile boolean STATUS = false;//代表本身是否正在显示
    public static volatile boolean STATUS_OTHER = false;
    private static final String BANNER = "BANNER";//横幅；
    private static final String PROMPT = "PROMPT"; //弹框；
    private static final String FLOAT = "FLOAT"; //浮动；
    private static final String BUBBLE = "BUBBLE"; //气泡；

    private static final String FROM_BANNER = "popUpbanner";//横幅；
    private static final String FROM_PROMPT = "popUpWidget"; //弹框；
    private static final String FROM_FLOAT = "floatActivate"; //浮动；
    private static final String FROM_BUBBLE = "bubblelump"; //气泡；

    public static final long TIP_REQUEST_INTERVAL = 4 * 60 * 60 * 1000L; //4h
    public static final long TIP_UPDATE_INTERVAL = 24 * 60 * 60 * 1000L; //24h
    private static final long TIP_SHOW_INTERVAL = 5 * 60 * 1000L; //5min
    private static volatile TipsConfigInfo mTipsConfig;
    private static volatile long mLastShowTime;
    private static final String STYLE_ENDING = "_NEW";
    private static final String TIP_CONFIG = "tip_config";
    private static final String PROMPT_COUNT = "prompt_count"; //弹框；
    private static final String BUBBLE_COUNT = "bubble_count"; //弹框；
    private static final String BANNER_COUNT = "bannner_count"; //弹框；
    private static final String FLOAT_COUNT = "float_count"; //弹框；
    private int promptTotalCount; //弹框已展示次数
    private int bubbleTotalCount; //气泡已展示次数
    private int bannerTotalCount; //横幅已展示次数
    private int floatTotalCount;  //悬浮已展示次数
    private static final String TIP_STATUS_MAP = "tip_status_map"; //存储活动展示状态信息
    private Map<String, Map<String, Integer>> mTipStatusMap = new ConcurrentHashMap<>();

    private boolean isPromptAdFromEw;
    private boolean isFloatAdFromEw;
    private MarketEventInfo canShowAdsInfo = null;

    private String mPromptPositionId;
    private String mFloatPositionId;

    private static volatile List<String> mActivateList = new ArrayList<>();
    private static final String []tipsArray = new String[]{
            //顺序： 弹框>气泡>横幅>悬浮
            TRActivateConstant.TIP_SUB_PROMPT,
            TRActivateConstant.TIP_SUB_BUBBLE,
            TRActivateConstant.TIP_SUB_BANNER,
            TRActivateConstant.TIP_SUB_FLOAT
    };

    public TRTipActivateExecutor() {
        //取一次值，后续判断不需要取，直接拿内存的值使用。提高效率
        requestTime = SPManager.getLong(TRActivateConstant.TIP_AD_LOADTIME, 0);
        mLastShowTime = SPManager.getLong(TRActivateConstant.TIP_AD_SHOWTIME, 0);

        initTotalShowCount();

    }

    private void checkAndClearOldAds() {
        if (isPromptAdFromEw) {
            clearOldData(TRActivateConstant.TIP_SUB_PROMPT);
        }
        if (isFloatAdFromEw) {
            clearOldData(TRActivateConstant.TIP_SUB_FLOAT);
        }
    }


    private void initTotalShowCount() {
        if(isDateChanged()) {
            for (String key : tipsArray) {
                resetShowTotalCount(key);
            }
        }else {
            promptTotalCount = getShowCount(TRActivateConstant.TIP_SUB_PROMPT);
            bubbleTotalCount = getShowCount(TRActivateConstant.TIP_SUB_BUBBLE);
            bannerTotalCount = getShowCount(TRActivateConstant.TIP_SUB_BANNER);
            floatTotalCount = getShowCount(TRActivateConstant.TIP_SUB_FLOAT);
        }
    }

    /**
     * 初始化活动状态表
     * */
    private void initTipStatusMap() {

        mTipStatusMap.clear();

        Map<String, Map<String, Integer>> map = null;
        if(SPManager.containsKey(TIP_STATUS_MAP)) {
            String txt = SPManager.getString(TIP_STATUS_MAP, "");
            try {
                Type type = new TypeToken<ConcurrentHashMap<String, ConcurrentHashMap<String, Integer>>>(){}.getType();
                map = new Gson().fromJson(txt, type);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        if (map != null && !map.isEmpty()) {
            mTipStatusMap.putAll(map);
        }else {

            if(isTipEmpty()) {
                return;
            }

            for (String key : tipsArray) {
                List<MarketEventInfo> list = marketEventInfoList.get(key);
                if(list != null && !list.isEmpty()) {
                    Map<String, Integer> tmpMap = new ConcurrentHashMap<>();
                    mTipStatusMap.put(key, tmpMap);

                    Iterator<MarketEventInfo> it = list.iterator();
                    while (it.hasNext()) {
                        MarketEventInfo item = it.next();
                        if(item != null && !TextUtils.isEmpty(item.id)) {
                            tmpMap.put(item.id, 0);
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新活动状态表
     * */
    private void updateTipStatusMap() {

        mTipStatusMap.clear();

        if(!isTipEmpty()) {
            for (String key : tipsArray) {
                List<MarketEventInfo> list = marketEventInfoList.get(key);
                if(list != null && !list.isEmpty()) {
                    Map<String, Integer> tmpMap = new ConcurrentHashMap<>();
                    mTipStatusMap.put(key, tmpMap);

                    Iterator<MarketEventInfo> it = list.iterator();
                    while (it.hasNext()) {
                        MarketEventInfo item = it.next();
                        if(item != null && !TextUtils.isEmpty(item.id)) {
                            tmpMap.put(item.id, 0);
                        }
                    }
                }
            }
        }

        saveTipStatus();
    }

    /**
     * 根据style和id获取对应状态值
     * */
    private int getTipStatusFromMap(String style, String id) {
        if(mTipStatusMap == null || mTipStatusMap.isEmpty()) {
            return 0;
        }

        if(TextUtils.isEmpty(style) || TextUtils.isEmpty(id)) {
            return 0;
        }

        Integer status = 0;
        Map<String, Integer> map = mTipStatusMap.get(style);
        if(map != null && !map.isEmpty()) {
            status = map.get(id);
        }

        return ((status != null) ? (status) : 0);
    }

    /**
     * 展示后更新对应状态值
     * */
    private void updateTipStatus(MarketEventInfo item) {

        if(item == null || TextUtils.isEmpty(item.style) || TextUtils.isEmpty(item.id)) {
            return;
        }

        if(mTipStatusMap == null) {
            mTipStatusMap = new ConcurrentHashMap<>();
        }

        Integer val = 0;
        Map<String, Integer> map = mTipStatusMap.get(item.style);
        if (map != null) {
            val = map.get(item.id);
            if (val == null) {
                val = 0;
            }
        }else {
            map = new ConcurrentHashMap<>();
            mTipStatusMap.put(item.style, map);
        }

        val++;

        map.put(item.id, val);

        saveTipStatus();
    }

    /**
     * 保存活动状态
     * */
    private void saveTipStatus() {
        try {
            if(mTipStatusMap != null) {
                JSONObject js = new JSONObject(mTipStatusMap);
                String txt = js.toString();
                SPManager.putString(TIP_STATUS_MAP, txt);
            }
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }


    @Override
    public void callbackShow(String activateType, String subActivateType) {

    }

    @Override
    public void loadData() {
        if (!TRSharedPreferenceUtils.getGDrpGree()) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_REQ, TRAnalyticsConstant.TIP_ACTIVATE_REQ_GDPR, null);
            return;
        }
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_REQ, TRAnalyticsConstant.TIP_ACTIVATE_REQ_NO_NET, null);
            return;
        }

        if (!isRequestTimeExpired()) {
            LogUtils.d(LogUtils.TAG_TIPS_REQUEST,"loadData interval no ok");
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_REQ, TRAnalyticsConstant.TIP_ACTIVATE_REQ_INTERVAL, null);
            return;//间隔时间不满足
        }

        PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_REQ, TRAnalyticsConstant.TIP_ACTIVATE_REQ_NORMAL, null);


        isPromptAdFromEw = isPromptAdFromEw();
        isFloatAdFromEw = isFloatAdFromEw();

        preloadEwAds(isPromptAdFromEw,isFloatAdFromEw);

        HashMap<String,Boolean> supportSceneMap = new HashMap<>(2);
        supportSceneMap.put(SceneCode.INSERT_SCREEN_X, isPromptAdFromEw);
        supportSceneMap.put(SceneCode.FLOAT_X, isFloatAdFromEw);

        try {
            LogUtils.d(LogUtils.TAG_TIPS_REQUEST,"loadData ...");
            NetworkClient.pullTipData(supportSceneMap, new AbsRequestListener<BaseResponseModel<TipsData>>() {
                @Override
                public void onResponse(BaseResponseModel<TipsData> response) {
                    requestTime = System.currentTimeMillis();
                    SPManager.putLong(TRActivateConstant.TIP_AD_LOADTIME, System.currentTimeMillis());
                    LogUtils.d(LogUtils.TAG_TIPS_REQUEST,"loadData ==> response = " + response);
                    if (response == null || response.code != NetworkClient.STATUS_CODE_SUCCESS) {
                        PalmplayApplication.getAppInstance()
                        .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_RES, TRAnalyticsConstant.TIP_ACTIVATE_RES_NO_TIP, null);
                        String txt = (response == null) ? ("response is null") : ("response code:" + response.code + ",msg:" + response.message);
                        LogUtils.i(LogUtils.TAG_TIPS_REQUEST ,txt);
                        return;
                    }
                    parseData(response.data);

                }

                @Override
                public void onError(ANError anError) {
                    LogUtils.d(LogUtils.TAG_TIPS_REQUEST,"loadData ==> anError " + anError);

                    PalmplayApplication.getAppInstance()
                        .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_RES, TRAnalyticsConstant.TIP_ACTIVATE_RES_FAIL, null);
                    requestTime = System.currentTimeMillis();
                    SPManager.putLong(TRActivateConstant.TIP_AD_LOADTIME, System.currentTimeMillis());
                }
            }, TRTipActivateExecutor.class.toString());
        } catch (Error e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private boolean isPromptAdFromEw(){
        if(TextUtils.isEmpty(mPromptPositionId)){
            mPromptPositionId = getAdPositionId(SceneCode.INSERT_SCREEN_X);
        }
        return !TextUtils.isEmpty(mPromptPositionId);
    }
    public String getPositionId(String style){
        if (TRActivateConstant.TIP_SUB_PROMPT.equals(style)) {
            isPromptAdFromEw();
            return mPromptPositionId;
        } else if (TRActivateConstant.TIP_SUB_FLOAT.equals(style)) {
            isFloatAdFromEw();
            return mFloatPositionId;
        }
        return "no_match";
    }

    private boolean isFloatAdFromEw(){
        if (TextUtils.isEmpty(mFloatPositionId)) {
            mFloatPositionId = getAdPositionId(SceneCode.FLOAT_X);
        }
        return !TextUtils.isEmpty(mFloatPositionId);
    }

    /**
     * 预加载广告数据
     * @param isSupportPrompt
     * @param isSupportFloat
     */
    private void preloadEwAds(boolean isSupportPrompt,boolean isSupportFloat) {
        if (isSupportPrompt) {
            preloadAdsFromEw(SceneCode.INSERT_SCREEN_X);
            LogUtils.d(LogUtils.TAG_TIPS_EW,"preloadEwAds PROMPT");
        }

        if(isSupportFloat) {
            preloadAdsFromEw(SceneCode.FLOAT_X);
            LogUtils.d(LogUtils.TAG_TIPS_EW,"preloadEwAds FLOAT");
        }
    }

    private String getAdPositionId(String sceneKey) {
        return HisavanaSdkManager.getInstance().getEwScenePositionID(sceneKey);
    }

    public void preloadAdsFromEw(String sceneCode) {
        String serialNum = CommonUtils.generateSerialNum();

        HisavanaSdkManager.getInstance().sdkLoad(sceneCode,"",serialNum,0,0, new HisavanaSdkCallBack() {
            @Override
            public void onError(TaErrorCode adError) {
                if (adError != null) {
                    LogUtils.d(LogUtils.TAG_TIPS_EW, "preloadAdsFromEw  onError: code: " + adError.getErrorCode() + ",msg:" + adError.getErrorMessage());
                }
            }

            @Override
            public void onAdLoaded(List<TaNativeInfo> adInfo) {
                LogUtils.d(LogUtils.TAG_TIPS_EW, "onAdLoaded: sceneCode："+ sceneCode);
            }

            @Override
            public void onAdClicked() {

            }

            @Override
            public void onTimeOut() {

            }

            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {

            }
        });
    }

    @Override
    public void parseData(TipsData data) {

        TipsConfigInfo tipsConfigInfo = null;
        ConcurrentHashMap<String, List<MarketEventInfo>> map = new ConcurrentHashMap<>();
        String model = "";

        if(data != null) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_RES, TRAnalyticsConstant.TIP_ACTIVATE_RES_TIP, null);
            tipsConfigInfo = data.getTipsConfig();

            if (tipsConfigInfo != null) {
                SPManager.putLong(TRActivateConstant.TIP_AD_CFG_LOAD_TIME_INTERVAL,tipsConfigInfo.getLoadTimeInterval());
                SPManager.putLong(TRActivateConstant.TIP_AD_CFG_RELOAD_TIME_INTERVAL,tipsConfigInfo.getReloadTimeInterval());
            }

            if (isPromptAdFromEw) {
                if (marketEventInfoList != null) {
                    List<MarketEventInfo> marketEventInfos = marketEventInfoList.get(PROMPT);
                    if (marketEventInfos != null) {
                        map.put(PROMPT, marketEventInfos);
                    }
                }
            } else {
                if(data.getPromptItemList() != null) {
                    map.put(PROMPT, data.getPromptItemList());
                }
            }

            if (isFloatAdFromEw) {
                if (marketEventInfoList != null) {
                    List<MarketEventInfo> marketEventInfos = marketEventInfoList.get(FLOAT);
                    if (marketEventInfos != null) {
                        map.put(FLOAT, marketEventInfos);
                    }
                }
            } else {
                if(data.getFloatItemList() != null) {
                    map.put(FLOAT, data.getFloatItemList());
                }
            }

            if(data.getBannerItemList() != null) {
                map.put(BANNER, data.getBannerItemList());
            }

            if(data.getBubbleItemList() != null) {
                //BubbleItemList
                map.put(BUBBLE, data.getBubbleItemList());
                LogUtils.d(LogUtils.TAG_TIPS_REQUEST, data.getBubbleItemList().toString());
            }
        } else {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_RES, TRAnalyticsConstant.TIP_ACTIVATE_RES_NO_TIP, null);
        }

        for (Map.Entry<String, List<MarketEventInfo>> entry : map.entrySet()) {
            List<MarketEventInfo> infos = entry.getValue();
            handlePreload(infos);
            if (infos != null && infos.size() > 0) { //把解析的list转成map
                Iterator<MarketEventInfo> iterator = infos.iterator();
                while (iterator.hasNext()) {
                    MarketEventInfo info = iterator.next();
                    if(info == null || TRStringUtil.isBlank(info.style)
                            || TRStringUtil.isBlank(info.jumpType)
                            /*|| info.jumpType.equalsIgnoreCase(TRActivateConstant.GAME_HALL)*/) {
                        //线上版本支持游戏大厅跳转功能，不再过滤
                        iterator.remove();
                        continue;
                    }

                    if(BUBBLE.equals(info.style)) {
                        info.fromPage = FROM_BUBBLE;
                        model = TRAnalyticsConstant.AD_BUBBLE;
                    } else if(FLOAT.equals(info.style)) {
                        info.fromPage = FROM_FLOAT;
                        model = TRAnalyticsConstant.AD_SW;
                    } else if(BANNER.equals(info.style)) {
                        info.fromPage = FROM_BANNER;
                        model = TRAnalyticsConstant.AD_BANNER;
                    } else if(PROMPT.equals(info.style)) {
                        info.fromPage = FROM_PROMPT;
                        model = TRAnalyticsConstant.AD_PP;
                    }
                    info.value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, model, "", "");
                    //图片预下载
                    preDownloadImage(info);
                }
            }
        }


        //TODO:update tip datas
        mTipsConfig = tipsConfigInfo;
        updateTipConfigInfo();

        //数据覆盖
        if (marketEventInfoList != null) {
            marketEventInfoList.clear();
        }
        marketEventInfoList.putAll(map);

        if (marketEventInfoList.isEmpty()) {
            SPManager.putBoolean(TRActivateConstant.TIP_ADS_IS_EMPTY,true);
        } else {
            SPManager.putBoolean(TRActivateConstant.TIP_ADS_IS_EMPTY,false);
        }

        initActivateList();

        if(isDateChanged()) {
            for (String type : tipsArray) {
                resetShowTotalCount(type);
            }
        }

        updateTipStatusMap();

        //数据持久化
        for (String key : tipsArray) {
            List<MarketEventInfo> list = marketEventInfoList.get(key);
            put(key, list);
        }

        DetailCacheManager.getInstance().addItemByObject(data);
    }

    //预加载逻辑
    private void handlePreload(final List<MarketEventInfo> infos) {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new Runnable() {
            @Override
            public void run() {
                if (infos != null && infos.size() > 0) {
                    for (MarketEventInfo info : infos) {
                        savePreLoadDataWithActivateType(info);
                    }
                    UrlPreLoadProcessor.handlePreLoadLogic(ConfigManager.isPreLoadOn());
                }
            }
        });
    }

    private void savePreLoadDataWithActivateType(MarketEventInfo info) {
        if (info != null) {
            boolean isPreLoadOn = ConfigManager.isPreLoadOn();
            boolean isInWhiteList = StartUpTabsCache.getInstance().inInUrlWhiteList(info.jumpUrl);

            switch (info.style) {
                case BANNER:
                    UrlPreLoadProcessor.checkPreloadConditionAndSaveData(BANNER, info.jumpType, info.jumpUrl, isPreLoadOn, isInWhiteList);
                    break;
                case PROMPT:
                    UrlPreLoadProcessor.checkPreloadConditionAndSaveData(PROMPT, info.jumpType, info.jumpUrl, isPreLoadOn, isInWhiteList);
                    break;
                case BUBBLE:
                    UrlPreLoadProcessor.checkPreloadConditionAndSaveData(BUBBLE, info.jumpType, info.jumpUrl, isPreLoadOn, isInWhiteList);
                    break;
                case FLOAT:
                    UrlPreLoadProcessor.checkPreloadConditionAndSaveData(FLOAT, info.jumpType, info.jumpUrl, isPreLoadOn, isInWhiteList);
                    break;
            }
        }
    }

    public void clearNeedShowData() {
        canShowAdsInfo = null;
    }

    /***
     * 获取符合条件的单个子活动
     * @return
     */
    @Override
    public MarketEventInfo getActivateData() {

        if (isDateChanged()) {
            for (String style : tipsArray) {
                resetShowTotalCount(style);
            }
        }

        updateEwPositionInfo();

        getData();

        if (isPromptAdFromEw) {
            if (isHaveCache(mPromptPositionId,SceneCode.INSERT_SCREEN_X)) {
                createAdsFromEw(TRActivateConstant.TIP_SUB_PROMPT);
            } else {
                clearOldEwData(TRActivateConstant.TIP_SUB_PROMPT);
            }
        }

        if (isFloatAdFromEw) {
            if (isHaveCache(mFloatPositionId,SceneCode.FLOAT_X)) {
                createAdsFromEw(TRActivateConstant.TIP_SUB_FLOAT);
            } else {
                clearOldEwData(TRActivateConstant.TIP_SUB_FLOAT);
            }
        }

        if (marketEventInfoList == null || marketEventInfoList.isEmpty()) {
            return null;
        }

        return getLargestMarketEventInfo();
    }


    private void clearOldEwData(String style) {
        if (marketEventInfoList != null) {
            List<MarketEventInfo> marketEventInfos = marketEventInfoList.get(style);
            if (marketEventInfos != null) {
                marketEventInfos.clear();
            }
        }
    }

    private void createAdsFromEw(String style){
        if (marketEventInfoList == null) {
            marketEventInfoList = new ConcurrentHashMap<>();
        }
        List<MarketEventInfo> marketEventInfos = marketEventInfoList.get(style);
        if (marketEventInfos == null) {
            marketEventInfos = new ArrayList<>();
        }
        // 插屏和悬浮只需构造一个数据
        if (marketEventInfos.size() == 1) {
            MarketEventInfo marketEventInfo = marketEventInfos.get(0);
            if (marketEventInfo != null &&  marketEventInfo.isFromEw) {
                marketEventInfo.taNativeInfo = null;
                return;
            } else {
                marketEventInfos.clear();
            }
        } else {
            marketEventInfos.clear();
        }

        marketEventInfos.add(buildEwData(style));
        marketEventInfoList.put(style,marketEventInfos);
    }

    private boolean isHaveCache(String positionId,String scene){
        boolean hasCache;
        if(TextUtils.isEmpty(positionId)){
            return false;
        }
        long l = System.currentTimeMillis();
        TFeedNative feedNative = new TFeedNative(positionId);
        hasCache = feedNative.isHaveCache(Constants.ASKSCENE.ENTER_SCENE_ASK);
        if(hasCache) {
            TRAnalysticsUtil.trackEWSDKResponse(positionId, scene, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_HAS_CACHE, null);
        } else {
            TRAnalysticsUtil.trackEWSDKResponse(positionId, scene, HisavanaSdkManager.TRACK_LOAD_CACHE_ADS_NO_CACHE, null);
        }
        LogUtils.d(LogUtils.TAG_TIPS_EW, "isHaveCache: ew hasCache : positionId " + positionId + hasCache + (System.currentTimeMillis() - l));
        return hasCache;
    }

    private void updateEwPositionInfo() {
        if (!isPromptAdFromEw) {
            isPromptAdFromEw = isPromptAdFromEw();
        }
        if (!isFloatAdFromEw) {
            isFloatAdFromEw = isFloatAdFromEw();
        }
    }


    private MarketEventInfo buildEwData(String style) {
        MarketEventInfo marketEventInfo = new MarketEventInfo();
        marketEventInfo.style = style;
        marketEventInfo.isFromEw = true;
        marketEventInfo.manualClose = "T";
        marketEventInfo.position = MarketEventInfo.Position.HOME;
        return marketEventInfo;
    }

    /***
     * 根据子活动类型获取单个子活动
     * @param subActivateType
     * @return
     */
    @Override
    public MarketEventInfo getSubActivateData(String subActivateType) {

        return null;
    }


    @Override
    public ConcurrentHashMap<String, List<MarketEventInfo>> getData() {
        //先从内存取，如果内存没有，从磁盘取
        if (marketEventInfoList != null && marketEventInfoList.size() <= 0) {

            File bubbleFile = ACache.get(PalmplayApplication.getAppInstance()).file(TRActivateConstant.TIP_SUB_BUBBLE);
            if(bubbleFile != null) {
                bubbleFile.delete();
            }

            File promoteFile = ACache.get(PalmplayApplication.getAppInstance()).file(TRActivateConstant.TIP_SUB_PROMPT);
            if(promoteFile != null) {
                promoteFile.delete();
            }

            File bannerFile = ACache.get(PalmplayApplication.getAppInstance()).file(TRActivateConstant.TIP_SUB_BANNER);
            if(bannerFile != null) {
                bannerFile.delete();
            }

            File floatFile = ACache.get(PalmplayApplication.getAppInstance()).file(TRActivateConstant.TIP_SUB_FLOAT);
            if(floatFile != null) {
                floatFile.delete();
            }

            //TODO:get new info and join it
            //顺序： 弹框>气泡>横幅>悬浮
            loadAndJoinOldActivate(TRActivateConstant.TIP_SUB_PROMPT);
            loadAndJoinOldActivate(TRActivateConstant.TIP_SUB_BUBBLE);
            loadAndJoinOldActivate(TRActivateConstant.TIP_SUB_BANNER);
            loadAndJoinOldActivate(TRActivateConstant.TIP_SUB_FLOAT);

            //load tip config info
            initTipConfigInfo();

            initActivateList();

            initTipStatusMap();
        }
        return marketEventInfoList;
    }

    /**
     * 按顺序初始化各活动队列
     * */
    private void initActivateList() {

        mActivateList.clear();

        if(isTipEmpty()) {
            return;
        }

        for (int i = 0;i < tipsArray.length; i++) {
            String key = tipsArray[i];
            if(marketEventInfoList.containsKey(key)) {
                mActivateList.add(key);
            }
        }
    }

    private void loadAndJoinOldActivate(String style) {
        if(TextUtils.isEmpty(style)) {
            return;
        }
        if (TRActivateConstant.TIP_SUB_PROMPT.equals(style) && isPromptAdFromEw) {
            return;
        }
        if (TRActivateConstant.TIP_SUB_FLOAT.equals(style) && isFloatAdFromEw) {
            return;
        }
        List<MarketEventInfo> list = getAsList(style);

        if(list != null && !list.isEmpty()) {
            marketEventInfoList.put(style, list);
        }
    }




    public void preDownloadImage(final MarketEventInfo info) {
        if (info == null) {
            return;
        }

        String imageUrl = info.imgUrl;
        if (TRStringUtil.isBlank(imageUrl)) {
            return;
        }
        boolean isCached = TRBitmapManager.isImageCachedWithSmallCache(imageUrl);
        if (isCached) { //已经存在的话，不下载
            if (TRActivateConstant.TIP_SUB_BUBBLE.equals(info.style)) {
                // 气泡图片已在 small cache，跳过预下载（记录用于排查哪些 item 因此路径正常缓存）
                PalmplayApplication.getAppInstance()
                        .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE,
                                TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_BUBBLE_IMG_ALREADY_CACHED, info);
            }
            return;
        }
        TRBitmapManager.preLoadImageWithSmallCache(imageUrl, null, new TRImageDownloadListener() {
            @Override
            public void onSuccess(File file) {
                LogUtils.i(LogUtils.TAG_TIPS_CACHE, "Tip Activate image preload finish,id:" + info.id + ",style:" + info.style);
            }
            @Override
            public void onError(Object dataSource) {

            }
        });
    }

    @Override
    public boolean isCanShow(String fromType) {
        if(CommonUtils.isBlockAllPopUps()){
            LogUtils.d(LogUtils.TAG_TIPS,"应用助手拦截 ");
            return false;
        }
        if (TRTipActivateExecutor.STATUS || TRTipActivateExecutor.STATUS_OTHER) {
            return false;
        }

        MarketEventInfo item = getActivateData();
        if (item != null) {
            //保存待展示数据到内存，避免show() 再次获取
            canShowAdsInfo = item;
        } else {
            canShowAdsInfo = null;
        }

        LogUtils.d(LogUtils.TAG_TIPS, "isCanShow: getActivateData " + (canShowAdsInfo!= null ?canShowAdsInfo.isFromEw : null));

        if (canShowAdsInfo!=null && canShowAdsInfo.taNativeInfo!=null) {
            LogUtils.d(LogUtils.TAG_TIPS, "isCanShow: getActivateData getNativeAdId " + canShowAdsInfo.taNativeInfo.getNativeAdId());
        }
        return (item != null);
    }

    @Override
    public boolean show(String fromType) {
        PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE, TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_TRIGGER, canShowAdsInfo);

        if (TRDialogUtil.hasDialogShowing()) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE, TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_OTHER_IS_SHOWING, canShowAdsInfo);
            return false;
        }

        if (!isShowTimeExpired()) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE, TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_INTERVAL, canShowAdsInfo);
            return false;
        }

        if (isPromptTipWithSpaceLimit(canShowAdsInfo)) {
            LogUtils.d(LogUtils.TAG_TIPS,"Tip activity of PROMPT dialog will not show,because disk space limit activity is showing");
            return false;
        }
        LogUtils.d(LogUtils.TAG_TIPS, "show: trigger");
        CommonUtils.postAtivateEvent(TRActivateConstant.TIP_ACTIVATE, "", canShowAdsInfo);
        return true;
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }

    @Override
    public boolean showOthers() {

        if (!isShowTimeExpired()) {
            return false;
        }

        if (isDateChanged()) {
            for (String style : tipsArray) {
                resetShowTotalCount(style);
            }
        }

        MarketEventInfo item = getLargestMarketEventInfoForOthers();
        if (item == null) {
            return false;
        }

        if (isPromptTipWithSpaceLimit(item)) {
            LogUtils.d(LogUtils.TAG_TIPS,"Tip activity of PROMPT dialog will not show,because disk space limit activity is showing");
            return false;
        }

        if (!TRActivateConstant.TIP_SUB_FLOAT.equals(item.style) || !isFloatAdFromEw) {
            boolean isCached = TRBitmapManager.isImageCachedWithSmallCache(item.imgUrl);
            if (!isCached) {
                return false;
            }

        }

        CommonUtils.postAtivateEvent(TRActivateConstant.TIP_ACTIVATE, "", item);

        return true;
    }

    @Override
    public boolean isPromptTip() {

        if (TRTipActivateExecutor.STATUS || TRTipActivateExecutor.STATUS_OTHER) {
            return false;
        }
        LogUtils.d(LogUtils.TAG_TIPS, "isPromptTip: getActivateData ");

        MarketEventInfo item = getActivateData();
        if(item != null && TextUtils.equals(item.style, TRActivateConstant.TIP_SUB_PROMPT)) {
            return true;
        }
        return false;
    }

    private boolean isPromptTipWithSpaceLimit(MarketEventInfo item) {
        if(item != null && TextUtils.equals(item.style, TRActivateConstant.TIP_SUB_PROMPT)) {
            return TRDiskSpaceLimitExecutor.STATUS;
        }
        return false;
    }


    private boolean isTipEmpty() {
        if(marketEventInfoList == null || marketEventInfoList.isEmpty()) {
            return true;
        }

        for(List<MarketEventInfo> item : marketEventInfoList.values()) {
            if(item != null && item.size() > 0) {
                return false;
            }
        }

        return true;
    }

    /**
     * 请求时间是否超时？（区分有无物料情况，以服务器为准。无物料时默认4h，有物料默认24h）
     * */
    private boolean isRequestTimeExpired() {

        long currTime = System.currentTimeMillis();
        long lastReqTime = requestTime;
        long reqInterval = 0;
        if (isTipEmpty()) {//无物料
           // LogUtils.d(LogUtils.TAG_TIPS_REQUEST," mTipsConfig == null ");
            if(mTipsConfig != null) {
                reqInterval = mTipsConfig.getLoadTimeInterval();
            }

            if(reqInterval <= 0) {
                reqInterval = TIP_REQUEST_INTERVAL;
            }
        }else {
          //  LogUtils.d(LogUtils.TAG_TIPS_REQUEST," mTipsConfig != null ");
            if(mTipsConfig != null) {
               reqInterval = mTipsConfig.getReloadTimeInterval();
            }

            if(reqInterval <= 0) {
                reqInterval = TIP_UPDATE_INTERVAL;
            }
        }

        if(Math.abs(currTime - lastReqTime) >= reqInterval) {
            return true;
        }

        return false;
    }

    /**
     * 展示时间是否超时
     * */
    public boolean isShowTimeExpired() {
        long currShowTime = System.currentTimeMillis();
        long lastShowTime = mLastShowTime;
        long showInterval = 0;
       // float showInterval = 0f;
        if(mTipsConfig != null) {
            showInterval = mTipsConfig.getShowTimeInterval();
          //  showInterval = 0.03f;
        }
        if(showInterval <= 0) {
            showInterval = TIP_SHOW_INTERVAL;
        }

        if(Math.abs(currShowTime - lastShowTime) >= showInterval) {
            return true;
        }

        return false;
    }


    /**
     * 日期是否改变？
     * */
    public boolean isDateChanged() {
        long lastInterval = mLastShowTime;
        long currInterval = System.currentTimeMillis();

        String lastYMD = TimeUtil.getDateToStringYMD(lastInterval);
        String currYMD = TimeUtil.getDateToStringYMD(currInterval);

        return (!TextUtils.equals(lastYMD, currYMD));
    }


    /**
     * 根据传入的Tip信息判断是否有效
     * */
    public boolean isActivateValidate(MarketEventInfo item) {
        try {

            if(item != null) {
                long startTime = 0;
                long endTime = 0;
                long currTime = System.currentTimeMillis();
                //时间转成时间戳
                if(!TextUtils.isEmpty(item.beginDate)) {
                    startTime = TimeUtil.getMillisByDate(item.beginDate);
                }
                if(!TextUtils.isEmpty(item.endDate)) {
                    endTime = TimeUtil.getMillisByDate(item.endDate);
                }

                if((currTime >= startTime) && (currTime <= endTime)) {
                    return true;
                }
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return false;
    }

    /**
     * 当天展示次数重置
     * */
    public void resetShowTotalCount(String style) {
        if(TextUtils.isEmpty(style)) {
            return;
        }

        switch (style) {
            case TRActivateConstant.TIP_SUB_PROMPT:
                promptTotalCount = 0;
                SPManager.putInt(PROMPT_COUNT, promptTotalCount);
                break;
            case TRActivateConstant.TIP_SUB_BUBBLE:
                bubbleTotalCount = 0;
                SPManager.putInt(BUBBLE_COUNT, bubbleTotalCount);
                break;
            case TRActivateConstant.TIP_SUB_BANNER:
                bannerTotalCount = 0;
                SPManager.putInt(BANNER_COUNT, bannerTotalCount);
                break;
            case TRActivateConstant.TIP_SUB_FLOAT:
                floatTotalCount = 0;
                SPManager.putInt(FLOAT_COUNT, floatTotalCount);
                break;
            default:
                break;
        }
    }

    /**
     * 当天展示次数是否达到上限
     * */
    public boolean isUpperLimit(String style) {
        if(TextUtils.isEmpty(style) || mTipsConfig == null) {
            LogUtils.d(LogUtils.TAG_TIPS, "isUpperLimit: style empty or config is null");
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE, TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_CONFIG_NULL, canShowAdsInfo);
            return true;
        }
        boolean isUpperLimit = true;
        switch (style) {
            case TRActivateConstant.TIP_SUB_PROMPT:
                isUpperLimit = promptTotalCount >= mTipsConfig.getPromptFrequency();
                break;
            case TRActivateConstant.TIP_SUB_BUBBLE:
                isUpperLimit = bubbleTotalCount >= mTipsConfig.getBubbleFrequency();
                break;
            case TRActivateConstant.TIP_SUB_BANNER:
                isUpperLimit = bannerTotalCount >= mTipsConfig.getBannerFrequency();
                break;
            case TRActivateConstant.TIP_SUB_FLOAT:
                isUpperLimit = floatTotalCount >= mTipsConfig.getFloatFrequency();
                break;
            default:
                break;
        }
        if (isUpperLimit) {
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE, TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_OVER_UPPER_LIMIT, canShowAdsInfo);
        }
        return isUpperLimit;
    }

    /**
     * 当天展示次数+1
     * */
    public void increaseShowCount(String style) {
        if(TextUtils.isEmpty(style)) {
            return;
        }

        switch (style) {
            case TRActivateConstant.TIP_SUB_PROMPT:
                promptTotalCount++;
                SPManager.putInt(PROMPT_COUNT, promptTotalCount);
                break;
            case TRActivateConstant.TIP_SUB_BUBBLE:
                bubbleTotalCount++;
                SPManager.putInt(BUBBLE_COUNT, bubbleTotalCount);
                break;
            case TRActivateConstant.TIP_SUB_BANNER:
                bannerTotalCount++;
                SPManager.putInt(BANNER_COUNT, bannerTotalCount);
                break;
            case TRActivateConstant.TIP_SUB_FLOAT:
                floatTotalCount++;
                SPManager.putInt(FLOAT_COUNT, floatTotalCount);
                break;
            default:
                break;
        }
    }

    /**
     * 当天展示次数+1
     * */
    public int getShowCount(String style) {
        int count = 0;
        if(TextUtils.isEmpty(style)) {
            return count;
        }

        switch (style) {
            case TRActivateConstant.TIP_SUB_PROMPT:
                count = promptTotalCount = SPManager.getInt(PROMPT_COUNT, 0);
                break;
            case TRActivateConstant.TIP_SUB_BUBBLE:
                count = bubbleTotalCount = SPManager.getInt(BUBBLE_COUNT, 0);
                break;
            case TRActivateConstant.TIP_SUB_BANNER:
                count = bannerTotalCount = SPManager.getInt(BANNER_COUNT, 0);
                break;
            case TRActivateConstant.TIP_SUB_FLOAT:
                count = floatTotalCount = SPManager.getInt(FLOAT_COUNT, 0);
                break;
            default:
                break;
        }

        return count;
    }


    /**
     * 根据传入风格类型获取对应的展示频次
     * */
    public int getShowFrequency(String style) {
        if(mTipsConfig == null || TextUtils.isEmpty(style)) {
            return 0;
        }

        int frequency = 0;
        switch (style) {
            case TRActivateConstant.TIP_SUB_PROMPT:
                frequency = mTipsConfig.getPromptFrequency();
                break;
            case TRActivateConstant.TIP_SUB_BUBBLE:
                frequency = mTipsConfig.getBubbleFrequency();
                break;
            case TRActivateConstant.TIP_SUB_BANNER:
                frequency = mTipsConfig.getBannerFrequency();
                break;
            case TRActivateConstant.TIP_SUB_FLOAT:
                frequency = mTipsConfig.getFloatFrequency();
                break;
            default:
                break;
        }

        return frequency;
    }



    /**
     * 根据传入风格,ID获取对应的Tip信息对象
     * */
    public MarketEventInfo getTipActivateData(String style, String id) {
        if(isTipEmpty()) {
            return null;
        }

        List<MarketEventInfo> list = marketEventInfoList.get(style);
        if(list == null || list.size() <= 0) {
            return null;
        }

        Iterator<MarketEventInfo> iterator = list.iterator();
        while (iterator.hasNext()) {
            MarketEventInfo item = iterator.next();
            if(TextUtils.equals(item.id, id)) {
                return item;
            }
        }

        return null;
    }

    /**
     * 根据传入风格获取对应的权重最大的有效的Tip信息对象
     * */
    public MarketEventInfo getLargestWeightTipActivateData(String style) {
        if(marketEventInfoList == null || marketEventInfoList.isEmpty()) {
            return null;
        }

        List<MarketEventInfo> list = marketEventInfoList.get(style);
        if(list == null || list.isEmpty()) {
            return null;
        }

        if(isUpperLimit(style)) {
            return null;
        }

        int len = list.size();
        if(len <= 0) {
            return null;
        }

        int smallestStatus = -1;
        int largestWeight = -1;
        MarketEventInfo findItem = null;
        boolean isBubble = TextUtils.equals(style, TRActivateConstant.TIP_SUB_BUBBLE);
        StringBuilder candidatesBuilder = isBubble ? new StringBuilder() : null;

        Iterator<MarketEventInfo> iterator = list.iterator();
        while (iterator.hasNext()) {
            MarketEventInfo item = iterator.next();

            if (item != null) {
                if (TextUtils.equals(style, TRActivateConstant.TIP_SUB_PROMPT) && isPromptAdFromEw && !item.isFromEw) {
                    continue;
                }
                if (TextUtils.equals(style, TRActivateConstant.TIP_SUB_FLOAT) && isFloatAdFromEw && !item.isFromEw) {
                    continue;
                }
                if (TextUtils.equals(style, TRActivateConstant.TIP_SUB_PROMPT)) {
                    if (item.isNoNeedShow) {
                        continue;
                    }else if (System.currentTimeMillis() - item.getLatestShowTime() < item.showintervalTime * com.afmobi.util.Constants.TIME_HOUR_UNIT) {
                        continue;
                    }
                }
                if (item.isFromEw) {
                    findItem = item;
                    LogUtils.d(LogUtils.TAG_TIPS_EW, "getLargestWeightTipActivateData: from ew " + item);
                    break;
                }

                if (isActivateValidate(item) && !TextUtils.isEmpty(item.imgUrl)) {
                    if (TRBitmapManager.isImageCachedWithSmallCache(item.imgUrl)) {
                        if (isBubble) { //气泡类型，取权重weight最大的
                            // 收集有效候选快照
                            if (candidatesBuilder.length() > 0) candidatesBuilder.append(',');
                            candidatesBuilder.append(item.id).append(':').append(item.weight);
                            if (largestWeight == -1 || item.weight > largestWeight) {
                                largestWeight = item.weight;
                                findItem = item;
                            }
                        } else {
                            int val = getTipStatusFromMap(style, item.id);
                            if (smallestStatus == -1 || val < smallestStatus) { //其他类型 取展示次数少的先展示
                                smallestStatus = val;
                                findItem = item;
                            }
                        }
                    } else if (isBubble) {
                        // 气泡：通过时间校验但图片未在 small cache，被跳过（排查权重展示异常的关键路径）
                        PalmplayApplication.getAppInstance()
                                .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE,
                                        TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_BUBBLE_IMG_NOT_CACHED, item);
                    }
                } else if (isBubble) {
                    // 气泡：时间范围校验不通过
                    PalmplayApplication.getAppInstance()
                            .getAppDataManager().trackHomeTipActivate(TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE,
                                    TRAnalyticsConstant.TIP_ACTIVATE_EXPOSE_BUBBLE_VALIDATE_FAIL, item);
                }

            }

        }

        if (isBubble && findItem != null) {
            // 气泡最终选中，上报 weight + 全量有效候选快照，供线上权重分布分析
            PalmplayApplication.getAppInstance()
                    .getAppDataManager().trackBubbleSelected(findItem,
                            candidatesBuilder != null ? candidatesBuilder.toString() : "");
        }

        return findItem;
    }

    /**
     * 保存 对象列表的数据 到 缓存中
     *
     * @param key
     *            保存的key
     * @param value
     *            保存的列表数据
     */
    public void put(String key, List<MarketEventInfo> value) {
        try {
            String newKey = key + STYLE_ENDING;
            if ((TRActivateConstant.TIP_SUB_PROMPT.equals(key) && isPromptAdFromEw) ||
                    (TRActivateConstant.TIP_SUB_FLOAT.equals(key) && isFloatAdFromEw)) {
                ACache.get(PalmplayApplication.getAppInstance()).remove(newKey);
                LogUtils.d(LogUtils.TAG_TIPS, "Tips old ads removed; get from ew");
                return;
            }

            if(value != null && !value.isEmpty()) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<MarketEventInfo>>(){}.getType();
                String txt = gson.toJson(value, type);
                ACache.get(PalmplayApplication.getAppInstance()).put(newKey, txt);

                LogUtils.i(LogUtils.TAG_TIPS, "Tips activate [" + key + "] info:" + txt);
            }else {
                //没有配置活动
                ACache.get(PalmplayApplication.getAppInstance()).remove(newKey);
            }
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }


    private void clearPromptAndFloatAds() {
        clearOldData(TRActivateConstant.TIP_SUB_PROMPT);
        clearOldData(TRActivateConstant.TIP_SUB_FLOAT);
    }

    /**
     * clear old ads
     * @param key
     */
    private void clearOldData(String key) {
        try {
            String newKey = key + STYLE_ENDING;
            ACache.get(PalmplayApplication.getAppInstance()).remove(newKey);
        } catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    /**
     * 读取 String数据转成对象列表
     *
     * @param key
     * @return 对象列表 数据
     */
    public List<MarketEventInfo> getAsList(String key) {
        List<MarketEventInfo> list = null;
        String newKey = key + STYLE_ENDING;
        File f = ACache.get(PalmplayApplication.getAppInstance()).file(newKey);
        if(f == null) {
            return list;
        }

        String txt = ACache.get(PalmplayApplication.getAppInstance()).getAsString(newKey);
        if(!TextUtils.isEmpty(txt)) {
            try {
                Gson gson = new Gson();
                Type type = new TypeToken<List<MarketEventInfo>>() {}.getType();
                list = gson.fromJson(txt, type);
            }catch(Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        if(list != null && list.size() > 0) {
            for (MarketEventInfo item : list) {
                if(TextUtils.equals(item.style, TRActivateConstant.TIP_SUB_BUBBLE)) {
                    item.fromPage = FROM_BUBBLE;
                    item.value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.AD_BUBBLE, "", "");
                }else if(TextUtils.equals(item.style, TRActivateConstant.TIP_SUB_PROMPT)) {
                    item.fromPage = FROM_PROMPT;
                    item.value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.AD_PP, "", "");
                }else if(TextUtils.equals(item.style, TRActivateConstant.TIP_SUB_BANNER)) {
                    item.fromPage = FROM_BANNER;
                    item.value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.AD_BANNER, "", "");
                }else if(TextUtils.equals(item.style, TRActivateConstant.TIP_SUB_FLOAT)) {
                    item.fromPage = FROM_FLOAT;
                    item.value = TRStringUtil.generateString(TRAnalyticsConstant.HOME_A, TRAnalyticsConstant.AD_SW, "", "");
                }
            }
        }

        return list;
    }


    /**
     * 更新活动配置信息
     * */
    public void updateTipConfigInfo() {
        if(mTipsConfig == null) {
            ACache.get(PalmplayApplication.getAppInstance()).remove(TIP_CONFIG);
            return;
        }

        ACache.get(PalmplayApplication.getAppInstance()).put(TIP_CONFIG, mTipsConfig);

        if(BuildConfig.DEBUG) {
            LogUtils.i(LogUtils.TAG_TIPS, "Tips activate config info:" + new Gson().toJson(mTipsConfig));
        }
    }


    /**
     * 读取活动配置信息
     * */
    public void initTipConfigInfo() {

        if(mTipsConfig == null) {
            mTipsConfig = (TipsConfigInfo) ACache.get(PalmplayApplication.getAppInstance()).getAsObject(TIP_CONFIG);
        }
    }


    /**
     * Tip展示之后更新Tip信息，同步更新缓存
     * @param item Tip信息
     * @param isPreload 是否预加载
     * */
    @Override
    public void updateTipAfterShow(MarketEventInfo item, boolean isPreload) {

        if(item == null || isTipEmpty()) {
            return;
        }

        mLastShowTime = System.currentTimeMillis();
        SPManager.putLong(TRActivateConstant.TIP_AD_SHOWTIME, mLastShowTime);

        increaseShowCount(item.style);
        updateTipStatus(item);

        LogUtils.d(LogUtils.TAG_TIPS, "tips showed id:" + item.id + ", showed counts:" + getShowCount(item.style) + ", Frequency:" + getShowFrequency(item.style));

    }


    /**
     * 获取非弹框类型的活动信息
     * */
    public MarketEventInfo getLargestMarketEventInfoForOthers() {
        if(isTipEmpty()) {
            return null;
        }

        MarketEventInfo item = null;
        if(!isUpperLimit(TRActivateConstant.TIP_SUB_BUBBLE)) {
            item = getLargestWeightTipActivateData(TRActivateConstant.TIP_SUB_BUBBLE);
            if(item != null) {
                return item;
            }
        }

        if(!isUpperLimit(TRActivateConstant.TIP_SUB_BANNER)) {
            item = getLargestWeightTipActivateData(TRActivateConstant.TIP_SUB_BANNER);
            if(item != null) {
                return item;
            }
        }

        if(!isUpperLimit(TRActivateConstant.TIP_SUB_FLOAT)) {
            item = getLargestWeightTipActivateData(TRActivateConstant.TIP_SUB_FLOAT);
            if(item != null) {
                return item;
            }
        }

        return null;
    }


    /**
     * 获取四种活动信息
     * */
    public MarketEventInfo getLargestMarketEventInfo() {
        if(isTipEmpty() || mActivateList == null) {
            return null;
        }

        if (mActivateList.isEmpty()) {
            initActivateList();
        }

        MarketEventInfo item = null;
        Iterator<String> iteratorActivate = mActivateList.iterator();
        while (iteratorActivate.hasNext()) {
            String key = iteratorActivate.next();
            if(TextUtils.isEmpty(key)) {
                continue;
            }

            if(!isUpperLimit(key)) {
                item = getLargestWeightTipActivateData(key);
                if(item != null) {
                    return item;
                }
            }
        }

        return null;
    }




    /**
     * 退出程序时清除标记，下次启动重新开始
     * */
    @Override
    public void onClear() {
        initActivateList();

    }

    public void removeCacheAndFile() {
        if(mActivateList != null) {
            mActivateList.clear();
        }
        if (marketEventInfoList != null) {
            marketEventInfoList.clear();
        }
        clearOldData(TRActivateConstant.TIP_SUB_PROMPT);
        clearOldData(TRActivateConstant.TIP_SUB_BUBBLE);
        clearOldData(TRActivateConstant.TIP_SUB_BANNER);
        clearOldData(TRActivateConstant.TIP_SUB_FLOAT);

        mPromptPositionId = null;
        mFloatPositionId = null;

        HisavanaSdkManager.getInstance().clearEwConfigByKey(SceneCode.INSERT_SCREEN_X);
        HisavanaSdkManager.getInstance().clearEwConfigByKey(SceneCode.FLOAT_X);
    }
}


package com.afmobi.palmplay.cache.v6_4;

import android.text.TextUtils;
import android.util.LruCache;

import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.FindExtendData;
import com.afmobi.palmplay.home.model.RankExtendData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.hotword.HotWordCarouselManager;
import com.afmobi.palmplay.hotword.cache.HotWordCache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.BannerDTO;
import com.afmobi.palmplay.model.HotWordFeatureData;
import com.afmobi.palmplay.model.SearchPageInfo;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsnet.store.BuildConfig;

import org.json.JSONArray;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SearchPageCache implements LocalCache {

    private final static String SEARCH_PAGE_FILE_NAME = "SearchPageData";
    private static volatile SearchPageCache mInstance;

    public static final int SEARCH_HISTORY_MAX_SIZE = 10;
    private static final String SEARCH_HISTORY_CACHE_NAME = "search_history_file";

    /**
     * 搜索历史，最多十条记录；
     */
//    private List<String> searchHistoryList = new ArrayList<>(SEARCH_HISTORY_MAX_SIZE);
    private LruCache<String, String> searchHistoryCache = new LruCache<>(SEARCH_HISTORY_MAX_SIZE);

    private List<HotWordFeatureData> searchHotwordList = new ArrayList<>();


    private final int TAG_COUNT_LIMIT = 10;

    private int hotWordRefreshIndex;

    /**
     * 搜索热词、推荐、you may like 数据；
     * */
    private SearchPageInfo mSearchPageData;


    public SearchPageCache() {
        loadFromCache();

        initSearchHistory();
    }




    public static SearchPageCache getInstance() {
        if (mInstance == null) {
            synchronized (SearchPageCache.class) {
                if (mInstance == null) {
                    mInstance = new SearchPageCache();
                }
            }
        }

        return mInstance;
    }








    public void initCache(SearchPageInfo info) {
        if(info == null) {
            return;
        }

        transformAndSortData(info);

        mSearchPageData = info;

        hotWordRefreshIndex = 0;

        String txt = null;
        try {
            txt = new Gson().toJson(info);
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        saveToCache(txt);
    }


    public void initSearchHistory() {

        //从SD卡提取数据；
        JsonElement jsonElement = FilePathManager.fileToJson(SEARCH_HISTORY_CACHE_NAME);
        if(jsonElement == null || !jsonElement.isJsonArray()) {
            return;
        }

        List<String> tempList = null;
        try {
            Gson googleJson = new Gson();
            tempList = googleJson.fromJson(jsonElement.getAsJsonArray(), new TypeToken<List<String>>(){}.getType());
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }


        searchHistoryCache.evictAll();

        if(tempList != null && tempList.size() > 0) {
            for (String item : tempList) {
                if(!TextUtils.isEmpty(item)) {
                    searchHistoryCache.put(item, item);
                }
            }
        }
    }


    /**
     * 获取搜索历史列表
     * */
    public List<String> getSearchHistoryList() {
        if(searchHistoryCache == null) {
            return null;
        }

        Map<String, String> map = searchHistoryCache.snapshot();
        List<String> list = new ArrayList<>(map.values());

        Collections.reverse(list); //最近的排在前面

        return list;
    }


    public void insertSearchHistory(String searchKey) {
        if(TextUtils.isEmpty(searchKey)) {
            return;
        }

        if(searchHistoryCache == null) {
            return;
        }

        searchHistoryCache.put(searchKey, searchKey);

        HotWordCache.getInstance().invalidateAllMergedCache();
        HotWordCarouselManager.getInstance().resetAll();

        Collection<String> list = searchHistoryCache.snapshot().values();

        //持久化存储；
        JSONArray jsonArray = new JSONArray(list);

        saveSearchHistory(jsonArray.toString());
    }

    /**
     * 清空搜索历史列表
     * */
    public void clearSearchHistory() {
        if (searchHistoryCache.size() > 0) {
            HotWordCache.getInstance().invalidateAllMergedCache();
            HotWordCarouselManager.getInstance().resetAll();
        }

        searchHistoryCache.evictAll();
        //update file
        saveSearchHistory("");
    }

    private void saveSearchHistory(final String txt) {
        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                //持久化存储；
                FilePathManager.jsonToFile(txt, SEARCH_HISTORY_CACHE_NAME);
            }
        }));
    }



    public SearchPageInfo getSearchPageData() {
        if (mSearchPageData != null && mSearchPageData.featureList != null) {
            Iterator<FeatureBean> it = mSearchPageData.featureList.iterator();
            while (it.hasNext()) {
                FeatureBean item = it.next();
                if (item.dataList != null && item.dataList.size() > 0) {
                    Iterator<FeatureBaseData> childIt = item.dataList.iterator();
                    while (childIt.hasNext()) {
                        FeatureBaseData baseData = childIt.next();
                        baseData.hasTrack = false;
                    }
                }
            }
        }

        return mSearchPageData;
    }

    /***
     * 获取搜索热词列表
     *
     */
    public List<HotWordFeatureData> getSearchHotword() {
        return searchHotwordList;
    }

    /**
     * 将下发的热词单独保存到列表中，并将原列表中的热词列表只保留前10个(每次最多展示10个，剩下的供Refresh切换时使用)
     * */
    private void initSearchHotwordList(List<FeatureBaseData> list) {

        searchHotwordList.clear();

        //save hotword only again
        if(list != null && !list.isEmpty()) {

            for (FeatureBaseData item : list) {
                if(item instanceof HotWordFeatureData) {
                    HotWordFeatureData hotwod = (HotWordFeatureData) item;
                    searchHotwordList.add(hotwod);
                }
            }

            list.clear();
            List<HotWordFeatureData> hotword = getTopTenTagItem();
            if(hotword != null) {
                list.addAll(hotword);
            }
        }
    }



    //取10个item
    private List<HotWordFeatureData> getTopTenTagItem() {
        List<HotWordFeatureData> list = getSearchHotword();
        if(list == null || list.isEmpty()) {
            return null;
        }

        List<HotWordFeatureData> tagItems = new ArrayList<>(TAG_COUNT_LIMIT);
        for (int i = 0; i < TAG_COUNT_LIMIT && i < list.size(); i++) {
            tagItems.add(list.get(i));
        }
        hotWordRefreshIndex = TAG_COUNT_LIMIT - 1;
        return tagItems;
    }

    public List<FeatureBaseData> getNextTenTagItem() {
        List<HotWordFeatureData> sourceList = getSearchHotword();

        if (sourceList != null && sourceList.size() > TAG_COUNT_LIMIT) {

            List<FeatureBaseData> tagItems = new ArrayList<>(TAG_COUNT_LIMIT);
            if (hotWordRefreshIndex + TAG_COUNT_LIMIT <= sourceList.size()) {

                for (int i = hotWordRefreshIndex + 1; i < hotWordRefreshIndex + TAG_COUNT_LIMIT + 1 && i < sourceList.size(); i++) {
                    tagItems.add(sourceList.get(i));
                }
                hotWordRefreshIndex = hotWordRefreshIndex + TAG_COUNT_LIMIT;

            } else {

                for (int i = hotWordRefreshIndex + 1; i < sourceList.size(); i++) {
                    tagItems.add(sourceList.get(i));
                }
                //还差几个
                int count = TAG_COUNT_LIMIT - (sourceList.size() - hotWordRefreshIndex - 1);
                for (int j = 0; j < count && j < sourceList.size(); j++) {
                    tagItems.add(sourceList.get(j));
                }
                hotWordRefreshIndex = count - 1;
            }

            return tagItems;
        }

        return null;
    }



    /**
     * 获取DataList的具体类型
     * @param featureType
     * @return
     */
    private Type getDataType(String featureType){
        Type type = null;
        switch (featureType){
            case TRHomeUtil.FEATURE_TYPE_RANK:
                type = new TypeToken<List<FeatureItemData>>() {}.getType();
                break;

            case TRHomeUtil.FEATURE_TYPE_HOT_WORD:
                type = new TypeToken<List<HotWordFeatureData>>() {}.getType();
                break;
        }
        return type;
    }

    private Type getExtendDataType(String featureType){
        Type type = null;
        switch (featureType){
            case TRHomeUtil.FEATURE_TYPE_RANK:
                type = new TypeToken<RankExtendData>() {}.getType();
                break;
            case TRHomeUtil.FEATURE_TYPE_FIND:
                type = new TypeToken<FindExtendData>() {}.getType();
                break;
        }
        return type;
    }

    /**
     * 将已经安装的放到列表尾
     * @param mFeatureBean
     */
    private void rankListSort(FeatureBean mFeatureBean) {
        if (mFeatureBean != null && !TextUtils.equals(mFeatureBean.featureType, TRHomeUtil.FEATURE_TYPE_HOT_WORD) && mFeatureBean.dataList != null && mFeatureBean.dataList.size() > 0) {
            Collections.sort(mFeatureBean.dataList, new Comparator<FeatureBaseData>() {
                @Override
                public int compare(FeatureBaseData o1, FeatureBaseData o2) {

                    String firstPkg = ((FeatureItemData)o1).packageName;
                    int firstVersionCode = ((FeatureItemData)o1).versionCode;
                    String secondPkg = ((FeatureItemData)o2).packageName;
                    int secondVersionCode = ((FeatureItemData)o2).versionCode;
                    int compareResult = 0;
                    if (InstalledAppManager.getInstance().isInstalled(firstPkg, firstVersionCode)) {
                        compareResult = 1;
                        ((FeatureItemData)o1).isInstalled = true;
                    } else if (InstalledAppManager.getInstance().isInstalled(secondPkg, secondVersionCode)) {
                        compareResult = -1;
                        ((FeatureItemData)o2).isInstalled = true;
                    } else {
                        ((FeatureItemData)o1).isInstalled = false;
                        ((FeatureItemData)o2).isInstalled = false;
                    }
                    return compareResult;
                }
            });
        }
    }

    private SearchPageInfo transformAndSortData(SearchPageInfo searchPageInfo) {
        if (searchPageInfo != null && searchPageInfo.featureList != null && searchPageInfo.featureList.size() > 0) {
            Gson gson = new Gson();
            int line = 0;
            for (int i = 0;i<searchPageInfo.featureList.size();i++) {
                FeatureBean featureBean = searchPageInfo.featureList.get(i);
                featureBean.extraType = -1;
                Type typeExtendData = getExtendDataType(featureBean.featureType);
                if( typeExtendData != null){
                    try {
                        featureBean.extendData = gson.fromJson(featureBean.extendInfo,typeExtendData);
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
                Type type = getDataType(featureBean.featureType);

                if( type != null){
                    try {
                        featureBean.dataList = gson.fromJson(featureBean.data, type);
                        rankListSort(featureBean);
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }

                if(featureBean.dataList != null && !featureBean.dataList.isEmpty()) {
                    for (int j = 0; j < featureBean.dataList.size(); j++) {
                        FeatureBaseData featureBaseData = featureBean.dataList.get(j);
                        featureBaseData.topicID = featureBean.getId();
                        featureBaseData.topicPlace = String.valueOf(line);
                        featureBaseData.placementId = String.valueOf(j);
                    }
                }

                if(TextUtils.equals(featureBean.featureType, TRHomeUtil.FEATURE_TYPE_HOT_WORD)) {
                    initSearchHotwordList(featureBean.dataList);
                }

                //其他非支持类型不展示
                if(TextUtils.equals(featureBean.featureType, TRHomeUtil.FEATURE_TYPE_HOT_WORD)) {
                    line++;
                }else if (TextUtils.equals(featureBean.featureType, TRHomeUtil.FEATURE_TYPE_RANK)) {
                    if (TextUtils.equals(featureBean.style, RankStyleType.V_ROLL_TITLE) || TextUtils.equals(featureBean.style, RankStyleType.V_ROLL_NO_TITLE)) {
                        line++;
                    }
                }
            }
        }

        if (searchPageInfo != null && searchPageInfo.bannerList != null && searchPageInfo.bannerList.size() > 0) {
            for (int i = 0;i<searchPageInfo.bannerList.size();i++) {
                BannerDTO item = searchPageInfo.bannerList.get(i);
                item.placementId = String.valueOf(i);
            }
        }

        TRHomeUtil.resetVaStatus4SearchPageInfo(searchPageInfo);
        TRHomeUtil.checkTraceId(searchPageInfo);

        return searchPageInfo;
    }


    @Override
    public void saveToCache(final String jsonBuffer, final Object... objects) {

        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
            @Override
            public void doRun() {
                String fileName = getFileName(objects);
                FilePathManager.jsonToFile(jsonBuffer, fileName);
            }
        }));
    }

    @Override
    public void loadFromCache(Object... objects) {
        String fileName = getFileName(objects);

        if (fileName != null) {
            JsonElement jsonObject = (JsonElement) FilePathManager.fileToJson(fileName);
            if (jsonObject != null) {
                try {
                    Gson gson = new Gson();
                    Type type = new TypeToken<SearchPageInfo>() {}.getType();
                    mSearchPageData = gson.fromJson(jsonObject, type);
                }catch(Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        }

        transformAndSortData(mSearchPageData);
    }

    @Override
    public String getFileName(Object... objects) {
        return SEARCH_PAGE_FILE_NAME;
    }

    public void onClear() {
        hotWordRefreshIndex = 0;
    }
}

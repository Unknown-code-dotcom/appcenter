package com.afmobi.palmplay.cloudfolder.recently.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "installed_apps_history",
    indices = [Index(value = ["installedTime"])]
)
data class PalmInstalledAppEntity(
    @PrimaryKey
    val packageName: String,
    val itemId: String?,
    val name: String?,
    val iconUrl: String?,
    val versionCode: Int,
    val versionName: String?,
    val installedTime: Long,
    val isUpdate: Int,
    val fromPage: String?
)

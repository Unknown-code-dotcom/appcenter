/*Transsion Top Secret*/
package com.afmobi.palmplay.cloudfolder.utils;

import android.content.Context;
import android.widget.TextView;
import androidx.core.content.ContextCompat;

import com.transsnet.store.R;

/**
 * Created by tao.xu2 on 2017/5/3.
 */

public class PaletteControls{
    private static final String TAG = "PaletteControls";
    private static final int SHADOW_HIDE_RADIUS = 0;
    public static final int SHADOW_DX = 0;
    public static final int SHADOW_DY = 1;

    private int mShadowColor;
    private int mShadowRadius;

    private static PaletteControls sInstance;
    private PaletteControls(Context context){
        mShadowColor = ContextCompat.getColor(context, R.color.cloud_folder_text_shadow_color);
        mShadowRadius = context.getResources().getDimensionPixelSize(R.dimen.cloud_folder_text_shadow_radius);
    }

    public static PaletteControls getInstance(Context context){
        if(sInstance == null){
            sInstance = new PaletteControls(context);
        }
        return sInstance;
    }

    public void updateTextShadow(TextView textView){
        updateTextShadow(textView, true);
    }

    public void updateTextShadow(TextView textView, boolean forceAddShadow) {
        if (textView != null) {
            if (forceAddShadow) {
                textView.setShadowLayer(mShadowRadius * 1.0f, SHADOW_DX * 1.0f, SHADOW_DY * 1.0f, mShadowColor);
            } else {
                textView.setShadowLayer(SHADOW_HIDE_RADIUS * 1.0f, SHADOW_DX * 1.0f, SHADOW_DY * 1.0f, mShadowColor);
            }
        }
    }

}

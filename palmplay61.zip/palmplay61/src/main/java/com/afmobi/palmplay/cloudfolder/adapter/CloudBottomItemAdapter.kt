package com.afmobi.palmplay.cloudfolder.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.CloudFolderRemoteController
import com.afmobi.palmplay.cloudfolder.AttributionUploadManager
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.utils.CloudFolderLauncher
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.PadFolderUi
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import com.afmobi.palmplay.cloudfolder.view.GlobalShapeClipFrameLayout
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.transsion.palmstorecore.glide.GlideApp
import com.transsnet.launcherlib.model.FileFolderData
import com.transsnet.store.R

class CloudBottomItemAdapter(val categoryType: Int,
    private var items: List<FileFolderData.DataItem.AppBottomInfo>
) : RecyclerView.Adapter<CloudBottomItemAdapter.ItemViewHolder>() {

    private var pageIndex = 0

    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView: TextView = itemView.findViewById(R.id.itemText)
        val cardIcon: GlobalShapeClipFrameLayout = itemView.findViewById(R.id.card_icon)
        val iconView: ImageView = itemView.findViewById(R.id.iconView)
        val rootView: View = itemView.findViewById(R.id.rootView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cloud_folder_bottom, parent, false)
        applyPadItemWidth(view)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        applyPadItemWidth(holder.itemView)
        val itemInfo = items[position]
        holder.textView.text = itemInfo.name
        val remoteController = CloudFolderRemoteController.getInstance()
        val useGlobalShape = remoteController.hasGlobalIconShape()
        holder.cardIcon.setGlobalIconShapePath(
            if (useGlobalShape) remoteController.getGlobalIconShapePath() else null
        )
        val glideRequest = GlideApp.with(PalmplayApplication.getAppInstance())
            .load(itemInfo.iconUrl)
        if (useGlobalShape) {
            glideRequest.transform(CenterCrop()).into(holder.iconView)
        } else {
            glideRequest.transform(CenterCrop(), RoundedCorners(dip2px(15f)))
                .into(holder.iconView)
        }
        val totalIndex = pageIndex * 4 + position
        reportBindExposure(holder.itemView, totalIndex, itemInfo)
        holder.rootView.setOnClickListener {
            val launchType = CloudFolderLauncher.launchFromOtherType(itemInfo)
            CloudFolderTrackUtil.businessBottomItemClickTrack(totalIndex, itemInfo.packageName, categoryType, itemInfo.jumpType, launchType)
        }
    }

    override fun getItemCount(): Int = items.size

    private fun reportBindExposure(
        itemView: View,
        totalIndex: Int,
        itemInfo: FileFolderData.DataItem.AppBottomInfo
    ) {
        val deviceProfile = DeviceProfile.getInstance()
        if (deviceProfile.isPadLayout &&
            itemView.resources.configuration.orientation
            == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        ) {
            return
        }
        if (!CloudFolderTrackUtil.markBottomExposureOnce(
                categoryType,
                totalIndex,
                itemInfo.packageName,
                CloudFolderTrackUtil.SCENE_BOTTOM_CDN
            )
        ) {
            return
        }
        CloudFolderTrackUtil.businessBottomItemExposureTrack(
            totalIndex, itemInfo.packageName, 0, categoryType, itemInfo.jumpType
        )
        AttributionUploadManager.getInstance().enqueueNewRequest(itemInfo.showTracking, itemInfo.name)
    }

    private fun applyPadItemWidth(view: View) {
        val deviceProfile = DeviceProfile.getInstance()
        if (!deviceProfile.isPadLayout) return
        view.layoutParams = view.layoutParams.apply {
            width = deviceProfile.folderBottomItemWidth
        }
        PadFolderUi.applyBottomDownloadBadge(view)
    }

    // 更新数据的方法
    fun updateItems(index: Int, newItems: List<FileFolderData.DataItem.AppBottomInfo>) {
        pageIndex = index
        items = newItems
        notifyDataSetChanged()
    }
}

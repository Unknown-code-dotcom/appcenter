package com.afmobi.palmplay.collection

interface CollectionNavigator {
}
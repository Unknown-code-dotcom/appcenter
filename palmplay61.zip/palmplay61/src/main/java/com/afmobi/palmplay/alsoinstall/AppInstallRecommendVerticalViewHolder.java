package com.afmobi.palmplay.alsoinstall;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appnext.AppNextConstants;
import com.afmobi.palmplay.appnext.AppNextProcessor;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.home.instant.IVaPlayDownloadCallback;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.animations.AnimationFactory;
import com.afmobi.util.animations.AnimationFactoryParams;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ZLayoutAppInstallRecommendListItemVBinding;

import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class AppInstallRecommendVerticalViewHolder extends AppInstallRecommendBaseViewHolder{


    private ZLayoutAppInstallRecommendListItemVBinding mBinding;


    public AppInstallRecommendVerticalViewHolder(ViewDataBinding binding) {
        super(binding.getRoot());

        mBinding = (ZLayoutAppInstallRecommendListItemVBinding) binding;
    }

    @Override
    public void bind(FeatureBaseData featureItemData, int position) {

        if (featureItemData instanceof FeatureItemData) {

            FeatureItemData item = (FeatureItemData)featureItemData;

            itemView.setVisibility(View.VISIBLE);

            itemView.setTag(item);

            int defaultIcon = R.drawable.layer_list_app_default_01_bg;

            DownloadStatusManager.getInstance().registerFeatureItemInstance(item);

            CommonUtils.checkStatusItemDisplay(item, mBinding.downloadView, mOfferInfo, null);
            mBinding.layoutRoot.setOnClickListener(new NoDoubleClickListener(item, position));
            mBinding.downloadView.setOnClickListener(new DownloadBtnOnClickListener(item,mBinding.downloadView, position));
            int corner = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 8f);
            GlideUtils.setImageUrl(mBinding.ivIcon, item.iconUrl, corner, defaultIcon, defaultIcon);

            String simpleDescription = CommonUtils.getSimpleDescription(item);
            mBinding.tvDescription.setText(simpleDescription);
            mBinding.tvName.setText(item.name);

            boolean show = CommonUtils.shouldShowScore(item.score);
            mBinding.llStarContainer.setVisibility(show ? View.VISIBLE : View.GONE);
            if (show) {
                mBinding.tvScore.setText(String.valueOf(item.score));
            }
            CommonUtils.setStrikeThroughSpannable(item.size, item.compSourceSize, mBinding.tvSourceSize);


            mBinding.ivScore.setVisibility(View.VISIBLE);
            mBinding.tvScore.setVisibility(View.VISIBLE);
            updateTextDownloadCountAndSize(item,mBinding.tvDownloadCount);

            mBinding.ivGift.setVisibility(TextUtils.isEmpty(item.lableUrl) || !CommonUtils.isGiftFlagNeedShow() ? View.GONE : View.VISIBLE);
            GlideUtils.setImageUrlWithNoBorder(mBinding.ivGift, item.lableUrl);

            if (item.downloadCount > 0) {
                mBinding.tvDownloadCount.setVisibility(View.VISIBLE);
                mBinding.ivDownloadCount.setVisibility(View.VISIBLE);
                mBinding.tvDownloadCount.setText(CommonUtils.getDownloadCountStr(item.downloadCount));
            } else {
                mBinding.tvDownloadCount.setVisibility(View.GONE);
                mBinding.ivDownloadCount.setVisibility(View.GONE);
            }

            if (gdprHasAllowed && !item.hasTrack) {
                item.hasTrack = true;
                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(position));
                if(!TextUtils.isEmpty(item.getShowReportUrl())) {
                    AppNextProcessor.addAsyncTask(item.packageName, AppNextConstants.ITEM_SHOW, item.getShowReportUrl());
                }
                ComponentExposureBuilder builder = new ComponentExposureBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(getStyleName())
                        .setTopicId(item.topicID)
                        .setItemType(item.detailType)
                        .setItemId(item.itemID)
                        .setItemValue(item.packageName)
                        .setTaskId(item.getTaskId())
                        .setExpId(item.getExpId())
                        .setItemFrom(item.getItemFrom())
                        .setReportSource(item.getReportSource())
                        .setCfgId(item.getCfgId())
                        .setVarId(item.getVarId())
                        .setDataType(item.dataType)
                        .setNativeId(item.nativeId)
                        .setFeatureId(featureId)
                        .setExtras(getExtras())
                        .setIsVa(item.isVa);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                }
                TRAnalysticsUtil.trackExposure(builder);
            }
        }else {
            dismissItemView();
        }
    }



    private void updateTextDownloadCountAndSize(FeatureItemData featureData, TextView tv_download_count_and_size) {
        if (0 != featureData.size) {
            tv_download_count_and_size.setVisibility(View.VISIBLE);
            tv_download_count_and_size.setText(CommonUtils.replace(PalmplayApplication.getAppInstance().getString(R.string.text_download_size), CommonUtils.TARGET_NAME
                    , FileUtils.getSizeName(featureData.size/*Transverter.stringToLong(mRankDataListItem.size, 0)*/)));
        } else {
            tv_download_count_and_size.setVisibility(View.GONE);
        }
    }



    //防止快速点击响应多次
    private class NoDoubleClickListener implements View.OnClickListener {

        private FeatureItemData featureItemData;
        private int mPosition;

        public NoDoubleClickListener(FeatureItemData featureItemData, int position) {
            this.featureItemData = featureItemData;
            this.mPosition = position;
        }

        @Override
        @SingleClick(800)
        public void onClick(View v) {
            if (featureItemData != null && !TextUtils.isEmpty(featureItemData.itemID)) {
                String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(mPosition));
                AppBuilder appBuilder = new AppBuilder()
                        .setFromPage(mFromPage)
                        .setTopicID(featureItemData.topicID)
                        .setExpId(featureItemData.getExpId())
                        .setVarId(featureItemData.getVarId())
                        .setLastPage(PageConstants.getCurPageStr(mPageParamInfo))
                        .setValue(value)
                        .setParamsByData(featureItemData, featureId);
                TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);
                ComponentClickBuilder builder = new ComponentClickBuilder();

                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(getStyleName())
                        .setTopicId(featureItemData.topicID)
                        .setItemType(featureItemData.detailType)
                        .setItemId(featureItemData.itemID)
                        .setButtonType(TRAnalyticsConstant.ICON)
                        .setItemValue(featureItemData.packageName)
                        .setExtraValue("")
                        .setTaskId(featureItemData.getTaskId())
                        .setExpId(featureItemData.getExpId())
                        .setItemFrom(featureItemData.getItemFrom())
                        .setVarId(featureItemData.getVarId())
                        .setNativeId(featureItemData.nativeId)
                        .setReportSource(featureItemData.getReportSource())
                        .setFromPage(mFromPage)
                        .setFeatureId(featureId)
                        .setExtras(getExtras())
                        .setIsVa(featureItemData.isVa);
                if (featureItemData.reportDto!=null) {
                    builder.setTid(featureItemData.reportDto.traceId);
                }
                TRAnalysticsUtil.trackClick(builder);
            }
        }

    }

    // download click listener
    class DownloadBtnOnClickListener implements View.OnClickListener {

        private FeatureItemData featureItemData;
        private View bindClickView;
        private int mPosition;

        public DownloadBtnOnClickListener(FeatureItemData featureItemData, View bindClickView, int position) {
            this.featureItemData = featureItemData;
            this.bindClickView = bindClickView;
            this.mPosition = position;
        }

        @Override
        public void onClick(View v) {
            if (bindClickView == null || featureItemData == null)
                return;
            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(mPosition));
            String itemFrom = featureItemData.getItemFrom();
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType(getStyleName())
                    .setTopicId(featureItemData.topicID)
                    .setItemType(featureItemData.detailType)
                    .setItemId(featureItemData.itemID)
                    .setItemValue(featureItemData.packageName)
                    .setExtraValue("")
                    .setTaskId(featureItemData.getTaskId())
                    .setExpId(featureItemData.getExpId())
                    .setItemFrom(itemFrom)
                    .setNativeId(featureItemData.nativeId)
                    .setReportSource(featureItemData.getReportSource())
                    .setVarId(featureItemData.getVarId())
                    .setFromPage(mFromPage)
                    .setFeatureId(featureId)
                    .setExtras(getExtras())
                    .setIsVa(featureItemData.isVa);
            if (featureItemData.reportDto!=null) {
                builder.setTid(featureItemData.reportDto.traceId);
            }
            PsVaManager.getInstance().checkDownloadInfo(featureItemData, LaunchInfo.LAUNCH_FROM_ICON,mFromPage,value,
                    new IVaPlayDownloadCallback() {
                        @Override
                        public void clickVaPlay() {
                            builder.setButtonType(TRAnalyticsConstant.PLAY);
                            TRAnalysticsUtil.trackClick(builder);
                        }
                        @Override
                        public void start() {
                            startDownload(featureItemData, mBinding.ivIcon, mBinding.downloadView, builder);
                        }
                    });
        }

        private void startDownload(FeatureItemData featureItemData, ImageView iv_icon, View downloadView, ComponentClickBuilder builder) {
            if (featureItemData == null) {
                return;
            }

            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, topicPlace, placementId, String.valueOf(mPosition));

            if (FileDownloadInfo.STATUS_DOWNING == featureItemData.observerStatus) {
                DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_WAIT == featureItemData.observerStatus) {
                if ((featureItemData.isVa)) {
                    DownloadManager.getInstance().resumeDownload(featureItemData.packageName);
                } else {
                    DownloadManager.getInstance().pauseDownload(featureItemData.packageName);
                }
                builder.setButtonType(featureItemData.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            }else if (FileDownloadInfo.STATUS_PAUSE == featureItemData.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == featureItemData.observerStatus) {
                DownloadUtil.resumeDownload(PalmplayApplication.getAppInstance(), featureItemData.packageName);
                builder.setButtonType(TRAnalyticsConstant.CONTINUE);
                TRAnalysticsUtil.trackClick(builder);
            } else {
                if (FileDownloadInfo.STATUS_NONE == featureItemData.observerStatus) {//下载
                    builder.setButtonType(TRAnalyticsConstant.INSTALL);
                    TRAnalysticsUtil.trackClick(builder);
                } else if (FileDownloadInfo.STATUS_APP_INSTALLED == featureItemData.observerStatus) {//打开
                    builder.setButtonType(TRAnalyticsConstant.OPEN)
                            .setExtraValue(DeeplinkManager.getDeeplink(featureItemData.packageName));
                    TRAnalysticsUtil.trackClick(builder);
                }
                if (DownloadDecorator.checkJumpToGooglePlay(PalmplayApplication.getAppInstance(), featureItemData.getOuterUrl(), featureItemData.packageName, mPageParamInfo, featureItemData.itemID, featureItemData.versionCode, featureItemData.verifyGoogle)) {
                    return;
                }

                AnimationFactory mAnimationFactory = null;
                AnimationFactoryParams param = null;

                if (mOnViewLocationInScreen != null) {
                    mAnimationFactory = AppDetailAnimationUtil.getInstance();
                    param = new AnimationFactoryParams(iv_icon, mOnViewLocationInScreen, 24);
                }
                DownloadDecorator.startDownloading(FeatureItemData.convertToCommonInfo(featureItemData, featureId), mFromPage, new PageParamInfo(mFrom, value), mAnimationFactory, param);
            }
        }
    }

    public static void updateItemProgress(View itemView, FileDownloadInfo downloadInfo, int progress, OfferInfo offerInfo) {
        RecyclerView id_recycleview = itemView.findViewById(R.id.id_recyclerview);
        RecyclerView.Adapter adapter = (id_recycleview != null) ? id_recycleview.getAdapter() : null;
        if (adapter == null || downloadInfo == null) {
            return;
        }

        String packageName = downloadInfo.packageName;
        int childCount = adapter.getItemCount();
        LinearLayoutManager lm = (LinearLayoutManager) id_recycleview.getLayoutManager();
        for (int i = 0; i < childCount; i++) {
            View childView = lm.findViewByPosition(i);
            Object objTag = childView != null ? childView.getTag() : null;
            if (objTag != null && objTag instanceof FeatureItemData) {
                FeatureItemData featureItemData = (FeatureItemData) objTag;
                if (!TextUtils.isEmpty(featureItemData.packageName) && featureItemData.packageName.equals(packageName)) {
                    XFermodeDownloadView downloadView = childView.findViewById(R.id.downloadView);
                    CommonUtils.updateViewHolderProgressBar(downloadInfo, downloadView, offerInfo, null);
                }
            }
        }
    }
}

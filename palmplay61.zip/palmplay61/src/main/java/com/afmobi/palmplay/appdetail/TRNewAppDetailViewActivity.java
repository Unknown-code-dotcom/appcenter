package com.afmobi.palmplay.appdetail;

import static com.afmobi.palmplay.PalmplayApplication.getAppInstance;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appdetail.data.AppInfoDetail;
import com.afmobi.palmplay.appdetail.holder.AppDetailDownloadHolder;
import com.afmobi.palmplay.appdetail.holder.AppDetailTopHolder;
import com.afmobi.palmplay.appdetail.holder.CommonAppDetailView;
import com.afmobi.palmplay.appdetail.holder.AppDetailsAppBarHolder;
import com.afmobi.palmplay.appdetail.holder.AppDetailsIconHolder;
import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.customview.BackFloatBallView;
import com.afmobi.palmplay.customview.PsFloatBallView;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.hotword.HotWordViewModel;
import com.afmobi.palmplay.hotword.SearchBarPosition;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.ObbFormatDataManager;
import com.afmobi.palmplay.main.PermissionsReqActivity;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.manager.Code;
import com.afmobi.palmplay.manager.DetailCacheManager;
import com.afmobi.palmplay.manager.DetailConfigManager;
import com.afmobi.palmplay.manager.PalmPlayNetworkDownloadStateManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.DetailResponseData;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.PreDownloadInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.TagItem;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.mvvm.BaseActivity;
import com.afmobi.palmplay.network.AsyncHttpRequestUtils;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.newdiff.HsyniLoader;
import com.afmobi.palmplay.newdiff.OnHsynzListener;
import com.afmobi.palmplay.permissions.PermissonsHintDialog;
import com.afmobi.palmplay.quickinstall.PreInstallManager;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.video.helper.TrVideoPlayer;
import com.afmobi.palmplay.viewmodel.TRAppOtherModel;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.TRPermissionUtil;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.androidnetworking.error.ANError;
import com.androidnetworking.internal.InternalNetworking;
import com.didi.drouter.annotation.Router;
import com.trans.common.netstate.AppNetState;
import com.trans.common.netstate.NetTypeKt;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.apm.TRApmAnalysticsUtil;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.AndroidVUIUtils;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BR;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ZActivityNewAppDetailLayoutBinding;

import java.util.List;
import java.util.Objects;

/**
 */
@Router(path = "/page/newAppDetail/full")
public class TRNewAppDetailViewActivity extends BaseActivity<ZActivityNewAppDetailLayoutBinding, TRNewAppViewModel> {
    private static final String TAG = "TRNewAppDetailViewActivity";

    private ZActivityNewAppDetailLayoutBinding mBinding;
    private CommonAppDetailView commonAppDetailView;//基础框架Holder，包括Tablayout以及ViewPager的分页逻辑
    private AppDetailDownloadHolder detailDownloadHolder;//大按钮statusPanel的holder，包括下载点击的处理
    private AppDetailTopHolder appDetailTopHolder;//页面上半部分的hodler，标题、标签、下载、大小、榜单排名等
    private AppDetailsAppBarHolder appBarHolder;//标题栏holder，包括搜索热词、下载/分享/游戏/回退按键的处理、滑动变色的处理
    private AppDetailsIconHolder detailsIconHolder;//icon的变色处理
    private HotWordViewModel hotWordViewModel;

    private AppInfo mAppInfo;
    private CustomDialog mProductInvalidDialog;
    private TRNewAppViewModel mAppDetailModel;

    private UINetworkErrorUtil mUINetworkErrorUtil = UINetworkErrorUtil.create();
    private UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();
    private String mFrom = "";
    private PageParamInfo mPageParamInfo = new PageParamInfo();

    @Nullable
    private BackFloatBallView mBackFloatBallView;
    private MutableLiveData<Integer> mColorLiveData = new MutableLiveData<>();

    private boolean isCustomized = false;
    private boolean isHaveCache = false;
    private String mType;
    private String track_type;//EW归因类型

    private boolean isPermissionHintDialogShowed;
    private String mValue = "";

    private long onCreateTime;
    private long onRenderStartTime;
    private boolean backFloatball;
    public static boolean detailDialogHasShowed = false;
    private int code;
    private Handler mHandle = new Handler();
    private AppInfoDetail appInfoDetail;
    boolean restoreTipsVisible = false;
    int restoreTab = 0;

    // 深色/浅色切换重建 Activity 的防抖与状态记录（避免多次触发导致反复重建）
    private int mLastUiModeNight = -1;
    private boolean mUiModeRecreating = false;

    public boolean isLaunchedFromVa() {
        Intent intent = getIntent();
        if (intent == null){
            return false;
        }
        int launchType  = intent.getIntExtra(PsVaManager.VA_LAUNCH_TYPE, LaunchInfo.LAUNCH_FROM_ICON);
        // 目前只处理快捷方式和VA游戏内来源
        return launchType == LaunchInfo.LAUNCH_FROM_SHORTCUT || launchType == LaunchInfo.LAUNCH_FROM_VIRTUAL_APP;
    }


    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("tips_visible", mAppDetailModel.isTipsVisible());
        outState.putInt("current_tab", mBinding.viewpager.getCurrentItem());
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        reMeasureStatusBar = true;
        super.onCreate(savedInstanceState);
        // 记录当前 uiMode（夜间/非夜间），用于 onConfigurationChanged 判断是否需要重建
        mLastUiModeNight = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        mUiModeRecreating = false;

        if (BuildConfig.DEBUG) {
            int type = getIntent().getIntExtra(PsVaManager.VA_LAUNCH_TYPE, LaunchInfo.LAUNCH_FROM_ICON);
            LogUtils.d("launch from type: " + type);
        }
        mBinding = getViewDataBinding();
        onCreateTime = System.currentTimeMillis();

        if (TRSharedPreferenceUtils.getAdDetailSwitch() == 1) {
            mAppDetailModel.loadAdData();
        }
        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            mAppDetailModel.handBundleData(bundle, mPageParamInfo);
            mFrom = bundle.getString("value", "");
            mType = bundle.getString("type");
        }
        mValue = getValue();
        mAppDetailModel.setPage(mValue, mFrom);

        if (mAppDetailModel.getAppInfoDetailLiveData() != null && mAppDetailModel.getAppInfoDetailLiveData().getValue() != null){
            appInfoDetail = mAppDetailModel.getAppInfoDetailLiveData().getValue();
            isHaveCache = appInfoDetail.isHaveCache;
            isCustomized = appInfoDetail.isCustomized;
            mAppInfo = appInfoDetail.appInfo;

            if (BuildConfig.DEBUG) {
                LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onCreate 1:" + appInfoDetail.toString());
            }
        }
        if (mAppInfo == null) {//需要处理重建问题
            appInfoDetail = mAppDetailModel.loadDetailCacheData(AppDetailUtils.isUseSmallCache(mType));// 改造 initData();
            isHaveCache = appInfoDetail.isHaveCache;//挪走到
            isCustomized = appInfoDetail.isCustomized;//挪走到
            mAppInfo = appInfoDetail.appInfo;
            mAppDetailModel.getAppInfoDetailLiveData().setValue(appInfoDetail);

            if (BuildConfig.DEBUG) {
                LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onCreate 2:" + appInfoDetail.toString());
            }
        }
        if (mAppInfo != null) {
            mAppInfo.isMultiPackage = ((Integer)mAppDetailModel.getParam(Constant.KV_SUPPORT_OVERLAY)) == 1;
        }

        int bg = CommonUtils.parseColor(mAppInfo.backgroundRgb);
        AndroidVUIUtils.INSTANCE.matchAndroid15UI(this,reMeasureStatusBar, bg);

        if (savedInstanceState != null) {
            restoreTipsVisible = savedInstanceState.getBoolean("tips_visible", false);
            restoreTab = savedInstanceState.getInt("current_tab", 0);
        }
        mBinding.toolbar.setContentInsetsAbsolute(0, 0);
        mBinding.toolbar.setContentInsetsRelative(0, 0);
        initViewHolder(restoreTipsVisible ,restoreTab);//findViews改造来的
        initObservers();//modifyData()改造而来
        GdprDialogInstance.getInstance().gdprAppDetailHandle(this);
        requestDetailApiData();
        mAppDetailModel.setPageCode(1);
        mAppDetailModel.trackEvent(1, mAppInfo);
        mHandle.post(new Runnable() {
            @Override
            public void run() {
                if(isHaveCache) {
                    if (BuildConfig.DEBUG) {
                        LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onCreate 3:" + appInfoDetail.toString());
                    }
                    refreshUI();
                    if (detailDownloadHolder != null){
                        detailDownloadHolder.preHandleAutoDownload(mAppDetailModel.isAutoDownload(), mAppInfo, mBinding.statusPanel, mFrom);
                    }
                }
            }
        });
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // 仅处理深色/浅色切换：通过 recreate() 重建当前 Activity，让所有布局/资源按新模式重新 inflate。
        // 使用 recreate 而不是 startActivity，避免启动多个实例。
        int newNight = newConfig.uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (BuildConfig.DEBUG) {
            LogUtils.e(TAG, TrVideoPlayer.TAG + "----0----onConfigurationChanged----onKeyDown----"
                    + newNight + "----" + mLastUiModeNight + "----" + mUiModeRecreating);
        }
        if (mLastUiModeNight == -1) {
            mLastUiModeNight = newNight;
            return;
        }

        if (newNight != mLastUiModeNight) {
            mLastUiModeNight = newNight;

            if (mUiModeRecreating || isFinishing() || isDestroyed()) {
                return;
            }
            mUiModeRecreating = true;

            View root = (mBinding != null) ? mBinding.getRoot() : null;
            if (root != null) {
                root.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            int orientation = getResources().getConfiguration().orientation;
                            boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
                            if (isLandscape) {
                                if (commonAppDetailView != null && commonAppDetailView.onKeyDown()) { //全屏播放视频时返回只退出全屏播放
//                                    TrVideoViewManager.getInstance().releaseVideoView();
                                    if (BuildConfig.DEBUG) {
                                        LogUtils.e(TAG, TrVideoPlayer.TAG + "----1----onConfigurationChanged----onKeyDown----");
                                    }
                                }
                            }

                            recreate();
                        } catch (Throwable ignore) {
                        }
                    }
                });
            } else {
                try {
                    int orientation = getResources().getConfiguration().orientation;
                    boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
                    if (isLandscape) {
                        if (commonAppDetailView != null && commonAppDetailView.onKeyDown()) { //全屏播放视频时返回只退出全屏播放
//                            TrVideoViewManager.getInstance().releaseVideoView();
                            if (BuildConfig.DEBUG) {
                                LogUtils.e(TAG, TrVideoPlayer.TAG + "----2----onConfigurationChanged----onKeyDown----");
                            }
                        }
                    }
                    recreate();
                } catch (Throwable ignore) {
                }
            }
        }
    }

    @Override
    public void resetHasShowed() {
        //单独控制是否弹无网络弹框
    }

    private void initHotWordViewModel() {
        hotWordViewModel = new ViewModelProvider(this).get(HotWordViewModel.class);
        // 有缓存热词时立即替换默认文案，无热词时设置默认文案兜底
        TagItem firstTag = hotWordViewModel.getFirstTagItem(SearchBarPosition.DETAIL);
        if (firstTag != null && appBarHolder != null) {
            appBarHolder.initHotWord(firstTag);
        } else if (appBarHolder != null) {
            TagItem defaultTag = new TagItem();
            defaultTag.term = getString(R.string.search_soft);
            defaultTag.name = getString(R.string.search_soft);
            appBarHolder.initHotWord(defaultTag);
        }
        hotWordViewModel.getLiveData(SearchBarPosition.DETAIL).observe(this, tagItem -> {
            if (appBarHolder != null) {
                appBarHolder.updateHotWord(tagItem);
            }
        });
    }

    private String buildDisplayList(DetailResponseData response, AppInfo appInfo, boolean isCustomized) {
        List<DetailComponentItemData> componentList = response != null ? response.getComponentListByStyle(AppDetailsRecyclerViewAdapter.TAB_TYPE_DETAIL) : null;
        // 进入详情页时，检查 _source 是否命中折叠配置（使用 TRAppOtherModel 已解析好的 _source）
        String source = (String) mAppDetailModel.getParam("_source");
        boolean mIsDetailCollapsed = DetailConfigManager.getInstance().checkSourceCollapsed(source);
        boolean mIsSourceCollapsed = !isCustomized && mIsDetailCollapsed;

        //优先展示升级的show detail
        String mDetailSource;
        if (componentList!=null) {
            for (DetailComponentItemData item : componentList) {
                if (mIsSourceCollapsed && appInfo.observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED) {
                    // 命中view all 并且是open的情况下，不展示show detail
                } else {
                    if (NewAppDetailsRecyclerViewAdapter.COMPONET_INTRODUCE.equals(item.dataType) && item.nfAbSwitch == 1) {
                        mDetailSource = "Update";
                        return mDetailSource;
                    }
                }
            }
        }
        //再展示渠道的view all
        if (mIsSourceCollapsed) {
            mDetailSource = "Source";
            return mDetailSource;
        }
        if (isCustomized){
            mDetailSource = "Offer";
        }else {
            mDetailSource = "Default";
        }
        return mDetailSource;
    }

    /***
     * 接受从viewmodel的数据变化
     */
    private void initObservers() {
        mAppDetailModel.getAppInfoDetailLiveData().observe(this, new Observer<AppInfoDetail>() {
            @Override
            public void onChanged(AppInfoDetail appInfoDetail) {
                if (appInfoDetail != null){
                    isHaveCache = appInfoDetail.isHaveCache;
                    isCustomized = appInfoDetail.isCustomized;
                    if (appInfoDetail.appInfo != null) {
                        mAppInfo.copyData(appInfoDetail.appInfo);
                        if (commonAppDetailView != null) {//todo 这个地方没有处理好
                            commonAppDetailView.setData(mAppInfo, mPageParamInfo, mType, isCustomized, mFrom);
                        }
                    }
                }

                if (BuildConfig.DEBUG) {
                    LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onChanged 1:" + (appInfoDetail == null ? " null" : appInfoDetail.toString()));
                }

                final PreDownloadInfo.DownloadTypeBean.NewDiffBean newDiffBean;
//
                DetailResponseData newDetailResponse = mAppDetailModel.getNewDetailResponseLiveData().getValue();
                DetailResponseData detailResponse = mAppDetailModel.getDetailResponseLiveData().getValue();

                int uiFindFlag = detailResponse != null ? detailResponse.findFlag : -1;
                int newFindFlag = newDetailResponse != null ? newDetailResponse.findFlag : -1;

                boolean needRebuildTab = uiFindFlag != -1 && newFindFlag != -1 && uiFindFlag != newFindFlag;
                LogUtils.d(LogUtils.TAG_NETWORK, "[tab-check] needRebuildTab=" + needRebuildTab + " (ui=" + uiFindFlag + ", new=" + newFindFlag + ")");

                if(!isHaveCache || needRebuildTab) {
                    //无缓存时EW插入到新详情数据中，并刷新页面；
                    mAppDetailModel.addAdData(newDetailResponse, isHaveCache);
                    mAppDetailModel.getDetailResponseLiveData().setValue(newDetailResponse);

                    refreshUI();
                    if (detailDownloadHolder != null){
                        detailDownloadHolder.preHandleAutoDownload(mAppDetailModel.isAutoDownload(), mAppInfo, mBinding.statusPanel, mFrom);
                    }
                    mUILoadingGifUtil.setVisibility(View.GONE);
                    newDiffBean = (newDetailResponse != null) ? newDetailResponse.newDiff : null;
                }else {

                    // 接受网络数据的变化
                    boolean ret = mAppDetailModel.addAdData(detailResponse, isHaveCache);
                    if (ret) {
                        mAppInfo.detailSource = buildDisplayList(detailResponse, mAppInfo, isCustomized);
                        mAppDetailModel.setParam("_detailSource", mAppInfo.detailSource);//在 onAppInfoChanged 之前，需要处理这个逻辑，不然，和里面的不一样

                        if (commonAppDetailView != null) {//todo 这个地方没有处理好，mAppInfo修改成 livedata
                            commonAppDetailView.setData(mAppInfo, mPageParamInfo, mType, isCustomized, mFrom);
                        }

                        List<DetailComponentItemData> componentList = commonAppDetailView.onAppInfoChanged(detailResponse, false);
                        if (BuildConfig.DEBUG) {
                            LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity onChanged 2:" + (componentList == null? " null" : componentList.size()));
                        }
                    }
                    newDiffBean = (detailResponse != null) ? detailResponse.newDiff : null;
                }

                //load newDiff
                if (newDiffBean != null) {//todo 有没有可能挪走？放到子线程中
                    final String pkg = mAppInfo.packageName;
                    HsyniLoader.INSTANCE.loadHsyni(pkg, newDiffBean, InternalNetworking.getClient(), new OnHsynzListener() {
                        @Override
                        public void onHsynzError(@Nullable String path) {

                        }

                        @Override
                        public void onHsynzComplete(@Nullable String path) {

                        }

                        @Override
                        public void onHsynzSuccess(long diffSize, long total) {
                            if (mAppInfo != null && diffSize > 0 && total > diffSize) {
                                mAppInfo.diffSize = (int) diffSize;

                                DetailResponseData respData = mAppDetailModel.getDetailResponseLiveData().getValue();
                                if (respData != null) {
                                    respData.putComponentItemDiffSize((int) diffSize);
                                    DetailCacheManager.getInstance().putDetailRamCache(respData);
                                }

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (detailDownloadHolder != null){
                                            detailDownloadHolder.updateStatusChanged();
                                        }
                                    }
                                });

                            }
                        }
                    });
                }
            }
        });

        mAppDetailModel.getCodeLiveData().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer integer) {
                if (integer == null) {
                    return;
                }
                code = integer;
                detailDownloadHolder.checkButton(mAppInfo, code);

                if (integer == Code.CODE_506_NEGATIVE
                        && !TRStringUtil.isBlank((String) mAppDetailModel.getParam("fromPageID"))
                        && (((String) mAppDetailModel.getParam("fromPageID")).equals(FromPageType.Message)
                        || ((String) mAppDetailModel.getParam("fromPageID")).equals(FromPageType.Notify))) {

                    // showDialog
                    if (mProductInvalidDialog != null) {
                        mProductInvalidDialog.dismiss();
                        mProductInvalidDialog = null;
                    }
                    if (mProductInvalidDialog == null) {
                        mProductInvalidDialog = new CustomDialog(TRNewAppDetailViewActivity.this);
                    }
                    mProductInvalidDialog.setCancelable(false);
                    mProductInvalidDialog.showAppDetailProductInvalidDialog(TRNewAppDetailViewActivity.this.getString(R.string.content_expired), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
//                            finishActivity();
                            finish();
                        }
                    });
                    if (commonAppDetailView != null) {
                        commonAppDetailView.jump2FeatureTab();
                    }
                    return;
                } else if(integer == Code.CODE_506_NEGATIVE && TRAnalyticsConstant.PAGE_SUNN.equals(mAppDetailModel.getParam("fromPageID"))){
                    //{"code":"-506","desc":"product is not exist."}
                    //跳去Google Play
                    String url = "market://details?id=" + mAppDetailModel.getParam("mPackageName");
                    DownloadDecorator.jumpToGooglePlay(TRNewAppDetailViewActivity.this, url, null);
                    finish();

                } else if(integer == Code.CODE_506_NEGATIVE && TRAnalyticsConstant.MARKET.equals(mAppDetailModel.getParam("fromPageID"))){
                    //跳去Google Play
                    skipGp();
                } else if (integer == Code.CODE_506_NEGATIVE && TRAnalyticsConstant.PM_SCAN_FAIL.equals(mAppDetailModel.getParam("fromPageID"))) {
                    //跳去Google Play
                    skipGp();
                } else if (integer == Code.CODE_506_NEGATIVE) {
                    if (commonAppDetailView != null) {
                        commonAppDetailView.jump2FeatureTab();
                    }
                }
            }
        });

        mAppDetailModel.getNetworkErrorLiveData().observe(this, new Observer<ANError>() {
            @Override
            public void onChanged(@Nullable ANError anError) {
                if(TRAnalyticsConstant.PAGE_SUNN.equals(mAppDetailModel.getParam("fromPageID"))){
                    mUINetworkErrorUtil.setVisibility(View.VISIBLE);
                    mUILoadingGifUtil.setVisibility(View.GONE);
                }
                if (detailDownloadHolder != null){
                    detailDownloadHolder.preHandleAutoDownload(mAppDetailModel.isAutoDownload(), mAppInfo, mBinding.statusPanel, mFrom);
                }
            }
        });

    }

    private void skipGp() {
        String pkg = (String )mAppDetailModel.getParam("mPackageName");
        String url = "market://details?id=" + pkg;
        DownloadDecorator.jumpToGooglePlay(TRNewAppDetailViewActivity.this, url, null);
        String soure = (String) mAppDetailModel.getParam("fromPageID");
        TRAnalysticsUtil.trackDetailJumpGp(pkg, soure);
        finish();
    }

    //findViews改造来的
    //private void initViewHolder(boolean tabVisible,boolean isRestoring) {
    private void initViewHolder( boolean restoreTipsVisible, int restoreTab ) {

        setupEdgeToEdgeInsets();
        //基础框架Holder
        commonAppDetailView = new CommonAppDetailView(this, mBinding, mAppDetailModel);
        commonAppDetailView.setData(mAppInfo, mPageParamInfo, mType, isCustomized, mFrom);
        commonAppDetailView.initHolder(restoreTipsVisible,restoreTab);

        //下载按钮Holder
        detailDownloadHolder = new AppDetailDownloadHolder(this, mAppDetailModel, commonAppDetailView, new AppDetailDownloadHolder.DownClicker() {
            @Override
            public void downLoadClick() {
                if (AppDetailUtils.isTakeDown(code, mAppInfo)) { //todo 封装到 detailDownloadHolder里面
                    mBinding.downMsgLayout.setVisibility(View.VISIBLE);
                    if (mAppInfo != null && !TextUtils.isEmpty(mAppInfo.itemCheckReason)){
                        mBinding.txtDownMsg.setText(mAppInfo.itemCheckReason);
                    } else {
                        mBinding.txtDownMsg.setText(R.string.no_related_resource_2);
                    }
                    return;
                } else {
                    mBinding.downMsgLayout.setVisibility(View.GONE);
                }

                if (detailDownloadHolder != null){
                    detailDownloadHolder.handDownload(mBinding.statusPanel, mAppInfo, mFrom);
                }

                boolean isChecked = mBinding.idAutoupdate.isChecked();
                boolean isAutoUpdateToggle = PalmPlayNetworkDownloadStateManager.isAutoUpdateAllow();
                if (!isAutoUpdateToggle && mBinding.idAutoupdate.getVisibility() == View.VISIBLE) {
                    PalmPlayNetworkDownloadStateManager.saveAutoUpdateType(isChecked ? Constant.AUTO_UPDATE_APP_WIFI : Constant.AUTO_UPDATE_APP_NOT_ALLOW);
                    mBinding.idAutoupdate.setVisibility(View.GONE);
                    TrackUtils.clickAutoupdate(isChecked, mFrom, mAppInfo);
                }
            }
        });
        detailDownloadHolder.initHolder();

        DownloadHandlerInf downloadHandlerInf = new DownloadHandlerInf() {//没处理好，需要重新处理
            @Override
            public void handDownload(View v, AppInfo mAppInfo, String mFrom) {
                if (detailDownloadHolder != null){
                    detailDownloadHolder.handDownload(null, mAppInfo, mFrom);
                }
            }
        };
        commonAppDetailView.initIMessager(downloadHandlerInf);

        //页面上半部分holder
        appDetailTopHolder = new AppDetailTopHolder(this, mAppDetailModel, commonAppDetailView, downloadHandlerInf, mValue);
        appDetailTopHolder.initHolder();

        appBarHolder = new AppDetailsAppBarHolder(this, mAppDetailModel, commonAppDetailView, mValue);
        appBarHolder.initHolder();
        initHotWordViewModel();

        detailsIconHolder = new AppDetailsIconHolder(this, mAppDetailModel, commonAppDetailView);
        detailsIconHolder.setUseSmallCache(AppDetailUtils.isUseSmallCache(mType));
        detailsIconHolder.initHolder();

        detailDownloadHolder.updateStatusChanged(mAppInfo);

        //updateDownloadView();

//        if (detailsIconHolder != null) {
//            detailsIconHolder.initIconShow();
//        }

        //tabs
//        setupPager();

        mBinding.executePendingBindings();
        mBinding.titleInclude.executePendingBindings();

        AppNetState.INSTANCE.getNetType().observe(this, netType -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            if (commonAppDetailView.currentPosition == 0 || commonAppDetailView.currentPosition == 1) {
                if (NetTypeKt.connected(netType)) {
                    onTipNetworkDialogDismiss();
                } else {
                    int orientation = getResources().getConfiguration().orientation;
                    boolean isLandscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
                    if (!isLandscape) {//横屏播放时，不弹出无网络弹框
                        onTipNetworkDialogShow();
                    }
                }
            }
        });
        appDetailTopHolder.onTopLayoutViewObserver();
    }

    private void requestDetailApiData() {
        mAppDetailModel.loadDetailApiData(getCommentAction(NetworkActions.ACTION_APP_DETAIL));
        if(TRAnalyticsConstant.PAGE_SUNN.equals(mAppDetailModel.getParam("fromPageID"))){
            mUILoadingGifUtil.setVisibility(View.VISIBLE);
        }
    }

    private void setupEdgeToEdgeInsets() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            TRStatusBarUtil.enableEdgeToEdge(this, null, null);
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                ViewGroup.LayoutParams lp = mBinding.layoutBottom.getLayoutParams();
                if (lp instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
                    mlp.bottomMargin = DisplayUtil.dip2px(this, 20);
                    mBinding.layoutBottom.setLayoutParams(mlp);
                }
            }
            ViewGroup.LayoutParams downLp = mBinding.downMsgLayout.getLayoutParams();
            if (downLp instanceof RelativeLayout.LayoutParams) {
                RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) downLp;
                rlp.bottomMargin = DisplayUtil.dip2px(this, 120);
                mBinding.downMsgLayout.setLayoutParams(rlp);
            }
            mBinding.appbarLayout.setFitsSystemWindows(false);
            ViewGroup coordinatorLayout = (ViewGroup) mBinding.appbarLayout.getParent();
            if (coordinatorLayout != null) {
                coordinatorLayout.setFitsSystemWindows(false);
            }
            ViewCompat.setOnApplyWindowInsetsListener(mBinding.appbarLayout, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(0, 0, 0, 0);
                if (mBinding.toolbar != null) {
                    mBinding.toolbar.setPadding(0, systemBars.top, 0, 0);
                    mBinding.titleInclude.newAppDetailTitle.setPadding(0, systemBars.top, 0, 0);
                    ViewGroup.LayoutParams lp = mBinding.toolbar.getLayoutParams();
                    if (lp != null) {
                        lp.height = com.afmobi.util.DisplayUtil.dip2px(this, 54) + systemBars.top;
                        mBinding.toolbar.setLayoutParams(lp);
                        mBinding.titleInclude.newAppDetailTitle.setLayoutParams(lp);
                    }
                }
                if (appBarHolder != null && appBarHolder.getStatusBar() != null) {
                    ViewGroup.LayoutParams lp = appBarHolder.getStatusBar().getLayoutParams();
                    if (lp != null && lp.height != systemBars.top) {
                        lp.height = systemBars.top;
                        appBarHolder.getStatusBar().setLayoutParams(lp);
                    }
                }
                return WindowInsetsCompat.CONSUMED;
            });
            ViewCompat.setOnApplyWindowInsetsListener(mBinding.layoutBottom, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                int originalPaddingTop = getResources().getDimensionPixelSize(R.dimen.dp_14);
                int extraBottomPadding = getResources().getDimensionPixelSize(R.dimen.dp_30);
                if (mBinding.tvQuickOpenDesc.getVisibility() == View.VISIBLE) {
                    extraBottomPadding = getResources().getDimensionPixelSize(R.dimen.dp_20);
                }
                int bottomPadding = systemBars.bottom + extraBottomPadding;
                v.setPadding(
                        v.getPaddingLeft(),
                        originalPaddingTop,
                        v.getPaddingRight(),
                        bottomPadding
                );
                return WindowInsetsCompat.CONSUMED;
            });
            mBinding.collapsingToolbar.setNestedScrollingEnabled(false);
            mBinding.viewpager.post(() -> {
                View child = mBinding.viewpager.getChildAt(0);
                if (child instanceof RecyclerView) {
                    ((RecyclerView) child).setOverScrollMode(View.OVER_SCROLL_NEVER);
                }
            });
        }
    }

    private void refreshUI() {

        onRenderStartTime = System.currentTimeMillis();
        if (BuildConfig.DEBUG) {
            LogUtils.d(LogUtils.TAG_APM, "trackAPMPageRenderStart: value = " + mValue + (System.currentTimeMillis() - onCreateTime));
        }
        TRApmAnalysticsUtil.trackAPMPageRenderStart(mValue,mFrom);
        addRenderListener();
        if (appDetailTopHolder != null) {
            appDetailTopHolder.onAppDetailHeaderLayout();
        }

        updateDetailInfo();//这里也会修改状态
        mAppDetailModel.trackEvent(3, mAppInfo);
        DetailResponseData response = mAppDetailModel.getDetailResponseLiveData().getValue();

        mAppInfo.detailSource = buildDisplayList(response, mAppInfo, isCustomized);
        mAppDetailModel.setParam("_detailSource", mAppInfo.detailSource);//在 onAppInfoChanged 需要修改 detailSource
        if (commonAppDetailView != null) {//todo 这个地方没有处理好,需要改成lievdata
            commonAppDetailView.setData(mAppInfo, mPageParamInfo, mType, isCustomized, mFrom);
        }

        LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity refreshUI :" + (response == null? " null" : response.findFlag ));

        if (commonAppDetailView != null) {
            List<DetailComponentItemData> componentList = commonAppDetailView.onAppInfoChanged(response, true);

            if (BuildConfig.DEBUG) {
                LogUtils.d("_dataShow", "detail - TRNewAppDetailVewActivity refreshUI :" + (componentList == null? " null" : componentList.size()));
            }
        }

        if (mAppInfo != null && !mAppInfo.itemCheckFlag) {
            TRAnalysticsUtil.trackNoProductWithPageInfo(mAppInfo.itemID, mAppInfo.packageName,getValue());
            if (AppDetailUtils.isTakeDown(code, mAppInfo)) {
                CommonUtils.setDownloadButtonGray(mBinding.statusPanel,getResources().getDrawable(R.drawable.selector_common_gray_btn_bg));
                String fromPageID = (String) mAppDetailModel.getParam("fromPageID");
                if (TRAnalyticsConstant.PM_SCAN_FAIL.equals(fromPageID) || TRAnalyticsConstant.MARKET.equals(fromPageID)) {
                    skipGp();
                    return;
                }
            }
            if (commonAppDetailView != null) {
                commonAppDetailView.jump2FeatureTab();
            }
        }
        detailDownloadHolder.checkButton(mAppInfo, code);
        AppDetailUtils.checkFdr(mFrom);
        showPsFloatView();
    }

    /**
     * 展示悬浮球
     */
    private void showBackFloatBallIfNeeded() {
        String from = resolveBackFloatBallFrom();
        if (from == null) return;
        if (mBackFloatBallView == null) {
            mBackFloatBallView = new BackFloatBallView(this);
        }
        mBackFloatBallView.show(this, from);
    }

    /**
     * 返回需要展示 BackFloatBallView 时对应的 from 值，返回 null 表示不展示。
     */
    private String resolveBackFloatBallFrom() {
        if (getIntent() != null && getIntent().getBooleanExtra(Constant.KEY_FROM_HALF_DETAIL, false)) {
            return Constant.KEY_FROM_HALF_DETAIL;
        }
        if (mAppDetailModel != null) {
            Object sourceObj = mAppDetailModel.getParam("_source");
            if (sourceObj instanceof String && Constant.SOURCE_APP_UPDATE.equals(sourceObj)) {
                return Constant.SOURCE_APP_UPDATE;
            }
        }
        return null;
    }

    private void showPsFloatView() {
        String fromPageID = (String) mAppDetailModel.getParam("fromPageID");
        backFloatball = (boolean) mAppDetailModel.getParam("backFloatball");
        String packageName = (String) mAppDetailModel.getParam("mPackageName");
        if (backFloatball && ((TRAnalyticsConstant.UPDATESDK.equals(fromPageID))||TRAnalyticsConstant.PMUPDATE.equals(fromPageID))) {
            if(ConfigManager.canShowFloatballCloudControl(TRAnalyticsConstant.FOLLATBALL_APPDETAIL,fromPageID,packageName)){
                if(!MMKVUtils.getMMKV().getBoolean(Constant.KV_DEEPLINK_FLOATBALL_BACKGROUND,false)) {
                    //显示悬浮球
                    PsFloatBallView.getInstance(getApplicationContext()).showFloatView(packageName, mAppInfo.itemID, fromPageID, mValue);
                }
            }
        }
    }

    /**
     * 增加渲染监听，收到回调后，移除listener，并埋点
     */
    private void addRenderListener() {
        mBinding.viewpager.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {

            @Override
            public boolean onPreDraw() {
                mBinding.viewpager.getViewTreeObserver().removeOnPreDrawListener(this);

                TRApmAnalysticsUtil.trackAPMPageRenderEnd(mValue,mFrom,isHaveCache ? 1 : 0,
                        System.currentTimeMillis() - onRenderStartTime ,System.currentTimeMillis()-onCreateTime);
                LogUtils.d(LogUtils.TAG_APM, "trackAPMPageRenderEnd: value = " + mValue + (System.currentTimeMillis() - onCreateTime));
                return false;
            }
        });
    }

    private void updateDetailInfo() {
        mAppDetailModel.setParam("mItemID", mAppInfo.itemID);

        setAppInfo();

        if (appBarHolder != null) {
            appBarHolder.initTitleName();
        }

        if (detailDownloadHolder != null) {
            detailDownloadHolder.updateStatusChanged(mAppInfo);
        }
    }

    public boolean isOfferStyle() {
        return isCustomized;
    }

    private String getCommentAction(String baseAction) {
        return (TRStringUtil.isBlank(baseAction) ? "" : baseAction) + (TRStringUtil.isBlank((String) mAppDetailModel.getParam("mItemID")) ? "" : (String) mAppDetailModel.getParam("mItemID"));
    }

    private void setAppInfo() {
        if (mAppInfo != null) {
            boolean isAutoUpdate = PalmPlayNetworkDownloadStateManager.isAutoUpdateAllow();
            boolean isQuickOpen = mAppInfo != null && PreInstallManager.INSTANCE.isQuickOpenApp(mAppInfo.itemID, mAppInfo.version);
            int status = mAppInfo.observerStatus;
            if(!isAutoUpdate &&
                    (status < FileDownloadInfo.STATUS_DOWNLOADED || status == FileDownloadInfo.STATUS_APP_UPDATE || status == FileDownloadInfo.STATUS_NETWORK_ERROR)) {
                mBinding.idAutoupdate.setVisibility(View.VISIBLE);
                mBinding.tvQuickOpenDesc.setVisibility(View.GONE);
                mBinding.idAutoupdate.setChecked(true);
                mBinding.idAutoupdate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        TrackUtils.clickAutoupdate(isChecked, mFrom, mAppInfo);
                    }
                });
                TrackUtils.exposureAutoupdate(mFrom, mAppInfo);
            } else {
                mBinding.idAutoupdate.setVisibility(View.GONE);
                if(isQuickOpen) {
                    if(commonAppDetailView != null && commonAppDetailView.isCustomizedStyle()) {
                        mBinding.tvQuickOpenDesc.setTextColor(Color.WHITE);
                    } else {
                        mBinding.tvQuickOpenDesc.setTextColor(ContextCompat.getColor(this, R.color.color_66000000));
                    }
                    mBinding.tvQuickOpenDesc.setVisibility(View.VISIBLE);
                } else {
                    mBinding.tvQuickOpenDesc.setVisibility(View.GONE);
                }
            }
            ViewCompat.requestApplyInsets(mBinding.layoutBottom);
        }

        if (detailsIconHolder != null) {
            detailsIconHolder.initIconShow();
        }
        mBinding.executePendingBindings();
    }

    //获取游戏详情页APK的包名
    public String getPkgName(){
        return mAppInfo != null ? mAppInfo.packageName : "";
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent!=null) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                mAppDetailModel.handBundleData(bundle, mPageParamInfo);
                mFrom = bundle.getString("value", "");
                mType = bundle.getString("type");
                if (commonAppDetailView != null && mAppInfo != null){
                    commonAppDetailView.setData(mAppInfo, mPageParamInfo, mType, isCustomized, mFrom);
                }
            }
            if (!isFinishing() && !isDestroyed()){
                if (commonAppDetailView != null){
                    commonAppDetailView.setTab();
                }
            }
            detailDownloadHolder.checkDownInfo(mAppInfo, code);
        }
    }

    @Override
    public int getBindingVariable() {
        return BR.appDetailViewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.z_activity_new_app_detail_layout;
    }

    @Override
    public TRNewAppViewModel getViewModel() {
        mAppDetailModel = new ViewModelProvider(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(TRNewAppViewModel.class);
        getLifecycle().addObserver(mAppDetailModel);
        return mAppDetailModel;
    }

    @Override
    protected void onResume() {
        super.onResume();
        PsVaManager.detailActivityIsVisible = true;
        if (detailDownloadHolder != null){
            detailDownloadHolder.setUpdatedAppCount();
        }
        mAppDetailModel.setBooleanParam("mRequestDSP", false);
        if (isPermissionHintDialogShowed) {
            if (CommonUtils.hasStoragePermissions()) {
                isPermissionHintDialogShowed = false;
                ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp();
            }
        }
        showPsFloatView();
        showBackFloatBallIfNeeded();
        if (hotWordViewModel != null) {
            hotWordViewModel.startCarousel(SearchBarPosition.DETAIL);
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        onTipNetworkDialogDismiss();
        PsVaManager.detailActivityIsVisible = false;
        PsFloatBallView.getInstance(getAppInstance()).hideFloatView();
        if (hotWordViewModel != null) {
            hotWordViewModel.stopCarousel(SearchBarPosition.DETAIL);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mBackFloatBallView != null) {
            mBackFloatBallView.destroy();
            mBackFloatBallView = null;
        }
        if (detailDownloadHolder != null){
            detailDownloadHolder.onDestroy();
        }

        AppDetailAnimationUtil.getInstance().releaseAnimation(false);

        if ((Boolean) mAppDetailModel.getParam("mRequestDSP")) {
            AsyncHttpRequestUtils.cancel("DSP");
        }
        AsyncHttpRequestUtils.cancel(getCommentAction(NetworkActions.ACTION_APP_DETAIL));
        if (mUILoadingGifUtil != null) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }
        if (mAppDetailModel != null) {
            mAppDetailModel.destoryHisavanaSdk();
        }
        if(mHandle != null) {
            mHandle.removeCallbacksAndMessages(null);
        }

        if (backFloatball) {
            PsFloatBallView.getInstance(getAppInstance()).hideFloatView();
            PsFloatBallView.getInstance(getAppInstance()).removeFloatView();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (commonAppDetailView != null && commonAppDetailView.onKeyDown()) { //全屏播放视频时返回只退出全屏播放
                return true;
            }
            finish();
        }

        TrackUtils.onKeyDown(mValue, mFrom, mAppInfo);
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        super.onEventMainThread(mEventMainThreadEntity);
        if (mEventMainThreadEntity.getAction().equals(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS)) {
            InstalledAppInfo appInfo = (InstalledAppInfo) mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DATA);
            FileDownloadInfo downloadInfo = (FileDownloadInfo) mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DOWNLOADINFO);
            boolean show = showInstalledCompleteWindow(this, appInfo, downloadInfo);
            if (show) {
                //隐藏无网络提示框
                onTipNetworkDialogDismiss();
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_REFRESH_TAB_RED_POINT)) { //刷新角标
            if (detailDownloadHolder != null){
                detailDownloadHolder.setUpdatedAppCount();
            }
        } else if (TextUtils.equals(PsVaManager.ACTION_GAME_LAUNCH, mEventMainThreadEntity.getAction())) {
            String pkgName = (String) mEventMainThreadEntity.get(PsVaManager.KEY_PKG_NAME);
            if (!TextUtils.isEmpty(pkgName) && mAppInfo != null) {
                if (pkgName.equals(mAppInfo.packageName)) {
                    updateVaUIOnResume();
                }
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), PsVaManager.ACTION_VA_GAME_INSTALL)) {
            String iconUrl = (String) mEventMainThreadEntity.get(PsVaManager.KEY_ICON_URL);
            if (!TextUtils.isEmpty(iconUrl)) {
                mBinding.titleInclude.gameDetailVaGame.startAnim(iconUrl);
            }
        }
    }

    private void updateVaUIOnResume() {
        getLifecycle().addObserver(new LifecycleEventObserver() {
            @Override
            public void onStateChanged(@NonNull LifecycleOwner source, @NonNull Lifecycle.Event event) {
                if (event == Lifecycle.Event.ON_RESUME) {
                    getLifecycle().removeObserver(this);
                    if (detailDownloadHolder != null) {
                        detailDownloadHolder.updateVaUI();
                    }
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (!TRPermissionUtil.isGranted(grantResults, permissions)) {
            boolean isTip = ActivityCompat.shouldShowRequestPermissionRationale(this, permissions.length > 0 ? permissions[0] : "");
            LogUtils.d("obbPermission", "onRequestPermissionsResult: refuse " + isTip);
            TRAnalysticsUtil.trackObbPermissionClick(TRAnalyticsConstant.OBB_PERMISSION_REFUSE,getValue());
            if (isTip) {//表明用户没有彻底禁止弹出权限请求
                // 用户选择了禁止权限

            } else {//表明用户已经彻底禁止弹出权限请求
                isPermissionHintDialogShowed = true;
                PermissonsHintDialog.getPermissionHintDlg(this, PermissionsReqActivity.SYS_SETTING_DETAILS_REQUEST_CODE, permissions.length > 0 ? permissions[0] : "");
            }
        } else {
            isPermissionHintDialogShowed = false;
            LogUtils.d("obbPermission", "onRequestPermissionsResult: agree");
            TRAnalysticsUtil.trackObbPermissionClick(TRAnalyticsConstant.OBB_PERMISSION_AGREE,getValue());
            ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp();
        }
    }

    @Override
    public String getValue() {
        return TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, "","","");
    }
}

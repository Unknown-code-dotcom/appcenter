/**
 * @author liupengbing
 */
package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.configs.v6_3.FeaturedType;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.manager.UpdateControlManager;
import com.afmobi.palmplay.model.FeatureTabInfo;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.HomeBannerConfig;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.optimize.HomeTabDefault;
import com.afmobi.util.Constant;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppCacheUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.launcherlib.config.Constants;
import com.transsnet.store.BuildConfig;

import java.util.List;

public class HomeBannerConfigManager {
    private static final String TAG = "HomeBannerCache";
    private static final String LAST_REQUEST_API_KEY = "last_request_home_banner_config_api_key";
    private final static String HOME_BANNER_CONFIG_FILE_NAME = "homeBannerConfigFile";
    private final static String KEY_HOMEBANNER_DATA_MARK = "key_homebanner_data_mark";
    private static final long DEFAULT_REQUEST_INTERVAL = 4 * 60 * 60 * 1000L;
    private long mLastReqApiTime = 0;
    private HomeBannerConfig mHomeBannerConfig;
    private static HomeBannerConfigManager sInstance;

    public static HomeBannerConfigManager getInstance() {
        if (sInstance == null) {
            synchronized (HomeBannerConfigManager.class) {
                sInstance = new HomeBannerConfigManager();
            }
        }
        return sInstance;
    }

    private HomeBannerConfigManager() {
        loadFromCache();
    }
    public boolean requestHomeBannerList(boolean needUpdate, final int reqType) {
        if (mLastReqApiTime == 0) {
            mLastReqApiTime = SPManager.getLong(LAST_REQUEST_API_KEY, 0);
        }
        long requestInterval = 0;

        if (mHomeBannerConfig != null) {
            if (needUpdate || mHomeBannerConfig.bannerList == null || mHomeBannerConfig.bannerList.isEmpty()) {
                requestInterval = mHomeBannerConfig.loadTimeInterval * Constants.INTERVAL_TIME_HOUR_UNIT;
            } else {
                requestInterval = mHomeBannerConfig.reloadTimeInterval * Constants.INTERVAL_TIME_HOUR_UNIT;
            }
        } else {
            requestInterval = DEFAULT_REQUEST_INTERVAL;
        }

        if (requestInterval <= 0) {
            requestInterval = DEFAULT_REQUEST_INTERVAL;
        }
        long diffTime = System.currentTimeMillis() - mLastReqApiTime;
        if (diffTime < requestInterval) {
            LogUtils.d(TAG, "requestHomeBannerConfig < interval ");
            ApmAppCacheUtil.getInstance().startCollectCacheTime(ApmAppCacheUtil.homeBannerList_t, diffTime);
            return false;
        }

        mLastReqApiTime = System.currentTimeMillis();
        SPManager.putLong(LAST_REQUEST_API_KEY, mLastReqApiTime);
        if (needUpdate) {
            NetworkClient.requestHomeBannerConfig(new AbsRequestListener<GenericResponseInfo<HomeBannerConfig>>() {
                @Override
                public void onResponse(GenericResponseInfo<HomeBannerConfig> response) {
                    super.onResponse(response);
                    LogUtils.d(TAG, "onResponse: mHomeBannerConfig : " + response);
                    int size = 0;
                    long costTime = 0;
                    String result = "E";

                    if (response != null && response.isSuccess()) {
                        result = "S";
                        mHomeBannerConfig= response.getData();
                        int status = 0;
                        String dataMark = "";
                        if(mHomeBannerConfig!=null) {
                            status = 1;
                            dataMark = mHomeBannerConfig.dataMark+"";
                        }
                        TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,status, dataMark,
                                com.afmobi.util.Constants.SCENE_HONE_BANNER_KEY,UpdateControlManager.getAbTestStatus(),-1,""+reqType);
                        LogUtils.d(TAG, "onResponse: mHomeBannerConfig : " + mHomeBannerConfig);
                        long startTime = System.currentTimeMillis();
                        saveHomeBannerConfig(mHomeBannerConfig);
                        replaceHomeBannerFromCache(mHomeBannerConfig);
                        costTime = System.currentTimeMillis() - startTime;
                    }
                    ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.homeBannerList_t,
                            diffTime, mLastReqApiTime, result, size, costTime);
                }

                @Override
                public void onError(ANError anError) {
                    super.onError(anError);
                    LogUtils.d(TAG, "onResponse: onError : " + anError.toString());
                    String errorMsg = "";
                    if (anError != null) {
                        if (TextUtils.isEmpty(anError.getMessage())) {
                            errorMsg = anError.getErrorDetail() + anError.getErrorCode();
                        } else {
                            errorMsg = anError.getMessage() + anError.getErrorCode();
                        }
                    }
                    TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,0, "",
                            com.afmobi.util.Constants.SCENE_HONE_BANNER_KEY,UpdateControlManager.getAbTestStatus(),-1,errorMsg+"_"+reqType);

                    ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.homeBannerList_t,
                            diffTime, mLastReqApiTime, errorMsg);
                }
            }, "requestHomeBannerConfig");
            return true;
        }
        return false;
    }

    private void replaceHomeBannerFromCache(HomeBannerConfig mHomeBannerConfig) {
        if (mHomeBannerConfig != null && mHomeBannerConfig.bannerList != null && mHomeBannerConfig.bannerList.size() > 0) {
            String mTabId = getTabId();
            FeaturedModel mFeaturedModel = TRHomeUtil.loadFromCache(FeaturedType.HOME, mTabId);
            if (mFeaturedModel != null) {
                mFeaturedModel.bannerList = mHomeBannerConfig.bannerList;
                TRHomeUtil.saveToCache(mFeaturedModel, FeaturedType.HOME, mTabId);
            }
        }
    }

    public static long getHomeBannerConfigDataMark() {
        return SPManager.getLong(KEY_HOMEBANNER_DATA_MARK,0);
    }
    private String getTabId() {
        String mTabId = null;
        List<FeatureTabInfo> list = NavTabManager.getInstance().getFeatureTabByKey(FeaturedType.HOME);
        if (list == null || list.size() <= 0) {
            //startup接口下发tab为空时，获取预置asset下的tab数据
            list = HomeTabDefault.INSTANCE.initDefaultTab();
        }
        FeatureTabInfo info = null;
        if (list != null && list.size() > 0) {
            for (FeatureTabInfo featureTabInfo : list) {
                if (featureTabInfo.isDefault() && featureTabInfo.getTabType().equals(Constant.TAB_TYPE_FEATURE)) {
                    info = featureTabInfo;
                    break;
                }
            }
        }
        mTabId = info != null ? String.valueOf(info.getId()) : "";

        return mTabId;

    }
    private void loadFromCache() {
        try {
            JsonElement jsonObject = FilePathManager.fileToJson(HOME_BANNER_CONFIG_FILE_NAME);
            if (jsonObject != null) {
                mHomeBannerConfig = new Gson().fromJson(jsonObject, HomeBannerConfig.class);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    public void saveHomeBannerConfig(HomeBannerConfig config) {
        String data = "";
        if (config != null) {
            try {
                data = new Gson().toJson(config);
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            SPManager.putLong(KEY_HOMEBANNER_DATA_MARK,config.dataMark);
        }
        if (!TextUtils.isEmpty(data)) {
            FilePathManager.jsonToFile(data, HOME_BANNER_CONFIG_FILE_NAME);
        }
    }
}


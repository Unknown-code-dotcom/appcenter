package com.afmobi.palmplay.activate.handler

import android.app.Activity
import android.content.DialogInterface
import android.view.View
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.TRIntantGameExecutor
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.dialog.TRDialogUtil
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager

class TRIntantGameHandler(
    executor: TRIntantGameExecutor?,
    sceneName: String,
    priority: TRPriority,
    popupType: TRPopupType
) :
    TRChainHandler(sceneName, priority, popupType) {

    private var mExecutor: TRBaseExecutor<*>? = executor
    var clickListener: View.OnClickListener? = null
    var dismissListener: DialogInterface.OnDismissListener? = null
    override fun canShow(fromType: String?): Boolean {
        if(TRDialogUtil.hasDialogShowing()) {
            return false
        }
        return mExecutor?.isCanShow(fromType) ?: false
    }
    override fun show(fromType: String?, activity: Activity?, clickListener: View.OnClickListener, dismissListener: DialogInterface.OnDismissListener): Boolean {
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if(!canShow(fromType)) {
            return false
        }

        return mExecutor?.show(fromType, activity, clickListener, dismissListener) ?: false
    }


    override fun showNext(fromType: String?): Boolean {
        if(canShow(fromType)) {
            if(AtyManager.getAtyManager().currentActivity != curActivity?.get()) {
                return false
            }
            return mExecutor?.show(
                fromType,
                curActivity?.get(),
                clickListener,
                dismissListener
            ) == true
        }
        return false
    }

    override fun dismiss(): Boolean {
        return mExecutor?.dismiss() ?: false
    }

    override fun showing(): Boolean {
        return mExecutor?.isShowing ?: false
    }

}

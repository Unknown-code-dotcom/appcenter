package com.afmobi.palmplay.cloudfolder.recently.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PalmInstalledAppEntity::class], version = 3, exportSchema = false)
abstract class PalmInstalledAppDatabase : RoomDatabase() {

    abstract fun installedAppDao(): PalmInstalledAppDao

    companion object {
        private const val DB_NAME = "PalmInstalledApp.db"

        @Volatile
        private var INSTANCE: PalmInstalledAppDatabase? = null

        fun getInstance(context: Context): PalmInstalledAppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PalmInstalledAppDatabase::class.java,
                    DB_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

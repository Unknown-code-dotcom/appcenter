package com.afmobi.palmplay.appmanage.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.apk.ApkInstallUtils;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter;
import com.afmobi.palmplay.appmanage.FileManageDownloadAdapterItem;
import com.afmobi.palmplay.appmanage.holder.ChildDownloadingRecyclerViewHolder;
import com.afmobi.palmplay.appmanage.holder.ChildPreOrderedRecyclerViewHolder;
import com.afmobi.palmplay.appmanage.holder.DownloadContentEmptyViewHolder;
import com.afmobi.palmplay.appmanage.holder.DownloadedItemViewHolder;
import com.afmobi.palmplay.appmanage.holder.DownloadingTitleViewHolder;
import com.afmobi.palmplay.appmanage.holder.InstalledItemViewHolder;
import com.afmobi.palmplay.appmanage.holder.InstalledSeeMoreViewHolder;
import com.afmobi.palmplay.appmanage.holder.InstalledTitleViewHolder;
import com.afmobi.palmplay.appmanage.holder.PreOrderedTitleViewHolder;
import com.afmobi.palmplay.appmanage.holder.RecommendItemViewHolder;
import com.afmobi.palmplay.appmanage.holder.RecommendTitleViewHolder;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.download.DownloadHandler;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.InterfaceBatchStatusChange;
import com.afmobi.palmplay.download.InterfaceBatchStatusWithImageUrlChange;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.keeptojosn.ClientOperationRecordNode;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadExtraInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.model.v6_3.RankModel;
import com.afmobi.palmplay.service.dispatch.PalmstoreDownloadHandler;
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.NotificationUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutManageDownloadingListItemBinding;
import com.transsnet.store.databinding.LayoutManagePreorderedListItemBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import de.greenrobot.event.EventBus;

/**
 * 文件管理页Download模块 的adapter
 * Created by xiangfei.wei on 2018/12/14.
 */
public class FileManageDownloadAdapter extends PalmBaseDownloadRecyclerViewAdapter {
    private String TAG = FileManageDownloadAdapter.class.getSimpleName();
    private PageParamInfo mPageParamInfo;
    private List<FileManageDownloadAdapterItem> mDatas;
    private Context mContext;
    private RecyclerView recyclerView;
    private TRLinearLayoutManager mLinearLayoutManager;
    private String mCurrentItemID = null;
    private MutableLiveData<String> callRefresh;
    public static String REFRESH_NOW = "refreshNow";//通知刷新
    /**
     * 是否点击过install all 按钮
     */
    private boolean installAllClicked;

    private MutableLiveData<Boolean> isNoResListFold;

    private boolean checked;

    public FileManageDownloadAdapter(Context context, RecyclerView recyclerView) {
        super();
        mContext = context;
        this.recyclerView = recyclerView;

        mLinearLayoutManager = new TRLinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        mLinearLayoutManager.setSmoothScrollbarEnabled(true);
        mLinearLayoutManager.setAutoMeasureEnabled(true);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(mLinearLayoutManager);
        recyclerView.setAdapter(this);
        RecyclerView.ItemAnimator itemAnimator = recyclerView.getItemAnimator();
        if (itemAnimator instanceof SimpleItemAnimator) {
            ((SimpleItemAnimator) itemAnimator).setSupportsChangeAnimations(false);//解决刷新单个item时，该item闪烁的问题
        }
        mDatas = new ArrayList<>();
    }

    public void setPageParamInfo(PageParamInfo pageParamInfo) {
        this.mPageParamInfo = pageParamInfo;
    }

    public void setCallRefresh(MutableLiveData callRefresh) {
        this.callRefresh = callRefresh;
    }

    public boolean isInstallAllClicked() {
        return installAllClicked;
    }

    public void setInstallAllClicked(boolean installAllClicked) {
        this.installAllClicked = installAllClicked;
    }


    private int getPosition(FileDownloadInfo downloadInfo) {
        if (mDatas == null || mDatas.size() <= 0 || downloadInfo == null) {
            return -1;
        }

        int pos = -1;
        FileManageDownloadAdapterItem info;
        for (int i = 0; i < mDatas.size(); i++) {
            info = mDatas.get(i);
            if (info != null && info.fileDownloadInfo != null && info.fileDownloadInfo.packageName != null && TextUtils.equals(info.fileDownloadInfo.packageName, downloadInfo.packageName)) {
                if(downloadInfo.extraInfo != null && !downloadInfo.extraInfo.itemCheckFlag && info.fileDownloadInfo != null) {
                    if (info.fileDownloadInfo.extraInfo == null) {
                        info.fileDownloadInfo.extraInfo = new FileDownloadExtraInfo("","");
                    }
                    info.fileDownloadInfo.extraInfo.itemCheckFlag = false;
                }
                pos = i;
                break;
            }
        }
        return pos;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onCreateView() {
        super.onCreateView();
    }

    @Override
    public void onResume() {
        super.onResume();
        //数据过滤得耗时操作放在线程里避免anr（monkey复现了anr）
//        TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new TRRunnable(new TRRunnableInterface() {
//            @Override
//            public void doRun() {
//
//            }
//        }));

        // 修改某些手机(CG6)在非下载管理页增加下载任务，进入下载管理，重复几次之后，出现下载列表延迟几秒展示问题
        handleInstallingListInfo(false);
        handleInstalledListInfo(false);
        //把刷新放在外层，理由两个。1.子线程不能刷新，2.刷新的操作必须在数据set完之后才能进行，否则时机会错乱
        if (callRefresh != null) {
            callRefresh.postValue(REFRESH_NOW);
        }
        if (!checked) {
            // 首次进入页面检查无下载中任务，无安装完成任务，有不可下载任务时，默认展开不可下载列表
            checked = true;
            if (isNoResListFold != null) {
                if (mDatas == null || mDatas.isEmpty()) {
                    isNoResListFold.postValue(Boolean.FALSE);
                } else {
                    isNoResListFold.postValue(Boolean.TRUE);
                }
            }
        }

    }

    /**
     * 处理installing列表的数据，包含下载中和下载成功未安装；
     *
     * @param notifyDataSetChanged
     */
    public void handleInstallingListInfo(boolean notifyDataSetChanged) {
        if (mDatas == null) {
            return;
        }

        List<FileDownloadInfo> installingList = DownloadManager.getInstance().getShadowDownloadingInfoList();
        List<FileDownloadInfo> downloadingList = new ArrayList<>();
        // Installing区域过滤不可下载应用，不可下载应用展示在Unavailable区域
        for (FileDownloadInfo info: installingList){
            if (info.extraInfo != null && !info.extraInfo.itemCheckFlag && !info.extraInfo.canRetry) {
                // ignore
                LogUtils.d("DownloadNoRes",info.packageName);
            } else {
                downloadingList.add(info);
            }
        }
        List<FileDownloadInfo> downloadedList = getUnInstallUnActiveList();
        //过滤掉再次安装失败的数据
        Iterator<FileDownloadInfo> iterator1 = downloadedList.iterator();
        FileDownloadInfo item1;
        while (iterator1.hasNext()) {
            item1 = iterator1.next();
            if (item1 != null && item1.extraInfo != null && item1.extraInfo.isRetryInstallFail) {
                iterator1.remove();
            }
        }

        //每次更新数据前，先把旧的数据整体移除掉，再把新的数据整体添加进adapter的列表；

        boolean isFind = false;
        Iterator<FileManageDownloadAdapterItem> iterator = mDatas.iterator();
        FileManageDownloadAdapterItem item;
        while (iterator.hasNext()) {
            item = iterator.next();
            if (item != null && item.itemType == FileManageDownloadAdapterItem.INSTALLING_TITLE) {
                isFind = true;
                iterator.remove();
                break;
            }
        }

        item = null;
        if (isFind) {
            Iterator<FileManageDownloadAdapterItem> it = mDatas.iterator();
            while (it.hasNext()) {
                item = it.next();
                //installing模块包含downloading和downloaded；
                if (item != null && (item.itemType == FileManageDownloadAdapterItem.DOWNLOADING_ITEM || item.itemType == FileManageDownloadAdapterItem.DOWNLOADED_ITEM)) {
                    it.remove();
                }
            }
        }

        insertInstallingListData(downloadingList, downloadedList);

        insertDownloadContentEmptyTipsData();

        if (notifyDataSetChanged) {
            notifyDataSetChanged();
        }

    }

    private void insertInstallingListData(List<FileDownloadInfo> downloadingList, List<FileDownloadInfo> downloadedList) {
        if ((downloadingList != null && downloadingList.size() > 0) || (downloadedList != null && downloadedList.size() > 0)) {
            removeNoDownloadTips();
        }

        int downloadingSize = 0;
        int downloadedSize = 0;
        FileManageDownloadAdapterItem item;
        List<FileDownloadInfo> nonVadownloadedList = new ArrayList<>();
        List<FileDownloadInfo> installFailedList = new ArrayList<>();
        //downloaded item
        if (downloadedList != null) {
            for (int i = 0; i < downloadedList.size(); i++) {
                FileDownloadInfo fileDownloadInfo = downloadedList.get(i);
                if (!fileDownloadInfo.extraInfo.isVaGame) {
                    if (fileDownloadInfo.extraInfo.isInstallFail) {
                        installFailedList.add(fileDownloadInfo);
                    } else {
                        nonVadownloadedList.add(fileDownloadInfo);
                    }
                }
            }
            // Then add other downloaded items
            for (FileDownloadInfo fileDownloadInfo : nonVadownloadedList) {
                item = new FileManageDownloadAdapterItem();
                item.itemType = FileManageDownloadAdapterItem.DOWNLOADED_ITEM;
                item.fileDownloadInfo = fileDownloadInfo;
                mDatas.add(0, item);
            }

            downloadedSize = installFailedList.size() + nonVadownloadedList.size();
        }

        List<FileDownloadInfo> nonVaDownloadingList =  new ArrayList<>();
        //downloading item
        if (downloadingList != null) {
            for (int i = downloadingList.size()-1; i >= 0; i--) {
                FileDownloadInfo fileDownloadInfo = downloadingList.get(i);
                if (!fileDownloadInfo.extraInfo.isVaGame) {
                    nonVaDownloadingList.add(fileDownloadInfo);

                    item = new FileManageDownloadAdapterItem();
                    item.itemType = FileManageDownloadAdapterItem.DOWNLOADING_ITEM;
                    item.fileDownloadInfo = fileDownloadInfo;
                    item.placementId = String.valueOf(i);
                /*if (isAdInfoExist()) {
                    mDatas.add(1, item);
                } else {
                    mDatas.add(0, item);
                }*/

                    mDatas.add(0, item);
                }
            }
            downloadingSize = nonVaDownloadingList.size();
        }
        // Add install failed items first
        if (!installFailedList.isEmpty()) {
            for (FileDownloadInfo fileDownloadInfo : installFailedList) {
                item = new FileManageDownloadAdapterItem();
                item.itemType = FileManageDownloadAdapterItem.DOWNLOADED_ITEM;
                item.fileDownloadInfo = fileDownloadInfo;
                mDatas.add(0, item);
            }
        }

        //插入Installing模块的title信息
        if( downloadingSize + downloadedSize > 0) {
            item = new FileManageDownloadAdapterItem();
            item.itemType = FileManageDownloadAdapterItem.INSTALLING_TITLE;
            item.downloadingCount = downloadingSize + downloadedSize;
            if (isExistDownloading(downloadingList)) {
                item.startAllStatus = false;
            } else {
                item.startAllStatus = true;
            }
            /*if (isAdInfoExist()) {
                mDatas.add(1, item);
            } else {
                mDatas.add(0, item);
            }*/

            mDatas.add(0, item);
        }

    }

    /**
     * 处理安装完成的数据
     *
     * @param notifyDataSetChanged
     */
    private void handleInstalledListInfo(boolean notifyDataSetChanged) {
        if (mDatas == null) {
            return;
        }
        List<FileDownloadInfo> installedList = DownloadManager.getInstance().getInstalledInfoList();

        //每次更新数据前，先把旧的数据整体移除掉，再把新的数据整体添加进adapter的列表；
        //找到installed title类型，移除
        boolean isFind = false;
        Iterator<FileManageDownloadAdapterItem> iterator = mDatas.iterator();
        FileManageDownloadAdapterItem item;
        while (iterator.hasNext()) {
            item = iterator.next();
            if (item != null && item.itemType == FileManageDownloadAdapterItem.INSTALLED_TITLE) {
                isFind = true;
                iterator.remove();
                break;
            }
        }

        //根据installed title，移除installed；
        item = null;
        if (isFind) {
            Iterator<FileManageDownloadAdapterItem> it = mDatas.iterator();
            while (it.hasNext()) {
                item = it.next();
                if (item != null && (item.itemType == FileManageDownloadAdapterItem.INSTALLED_ITEM || item.itemType == FileManageDownloadAdapterItem.INSTALLED_MORE_APPS)) {
                    it.remove();
                }
            }
        }

        //插入新数据;
        insertInstalledListData(installedList);

        //是否需要插入 空内容提示；
        insertDownloadContentEmptyTipsData();

        if (notifyDataSetChanged) {
            notifyDataSetChanged();
        }
    }

    private void insertInstalledListData(List<FileDownloadInfo> installedList) {

        if (installedList != null && installedList.size() > 0) {
            //可能存在 空内容提示，移除掉它；
            removeNoDownloadTips();
        } else {
            return;
        }

        List<FileManageDownloadAdapterItem> tempList = new ArrayList<>(installedList.size() + 2);
        FileManageDownloadAdapterItem item;
        //插入installed item
        for (int i = 0; i < installedList.size(); i++) {
            FileDownloadInfo fileDownloadInfo = installedList.get(i);
            // 屏蔽PalmSpace
            if (VaStaticProxy.isInstantPluginApp(fileDownloadInfo.packageName)) {
                continue;
            }
            if (!fileDownloadInfo.extraInfo.isVaGame) {
                item = new FileManageDownloadAdapterItem();
                item.itemType = FileManageDownloadAdapterItem.INSTALLED_ITEM;
                item.fileDownloadInfo = installedList.get(i);
                item.placementId = String.valueOf(i);
                tempList.add(item);
            }
        }
        //插入installed模块的title信息
        item = new FileManageDownloadAdapterItem();
        item.itemType = FileManageDownloadAdapterItem.INSTALLED_TITLE;
        tempList.add(0, item);

        /*item = new FileManageDownloadAdapterItem();
        item.itemType = FileManageDownloadAdapterItem.INSTALLED_MORE_APPS;
        tempList.add(item);*/

        // 新数据根据有没有installing title，确定插入的位置；没有title，插入头部；有title，插入到installing的后面；
        int installingTitleIndex = -1;
        for (int i = 0; i < mDatas.size(); i++) {
            if (mDatas.get(i).itemType == FileManageDownloadAdapterItem.INSTALLING_TITLE) {
                installingTitleIndex = mDatas.get(i).downloadingCount;
                break;
            }
        }
        // 没有installing模块installingTitleIndex = -1; +1表示从0开始
        // 有installing模块installingTitleIndex = INSTALLING区域item个数（downloadingCount）; +1表示计算（INSTALLING_TITLE）
        // PS: 这里最简单方式是mDatas.addAll(tempList);因为前面已做过移除重新添加
        mDatas.addAll(installingTitleIndex + 1, tempList);

        //没有installing模块
//        if (installingTitleIndex == -1) {
//            /*if (isAdInfoExist()) {
//                mDatas.addAll(1, tempList);
//            } else {
//                mDatas.addAll(0, tempList);
//            }*/
//
//            mDatas.addAll(0, tempList);
//        } else {
//
//            //有installing模块
//            int position = installingTitleIndex + DownloadManager.getInstance().getNonVaShadowDownloadingInfoListSize() + getUnInstallUnActiveList().size() + 1;
//            if (position == mDatas.size()) {
//                //没有底部you may like，直接插入到列表尾部即可;
//                mDatas.addAll(tempList);
//            } else if (position < mDatas.size()) {
//                //有底部you may like，需要插入到installing和you may like之间；
//                mDatas.addAll(position, tempList);
//            }
//        }
    }

    private List<FileDownloadInfo> getUnInstallUnActiveList() {
        List<FileDownloadInfo> list = DownloadManager.getInstance().getShadowDownloadedInfoList();
        if (list == null || list.size() == 0) {
            return new ArrayList<>(0);
        }
        //下载好的文件已经不存在的，要从下载历史中移除掉
        List<FileDownloadInfo> tempList = new ArrayList<>(10);
        for (FileDownloadInfo fileDownloadInfo : list) {
            if (fileDownloadInfo.extraInfo == null || !fileDownloadInfo.extraInfo.isVaGame) {
                if (!downloadedFileIsExist(fileDownloadInfo)) {
                    tempList.add(fileDownloadInfo);
                }
            } else {
                // 已下载好未安装的va应用，不显示在下载中心
                tempList.add(fileDownloadInfo);
            }
        }
        DownloadManager.getInstance().removeDownloadedInfos(tempList);
        list.removeAll(tempList);

        if (list.size() <= 0) {
            NotificationUtil.cancelNotification(mContext, NotificationExtKt.getNOTIFY_ID_INSTALL_APP_LIST());
        }
        PalmstoreSysHandler.startService(PalmplayApplication.getAppInstance(), PalmstoreSysHandler.ACION_NOTIFICATION_CHECK_APP_DOWNLOADED);
        PalmstoreSysHandler.startService(PalmplayApplication.getAppInstance(), PalmstoreSysHandler.ACTION_NOTIFICATION_CHECK_APP_DOWNLOADING);

        List<FileDownloadInfo> dst = new ArrayList<>();
        if (list.size() > 0) {
            for (FileDownloadInfo item : list) {
                if (item.extraInfo == null || !item.extraInfo.isVaGame) {
                    if (item == null || item.isDeletedTag == 1) {
                        continue;
                    }

                    int status = DownloadStatusManager.getInstance().getObserverStatus(item, FileDownloadInfo.STATUS_DOWNLOADED);
                    if (DetailType.isApp(item.type)) {
//                    if (item.downloadStatus != FileDownloadInfo.STATUS_APP_INSTALLED
//                            && status != FileDownloadInfo.STATUS_APP_INSTALLED
//                            && status != FileDownloadInfo.STATUS_INSTALLING) {
//                        dst.add(item);
//                    }
                        dst.add(0, item);
                    } else {
                        dst.add(0, item);
                    }
                }
            }
        }
        return dst;
    }


    /**
     * 是否存在广告数据
     *
     * @return true，存在；
     */
    private boolean isAdInfoExist() {
        if (mDatas.size() > 0 && mDatas.get(0).itemType == FileManageDownloadAdapterItem.AD) {
            return true;
        }
        return false;
    }

    public int getDownloadedTitleItemPosition() {
        for (int i = 0; i < mDatas.size(); i++) {
            FileManageDownloadAdapterItem fileManageDownloadAdapterItem = mDatas.get(i);
            if (fileManageDownloadAdapterItem != null && fileManageDownloadAdapterItem.itemType == FileManageDownloadAdapterItem.DOWNLOADED_TITLE) {
                return i;
            }
        }
        return 0;
    }

    public void refreshEmptyTips(){
        if (getItemCount() == 0 || getItemViewType(0) == FileManageDownloadAdapterItem.NO_DOWNLOAD_TIPS){
            insertDownloadContentEmptyTipsData();
            notifyDataSetChanged();
        }
    }

    /**
     * 插入无下载内容提示
     */
    private void insertDownloadContentEmptyTipsData() {
        if(mDatas == null) {
            return;
        }
        int downloadIndex = -1;
        int adIndex = -1;
        for (FileManageDownloadAdapterItem item : mDatas) {
            if(item == null) {
                continue;
            }
            if (item.itemType == FileManageDownloadAdapterItem.NO_DOWNLOAD_TIPS) {
                return;
            }
            if (item.itemType == FileManageDownloadAdapterItem.INSTALLING_TITLE || item.itemType == FileManageDownloadAdapterItem.INSTALLED_TITLE
            || item.itemType == FileManageDownloadAdapterItem.PREORDERED_TITLE) {
                downloadIndex = 0;
            }
            if (item.itemType == FileManageDownloadAdapterItem.AD) {
                adIndex = 0;
            }
        }
        if (downloadIndex == -1) {
            FileManageDownloadAdapterItem item = new FileManageDownloadAdapterItem();
            item.itemType = FileManageDownloadAdapterItem.NO_DOWNLOAD_TIPS;
            if (adIndex == -1) {
                mDatas.add(0, item);
            } else {
                mDatas.add(1, item);
            }
        }

        checkUnavailable();
    }


    private void removeNoDownloadTips() {
        Iterator<FileManageDownloadAdapterItem> it = mDatas.iterator();
        while (it.hasNext()) {
            FileManageDownloadAdapterItem item = it.next();
            if (item!=null && item.itemType == FileManageDownloadAdapterItem.NO_DOWNLOAD_TIPS) {
                it.remove();
                break;
            }
        }
    }

    private void checkUnavailable() {
        List<FileDownloadInfo> list = DownloadManager.getInstance().getShadowErrorListWithoutVa();
        if (!list.isEmpty()){
            removeNoDownloadTips();
        }
    }

    /**
     * 已下载的文件是否还存在
     *
     * @param fileDownloadInfo
     * @return true，存在，false，不存在
     */
    private boolean downloadedFileIsExist(FileDownloadInfo fileDownloadInfo) {
        if (fileDownloadInfo == null) {
            return false;
        }
        //创建File对象，如果路径为空，给个默认值，避免空指针
        File file = new File(TextUtils.isEmpty(FilePathManager.getDownloadedFilePath(fileDownloadInfo)) ? "path" : FilePathManager.getDownloadedFilePath(fileDownloadInfo));
        if (file == null || !file.exists()) {
            file = new File(TextUtils.isEmpty(FilePathManager.getDownloadedFilePathForOldVersion(fileDownloadInfo)) ? "path" : FilePathManager.getDownloadedFilePathForOldVersion(fileDownloadInfo));
            if (file == null || !file.exists()) {
                file = new File(TextUtils.isEmpty(FilePathManager.getDownloadingTempFilePath(fileDownloadInfo)) ? "path" : FilePathManager.getDownloadingTempFilePath(fileDownloadInfo));
                if (file == null || !file.exists()) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 点击 Install All触发
     */
    public void installAll() {
        ArrayList<FileManageDownloadAdapterItem> fileDownloadInfoByDeleteFileList = new ArrayList<>();
        for (FileManageDownloadAdapterItem downloadInfo : mDatas) {
            if (downloadInfo.itemType != FileManageDownloadAdapterItem.DOWNLOADED_ITEM || !DetailType.isApp(downloadInfo.fileDownloadInfo.type)) {
                continue;
            }

            if (!downloadInfo.fileDownloadInfo.isNeedActive()) {
                String filePath = FilePathManager.getDownloadedFilePath(downloadInfo.fileDownloadInfo);
                File file = new File(filePath);
                boolean isFileExist = true;
                if (file == null || !file.exists()) {
                    filePath = FilePathManager.getDownloadedFilePathForOldVersion(downloadInfo.fileDownloadInfo);
                    File oldPathFile = new File(filePath);
                    if (oldPathFile == null || !oldPathFile.exists()) {
                        filePath = FilePathManager.getDownloadingTempFilePath(downloadInfo.fileDownloadInfo);
                        File tempPathFile = new File(filePath);
                        if (tempPathFile == null || !tempPathFile.exists()) {
                            isFileExist = false;
                        }
                    }
                }

                if (isFileExist) {
                    //installAppFile(filePath);
                    //记录点击安装的PageParamInfo
                    downloadInfo.fileDownloadInfo.pageParamInfo = mPageParamInfo;
                    boolean isPlutoOffer = false;
                    boolean isSubPackage = false;
                    Map<String, String> preAuthTokens = null;
                    boolean isMultiPackage = false;
                    if (downloadInfo.fileDownloadInfo.extraInfo != null) {
                        isPlutoOffer = downloadInfo.fileDownloadInfo.extraInfo.isPlutoOffer;
                        isSubPackage = downloadInfo.fileDownloadInfo.extraInfo.isSubPackage;
                        preAuthTokens = CommonUtils.getPreAuthTokens(downloadInfo.fileDownloadInfo.extraInfo.advDetails);
                        isMultiPackage = downloadInfo.fileDownloadInfo.extraInfo.isMultiPackage;
                    }
                    ApkInstallUtils.installSilentWithReflection(mContext.getApplicationContext(), filePath, downloadInfo.fileDownloadInfo.packageName, isPlutoOffer, isSubPackage, preAuthTokens, isMultiPackage);
                    String updateTF = downloadInfo.fileDownloadInfo.extraInfo != null ? downloadInfo.fileDownloadInfo.extraInfo.isUpdate : "F";
                    ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(ClientOperationRecordNode.newClickManualInstallNode(mPageParamInfo, downloadInfo.fileDownloadInfo.itemID, downloadInfo.fileDownloadInfo.packageName, String.valueOf(downloadInfo.fileDownloadInfo.version), updateTF));
                } else {
                    fileDownloadInfoByDeleteFileList.add(downloadInfo);
                }
            }
        }

        //文件被删除了，点击InstallAll需要重新下载
        if (fileDownloadInfoByDeleteFileList != null && fileDownloadInfoByDeleteFileList.size() > 0) {
//            mDatas.removeAll(fileDownloadInfoByDeleteFileList);
            FileDownloadInfo startDownloadingInfo = null;
            for (FileManageDownloadAdapterItem fileDownloadInfo : fileDownloadInfoByDeleteFileList) {
                if (fileDownloadInfo.fileDownloadInfo != null) {
                    startDownloadingInfo = fileDownloadInfo.fileDownloadInfo;
                }
                DownloadManager.getInstance().reDownloadWhenDeletedWithNotStart(fileDownloadInfo.fileDownloadInfo);
            }
            if (startDownloadingInfo != null) {
                Message msg = DownloadHandler.getInstance().getHandler().obtainMessage();
                msg.what = PalmstoreDownloadHandler.MSG_START;
                msg.obj = startDownloadingInfo.packageName;
                DownloadHandler.getInstance().getHandler().sendMessage(msg);
                LogUtils.v("AFMOBI", "send MSG_START 111");
                DownloadStatusManager.getInstance().onDownloadStart(startDownloadingInfo);
            }

            handleInstallingListInfo(true);
//            notifyDataSetChanged();
        }
    }

    public void insertRecommendData(List<FileManageDownloadAdapterItem> list) {
        if (list == null || list.size() <= 0) {
            return;
        }
        List<FileManageDownloadAdapterItem> tempList = new ArrayList<>();
        for (FileManageDownloadAdapterItem item : mDatas) {
            if(item == null ) {
                continue;
            }
            if (item.itemType == FileManageDownloadAdapterItem.RECOMMEND_TITLE || item.itemType == FileManageDownloadAdapterItem.RECOMMEND_ITEM) {
                tempList.add(item);
            }
        }
        mDatas.removeAll(tempList);
        mDatas.addAll(list);
        notifyDataSetChanged();
    }

    /**
     * 清空下载列表任务的展开折叠标志位
     * */
    private void onResetExpandFlag() {
        List<FileDownloadInfo> downloadingList = DownloadManager.getInstance().getShadowDownloadingInfoList();
        List<FileDownloadInfo> downloadedList = getUnInstallUnActiveList();
        if (downloadingList != null && !downloadingList.isEmpty()) {
            Iterator<FileDownloadInfo> it = downloadingList.iterator();
            while (it.hasNext()) {
                FileDownloadInfo item = it.next();
                if (item.isExpand()) {
                    item.setExpandFlag(false);
                }
            }
        }

        if (downloadedList != null && !downloadedList.isEmpty()) {
            Iterator<FileDownloadInfo> it = downloadedList.iterator();
            while (it.hasNext()) {
                FileDownloadInfo item = it.next();
                if (item.isExpand()) {
                    item.setExpandFlag(false);
                }
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mDatas != null) {
            mDatas.clear();
            //mDatas = null;
            notifyDataSetChanged(); //避免数据发生变化 不刷新adapter出问题
        }
        mContext = null;
        callRefresh = null;//设置为空，避免线程执行时activity已经销毁导致内存泄漏
        onResetExpandFlag();
    }

    @Override
    public void putInterfaceStatusChange() {
        InterfaceBatchStatusChange mInterfaceStatusChange = new InterfaceBatchStatusWithImageUrlChange() {

            @Override
            public void onIconUrlUpdated(FileDownloadInfo downloadInfo) {
                handleInstallingListInfo(true);
            }

            @Override
            public void onDownloadStart(FileDownloadInfo downloadInfo) {
                handleInstallingListInfo(true);
            }

            @Override
            public void onDownloadResume(FileDownloadInfo downloadInfo) {
//                statusChange();
                int position = getPosition(downloadInfo);
                notifyItemChanged(position);
                refreshDownloadingTitleAndRecommendContent();
            }

            @Override
            public void onDownloadBatchResume(List<FileDownloadInfo> downloadInfo) {
                if (mLinearLayoutManager != null) {
                    int first = mLinearLayoutManager.findFirstVisibleItemPosition();
                    int last = mLinearLayoutManager.findLastVisibleItemPosition();
                    int range = (last > first) ? (last - first + 1) : 1;
                    notifyItemRangeChanged(first, range);
                }
            }

            @Override
            public void onDownloadBatchPause(List<FileDownloadInfo> downloadInfoList) {
                if (mLinearLayoutManager != null) {
                    int first = mLinearLayoutManager.findFirstVisibleItemPosition();
                    int last = mLinearLayoutManager.findLastVisibleItemPosition();
                    int range = (last > first) ? (last - first + 1) : 1;
                    notifyItemRangeChanged(first, range);
                }
            }

            @Override
            public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {
                if (downloadInfo == null || downloadInfo.isVa()) {
                    return;
                }
                updateDownloadingProgressBar(downloadInfo, speed);
            }

            @Override
            public void onDownloadPause(FileDownloadInfo downloadInfo) {
                if (downloadInfo != null && downloadInfo.extraInfo != null && !downloadInfo.extraInfo.itemCheckFlag && !downloadInfo.extraInfo.canRetry){
                    // 不可下载任务删除刷新不可下载任务列表
                    handleInstallingListInfo(true);
                    EventMainThreadEntity entity = new EventMainThreadEntity();
                    entity.setAction(Constant.ACTION_DOWNLOAD_NORES_LIST_REFRESH);
                    EventBus.getDefault().post(entity);
                    return;
                }
//                statusChange();
                int position = getPosition(downloadInfo);
                notifyItemChanged(position);
                refreshDownloadingTitleAndRecommendContent();
            }

            @Override
            public void onDownloadError(FileDownloadInfo downloadInfo) {
                statusChange();
            }

            @Override
            public void onDownloadDelete(FileDownloadInfo downloadInfo) {
                if (downloadInfo != null && downloadInfo.extraInfo != null && !downloadInfo.extraInfo.itemCheckFlag && !downloadInfo.extraInfo.canRetry){
                    // 不可下载任务删除刷新不可下载任务列表，不在此处刷新
                    return;
                }
                //onResume();
                handleInstallingListInfo(true);
            }

            @Override
            public void onDownloadComplete(FileDownloadInfo downloadInfo) {
                handleInstallingListInfo(true);
            }

            @Override
            public void onActivated(FileDownloadInfo downloadInfo) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
                handleInstalledListInfo(false);
            }

            @Override
            public void onAppPackageAdded(String packageName, int versionCode) {
                handleInstallingListInfo(false);
                handleInstalledListInfo(false);
            }
        };

        DownloadStatusManager.getInstance().putStatusChangeListener(TAG, mInterfaceStatusChange);
        DownloadStatusManager.getInstance().putStatusBatchChangeListener(TAG, mInterfaceStatusChange);
    }

    @Override
    public void removeInterfaceStatusChange() {
        DownloadStatusManager.getInstance().removeStatusChangeListener(TAG);
        DownloadStatusManager.getInstance().removeStatusBatchChangeListener(TAG);
    }

    @Override
    public Object loaderInterfaceStatusChangeObjectKey() {
        return null;
    }

    @Override
    public InterfaceStatusChange loaderInterfaceStatusChange() {
        return null;
    }

    private void statusChange() {
        notifyDataSetChanged();
    }

    private void refreshDownloadingTitleAndRecommendContent() {
        if (mDatas == null) {
            return;
        }
        int index = -1;
        for (int i = 0; i < mDatas.size(); i++) {
            if (mDatas.get(i).itemType == FileManageDownloadAdapterItem.INSTALLING_TITLE) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            notifyItemChanged(index);
        }

        for (int i = 0; i < mDatas.size(); i++) {
            if (mDatas.get(i).itemType == FileManageDownloadAdapterItem.RECOMMEND_ITEM) {
                notifyItemChanged(i);
            }
        }
    }

    public boolean isExistUnDownload(List<FileDownloadInfo> listDownloadingInfo) {
        boolean isExistUnDownload = false;
        if (listDownloadingInfo == null || listDownloadingInfo.size() == 0)
            return isExistUnDownload;

        Iterator<FileDownloadInfo> iterator = listDownloadingInfo.listIterator();
        while (iterator.hasNext()) {
            FileDownloadInfo info = iterator.next();
            if (info.extraInfo != null && info.extraInfo.isVaGame) {
                continue;
            }
            if (info.downloadStatus == FileDownloadInfo.STATUS_PAUSE || info.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
                isExistUnDownload = true;
                break;
            }
        }
        return isExistUnDownload;
    }

    public boolean isExistPause(List<FileDownloadInfo> listDownloadingInfo) {
        boolean isExistPause = false;
        for (FileDownloadInfo downloadInfo : listDownloadingInfo) {
            if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_PAUSE) {
                isExistPause = true;
                break;
            }
        }
        return isExistPause;
    }

    public boolean isExistRetry(List<FileDownloadInfo> listDownloadingInfo) {
        boolean isExistRetry = false;
        for (FileDownloadInfo downloadInfo : listDownloadingInfo) {
            if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
                isExistRetry = true;
                break;
            }
        }
        return isExistRetry;
    }

    public boolean isExistDownloading(List<FileDownloadInfo> listDownloadingInfo) {
        boolean isExistDownloading = false;
        for (FileDownloadInfo downloadInfo : listDownloadingInfo) {
            if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isVaGame) {
                continue;
            }
            if (FileDownloadInfo.isDownloading(downloadInfo.downloadStatus)) {
                isExistDownloading = true;
                break;
            }
        }
        return isExistDownloading;
    }

    private void updateDownloadingProgressBar(FileDownloadInfo downloadInfo, int speed) {
        if (downloadInfo != null && mLinearLayoutManager != null) {
            int firstVisibleItemPosition = mLinearLayoutManager.findFirstVisibleItemPosition();
            int lastVisibleItemPosition = mLinearLayoutManager.findLastVisibleItemPosition();

            for (int i = firstVisibleItemPosition; i <= lastVisibleItemPosition; i++) {
                View itemView = mLinearLayoutManager.findViewByPosition(i);
                if (itemView == null) {
                    continue;
                }
                Object objTag = itemView.getTag();
                if (objTag == null) {
                    continue;
                }

                if (objTag instanceof FileManageDownloadAdapterItem) {
                    FileManageDownloadAdapterItem tmpFileDownloadInfo = (FileManageDownloadAdapterItem) objTag;
                    if (tmpFileDownloadInfo.itemType == FileManageDownloadAdapterItem.DOWNLOADING_ITEM && tmpFileDownloadInfo.fileDownloadInfo != null) {
                        if (TextUtils.equals(tmpFileDownloadInfo.fileDownloadInfo.packageName, downloadInfo.packageName) &&
                                null != recyclerView.getChildViewHolder(itemView)) {
                            ChildDownloadingRecyclerViewHolder viewHolder = (ChildDownloadingRecyclerViewHolder) recyclerView.getChildViewHolder(itemView);
                            viewHolder.updateViewHolderProgressBar(downloadInfo, speed);
                        }
                    }
                } else if (objTag instanceof RankModel) {
                    RecommendItemViewHolder viewHolder = (RecommendItemViewHolder) recyclerView.getChildViewHolder(itemView);
                    viewHolder.updateItemProgress(itemView, downloadInfo.packageName, downloadInfo);
                }
            }
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        if (viewType == FileManageDownloadAdapterItem.DOWNLOADING_ITEM) {
            LayoutManageDownloadingListItemBinding binding = DataBindingUtil.inflate(inflater, R.layout.layout_manage_downloading_list_item,
                    viewGroup, false);
            return new ChildDownloadingRecyclerViewHolder(binding.getRoot());

        } else if (viewType == FileManageDownloadAdapterItem.INSTALLING_TITLE) {
            return new DownloadingTitleViewHolder(inflater.inflate(R.layout.layout_downloading_title, viewGroup, false));

        } else if (viewType == FileManageDownloadAdapterItem.DOWNLOADED_ITEM) {
            return new DownloadedItemViewHolder(DataBindingUtil.inflate(inflater, R.layout.layout_manage_downloaded_list_item, viewGroup,
                    false).getRoot());

        } else if (viewType == FileManageDownloadAdapterItem.INSTALLED_TITLE) {
            return new InstalledTitleViewHolder(inflater.inflate(R.layout.layout_installed_title, viewGroup, false));

        } else if (viewType == FileManageDownloadAdapterItem.INSTALLED_ITEM) {
            //installed；
            return new InstalledItemViewHolder(DataBindingUtil.inflate(inflater, R.layout.layout_manage_installed_item, viewGroup,
                    false));

        } else if (viewType == FileManageDownloadAdapterItem.INSTALLED_MORE_APPS) {
            //installed more
            return new InstalledSeeMoreViewHolder(inflater.inflate(R.layout.layout_installed_more_apps, viewGroup, false));

        } else if (viewType == FileManageDownloadAdapterItem.NO_DOWNLOAD_TIPS) {

            return new DownloadContentEmptyViewHolder(inflater.inflate(R.layout.layout_download_content_empty, viewGroup, false));

        } else if (viewType == FileManageDownloadAdapterItem.RECOMMEND_TITLE) {
            return new RecommendTitleViewHolder(inflater.inflate(R.layout.layout_recommend_title, viewGroup, false));

        } else if (viewType == FileManageDownloadAdapterItem.RECOMMEND_ITEM) {
            return new RecommendItemViewHolder(inflater.inflate(R.layout.layout_download_recommend_item, viewGroup, false));

        } else if (viewType == FileManageDownloadAdapterItem.AD) {
            return null;
        } else if (viewType == FileManageDownloadAdapterItem.PREORDERED_ITEM) {
            LayoutManagePreorderedListItemBinding binding = DataBindingUtil.inflate(inflater, R.layout.layout_manage_preordered_list_item,
                    viewGroup, false);
            return new ChildPreOrderedRecyclerViewHolder(binding.getRoot());

        } else if (viewType == FileManageDownloadAdapterItem.PREORDERED_TITLE) {
            return new PreOrderedTitleViewHolder(inflater.inflate(R.layout.layout_preordered_title, viewGroup, false));

        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        if (position >= mDatas.size()) {
            return;
        }
        FileManageDownloadAdapterItem itemData = mDatas.get(position);

        if (FileManageDownloadAdapterItem.DOWNLOADING_ITEM == itemData.itemType) {
            if (itemData.fileDownloadInfo == null) {
                return;
            }
            ChildDownloadingRecyclerViewHolder holder = (ChildDownloadingRecyclerViewHolder) viewHolder;
            holder.setActivity((Activity) mContext).setAdapter(this).setDatas(mDatas).setPageParamInfo(mPageParamInfo).setFrom(mFrom).setScreenPageName(mScreenPageName)
                    .setFeatureName(TRAnalyticsConstant.MODULE_DOWNLOADING)
                    .bind(itemData, position);

        } else if (FileManageDownloadAdapterItem.INSTALLING_TITLE == itemData.itemType) {

            DownloadingTitleViewHolder holder = (DownloadingTitleViewHolder) viewHolder;
            holder.setContext(mContext).setPageParamInfo(mPageParamInfo).setAdapter(this).setFrom(mFrom).bind(itemData, position);

        } else if (FileManageDownloadAdapterItem.DOWNLOADED_ITEM == itemData.itemType) {

            DownloadedItemViewHolder holder = (DownloadedItemViewHolder) viewHolder;
            holder.setContext(mContext).setAdapter(this).setPageParamInfo(mPageParamInfo).setFrom(mFrom).bind(itemData.fileDownloadInfo);

        } else if (FileManageDownloadAdapterItem.INSTALLED_TITLE == itemData.itemType) {

            InstalledTitleViewHolder holder = (InstalledTitleViewHolder) viewHolder;
            holder.setContext(mContext).setPageParamInfo(mPageParamInfo).bind();

        } else if (FileManageDownloadAdapterItem.INSTALLED_ITEM == itemData.itemType) {
            //installed类型
            InstalledItemViewHolder installedItemViewHolder = (InstalledItemViewHolder) viewHolder;
            installedItemViewHolder.setActivity((Activity) mContext)
                    .setPageParamInfo(mPageParamInfo).setFrom(mFrom)
                    .setScreenPageName(mScreenPageName)
                    .setFeatureName(TRAnalyticsConstant.MODULE_INSTALLED)
                    .bind(itemData,position);

        } else if (FileManageDownloadAdapterItem.INSTALLED_MORE_APPS == itemData.itemType) {
            //installed more
            InstalledSeeMoreViewHolder holder = (InstalledSeeMoreViewHolder) viewHolder;
            holder.setContext(mContext).setPageParamInfo(mPageParamInfo).setFrom(mFrom)
                    .setScreenPageName(mScreenPageName)
                    .setFeatureName(TRAnalyticsConstant.MODULE_INSTALLED)
                    .bind();

        } else if (FileManageDownloadAdapterItem.NO_DOWNLOAD_TIPS == itemData.itemType) {

            DownloadContentEmptyViewHolder holder = (DownloadContentEmptyViewHolder) viewHolder;
            holder.setContext(mContext)
                    .setFrom(mFrom)
                    .setScreenPageName(mScreenPageName)
                    .setFeatureName(TRAnalyticsConstant.MODULE_DOWNLOADING)
                    .bind();

        } else if (FileManageDownloadAdapterItem.RECOMMEND_TITLE == itemData.itemType) {

        } else if (FileManageDownloadAdapterItem.RECOMMEND_ITEM == itemData.itemType) {

            RecommendItemViewHolder mRecommendItemViewHolder = (RecommendItemViewHolder) viewHolder;
            mRecommendItemViewHolder
                    .setFromPage(mPageParamInfo.getLastPage())
                    .setPageParamInfo(mPageParamInfo)
                    .setFrom(mFrom)
                    .setScreenPageName(mScreenPageName)
                    .setFeatureName(TRAnalyticsConstant.MODULE_DOWNLOAD_RECOMMEND)
                    .setOnViewLocationInScreen(null)
                    .setItemViewStateListener(null)
                    .bind(itemData.rankModel, position);

        } else if (FileManageDownloadAdapterItem.AD == itemData.itemType) {
        } else if (FileManageDownloadAdapterItem.PREORDERED_ITEM == itemData.itemType) {
            if (itemData.fileDownloadInfo == null) {
                return;
            }
            ChildPreOrderedRecyclerViewHolder holder = (ChildPreOrderedRecyclerViewHolder) viewHolder;
            holder.setActivity((Activity) mContext)
                    .setAdapter(this)
                    .setDatas(mDatas)
                    .setPageParamInfo(mPageParamInfo)
                    .setFrom(mFrom)
                    .setScreenPageName(mScreenPageName)
                    .setFeatureName(TRAnalyticsConstant.MODULE_DOWNLOAD_PREORDER)
                    .bind(itemData, position);

        } else if (FileManageDownloadAdapterItem.PREORDERED_TITLE == itemData.itemType) {

            PreOrderedTitleViewHolder holder = (PreOrderedTitleViewHolder) viewHolder;
            holder.setContext(mContext).setPageParamInfo(mPageParamInfo).setFrom(mFrom).bind(itemData, position);

        }
    }

    @Override
    public int getItemCount() {
        return mDatas == null ? 0 : mDatas.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (mDatas == null || position >= mDatas.size() || position < 0 || mDatas.get(position) == null) {
            return 0;
        }
        return mDatas.get(position).itemType;
    }

    public void setIsNoResListFold(MutableLiveData<Boolean> isNoResListFold) {
        this.isNoResListFold = isNoResListFold;
    }

}

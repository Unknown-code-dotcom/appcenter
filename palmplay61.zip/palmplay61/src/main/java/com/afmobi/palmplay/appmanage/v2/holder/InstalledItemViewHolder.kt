package com.afmobi.palmplay.appmanage.v2.holder

import android.text.TextUtils
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.appmanage.v2.adapter.EventCombine
import com.afmobi.palmplay.appmanage.v2.model.MIN_CLICK_DURATION
import com.afmobi.palmplay.cache.ApkIconLoader
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.util.FileUtils
import com.afmobi.util.TRNoDoubleClickListener
import com.transsion.palmstorecore.glide.GlideUtils
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.isHttpOrHttps
import com.transsnet.store.R
import com.transsnet.store.databinding.LayoutManageInstalledItemV2Binding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class InstalledItemViewHolder(
    private val binding: LayoutManageInstalledItemV2Binding,
    private val event: EventCombine,
    private val viewHolderScope: CoroutineScope
) : RecyclerView.ViewHolder(binding.root) {

    fun bind(downloadInfo: FileDownloadInfo) {
        binding.layoutContent.visibility = View.VISIBLE
        binding.tvName.text = downloadInfo.name
        binding.tvSize.text = FileUtils.getSizeName(downloadInfo.sourceSize)
        val defaultIcon: Int = R.drawable.layer_list_app_default_01_bg
        if (downloadInfo.extraInfo != null && !TextUtils.isEmpty(downloadInfo.extraInfo.category2) && downloadInfo.extraInfo.category2 == "local") {
            //本地app
            if (downloadInfo.iconUrl.isHttpOrHttps()) {
                //重新下载的游戏
                GlideUtils.setImageUrl(
                    binding.ivIcon,
                    downloadInfo.iconUrl,
                    defaultIcon,
                    defaultIcon
                )
            } else {
                viewHolderScope.launch {
                    val drawable = ApkIconLoader.getApkIconAsync(
                        PalmplayApplication.getAppInstance(),
                        downloadInfo.iconUrl
                    )
                    if (drawable != null) {
                        binding.ivIcon.setImageDrawable(drawable)
                    } else {
                        binding.ivIcon.setImageResource(R.drawable.ic_launcher)
                    }
                }
//                PsVaManager.getInstance().showLocalAppIcon(
//                    mActivity,
//                    downloadInfo.name,
//                    binding.ivIcon,
//                    downloadInfo.iconUrl,
//                    position,
//                    (binding.layoutContent.tag) as Int
//                )
            }
        } else {
            GlideUtils.setImageUrl(
                binding.ivIcon,
                downloadInfo.iconUrl,
                defaultIcon,
                defaultIcon
            )
        }
        // 设置点击事件
        setupClickListeners(downloadInfo)
    }

    private fun setupClickListeners(downloadInfo: FileDownloadInfo) {
        // 整个item点击
        binding.layoutContent.setOnClickListener(
            object : TRNoDoubleClickListener(MIN_CLICK_DURATION) {
                override fun onNoDoubleClick(v: View?) {
                    LogUtils.d("DownloadRepo", "InstalledItem OnClick$layoutPosition")
                    event.onDownloadItemClick?.invoke(downloadInfo, true, layoutPosition)
                }
            }
        )
    }
}
package com.afmobi.palmplay.base

import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

open class BaseViewBindingVH<VB : ViewBinding>(val binding: VB) : RecyclerView.ViewHolder(binding.root) {
    val baseTag: String = "${javaClass.simpleName}_${Integer.toHexString(hashCode())}"

}
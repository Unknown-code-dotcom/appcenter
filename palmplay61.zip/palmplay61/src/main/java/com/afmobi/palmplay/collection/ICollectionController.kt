package com.afmobi.palmplay.collection

import com.afmobi.palmplay.home.model.FeatureBean

interface ICollectionController {

    fun askWifiOnlyPermission(callback: IViewHolder, featureBean: FeatureBean)

}

interface IViewHolder {

    fun continueExecuteGetAll(featureBean: FeatureBean, waitingWiFi: Boolean)

}
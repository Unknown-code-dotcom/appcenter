package com.afmobi.palmplay.acpush.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import com.afmobi.palmplay.acpush.handler.DeliverPushHandler
import com.afmobi.palmplay.acpush.handler.UpdateConfigHandler
import com.transsion.palmstorecore.log.LogUtils

/**
 * AC-PUSH 对外 ContentProvider。
 *
 * authority: com.transsion.ac.provider.push
 * CRUD 全部 Stub，唯一入口是 call()，支持两个方法：
 *   - deliver_push: 由 DeliverPushHandler 处理（受 A/B 闸门约束）
 *   - update_config: 由 UpdateConfigHandler 处理（始终执行）
 *
 * 系统在 ApplicationInfo 加载时自动 onCreate，无需手动注册到 Application。
 */
class ClientPushReceiverProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun query(u: Uri, p: Array<out String>?, s: String?, sa: Array<out String>?, o: String?): Cursor? = null
    override fun insert(u: Uri, v: ContentValues?): Uri? = null
    override fun delete(u: Uri, s: String?, sa: Array<out String>?): Int = 0
    override fun update(u: Uri, v: ContentValues?, s: String?, sa: Array<out String>?): Int = 0
    override fun getType(u: Uri): String? = null

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        val ctx = context ?: return Bundle().apply {
            putBoolean("success", false)
            putString("error", "context is null")
            LogUtils.d(LogUtils.TAG_AC_PUSH, "pm provider call finished, method=$method, success=false, error=context is null")
        }
        if (!isAuthorizedCaller()) {
            val callingUid = Binder.getCallingUid()
            LogUtils.d(
                LogUtils.TAG_AC_PUSH,
                "pm provider call rejected, method=$method, callingUid=$callingUid"
            )
            return Bundle().apply {
                putBoolean("success", false)
                putString("error", "unauthorized caller")
            }
        }
        val result = when (method) {
            METHOD_DELIVER_PUSH -> DeliverPushHandler.handle(ctx, extras)
            METHOD_UPDATE_CONFIG -> UpdateConfigHandler.handle(extras)
            else -> Bundle().apply {
                putBoolean("success", false)
                putString("error", "unsupported method: $method")
            }
        }
        LogUtils.d(
            LogUtils.TAG_AC_PUSH,
            "pm provider call finished, method=$method, success=${result.getBoolean("success", false)}, error=${result.getString("error")}"
        )
        return result
    }

    private fun isAuthorizedCaller(): Boolean {
        val ctx = context ?: return false
        val callingUid = Binder.getCallingUid()
        if (callingUid == ctx.applicationInfo.uid) return true

        return try {
            val providerInfo = ctx.packageManager.resolveContentProvider(PM_PUSH_HUB_AUTHORITY, 0)
            providerInfo?.packageName == PM_PACKAGE_NAME && providerInfo.applicationInfo.uid == callingUid
        } catch (e: Exception) {
            LogUtils.e(LogUtils.TAG_AC_PUSH, "pm provider caller auth failed", e)
            false
        }
    }

    companion object {
        const val AUTHORITY = "com.transsion.ac.provider.push"
        const val METHOD_DELIVER_PUSH = "deliver_push"
        const val METHOD_UPDATE_CONFIG = "update_config"
        private const val PM_PACKAGE_NAME = "com.transsion.phonemaster"
        private const val PM_PUSH_HUB_AUTHORITY = "com.transsion.pushsdk.provider"
    }
}

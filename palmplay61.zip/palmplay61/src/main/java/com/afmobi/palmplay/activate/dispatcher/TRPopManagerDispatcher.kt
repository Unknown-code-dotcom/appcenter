package com.afmobi.palmplay.activate.dispatcher

import android.app.Activity
import android.content.DialogInterface.OnDismissListener
import android.text.TextUtils
import android.view.View
import android.view.View.OnClickListener
import com.afmobi.palmplay.activate.TRActivateConstant
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.handler.DefaultChainHandler
import com.afmobi.palmplay.activate.handler.TRChainHandler
import com.afmobi.palmplay.activate.handler.TRIntantGameHandler
import com.afmobi.palmplay.activate.handler.TROfflineMoreGuideHandler
import com.afmobi.palmplay.activate.handler.TRUserDialogHandler
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.activate.manager.TRNewManager.Companion.instance
import com.afmobi.palmplay.activate.state.TRPopUpScene
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.dialog.OfflineMoreGuideDialog.OnDialogBtnClickListener
import com.afmobi.palmplay.dialog.TRDialogUtil
import com.afmobi.palmplay.switchcountry.SwitchCountryManager
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.log.LogUtils
import java.lang.ref.WeakReference
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.PriorityBlockingQueue

/**
 *
 */
class TRPopManagerDispatcher {

    val TAG = "TRPopManagerDispatcher"
    // 使用优先队列管理弹框顺序
    var mPopOrderQueue: PriorityBlockingQueue<TRChainHandler> = PriorityBlockingQueue()

    // 等待显示的弹框列队
    private val mPendingPopupQueue: ConcurrentLinkedQueue<TRChainHandler> = ConcurrentLinkedQueue()

    // 当前正在显示的弹框
    private var mCurrentShowingPopup: TRChainHandler? = null

    // 下一个等待展示的弹框
    private var nextToShowPopup: TRChainHandler? = null

    private var reason = "" // 跟源代码对齐，补埋点

    private var homeShowed = false      // 首页那几个优先级最高，用来判断首页弹框是否显示


    fun dispatchEvent(fromType: String) {
        show(fromType)
    }

    /**
     * 兼容TRManager#callBackShow
     */
    fun callBackShow(type: Int, fromType: String): Boolean {
        var popupHandler: TRChainHandler? = null // 用于保存下一次弹框，需提前获取TRChainHandler
        if (type == TRActivateConstant.FROM_SPACE_LIMIT) {
            popupHandler = findPopupHandler(TRPopUpScene.POP_UP_DISK_SPACE_LIMIT)
        } else {
            var sence = ""
            when (type) {
                TRActivateConstant.FROM_UPDATE -> sence = TRPopUpScene.POP_UP_APP_UPDATE
                TRActivateConstant.FROM_MUST_INSTALL -> sence = TRPopUpScene.POP_UP_MUST_INSTALL
                TRActivateConstant.FROM_RECOM_INSTALL -> sence =
                    TRPopUpScene.POP_UP_RECOMMOND_INSTALL

                TRActivateConstant.FROM_ACTIVATE -> sence = TRPopUpScene.POP_UP_TIP_ACTIVATE
                TRActivateConstant.FROM_FILE_FOLDER -> sence = TRPopUpScene.POP_UP_FILE_FOLDER
                TRActivateConstant.FROM_NOTIFICATION_TOGGLE -> sence =
                    TRPopUpScene.POP_UP_NOTIFICATION_TOGGLE

                TRActivateConstant.FROM_SPLASH_AD -> sence = TRPopUpScene.POP_UP_SPLASH_ACTIVATE
                TRActivateConstant.FROM_WIDGET -> sence = TRPopUpScene.POP_UP_GUIDE_WIDGE
                else -> {}
            }
            popupHandler = findPopupHandler(sence)
        }

        if (popupHandler == null) {
            return false
        }

        if (!instance.canShow()) {
            storeNextPopup(popupHandler, fromType)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            return false
        }

        val isShow = popupHandler.show(fromType)
        if (isShow) {
            mCurrentShowingPopup = popupHandler
            TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
        } else {
            LogUtils.d(TRNewManager.TAG, "callBackShow -> show popupHandler for ${popupHandler.sceneName} failed")
        }
        return isShow
    }

    /**
     * 适用于Activity类型的弹窗，不用传入Activity
     * @param fromType
     */
    fun showPop(fromType: String): Boolean {
        val popupHandler = findPopupHandler(fromType)
        if (popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            return  false
        }
        val isShow = popupHandler.show(fromType)
        if (isShow) {
            mCurrentShowingPopup = popupHandler
            TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> show popupHandler for ${popupHandler.sceneName} failed")
        }
        return isShow
    }

    /**
     * 绝大多数dialog走这里
     * @param fromType
     * @param activity
     */
    fun showPop(fromType: String, activity: Activity?): Boolean {
        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType, activity)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType, activity)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            storeNextPopup(popupHandler, fromType, activity)
            return  false
        }
        val isShow = popupHandler.show(fromType, activity)
        if (isShow) {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is showing")
            mCurrentShowingPopup = popupHandler
            if(fromType != TRPopUpScene.POP_UP_TIP_NETWORK) {
                TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
            }
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is show fail")
        }
        return isShow
    }

    /**
     * 目前专给无网弹窗用
     * @param fromType  弹窗类型
     * @param activity
     * @param from   无网弹窗埋点用
     */
    fun showPop(fromType: String,from: String?, activity: Activity?):Boolean{
        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            if (popupHandler is DefaultChainHandler ) {
                popupHandler.from = from
            }
            storeNextPopup(popupHandler, fromType, activity)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            if (popupHandler is DefaultChainHandler ) {
                popupHandler.from = from
            }
            storeNextPopup(popupHandler, fromType, activity)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            if (popupHandler is DefaultChainHandler ) {
                popupHandler.from = from
            }
            storeNextPopup(popupHandler, fromType, activity)
            return  false
        }
        val isShow = popupHandler.show(fromType,from, activity)
        if (isShow) {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is showing")
            mCurrentShowingPopup = popupHandler
            if(fromType != TRPopUpScene.POP_UP_TIP_NETWORK) {
                TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
            }
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is show fail")
        }
        return isShow
    }

    /**
     * 专门用于freeData引导，因其需要传入y坐标
     * @param fromType
     * @param activity
     * @param y   y坐标
     */
    fun showPop(fromType: String, activity: Activity?, y:Int): Boolean {
        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType,y)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType,y)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            storeNextPopup(popupHandler, fromType,y)
            return  false
        }
        val isShow = popupHandler.show(fromType, activity,y)
        if (isShow) {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is showing")
            mCurrentShowingPopup = popupHandler
            TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is show fail")
        }
        return isShow
    }


    /**
     * 用于InstantGame引导，因其listener里需要处理UI，只能传入处理
     * @param fromType
     * @param activity
     * @param clickListener
     * @param dismissListener
     */
    fun showPop(fromType: String, activity: Activity?, clickListener: View.OnClickListener, dismissListener: OnDismissListener): Boolean {
        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType, activity, clickListener, dismissListener)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType, activity, clickListener, dismissListener)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            storeNextPopup(popupHandler, fromType, activity, clickListener, dismissListener)
            return  false
        }
        val isShow = popupHandler.show(fromType, activity,clickListener, dismissListener)
        if (isShow) {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is showing")
            TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
            mCurrentShowingPopup = popupHandler
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is show fail")
        }
        return isShow
    }

    /**
     * 专门用于用户引导，因其需要传入isNeedGuide，OnDismissListener
     * @param fromType
     * @param activity
     * @param isNeedGuide  NeedH5TabGuide
     * @param listener
     */
    fun showPop(fromType: String, activity: Activity? ,isNeedGuide: Boolean, listener: OnDismissListener): Boolean {
        if(activity?.isDestroyed == true || activity?.isFinishing == true) {
            LogUtils.d(TRNewManager.TAG, "showPop -> activity is destroyed, ${fromType} return")
            return false
        }

        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType,isNeedGuide,  listener)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType,isNeedGuide,  listener)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            return false
        }
        val isShow = popupHandler.show(fromType, activity, isNeedGuide, listener)
        if (isShow) {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is showing")
            mCurrentShowingPopup = popupHandler
            TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is show fail")
        }
        return isShow
    }

    /**
     * 专门引用于more引导， 需传入listener、isR2L、location
     * @param fromType
     * @param activity
     * @param listener
     * @param isR2L
     * @param location
     * @return
     */
    fun showPop(
        fromType: String,
        activity: Activity?,
        listener: OnDialogBtnClickListener,
        isR2L: Boolean,
        position: IntArray
    ): Boolean {
        if(activity?.isDestroyed == true || activity?.isFinishing == true) {
            LogUtils.d(TRNewManager.TAG, "showPop -> activity is destroyed, ${fromType} return")
            return false
        }

        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            LogUtils.d(TRNewManager.TAG, "showPop -> no popupHandler for $fromType")
            return false
        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType,activity, listener,  isR2L,  position)
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            LogUtils.d(TRNewManager.TAG, "showPop -> other pop is showing, can't show popupHandler for ${popupHandler.sceneName}")
            storeNextPopup(popupHandler, fromType,activity, listener,  isR2L,  position)
            return false
        }
        if(!canHomePopNeedShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showPop -> 有首页弹框可以显示，${popupHandler.sceneName}不能显示")
            return false
        }
        val isShow = popupHandler.show(fromType, activity, listener,  isR2L,  position)
        if (isShow) {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is showing")
            mCurrentShowingPopup = popupHandler
            TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
        } else {
            LogUtils.d(TRNewManager.TAG, "showPop -> ${popupHandler.sceneName} is show fail")
        }
        return isShow
    }


    fun dismiss(fromType: String) {

        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            return
        }
        try {
            popupHandler.dismiss()
            LogUtils.d(TRNewManager.TAG, "dismiss -> ${popupHandler.sceneName}")
        } catch(_: Exception) {

        }
    }

    fun dismiss(fromType: String, activity: Activity?) {

        val popupHandler = findPopupHandler(fromType)
        if(popupHandler == null) {
            return
        }
        try {
            popupHandler.dismiss(activity)
            LogUtils.d(TRNewManager.TAG, "dismiss -> ${popupHandler.sceneName}")
        } catch(_: Exception) {

        }
    }

    fun showing(sceneName: String): Boolean {
        val popupHandler = findPopupHandler(sceneName)
        LogUtils.d(TRNewManager.TAG, "showing -> ${mCurrentShowingPopup?.sceneName} is showing? ${ mCurrentShowingPopup?.showing()}")
        return popupHandler?.showing() == true

    }



    fun showNextPopup(): Boolean {
        if (!instance.canShow()) {
            return false
        }
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if (TRDialogUtil.hasDialogShowing()) {
            return false
        }

        if (instance.hasNextToShow()) {
            val isShow = nextToShowPopup?.showNext(
                nextToShowPopup?.fromType
            ) == true
            if (isShow) {
                mCurrentShowingPopup = nextToShowPopup
                LogUtils.d(TRNewManager.TAG, "show -> show next popup,${nextToShowPopup?.sceneName}")
                nextToShowPopup = null
                if(nextToShowPopup?.sceneName != TRPopUpScene.POP_UP_TIP_NETWORK) {
                    TRNewManager.instance.dismiss(TRPopUpScene.POP_UP_TIP_NETWORK)
                }
            } else {
                LogUtils.d(TRNewManager.TAG, "show -> no next popup to show")
            }
            return isShow
        }
        return false
    }

    private fun findPopupHandler(fromType: String): TRChainHandler? {
        try {
            val handlersCopy = mPopOrderQueue.toTypedArray()
            // 添加超时机制，避免无限等待
            val iterator = handlersCopy.iterator()
            while (iterator.hasNext()) {
                val handler = iterator.next()
                if (handler?.sceneName == fromType) {
                    LogUtils.d(TRNewManager.TAG, "findPopupHandler -> found handler for $fromType")
                    return handler
                }
            }
            LogUtils.d(TRNewManager.TAG, "findPopupHandler -> no handler found for $fromType")
            return null
        } catch (e: Exception) {
            LogUtils.e(TRNewManager.TAG, "findPopupHandler -> exception occurred: ${e.message}")
            return null
        }
    }

    // 可用于后面新增
    fun addPopupHandler(handler: TRChainHandler) {
        mPopOrderQueue.offer(handler)
    }

    fun hide(): Unit {
        val popup = findPopupHandler(TRPopUpScene.POP_UP_PRIVACY_POLICY)
        popup?.hide()
    }

    private fun show(fromType: String) {
//        if (isdealShow) {
//            LogUtils.d(TRNewManager.TAG, "show -> other pop is ready,${fromType} return")
//            return
//        }
        if (!instance.canShow()) {
            LogUtils.d(TRNewManager.TAG, "show -> new pop is showing,${fromType} return")
            return
        }
//        isdealShow = true
        mPendingPopupQueue.clear()
        val handlersCopy = mPopOrderQueue.toTypedArray()
        for (handler in handlersCopy) {
            if (handler != null && handler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                mPendingPopupQueue.add(handler)
            }
        }
        processNextPopup(fromType)
    }


    private fun storeNextPopup(popupHandler: TRChainHandler, fromType: String) {

        if (instance.hasNextToShow()) {
            LogUtils.d(TRNewManager.TAG, "storeNextPopup -> has next popup,check for ${popupHandler.sceneName} ")
            if (mCurrentShowingPopup != null) {
                if (TextUtils.equals(mCurrentShowingPopup!!.sceneName, popupHandler.sceneName)) {
                    LogUtils.d(TRNewManager.TAG, "storeNextPopup -> ${popupHandler.sceneName} is same with current pop, return")
                    return
                }
                if (mCurrentShowingPopup!!.getPopType() == TRPopupType.HOME_ONE_TIME && popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                    LogUtils.d(TRNewManager.TAG, "storeNextPopup -> ${popupHandler.sceneName} and current ${mCurrentShowingPopup!!.sceneName} is home_one_time, return")
                    return
                }
            }
            if (popupHandler.canShow(fromType)) {
                LogUtils.d(TRNewManager.TAG, "storeNextPopup -> ${popupHandler.sceneName} can show, store it for next")
                nextToShowPopup = popupHandler
                nextToShowPopup?.fromType = fromType
            }
        }
    }

    private fun storeNextPopup(popupHandler: TRChainHandler, fromType: String, isNeedGuide: Boolean, listener: OnDismissListener) {
        if (instance.hasNextToShow()) {
            if (mCurrentShowingPopup != null) {
                if (TextUtils.equals(mCurrentShowingPopup!!.sceneName, popupHandler.sceneName)) {
                    return
                }
                if (popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME && popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                    return
                }
            }
            if (popupHandler.canShow(fromType)) {
                nextToShowPopup = popupHandler
                nextToShowPopup?.fromType = fromType
                if(nextToShowPopup is TRUserDialogHandler) {
                    (nextToShowPopup as TRUserDialogHandler).isNeedGuide = isNeedGuide
                    (nextToShowPopup as TRUserDialogHandler).listener = listener
                }
            }
        }
    }

    private fun storeNextPopup(popupHandler: TRChainHandler, fromType: String, y:Int) {
        if (instance.hasNextToShow()) {
            if (mCurrentShowingPopup != null) {
                if (TextUtils.equals(mCurrentShowingPopup!!.sceneName, popupHandler.sceneName)) {
                    return
                }
                if (popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME && popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                    return
                }
            }
            if (popupHandler.canShow(fromType)) {
                nextToShowPopup = popupHandler
                nextToShowPopup?.fromType = fromType
            }
        }
    }

    private fun storeNextPopup(popupHandler: TRChainHandler, fromType: String, activity: Activity?) {
        if (instance.hasNextToShow()) {
            if (mCurrentShowingPopup != null) {
                if (TextUtils.equals(mCurrentShowingPopup!!.sceneName, popupHandler.sceneName)) {
                    return
                }
                if (popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME && popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                    return
                }
            }
            if (popupHandler.canShow(fromType)) {
                nextToShowPopup = popupHandler
                nextToShowPopup?.fromType = fromType
                nextToShowPopup?.curActivity = WeakReference(activity)
            }
        }
    }

    private fun storeNextPopup(popupHandler: TRChainHandler, fromType: String, activity: Activity?, clickListener: OnClickListener, dismissListener: OnDismissListener) {
        if (instance.hasNextToShow()) {
            if (mCurrentShowingPopup != null) {
                if (TextUtils.equals(mCurrentShowingPopup!!.sceneName, popupHandler.sceneName)) {
                    return
                }
                if (popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME && popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                    return
                }
            }
            if (popupHandler.canShow(fromType)) {
                nextToShowPopup = popupHandler
                nextToShowPopup?.fromType = fromType
                nextToShowPopup?.curActivity = WeakReference(activity)
                if(nextToShowPopup is TRIntantGameHandler) {
                    (nextToShowPopup as TRIntantGameHandler).clickListener =  clickListener
                    (nextToShowPopup as TRIntantGameHandler).dismissListener =  dismissListener
                }
            }
        }
    }

    private fun storeNextPopup(popupHandler: TRChainHandler, fromType: String, activity: Activity?, listener: OnDialogBtnClickListener, isR2L: Boolean, location: IntArray) {
        if (instance.hasNextToShow()) {
            if (mCurrentShowingPopup != null) {
                if (TextUtils.equals(mCurrentShowingPopup!!.sceneName, popupHandler.sceneName)) {
                    return
                }
                if (popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME && popupHandler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                    return
                }
            }
            if (popupHandler.canShow(fromType)) {
                nextToShowPopup = popupHandler
                nextToShowPopup?.fromType = fromType
                nextToShowPopup?.curActivity = WeakReference(activity)
                if(nextToShowPopup is TROfflineMoreGuideHandler) {
                    (nextToShowPopup as TROfflineMoreGuideHandler).listener=  listener
                    (nextToShowPopup as TROfflineMoreGuideHandler).location =  location
                    (nextToShowPopup as TROfflineMoreGuideHandler).isR2L =  isR2L
                }
            }
        }
    }


    private fun processNextPopup(fromType: String) {
        val popupHandler = mPendingPopupQueue.poll()
        if (popupHandler != null) {
            if (!instance.canShow()) {
                reason = "It is already showed and return"
                TRAnalysticsUtil.trackPopSenceInfo(reason, fromType, "")
                storeNextPopup(popupHandler, fromType)
 //               isdealShow = false
                LogUtils.d(
                    TRNewManager.TAG,
                    "processNextPopup -> other pop is showing, ${popupHandler.sceneName} return"
                )
                return
            }

            val isShow = popupHandler.show(fromType)
            if (isShow) {
                LogUtils.d(TRNewManager.TAG, "processNextPopup ${popupHandler.sceneName}")
                mCurrentShowingPopup = popupHandler
                homeShowed = true
            } else {
                processNextPopup(fromType)
            }
        }
//        } else {
//            isdealShow = false
//        }
    }

    private fun canHomePopNeedShow(fromType: String): Boolean {
        if(homeShowed) {
            return true
        }
        if(  fromType ==TRPopUpScene.POP_UP_OFFLINE_MORE_GUIDE
            || fromType == TRPopUpScene.POP_UP_SPLASH_ACTIVATE
            || fromType == TRPopUpScene.POP_UP_PRIVACY_POLICY
            || fromType ==TRPopUpScene.POP_UP_PET_GUIDE) {
            return true    // 不在首页，不用要求首页先显示
        }
        val handlersCopy = mPopOrderQueue.toTypedArray()
        for(handler in handlersCopy) {
            if(handler.getPopType() == TRPopupType.HOME_ONE_TIME) {
                if(handler.canShow(fromType))  {
                    return false
                }
            }
        }
        return true
    }

    fun getExecutor(fromType: String): TRBaseExecutor<*>?{
        val popupHandler = findPopupHandler(fromType)
        return popupHandler?.getExecutor()
    }
}

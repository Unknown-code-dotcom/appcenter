// TOP SECRET
package com.afmobi.palmplay.cache;

public interface LocalCache {
	
	public void saveToCache(String jsonBuffer, Object... objects);
	
	public void loadFromCache(Object... objects);
	
	public String getFileName(Object... objects);
	
	
}

package com.afmobi.palmplay.appmanage.holder;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.transsnet.store.R;

/**
 * 更新列表折叠ViewHolder
 */
public class UpdateFoldRecyclerViewHolder extends RecyclerView.ViewHolder {

    public View layoutFold;
    public TextView tvFoldText;

    public UpdateFoldRecyclerViewHolder(View itemView) {
        super(itemView);
        layoutFold = itemView.findViewById(R.id.layout_fold);
        tvFoldText = itemView.findViewById(R.id.tv_fold_text);
    }
}

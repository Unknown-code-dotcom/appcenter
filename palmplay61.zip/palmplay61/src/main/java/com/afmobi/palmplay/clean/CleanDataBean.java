package com.afmobi.palmplay.clean;

import java.io.Serializable;

public class CleanDataBean implements Serializable {

    public long memoryCheckAutoTime;//自动检测内存的时间点；

    public long memoryCheckUserTime;//用户检测内存的时间点；

    public int memoryCheckResult;//内存检测的结果；直接保存百分比；

    public long memoryOptimizeTime;//内存优化的时间点；

    public int memoryOptimizePercentResult;//内存优化结果-展示的百分比

    public String memoryOptimizeSizeResult;//内存优化结果-展示的size值；

    public long deepCleanTime;//junk files操作时间点；
    public String deepCleanResult;//junk files清理的结果值；
    public int backgroundStatus;//背景色是已检测状态还是已优化状态；

    @Override
    public String toString() {
        return "CleanDataBean{" +
                "memoryCheckAutoTime=" + memoryCheckAutoTime +
                ", memoryCheckUserTime=" + memoryCheckUserTime +
                ", memoryCheckResult=" + memoryCheckResult +
                ", memoryOptimizeTime=" + memoryOptimizeTime +
                ", memoryOptimizePercentResult=" + memoryOptimizePercentResult +
                ", memoryOptimizeSizeResult='" + memoryOptimizeSizeResult + '\'' +
                ", deepCleanTime=" + deepCleanTime +
                ", deepCleanResult='" + deepCleanResult + '\'' +
                ", backgroundStatus=" + backgroundStatus +
                '}';
    }
}

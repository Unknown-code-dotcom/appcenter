package com.afmobi.palmplay.cache.v6_0;

import android.text.TextUtils;

import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommonInfo;
import com.afmobi.palmplay.model.TagItemList;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.BannerModel;
import com.afmobi.palmplay.network.NetworkActions;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.transsnet.store.BuildConfig;

import java.lang.reflect.Type;
import java.util.List;

import androidx.collection.LruCache;

/**
 * 主界面缓存类
 * @author HJG
 * @date 2016-5-17 上午11:42:41
 * @modifyAuthor:
 * @modifyDate: 2016-5-17 上午11:42:41
 * @modifyContent:
 */
public class RankCache {

	private static String CACHE_URI = NetworkActions.ACTION_RANK;

	private static volatile RankCache mInstance;
	private static byte[] lock = new byte[0];

	private static final int MAX_CACHE_SIZE = 5;
	public static final int MAX_PAGE_SIZE = 24;

	private LruCache<String, TagItemList<? extends CommonInfo>> mAppListCache;


	private RankCache() {
		mAppListCache = new LruCache<String, TagItemList<? extends CommonInfo>>(MAX_CACHE_SIZE);
	}

	public static RankCache getInstance() {
		if (mInstance == null) {
			synchronized (lock) {
				if (mInstance == null) {
					mInstance = new RankCache();
				}
			}
		}

		return mInstance;
	}

	public static void resetInstance() {
		mInstance = null;
	}

	public void initCache(JsonElement jsonElement, String categoryID, String rankID, int pageIndex, boolean isOffline){
		if(jsonElement==null || !jsonElement.isJsonObject() || TextUtils.isEmpty(rankID))
			return;

            TagItemList<? extends CommonInfo> tempAppList = null;
            JsonObject jsonObject = (JsonObject) jsonElement;
            Gson gson = new Gson();
            JsonElement jsonElement1 = jsonObject.get("itemType");
            String itemType = gson.fromJson(jsonElement1, String.class);

		try{
//
            if(itemType.equals(TabType.SOFT)){
                Type type = new TypeToken<TagItemList<AppInfo>>() {}.getType();
                tempAppList = gson.fromJson(jsonObject, type);
            }


		}catch(Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
		}finally{

			if(pageIndex==0){
				TagItemList<? extends CommonInfo> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
				if(tagItemList!=null)
					mAppListCache.remove(getCacheKey(categoryID, rankID, isOffline));
			}

			if (tempAppList != null && tempAppList.itemList!=null) {

				TagItemList<? extends CommonInfo> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));

				if (tagItemList == null) {
                    if (itemType.equals(TabType.SOFT.toString())){
                        tagItemList = new TagItemList<AppInfo>();

                    }
				}

				mAppListCache.put(getCacheKey(categoryID, rankID, isOffline), tagItemList);

				int size = tempAppList.itemList.size();

				if (size > 0) {
					tagItemList.pageIndex = tempAppList.pageIndex + 1;
					tagItemList.addAll(tempAppList);
				}
                if(tempAppList.pageSum > 0){
                    tagItemList.isPageLast = tagItemList.pageIndex < tempAppList.pageSum ? false:true;
                }else if (size < MAX_PAGE_SIZE) {
                    tagItemList.isPageLast = true;
                }
                if(tempAppList.bannerUrl != null){
                    tagItemList.bannerUrl = tempAppList.bannerUrl;
                }
                if(tempAppList.name != null){
                    tagItemList.name = tempAppList.name;
                }
                if(tempAppList.info != null){
                    tagItemList.info = tempAppList.info;
                }
			}

		}
	}

	@SuppressWarnings("unchecked")
	public List<AppInfo> getAppInfoList(String categoryID, String rankID, boolean isOffline) {

		if (mAppListCache != null) {
			TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
			if (tagItemList != null && tagItemList.itemList!=null) {
				return (List<AppInfo>) tagItemList.itemList;
			}
		}
		return null;
	}

	public List<BannerModel> getAdInfoList(String categoryID, String rankID, boolean isOffline) {

		if (mAppListCache != null) {
			TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
			if (tagItemList != null && tagItemList.adList!=null) {
				return tagItemList.adList;
			}
		}
		return null;
	}

    public TagItemList<?> getItemList(String categoryID, String rankID, boolean isOffline) {

        if (mAppListCache != null) {
            TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
            if (tagItemList != null) {
                return tagItemList;
            }
        }
        return null;
    }

    public String getName(String categoryID, String rankID, boolean isOffline){
        if (mAppListCache != null) {
            TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
            if (tagItemList != null) {
                return tagItemList.name;
            }
        }
        return null;
    }

    public String getBannerUrl(String categoryID, String rankID, boolean isOffline){
        if (mAppListCache != null) {
            TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
            if (tagItemList != null) {
                return tagItemList.bannerUrl;
            }
        }
        return null;
    }

	public String getInfo(String categoryID, String rankID, boolean isOffline) {
		if (mAppListCache != null) {
			TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
			if (tagItemList != null) {
				return tagItemList.info;
			}
		}
		return null;
	}

	public TagItemList<?> getTagInfo(String categoryID, String rankID){
		if (mAppListCache != null) {
			TagItemList<?> tagItemList = mAppListCache.get(getCacheKey(categoryID, rankID, false));
			if (tagItemList != null) {
				return tagItemList;
			}
		}
		return null;
	}


    public int getPageIndex(String categoryID, String rankID, boolean isOffline) {

        int pageIndex = 0;

        if (mAppListCache != null) {
            TagItemList<?> itemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
            if (itemList != null) {
                return itemList.pageIndex;
            }
        }
        return pageIndex;
    }

	public boolean isPageLast(String categoryID, String rankID, boolean isOffline) {

		boolean mIsPageLast = false;

		if (mAppListCache != null) {
			TagItemList<?> itemList = mAppListCache.get(getCacheKey(categoryID, rankID, isOffline));
			if (itemList != null) {
				return itemList.isPageLast;
			}
		}
		return mIsPageLast;
	}

	public String getCacheKey(String categoryID, String rankID, boolean isOffline){
		return CACHE_URI + (TextUtils.isEmpty(categoryID) ? "" : categoryID) + (TextUtils.isEmpty(rankID) ? "" : rankID);
	}

}

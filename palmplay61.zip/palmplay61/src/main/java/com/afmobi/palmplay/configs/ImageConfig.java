// TOP SECRET
package com.afmobi.palmplay.configs;


/**
 * all banner image width & height
 * @author HJG
 * @date 2016-8-22 下午12:13:51
 * @modifyAuthor: 
 * @modifyDate: 
 * @modifyContent:
 */
public class ImageConfig {
	
	/** when home banner Image >= 3, middle Image's width / screenWidth */
	public static final float BANNER_IMG_WIDTH_PERCENT_OF_SCREENWIDTH = 5.0f / 6.0f;//Note: must format xx.xf
	/** banner Image width & height percent */
	public static final float BANNER_IMG_WIDTH_HEIGHT_PERCENT = 720.0f / 280.0f;
	
	/** video Image width & height percent */
	public static final float VIDEO_IMAGE_WIDTH_HEIGHT_PERCENT = 340.0f / 192.0f;
	
	/** video Image width & height percent */
	public static final float BOOK_IMAGE_WIDTH_HEIGHT_PERCENT = 224.0f / 264.0f;

	//featured top banner height
	public static final float HOME_TOP_BANNER_IMG_WIDTH_HEIGHT_PERCENT = 328.0f / 158.0f;  //720.0f / 440.0f;

	public static final float HOME_TOP_BANNER_IMG_WIDTH_HEIGHT_PERCENT_PAD = 1153f / 448.39f;

	//featured top banner height
	public static final float FEATURES_BANNER_IMG_WIDTH_HEIGHT_PERCENT = 720.0f / 344.0f;

	public static final float HOME_IMMERSIVE_TOP_BANNER_IMG_WIDTH_HEIGHT_PERCENT = 720.0f / 408.0f;

	public static final float HOME_SHORT_BANNER_IMG_WIDTH_HEIGHT_PERCENT = 328.0f / 83.0f;  //720.0f / 440.0f;

	public static final float DETAIL_SHORT_BANNER_IMG_WIDTH_HEIGHT_PERCENT = 328.0f / 72.0f;


//	public static int getDefImageWidth(int screenWidth){
//		return screenWidth;
//	}
	
	public static int getBannerImageWidth(int screenWidth, int count, int minLimit){
		int mImageWidth = screenWidth;
		if(count >= minLimit){
			mImageWidth = (int) (screenWidth * ImageConfig.BANNER_IMG_WIDTH_PERCENT_OF_SCREENWIDTH);
		}
		
		return mImageWidth;
	}
	
//	public static int getBannerImageHeight(int screenWidth, int count, int minLimit){
//		int mImageWidth = screenWidth;
//		if(count >= minLimit){
//			mImageWidth = (int) (screenWidth * ImageConfig.BANNER_IMG_WIDTH_PERCENT_OF_SCREENWIDTH);
//		}
//		return getBannerImageHeight(mImageWidth);
//	}
	
	public static int getBannerImageHeight(int mImageWidth){
		return (int) (mImageWidth / ImageConfig.BANNER_IMG_WIDTH_HEIGHT_PERCENT);
	}


	public static int getHomeTopBannerImageHeight(int mImageWidth){
		return (int) (mImageWidth / ImageConfig.HOME_TOP_BANNER_IMG_WIDTH_HEIGHT_PERCENT);
	}

	public static int getHomeImmersiveTopBannerImageHeight(int mImageWidth){
		return (int) (mImageWidth / ImageConfig.HOME_IMMERSIVE_TOP_BANNER_IMG_WIDTH_HEIGHT_PERCENT);
	}

	public static int getImageHeight(int mImageWidth, float rate){
		if(0 == rate){
			return 0;
		}
		return (int) (mImageWidth / rate);
	}

}

package com.afmobi.palmplay.customview.banner.indicator

import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.util.AttributeSet

class RoundedBarIndicator @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseIndicator(context, attrs, defStyleAttr) {

    private val rectF = RectF()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        val count = config.indicatorSize
        if (count <= 1) return
        val width = config.selectedWidth +
                (count - 1) * config.normalWidth +
                (count - 1) * config.indicatorSpace
        setMeasuredDimension(width, config.height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val count = config.indicatorSize
        if (count <= 1) return
        val radius = config.radius.toFloat()
        val h = config.height.toFloat()
        var left = 0f
        for (i in 0 until count) {
            val selected = config.currentPosition == i
            mPaint.color = if (selected) config.selectedColor else config.normalColor
            val w = if (selected) config.selectedWidth else config.normalWidth
            rectF.set(left, 0f, left + w, h)
            canvas.drawRoundRect(rectF, radius, radius, mPaint)
            left += w + config.indicatorSpace
        }
    }

    override fun onPageScrollStateChanged(state: Int) {
        super.onPageScrollStateChanged(state)
    }
}

// TOP SECRET
package com.afmobi.palmplay.appmanage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;

import com.afmobi.apk.ThreadHelper;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.appmanage.adapter.DownloadNoResAdapter;
import com.afmobi.palmplay.appmanage.adapter.FileManageDownloadAdapter;
import com.afmobi.palmplay.appmanage.v2.util.DownloadActivityLauncher;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.ObbFormatDataManager;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter;
import com.afmobi.palmplay.home.instant.InstantVisibleState;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.main.PermissionsReqActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.SimpleDataInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.notify.db.NotifyInstallCompleteDatabase;
import com.afmobi.palmplay.permissions.PermissonsHintDialog;
import com.afmobi.palmplay.saveddata.SavedDataActivity;
import com.afmobi.palmplay.viewmodel.filedownload.DownloadNoResViewModel;
import com.afmobi.palmplay.viewmodel.filedownload.DownloadViewModel;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.TRNoDoubleClickListener;
import com.afmobi.util.TRPermissionUtil;
import com.afmobi.util.TimeUtil;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.didi.drouter.annotation.Router;
import com.google.gson.Gson;
import com.trans.common.netstate.AppNetState;
import com.trans.common.netstate.NetTypeKt;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.DownloadManageActivityBinding;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


/**
 * 下载管理器页面
 */
@Router(path = "/page/manageDownload")
public class ManageDownloadActivity extends BaseEventFragmentActivity {

    public final static int ACTIVITY_REQUESTCODE_SETTING_PERMISSION = 20;
    private final int ATIVITY_REQUESTCODE_PERMISSIONS = 21;
    public static final String IS_FROM_DEEP_LINK = "is_from_deep_link";

    private Handler mDelayScrollHandler;
    private Runnable mDelayScrollRunnable;
    private boolean mNeedScrollTo;

    private FileManageDownloadAdapter mAdapter;

    private TrHomeRecyclerViewAdapter mHomeRecyclerViewAdapter;
    private DownloadManageActivityBinding downloadManageActivityBinding;
    private DownloadViewModel mDownloadViewModel;

    private DownloadNoResViewModel mDownloadNoResViewModel;
    private String mFrom;
    private String mFromSite = "";
    private String mValue;
    private boolean isFromDeepLink;
    private boolean isSavedDataTrack;

    protected List<String> mAlreadyAdList = new ArrayList<String>();  //记录已经展示过的广告包名

    private DownloadNoResAdapter downloadNoResAdapter;
    private DownloadNoResAdapter.OnItemDeleteListener onItemDeleteListener;

    private boolean isFromInstant;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        if (InstantVisibleState.getInstance().isVisible()) {
            isFromInstant = true;
            InstantVisibleState.getInstance().setVisible(false);
        }
        mDownloadViewModel = ViewModelProviders.of(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(DownloadViewModel.class);
        getLifecycle().addObserver(mDownloadViewModel);
        mDownloadViewModel.getRefreshObservable().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String str) {
                if (isFinishing() || isDestroyed() || TRStringUtil.isBlank(str)) {
                    return;
                }
                if (mAdapter != null && FileManageDownloadAdapter.REFRESH_NOW.equalsIgnoreCase(str)) {
                    mAdapter.notifyDataSetChanged();
                }
            }
        });
        mDownloadNoResViewModel = ViewModelProviders.of(this).get(DownloadNoResViewModel.class);

        Intent intent = getIntent();
        if (intent != null) {
            mNeedScrollTo = intent.getBooleanExtra(Constant.KEY_SCROLLTO, false);
            mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE);
            mFromSite = intent.getStringExtra("_source");
            isFromDeepLink = intent.getBooleanExtra(IS_FROM_DEEP_LINK, false);
        }

        mValue = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,"","","");
        mPageParamInfo.deliverPageParamInfo(intent, PageConstants.My_Download);
        mDownloadViewModel.setParamInfo(mPageParamInfo);

        downloadManageActivityBinding = DataBindingUtil.setContentView(this, R.layout.activity_manage_download_main);
        downloadManageActivityBinding.layoutTitle.layoutTitleContent.setText(getString(R.string.text_installation_manager));
        downloadManageActivityBinding.layoutTitle.layoutTitleContent.setTextColor(getColor(R.color.download_manage_title));

        if (isFromNotify) {
            PalmplayApplication.getPalmplayApplicationInstance().appInit();
        }
        initViews();

        mDownloadViewModel.loadFeaturedData();
        //D_x_x_x
        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(mValue)
                .setFrom(mFrom).setFromSite(mFromSite);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private void showRecommendView(FeaturedModel featuredModel) {
        if (featuredModel != null && featuredModel.featureList != null && featuredModel.featureList.size() > 0) {
            List<FeatureBean> listItems = featuredModel.featureList;

            if (View.VISIBLE != downloadManageActivityBinding.recomRecyclerView.getVisibility()) {
                downloadManageActivityBinding.recomRecyclerView.setVisibility(View.VISIBLE);
            }

            if (mHomeRecyclerViewAdapter != null) {
                if (listItems != null && listItems.size() > 0) {
                    for (FeatureBean bean:listItems){
                        removeListInstalled(bean);
                    }
                    List<TaNativeInfo> adInfo = mDownloadViewModel.downloadAdInfos;
                    if (adInfo != null) {
                        int size = adInfo.size();
                        for (int i = 0; i < size; i++) {
                            TaNativeInfo taNativeInfo = adInfo.get(i);
                            if (!taNativeInfo.isIconType()) {
                                //continue
                            } else {
                                //icon类广告
                                FeatureItemData appinfo = null;
                                try {
                                    appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                                    if(appinfo != null) {
                                        appinfo.tNativeInfo = taNativeInfo;
                                        if(appinfo.extJson!=null){
                                            appinfo.isVa = appinfo.extJson.isVa;
                                        }
                                    }
                                } catch (GsonUtil.GsonParseException e) {
                                    if (BuildConfig.DEBUG) e.printStackTrace();
                                }

                                if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName)
                                        && !mAlreadyAdList.contains(appinfo.packageName))) {
                                    mDownloadViewModel.filterEWData(featuredModel, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), null);
                                    TRHomeUtil.addAdForFeatureData(featuredModel.featureList, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), mAlreadyAdList, SceneCode.D_ym);
                                }
                            }
                        }
                    }
                    TRHomeUtil.doBeddingData(featuredModel,mDownloadViewModel, mAlreadyAdList, SceneCode.D_ym, HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0);
                    mHomeRecyclerViewAdapter.setData(AppDataManager.FEATURE_FLOW_ALLOW_MULTI_COUNT ?
                           listItems: listItems.subList(0,1), null,null,false,false, true);
                }
            }
        }
    }

    @Override
    public String getValue() {
        return mValue;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        mPageParamInfo.deliverPageParamInfo(intent, PageConstants.My_Download);
        if (mDownloadViewModel != null) {
            mDownloadViewModel.setParamInfo(mPageParamInfo);
        }

        if (intent != null) {
            boolean isFromNotify = intent.getBooleanExtra(FromPageType.Notify, false);
            if (isFromNotify) {
                this.isFromNotify = isFromNotify;
            }

            mNeedScrollTo = intent.getBooleanExtra(Constant.KEY_SCROLLTO, false);
            if (mNeedScrollTo && mDelayScrollHandler != null) {
                mDelayScrollHandler.postDelayed(mDelayScrollRunnable, 1000);
            }
            mFromSite = intent.getStringExtra("_source");
            mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE);
            PagePvBuilder pagePvBuilder = new PagePvBuilder();
            pagePvBuilder.setValue(mValue)
                    .setFrom(mFrom).setFromSite(mFromSite);
            TRAnalysticsUtil.trackPV(pagePvBuilder);
        }
    }

    private void initViews() {
        try {
            downloadManageActivityBinding.layoutTitle.tvSearch.setVisibility(View.VISIBLE);
            downloadManageActivityBinding.layoutTitle.tvSearch.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    TRJumpUtil.switchToSearchActivity(ManageDownloadActivity.this, TabType.SOFT, "", false, "", false, "",
                            mPageParamInfo, mValue, TRAnalyticsConstant.BUTTON_SEARCH_IMG, mFrom);
                }
            });

            // 9.3.2新增无发下载列表
            initNoResViews();

            downloadManageActivityBinding.layoutTitle.layoutTitleBack.setOnClickListener(
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            if (!checkOnBackPressed()) {
                                finish();
                            }

                            ComponentClickBuilder builder = new ComponentClickBuilder();
                            builder.setValue(mValue)
                                    .setFrom(mFrom)
                                    .setTopicType("")
                                    .setTopicId("")
                                    .setItemType("")
                                    .setItemId("")
                                    .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                                    .setItemValue("")
                                    .setExtraValue("");
                            TRAnalysticsUtil.trackClick(builder);
                        }
                    });

        } catch (Exception e) {
            LogUtils.e(e);
        }

        mDelayScrollHandler = new Handler();
        mDelayScrollRunnable = new Runnable() {
            @Override
            public void run() {
                //滚动到Downloaded模块
                if (downloadManageActivityBinding.recyclerView == null) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = downloadManageActivityBinding.recyclerView.getLayoutManager();
                if (layoutManager != null) {
                    ((LinearLayoutManager) layoutManager).scrollToPositionWithOffset(mAdapter.getDownloadedTitleItemPosition(), 0);
                }

            }
        };

        if (mNeedScrollTo) {
            mDelayScrollHandler.postDelayed(mDelayScrollRunnable, 1000);
        }
        mAdapter = new FileManageDownloadAdapter(this, downloadManageActivityBinding.recyclerView);
        mAdapter.setCallRefresh(mDownloadViewModel == null ? null : mDownloadViewModel.getRefreshObservable());
        mAdapter.setPageParamInfo(mPageParamInfo);
        mAdapter.setScreenPageName(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER);
        mAdapter.setFrom(mFrom);
        mAdapter.setIsNoResListFold(mDownloadNoResViewModel == null ? null : mDownloadNoResViewModel.isNoResListFold());

        downloadManageActivityBinding.layoutTitle.layoutCommonTitle.setBackgroundColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
        downloadManageActivityBinding.filemanagerToolbar.setPadding(0,0,0,0);


        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        layoutManager.setSmoothScrollbarEnabled(true);
        layoutManager.setAutoMeasureEnabled(true);
        downloadManageActivityBinding.recomRecyclerView.setHasFixedSize(true);
        downloadManageActivityBinding.recomRecyclerView.setNestedScrollingEnabled(true);
        downloadManageActivityBinding.recomRecyclerView.setLayoutManager(layoutManager);

        if (mHomeRecyclerViewAdapter == null) {
            mHomeRecyclerViewAdapter = new TrHomeRecyclerViewAdapter(this, downloadManageActivityBinding.recomRecyclerView, layoutManager, null, null, null
                    , PageConstants.My_Download, mPageParamInfo, false, 0, 0,false);
//            mHomeRecyclerViewAdapter = new TrHomeRecyclerViewAdapter(this, downloadManageActivityBinding.recomRecyclerView, layoutManager, null, null
//                    , null, mPageParamInfo.getLastPage(), mPageParamInfo, false, 0, 0);
//            mHomeRecyclerViewAdapter.setOnViewLocationInScreen(mOnViewLocationInScreen);
            mHomeRecyclerViewAdapter.setFrom(mFrom);
            mHomeRecyclerViewAdapter.onCreateView();
            mHomeRecyclerViewAdapter.setCurScreenPage(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER);
            mHomeRecyclerViewAdapter.setFeatureName(TRAnalyticsConstant.MODULE_YOU_LIKE);
            downloadManageActivityBinding.recomRecyclerView.setAdapter(mHomeRecyclerViewAdapter);

        }


        mDownloadViewModel.getFeaturedLiveData().observe(this, new Observer<FeaturedModel>() {
            @Override
            public void onChanged(FeaturedModel featuredModel) {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                try {
                    showRecommendView(featuredModel);
                } catch (Exception e) {
                    LogUtils.e(e);
                }

            }
        });

        AppNetState.INSTANCE.getNetType().observe(this, netType -> {
            if (NetTypeKt.connected(netType)) {
                onTipNetworkDialogDismiss();
            } else {
                onTipNetworkDialogShow();
            }
        });
        onTipNetworkDialogShow();

        downloadManageActivityBinding.idNestedscrollview.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if(mHomeRecyclerViewAdapter != null) {
                    mHomeRecyclerViewAdapter.onNestedScrollChanged();
                }
            }
        });

        // saved data
        mDownloadViewModel.getSavedDataLiveData().observe(this, new Observer<List<SimpleDataInfo>>() {
            @Override
            public void onChanged(List<SimpleDataInfo> savedDataInfos) {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                onSavedDataShow(savedDataInfos);
            }
        });

        TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new Runnable() {
            @Override
            public void run() {
                List<SimpleDataInfo> list = NotifyInstallCompleteDatabase.getDatabase(PalmplayApplication.getAppInstance())
                        .getSavedDataDao().getSimpleDataList(Constant.SAVED_DATA_LIST_MAX);

                mDownloadViewModel.getSavedDataLiveData().postValue(list);
            }
        });
    }

    private void onSavedDataShow(List<SimpleDataInfo> list) {

        if (list == null || list.size() <= 0) {
            downloadManageActivityBinding.savedInclude.getRoot().setVisibility(View.GONE);
            return;
        }

        downloadManageActivityBinding.savedInclude.getRoot().setVisibility(View.VISIBLE);

        //today
        String day = TimeUtil.getDateToStringDay(System.currentTimeMillis());
        String startDay = day + " " + "00:00:00";
        String endDay = day + " " + "23:59:59";
        long startTime = TimeUtil.getStringToDate(startDay);
        long endTime = TimeUtil.getStringToDate(endDay) + 1000;
        long todaySize = 0;
        long totalSize = 0;
        for (SimpleDataInfo item : list) {
            if (item.time >= startTime && item.time < endTime) {
                todaySize += item.savedSize;
            }

            totalSize += item.savedSize;
        }


        downloadManageActivityBinding.savedInclude.tvTodaySize.setText(FileUtils.getWebSizeName(todaySize));


        downloadManageActivityBinding.savedInclude.tvTotalSize.setText(FileUtils.getWebSizeName(totalSize));

        SimpleDataInfo item = list.get(0);
        if (item != null) {
            int defaultIcon = R.drawable.layer_list_app_default_01_bg;
            int corner = getResources().getDimensionPixelSize(R.dimen.dp_04);
            GlideUtils.setImageUrl(downloadManageActivityBinding.savedInclude.ivDetials, item.iconUrl, corner, defaultIcon, defaultIcon);
        }

        downloadManageActivityBinding.savedInclude.layoutContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(ManageDownloadActivity.this, SavedDataActivity.class);
                    intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, mPageParamInfo.getCurPage());
                    intent.putExtra(TRAnalyticsConstant.VALUE, getValue());
                    startActivity(intent);
                } catch (Exception ignored) {
                }

                String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, TRAnalyticsConstant.SAVED_DATA, "", "");
                ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setItemValue("")
                        .setButtonType(TRAnalyticsConstant.ICON);
                TRAnalysticsUtil.trackClick(builder);
            }
        });

        if (!isSavedDataTrack) {
            isSavedDataTrack = true;
            ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
            builder.setValue(TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, TRAnalyticsConstant.SAVED_DATA, "", ""))
                    .setFrom(mFrom)
                    .setItemValue("");
            TRAnalysticsUtil.trackExposure(builder);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mAdapter != null)
            mAdapter.onResume();

        if (isPermissionHintDialogShowed) {
            if (CommonUtils.hasStoragePermissions()) {
                isPermissionHintDialogShowed = false;
                ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp();
            }
        }

        mDownloadNoResViewModel.queryNoResList();

        ThreadHelper.runOnWorkThread(() -> {
            //每次进来记录已读下载列表
            List<String> downloadingAndDownloadedList = DownloadManager.getInstance().getDownloadingAndDownloadedList();
            if (downloadingAndDownloadedList != null && !downloadingAndDownloadedList.isEmpty()) {
                SPManager.putString(Constant.preference_key_downloading_date, new Gson().toJson(downloadingAndDownloadedList));
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mAdapter != null)
            mAdapter.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAdapter != null)
            mAdapter.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseInfo();
        if (mHomeRecyclerViewAdapter != null) {
            mHomeRecyclerViewAdapter.onDestroy();
        }
        mDownloadViewModel.destoryHisavanaSdk();
    }

    private void releaseInfo() {
        if (mDelayScrollHandler != null) {
            mDelayScrollHandler.removeCallbacksAndMessages(null);
            mDelayScrollHandler = null;
        }
        mDelayScrollRunnable = null;
        if (mAdapter != null) {
            mAdapter.onDestroy();
            mAdapter = null;
        }
    }

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        if (mEventMainThreadEntity.getAction().equals(Constant.ACTION_DOWNLOAD_LIST_REFRESH)) {
            if (null != mAdapter) {
                mAdapter.refreshEmptyTips();
            }
        }
        else if (mEventMainThreadEntity.getAction().equals(Constant.ACTION_DOWNLOAD_NORES_LIST_REFRESH)) {
            mDownloadNoResViewModel.queryNoResList();
        }
        else if (mEventMainThreadEntity.getAction().equals(Constant.ACTION_REDOWNLOAD_FORCE_REFRESH)) {
            if (null != mAdapter) {
                mAdapter.onResume();
            }
        } else if (NetworkActions.ACTION_OPEN_ACCESSIBILITY.equalsIgnoreCase(mEventMainThreadEntity.getAction())) {
            if (mAdapter != null && mAdapter.isInstallAllClicked()) {
                mAdapter.installAll();
            }
        } else if (NetworkActions.ACTION_PREORDER_STATUS.equalsIgnoreCase(mEventMainThreadEntity.getAction())) {
            if(mEventMainThreadEntity.isSuccess) {
                //List<String> list = (List<String>) mEventMainThreadEntity.getList(Constant.KEY_PACKAGES);
                if (null != mAdapter) {
                    mAdapter.onResume();
                }
            }
        } else if (mEventMainThreadEntity.getAction().equals(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS)) {
            InstalledAppInfo appInfo = (InstalledAppInfo) mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DATA);
            FileDownloadInfo downloadInfo = (FileDownloadInfo) mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DOWNLOADINFO);
            showInstalledCompleteWindow(this, appInfo, downloadInfo);
        } else if (NetworkActions.ACTION_SAVED_DATA_ADD.equals(mEventMainThreadEntity.getAction())) {
            List<SimpleDataInfo> list = NotifyInstallCompleteDatabase.getDatabase(PalmplayApplication.getAppInstance())
                    .getSavedDataDao().getSimpleDataList(Constant.SAVED_DATA_LIST_MAX);

            mDownloadViewModel.getSavedDataLiveData().postValue(list);
        }
    }

    /**
     * 提供给BaseActivity用来决定是否弹出网络断掉的toast
     *
     * @return
     */
    @Override
    public boolean isToastNetworkDisConnectedWhenResume() {
        if (mDownloadViewModel == null) {
            return false;
        }
        return mDownloadViewModel.isExistDownloading(DownloadManager.getInstance().getShadowDownloadingInfoList());
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ATIVITY_REQUESTCODE_PERMISSIONS) {
            initViews();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(mValue)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType("")
                    .setItemId("")
                    .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                    .setItemValue("")
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);

            if (checkOnBackPressed()) {
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private boolean checkOnBackPressed() {

        if (isFromInstant) {
            InstantVisibleState.getInstance().setVisible(true);
        }

        if (isFromNotify) {
            if (!AtyManager.getAtyManager().isExistsActivity(MainActivity.class)) {
                startActivity(new Intent(this, MainActivity.class).putExtra(FromPageType.Notify, false));
            }
            finish();
            return true;

        } else if(isFromDeepLink){
            if (!AtyManager.getAtyManager().isExistsActivity(MainActivity.class)) {
                startActivity(new Intent(this, MainActivity.class));
            }
            finish();
            return true;
        }

        return false;
    }

    public static Intent getIntoIntent(Context mContext, boolean isFromNotify, PageParamInfo pageParamInfo, String value) {
        Intent intent = new Intent(mContext, DownloadActivityLauncher.getManageDownloadClass()).putExtra(FromPageType.Notify, isFromNotify).putExtra(TRAnalyticsConstant.VALUE, value);
        PageConstants.putPageParamInfo(intent, pageParamInfo);
        return intent;
    }


    private boolean isPermissionHintDialogShowed;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (!TRPermissionUtil.isGranted(grantResults, permissions)) {
            boolean isTip = ActivityCompat.shouldShowRequestPermissionRationale(this, permissions.length > 0 ? permissions[0] : "");
            LogUtils.d("obbPermission", "onRequestPermissionsResult: refuse " + isTip);
            TRAnalysticsUtil.trackObbPermissionClick(TRAnalyticsConstant.OBB_PERMISSION_REFUSE,getValue());
            if (isTip) {//表明用户没有彻底禁止弹出权限请求
                // 用户选择了禁止权限

            } else {//表明用户已经彻底禁止弹出权限请求
                isPermissionHintDialogShowed = true;
                PermissonsHintDialog.getPermissionHintDlg(this, PermissionsReqActivity.SYS_SETTING_DETAILS_REQUEST_CODE, permissions.length > 0 ? permissions[0] : "");
            }
        } else {
            isPermissionHintDialogShowed = false;
            LogUtils.d("obbPermission", "onRequestPermissionsResult: agree");
            TRAnalysticsUtil.trackObbPermissionClick(TRAnalyticsConstant.OBB_PERMISSION_AGREE,getValue());
            ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp();
        }
    }

    /**
     * 移除已安装的应用
     * @param mFeatureBean
     */
    public static void removeListInstalled(FeatureBean mFeatureBean) {
        //若不过滤 直接返回
        if(mFeatureBean.filterInstalled==0){

            return;
        }
        if (mFeatureBean != null && mFeatureBean.dataList != null && mFeatureBean.dataList.size() > 0) {
            Iterator iterator = mFeatureBean.dataList.iterator();
            while (iterator.hasNext()) {
                Object data = iterator.next();
                if (data instanceof FeatureItemData) {
                    String firstPkg = ((FeatureItemData)data).packageName;
                    int firstVersionCode = ((FeatureItemData)data).versionCode;
                    if (InstalledAppManager.getInstance().isInstalled(firstPkg, firstVersionCode)) {
                        LogUtils.d("已移除-----"+firstPkg);
                        iterator.remove();
                    }
                }

            }
        }
    }

    private void initNoResViews() {
        mDownloadNoResViewModel.isNoResListFold().observe(this, state -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            List<FileDownloadInfo> noResList = mDownloadNoResViewModel.getNoResListLiveData().getValue();
            if (noResList == null || noResList.isEmpty()){
                return;
            }
            boolean isFold = Boolean.TRUE.equals(state);
            onNoResFoldStateChange(isFold);
        });
        mDownloadNoResViewModel.getNoResListLiveData().observe(this, this::onNoResListChange);
        downloadManageActivityBinding.llUnavailable.getRoot().setVisibility(View.GONE);
        downloadManageActivityBinding.llUnavailable.rvUnavailable.setLayoutManager(new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        downloadManageActivityBinding.llUnavailable.tvUnavailable.setOnClickListener(v -> {
            mDownloadNoResViewModel.isNoResListFold().postValue(Boolean.FALSE);
            int size = 0;
            if (mDownloadNoResViewModel.getNoResListLiveData().getValue() != null) {
                size = mDownloadNoResViewModel.getNoResListLiveData().getValue().size();
            }
            String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "UA", "", "");
            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setItemValue(String.valueOf(size))
                    .setButtonType("unavailable");
            TRAnalysticsUtil.trackClick(builder);
        });
        downloadManageActivityBinding.llUnavailable.tvCollapse.setOnClickListener(v -> {
            mDownloadNoResViewModel.isNoResListFold().postValue(Boolean.TRUE);
            int size = 0;
            if (mDownloadNoResViewModel.getNoResListLiveData().getValue() != null) {
                size = mDownloadNoResViewModel.getNoResListLiveData().getValue().size();
            }
            String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "UA", "", "");
            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setItemValue(String.valueOf(size))
                    .setButtonType("collapse");
            TRAnalysticsUtil.trackClick(builder);
        });
        downloadManageActivityBinding.llUnavailable.tvClearAll.setOnClickListener(new TRNoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                LogUtils.d("DownloadNoRes", "onNoDoubleClick");
                onClearAll();
            }
        });
    }

    private void onNoResListChange(List<FileDownloadInfo> noResList) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        if (noResList == null || noResList.isEmpty()) {
            hideNoResList(); // 无不可下载数据
        } else {
            int size = noResList.size();
            LogUtils.d("DownloadNoRes", "noResList:" + size);
            updateNoResListCount(size);
            showNoResList();
        }
    }

    private void hideNoResList(){
        downloadManageActivityBinding.llUnavailable.getRoot().setVisibility(View.GONE);
    }

    private void showNoResList(){
        downloadManageActivityBinding.llUnavailable.getRoot().setVisibility(View.VISIBLE);
        boolean isFold = Boolean.TRUE.equals(mDownloadNoResViewModel.isNoResListFold().getValue());
        onNoResFoldStateChange(isFold);
    }

    private void onNoResFoldStateChange(boolean isFold){
        if (isFold){
            foldUpNoResList();
        } else {
            unfoldNoResList();
        }
    }

    private void foldUpNoResList(){
        downloadManageActivityBinding.llUnavailable.tvUnavailable.setVisibility(View.VISIBLE);
        downloadManageActivityBinding.llUnavailable.llUnavailableList.setVisibility(View.GONE);
        downloadManageActivityBinding.llUnavailable.tvCollapse.setVisibility(View.GONE);
    }

    private void unfoldNoResList(){
        downloadManageActivityBinding.llUnavailable.tvUnavailable.setVisibility(View.GONE);
        downloadManageActivityBinding.llUnavailable.llUnavailableList.setVisibility(View.VISIBLE);
        downloadManageActivityBinding.llUnavailable.tvCollapse.setVisibility(View.VISIBLE);
        updateNoResListAdapter();
    }

    private void updateNoResListAdapter() {
        List<FileDownloadInfo> noResList = mDownloadNoResViewModel.getNoResListLiveData().getValue();
        downloadNoResAdapter = new DownloadNoResAdapter(this, noResList, getOnItemDeleteListener());
        downloadManageActivityBinding.llUnavailable.rvUnavailable.swapAdapter(downloadNoResAdapter, false);
    }

    private void updateNoResListCount(int count) {
        String display = this.getString(R.string.download_unavailable_list, "" + count);
        downloadManageActivityBinding.llUnavailable.tvUnavailable.setText(display);
        downloadManageActivityBinding.llUnavailable.tvUnavailableStart.setText(display);
    }

    private DownloadNoResAdapter.OnItemDeleteListener getOnItemDeleteListener() {
        if (onItemDeleteListener == null) {
            onItemDeleteListener = (pos) -> {
                if (downloadNoResAdapter != null) {
                    FileDownloadInfo info = downloadNoResAdapter.getItemById(pos);
                    if (info != null) {
                        LogUtils.d("DownloadNoRes", info.packageName + " pos:" + pos);
                        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
                            deleteNoResTask(info, pos);
                        } else {
                            final DialogBuilder mDialogBuilder = new DialogBuilder();
                            new CustomDialog(ManageDownloadActivity.this).showCheckBoxFunctionDialog(
                                    mDialogBuilder
                                            .hideTitle()
                                            .setMessage(ManageDownloadActivity.this.getString(R.string.delete_task))
                                            .setCheckBoxChecked(false)
                                            .setCheckBoxText(ManageDownloadActivity.this.getString(R.string.no_again))
                                            .setNegativeBtnText(ManageDownloadActivity.this.getString(R.string.text_cancel))
                                            .setPositiveBtnText(ManageDownloadActivity.this.getString(R.string.text_ok))
                                            .setPositiveBtnOnClickListener(new View.OnClickListener() {

                                                @Override
                                                public void onClick(View view) {
                                                    SPManager.putBoolean(Constant.preferences_delete_tips_downloading_record, mDialogBuilder.isCheckBoxChecked());
                                                    deleteNoResTask(info, pos);
                                                }
                                            }));
                        }
                    }
                }
            };
        }
        return onItemDeleteListener;
    }

    private void deleteNoResTask(FileDownloadInfo info, int pos) {
        if (info == null) {
            return;
        }
        mDownloadNoResViewModel.deleteNoResTask(info);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.getDeletePageParamInfo(mPageParamInfo, info.type));

        String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "", "UA", String.valueOf(pos));
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(info.itemID)
                .setButtonType(TRAnalyticsConstant.DELETE)
                .setItemValue(info.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private void onClearAll(){
        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
            clearAllNoResTasks();
        } else {
            final DialogBuilder mDialogBuilder = new DialogBuilder();
            new CustomDialog(ManageDownloadActivity.this).showCheckBoxFunctionDialog(
                    mDialogBuilder
                            .hideTitle()
                            .setMessage(ManageDownloadActivity.this.getString(R.string.download_dialog_clear_all_tips))
                            .setCheckBoxChecked(false)
                            .setCheckBoxText(ManageDownloadActivity.this.getString(R.string.no_again))
                            .setNegativeBtnText(ManageDownloadActivity.this.getString(R.string.text_cancel))
                            .setPositiveBtnText(ManageDownloadActivity.this.getString(R.string.text_ok))
                            .setPositiveBtnOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View view) {
                                    SPManager.putBoolean(Constant.preferences_delete_tips_downloading_record, mDialogBuilder.isCheckBoxChecked());
                                    clearAllNoResTasks();
                                }
                            }));
        }
    }

    private void clearAllNoResTasks() {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "CA", "", "");
        mDownloadNoResViewModel.clearAllNoResTasks(value, mFrom);
    }

}

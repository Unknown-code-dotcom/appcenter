package com.afmobi.palmplay.cloudfolder.view

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderRemoteController
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_CENTER
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.PaletteControls
import com.afmobi.palmplay.cloudfolder.utils.drawableToBitmap
import com.afmobi.palmplay.cloudfolder.utils.getSafeString
import com.afmobi.palmplay.customview.DownloadStatusView
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.download.InterfaceStatusChange
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.shape.ShapeAppearanceModel
import com.transsion.palmstorecore.bitmap.TRBitmapManager
import com.afmobi.palmplay.cloudfolder.utils.CloudFolderLauncher
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.DownloadUtil
import com.transsion.palmstorecore.glide.GlideApp
import com.transsion.palmstorecore.glide.GlideUtils
import com.afmobi.palmplay.shortcuts.ShortcutsGridAdapter
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.GsonUtils
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.model.FileFolderAdTrackData
import com.transsnet.store.R
import java.util.WeakHashMap

/**
 * 固定榜单区域自定义 View
 * 封装3个榜单条目，用于样式2/3 且 fixRankTile=true 时展示
 * 在 RecyclerView 上方固定显示，不随列表滚动
 *
 * 支持下载状态监听：通过 DownloadStatusManager 注册 InterfaceStatusChange，
 * 实时更新条目的下载进度、状态文案和 UI 样式。
 */
class FixedRankSectionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    companion object {
        private const val TAG = "FixedRankSectionView"
    }

    private val rankItemsLayout: LinearLayout
    private val rankItemViews: List<View>
    private val defaultIconShapeAppearances =
        WeakHashMap<ShapeableImageView, ShapeAppearanceModel>()
    private val paletteControls: PaletteControls by lazy {
        PaletteControls.getInstance(PalmplayApplication.getAppInstance())
    }

    private val isShowMark: Boolean by lazy {
        CloudFolderManager.getInstance().isIconMaskShow()
    }

    private val markAlpha: Float by lazy {
        CloudFolderManager.getInstance().getCloudFolderDownAlpha()
    }

    /** 当前绑定的榜单应用列表 */
    private var rankApps: List<CloudAppInfo> = emptyList()

    private var adxTriggerId = ""

    /** 分类类型（APP/GAME） */
    var categoryType: Int = CATEGORY_APP

    /** 当前云文件夹布局样式（由宿主 Fragment 注入），用于埋点 sty 字段 */
    var layoutStyle: Int = CloudFolderTrackUtil.STY_DEFAULT

    /** 外部设置的条目点击回调 */
    var onRankItemClickListener: ((index: Int, appInfo: CloudAppInfo) -> Unit)? = null

    /** 外部设置的条目长按回调 */
    var onRankItemLongClickListener: ((view: View, index: Int, appInfo: CloudAppInfo) -> Unit)? = null

    /** 下载状态监听回调 */
    private val statusChangeListener = object : InterfaceStatusChange {
        override fun onDownloadStart(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onDownloadStart: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onDownloadProgressUpdate(
            downloadInfo: FileDownloadInfo,
            downloadedBytes: Long,
            fileLength: Long,
            speed: Int
        ) {
            LogUtils.d(TAG, "onDownloadProgressUpdate: pkg=${downloadInfo.packageName}, downloaded=$downloadedBytes, total=$fileLength, speed=$speed")
            updateProgressByDownloadInfo(downloadInfo)
        }

        override fun onDownloadComplete(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onDownloadComplete: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onActivated(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onActivated: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onDownloadError(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onDownloadError: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onDownloadPause(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onDownloadPause: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onDownloadResume(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onDownloadResume: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onDownloadDelete(downloadInfo: FileDownloadInfo) {
            LogUtils.d(TAG, "onDownloadDelete: pkg=${downloadInfo.packageName}, status=${downloadInfo.downloadStatus}")
            refreshItemByDownloadInfo(downloadInfo, null)
        }

        override fun onAppPackageAdded(packageName: String, versionCode: Int) {
            LogUtils.d(TAG, "onAppPackageAdded: pkg=$packageName, vc=$versionCode")
            refreshItemByDownloadInfo(null, packageName)
        }

        override fun onAppPackageRemoved(packageName: String, versionCode: Int, modifyStatusFrom: Int) {
            LogUtils.d(TAG, "onAppPackageRemoved: pkg=$packageName, vc=$versionCode, from=$modifyStatusFrom")
            refreshItemByDownloadInfo(null, packageName)
        }
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        clipChildren = false
        clipToPadding = false
        inflate(context, R.layout.layout_fixed_rank_section, this)
        rankItemsLayout = findViewById(R.id.layoutRankItems)
        rankItemsLayout.clipChildren = false
        rankItemsLayout.clipToPadding = false
        rankItemsLayout.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            alignRankItemsLayoutToCenter()
        }
        rankItemViews = listOf(
            findViewById(R.id.rankItem1),
            findViewById(R.id.rankItem2),
            findViewById(R.id.rankItem3)
        )
    }

    /**
     * 绑定数据到固定榜单区域
     * @param rankApps 榜单应用列表（最多3个）
     */
    fun bindData(rankApps: List<CloudAppInfo>, contentHostWidth: Int = 0) {
        this.rankApps = rankApps
        LogUtils.d(TAG, "bindData: size=${rankApps.size}, pkgs=${rankApps.map { it.packageName }}, statuses=${rankApps.map { it.observerStatus }}")

        if (rankApps.isEmpty()) {
            visibility = GONE
            return
        }

        visibility = VISIBLE

        // 绑定每个条目
        rankItemViews.forEachIndexed { index, itemView ->
            if (index < rankApps.size) {
                itemView.visibility = VISIBLE
                bindRankItem(itemView, index, rankApps[index])
            } else {
                itemView.visibility = GONE
            }
        }
        refreshPadItemSpacing(contentHostWidth)
    }

    override fun onSizeChanged(width: Int, height: Int, oldWidth: Int, oldHeight: Int) {
        super.onSizeChanged(width, height, oldWidth, oldHeight)
        // 仅在已有宽度后发生变化时重排（转屏）。首次 0→实测宽若再 post，会在首帧 wrap_content 后再拉伸。
        if (oldWidth > 0 && oldWidth != width) {
            post { updateRankItemSpacingForPad() }
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        alignRankItemsLayoutToCenter()
    }

    /**
     * 横竖屏切换后按最新测量宽度重排榜单。
     * @param contentHostWidth 与下方四列 RecyclerView 相同的内容宽度；0 表示按自身宽度回退。
     */
    fun refreshPadItemSpacing(contentHostWidth: Int = 0) {
        if (!shouldCenterPadRankList()) {
            return
        }
        val hostWidth = resolvePadRankHostWidth(contentHostWidth)
        updateRankItemSpacingForPad(hostWidth)
        if (isLaidOut) {
            alignRankItemsLayoutToCenter()
        }
    }

    private fun resolvePadRankHostWidth(contentHostWidth: Int): Int {
        if (contentHostWidth > 0) return contentHostWidth
        if (width > 0) return width
        val parentView = parent as? View
        val parentWidth = if (parentView != null && parentView.width > 0) {
            parentView.width - parentView.paddingLeft - parentView.paddingRight
        } else {
            0
        }
        if (parentWidth > 0) return parentWidth
        val desiredWidth = DeviceProfile.getInstance().getDesiredWidth()
        val listSideMargin = resources.getDimensionPixelSize(R.dimen.dp_20)
        if (desiredWidth > listSideMargin * 2) {
            return desiredWidth - listSideMargin * 2
        }
        return DeviceProfile.getInstance().getPadSearchAlignedContentWidth(resources)
    }

    private fun shouldCenterPadRankList(): Boolean {
        if (!DeviceProfile.getInstance().isPadLayout) return false
        if (rankItemViews.count { it.visibility == VISIBLE } != 3) return false
        return layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST ||
                layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_GRID
    }

    /** 相对 FixedRankSectionView 整体居中，而不是内部 wrap_content 的 wrapper。 */
    private fun alignRankItemsLayoutToCenter() {
        if (!shouldCenterPadRankList()) {
            rankItemsLayout.translationX = 0f
            return
        }
        if (width <= 0 || rankItemsLayout.width <= 0) {
            return
        }
        var leftInSection = 0
        var current: View? = rankItemsLayout
        while (current != null && current != this) {
            leftInSection += current.left
            current = current.parent as? View
        }
        val translationX = (width - rankItemsLayout.width) / 2f - leftInSection
        rankItemsLayout.translationX = translationX
    }

    /** Pad 样式 2/3 的榜单共用样式 3 的内容宽度和条目间距。 */
    private fun updateRankItemSpacingForPad(contentHostWidth: Int = 0) {
        if (!shouldCenterPadRankList()) {
            return
        }
        val availableWidth = resolvePadRankHostWidth(contentHostWidth)
        if (availableWidth <= 0) {
            return
        }
        val contentWidth = minOf(
            availableWidth.coerceAtLeast(0),
            DeviceProfile.getInstance().getPadSearchAlignedContentWidth(resources)
        )
        applyPadRankContentWidth(contentWidth)
        applyPadRankItemMargins(contentWidth)
    }

    private fun applyPadRankContentWidth(contentWidth: Int) {
        (rankItemsLayout.parent as? View)?.takeIf { it != this }?.let { wrapper ->
            val wrapperParams = wrapper.layoutParams
            if (wrapperParams != null && wrapperParams.width != LayoutParams.MATCH_PARENT) {
                wrapperParams.width = LayoutParams.MATCH_PARENT
                wrapper.layoutParams = wrapperParams
            }
        }
        val params = rankItemsLayout.layoutParams as? LayoutParams ?: return
        val gravityChanged = params.gravity != Gravity.CENTER_HORIZONTAL
        if (params.width != contentWidth || gravityChanged) {
            params.width = contentWidth
            params.gravity = Gravity.CENTER_HORIZONTAL
            rankItemsLayout.layoutParams = params
            rankItemsLayout.requestLayout()
        }
        rankItemsLayout.gravity = Gravity.START
    }

    private fun applyPadRankItemMargins(contentWidth: Int) {
        val rankItemWidth = padRankItemWidth()
        val rankSideMargin = 0
        val rankGap = ((contentWidth - rankItemWidth * 3) / 2).coerceAtLeast(0)
        rankItemViews.forEachIndexed { index, itemView ->
            (itemView.layoutParams as? LayoutParams)?.let { params ->
                val marginStart = if (index == 0) rankSideMargin else 0
                val marginEnd = if (index < rankItemViews.lastIndex) rankGap else 0
                if (params.width != rankItemWidth ||
                    params.marginStart != marginStart ||
                    params.marginEnd != marginEnd
                ) {
                    params.width = rankItemWidth
                    params.marginStart = marginStart
                    params.marginEnd = marginEnd
                    itemView.layoutParams = params
                }
            }
        }
    }

    /** Pad 榜单条目宽：卡片 88dp + 投影左右内缩留白。 */
    private fun padRankItemWidth(): Int {
        val baseWidth = resources.getDimensionPixelSize(R.dimen.dp_88)
        if (!DeviceProfile.getInstance().isPadLayout ||
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P
        ) {
            return baseWidth
        }
        val shadowRadius = resources.getDimension(R.dimen.ps_cloud_folder_pad_rank_shadow_radius)
        return baseWidth + shadowRadius.toInt() * 2
    }

    fun refreshIconStyle() {
        rankItemViews.forEachIndexed { index, itemView ->
            rankApps.getOrNull(index)?.let { bindRankItem(itemView, index, it) }
        }
    }

    /**
     * 注册下载状态监听
     * 应在 Fragment/Activity 的 onStart 中调用
     */
    fun registerDownloadListener() {
        LogUtils.d(TAG, "registerDownloadListener: this=${this.hashCode()}, rankApps.size=${rankApps.size}, pkgs=${rankApps.map { it.packageName }}")
        DownloadStatusManager.getInstance().putStatusChangeListener(this, statusChangeListener)
    }

    /**
     * 注销下载状态监听
     * 应在 Fragment/Activity 的 onStop 中调用
     */
    fun unregisterDownloadListener() {
        LogUtils.d(TAG, "unregisterDownloadListener: this=${this.hashCode()}")
        DownloadStatusManager.getInstance().removeStatusChangeListener(this)
    }

    /**
     * 绑定单个榜单条目的数据
     */
    private fun applyPadRankCardBackground(itemView: View) {
        if (!DeviceProfile.getInstance().isPadLayout) return
        val bg = itemView.findViewById<View>(R.id.layoutBottomBg) ?: return
        val res = bg.resources
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            bg.setBackgroundResource(R.drawable.bg_cloud_folder_rank_bottom_14dp_pad)
            return
        }
        val shadowRadius = res.getDimension(R.dimen.ps_cloud_folder_pad_rank_shadow_radius)
        val offsetY = res.getDimension(R.dimen.ps_cloud_folder_pad_rank_shadow_dy)
        val cornerRadius = res.getDimension(R.dimen.dp_14)
        val baseWidth = res.getDimensionPixelSize(R.dimen.dp_88)
        val baseHeight = res.getDimensionPixelSize(R.dimen.dp_84)
        val insetH = shadowRadius.toInt()
        val insetTop = (shadowRadius - offsetY).toInt().coerceAtLeast(0)
        val insetBottom = (shadowRadius + offsetY).toInt()
        val cardWidth = baseWidth + insetH * 2
        val cardHeight = baseHeight + insetTop + insetBottom
        bg.layoutParams = bg.layoutParams?.apply {
            width = cardWidth
            height = cardHeight
        }
        // include 固定 88dp，需放宽条目宽度，否则投影被裁切
        itemView.layoutParams = itemView.layoutParams?.apply {
            width = cardWidth
        }
        (itemView as? ViewGroup)?.apply {
            clipChildren = false
            clipToPadding = false
        }
        bg.background = PadRankCardShadowDrawable(
            shadowRadius = shadowRadius,
            cornerRadius = cornerRadius,
            bgColor = ContextCompat.getColor(bg.context, R.color.color_cloud_folder_rank_bg_pad),
            shadowColor = ContextCompat.getColor(bg.context, R.color.color_cloud_folder_rank_shadow_pad),
            offsetY = offsetY
        )
    }

    /** Pad 榜单标题到星星间距；手机保持 XML 的 3dp。 */
    private fun applyPadRankNameStarGap(ratingBar: View?) {
        if (ratingBar == null || !DeviceProfile.getInstance().isPadLayout) return
        val params = ratingBar.layoutParams as? ViewGroup.MarginLayoutParams ?: return
        val target = ratingBar.resources.getDimensionPixelSize(
            R.dimen.ps_cloud_folder_pad_rank_name_star_gap
        )
        if (params.topMargin != target) {
            params.topMargin = target
            ratingBar.layoutParams = params
        }
    }

    private fun bindRankItem(itemView: View, index: Int, appInfo: CloudAppInfo) {
        // 注入页面级别样式，下游埋点与下载链路直接读取 appInfo 即可
        appInfo.layoutStyle = layoutStyle
        applyPadRankCardBackground(itemView)
        val cardIcon = itemView.findViewById<GlobalShapeClipFrameLayout>(R.id.card_icon)
        val itemIcon = itemView.findViewById<ShapeableImageView>(R.id.img_item_icon)
        val itemName = itemView.findViewById<TextView>(R.id.tv_item_name)
        val viewMark = itemView.findViewById<ShapeableImageView>(R.id.view_mark)
        val ivDefaultIcon = itemView.findViewById<ImageView>(R.id.iv_default_icon)
        val ivRankBadge = itemView.findViewById<ImageView>(R.id.ivRankBadge)
        val statusView = itemView.findViewById<DownloadStatusView>(R.id.statusView)
        val ratingBar = itemView.findViewById<com.afmobi.palmplay.customview.ratingbar.AndRatingBar>(R.id.layoutStarRating)
        val remoteController = CloudFolderRemoteController.getInstance()
        val isPreInstallItem = appInfo.isPreInstallItem()
        val isDynamicIcon = !isPreInstallItem && appInfo.isDynamicIcon()
        val useGlobalShape = remoteController.hasGlobalIconShape()

        cardIcon.setGlobalIconShapePath(
            if (useGlobalShape) remoteController.getGlobalIconShapePath() else null
        )
        statusView?.setClipToOutline(!useGlobalShape)
        updateIconShapeAppearance(itemIcon, useGlobalShape)
        updateIconShapeAppearance(viewMark, useGlobalShape)

        // 注册下载状态实例
        DownloadStatusManager.getInstance().registerInfoInstance(appInfo)

        // 设置星级
        ratingBar?.rating = appInfo.star.toFloat()
        applyPadRankNameStarGap(ratingBar)

        // 设置皇冠徽章
        val crownRes = when (index) {
            0 -> R.drawable.ic_cloud_folder_gold
            1 -> R.drawable.ic_cloud_folder_silver
            2 -> R.drawable.ic_cloud_folder_bronze
            else -> 0
        }
        if (crownRes != 0) {
            ivRankBadge?.setImageResource(crownRes)
            ivRankBadge?.visibility = View.VISIBLE
        } else {
            ivRankBadge?.visibility = View.GONE
        }


        // 更新名称、状态、遮罩 UI（合并了 bindMark 逻辑）
        updateItemStatus(appInfo, itemName, itemIcon, ivDefaultIcon, statusView, viewMark)
        if (useGlobalShape) {
            itemIcon.setBackgroundResource(0)
        }

        // 加载图标
        if (isPreInstallItem) {
            drawableToBitmap(appInfo.drawable)?.apply {
                itemIcon.setImageBitmap(
                    remoteController.getCloudThemeIcon(context, this)
                )
            }
        } else {
            val iconUrl = if (isDynamicIcon) appInfo.dynamicIconUrl else appInfo.iconUrl

            GlideApp.with(PalmplayApplication.getAppInstance())
                .load(iconUrl)
                .apply(GlideUtils.newCommonRequestOptions())
                .addListener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        if (resource == null) return false
                        if (isDynamicIcon) {
                            itemIcon.setImageDrawable(resource)
                            if (resource is android.graphics.drawable.Animatable) {
                                resource.start()
                            }
                        } else {
                            val bitmap = ShortcutsGridAdapter.drawableToBitmap(resource)
                            val resultBitmap = if (remoteController.hasGlobalIconShape()) {
                                bitmap
                            } else {
                                TRBitmapManager.mergeBitmap(bitmap, R.drawable.shortcut_icon_items_bg)
                            }
                            if (resultBitmap == null || resultBitmap.isRecycled) return false
                            itemIcon.setImageBitmap(
                                remoteController.getCloudThemeIcon(context, resultBitmap)
                            )
                        }
                        appInfo.hasLoaded = true
                        if (appInfo.observerStatus == FileDownloadInfo.STATUS_NONE || appInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
                            ivDefaultIcon?.visibility = View.VISIBLE
                        } else {
                            ivDefaultIcon?.visibility = View.GONE
                        }
                        return true
                    }
                })
                .into(itemIcon)
        }

        // 点击事件（模拟 CloudShortcutAdapter.bindClickEvents 逻辑）
        itemView.tag = index
        itemView.setOnLongClickListener { v ->
            onRankItemLongClickListener?.invoke(v, index, appInfo)
            true
        }
        itemView.setOnClickListener(OnClickListener {
            if (appInfo.isPreInstallItem()) {
                CloudFolderLauncher.launchFromPreInstall(appInfo)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_OPEN_APP, appInfo, index, appInfo.jumpType)
                return@OnClickListener
            }
            if (appInfo.isOtherType()) {
                val launchType = CloudFolderLauncher.launchFromOtherType(appInfo)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_INSTALL, appInfo, index, appInfo.jumpType, launchType)
                return@OnClickListener
            }
            if (appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING) {
                return@OnClickListener
            }
            if (FileDownloadInfo.isDownloading(appInfo.observerStatus)) {
                DownloadManager.getInstance().onDownloadingPauseByUser(appInfo.packageName, false, true)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_PAUSE, appInfo, index)
                onRankItemClickListener?.invoke(index, appInfo)
            } else if (FileDownloadInfo.STATUS_PAUSE == appInfo.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == appInfo.observerStatus) {
                DownloadUtil.resumeDownload(context, appInfo.packageName)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_RESUME, appInfo, index)
            } else {
                if (FileDownloadInfo.STATUS_NONE == appInfo.observerStatus) {
                    trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_INSTALL, appInfo, index)
                }
                val sign = if (categoryType == CATEGORY_APP) "A" else "G"
                val fromPage = "FL_${sign}_${SCENE_CENTER}_$index"
                CloudFolderManager.getInstance().startDownload(appInfo, categoryType, fromPage)
            }
        })
    }

    private fun updateIconShapeAppearance(
        itemIcon: ShapeableImageView,
        useGlobalShape: Boolean
    ) {
        val defaultShape = defaultIconShapeAppearances.getOrPut(itemIcon) {
            itemIcon.shapeAppearanceModel
        }
        itemIcon.shapeAppearanceModel = if (useGlobalShape) {
            defaultShape.toBuilder().setAllCornerSizes(0f).build()
        } else {
            defaultShape
        }
    }

    // ==================== 下载状态处理 ====================

    /**
     * 根据下载信息或包名查找匹配的条目并刷新
     */
    private fun refreshItemByDownloadInfo(downloadInfo: FileDownloadInfo?, packageName: String?) {
        val matchIndex = findMatchingIndex(downloadInfo, packageName)
        LogUtils.d(TAG, "refreshItemByDownloadInfo: pkg=${downloadInfo?.packageName ?: packageName}, matchIndex=$matchIndex, rankApps.size=${rankApps.size}")
        if (matchIndex < 0 || matchIndex >= rankApps.size) {
            LogUtils.w(TAG, "refreshItemByDownloadInfo: no match, skip refresh")
            return
        }

        val appInfo = rankApps[matchIndex]
        // 更新 observerStatus
        if (downloadInfo != null) {
            DownloadStatusManager.checkObserverData(rankApps, downloadInfo, true)
        } else if (!packageName.isNullOrEmpty()) {
            DownloadStatusManager.checkObserverDataWithTypeApp(rankApps, packageName, true)
        }
        DownloadStatusManager.getInstance().registerInfoInstance(appInfo)
        LogUtils.d(TAG, "refreshItemByDownloadInfo: after update, pkg=${appInfo.packageName}, observerStatus=${appInfo.observerStatus}, progress=${appInfo.progress}")

        // 刷新对应条目 UI
        val itemView = rankItemViews.getOrNull(matchIndex) ?: return
        val itemName = itemView.findViewById<TextView>(R.id.tv_item_name)
        val ivDefaultIcon = itemView.findViewById<ImageView>(R.id.iv_default_icon)
        val statusView = itemView.findViewById<DownloadStatusView>(R.id.statusView)
        val viewMark = itemView.findViewById<ImageView>(R.id.view_mark)
        val itemIcon = itemView.findViewById<ImageView>(R.id.img_item_icon)

        updateItemStatus(appInfo, itemName, itemIcon, ivDefaultIcon, statusView, viewMark)
    }

    /**
     * 更新下载进度（高频回调，仅更新进度条）
     */
    private fun updateProgressByDownloadInfo(downloadInfo: FileDownloadInfo) {
        val matchIndex = findMatchingIndex(downloadInfo, null)
        if (matchIndex < 0 || matchIndex >= rankApps.size) {
            LogUtils.w(TAG, "updateProgressByDownloadInfo: no match, pkg=${downloadInfo.packageName}, rankApps.pkgs=${rankApps.map { it.packageName }}")
            return
        }

        val appInfo = rankApps[matchIndex]
        val progress = downloadInfo.downloadedSize / downloadInfo.sourceSize.toFloat()
        appInfo.progress = progress

        val itemView = rankItemViews.getOrNull(matchIndex) ?: return
        val statusView = itemView.findViewById<DownloadStatusView>(R.id.statusView)
        LogUtils.d(TAG, "updateProgressByDownloadInfo: pkg=${appInfo.packageName}, progress=$progress, statusViewVisibility=${statusView?.visibility}")
        statusView?.setProgress(progress)
    }

    /**
     * 在 rankApps 中查找与 downloadInfo/packageName 匹配的条目索引
     */
    private fun findMatchingIndex(downloadInfo: FileDownloadInfo?, packageName: String?): Int {
        val targetPkg = downloadInfo?.packageName ?: packageName ?: return -1
        return rankApps.indexOfFirst {
            !TextUtils.isEmpty(it.packageName) && it.packageName == targetPkg
        }
    }

    /**
     * 更新条目的下载状态 UI（文案、进度、遮罩）
     * 参考 CloudShortcutAdapter.checkStatus 逻辑
     */
    private fun updateItemStatus(
        appInfo: CloudAppInfo,
        itemName: TextView,
        itemIcon: ImageView,
        ivDefaultIcon: ImageView?,
        statusView: DownloadStatusView?,
        markView: ImageView?
    ) {
        when (appInfo.observerStatus) {
            FileDownloadInfo.STATUS_NONE -> {
                itemName.text = appInfo.name
                statusView?.setProgress(0f)
            }
            FileDownloadInfo.STATUS_WAIT -> {
                itemName.text = PalmplayApplication.getAppInstance()
                    .getSafeString(R.string.waiting, useSystemLanguage = true)
            }
            FileDownloadInfo.STATUS_DOWNING, FileDownloadInfo.STATUS_NETWORK_ERROR -> {
                itemName.text = PalmplayApplication.getAppInstance()
                    .getSafeString(R.string.text_downloading, useSystemLanguage = true)
            }
            FileDownloadInfo.STATUS_PAUSE -> {
                itemName.text = PalmplayApplication.getAppInstance()
                    .getSafeString(R.string.paused, useSystemLanguage = true)
            }
            FileDownloadInfo.STATUS_DOWNLOADED -> {
                itemName.text = PalmplayApplication.getAppInstance()
                    .getSafeString(R.string.click_install, useSystemLanguage = true)
            }
            FileDownloadInfo.STATUS_INSTALLING -> {
                itemName.text = PalmplayApplication.getAppInstance()
                    .getSafeString(R.string.text_installing, useSystemLanguage = true)
            }
            FileDownloadInfo.STATUS_APP_INSTALLED, FileDownloadInfo.STATUS_APP_UPDATE -> {
                itemName.text = appInfo.name
            }
        }
        paletteControls.updateTextShadow(itemName)

        // 下载图标可见性
        if (appInfo.observerStatus != FileDownloadInfo.STATUS_NONE && appInfo.observerStatus != FileDownloadInfo.STATUS_APP_UPDATE) {
            ivDefaultIcon?.visibility = View.GONE
        } else {
            if (appInfo.hasLoaded) {
                ivDefaultIcon?.visibility = View.VISIBLE
            }
        }

        // 图标背景 + 遮罩 + 进度条（合并 bindMark 逻辑）
        val isActiveDownload = appInfo.observerStatus == FileDownloadInfo.STATUS_WAIT
                || appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING
                || appInfo.observerStatus == FileDownloadInfo.STATUS_PAUSE
                || appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED
                || appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING
                || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR
        if (isActiveDownload) {
            statusView?.visibility = View.VISIBLE
            markView?.visibility = View.GONE
            statusView?.setStatus(appInfo.observerStatus, true)
            if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING
                || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
                statusView?.setProgress(appInfo.progress)
            }
        } else {
            statusView?.visibility = View.GONE
        }

        // 遮罩和背景控制
        if (appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
            itemIcon.setBackgroundResource(R.drawable.shortcut_icon_bg)
            if (!isActiveDownload && isShowMark) {
                markView?.visibility = View.VISIBLE
                markView?.alpha = markAlpha
            } else {
                markView?.visibility = View.GONE
            }
        } else {
            itemIcon.setBackgroundResource(0)
            markView?.visibility = View.GONE
        }
    }

    /**
     * 获取当前绑定的榜单条目数量
     */
    fun getRankItemCount(): Int = rankApps.size

    /**
     * 上报固定榜单区域的曝光埋点（rk = 1）。
     * 由宿主 Fragment 在 onResume 时机统一调用，避免每次 bindData/scroll 重复上报。
     */
    fun reportRankExposure(enterFrom: Int) {
        if (visibility != VISIBLE || rankApps.isEmpty()) return
        rankApps.forEachIndexed { index, appInfo ->
            var adType = 0
            if (appInfo.isOffer == Constants.IS_ADX && FileDownloadInfo.STATUS_NONE == appInfo.observerStatus) {
                adType = 1
                if (TextUtils.isEmpty(adxTriggerId)) {
                    adxTriggerId = CloudFolderManager.getInstance().generateTriggerId()
                }
                val trackList = arrayListOf(
                    FileFolderAdTrackData(
                        appInfo.packageName,
                        adxTriggerId,
                        CloudFolderManager.getInstance().generateShowId()
                    )
                )
                CloudFolderManager.getInstance().uploadAdxExposure(GsonUtils.getInstance().toJson(trackList), categoryType)
            }
            CloudFolderTrackUtil.businessItemExposureTrack(
                index,
                appInfo.packageName,
                CloudFolderTrackUtil.getDownloadStatus(appInfo.observerStatus),
                enterFrom,
                categoryType,
                adType,
                appInfo.jumpType,
                sceneTag = SCENE_CENTER,
                cfValue = appInfo.getCloudStyleString(),
            )
        }
    }

    /**
     * 隐藏并重置
     */
    fun hide() {
        visibility = GONE
    }

    fun onPause() {
        adxTriggerId = ""
    }

    // ==================== 辅助方法 ====================

    private fun trackClickWithParams(eventName: String, appInfo: CloudAppInfo, position: Int, turnType: Int = 0, ctj: String? = null) {
        CloudFolderTrackUtil.businessItemClickTrack(
            position,
            eventName,
            appInfo.packageName,
            categoryType,
            appInfo.isOffer,
            turnType,
            ctj,
            cfValue = appInfo.getCloudStyleString(),
        )
    }
}

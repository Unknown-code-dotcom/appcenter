package com.afmobi.palmplay.activate.state;

/**
 * 后续所有新增弹框，需在此处注册SceneId
 */
public class TRPopUpScene {

    public static final String POP_UP_FILE_FOLDER = "FileFolder";
    public static final String POP_UP_MUST_INSTALL = "MustInstall";
    public static final String POP_UP_RECOMMOND_INSTALL = "RecommondInstall";
    public static final String POP_UP_APP_UPDATE = "AppUpdate";
    public static final String POP_UP_TIP_ACTIVATE = "TipActivate";
    public static final String POP_UP_GUIDE_WIDGE = "guideWidge";


    public static final String POP_UP_NOTIFICATION_TOGGLE = "NotificatoinToggle";
    public static final String POP_UP_NAV_ACTIVATE = "navActivate";
    public static final String POP_UP_DISK_SPACE_LIMIT = "DiskSpaceLimit";
    public static final String POP_UP_SPLASH_ACTIVATE = "SplashActivate";
    public static final String POP_UP_TIP_NETWORK = "TipNetwork";
    public static final String POP_UP_USER_DIALOG = "UserDialog";
    public static final String POP_UP_PET_GUIDE = "PetGuide";
    public static final String POP_UP_INSTANT_GAME_GUIDE = "InstantGameGuide";
    public static final String POP_UP_PRIVACY_POLICY = "PrivacyPolicy";

    public static final String POP_UP_OFFLINE_MORE_GUIDE = "OfflineMoreGuide";
}

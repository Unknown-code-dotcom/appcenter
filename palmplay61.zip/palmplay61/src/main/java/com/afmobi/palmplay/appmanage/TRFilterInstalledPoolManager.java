package com.afmobi.palmplay.appmanage;

import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.RankModel;
import com.transsion.palmstorecore.util.TRStringUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/***
 * created by yongli
 * 首页下沉
 */
public class TRFilterInstalledPoolManager {
    private static volatile TRFilterInstalledPoolManager mInstance;
    private ConcurrentHashMap<String, List<RankDataListItem>> mValidPools;
    private List<RankModel> mRankList; // 要展现的数据
    private List<RankModel> mTempList;//临时数据
    private List<RankModel> mRankListBackUp; //预留的数据
    private  List<String> mNameFlag;

    public TRFilterInstalledPoolManager() {
        mValidPools = new ConcurrentHashMap<>();
        mRankList = new ArrayList<>();
        mNameFlag = new ArrayList<>();
        mRankListBackUp = new ArrayList<>();
        mTempList = new ArrayList<>();
    }

    public static TRFilterInstalledPoolManager getmInstance() {
        if (mInstance == null) {
            synchronized(TRFilterInstalledPoolManager.class) {
                if (mInstance == null) {
                    mInstance = new TRFilterInstalledPoolManager();
                }
            }
        }
        return mInstance;
    }

    /***
     * 过滤每个类别要展示的行数
     * @param list
     */
    public List<RankModel> filterShow(List<RankModel> list, boolean refresh) {
        if (list == null || list.size() <= 0) {
            return null;
        }
        if (mRankListBackUp != null) {
            mRankListBackUp.clear();
        }
        if (mTempList != null) {
            mTempList.clear();
        }
        if (mRankList != null) {
            mRankList.clear();
            mRankList.addAll(list);
        }
        if (mValidPools != null && refresh) { // 下来刷新的时候清除
            mValidPools.clear();
        }
        filterDouble(list);
        if (mRankListBackUp != null) { // 用完就清除，避免短时内暂用内存
            mRankListBackUp.clear();
        }
        //新增滚动样式的数据处理；
        filterScrollRankData();
        return mRankList;
    }

    private void filterScrollRankData() {
        if(mRankList == null || mRankList.size() == 0){
            return;
        }
        for (int i = 0; i < mRankList.size(); i++){
            if(!isNewRollType(mRankList.get(i))){
                continue;
            }
            /*if(!mRankList.get(i).rankData.inner_is_double){
                continue;
            }*/

            //----------------------
            // 先把已安装的数据挑选出来，放入temp
            // 先把原始list的已安装数据移除
            //如果原始数据小于等于12个，再添加到末尾，结束
            //如果原始数据大于12个，移除后的size如果大于12，处理备选池；移除后的数据小于12，从temp里面取数据，把原始list填充够12个，结束
            if(mRankList.get(i).rankData == null || mRankList.get(i).rankData.itemList == null) {
                continue;
            }
            List<RankDataListItem> sourceList = mRankList.get(i).rankData.itemList;
            int sourceSize = sourceList.size();
            if (sourceList == null) {
                continue;
            }
            List<RankDataListItem> tempList = new ArrayList<>(sourceSize);
            for(RankDataListItem item : sourceList){
                if(InstalledAppManager.getInstance().isInstalled(item.packageName, item.version)){
                    tempList.add(item);
                }
            }

            sourceList.removeAll(tempList);
            if(sourceSize <= 12){
                sourceList.addAll(tempList);
            }else {
                if(sourceList.size() > 12){
                    List<RankDataListItem> newList = new ArrayList<>(12);
                    newList.addAll(sourceList.subList(0, 12));
                    mRankList.get(i).rankData.itemList = newList;
                    for(RankDataListItem rankDataListItem : sourceList.subList(12, sourceList.size())){
                        putItemToPools(rankDataListItem, mRankList.get(i).rankData.name);
                    }
                }else {
                    sourceList.addAll(tempList.subList(0, 12 - sourceList.size()));
                }
            }
        }
    }

    private void filterDouble(List<RankModel> list) {
        if (mNameFlag == null || list == null || list.size() <= 0) {
            return;
        }
        for (int m = 0;  m < list.size(); m++) { //动态获取类别的名字，有利于扩展
            if(isNewRollType(list.get(m))){
                continue;
            }
            if (list.get(m) != null && !mNameFlag.contains(list.get(m).rankData.name)) {
                mNameFlag.add(list.get(m).rankData.name);
            }
        }
        if (mNameFlag.size() <= 0) {
            return;
        }
        for (int i = 0 ; i < mNameFlag.size(); i++) { // 动态根据名字进行集合过滤和分类，有利于扩展
            if (mNameFlag.get(i) != null
                    && mNameFlag.get(i) != null
                    && !TRStringUtil.isBlank(mNameFlag.get(i))) {
                int count = 0;
                for (int j = 0; j < list.size(); j++) {
                    if (mNameFlag.get(i).equals(list.get(j).rankData.name)
                            && list.get(j).rankData.inner_is_double
                            && !isNewRollType(list.get(j))) {
                        mTempList.add(list.get(j));
                        count = count + 1;
                    }
                }
                filterShowData(count / 2);
                mTempList.clear();
            }
        }
    }

    /***
     * 删除数据
     * @param name
     * @param packName
     */
    public void deleteValidPoolsItem(String name, String packName) {
        if (TRStringUtil.isBlank(packName)) {
            return;
        }
        if (mValidPools != null && mValidPools.containsKey(name)) {
           for (int i = 0; i < mValidPools.get(name).size(); i ++) {
               if (mValidPools.get(name).get(i) != null && mValidPools.get(name).get(i).packageName.equals(packName)) {
                   mValidPools.get(name).remove(i);
                   break;
               }
           }
        }
    }


    /***
     * 过滤重复的数据进行展现和备选分家
     * @param showRow
     */
    public void filterShowData(int showRow) {
        for (int i = 0; i < mTempList.size(); i++) {
            if (i >= showRow && showRow < mTempList.size()) {
                if (mTempList.get(i) != null && mTempList.get(i).rankData.inner_is_double) {
                    mRankListBackUp.add(mTempList.get(i));
                    mRankList.remove(mTempList.get(i));
                }
            }
        }
        filterInstalledApps();
    }


    /***
     * 根据类别名字取一个有效的item
     * @param name
     * @return
     */
    public RankDataListItem getValidItem(String name) {
        RankDataListItem item;
        if (!TRStringUtil.isBlank(name) && mValidPools != null && mValidPools.containsKey(name)) {
            if (mValidPools.get(name) != null && mValidPools.get(name).size() > 0) { // 永远取第一个，只要存在第一个肯定有，提高取数据的效率
                item = mValidPools.get(name).get(0);
                mValidPools.get(name).remove(0);
                return item;
            }
        }
        return null;
    }

    /***
     * push的兜底 如果推送来的app已被安装就随机从首页备选池子里选一个
     * @return
     */
    public RankDataListItem getValidItemForPush() {
        if (mValidPools == null || mValidPools.size() <= 0 || mValidPools.entrySet() == null) {
            return null;
        }
        RankDataListItem item;
        Iterator i = mValidPools.entrySet().iterator();
        if (i == null) {
            return null;
        }
            try {
                while (i.hasNext()) {
                    Map.Entry entry = (Map.Entry) i.next();
                    if (entry == null) {
                        return null;
                    }
                    String key = (String) entry.getKey();
                    if (!TRStringUtil.isBlank(key) && mValidPools.containsKey(key)) {
                        if (mValidPools.get(key) == null) {
                            return null;
                        }
                        item= mValidPools.get(key).get(0);
                        mValidPools.get(key).remove(0);
                        return item;
                    }
                }

            } catch (Exception e) {
                return null;
            }
        return null;
    }

    /***
     * 获取最终的有效备选池子
     */
    public void filterInstalledApps() {
        if (mRankListBackUp == null || mRankListBackUp.size() <= 0) {
            return;
        }

        for (int i =0 ; i < mRankListBackUp.size(); i++) {
            if (mRankListBackUp.get(i) != null && mRankListBackUp.get(i).rankData != null && mRankListBackUp.get(i).rankData.itemList.size() > 0) {
                for (int n = 0;  n < mRankListBackUp.get(i).rankData.itemList.size(); n ++) {
                    RankDataListItem item = mRankListBackUp.get(i).rankData.itemList.get(n);
                    if (item != null) {
                        if (!InstalledAppManager.getInstance().isInstalled(item.packageName, item.version)) {
                            putItemToPools(item, mRankListBackUp.get(i).rankData.name);
                        }
                    }
                }
            }
        }
    }

    /***
     * 备选的有可能是多个一样的key，需要需要把key唯一，item合并。
     * @param item
     * @param name
     */
    private void putItemToPools(RankDataListItem item, String name) {
        if (mValidPools == null || item == null || TRStringUtil.isBlank(name)) {
            return;
        }
        // 1. key存在 2. 当前key的list不包含着item 3. add这个list中
        if (mValidPools.containsKey(name)) {
            if (!mValidPools.get(name).contains(item)) {
                mValidPools.get(name).add(item);
            }
        } else { // 不存在 当成新的key
            List<RankDataListItem> listItems = new ArrayList<>();
            listItems.add(item);
            mValidPools.put(name, listItems);
        }
    }

    /***
     * 释放资源
     */
    public void releaseResource() {
        if (mRankListBackUp != null) {
            mRankListBackUp.clear();
        }
        if (mNameFlag != null) {
            mNameFlag.clear();
        }
        if (mRankList != null) {
            mRankList.clear();
        }
        if (mValidPools != null) {
            mValidPools.clear();
        }
    }

    /**
     * 7.1.2.3版本添加，新样式判断，下沉逻辑和普通样式有差异
     * @param rankModel
     * @return
     */
    public boolean isNewRollType(RankModel rankModel){
        if(rankModel != null  &&
                (RankStyleType.H_ROLL_TITLE.equals(rankModel.rankData.style)
                        || RankStyleType.V_ROLL_TITLE.equals(rankModel.rankData.style)) || RankStyleType.H_CARD_TITLE.equals(rankModel.rankData.style)){
            return true;
        }
        return false;
    }
}

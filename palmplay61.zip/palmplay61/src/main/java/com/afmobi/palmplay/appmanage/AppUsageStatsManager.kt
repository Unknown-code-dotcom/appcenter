package com.afmobi.palmplay.appmanage

import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import com.transsion.phonehelper.util.LogUtils
import com.transsnet.store.BuildConfig

class AppUsageStatsManager private constructor() {

    @Volatile
    private var useFallbackLaunchCountField = false

    @Volatile
    private var launchCountReflectionUnavailable = false

    companion object {
        @Volatile
        private var instance: AppUsageStatsManager? = null

        @JvmStatic
        fun getInstance(): AppUsageStatsManager {
            return instance ?: synchronized(this) {
                instance ?: AppUsageStatsManager().also { instance = it }
            }
        }
    }

    /**
     * 获取指定时间范围内的应用使用统计
     */
    fun getUsageStatsMonth(context: Context): List<UsageStats> {
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return emptyList()

        val timeEnd = System.currentTimeMillis()
        val timeStart = timeEnd - (30L * 24 * 60 * 60 * 1000) // 最近30天

        return try {
            LogUtils.d("AppUsageStatsManager", "startTime" + timeEnd + "," + timeStart)
            val queryResult = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_MONTHLY, timeStart, timeEnd)
            // 在排序时，调用我们的反射帮助函数来获取 mLaunchCount 的值

            // 先将每个 UsageStats 和其 mAppLaunchCount 配对,避免重复反射
            val statsWithLaunchCount = queryResult.mapNotNull { stats ->
                val launchCount = getLaunchCountReflectively(stats)
                if (launchCount > 0) {
                    stats to launchCount // 只保留启动次数 > 0 的应用
                } else {
                    null
                }
            }

            // 按启动次数降序排序,然后只返回 UsageStats 对象
            statsWithLaunchCount
                .sortedByDescending { it.second } // 按 launchCount 排序
                .map { it.first } // 只返回 UsageStats

        } catch (e: Throwable) {
            emptyList()
        } finally {
            LogUtils.d("AppUsageStatsManager", "endTime" + System.currentTimeMillis())
        }
    }

    /**
     * 通过反射安全地获取 UsageStats 中的 mLaunchCount 字段值。
     * @param stats UsageStats 对象实例
     * @return 返回 mLaunchCount 的值，如果失败则返回 0。
     */
    private fun getLaunchCountReflectively(usageStats: UsageStats): Int {
        if (launchCountReflectionUnavailable) {
            return 0
        }

        if (!useFallbackLaunchCountField) {
            try {
                return getLaunchCount(usageStats, "mAppLaunchCount")
            } catch (exception: Exception) {
                useFallbackLaunchCountField = true
                LogUtils.d("AppUsageStatsManager", "无法通过反射获取 mAppLaunchCount", exception)
            }
        }

        return try {
            getLaunchCount(usageStats, "mLaunchCount")
        } catch (exception: Exception) {
            launchCountReflectionUnavailable = true
            LogUtils.d("AppUsageStatsManager", "无法通过反射获取 mLaunchCount", exception)
            0
        }
    }

    private fun getLaunchCount(usageStats: UsageStats, fieldName: String): Int {
        val field = UsageStats::class.java.getDeclaredField(fieldName)
        field.isAccessible = true
        return field.getInt(usageStats)
    }
}

package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.v6_0.TagItem;
import com.afmobi.util.Constant;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.log.LogUtils;

import java.util.List;

/**
 * APP GAME 搜索框轮播词 cache管理类
 */
public class SearchBoxTagsCache implements LocalCache {

    private static final String TAG = "SearchBoxTagsCache";
    private final static String CACHE_URL = "SearchBoxTagsCache";
    private static volatile SearchBoxTagsCache mInstance;

    private List<TagItem> mAppSearchBoxTagList;
    private List<TagItem> mGameSearchBoxTagList;
    private final Gson mGson;

    private SearchBoxTagsCache() {
        mGson = new Gson();
    }

    public static SearchBoxTagsCache getInstance() {
        if (mInstance == null) {
            synchronized (SearchBoxTagsCache.class) {
                if (mInstance == null) {
                    mInstance = new SearchBoxTagsCache();
                }
            }
        }

        return mInstance;
    }

    public void releaseAndClear() {
        mInstance = null;
        mAppSearchBoxTagList = null;
        mGameSearchBoxTagList = null;
    }

    public List<TagItem> getData(String tabType) {
        checkInit(tabType);

        if (Constant.SOFTTYPE_APP.equals(tabType)) {
            return mAppSearchBoxTagList;

        } else if (Constant.SOFTTYPE_GAME.equals(tabType)) {
            if (mGameSearchBoxTagList != null) {
                return mGameSearchBoxTagList;
            }
        }
        return null;
    }

    private void checkInit(String tabType) {
        if (Constant.SOFTTYPE_APP.equals(tabType) && mAppSearchBoxTagList == null || Constant.SOFTTYPE_GAME.equals(tabType) && mGameSearchBoxTagList == null) {
            loadFromCache(tabType);
        }
    }

    @Override
    public void saveToCache(String tabType, Object... objects) {
        String fileName = getFileName(tabType, Constant.SOFTTYPE_APP.equals(tabType) ? DetailType.TYPE_APP : DetailType.TYPE_GAME);

        if (fileName != null && objects.length > 0) {
            LogUtils.d(TAG, "saveToCache: " + objects[0] +  "  fileName = " + fileName);
            FilePathManager.jsonToFile(mGson.toJson(objects[0]),fileName);
        }
    }

    @Override
    public void loadFromCache(Object... objects) {
        if (objects != null && (objects[0] != null && objects[0] instanceof String)) {

            String tabType = (String) objects[0];
            int detailType = Constant.SOFTTYPE_APP.equals(tabType) ? DetailType.TYPE_APP : DetailType.TYPE_GAME;

            JsonElement searchBoxTagList = FilePathManager.fileToJson(getFileName(tabType, detailType));
            if (searchBoxTagList != null && !TextUtils.isEmpty(searchBoxTagList.toString())) {
                if (Constant.SOFTTYPE_APP.equals(tabType)) {
                    mAppSearchBoxTagList = mGson.fromJson(searchBoxTagList, new TypeToken<List<TagItem>>() {
                    }.getType());
                } else if (Constant.SOFTTYPE_GAME.equals(tabType)) {
                    mGameSearchBoxTagList = mGson.fromJson(searchBoxTagList, new TypeToken<List<TagItem>>() {
                    }.getType());
                }
            }
        }

    }

    @Override
    public String getFileName(Object... objects) {
        if (objects != null && objects.length > 1
                && (objects[0] != null && objects[0] instanceof String)
                && (objects[1] != null && objects[1] instanceof Integer)) {
            return getCacheKey((String) objects[0], (Integer) objects[1]);
        }

        return null;
    }

    public String getCacheKey(String tabType, int detailType) {
        if (!TextUtils.isEmpty(tabType)) {
            return CACHE_URL + "_" + tabType + "_" + detailType;
        }
        return "";
    }

}


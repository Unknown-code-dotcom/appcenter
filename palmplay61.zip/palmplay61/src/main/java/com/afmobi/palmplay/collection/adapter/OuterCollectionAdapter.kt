package com.afmobi.palmplay.collection.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter
import com.afmobi.palmplay.collection.ICollectionController
import com.afmobi.palmplay.collection.viewholder.OuterGridViewHolder
import com.afmobi.palmplay.collection.viewholder.OuterHeaderViewHolder
import com.afmobi.palmplay.collection.viewholder.OuterVerticalViewHolder
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.download.InterfaceStatusChange
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import com.afmobi.palmplay.model.v6_3.PageParamInfo
import com.afmobi.util.Constant
import com.androidnetworking.BuildConfig
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.store.R
import java.lang.ref.WeakReference

class OuterCollectionAdapter(private val data: FeaturedModel) : PalmBaseDownloadRecyclerViewAdapter() {

    companion object {
        private const val TAG = "${LogUtils.TAG_COLLECTION}OuterCollectionAdapter"
        private const val ITEM_TYPE_HEAD = 1
        private const val ITEM_TYPE_GRID = 2
        private const val ITEM_TYPE_VERTICAL = 3
    }

    var _mActivity: Activity? = null
    var _mCollectionController: ICollectionController? = null
    var _mLayoutManager: RecyclerView.LayoutManager? = null
    var _mRecyclerView: RecyclerView? = null
    var mFromPage: String = ""
    var mFrom: String = ""
    var mScreenName: String = ""
    var mPageParamInfo:PageParamInfo? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when(viewType) {
            ITEM_TYPE_HEAD -> {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.layout_recommend_collection_header, parent, false)
                OuterHeaderViewHolder(itemView)
            }
            ITEM_TYPE_GRID -> {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.layout_grid_recommend_collection_container, parent, false)
                OuterGridViewHolder(itemView).apply {
                    collectionController = _mCollectionController
                    setFromPage(mFromPage)
                    setFrom(mFrom)
                    setScreenPageName(mScreenName)
                    setPageParamInfo(mPageParamInfo)
                    setVarId("")
                }
            }
            else -> {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.layout_vertical_recommend_collection_container, parent, false)
                OuterVerticalViewHolder(itemView).apply {
                    collectionController = _mCollectionController
                    setFromPage(mFromPage)
                    setFrom(mFrom)
                    setScreenPageName(mScreenName)
                    setPageParamInfo(mPageParamInfo)
                    setVarId("")
                }
            }

        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewType = getItemViewType(position)
        val pos = position - 1 // pos 调整过了
        when(viewType) {
            ITEM_TYPE_HEAD -> {
                (holder as? OuterHeaderViewHolder)?.bind(data.currentTabConfig)
            }
            ITEM_TYPE_GRID -> {
                (holder as? OuterGridViewHolder)?.apply {
                    bottomPosition = itemCount - 2 // pos 调整过了
                    bind(data.featureList[pos], pos)
                }
            }
            else -> {
                (holder as? OuterVerticalViewHolder)?.apply {
                    bottomPosition = itemCount - 2 // pos 调整过了
                    bind(data.featureList[pos], pos)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return data.featureList.size + 1
    }

    override fun getItemViewType(position: Int): Int {
        try {
            if (position < 0) return position
            val pos = position - 1
            return when {
                position == 0-> ITEM_TYPE_HEAD
                Constant.ONE_CLICK_HORIZONTAL_4 == data.featureList[pos].style -> ITEM_TYPE_GRID
                else -> ITEM_TYPE_VERTICAL
            }
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) e.printStackTrace()
        }
        return -1
    }

    override fun loaderInterfaceStatusChangeObjectKey(): Any = this

    override fun loaderInterfaceStatusChange(): InterfaceStatusChange? = newStatusChange().get()

    private fun newStatusChange(): WeakReference<InterfaceStatusChange> {
        //把内部类采用弱指针的形式避免回收不掉
        return WeakReference<InterfaceStatusChange>(object : InterfaceStatusChange {
            override fun onDownloadStart(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onDownloadStart downloadInfo=$downloadInfo")
                if (downloadInfo?.extraInfo != null && !downloadInfo.extraInfo.isVaGame) {
                    notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
                }
            }

            override fun onDownloadComplete(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onDownloadComplete downloadInfo=$downloadInfo")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
            }

            override fun onActivated(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onActivated downloadInfo=$downloadInfo")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
            }

            override fun onDownloadError(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onDownloadError downloadInfo=$downloadInfo")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
            }

            override fun onDownloadPause(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onDownloadPause downloadInfo=$downloadInfo")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
            }

            override fun onDownloadResume(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onDownloadResume downloadInfo=$downloadInfo")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
            }

            override fun onDownloadDelete(downloadInfo: FileDownloadInfo?) {
                LogUtils.d(TAG, "onDownloadDelete downloadInfo=$downloadInfo")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo)
            }

            override fun onAppPackageAdded(packageName: String, versionCode: Int) {
                LogUtils.d(TAG, "onAppPackageAdded packageName=$packageName")
                onAppPackageChange(packageName, versionCode)
            }

            override fun onAppPackageRemoved(
                packageName: String,
                versionCode: Int,
                modifyStatusFrom: Int
            ) {
                LogUtils.d(TAG, "onAppPackageRemoved packageName=$packageName")
                onAppPackageChange(packageName, versionCode)
            }

            override fun onDownloadProgressUpdate(
                downloadInfo: FileDownloadInfo?,
                downloadedBytes: Long,
                fileLength: Long,
                speed: Int
            ) {
//                LogUtils.d(TAG, "onDownloadProgressUpdate downloadInfo=$downloadInfo")
                val mActivity = _mActivity
                if (mActivity == null || mActivity.isFinishing || mActivity.isDestroyed) {
                    DownloadStatusManager.getInstance().removeStatusChangeListener(this)
                    return
                }
                if (downloadInfo != null && !downloadInfo.isVa && _mLayoutManager != null) {
                    if (downloadInfo.sourceSize == 0L) {
                        // 防止出现异常
                        return
                    }
                    val progress =
                        (downloadInfo.downloadedSize * 100 / downloadInfo.sourceSize).toFloat()

                    if (_mLayoutManager is LinearLayoutManager) {
                        val mLinearLayoutManager = _mLayoutManager as LinearLayoutManager
                        val firstVisibleItemPosition =
                            mLinearLayoutManager.findFirstVisibleItemPosition()  //第一个可见的item，有个默认head
                        val lastVisibleItemPosition =
                            mLinearLayoutManager.findLastVisibleItemPosition()  //最后一个可见item

                        for (i in firstVisibleItemPosition..lastVisibleItemPosition) {
                            val mItemView =
                                mLinearLayoutManager.findViewByPosition(i+1) // 有个默认下拉刷新header
                                    ?: continue //可见范围内的 itemview
                            val viewType = getItemViewType(i)

                            when (viewType) {
                                ITEM_TYPE_GRID -> {
                                    NestedGridAdapter.updateItemProgress(mItemView, downloadInfo, progress.toInt(), null)
                                }
                                ITEM_TYPE_VERTICAL -> {
                                    NestedVerticalAdapter.updateItemProgress(mItemView, downloadInfo, progress.toInt(), null)
                                }
                                else -> {}
                            }
                        }
                    }
                }
            }
        })
    }

    private fun notifyDataSetChangedWithInterfaceStatusChange(downloadInfo: FileDownloadInfo?) {
        val mActivity = _mActivity
        if (mActivity == null || mActivity.isDestroyed || mActivity.isFinishing) {
            DownloadStatusManager.getInstance().removeStatusChangeListener(this)
            return
        }
        DownloadStatusManager.registerInfoInstanceNew(data.featureList, downloadInfo)

        notifyDataSetChanged()
    }


    private fun onAppPackageChange(packageName: String, versionCode: Int) {
        DownloadStatusManager.registerInfoInstanceNew(data.featureList, packageName)
        notifyDataSetChanged()
    }
}

package com.afmobi.palmplay.cache

import java.util.concurrent.atomic.AtomicBoolean

object SimpleDataMap {
    const val KEY_INSTALL_SOURCE_P2P = "P2P"
    const val KEY_INSTALL_SOURCE_AUTO = "auto_download"
    // https://juejin.cn/post/7405842860035424266
    val installSourceMap = HashMap<String,String>()

    // PS自升级状态管理
    val activeSelfUpdate: AtomicBoolean = AtomicBoolean(false)
}
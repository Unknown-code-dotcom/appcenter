// TOP SECRET
package com.afmobi.palmplay.appmanage.adapter;

import android.os.AsyncTask;

import com.afmobi.palmplay.configs.HttpRequestState;
import com.afmobi.palmplay.manager.HttpRequestTracerManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.afmobi.util.eventbus.IAction;

import java.util.Map;

import de.greenrobot.event.EventBus;

public class AsyncGetInstalledPackageListTask extends AsyncTask<Void, Void, Map<String, InstalledAppInfo>>{
	
	public AsyncGetInstalledPackageListTaskListener listener;
	

	public AsyncGetInstalledPackageListTask(AsyncGetInstalledPackageListTaskListener l){
		this.listener = l;
	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		if(listener!=null)
			listener.onPreExecute();
	}

	@Override
	protected Map<String, InstalledAppInfo> doInBackground(Void... arg0) {
		Map<String, InstalledAppInfo> map = InstalledAppManager.getInstance().initializePackageInfo();
		if(listener!=null)
			map = listener.doInBackground(map);
		return map;
	}
	
	@Override
	protected void onPostExecute(Map<String, InstalledAppInfo> result) {
		super.onPostExecute(result);
		
		if(listener!=null)
			listener.onPostExecute(result);
	}
	
	
	public static synchronized void excuteDef(final AsyncGetInstalledPackageListTaskListener listener){
           new AsyncGetInstalledPackageListTask(new AsyncGetInstalledPackageListTaskListener() {
			
			@Override
			public void onPreExecute() {
				if(listener!=null)
					listener.onPreExecute();
			}
			
			@Override
			public void onPostExecute(Map<String, InstalledAppInfo> map) {
				HttpRequestTracerManager.setHttpRequestState(IAction.Action_GetInstalledPackageList_task, HttpRequestState.requestSuccess);
				if(listener!=null){
					listener.onPostExecute(map);
				}

				EventMainThreadEntity mEventMainThreadEntity = new EventMainThreadEntity();
				mEventMainThreadEntity.setAction(IAction.Action_GetInstalledPackageList_task);
				mEventMainThreadEntity.isSuccess = true;
				EventBus.getDefault().post(mEventMainThreadEntity);
			}
			
			@Override
			public Map<String, InstalledAppInfo> doInBackground(
					Map<String, InstalledAppInfo> map) {
				HttpRequestTracerManager.requesting(IAction.Action_GetInstalledPackageList_task);

				if(listener!=null)
					listener.doInBackground(map);
				return map;
			}
		}).execute();
	}
	
	public interface AsyncGetInstalledPackageListTaskListener{
		
		public void onPreExecute();
		
		public Map<String, InstalledAppInfo> doInBackground(Map<String, InstalledAppInfo> map);
		
		public void onPostExecute(Map<String, InstalledAppInfo> map);
		
	}

}

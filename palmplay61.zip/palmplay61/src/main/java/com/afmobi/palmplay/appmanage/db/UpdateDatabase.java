package com.afmobi.palmplay.appmanage.db;

import android.content.Context;

import com.afmobi.palmplay.model.ClientVersion;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/**
 * @author: kun.shi
 * @date: 2024/5/15 11:27
 * @Desc: add your description
 */
@Database(entities = {ClientVersion.UpdateItem.class}, version = 3, exportSchema = false)
public abstract class UpdateDatabase extends RoomDatabase {
    private static UpdateDatabase sInstance;

    public static UpdateDatabase getDatabase(Context context) {
        if (sInstance == null) {
            sInstance = Room.databaseBuilder(context.getApplicationContext(),
                    UpdateDatabase.class, "IgnoreUpdateDatabase")
                    .setJournalMode(RoomDatabase.JournalMode.TRUNCATE)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return sInstance;
    }

    public abstract UpdateDao getIgnoreUpdateDao();

}

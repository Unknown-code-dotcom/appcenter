package com.afmobi.palmplay.appmanage.v2.adapter

import androidx.recyclerview.widget.DiffUtil
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.transsion.palmstorecore.log.LogUtils

/**
 * 下载列表DiffUtil回调类
 * 用于高效计算列表数据变化
 */
class DownloadDiffCallback : DiffUtil.ItemCallback<FileDownloadInfo>() {
    companion object {
        // 局部刷新类型常量
        const val CHANGE_DOWNLOAD_STATUS = "downloadStatus"
        const val CHANGE_PROGRESS = "progress"
        const val CHANGE_ICON = "icon"
        const val CHANGE_NAME = "appName"
        const val CHANGE_ERROR = "errMsg"
    }
    
    override fun areItemsTheSame(oldItem: FileDownloadInfo, newItem: FileDownloadInfo): Boolean {
        // 使用packageName作为唯一标识符
        return oldItem.packageName == newItem.packageName
    }
    
    override fun areContentsTheSame(oldItem: FileDownloadInfo, newItem: FileDownloadInfo): Boolean {
        // 比较所有可能影响UI显示的字段
        return oldItem.packageName == newItem.packageName &&
                oldItem.itemID == newItem.itemID &&
                oldItem.name == newItem.name &&
                oldItem.versionName == newItem.versionName &&
                oldItem.version == newItem.version &&
                oldItem.iconUrl == newItem.iconUrl &&
                oldItem.downloadStatus == newItem.downloadStatus &&
                oldItem.isDeletedTag == newItem.isDeletedTag &&
                compareExtraInfo(oldItem, newItem)
    }
    
    /**
     * 比较ExtraInfo对象
     */
    private fun compareExtraInfo(oldItem: FileDownloadInfo, newItem: FileDownloadInfo): Boolean {
        val oldExtra = oldItem.extraInfo
        val newExtra = newItem.extraInfo
        
        if (oldExtra == null && newExtra == null) {
            return true
        }
        
        if (oldExtra == null || newExtra == null) {
            return false
        }
        
        return oldExtra.itemCheckFlag == newExtra.itemCheckFlag &&
                oldExtra.canRetry == newExtra.canRetry &&
                oldExtra.isVaGame == newExtra.isVaGame &&
                oldExtra.isRetryInstallFail == newExtra.isRetryInstallFail &&
                oldExtra.isPlutoOffer == newExtra.isPlutoOffer &&
                oldExtra.isSubPackage == newExtra.isSubPackage
    }
    
    override fun getChangePayload(oldItem: FileDownloadInfo, newItem: FileDownloadInfo): Any? {
        // 返回变化的字段，用于局部更新
        val changes = mutableListOf<String>()
        
        if (oldItem.downloadStatus != newItem.downloadStatus) {
            changes.add("downloadStatus")
        }
        
        if (oldItem.downloadedSize != newItem.downloadedSize ||
            oldItem.sourceSize != newItem.sourceSize) {
            changes.add("progress")
        }
        
        if (oldItem.iconUrl != newItem.iconUrl) {
            changes.add("icon")
        }
        
        if (oldItem.name != newItem.name) {
            changes.add("appName")
        }
        LogUtils.d("DownloadRepo", "getChangePayload$changes")
        
        return changes.ifEmpty { null }
    }
}
package com.afmobi.palmplay.cloudfolder.adapter

import android.content.Context
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderRemoteController
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.model.BaseFolderUiModel
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_CENTER
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.CloudFolderLauncher
import com.afmobi.palmplay.cloudfolder.utils.PaletteControls
import com.afmobi.palmplay.cloudfolder.utils.drawableToBitmap
import com.afmobi.palmplay.cloudfolder.utils.getSafeString
import com.afmobi.palmplay.cloudfolder.view.FixedRankSectionView
import com.afmobi.palmplay.cloudfolder.view.GlobalShapeClipFrameLayout
import com.afmobi.palmplay.customview.DownloadStatusView
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.download.DownloadUtil
import com.afmobi.palmplay.download.InterfaceStatusChange
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.shortcuts.ShortcutsGridAdapter
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.android.material.imageview.ShapeableImageView
import com.transsion.palmstorecore.bitmap.TRBitmapManager
import com.transsion.palmstorecore.glide.GlideApp
import com.transsion.palmstorecore.glide.GlideUtils
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.launcherlib.config.Constants.FILE_FOLDER_FROM_SITE_APP
import com.transsnet.launcherlib.config.Constants.FILE_FOLDER_FROM_SITE_GAME
import com.transsnet.store.BuildConfig
import com.transsnet.store.R


class CloudShortcutAdapter(context: Context, val categoryType: Int) :
    PalmBaseDownloadRecyclerViewAdapter(), View.OnLongClickListener {
    private val mContext: Context = context.applicationContext
    private var mListData: MutableList<CloudAppInfo> = ArrayList() //数据
    private var gridLayoutManager: GridLayoutManager? = null

    /** 当前云文件夹布局样式（由宿主 Fragment 注入），用于埋点 sty 字段 */
    var layoutStyle: Int = CloudFolderTrackUtil.STY_DEFAULT
    var clickPositionOffset: Int = 0

    private val isShowMark : Boolean by lazy {
        CloudFolderManager.getInstance().isIconMaskShow()
    }

    private val markAlpha : Float by lazy {
        CloudFolderManager.getInstance().getCloudFolderDownAlpha()
    }

    private val paletteControls : PaletteControls by lazy {
        PaletteControls.getInstance(PalmplayApplication.getAppInstance())
    }

    //自定义监听事件
    interface OnRecyclerViewItemClickListener {
        fun onItemLongClick(view: View?)

        fun onItemClick(appInfo: AppInfo)
    }

    private var mOnItemClickListener: OnRecyclerViewItemClickListener? = null
    fun setOnItemClickListener(listener: OnRecyclerViewItemClickListener?) {
        mOnItemClickListener = listener
    }

    /** RANK_SECTION header 内子条目的长按回调，由 Fragment 桥接到弹窗逻辑 */
    var sectionOnLongClick: ((view: View, index: Int, appInfo: CloudAppInfo) -> Unit)? = null

    //适配器初始化
    init {
        mFrom = if(categoryType == CATEGORY_APP) FILE_FOLDER_FROM_SITE_APP else FILE_FOLDER_FROM_SITE_GAME
    }

    companion object {
        private const val TAG = "CloudShortcutAdapter"
        const val VIEW_TYPE_NORMAL = 0
        const val VIEW_TYPE_RANK_APP = BaseFolderUiModel.TYPE_RANK_APP     // 奖牌样式 (样式4)
        // RV header：3 个皇冠 app 整组横排（fixRankTile=false 时使用，复用 FixedRankSectionView）
        const val VIEW_TYPE_RANK_SECTION = BaseFolderUiModel.TYPE_RANK_SECTION

        // 皇冠/奖牌资源（金/银/铜）
        private val CROWN_DRAWABLES = intArrayOf(
            R.drawable.ic_cloud_folder_gold,
            R.drawable.ic_cloud_folder_silver,
            R.drawable.ic_cloud_folder_bronze
        )
    }

    fun setListData(list: List<CloudAppInfo>?) {
        if (!list.isNullOrEmpty()) {
            mListData.clear()
            mListData.addAll(list)
        } else {
            mListData.clear()
        }
        notifyDataSetChanged()
    }

    fun refreshVisibleRankSection(recyclerView: RecyclerView, contentHostWidth: Int) {
        for (index in 0 until recyclerView.childCount) {
            val holder = recyclerView.getChildViewHolder(recyclerView.getChildAt(index))
            if (holder is RankSectionViewHolder) {
                holder.sectionView.refreshPadItemSpacing(contentHostWidth)
                return
            }
        }
    }

    fun getAppInfo(position: Int): CloudAppInfo? {
        return if (position < mListData.size) {
            mListData[position]
        } else null
    }

    override fun getItemViewType(position: Int): Int {
        val appInfo = getAppInfo(position) ?: return VIEW_TYPE_NORMAL
        return when (appInfo.rankViewType) {
            BaseFolderUiModel.TYPE_RANK_SECTION -> VIEW_TYPE_RANK_SECTION
            BaseFolderUiModel.TYPE_RANK_APP -> VIEW_TYPE_RANK_APP
            else -> VIEW_TYPE_NORMAL
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(mContext)
        return when (viewType) {
            VIEW_TYPE_RANK_SECTION -> {
                val sectionView = FixedRankSectionView(parent.context).apply {
                    layoutParams = RecyclerView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    categoryType = this@CloudShortcutAdapter.categoryType
                    layoutStyle = this@CloudShortcutAdapter.layoutStyle
                    onRankItemLongClickListener = { v, idx, info ->
                        sectionOnLongClick?.invoke(v, idx, info)
                    }
                }
                RankSectionViewHolder(sectionView)
            }
            VIEW_TYPE_RANK_APP -> {
                val view = inflater.inflate(R.layout.cloud_folder_rank_app_item, parent, false)
                val isSpan3 = layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST
                if (isSpan3) {
                    view.layoutParams = view.layoutParams.apply {
                        width = com.afmobi.palmplay.cloudfolder.utils.dip2px(64f)
                    }
                    view.findViewById<View>(R.id.rl_icon)?.apply {
                        layoutParams = layoutParams.apply {
                            width = com.afmobi.palmplay.cloudfolder.utils.dip2px(64f)
                        }
                    }
                    view.findViewById<View>(R.id.tv_item_name)?.apply {
                        layoutParams = layoutParams.apply {
                            width = com.afmobi.palmplay.cloudfolder.utils.dip2px(62f)
                        }
                    }
                }
                RankAppViewHolder(view)
            }
            else -> {
                val view = inflater.inflate(R.layout.cloud_folder_items, parent, false)
                val isSpan3 = layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST
                if (isSpan3) {
                    view.layoutParams = view.layoutParams.apply {
                        width = com.afmobi.palmplay.cloudfolder.utils.dip2px(64f)
                    }
                    view.findViewById<View>(R.id.rl_icon)?.apply {
                        layoutParams = layoutParams.apply {
                            width = com.afmobi.palmplay.cloudfolder.utils.dip2px(64f)
                        }
                    }
                    view.findViewById<View>(R.id.tv_item_name)?.apply {
                        layoutParams = layoutParams.apply {
                            width = com.afmobi.palmplay.cloudfolder.utils.dip2px(62f)
                        }
                    }
                }
                NormalViewHolder(view)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val appInfo = getAppInfo(position) ?: return
        appInfo.placementId = position.toString()
        // 注入页面级别样式，下游埋点与下载链路直接读取 appInfo 即可
        appInfo.layoutStyle = layoutStyle

        // RANK_SECTION header 走独立路径（不走 BaseShortcutsViewHolder 通用绑定）
        if (holder is RankSectionViewHolder) {
            holder.sectionView.categoryType = categoryType
            holder.sectionView.layoutStyle = layoutStyle
            val parentView = holder.itemView.parent as? View
            val hostWidth = if (parentView != null && parentView.width > 0) {
                parentView.width - parentView.paddingLeft - parentView.paddingRight
            } else {
                0
            }
            holder.sectionView.bindData(appInfo.rankSectionApps ?: emptyList(), hostWidth)
            return
        }

        val baseHolder = holder as BaseShortcutsViewHolder
        paletteControls.updateTextShadow(baseHolder.itemName)
        LogUtils.i("CloudShortcutAdapter ----- onBindViewHolder ：  ${appInfo.observerStatus}   ---   ${appInfo.packageName}")

        // ===== 通用绑定逻辑 =====
        bindIcon(baseHolder, appInfo)
        bindMark(baseHolder, appInfo)
        checkStatus(
            appInfo,
            baseHolder.itemName,
            baseHolder.ivDefaultIcon,
            baseHolder.statusView,
            baseHolder.viewMark
        )
        bindClickEvents(baseHolder, appInfo, position)

        // ===== 差异化绑定逻辑 =====
        when (baseHolder) {
            is RankAppViewHolder -> bindRankAppBadge(baseHolder, appInfo)
            is NormalViewHolder -> { /* 普通条目无额外绑定 */ }
        }
    }

    override fun onViewAttachedToWindow(holder: RecyclerView.ViewHolder) {
        super.onViewAttachedToWindow(holder)
        if (holder is RankSectionViewHolder) {
            holder.sectionView.registerDownloadListener()
        }
    }

    override fun onViewDetachedFromWindow(holder: RecyclerView.ViewHolder) {
        super.onViewDetachedFromWindow(holder)
        if (holder is RankSectionViewHolder) {
            holder.sectionView.unregisterDownloadListener()
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is RankSectionViewHolder) {
            // 兜底：detach 已 unregister，此处再调一次幂等保护
            holder.sectionView.unregisterDownloadListener()
            return
        }
        if (holder is BaseShortcutsViewHolder) {
            // 停止可能正在播放的动画
            val drawable = holder.itemIcon.drawable
            if (drawable is Animatable) {
                drawable.stop()
            }
            // 清理 Glide 请求，释放资源
            GlideApp.with(PalmplayApplication.getAppInstance()).clear(holder.itemIcon)
        }
    }

    // ==================== 通用绑定方法 ====================

    private fun bindIcon(holder: BaseShortcutsViewHolder, appInfo: CloudAppInfo) {
        // 重置视图状态，防止复用残留
        holder.ivDefaultIcon.visibility = View.GONE
        val oldDrawable = holder.itemIcon.drawable
        if (oldDrawable is Animatable) {
            oldDrawable.stop()
        }
        val remoteController = CloudFolderRemoteController.getInstance()
        val isPreInstallItem = appInfo.isPreInstallItem()
        val isDynamicIcon = !isPreInstallItem && appInfo.isDynamicIcon()
        holder.cardIcon.setGlobalIconShapePath(
            if (remoteController.hasGlobalIconShape()) {
                remoteController.getGlobalIconShapePath()
            } else {
                null
            }
        )
        holder.statusView.setClipToOutline(!remoteController.hasGlobalIconShape())
        holder.statusView.setUseGlobalIconShape(remoteController.hasGlobalIconShape())
        holder.itemIcon.shapeAppearanceModel =
            if (remoteController.hasGlobalIconShape()) {
                holder.globalIconShapeAppearance
            } else {
                holder.defaultIconShapeAppearance
            }
        if(isPreInstallItem) {
            drawableToBitmap(appInfo.drawable)?.apply {
                holder.itemIcon.setImageBitmap(
                    remoteController.getCloudThemeIcon(mContext, this)
                )
            }
        } else {
            // 优先使用动态图标，否则回退到默认图标
            GlideApp.with(PalmplayApplication.getAppInstance())
                .load(if (isDynamicIcon) appInfo.dynamicIconUrl else appInfo.iconUrl)
                .apply(GlideUtils.newCommonRequestOptions())
                .addListener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        if (resource == null) {
                            return false
                        }
                        LogUtils.i(
                            "CloudShortcutAdapter onResourceReady pkg=${appInfo.packageName}" +
                                    " isDynamicIcon=$isDynamicIcon" +
                                    " resourceType=${resource.javaClass.simpleName}" +
                                    " isAnimatable=${resource is Animatable}"
                        )
                        if (isDynamicIcon) {
                            // 动态图标：直接展示，保持动图能力（GIF/WebP）
                            holder.itemIcon.setImageDrawable(resource)
                            if (resource is Animatable) {
                                resource.start()
                            }
                        } else {
                            // 标准图标：走合并背景 + 主题图标处理流程
                            val bitmap = ShortcutsGridAdapter.drawableToBitmap(resource)
                            val resultBitmap = if (remoteController.hasGlobalIconShape()) {
                                bitmap
                            } else {
                                TRBitmapManager.mergeBitmap(bitmap, R.drawable.shortcut_icon_items_bg)
                            }
                            if (resultBitmap == null || resultBitmap.isRecycled) {
                                return false
                            }
                            holder.itemIcon.setImageBitmap(
                                remoteController.getCloudThemeIcon(mContext, resultBitmap)
                            )
                        }

                        appInfo.hasLoaded = true
                        if (appInfo.observerStatus == FileDownloadInfo.STATUS_NONE || appInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
                            holder.ivDefaultIcon.visibility =
                                View.VISIBLE
                        } else {
                            holder.ivDefaultIcon.visibility =
                                View.GONE
                        }
                        return true
                    }

                })
                .into(holder.itemIcon)
        }
    }

    private fun bindMark(holder: BaseShortcutsViewHolder, appInfo: CloudAppInfo) {
        if(appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
            val useGlobalShape = shouldUseGlobalIconShape()
            holder.itemIcon.setBackgroundResource(
                if (useGlobalShape) 0 else R.drawable.shortcut_icon_bg
            )
            updateMarkShape(holder, useGlobalShape)
            if(isShowMark) {
                holder.viewMark.visibility = View.VISIBLE
                holder.viewMark.alpha = markAlpha
            } else {
                holder.viewMark.visibility = View.GONE
            }
        } else {
            holder.itemIcon.setBackgroundResource(0)
            updateMarkShape(holder, false)
            holder.viewMark.visibility = View.GONE
        }
    }

    private fun updateMarkShape(holder: BaseShortcutsViewHolder, useGlobalShape: Boolean) {
        holder.viewMark.shapeAppearanceModel = if (useGlobalShape) {
            holder.globalMarkShapeAppearance
        } else {
            holder.defaultMarkShapeAppearance
        }
    }

    private fun bindClickEvents(holder: BaseShortcutsViewHolder, appInfo: CloudAppInfo, position: Int) {
        holder.itemView.tag = position
        val actualPosition = position + clickPositionOffset

        holder.itemView.setOnLongClickListener { v ->
            mOnItemClickListener?.onItemLongClick(v)
            true
        }
        holder.itemView.setOnClickListener(View.OnClickListener { v ->
            if(appInfo.isPreInstallItem()) {
                CloudFolderLauncher.launchFromPreInstall(appInfo)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_OPEN_APP, appInfo, actualPosition, appInfo.jumpType)
                return@OnClickListener
            }
            if(appInfo.isOtherType()) {
                val launchType = CloudFolderLauncher.launchFromOtherType(appInfo)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_INSTALL, appInfo, actualPosition, appInfo.jumpType, launchType)
                return@OnClickListener
            }
            if (appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING) {
                return@OnClickListener
            }
            if (FileDownloadInfo.isDownloading(appInfo.observerStatus)) {
                DownloadManager.getInstance().onDownloadingPauseByUser(appInfo.packageName, false, true)
                trackClickWithParams(CloudFolderTrackUtil.BUTTON_TYPE_PAUSE, appInfo, actualPosition)
                mOnItemClickListener?.onItemClick(appInfo)
            } else if (FileDownloadInfo.STATUS_PAUSE == appInfo.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == appInfo.observerStatus) {
                DownloadUtil.resumeDownload(mContext, appInfo.packageName)
                trackClickWithParams(
                    CloudFolderTrackUtil.BUTTON_TYPE_RESUME,
                    appInfo,
                    actualPosition
                )
            } else {
                if (FileDownloadInfo.STATUS_NONE == appInfo.observerStatus) { //下载
                    trackClickWithParams(
                        CloudFolderTrackUtil.BUTTON_TYPE_INSTALL,
                        appInfo,
                        actualPosition
                    )
                }
                val sign = if (categoryType == CATEGORY_APP) "A" else "G"
                val fromPage = "FL_${sign}_${SCENE_CENTER}_$actualPosition"
                CloudFolderManager.getInstance().startDownload(appInfo, categoryType, fromPage)
            }
        })
    }

    // ==================== 差异化绑定方法 ====================

    /**
     * 绑定奖牌徽章（样式4）
     */
    private fun bindRankAppBadge(holder: RankAppViewHolder, appInfo: CloudAppInfo) {
        val index = appInfo.rankIndex
        if (index in CROWN_DRAWABLES.indices) {
            holder.ivRankBadge.setImageResource(CROWN_DRAWABLES[index])
            holder.ivRankBadge.visibility = View.VISIBLE
        } else {
            holder.ivRankBadge.visibility = View.GONE
        }
    }

    // ==================== 辅助方法 ====================

    private fun trackClickWithParams(eventName: String, appInfo: AppInfo?, position: Int, turnType: Int = 0, ctj: String ?= null) {
        if (appInfo == null) {
            return
        }
        CloudFolderTrackUtil.businessItemClickTrack(
            position,
            eventName,
            appInfo.packageName,
            categoryType,
            appInfo.isOffer,
            turnType,
            ctj,
            cfValue = (appInfo as? CloudAppInfo)?.getCloudStyleString(),
        )

    }

    private fun checkStatus(
        appInfo: CloudAppInfo,
        itemName: TextView,
        iv_default_icon: ImageView,
        statusView: DownloadStatusView,
        markView: View
    ) {
        DownloadStatusManager.getInstance().registerInfoInstance(appInfo)
        if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
            // 文件下载完成，正在进行校验，此时不处理点击事件，页面显示进度100%
            if (BuildConfig.DEBUG) {
                Log.e("checkDownloadInfo", "文件下载完成，校验中...", Throwable("who call me"))
            }
            return
        }
        if (appInfo.observerStatus == FileDownloadInfo.STATUS_NONE) {
            itemName.text = appInfo.name
            statusView.setProgress(0f)
        } else if(appInfo.observerStatus == FileDownloadInfo.STATUS_WAIT) {
            itemName.text = PalmplayApplication.getAppInstance().getSafeString(R.string.waiting, useSystemLanguage = true)
        }else if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
            itemName.text = PalmplayApplication.getAppInstance().getSafeString(R.string.text_downloading, useSystemLanguage = true)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_PAUSE) {
            itemName.text = PalmplayApplication.getAppInstance().getSafeString(R.string.paused, useSystemLanguage = true)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED) {
            itemName.text = PalmplayApplication.getAppInstance().getSafeString(R.string.click_install, useSystemLanguage = true)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING) {
            itemName.text = PalmplayApplication.getAppInstance().getSafeString(R.string.text_installing, useSystemLanguage = true)
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED) {
            itemName.text = appInfo.name
        } else if (appInfo.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
            itemName.text = appInfo.name
        }
        if (appInfo.observerStatus != FileDownloadInfo.STATUS_NONE && appInfo.observerStatus != FileDownloadInfo.STATUS_APP_UPDATE) {
            iv_default_icon.visibility = View.GONE
        } else {
            if (appInfo.hasLoaded) {
                iv_default_icon.visibility = View.VISIBLE
            }
        }
        if (appInfo.observerStatus == FileDownloadInfo.STATUS_WAIT || appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_PAUSE || appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNLOADED || appInfo.observerStatus == FileDownloadInfo.STATUS_INSTALLING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
            statusView.visibility = View.VISIBLE
            markView.visibility = View.GONE
            statusView.setStatus(appInfo.observerStatus, true)
            if (appInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING || appInfo.observerStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) { //下载中出现网络错误，要保持下载中的UI样子不变
                statusView.setProgress(appInfo.progress)
            }
        } else {
            statusView.visibility = View.GONE
            if(isShowMark && appInfo.observerStatus != FileDownloadInfo.STATUS_APP_INSTALLED) {
                markView.visibility = View.VISIBLE
            } else {
                markView.visibility = View.GONE
            }
        }
    }

    private fun shouldUseGlobalIconShape(): Boolean {
        return CloudFolderRemoteController.getInstance().hasGlobalIconShape()
    }

    fun setGridLayoutManager(gridLayoutManager: GridLayoutManager?) {
        this.gridLayoutManager = gridLayoutManager
    }

    override fun loaderInterfaceStatusChangeObjectKey(): Any {
        return this
    }

    override fun loaderInterfaceStatusChange(): InterfaceStatusChange {
        val folderTag = if (categoryType == CATEGORY_APP) "APP" else "GAME"
        return object : InterfaceStatusChange {
            override fun onDownloadStart(downloadInfo: FileDownloadInfo) {
                LogUtils.i(TAG, "[$folderTag] onDownloadStart pkg=${downloadInfo.packageName}")
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadProgressUpdate(
                downloadInfo: FileDownloadInfo,
                downloadedBytes: Long,
                fileLength: Long,
                speed: Int
            ) {
                downloadProgressUpdate(downloadInfo, downloadedBytes, fileLength, speed)
            }

            override fun onDownloadComplete(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onActivated(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadError(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadPause(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadResume(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onDownloadDelete(downloadInfo: FileDownloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo, null)
            }

            override fun onAppPackageAdded(packageName: String, versionCode: Int) {
                notifyDataSetChangedWithInterfaceStatusChange(null, packageName)
            }

            override fun onAppPackageRemoved(
                packageName: String,
                versionCode: Int,
                modifyStatusFrom: Int
            ) {
                notifyDataSetChangedWithInterfaceStatusChange(null, packageName)
            }
        }
    }

    private fun downloadProgressUpdate(
        downloadInfo: FileDownloadInfo,
        downloadedBytes: Long,
        fileLength: Long,
        speed: Int
    ) {
        if (mListData.size > 0) {
            var item: AppInfo?
            for (i in mListData.indices) {
                item = mListData[i]
                if (!TextUtils.isEmpty(item.packageName) && item.packageName == downloadInfo.packageName) {
                    val view = gridLayoutManager!!.findViewByPosition(i)
                    if (view != null) {
                        val progress =
                            downloadInfo.downloadedSize / downloadInfo.sourceSize.toFloat()
                        item.progress = progress
                        (view.findViewById<View>(R.id.statusView) as DownloadStatusView).setProgress(
                            progress
                        )
                    }
                    break
                }
            }
        }
    }

    private fun notifyDataSetChangedWithInterfaceStatusChange(
        downloadInfo: FileDownloadInfo?,
        packageName: String?
    ) {
        /*if (mIMessenger != null)
            mIMessenger.onMessenger();*/
        val position: Int
        position = if (downloadInfo != null) {
            DownloadStatusManager.checkObserverData(mListData, downloadInfo, true)
        } else {
            DownloadStatusManager.checkObserverDataWithTypeApp(mListData, packageName, true)
        }
        if (position >= 0 && position < mListData.size) {
            val mAppInfo = mListData[position]
            val observerStatus = mAppInfo.observerStatus
            DownloadStatusManager.getInstance().registerInfoInstance(mAppInfo)
//            if (observerStatus == FileDownloadInfo.STATUS_WAIT && mAppInfo.observerStatus == FileDownloadInfo.STATUS_DOWNING) {
//                //暂停后继续下载，两个状态，刷新两遍，可能导致icon不显示
//            } else {
//                notifyItemChanged(position)
//            }
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int {
        var count = 0
        if (mListData == null) {
            return count
        }
        count = mListData.size
        return count
    }

    override fun onLongClick(v: View): Boolean {
        if (mOnItemClickListener != null) {
            mOnItemClickListener!!.onItemLongClick(v)
        }
        return false
    }

    // ==================== ViewHolder 层级 ====================

    /**
     * 基类 ViewHolder：定义公共视图引用（图标、名称、进度、遮罩）
     * 所有布局必须包含这些相同 ID 的 View
     */
    internal abstract inner class BaseShortcutsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val itemName: TextView = view.findViewById(R.id.tv_item_name)
        val cardIcon: GlobalShapeClipFrameLayout = view.findViewById(R.id.card_icon)
        val itemIcon: ShapeableImageView = view.findViewById(R.id.img_item_icon)
        val defaultIconShapeAppearance = itemIcon.shapeAppearanceModel
        val globalIconShapeAppearance = defaultIconShapeAppearance.toBuilder()
            .setAllCornerSizes(0f)
            .build()
        val ivDefaultIcon: ImageView = view.findViewById(R.id.iv_default_icon)
        val viewMark: ShapeableImageView = view.findViewById(R.id.view_mark)
        val defaultMarkShapeAppearance = viewMark.shapeAppearanceModel
        val globalMarkShapeAppearance = defaultMarkShapeAppearance.toBuilder()
            .setAllCornerSizes(0f)
            .build()
        val statusView: DownloadStatusView = view.findViewById(R.id.statusView)
    }

    /**
     * 普通条目 ViewHolder（无排名徽章）
     */
    internal inner class NormalViewHolder(view: View) : BaseShortcutsViewHolder(view)

    /**
     * 奖牌榜单条目 ViewHolder（样式4 - RankAppUiModel）
     */
    internal inner class RankAppViewHolder(view: View) : BaseShortcutsViewHolder(view) {
        val ivRankBadge: ImageView = view.findViewById(R.id.ivRankBadge)
    }

    /**
     * RANK_SECTION header ViewHolder：itemView 直接是 FixedRankSectionView，
     * 内部展示 3 个皇冠 app 整组横排。
     */
    internal inner class RankSectionViewHolder(val sectionView: FixedRankSectionView)
        : RecyclerView.ViewHolder(sectionView)
}

// TOP SECRET
package com.afmobi.palmplay.configs.v6_3;

/**
 * Created by zz on 2016/11/8.
 */
public interface BannerItemType {

    String ITEM = "ITEM";//, 1) ,

    String RANK = "RANK";//, 2) ,

    String OUTER_URL = "OUTER_URL";//, 3) ;
}

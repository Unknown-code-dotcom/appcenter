// TOP SECRET
package com.afmobi.palmplay.base;

import de.greenrobot.event.EventBus;

/**
 * 
 * @author HJG
 * @date 2016-1-22 下午3:21:03
 * @modifyAuthor: 
 * @modifyDate: 2016-1-22 下午3:21:03
 * @modifyContent:
 */
public abstract class BaseEventStickyFragmentActivity extends BaseFragmentActivity{
	
	@Override
	public void registerEventBus() {
		EventBus.getDefault().registerSticky(this);
	}
	
	@Override
	public void unregisterEventBus() {
		EventBus.getDefault().unregister(this);
	}

}

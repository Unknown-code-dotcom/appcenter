package com.afmobi.palmplay.clean;

public interface OnCleanUpEventListener {

    void onCleanUpEvent(boolean isSuc);

}

// TOP SECRET
package com.afmobi.palmplay.configs.v6_3;

/**
 * Created by HJG on 2016/11/8.
 */
public class RankItemType {

    // Note: not use  type 0

    public static final String SOFT = "SOFT";
    public static final int SOFT_VALUE = 1;

    public static final String VIDEO = "VIDEO";
    public static final int VIDEO_VALUE = 2;

    public static final String MUSIC = "MUSIC";
    public static final int MUSIC_VALUE = 3;

    public static final String SINGER = "SINGER";
    public static final int SINGER_VALUE = 4;

    public static final String EBOOK = "EBOOK";
    public static final int EBOOK_VALUE = 5;

    public static final String IMAGEFILE = "IMAGEFILE";
    public static final int IMAGEFILE_VALUE = 6;

    public static final String IMAGEDIR = "IMAGEDIR";
    public static final int IMAGEDIR_VALUE = 7;

    // ----------------------

    private static final int BASE_MULTIPLIER = 100;

    public static int getTypeSetValue(int typeValue, int styleType) {
        return typeValue * BASE_MULTIPLIER + styleType;
    }
}

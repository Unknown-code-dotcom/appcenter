package com.afmobi.palmplay.clean;

import android.os.Bundle;
import com.transsion.palmstorecore.BaseCoreActivity;
import com.afmobi.util.PadUtils;
import android.view.View;

import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.transsion.palmstorecore.util.AndroidVUIUtils;
import com.transsnet.store.R;

/**
 * 磁盘空间不足提示；
 * 2018年6月27日11:02:10
 */
public class DiskSpaceNotEnoughTipsActivity extends BaseCoreActivity implements View.OnClickListener {

    private PageParamInfo pageParamInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disk_space_not_enough_tips);
        AndroidVUIUtils.INSTANCE.matchAndroid15UI(this, false);
        pageParamInfo = getIntent().getParcelableExtra(PageParamInfo.class.getSimpleName());
        pageParamInfo = PageConstants.deliverPageParamInfo(pageParamInfo, PageConstants.Nospace_Show);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(pageParamInfo);
        findViewById(R.id.btn_cancel).setOnClickListener(this);
        findViewById(R.id.btn_ok).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_cancel:
                finish();
                break;

            case R.id.btn_ok:
                /*Intent intent = new Intent(this, CleanNativeMemoryActivity.class);
                intent.putExtra(PageParamInfo.class.getSimpleName(), pageParamInfo);
                startActivity(intent);*/
                finish();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        // nothing
    }

    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadActivityAsDialog(this);
    }
}

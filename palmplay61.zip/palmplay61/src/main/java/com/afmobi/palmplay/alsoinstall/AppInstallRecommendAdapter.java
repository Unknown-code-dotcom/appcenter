package com.afmobi.palmplay.alsoinstall;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.adapter.PalmBaseDownloadRecyclerViewAdapter;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.InterfaceStatusChange;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.main.adapter.EmptyRecyclerViewHolder;
import com.afmobi.palmplay.model.DecorateInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.search.v9_3.SearchActivity_v9_3;
import com.transsnet.store.R;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class AppInstallRecommendAdapter extends PalmBaseDownloadRecyclerViewAdapter {

    public final static int VIEW_TYPE_HORIZONTAL = 801;
    public final static int VIEW_TYPE_VERTICAL = 802;

    private Context mContext;
    private List<FeatureBaseData> mList = new ArrayList<>();
    private FeatureBean mFeatureBean;
    private LayoutInflater inflater;
    private String mStyle = null;
    private RecyclerView mRecyclerView;
    private OfferInfo mOfferInfo;
    private String mFromPage;
    private DecorateInfo mDecorate;
    private String topicPlace;
    private String placementId;
    private boolean gdprHasAllowed;
    private String featureId;
    private String extraValue;
    private String extras;

    public AppInstallRecommendAdapter(FeatureBean featureBean, DecorateInfo decorate, RecyclerView recyclerView) {
//        this.mContext = context;
        this.inflater = LayoutInflater.from(recyclerView.getContext());
        this.mRecyclerView = recyclerView;

        setData(featureBean, decorate, false);
    }

    public AppInstallRecommendAdapter setData(FeatureBean featureBean, DecorateInfo decorate, boolean isNotify) {
        this.mFeatureBean = featureBean;
        this.mDecorate = decorate;

        if (decorate != null) {
            mStyle = decorate.decorateStyle;
        }
        if (featureBean != null) {
            featureId = featureBean.featureId;
        }

        initData();

        if (isNotify) {
            notifyDataSetChanged();
        }

        return this;
    }


    private void initData() {

        mList.clear();

        DecorateInfo decorateInfo = mDecorate;

        if (decorateInfo == null || TextUtils.isEmpty(decorateInfo.decorateStyle) || decorateInfo.dataList == null) {
            return;
        }

        int showIndex = decorateInfo.showIndex;
        List<FeatureBaseData> list = decorateInfo.dataList;
        int total = list.size();

        switch (decorateInfo.decorateStyle) {
            case DecorateInfo.DECORATE_STYLE_H:
            case DecorateInfo.DECORATE_STYLE_V:

                final int defaultLine = TextUtils.equals(decorateInfo.decorateStyle, DecorateInfo.DECORATE_STYLE_H) ?
                        AppInstallRecommendManager.H_STYLE_LINE_DEFAULT : AppInstallRecommendManager.V_STYLE_LINE_DEFAULT;

                if (total > defaultLine) {
                    if (showIndex < 0 || showIndex >= total) {
                        showIndex = 0;
                    }

                    int maxShow = showIndex + defaultLine;
                    for (int i = showIndex;i < total && i < maxShow;i++) {
                        mList.add(list.get(i));
                    }

                    int needItem = defaultLine - mList.size();
                    if (needItem > 0) {
                        for (int i = 0;i < total && i < needItem;i++) {
                            mList.add(list.get(i));
                        }
                    }

                    decorateInfo.showIndex = (showIndex + defaultLine) % total;
                }else {
                    mList.addAll(list);
                }
                break;

            case DecorateInfo.DECORATE_STYLE_H_SCROLL:
                mList.addAll(list);
                break;

            default:
                break;
        }
    }

    public AppInstallRecommendAdapter setOfferInfo(OfferInfo offerInfo) {
        this.mOfferInfo = offerInfo;
        return this;
    }

    public AppInstallRecommendAdapter setFromPage(String fromPage) {
        this.mFromPage = fromPage;
        return this;
    }

    public AppInstallRecommendAdapter setTopicPlace(String topicPlace) {
        this.topicPlace = topicPlace;
        return this;
    }

    public AppInstallRecommendAdapter setPlacementId(String placementId) {
        this.placementId = placementId;
        return this;
    }

    public AppInstallRecommendAdapter setGdprHasAllowed(boolean gdprHasAllowed) {
        this.gdprHasAllowed = gdprHasAllowed;
        return this;
    }

    public AppInstallRecommendAdapter setExtraValue(String extraValue) {
        this.extraValue = extraValue;
        return this;
    }

    public AppInstallRecommendAdapter setExtras(String extras) {
        this.extras = extras;
        return this;
    }

    public boolean isNetData() {
        if (mDecorate != null) {
            return mDecorate.isNetData;
        }

        return false;
    }

    public void onRefreshClicked() {
        initData();

        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (VIEW_TYPE_HORIZONTAL == viewType) {
            return new AppInstallRecommendHorizontalViewHolder(DataBindingUtil.inflate(inflater, R.layout.z_layout_app_install_recommend_list_item_h, parent, false));
        } else if (VIEW_TYPE_VERTICAL == viewType) {
            return new AppInstallRecommendVerticalViewHolder(DataBindingUtil.inflate(inflater, R.layout.z_layout_app_install_recommend_list_item_v, parent, false));
        } else {
            return new EmptyRecyclerViewHolder(inflater.inflate(R.layout.layout_home_typeempty_list_item, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        FeatureBaseData data = getItemByPosition(position);

        if (VIEW_TYPE_HORIZONTAL == viewType) {
            AppInstallRecommendHorizontalViewHolder viewHolder = (AppInstallRecommendHorizontalViewHolder) holder;
            viewHolder.setExtraValue(extraValue);
            viewHolder.setExtras(extras);
            viewHolder.setScreenPageName(mScreenPageName)
                    .setFeatureName(mFeaturedName)
                    .setFromPage(mFromPage)
                    .setFrom(mFrom)
                    .setOfferInfo(mOfferInfo)
                    .setStyleName(mStyle)
                    .setTopicPlace(topicPlace)
                    .setPlacementId(placementId)
                    .setGdprHasAllowed(gdprHasAllowed)
                    .setFeaturedId(featureId)
                    .setNetData(isNetData())
                    .bind(data, position);

        } else if (VIEW_TYPE_VERTICAL == viewType) {
            AppInstallRecommendVerticalViewHolder viewHolder = (AppInstallRecommendVerticalViewHolder) holder;
            viewHolder.setScreenPageName(mScreenPageName)
                    .setFeatureName(mFeaturedName)
                    .setFromPage(mFromPage)
                    .setFrom(mFrom)
                    .setOfferInfo(mOfferInfo)
                    .setStyleName(mStyle)
                    .setTopicPlace(topicPlace)
                    .setPlacementId(placementId)
                    .setGdprHasAllowed(gdprHasAllowed)
                    .setFeaturedId(featureId)
                    .setNetData(isNetData())
                    .setFeatureId(featureId)
                    .bind(data, position);
        }
    }

    @Override
    public int getItemCount() {
        return (mList == null) ? 0 : mList.size();
    }

    @Override
    public int getItemViewType(int position) {

        DecorateInfo decorateInfo = mDecorate;
        if (decorateInfo != null) {
            if (TextUtils.equals(DecorateInfo.DECORATE_STYLE_H, decorateInfo.decorateStyle)
                || TextUtils.equals(DecorateInfo.DECORATE_STYLE_H_SCROLL, decorateInfo.decorateStyle)) {
                return VIEW_TYPE_HORIZONTAL;
            }else if (TextUtils.equals(DecorateInfo.DECORATE_STYLE_V, decorateInfo.decorateStyle)) {
                return VIEW_TYPE_VERTICAL;
            }
        }

        return super.getItemViewType(position);
    }

    private FeatureBaseData getItemByPosition(int pos) {
        if (pos < 0 || pos >= getItemCount()) {
            return null;
        }

        return mList.get(pos);
    }


    private FeatureItemData getFeatureItemDataByPackageName(String pkg) {
        if (TextUtils.isEmpty(pkg)) {
            return null;
        }

        if (mDecorate == null || mDecorate.dataList == null) {
            return null;
        }

        Iterator<FeatureBaseData> it = mDecorate.dataList.iterator();
        while (it.hasNext()) {
            FeatureBaseData item = it.next();
            if (item instanceof FeatureItemData) {
                FeatureItemData info = (FeatureItemData) item;
                if (TextUtils.equals(info.packageName, pkg)) {
                    return info;
                }
            }
        }

        return null;
    }

    private int getPositionByPackageName(String pkg) {
        if (TextUtils.isEmpty(pkg)) {
            return -1;
        }

        if (mList == null || mList.isEmpty()) {
            return -1;
        }

        for (int i = 0;i < mList.size();i++) {
            FeatureBaseData item = mList.get(i);
            if (item instanceof FeatureItemData) {
                FeatureItemData data = (FeatureItemData) item;
                if (TextUtils.equals(data.packageName, pkg)) {
                    return i;
                }
            }
        }

        return -1;
    }


    private void notifyDataSetChangedWithInterfaceStatusChange(FileDownloadInfo downloadInfo) {

        String pkg = downloadInfo != null ? downloadInfo.packageName : null;
        FeatureItemData item = getFeatureItemDataByPackageName(pkg);

        DownloadStatusManager.getInstance().registerFeatureItemInstance(item);

        try {
            int position = getPositionByPackageName(pkg);
            if(position != -1) {
                notifyItemChanged(position);
            }
        } catch (Exception e) {

        }
    }

    private void onAppPackageChange(String packageName, int versionCode) {

        FeatureItemData item = getFeatureItemDataByPackageName(packageName);

        DownloadStatusManager.getInstance().registerFeatureItemInstance(item);

        notifyDataSetChanged();
    }

    public void updateDownloadingProgressBar(FileDownloadInfo downloadInfo, int speed) {
        if (downloadInfo != null && mRecyclerView != null) {
            LinearLayoutManager mLayoutManager = (LinearLayoutManager) mRecyclerView.getLayoutManager();
            int firstVisibleItemPosition = mLayoutManager.findFirstVisibleItemPosition();
            int lastVisibleItemPosition = mLayoutManager.findLastVisibleItemPosition();

            for (int i = firstVisibleItemPosition; i <= lastVisibleItemPosition; i++) {
                AppInstallRecommendBaseViewHolder viewHolder = null;
                View itemView = mLayoutManager.findViewByPosition(i);
                if (itemView == null)
                    continue;
                Object objTag = itemView.getTag();
                if (objTag instanceof FeatureItemData) {

                    FeatureItemData item = (FeatureItemData) objTag;

                    if (!TextUtils.isEmpty(item.packageName)
                            && TextUtils.equals(item.packageName, downloadInfo.packageName)
                            && mRecyclerView.getChildViewHolder(itemView) instanceof AppInstallRecommendBaseViewHolder) {

                        XFermodeDownloadView downloadView = itemView.findViewById(R.id.downloadView);
                        viewHolder = (AppInstallRecommendBaseViewHolder) mRecyclerView.getChildViewHolder(itemView);
                        viewHolder.updateItemProgress(downloadView, downloadInfo, mOfferInfo);
                        break;
                    }
                }
            }
        }
    }

    @Override
    public Object loaderInterfaceStatusChangeObjectKey() {
        Object statusKey = System.currentTimeMillis();
        if (this.mRecyclerView != null && this.mRecyclerView.getContext() instanceof SearchActivity_v9_3) {
            SearchActivity_v9_3 mActivity = (SearchActivity_v9_3) this.mRecyclerView.getContext();
            statusKey = "TR_search_"+ mActivity + statusKey;
        }
        return statusKey;
    }

    private StableStatusChangeListener mStableListener;
    @Override
    public InterfaceStatusChange loaderInterfaceStatusChange() {
        if (mStableListener == null) {
            mStableListener = new StableStatusChangeListener(this);
        }
        return mStableListener;
    }

/*
    private WeakReference<InterfaceStatusChange> newInterChange() {
        return new WeakReference<>(new InterfaceStatusChange() {
            @Override
            public void onDownloadStart(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo, long downloadedBytes, long fileLength, int speed) {

                if (downloadInfo == null || downloadInfo.isVa()) {
                    return;
                }
                if (!DetailType.isApp(downloadInfo.type)) {
                    return;
                }
                updateDownloadingProgressBar(downloadInfo, speed);
            }

            @Override
            public void onDownloadComplete(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onActivated(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadError(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadPause(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadResume(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onDownloadDelete(FileDownloadInfo downloadInfo) {
                notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
            }

            @Override
            public void onAppPackageAdded(String packageName, int versionCode) {
                onAppPackageChange(packageName, versionCode);
            }

            @Override
            public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
                onAppPackageChange(packageName, versionCode);
            }
        });
    };
*/

    static class StableStatusChangeListener implements InterfaceStatusChange {

        private final WeakReference<AppInstallRecommendAdapter> mAdapterRef;

        StableStatusChangeListener(AppInstallRecommendAdapter adapter) {
            this.mAdapterRef = new WeakReference<>(adapter);
        }

        private AppInstallRecommendAdapter get() {
            return mAdapterRef.get();
        }

        @Override
        public void onDownloadStart(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onDownloadProgressUpdate(FileDownloadInfo downloadInfo,
                                             long downloadedBytes, long fileLength, int speed) {
            AppInstallRecommendAdapter a = get();
            if (a == null) return;
            if (downloadInfo == null || downloadInfo.isVa()) return;
            if (!DetailType.isApp(downloadInfo.type)) return;
            a.updateDownloadingProgressBar(downloadInfo, speed);
        }

        @Override
        public void onDownloadComplete(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onActivated(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onDownloadError(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onDownloadPause(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onDownloadResume(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onDownloadDelete(FileDownloadInfo downloadInfo) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.notifyDataSetChangedWithInterfaceStatusChange(downloadInfo);
        }

        @Override
        public void onAppPackageAdded(String packageName, int versionCode) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.onAppPackageChange(packageName, versionCode);
        }

        @Override
        public void onAppPackageRemoved(String packageName, int versionCode, int modifyStatusFrom) {
            AppInstallRecommendAdapter a = get();
            if (a != null) a.onAppPackageChange(packageName, versionCode);
        }
    }


    @Override
    public void onViewAttachedToWindow(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewAttachedToWindow(holder);

    }

    @Override
    public void onViewDetachedFromWindow(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewDetachedFromWindow(holder);

    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        onCreateView();
    }

    @Override
    public void onDetachedFromRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);
        onDestroy();
    }
}

package com.afmobi.palmplay.alonefuction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.afmobi.palmplay.activate.TRUpdateVersionExecutor;
import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.base.BaseUpgradeActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.transsion.calculator.NoNetworkTipExclude;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.PalmPlayVersionManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.Constant;
import com.afmobi.util.DateHelper;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsnet.store.R;

import java.io.File;

@NoNetworkTipExclude
public class NewVersionTipActivity extends BaseUpgradeActivity {

    private int mTipCount = 0;
    private PageParamInfo mPageParamInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (null == mClientVersion) {
            return;
        }
        TRUpdateVersionExecutor.STATUS = true;
        preHandlerUpgradeRate(mClientVersion.versionCode);

        mPageParamInfo = new PageParamInfo();
        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.UpdateTip);
        if (PageConstants.Sidebar_Menu.equals(mPageParamInfo.getLastPage())) {
            mPageParamInfo.setCurPage(PageConstants.Setting_Update_Tips);
        }
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

        TRAnalysticsUtil.trackSelftUpdateShow(mTipCount, mNewVerStr, mClientVersion.upgradeFashion, mClientVersion.id, mClientVersion.versionCode);
    }

    private void preHandlerUpgradeRate(int onlineVersion) {
        int tipsVersionCode = SPManager.getInt(Constant.preferences_key_tips_version_code, 0);
        mTipCount = SPManager.getInt(Constant.preferences_key_tips_version_count, 0);
        mTipCount = mTipCount + 1;
        if (onlineVersion != tipsVersionCode) {
            mTipCount = 1;
            SPManager.putInt(Constant.preferences_key_tips_version_code, onlineVersion);
        }
        String curDayStr = DateHelper.getNowTime();
        SPManager.putString(Constant.preferences_key_tips_version_last_date, curDayStr);
        SPManager.putInt(Constant.preferences_key_tips_version_count, mTipCount);
    }

    @Override
    protected int getDefaultUpdateMessage() {
        return R.string.text_upgrade_content;
    }

    @Override
    public void onClick(View v) {
        String upgradeFashion = mClientVersion == null ? "" : mClientVersion.upgradeFashion;
        String id = mClientVersion == null ? "" : mClientVersion.id;
        int versionCode = mClientVersion == null ? -100 : mClientVersion.versionCode;

        switch (v.getId()) {
            case R.id.tv_cancel:
                FirebaseAnalytics.getInstance(getApplicationContext()).logEvent(FirebaseConstants.EVENT_UPDATE_POPOFF_CLICK, null);
                TRAnalysticsUtil.trackSelfUpdateClick(4, mNewVerStr, upgradeFashion, id, versionCode);
                finish();
                break;
            case R.id.tv_ok:
                updateButtonClick();
                TRAnalysticsUtil.trackSelfUpdateClick(1, mNewVerStr, upgradeFashion, id, versionCode);
                break;
            default:
                break;
        }
    }

    private void updateButtonClick() {
        FirebaseAnalytics.getInstance(getApplicationContext()).logEvent(FirebaseConstants.EVENT_UPDATE_POPUP_CLICK, null);

        ClientVersion clientVersion = PalmPlayVersionManager.getInstance().getNewClientVersionInfo();
        String newVersionFilePath = FilePathManager.myselfNewVersionFilePath();
        File newVersionFile = new File(newVersionFilePath);
        if (!newVersionFile.exists()) {
            SPManager.remove(Constant.preferences_key_downloaded_version_code);
        }

        String updateFromPage = TRAnalyticsConstant.FROMPAGE_CLICK;
        if (null != clientVersion) {
            if (PageConstants.Sidebar_Menu.equals(mPageParamInfo.getLastPage())) {
                updateFromPage = TRAnalyticsConstant.FROMPAGE_SETTING;
            }

            TRAnalysticsUtil.palmsClientUpdateClick(updateFromPage, clientVersion.versionCode, clientVersion.upgradeFashion, clientVersion.id, clientVersion.versionCode);
        }

        int versionCode = SPManager.getInt(Constant.preferences_key_downloaded_version_code, 0);
        if (null != clientVersion && clientVersion.versionCode == versionCode) {
            startInstalling();
            finish();
        } else {
            startUpgrading(updateFromPage);
        }
    }

    @Override
    public void onBackPressed() {
        String upgradeFashion = mClientVersion == null ? "" : mClientVersion.upgradeFashion;
        String id = mClientVersion == null ? "" : mClientVersion.id;
        int versionCode = mClientVersion == null ? -100 : mClientVersion.versionCode;
        TRAnalysticsUtil.trackSelfUpdateClick(3, mNewVerStr,
                upgradeFashion, id, versionCode);
        super.onBackPressed();
    }

    public static Intent getIntoIntent(Context mContext, boolean isFromNotify, PageParamInfo pageParamInfo) {
        Intent intent = new Intent(mContext, NewVersionTipActivity.class)
                .putExtra(FromPageType.Notify, isFromNotify);
        if (!(mContext instanceof android.app.Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        PageConstants.putPageParamInfo(intent, pageParamInfo);
        return intent;
    }

    public static void into(Context mContext, boolean isFromNotify, PageParamInfo pageParamInfo) {
        FirebaseAnalytics.getInstance(mContext.getApplicationContext()).logEvent(FirebaseConstants.EVENT_UPDATE_POPUP_SHOW, null);
        mContext.startActivity(getIntoIntent(mContext, isFromNotify, pageParamInfo));
    }

    @Override
    protected boolean isForceUpdate() {
        return false;
    }

    @Override
    public void finish() {
        super.finish();
        TRUpdateVersionExecutor.STATUS = false;

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TRUpdateVersionExecutor.STATUS = false;
        TRNewManager.getCloseListener().onDialogClosed();
    }
}    
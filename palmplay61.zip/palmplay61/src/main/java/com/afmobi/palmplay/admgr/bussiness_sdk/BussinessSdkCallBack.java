package com.afmobi.palmplay.admgr.bussiness_sdk;


public interface BussinessSdkCallBack {
    void showAdUi(boolean canShowSdkUi);
    void gotoHomePage();
    void recordSdkClicked();
}

package com.afmobi.palmplay.alonefuction;

public class H5TaskInfo {
    public int id;
    public int state = 0;
    public String pkg;
    public int type;
}

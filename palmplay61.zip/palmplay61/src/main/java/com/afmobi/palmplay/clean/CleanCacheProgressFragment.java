package com.afmobi.palmplay.clean;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseFragment;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_6.ScanResult;
import com.afmobi.util.DisplayUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;

import androidx.annotation.Nullable;

/**
 * 深度清理页面上半部分--显示进度和size
 * Created by xiangfei.wei on 2017/11/29.
 */

public class CleanCacheProgressFragment extends BaseFragment {

    private static final String BG_COLOR_BLUE = "#0A9BEB";
    private static final String BG_COLOR_RED = "#EE4866";
    private long totalCacheSize;
    private long totalCacheSizeTemp;

    private Activity mActivity;
    private LinearLayout ll_background;
    private TextView tv_size, tv_unit, tv_fileName, tv_release, tv_size_complete, tv_unit_complete;
    private View progress_view;
    private ValueAnimator progressViewAnim;
    private ProgressBar progressBar;
    private RelativeLayout rl_progress, rl_size_scaning, rl_size_complete;
    private ImageView iv_rocket;

    private int mScreenWidth;
    private ValueAnimator colorAnim;
    private ValueAnimator mCompleteValueAnimator;
    private boolean isUsePmScan;

    public static CleanCacheProgressFragment newInstance() {
        return new CleanCacheProgressFragment();
    }

    public void setIsUsePmScan(boolean isUsePmScan) {
        this.isUsePmScan = isUsePmScan;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = (Activity) context;
        mScreenWidth = DisplayUtil.getScreenWidthPx(mActivity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_clean_cache_progress, container, false);
        ll_background = (LinearLayout) contentView.findViewById(R.id.ll_background);
        tv_size = (TextView) contentView.findViewById(R.id.tv_size);
        tv_unit = (TextView) contentView.findViewById(R.id.tv_unit);
        progress_view = contentView.findViewById(R.id.progress_view);
        tv_fileName = (TextView) contentView.findViewById(R.id.tv_fileName);
        progressBar = (ProgressBar) contentView.findViewById(R.id.progressBar);
        rl_progress = (RelativeLayout) contentView.findViewById(R.id.rl_progress);
        // iv_rocket = (ImageView) contentView.findViewById(R.id.iv_rocket);
        tv_release = (TextView) contentView.findViewById(R.id.tv_release);
        rl_size_scaning = (RelativeLayout) contentView.findViewById(R.id.rl_size_scaning);
        rl_size_complete = (RelativeLayout) contentView.findViewById(R.id.rl_size_complete);
        tv_size_complete = (TextView) contentView.findViewById(R.id.tv_size_complete);
        tv_unit_complete = (TextView) contentView.findViewById(R.id.tv_unit_complete);
        return contentView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // 背景颜色变化
        colorAnim = ObjectAnimator.ofInt(ll_background, "backgroundColor", getResources().getColor(R.color.dialog_bg_color), Color.parseColor(BG_COLOR_RED), getResources().getColor(R.color.dialog_bg_color));
        colorAnim.setDuration(5000);
        colorAnim.setEvaluator(new ArgbEvaluator());
        //colorAnim.setRepeatCount(ValueAnimator.INFINITE);
        //colorAnim.setRepeatMode(ValueAnimator.REVERSE);
        colorAnim.start();
    }

    public void scanProgressUpdate(ScanResult scanResult, CacheListItem item) {
        if (isUsePmScan) {
            totalCacheSize = scanResult.cacheSize + scanResult.uninstallSize
                            + scanResult.systemCacheSize;

            long apkFilesSize = 0;
            if (null != scanResult.getApkList()) {
                for (CacheListItem apk : scanResult.getApkList()) {
                    apkFilesSize += apk.getSize();
                }
                totalCacheSize = totalCacheSize + apkFilesSize;
            }

            if (BuildConfig.DEBUG){
                LogUtils.d("CleanPage----ScanManager----scanProgressUpdate: " + totalCacheSize + "----" + scanResult.toString());
            }

            int currentProgress = progressBar.getProgress();
            int leftProgress = 100 - currentProgress;
            leftProgress = Math.min(100, leftProgress);

            final int progress;
            if (leftProgress >= 4) {
                progress = (int) (leftProgress / 4f);
            }else {
                progress = 0;
            }

            progressBar.setProgress(currentProgress + progress);
        }else {
//            totalCacheSize += item.getSize();
            //更新进度条
            if (CacheListItem.Type.MEMORY == item.type) {
                progressBar.setProgress(20);
            } else if (CacheListItem.Type.MOUNTING == item.type) {
                long apkFilesSize = 0;
                if (null != scanResult.getApkList()) {
                    for (CacheListItem apk : scanResult.getApkList()) {
                        if (!TextUtils.isEmpty(apk.apkPath)) {
                            File file = new File(apk.apkPath);
                            if (file.exists()) {
                                apkFilesSize += apk.getSize();
                            }
                        }
                    }
                }
                totalCacheSize += apkFilesSize;
                //progressBar.setProgress(40);
            } else if (CacheListItem.Type.UNINSTALL == item.type) {
                totalCacheSize += scanResult.uninstallSize;
            } else if (CacheListItem.Type.CACHE == item.type) {
                progressBar.setProgress(100);
                totalCacheSize += scanResult.cacheSize;
            } else {
                if (progressBar.getProgress() <= 98)
                    progressBar.setProgress(progressBar.getProgress() + 1);
            }
        }

        if (totalCacheSizeTemp != totalCacheSize){
            totalCacheSizeTemp = totalCacheSize;
            //更新总缓存大小显示
            updateTotalSize();
        }
        //更新 扫描中的文件或应用名
        String scanning = PalmplayApplication.getAppInstance().getString(R.string.text_scan_file_name);
        String scanningPm = PalmplayApplication.getAppInstance().getString(R.string.text_scanning);
        String prefix = isUsePmScan ? scanningPm : scanning;
        String txt = prefix + "  " + (TextUtils.isEmpty(item.getApplicationName()) ? item.getPackageName() : item.getApplicationName());
        tv_fileName.setText(txt);
    }

    private void updateTotalSize() {
        String original = ProcessAndMemoryUtil.formatSizeKbMbGb(totalCacheSize, 1);
        if (original.endsWith("KB")) {
            tv_size.setText(original.substring(0, original.indexOf("KB")));
            tv_unit.setText("KB");
        } else if (original.endsWith("MB")) {
            tv_size.setText(original.substring(0, original.indexOf("MB")));
            tv_unit.setText("MB");
        } else if (original.endsWith("GB")) {
            tv_size.setText(original.substring(0, original.indexOf("GB")));
            tv_unit.setText("GB");
        }else if(original.endsWith("B")){
            tv_size.setText(original.substring(0, original.indexOf("B")));
            tv_unit.setText("B");
        }
    }

    public void onScanStart() {
        progressViewAnim();
    }

    private void progressViewAnim() {
        if (progressViewAnim == null) {
            progressViewAnim = ValueAnimator.ofFloat(0.0f, 1f);
            progressViewAnim.setDuration(1500);
//             progressViewAnim.setRepeatCount(ValueAnimator.INFINITE);
//             progressViewAnim.setRepeatMode(ValueAnimator.RESTART);
            progressViewAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    float progress = (Float) valueAnimator.getAnimatedValue();
                    //System.out.println("progress = " + progress);
                    if (progress_view != null) {
                        progress_view.getLayoutParams().width = (int) (mScreenWidth * progress);
                        progress_view.requestLayout();
                    }
                }
            });
            progressViewAnim.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    animDelayHandler.sendEmptyMessageDelayed(PROGRESS_VIEW_ANIM_DELAY, 1000);
                }
            });
        }
        progressViewAnim.start();
    }

    private void cancelProgressViewAnim() {
        if (progressViewAnim != null)
            progressViewAnim.cancel();
        if (animDelayHandler != null) {
            animDelayHandler.removeCallbacksAndMessages(null);
        }
    }

    private static final int PROGRESS_VIEW_ANIM_DELAY = 11;
    private Handler animDelayHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == PROGRESS_VIEW_ANIM_DELAY) {
                progressViewAnim();
            }
        }
    };

    public void onScanComplete(long totalCacheSize) {
        this.totalCacheSize = totalCacheSize;
        updateTotalSize();
        cancelProgressViewAnim();
        rl_progress.setVisibility(View.GONE);

        mCompleteValueAnimator = ValueAnimator.ofInt(DisplayUtil.dip2px(mActivity, 236), DisplayUtil.dip2px(mActivity, 196));
        mCompleteValueAnimator.setDuration(500);
        mCompleteValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                if (ll_background != null){
                    ll_background.getLayoutParams().height = (Integer) valueAnimator.getAnimatedValue();
                    ll_background.requestLayout();
                }
            }
        });
        mCompleteValueAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
               /*iv_rocket.setVisibility(View.GONE);
                tv_size.setTextSize(52);
                tv_unit.setTextSize(20);
                tv_release.setTextSize(14);*/
                tv_size_complete.setText(tv_size.getText());
                tv_unit_complete.setText(tv_unit.getText());
                rl_size_scaning.setVisibility(View.GONE);
                rl_size_complete.setVisibility(View.VISIBLE);
                ((CleanNativeMemoryActivity) mActivity).addCleanCacheScanCompleteFragment();
            }
        });
        mCompleteValueAnimator.start();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        cancelProgressViewAnim();
        if (colorAnim != null) {
            colorAnim.cancel();
        }

        if(mCompleteValueAnimator != null && mCompleteValueAnimator.isRunning()){
            mCompleteValueAnimator.cancel();
        }
    }
}

// TOP SECRET
package com.afmobi.palmplay.configs.v6_3;

import com.afmobi.palmplay.home.viewholder.TrHomeFindBannerSingleItemViewHolder;

/**
 * Created by HJG on 2016/11/8.
 */
public class RankType {

    // Note: not use  type 0
    public static final String EMPTY = "EMPTY";
    public static final String BANNER = "BANNER";
    public static final String LIST = "LIST";
    public static final String SDK = "SDK";
    public static final String UPDATE = "UPDATE";
    public static final String SUSCRIBE = "SUSCRIBE";
    public static final String ADMOB = "ADMOB";
    public static final String CPM_AD = "WEB_VIEW";
    public static final String MARGIN = "MARGIN";

    public static final String NEW_TITLE = "NEW_TITLE";
    public static final String NEW_SEE_MORE = "NEW_SEE_MORE";
    public static final String HOME_GUIDE = "HOME_GUIDE";
    public static final String HOME_SSP_AD = "HOME_SSP_AD";
    public static final String SOFT_CATEGORY = "SOFT_CATEGORY";
    public static final String HOME_CATEGORY = "CATEGORY";
    public static final String HOME_OFFER_ACTIVATE = "HOME_OFFER_ACTIVATE";//offer激活
    public static final String HOME_CHECKIN = "HOME_CHECKIN";
    public static final String HOME_TOPBANNER_NEW = "HOME_TOPBANNER_NEW";
    /**
     * Game 频道沉浸式 banner（topic tab 首条 item）
     */
    public static final String GAME_IMMERSIVE_BANNER = "GAME_IMMERSIVE_BANNER";
    public static final String HOT_WORD = "HOT_WORD";
    public static final String HOT_WORD_RANKING = "HOT_WORD_RANKING";
    public static final String HOME_RACE_LAMP_TYPE = "HOME_RACE_LAMP_TYPE";

    public static final String SHORT_BANNER = "SHORT_BANNER";

    public static final String HOME_RANK_H_V4 = "RANK_H_V4";//横向排布 纵向4列

    public static final String RANK_ITEM_BANNER = "RANK_ITEM_BANNER";//大图+ICON+BUTTON
    public static final String RANK_BG_5ICON = "RANK_BG_5ICON";//大图+底部5ICON

    public static final String GAME_TOP_GAMES = "GAME_TOP_GAMES"; // 最近玩游戏

    public static final String ONE_CLICK_HORIZONTAL_4 = "ONE_CLICK_HORIZONTAL_4"; // 一键下载横向4icon带标题样式
    public static final String ONE_CLICK_VERTICAL_TITLE = "ONE_CLICK_VERTICAL_TITLE"; // 一键下载纵向带标题样式


    //FIND
    /**
     * {@link com.afmobi.palmplay.home.viewholder.TrHomeFindWhiteBgItemViewHolder}
     */
    public static final String HOME_FIND_ITEM_WHITE = "FIND_ITEM_WHITE";
    /**
     * {@link com.afmobi.palmplay.home.viewholder.TrHomeFindTransparentBgItemViewHolder}
     */
    public static final String HOME_FIND_ITEM = "FIND_ITEM";
    /**
     * {@link com.afmobi.palmplay.home.viewholder.TrHomeFindRankSingleLineViewHolder}
     */
    public static final String HOME_FIND_ITEM_LIST = "FIND_ITEM_LIST";

    /**
     * {@link com.afmobi.palmplay.home.viewholder.TrHomeFindVideoSingleItemViewHolder}
     */
    public static final String HOME_FIND_VIDEO_ITEM_WHITE = "FIND_ITEM_VIDEO_WHITE";

    /**
     * [V10.0.2]Find 图片大卡样式（日历大卡，原视频位置替换为封面图）
     * {@link TrHomeFindBannerSingleItemViewHolder}
     */
    public static final String HOME_FIND_BANNER_ITEM_WHITE = "FIND_ITEM_BANNER_WHITE";

    //RANK
    public static final String HOME_AUTO_SCROLL_MULTI_LINE = "RANK_R_H3";//多行app自行滚动样式
    /**
     * 大图+底部4icon样式
     * {@link #HOME_BG_SINGLE_LINE_4ICON_VALUE}
     */
    public static final String HOME_BG_SINGLE_LINE_4ICON = "RANK_BG_4ICON";

    /**
     * 单个产品样式
     * {@link #HOME_ITEM_WHITE_BG_VALUE}
     */
    public static final String HOME_ITEM_WHITE_BG = "ITEM_BG_WHITE";

    //专题集
    public static final String HOME_RANK_GROUP_2FIELD = "RANK_GROUP_FIELD";//左右2个专题集样式

    //独立专题页
    public static final String FEATURE_DEFAULT_RANK_PAGE = "DEFAULT_RANK_PAGE";   //通用排行榜样式
    public static final String V_TITLE = "V_TITLE";

    public static final String RANK_MEDAL_STALE = "RANK_MEDAL_STYLE";
    public static final String FEATURE_RANKING_LIST = "RANKING_LIST";             //顶图+列表
    public static final String FEATURE_HEAD3_RANKING_LIST = "HEAD3_RANKING_LIST"; //存在头部的排行榜样式(领奖台布局)
    public static final String FEATURE_ACTIVITY = "ACTIVITY";                     //活动样式
    public static final String FEATURE_ACTIVITY_STYLE_NO_RATE = "ACTIVITY_STYLE_NO_RATE";                     //活动样式无评分

    public static final String H5_HOT_RANK= "H5_GAME_RANKING";//热门榜单卡片
    public static final String H5_GAME_CARD= "H5_GAME_FLOW";//H5游戏卡片

    public static final String H5_GAME_RANK_ITEM = "H5_HOT_RANK";//榜单样式
    public static final String H5_GAME_ITEM = "H5_GAME_ITEM";//H5游戏普通item

    public static final String CATEGORY_FOUR_BANNER = "CATEGORY_FOUR_BANNER";//双行4banner

    //搜索热词
    public static final String HOTWORD_COMMON = "COMMON";                     //热词样式

    public static final int EMPTY_VALUE = -1;
    public static final int BANNER_VALUE = 1;
    public static final int LIST_VALUE = 2;
    public static final int SDK_VALUE = 3;
    public static final int UPDATE_VALUE = 4;
    public static final int SUSCRIBE_VALUE = 5;
    public static final int ADMOB_VALUE = 6;
    public static final int CPM_AD_VALUE = 7;
    public static final int NEW_TITLE_VALUE = 8;
    public static final int NEW_SEE_MORE_VALUE = 9;
    public static final int HOME_GUIDE_VALUE = 10;
    public static final int HOME_SSP_AD_VALUE = 11;
    public static final int SOFT_CATEGORY_VALUE = 13;
    public static final int HOME_CATEGORY_VALUE = 14;
    public static final int MARGIN_VALUE = 15;//margin VIEW
    public static final int HOME_OFFER_ACTIVATE_VALUE = 18;
    public static final int HOME_CHECKIN_VALUE = 19;

    public static final int HOME_FIND_ITEM_WHITE_VALUE = 20;
    public static final int HOME_FIND_ITEM_VALUE = 21;
    public static final int HOME_FIND_ITEM_LIST_VALUE = 22;

    public static final int HOME_AUTO_SCROLL_MULTI_LINE_VALUE = 23;

    public static final int GAME_TOP_GAMES_VALUE = 100;

    /**
     * {@link #HOME_BG_SINGLE_LINE_4ICON}
     */
    public static final int HOME_BG_SINGLE_LINE_4ICON_VALUE = 24; //大图+底部4icon样式
    /**
     * {@link #HOME_ITEM_WHITE_BG}
     */
    public static final int HOME_ITEM_WHITE_BG_VALUE = 25;// //大图+底部1 item样式
    public static final int HOME_RANK_GROUP_2FIELD_VALUE = 26;
    public static final int HOME_TOPBANNER_NEW_VALUE = 27;
    public static final int HOME_HOT_SEARCH_VALUE = 28;

    public static final int HOME_RANK_H_V4_VALUE = 29;//横向多行 纵向4列

    /*
     * *************************************************
     * *************************************************
     * ************************************           **
     * ************************************           **
     * ************************************           **
     * ************************************           **
     * ************************************  WhatsApp **
     * *************************************************
     * *************************************************
     * ************************************(_________)**
     * *************************************************
     * *************************************************
     * */
    public static final int RANK_ITEM_BANNER_VALUE = 30;//大图+ICON+BUTTON

    /*
     * *************************************************
     * *                                               *
     * *                                               *
     * *                                               *
     * *                                               *
     * *                                               *
     * *                                               *
     * *                                               *
     * *************************************************
     * ******     ***     ***     ***     ***     ******
     * ******   1 ***   2 ***   3 ***   4 ***   5 ******
     * ******     ***     ***     ***     ***     ******
     * *************************************************
     * */
    public static final int RANK_BG_5ICON_VALUE = 31;//大图+底部5ICON

    public static final int HOME_FIND_VIDEO_ITEM_VALUE = 32;//Find 视频样式

    public static final int CATEGORY_FOUR_BANNER_VALUE= 33;//双行4banner

    public static final int SHORT_BANNER_VALUE = 35;//short banner style

    public static final int HOME_RACE_LAMP_VALUE = 36;//权益福利，跑马灯

    public static final int ONE_CLICK_HORIZONTAL_4_VALUE = 37;//一键下载横向4icon带标题样式

    public static final int ONE_CLICK_VERTICAL_TITLE_VALUE = 38;//一键下载纵向带标题样式

    public static final int HOME_HOT_RANK_VALUE = 39; //V10.0.1新增热词排行版样式

    public static final int HOME_FIND_BANNER_ITEM_VALUE = 40; //[V10.0.2] 图片大卡样式

    /**
     * {@link #GAME_IMMERSIVE_BANNER}
     */
    public static final int GAME_IMMERSIVE_BANNER_VALUE = 41;


    public static final int VIEWTYPE_SCREENSHOT = 10100;   //截图 // todo 这些id都得改，不然迟早出事
    public static final int VIEWTYPE_TAG = 10200;          //标签
    public static final int VIEWTYPE_INTRODUCE = 10300;    //应用信息介绍
    public static final int VIEWTYPE_COMMENT = 10400;      //评论
    public static final int VIEWTYPE_WELFARE = 10500;      //福利券
    public static final int VIEWTYPE_FEATURE = 10600;      //榜单推荐
    public static final int VIEWTYPE_FEEDBACK = 10700;     //反馈

    public static final int VIEWTYPE_UPDATE = 10800;   //更新信息，在更新状态下，能出现
    /**
     * 这里常量值递增，注意顺序，不要重复（之前新增VIEWTYPE_SHORT_BANNER时出现 = 80）
     */
    public static final int VIEWTYPE_SHORT_BANNER = 10900;     //详情页短banner

    public static final int VIEWTYPE_TRANSITION = 100000;     //transition
}

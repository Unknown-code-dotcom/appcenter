package com.afmobi.palmplay.clean;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.afmobi.apk.ApkInstallUtils;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.TRToolsTabFragment;
import com.afmobi.palmplay.main.PermissionsReqActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.model.v6_6.ScanResult;
import com.afmobi.palmplay.permissions.PermissonsHintDialog;
import com.afmobi.palmplay.service.CleanNativeMemoryService;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.TRPermissionUtil;
import com.afmobi.util.ViewExtKt;
import com.afmobi.util.statusbar.TRNavigationBarUtil;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.didi.drouter.annotation.Router;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import org.json.JSONObject;

import java.io.File;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import static com.afmobi.palmplay.home.TRToolsTabFragment.JUNK_FILES_RESULT;

import de.greenrobot.event.EventBus;

/**
 * 深度清理页面
 *
 * @author xiangfei.wei
 * @date 2017/11/29
 */
@Router(path = "/page/cleanNativeMemory")
public class CleanNativeMemoryActivity extends BaseEventFragmentActivity implements CleanNativeMemoryService.OnScanEventListener, View.OnClickListener {

    public static final String FROM_POSITION = "from_position";
    public static final String FROM_POSITION_NOTIFICATION = "notification";
    public static final String LAST_CLEAN_TIME = "last_clean_time";

    private CleanServiceConnection mCleanServiceConnection;
    private CleanNativeMemoryService cleanService;

    private Button btn_stop_scan;
    /**
     * 一键清理按钮显示的值，就是真正待清理的值，根据用户选中取消动态变化；
     */
    private long waitingCleanCacheSize;

    private FrameLayout container_top, container_bottom, container_cleaning;
    private LinearLayout ll_bottom;
    private CleanCacheScaningFragment scaningFragment;
    private CleanCacheProgressFragment progressFragment;
    private CleanCacheScanCompleteFragment scanCompleteFragment;
    private CleanCacheCleaningFragment cleaningFragment;
    private CleanPerfectStateFragment cleanPerfectStateFragment;
    private ScanResult mScanResult;
    /**
     * 是否执行了返回操作；TRUE，已执行
     */
    private boolean onBackPressedPerformed;

    private boolean scanHasStarted;
    private String mPackageNname = null;

    private boolean fromOnCreate, fromOnNewIntent;
    private String cleanedJunkFilesSize;
    private String mFromPage = "None";
    private String value;
    private boolean mIsUsePmClean;
    private PmScanAndCleanImpl pmScanAndClean;

    private static final String KEY_PAGE_STAGE = "key_page_stage";
    private static final int PAGE_STAGE_SCAN = 0;
    private static final int PAGE_STAGE_CLEANING = 1;
    private static final int PAGE_STAGE_PERFECT = 2;
    private int mCurrentPageStage = PAGE_STAGE_SCAN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        reMeasureStatusBar = true;
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            mCurrentPageStage = savedInstanceState.getInt(KEY_PAGE_STAGE, PAGE_STAGE_SCAN);
        }
        setContentView(R.layout.activity_clean_native_memory);
        applyImmersiveStatusBar();

        PageParamInfo pageParamInfo = PageConstants.getPageParamInfo(getIntent());
        if(pageParamInfo !=null) {
            mFromPage = pageParamInfo.getLastPage();
        }
        mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.Deep_Clean);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);
        getArgus();

        findViewById(R.id.layout_title_back).setOnClickListener(this);

        if(TRPermissionUtil.hasExternalStoragePermission()){
            onCreateHandle();
        }else {
            fromOnCreate = true;
            TRPermissionUtil.requestExternalStorage(CleanNativeMemoryActivity.this, TRPermissionUtil.WRITE_EXTERNAL_STORAGE);
        }
        pvEvent(getIntent());

        if (TRHomeUtil.checkJunkClean()>0) {
            TRHomeUtil.clearJunkClean();
            TRHomeUtil.updateLaunchIconRedTips(true, "Scan", "page");

            TRHomeUtil.refreshMeRed();//通知mainActivity刷新红点，mainActvity可能也不存在，会在进入的时候刷新
            EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
            eventMainThreadEntity.setAction(TRToolsTabFragment.ACTION_CLEAN_RED_RESULT);//通知tools页面刷新红点，tools页面可能不存在
            EventBus.getDefault().post(eventMainThreadEntity);
        }
    }

    private void applyImmersiveStatusBar() {
        TRStatusBarUtil.setStatusBarTransparent(this);
        LinearLayout titleBar = findViewById(R.id.title_bar);
        if (titleBar == null) {
            return;
        }
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) titleBar.getLayoutParams();
        int statusBarHeight = TRStatusBarUtil.getStatusBarHeight(this);
        if (layoutParams.topMargin != statusBarHeight) {
            layoutParams.topMargin = statusBarHeight;
            titleBar.setLayoutParams(layoutParams);
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyImmersiveStatusBar();
        ViewCompat.requestApplyInsets(getWindow().getDecorView());
    }

    private void pvEvent(Intent intent){
        if(intent == null){
            return;
        }
        String from = intent.getStringExtra(TRAnalyticsConstant.VALUE);
        if(TextUtils.isEmpty(from)) {
           from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", "");
        }

        value = TRStringUtil.generateString(TRAnalyticsConstant.JUNK_FILE, "", "", "");
        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(value)
                .setFrom(from);
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private void onCreateHandle() {
        stopService(new Intent(this, CleanNativeMemoryService.class));// 避免和通知栏第一次出现时候调起的扫描服务起冲突，引起本页面收不到扫描开始事件；
        initViews();
        cleanupLegacyFragments();
        //上次清理距今不足两分钟，显示  已达完美状态；
        if (System.currentTimeMillis() - SPManager.getLong(LAST_CLEAN_TIME, 0) < 120 * 1000) {
            showPerfectStatePage();
        } else {
            showScanContainers();
            if (!scanHasStarted) {
                initScan();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (!TRPermissionUtil.isGranted(grantResults, permissions)) {

            boolean isTip = ActivityCompat.shouldShowRequestPermissionRationale(this, permissions.length > 0 ? permissions[0] : "");
            if (isTip) {//表明用户没有彻底禁止弹出权限请求
                // 用户选择了禁止权限
                finish();
            }else {//表明用户已经彻底禁止弹出权限请求
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < permissions.length; i++) {
                    String perm = permissions[i];
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        sb.append(perm);
                    }
                }
                PermissonsHintDialog.getPermissionHintDlg(this, PermissionsReqActivity.SYS_SETTING_DETAILS_REQUEST_CODE, sb.toString());
            }
        } else {
            if(fromOnCreate){
                fromOnCreate = false;
                onCreateHandle();
            }else if(fromOnNewIntent){
                fromOnNewIntent = false;
                onNewIntentHandle();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(PermissionsReqActivity.SYS_SETTING_DETAILS_REQUEST_CODE == requestCode) {
            boolean hasPermissions = TRPermissionUtil.hasExternalStoragePermission();
            if(hasPermissions) {
                onCreateHandle();
            }else {
                finish();
            }
        }
    }

    private void onNewIntentHandle() {
        //如果用户一直在展示 手机已达完美状态的页面，并且距离上次清理已超过2分钟，那就再次开始扫描
        if (mCurrentPageStage == PAGE_STAGE_PERFECT || cleanPerfectStateFragment != null) {
            if (System.currentTimeMillis() - SPManager.getLong(LAST_CLEAN_TIME, 0) >= 120 * 1000) {
                removeFragmentByTag(CleanPerfectStateFragment.class.getSimpleName());
                cleanPerfectStateFragment = null;
                showScanContainers();
                if (!scanHasStarted) {
                    initScan();
                }
            } else {
                showPerfectStatePage();
            }
        } else {
            if(!scanHasStarted){
                stopService(new Intent(this, CleanNativeMemoryService.class));// 避免和通知栏第一次出现时候调起的扫描服务起冲突，引起本页面收不到扫描开始事件；
            }
            //上次清理距今不足两分钟，显示  已达完美状态；
            if (System.currentTimeMillis() - SPManager.getLong(LAST_CLEAN_TIME, 0) < 120 * 1000) {
                showPerfectStatePage();
            } else {
                showScanContainers();
                if (!scanHasStarted) {
                    initScan();
                }
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        boolean hasPermissions =  TRPermissionUtil.hasExternalStoragePermission();
        if(hasPermissions){
            onNewIntentHandle();
        }else {
            fromOnNewIntent = true;
            TRPermissionUtil.requestExternalStorage(CleanNativeMemoryActivity.this, TRPermissionUtil.WRITE_EXTERNAL_STORAGE);
        }
        pvEvent(intent);
    }

    private void getArgus() {
        try {
            Intent intent = getIntent();
            if(intent != null) {
                mPackageNname = intent.getStringExtra(Constant.KEY_PACKAGE_NAME);
            }
        }catch (Exception e){
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private boolean isCanUsePmScan() {
        boolean isSupport = CommonUtils.isSupportPMCleanup();

        return isSupport;
    }

    private void initScan() {
        mIsUsePmClean = isCanUsePmScan();

        showScanContainers();
        initFragment();

        if (mIsUsePmClean) {
            if (BuildConfig.DEBUG){
                LogUtils.d("CleanPage----ScanManager----PmScanAndCleanImpl.getInstance");
            }
            pmScanAndClean = PmScanAndCleanImpl.getInstance();
            pmScanAndClean.addOnScanEventListener(this, this);
            pmScanAndClean.setOnCleanUpEventListener(new OnCleanUpEventListener() {
                @Override
                public void onCleanUpEvent(boolean isSuc) {
                    LogUtils.d("on Junk Files pm cleanup event callback, isSuc:" + isSuc);
                    if (!isSuc) {
                        mIsUsePmClean = false;
                        scaningFragment.setIsUsePmScan(mIsUsePmClean);
                        scaningFragment.refreshUiWhenCleanTypeChanged();
                        mCleanServiceConnection = new CleanServiceConnection();
                        bindService(new Intent(CleanNativeMemoryActivity.this, CleanNativeMemoryService.class), mCleanServiceConnection, Context.BIND_AUTO_CREATE);
                    }
                }
            });
            pmScanAndClean.initPmService();
        }else {
            if (BuildConfig.DEBUG){
                LogUtils.d("CleanPage----ScanManager----CleanServiceConnection");
            }
            mCleanServiceConnection = new CleanServiceConnection();
            bindService(new Intent(this, CleanNativeMemoryService.class), mCleanServiceConnection, Context.BIND_AUTO_CREATE);
        }
        scanHasStarted = true;
    }

    public PageParamInfo getPageParamInfo() {
        return mPageParamInfo;
    }

    private void initViews() {
        btn_stop_scan = (Button) findViewById(R.id.btn_stop_scan);
        btn_stop_scan.setOnClickListener(this);
        container_top = (FrameLayout) findViewById(R.id.container_top);
        container_bottom = (FrameLayout) findViewById(R.id.container_bottom);
        ll_bottom = (LinearLayout) findViewById(R.id.ll_bottom);
        container_cleaning = (FrameLayout) findViewById(R.id.container_cleaning);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_PAGE_STAGE, mCurrentPageStage);
    }

    private void showScanContainers() {
        mCurrentPageStage = PAGE_STAGE_SCAN;
        if (container_top != null) {
            container_top.setVisibility(View.VISIBLE);
        }
        if (container_bottom != null) {
            container_bottom.setVisibility(View.VISIBLE);
        }
        if (ll_bottom != null) {
            ll_bottom.setVisibility(View.VISIBLE);
        }
        if (container_cleaning != null) {
            container_cleaning.setVisibility(View.GONE);
            container_cleaning.removeAllViews();
        }
    }

    private void showCleaningContainer() {
        mCurrentPageStage = PAGE_STAGE_CLEANING;
        if (container_cleaning != null) {
            container_cleaning.setVisibility(View.VISIBLE);
        }
        if (container_top != null) {
            container_top.setVisibility(View.GONE);
        }
        if (container_bottom != null) {
            container_bottom.setVisibility(View.GONE);
        }
        if (ll_bottom != null) {
            ll_bottom.setVisibility(View.GONE);
        }
    }

    private void showPerfectStatePage() {
        mCurrentPageStage = PAGE_STAGE_PERFECT;
        if (container_top != null) {
            container_top.setVisibility(View.GONE);
        }
        if (container_bottom != null) {
            container_bottom.setVisibility(View.GONE);
        }
        if (ll_bottom != null) {
            ll_bottom.setVisibility(View.GONE);
        }
        if (container_cleaning != null) {
            container_cleaning.setVisibility(View.VISIBLE);
        }
        removeFragmentByTag(CleanCacheCleaningFragment.class.getSimpleName());
        cleanPerfectStateFragment = CleanPerfectStateFragment.newInstance();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.container_cleaning, cleanPerfectStateFragment, CleanPerfectStateFragment.class.getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    private void cleanupLegacyFragments() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment topFragment = fragmentManager.findFragmentByTag(CleanCacheProgressFragment.class.getSimpleName());
        Fragment bottomFragment = fragmentManager.findFragmentByTag(CleanCacheScaningFragment.class.getSimpleName());
        Fragment completeFragment = fragmentManager.findFragmentByTag(CleanCacheScanCompleteFragment.class.getSimpleName());
        Fragment cleaning = fragmentManager.findFragmentByTag(CleanCacheCleaningFragment.class.getSimpleName());
        Fragment perfect = fragmentManager.findFragmentByTag(CleanPerfectStateFragment.class.getSimpleName());

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        boolean hasTransaction = false;
        if (mCurrentPageStage == PAGE_STAGE_PERFECT) {
            if (topFragment != null) {
                transaction.remove(topFragment);
                hasTransaction = true;
            }
            if (bottomFragment != null) {
                transaction.remove(bottomFragment);
                hasTransaction = true;
            }
            if (completeFragment != null) {
                transaction.remove(completeFragment);
                hasTransaction = true;
            }
            if (cleaning != null) {
                transaction.remove(cleaning);
                hasTransaction = true;
            }
        } else if (mCurrentPageStage == PAGE_STAGE_CLEANING) {
            if (topFragment != null) {
                transaction.remove(topFragment);
                hasTransaction = true;
            }
            if (bottomFragment != null) {
                transaction.remove(bottomFragment);
                hasTransaction = true;
            }
            if (completeFragment != null) {
                transaction.remove(completeFragment);
                hasTransaction = true;
            }
            if (perfect != null) {
                transaction.remove(perfect);
                hasTransaction = true;
            }
        } else {
            if (cleaning != null) {
                transaction.remove(cleaning);
                hasTransaction = true;
            }
            if (perfect != null) {
                transaction.remove(perfect);
                hasTransaction = true;
            }
        }
        if (hasTransaction) {
            transaction.commitNowAllowingStateLoss();
        }
    }

    private void removeFragmentByTag(String tag) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(tag);
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().remove(fragment).commitNowAllowingStateLoss();
        }
    }

    private void initFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        scaningFragment = CleanCacheScaningFragment.newInstance();
        progressFragment = CleanCacheProgressFragment.newInstance();
        scaningFragment.setIsUsePmScan(mIsUsePmClean);
        progressFragment.setIsUsePmScan(mIsUsePmClean);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.container_bottom, scaningFragment, CleanCacheScaningFragment.class.getSimpleName());
        transaction.replace(R.id.container_top, progressFragment, CleanCacheProgressFragment.class.getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public void addCleanCacheScanCompleteFragment() {
        if (onBackPressedPerformed)
            return;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
            if (isDestroyed() || isFinishing()) {
                return;
            }
        } else {
            if (isFinishing()) {
                return;
            }
        }

        scanCompleteFragment = CleanCacheScanCompleteFragment.newInstance();
        scanCompleteFragment.setIsUsePmScan(mIsUsePmClean);
        scanCompleteFragment.setWaitingCleanCacheSize(waitingCleanCacheSize);
        scanCompleteFragment.setScanResult(mScanResult);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container_bottom, scanCompleteFragment, CleanCacheScanCompleteFragment.class.getSimpleName());
        transaction.commitAllowingStateLoss();//避免java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        onServiceDisconnected();
        if (mCleanServiceConnection != null) {
            unbindService(mCleanServiceConnection);
        }
        mCleanServiceConnection = null;
        if (pmScanAndClean != null) {
            pmScanAndClean.onStop(this);
            boolean isExist = AtyManager.getAtyManager().isExistsActivity(MainActivity.class);
            if (!isExist) {
                pmScanAndClean.onUnbindService();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_stop_scan:
                if (mIsUsePmClean) {
                    if (pmScanAndClean != null) {
                        pmScanAndClean.stopScan();
                    }
                }else {
                    if (cleanService != null) {
                        cleanService.stopScan();
                    }
                }
                String value = TRStringUtil.generateString(TRAnalyticsConstant.JUNK_FILE, "", "", "0");
                String from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", "");
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(from)
                        .setTopicType("")
                        .setTopicId("")
                        .setItemType("")
                        .setItemId("")
                        .setButtonType("Stop")
                        .setItemValue("")
                        .setExtraValue("")
                        .setExtras(getExtras(-1));
                TRAnalysticsUtil.trackClick(builder);
                break;
            case R.id.layout_title_back:
                onBackPressed();
                break;

            default:
                break;
        }
    }

    public void onKeyCleanClick(long waitingCleanCacheSize, ScanResult scanResult) {
        this.waitingCleanCacheSize = waitingCleanCacheSize;

        if (mIsUsePmClean) {
            if (pmScanAndClean != null) {
                pmScanAndClean.startClean();
            }
        }else if (cleanService != null) {
            cleanService.startClean(scanResult);
        }

        String value = TRStringUtil.generateString(TRAnalyticsConstant.JUNK_FILE, "", "", "");
        String from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", "");
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(value)
                .setFrom(from)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON)
                .setItemValue("")
                .setExtraValue("")
                .setExtras(getExtras(waitingCleanCacheSize));
        TRAnalysticsUtil.trackClick(builder);
    }

    private String getExtras(long size) {
        String txt = null;
        try {
            JSONObject js = new JSONObject();
            if (size >= 0) {
                js.put("cleanSize", size);
            }
            js.put("cleanType", mIsUsePmClean ? "PM" : "PS");

            txt = js.toString();
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return txt;
    }

    @Override
    public void onBackPressed() {
        onBackPressedPerformed = true;
        Intent resultIntent = new Intent();
        resultIntent.putExtra(JUNK_FILES_RESULT, cleanedJunkFilesSize);
        setResult(Activity.RESULT_OK, resultIntent);
        String value = TRStringUtil.generateString(TRAnalyticsConstant.JUNK_FILE, "", "", "");
        String from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(from)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType("BackBt")
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
        super.onBackPressed();
    }

    private class CleanServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                cleanService = ((CleanNativeMemoryService.MyBinder) service).getService();
                cleanService.addOnScanEventListener(CleanNativeMemoryActivity.this);
                cleanService.stopScan();
                cleanService.startScan();
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            CleanNativeMemoryActivity.this.onServiceDisconnected();
        }
    }

    private void onServiceDisconnected(){
        if(cleanService != null){//避免把service的其它调用者的listener覆盖了
            cleanService.stopScan();
            cleanService.removeOnScanEventListener(CleanNativeMemoryActivity.this);
        }
        cleanService = null;
    }


    @Override
    public void onScanStart() {
        if (progressFragment != null)
            progressFragment.onScanStart();
    }

    @Override
    public void onScanProgressUpdate(ScanResult scanResult, CacheListItem item) {
        if (scaningFragment != null) {
            scaningFragment.scanProgressUpdate(scanResult, item);
        }
        if (progressFragment != null)
            progressFragment.scanProgressUpdate(scanResult, item);
    }

    @Override
    public void onScanComplete(long cacheSize, ScanResult scanResult) {
        ll_bottom.setVisibility(View.GONE);

        if (scanResult == null)
            scanResult = new ScanResult();

        if (!mIsUsePmClean) {
            long apkFilesSize = 0;
            if (null != scanResult.getApkList()) {
                for (CacheListItem apk : scanResult.getApkList()) {
                    if (apk.isSelected()) {
                        if (!TextUtils.isEmpty(apk.apkPath)) {
                            File file = new File(apk.apkPath);
                            if (file.exists()) {
                                apkFilesSize += apk.getSize();
                            }
                        }
                    }
                }
            }
            scanResult.apkFilesSize = apkFilesSize;
        }

        mScanResult = scanResult;
        if (mIsUsePmClean) {
            waitingCleanCacheSize = mScanResult.cacheSize + mScanResult.uninstallSize + mScanResult.apkFilesSize
                    + mScanResult.systemCacheSize;
        }else {
            waitingCleanCacheSize = mScanResult.cacheSize + mScanResult.uninstallSize + mScanResult.apkFilesSize;
        }
        // 存储扫描的大小
        SPManager.putLong(TRToolsTabFragment.KEY_MEMORY_CLEAN_CHECK_SIZE, waitingCleanCacheSize);
        if (BuildConfig.DEBUG){
            LogUtils.d("CleanPage----ScanManager----onScanComplete: " + mIsUsePmClean +
                    "----:" + waitingCleanCacheSize
                    + "----: "+ mScanResult.toString());
        }

        LogUtils.i("On Scan cache total:" + waitingCleanCacheSize + ",  isPmClean:" + mIsUsePmClean);
        if (progressFragment != null)
            progressFragment.onScanComplete(waitingCleanCacheSize);
        if (scaningFragment != null)
            scaningFragment.onScanComplete(scanResult);
    }


    @Override
    public void onCleanStart() {
        cleaningFragment = CleanCacheCleaningFragment.newInstance();
        cleaningFragment.setCacheSize(waitingCleanCacheSize);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container_cleaning, cleaningFragment, CleanCacheCleaningFragment.class.getSimpleName());
        transaction.commitAllowingStateLoss();

        showCleaningContainer();

        String value = TRStringUtil.generateString(TRAnalyticsConstant.JUNK_FILE, "", "", "0");
        String from = TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(from)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType("CleanJunk")
                .setItemValue("")
                .setExtraValue("")
                .setExtras(getExtras(waitingCleanCacheSize));
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public void onCleanComplete(long cacheSize) {
        /*if (cleaningFragment != null) {
            cleaningFragment.onCleanComplete(cacheSize);
        }*/
        SPManager.putLong(TRToolsTabFragment.KEY_MEMORY_CLEAN_CHECK_SIZE, 0);//todo 内存已清理
        cleanedJunkFilesSize = ProcessAndMemoryUtil.formatSizeKbMbGb(cacheSize, 0);
        ProcessAndMemoryUtil.saveDeepCleanResult(cleanedJunkFilesSize);
        showPerfectStatePage();
        ApkInstallUtils.onTryInstallApkByPackageName(mPackageNname);
    }

    @Override
    public String getValue() {
        return value;
    }
}

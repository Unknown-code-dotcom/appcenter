package com.afmobi.palmplay.appmanage.v2.util

import com.afmobi.palmplay.appmanage.ManageDownloadActivity
import com.afmobi.palmplay.appmanage.v2.ManageDownloadV2Activity
import com.afmobi.util.Constant
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils

/**
 * 下载管理页面启动器
 * 根据配置自动选择 V1 或 V2 版本
 */
object DownloadActivityLauncher {

    const val USE_NEW_VERSION = 1
    const val USE_OLD_VERSION = 0

    private val useNew by lazy {
        MMKVUtils.getMMKV().getInt(Constant.KV_MD_REFACTOR_SWITCH, USE_NEW_VERSION) == USE_NEW_VERSION
    }

    fun useNewDownloadActivity(): Boolean {
        LogUtils.d("DownloadRepo", "useNewDownloadActivity=$useNew")
        return useNew
    }

    @JvmStatic
    fun getManageDownloadClass(): Class<*> {
        return if (useNewDownloadActivity()) {
            ManageDownloadV2Activity::class.java
        } else {
            ManageDownloadActivity::class.java
        }
    }

    @JvmStatic
    fun getManageDownloadPath(): String {
        return if (useNewDownloadActivity()) {
            "/page/manageDownloadV2"
        } else {
            "/page/manageDownload"
        }
    }

}
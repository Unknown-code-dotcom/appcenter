package com.afmobi.palmplay.az.attribution;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * AZ 场景拉活归因常量
 */
public final class AzAttrConstants {

    private AzAttrConstants() {}

    public static final Set<String> LAUNCHER_WHITELIST = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "com.transsion.launcher3"
    )));

    // 默认值（服务端未下发时兜底）
    public static final long DEFAULT_POLL_INTERVAL_MS = TimeUnit.HOURS.toMillis(4);
    public static final long DEFAULT_CLICK_CD_MS = TimeUnit.HOURS.toMillis(1);

    // MMKV
    public static final String MMKV_ID = "az_attr";
    /** 归因配置 JSON（AzAttrConfigBean 整体覆盖式写入） */
    public static final String K_CONFIG = "az_config";
    /** 包维度上报计数 JSON: Map<String, Integer> */
    public static final String K_REPORT_COUNT_MAP = "az_report_count";
    /** 包维度上次点击时间戳 JSON: Map<String, Long>（用于 CD 判定） */
    public static final String K_LAST_CLICK_MAP = "az_last_click";

    // AttributionUploadManager 入队 name
    public static final String UPLOAD_NAME = "az_attr";

    // 归因链接占位符（与服务端约定，如实际值不同请一并修改）
    public static final String PH_CLICKID = "__CLICK_ID__";
}

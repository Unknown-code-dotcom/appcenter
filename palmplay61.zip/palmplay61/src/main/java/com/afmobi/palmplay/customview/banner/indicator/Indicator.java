package com.afmobi.palmplay.customview.banner.indicator;

import android.view.View;

import com.afmobi.palmplay.customview.banner.config.IndicatorConfig;
import com.afmobi.palmplay.customview.banner.listener.OnPageChangeListener;

import androidx.annotation.NonNull;

public interface Indicator extends OnPageChangeListener {
    @NonNull
    View getIndicatorView();

    IndicatorConfig getIndicatorConfig();

    void onPageChanged(int count, int currentPosition);

}

package com.afmobi.palmplay.appmanage.holder;

import android.app.Activity;
import android.graphics.Paint;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afmobi.palmplay.appmanage.adapter.ManagerUpdateAdapter;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.FileUtils;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsnet.store.R;

import java.io.File;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by sk on 17-5-11.
 */

public class UpdateRecyclerViewHolder extends RecyclerView.ViewHolder {

    private Activity mActivity;

    public View rootView;
    public ImageView iv_image;
    public TextView tv_name;
    public TextView tv_size, tv_diff_size;
    public XFermodeDownloadView btn_operation;
    public ImageButton ib_more;
    public LinearLayout layout_ignore;

    public LinearLayout ll_app_info;
    public TextView tv_uninstall;
    public TextView tv_ignore;
    public TextView tv_version;
    public LinearLayout layout_downloading;
    public TextView tv_downloading_speed;
    public TextView tv_downloading_size_and_total_size;


    public UpdateRecyclerViewHolder(View convertView) {
        super(convertView);

        this.rootView = convertView.findViewById(R.id.update_item_root);
        this.ll_app_info = convertView.findViewById(R.id.ll_app_info);
        this.iv_image = convertView.findViewById(R.id.iv_image);
        this.tv_name = (TextView) convertView.findViewById(R.id.tv_name);

        this.tv_size = (TextView) convertView.findViewById(R.id.tv_size);
        this.tv_diff_size = (TextView) convertView.findViewById(R.id.tv_diff_size);

        this.tv_version = (TextView) convertView.findViewById(R.id.tv_version);
        this.btn_operation = (XFermodeDownloadView) convertView.findViewById(R.id.btn_operation);
        this.ib_more = (ImageButton) convertView.findViewById(R.id.ib_more);
        this.layout_ignore = (LinearLayout) convertView.findViewById(R.id.layout_ignore);
        this.layout_ignore.setVisibility(View.GONE);

        this.layout_downloading = (LinearLayout) convertView.findViewById(R.id.layout_downloading);
        this.tv_downloading_speed = (TextView) convertView.findViewById(R.id.tv_downloading_speed);
        this.tv_downloading_size_and_total_size = (TextView) convertView.findViewById(R.id.tv_downloading_size_and_total_size);

        this.tv_uninstall = (TextView) convertView.findViewById(R.id.tv_uninstall);
        this.tv_ignore = (TextView) convertView.findViewById(R.id.tv_ignore);
    }


    public void bind(ClientVersion.UpdateItem mUpdateItem, int position, ManagerUpdateAdapter.AdapterOnClickListener itemAndViewOnClinck) {
        DownloadStatusManager.getInstance().registerInfoInstance(mUpdateItem);

        layout_ignore.setVisibility(mUpdateItem == null ? View.GONE : mUpdateItem.isExpandInAdapter ? View.VISIBLE : View.GONE);

        ib_more.setOnClickListener(itemAndViewOnClinck);
        tv_ignore.setOnClickListener(itemAndViewOnClinck);
        btn_operation.setOnClickListener(itemAndViewOnClinck);
        rootView.setOnClickListener(itemAndViewOnClinck);

        tv_name.setText(mUpdateItem.name);
        String versionName = "";
        if (TextUtils.isEmpty(mUpdateItem.versionName)) {
            versionName = "";
        }else if (mUpdateItem.versionName.startsWith("V")){
            versionName = mUpdateItem.versionName;
        }else {
            versionName = CommonUtils.replace(mActivity.getString(R.string.versionname_prefix), CommonUtils.TARGET_NAME, mUpdateItem.versionName);
        }
        tv_version.setText(versionName);
        tv_size.setText(FileUtils.getSizeName(mUpdateItem.size));
        if (!TextUtils.isEmpty(mUpdateItem.diffSize)) {
            tv_diff_size.setVisibility(View.VISIBLE);
            tv_size.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG);
            try {
                tv_diff_size.setText(FileUtils.getSizeName(Long.valueOf(mUpdateItem.diffSize)));
            } catch (Exception e) {
            }
        } else {
            tv_size.getPaint().setFlags(0);
            tv_diff_size.setVisibility(View.GONE);
        }
        int defaultIcon = R.drawable.layer_list_app_default_01_bg;
        File iconFile = TextUtils.isEmpty(mUpdateItem.iconLocalUrl) ? null : new File(mUpdateItem.iconLocalUrl);
        if (iconFile != null && iconFile.exists()) {
            GlideUtils.setImageFileUriWithRadius(iv_image, Uri.fromFile(iconFile));
        } else {
            GlideUtils.setImageUrl(iv_image, mUpdateItem.iconUrl, defaultIcon, defaultIcon);
        }

        CommonUtils.checkStatusItemDisplay(mActivity, mUpdateItem, layout_downloading, btn_operation, null, tv_downloading_size_and_total_size, tv_downloading_speed, CommonUtils.DOWNLOAD_BUTTON_HEIGHT_28);
        checkIbMoreImageResource(layout_ignore, ib_more);
        systemAppHideUninstall(mUpdateItem.packageName, itemAndViewOnClinck);
        if (layout_downloading.getVisibility() == View.VISIBLE) {
            ll_app_info.setVisibility(View.GONE);
        } else {
            ll_app_info.setVisibility(View.VISIBLE);
        }
    }

    public void updateViewHolderProgressBar(FileDownloadInfo downloadInfo, int speed) {

        CommonUtils.updateViewHolderProgressBar(mActivity, downloadInfo, speed, layout_downloading, btn_operation, tv_downloading_size_and_total_size, tv_downloading_speed);

//        float progress = downloadInfo.downloadedSize * 100 / downloadInfo.sourceSize;
//        progressbar_downloading.setProgress((int) progress);
//
//        String sizeStr = FileUtils.getSizeName(downloadInfo.downloadedSize) + "/" + FileUtils.getSizeName(downloadInfo.sourceSize);
//        SpannableStringBuilder mSpannable = new SpannableStringBuilder(sizeStr);
//        int end = sizeStr.indexOf("/");
//        if (end != -1) {
//            int color = mActivity.getResources().getColor(R.color.color_0a9beb);
//            mSpannable.setSpan(new ForegroundColorSpan(color), 0, end, Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
//        }
//        tv_downloading_size_and_total_size.setText(mSpannable);
//
//        tv_downloading_speed.setText(FileUtils.getFileSizeMapUnit(speed, false) + "/S");
//
//        if (View.GONE == layout_downloading.getVisibility()) {
//            layout_downloading.setVisibility(View.VISIBLE);
//            tv_ignore.setVisibility(View.GONE);
//        }
    }

    public void systemAppHideUninstall(String packageName, View.OnClickListener onClinck) {
        tv_uninstall.setOnClickListener(onClinck);
        tv_uninstall.setTextColor(mActivity.getResources().getColor(R.color.update_ignore_txt_color));
        if(!TextUtils.isEmpty(packageName)){
            InstalledAppInfo info = InstalledAppManager.getInstance().addPackage(mActivity, packageName);

            if (info != null && info.isSystemApp) {
                tv_uninstall.setOnClickListener(new EmptyOnClickListener());
                tv_uninstall.setTextColor(mActivity.getResources().getColor(R.color.color_unable_gray));
            }
        }
    }

    public void checkIbMoreImageResource(ViewGroup layout_ignore, ImageButton ib_more) {
        if (layout_ignore.getVisibility() == View.VISIBLE) {
            ib_more.setImageResource(R.drawable.btn_download_more_down);
            ib_more.setRotation(180);
        } else {
            ib_more.setImageResource(R.drawable.btn_download_more_down);
            ib_more.setRotation(0);
        }
    }

    public UpdateRecyclerViewHolder setActivity(Activity curActivity) {
        mActivity = curActivity;
        return this;
    }

    private class EmptyOnClickListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {

        }
    }
}

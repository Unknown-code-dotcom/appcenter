package com.afmobi.palmplay.appmanage.dialog;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;
import androidx.appcompat.app.AlertDialog;
import android.view.View;

import com.afmobi.util.PadUtils;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.model.keeptojosn.ClientOperationRecordNode;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

/**
 * 打开 Accessibility设置提示
 * Created by xiangfei.wei on 2017/8/1.
 */

public class OpenAccessibilityTipsDialog extends AlertDialog implements View.OnClickListener {
    public OpenAccessibilityTipsDialog(@NonNull Context context) {
        super(context);
    }

    public OpenAccessibilityTipsDialog(@NonNull Context context, @StyleRes int themeResId) {
        super(context, themeResId);
    }

    public OpenAccessibilityTipsDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_open_accessibility_tips);
        /*WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = (int) (DisplayUtil.getScreenWidthPx(getContext()) * 0.9);
        params.height = (int) (DisplayUtil.getScreenHeightPx(getContext()) * 0.54);
        getWindow().setAttributes(params);*/
        findViewById(R.id.iv_close).setOnClickListener(this);
        findViewById(R.id.open).setOnClickListener(this);

        ClientOperationRecordNode node = new ClientOperationRecordNode(ClientOperationRecordNode.TYPE_AUTO_SETUP,
                new ClientOperationRecordNode.OperationShareArgs(PageConstants.Auto_Install_Tips, null, null, null, null, null, null));
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(node);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                dismiss();
                break;

            case R.id.open:
                dismiss();
                openAccessibilityGuide(getContext());
                break;
        }
    }

    public static void openAccessibilityGuide(final Context context) {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.setFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            context.startActivity(intent);
            /*intent.setAction(null);
            intent.setClass(context, AccessibilityGuideActivity.class);
            context.startActivity(intent);*/


            ClientOperationRecordNode node = new ClientOperationRecordNode(ClientOperationRecordNode.TYPE_AUTO_SETUP,
                    new ClientOperationRecordNode.OperationShareArgs(PageConstants.Auto_Install_Bt, null, null, null, null, null, null));
            ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(node);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            LogUtils.e("MainTabFragment", e.toString());
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadDialog(this);
    }

}

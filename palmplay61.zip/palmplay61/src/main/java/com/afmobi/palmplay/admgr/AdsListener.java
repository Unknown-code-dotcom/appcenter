package com.afmobi.palmplay.admgr;


import android.view.View;

public interface AdsListener {

    /**
     * AD LOAD FROM [own ad] or [ssp ad]
     * */
    int AD_FROM_NONE = 0;
    int AD_FROM_OWN = 1;  //owner ad
    int AD_FROM_SSP = 2;  //ssp ad


    /**
     * AD LOAD ERROR CODE for method {@onAdLoadFailed} on params @errorCode
     * */
    int AD_ERROR_INNER = 1101;
    int AD_ERROR_NETWORK = 1102;
    int AD_ERROR_PARS = 1103;
    int AD_ERROR_UNKNOWN = 1104;


    void onAdLoaded(int adFrom, View adView);

    void onAdLoadFailed(int adFrom, int errorCode);

    void onClicked(int adFrom, Object object);

    void onAdClose(int adFrom);  //某些类型广告可以点击关闭

    void onAdSkip(int adFrom,Object object);   //某些带倒计时的类型广告可以点击关闭

    void onTimeReach(int adFrom); //带倒计时广告超时回调

    void onAdShow(int adFrom, Object object);
}

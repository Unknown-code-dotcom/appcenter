package com.afmobi.palmplay.alsoinstall;

import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.home.model.base.FeatureBaseData;
import com.afmobi.palmplay.main.adapter.ItemViewStateListener;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.transsnet.store.BuildConfig;

import org.json.JSONObject;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by sk on 20221109.
 */

public abstract class AppInstallRecommendBaseViewHolder extends RecyclerView.ViewHolder{
    protected String mFromPage;
    protected PageParamInfo mPageParamInfo;
    protected OnViewLocationInScreen mOnViewLocationInScreen;
    protected ItemViewStateListener mItemViewStateListener;
    protected String mScreenPageName;
    protected String mFeatureName;
    protected String mStyle;
    protected String mCategoryTag;
    public String mFrom;//新型打点的from值
    public boolean mIsFromCache = false;
    protected OfferInfo mOfferInfo;

    protected boolean gdprHasAllowed;
    protected String itemID;
    protected String topicPlace;
    protected String placementId;
    protected boolean isNetData;
    protected String featureId;
    protected String extraValue = "";

    public AppInstallRecommendBaseViewHolder(View itemView) {
        super(itemView);
    }

    protected void unbind() {
    }

    public void trimViewMemory() {
        if (isRecyclable()) {
            unbind();
        }
    }

    public AppInstallRecommendBaseViewHolder setGdprHasAllowed(boolean gdprHasAllowed) {
        this.gdprHasAllowed = gdprHasAllowed;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setItemViewStateListener(ItemViewStateListener l){
        this.mItemViewStateListener = l;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setFromPage(String fromPage){
        this.mFromPage = fromPage;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setExtraValue(String extraValue) {
        this.extraValue = extraValue;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setOfferInfo(OfferInfo offerInfo) {
        this.mOfferInfo = offerInfo;
        return this;
    }

    public String getScreenPageName() {
        return mScreenPageName;
    }

    public AppInstallRecommendBaseViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }

    public String getFeatureName() {
        return mFeatureName;
    }

    public AppInstallRecommendBaseViewHolder setPageParamInfo(PageParamInfo pageParamInfo){
        if(null == pageParamInfo || null == pageParamInfo.getCurPage() ){
            pageParamInfo = new PageParamInfo();
        }
        this.mPageParamInfo = pageParamInfo;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setOnViewLocationInScreen(OnViewLocationInScreen l) {
        mOnViewLocationInScreen = l;
        return this;
    }

    public void bind(FeatureBaseData featureItemData, final int position) {
        itemView.setTag(featureItemData);
    }

    public String getStyleName() {
        return mStyle;
    }

    public boolean isFromCache() {
        return mIsFromCache;
    }

    public AppInstallRecommendBaseViewHolder setFromCache(boolean isCache) {
        mIsFromCache = isCache;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setStyleName(String style) {
        mStyle = style;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setTopicPlace(String topicPlace) {
        this.topicPlace = topicPlace;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setPlacementId(String placementId) {
        this.placementId = placementId;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setFeatureId(String featureId) {
        this.featureId = featureId;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setNetData(boolean netData) {
        this.isNetData = netData;
        return this;
    }

    public AppInstallRecommendBaseViewHolder setFeaturedId(String featureId) {
        this.featureId = featureId;
        return this;
    }

    public String getExtras() {
        String txt = null;

        try {
            JSONObject js = new JSONObject();
            int val = isNetData ? 1 : 0;
            js.put("isNetData", val);
            txt = js.toString();
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return txt;
    }

    /**
     * 当数据发生错误时,隐藏当前条目
     */
    public void dismissItemView() {
        if (itemView == null||itemView.getVisibility()==View.GONE) {
            return;
        }
        itemView.setVisibility(View.GONE);
        itemView.getLayoutParams().height = 0;
        unbind();
    }

    /**
     * 显示当前条目
     */
    public void showItemView() {
        if (itemView == null || itemView.getVisibility() == View.VISIBLE) {
            return;
        }
        itemView.setVisibility(View.VISIBLE);
        ViewGroup.LayoutParams layoutParams = itemView.getLayoutParams();
        layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    public void updateItemProgress(XFermodeDownloadView downloadView, FileDownloadInfo downloadInfo, OfferInfo offerInfo) {
        CommonUtils.updateViewHolderProgressBar(downloadInfo, downloadView, offerInfo, null);
    }
}

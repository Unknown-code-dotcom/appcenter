package com.afmobi.palmplay.cache;

import android.content.Context;
import android.text.TextUtils;

import com.afmobi.palmplay.configs.v6_3.AssetsConfig;
import com.afmobi.palmplay.model.keeptojosn.CountryBean;
import com.afmobi.util.FileUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.log.LogUtils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class CountryMccCache implements LocalCache {

    private static volatile CountryMccCache mCounryCache = null;
    private List<CountryBean> mCountryList = new ArrayList<>();


    public static CountryMccCache getInstance() {
        if(mCounryCache == null) {
            synchronized (CountryMccCache.class) {
                if(mCounryCache == null) {
                    mCounryCache = new CountryMccCache();
                }
            }
        }
        return mCounryCache;
    }

    public List<CountryBean> loadCountryData(Context context){

        if(mCountryList == null || mCountryList.size() <= 0) {
            List<CountryBean> list = null;
            try{
                String str = FileUtils.getStringFromAssets(AssetsConfig.FILE_NAME_COUNTRY_MCC, context);
                if(!TextUtils.isEmpty(str)) {
                    Type type = new TypeToken<List<CountryBean>>() {}.getType();
                    list = new Gson().fromJson(str, type);
                }
            }catch (Exception e){
                LogUtils.e(e);
            }

            if(list != null && list.size() > 0) {
                if (mCountryList!=null) {
                    mCountryList.clear();
                    mCountryList.addAll(list);
                }
            }
        }

        return mCountryList;
    }

    @Override
    public void loadFromCache(Object... objects) {

    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {

    }

    @Override
    public String getFileName(Object... objects) {
        return null;
    }
}

package com.afmobi.palmplay.appdetail;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.appdetail.model.AppDetailData;
import com.afmobi.palmplay.firebase.FirebaseAnalyticsTool;
import com.afmobi.palmplay.manager.ToolBarConfigManager;
import com.afmobi.palmplay.model.AppInfo;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.util.TrackingUtil;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.TRAnalyticsManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;

import java.util.List;

public class TrackUtils {

    public static void trackCommon(String eventName) {
        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent(eventName, null);
        TRAnalyticsManager.getmInstance().postClickEvent(eventName, FirebaseAnalyticsTool.getCommonParamBundle(), true);
    }

    public static void onKeyDown(String mValue, String mFrom, AppInfo mAppInfo){
        if (mAppInfo != null) {
            String requestFinished = "0";
            if (!AppDetailData.getInstance().isFeatureRequestFinished()) {
                requestFinished = "1";
            }

            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(mValue)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId(mAppInfo == null ? "" : mAppInfo.topicID)
                    .setExtras(requestFinished)
                    .setItemType(mAppInfo == null ? "" : mAppInfo.detailType)
                    .setItemId(mAppInfo == null ? "" : mAppInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                    .setItemValue(mAppInfo == null ? "" : mAppInfo.packageName)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);
        }
    }

    public static void clickAutoupdate(boolean isChecked, String mFrom, AppInfo mAppInfo){
        if (mAppInfo != null) {
            String extraVal = isChecked ? "On" : "Off";
            String val = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.TIP_AUTO_UPDATE, "", "");
            ComponentClickBuilder<?> buttonBuilder = new ComponentClickBuilder<>();
            buttonBuilder.setValue(val)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId(mAppInfo.topicID)
                    .setItemType(mAppInfo.detailType)
                    .setItemId(mAppInfo.itemID)
                    .setItemValue(mAppInfo.packageName)
                    .setButtonType(TRAnalyticsConstant.BUTTON)
                    .setExtraValue(extraVal)
                    .setTaskId(mAppInfo.taskId)
                    .setExpId(mAppInfo.expId)
                    .setVarId(mAppInfo.getVarId());
            TRAnalysticsUtil.trackClick(buttonBuilder);
        }
    }

    public static void exposureAutoupdate(String mFrom, AppInfo mAppInfo){
        String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.TIP_AUTO_UPDATE, "", "");
        ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId(mAppInfo.topicID)
                .setItemType(mAppInfo.detailType)
                .setItemId(mAppInfo.itemID)
                .setItemValue(mAppInfo.packageName)
                .setTaskId(mAppInfo.taskId)
                .setExpId(mAppInfo.expId)
                .setVarId(mAppInfo.getVarId())
                .setIsVa(mAppInfo.isVa);
        TRAnalysticsUtil.trackExposure(builder);
        if (BuildConfig.DEBUG) {
            LogUtils.d(LogUtils.TAG_DATA_SHOW, "show bundle: 详情页1");
        }
    }

    public static void clickLayoutStar(String mFrom, AppInfo mAppInfo){
        String val = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.DETAIL_DETAILS, "", TRAnalyticsConstant.DETAIL_SCORE);
        ComponentClickBuilder builderStar = new ComponentClickBuilder();
        builderStar.setValue(val)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId(mAppInfo == null ? "" : mAppInfo.topicID)
                .setItemType("")
                .setItemType(mAppInfo == null ? "" : mAppInfo.detailType)
                .setItemId(mAppInfo == null ? "" : mAppInfo.itemID)
                .setButtonType(TRAnalyticsConstant.BUTTON)
                .setItemValue(mAppInfo == null ? "" : mAppInfo.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builderStar);
    }

    /**
     * 通知栏广告位点击跳转逻辑处理
     */
    public static void initNoticeEwClick(AppInfo mAppInfo) {
            String mToolbarPositionId = ToolBarConfigManager.getInstance().mToolbarPositionId;
            if (TextUtils.equals(mToolbarPositionId, mAppInfo.adPositionId)) {
                List<TaNativeInfo> detailAdList = ToolBarConfigManager.getInstance().detailAdList;
                if (detailAdList != null) {
                    TrackingUtil.trackShows(detailAdList, SceneCode.NOTICE_BOARD_X);
                }
            }
            ToolBarConfigManager.getInstance().addEwAdClickTimes(mAppInfo.packageName);
            String detailValue = TRStringUtil.generateString(TRAnalyticsConstant.PAGE_TOOLBAR, "", "", "4");
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(detailValue)
                    .setFrom("x_x_x_x")
                    .setTopicType("")
                    .setTopicId(mAppInfo.topicID)
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(mAppInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.ICON)
                    .setItemValue(mAppInfo.packageName)
                    .setSubSiteId("")
                    .setSiteId("")
                    .setPid("")
                    .setReferrer("")
                    .setAdPositionId(mAppInfo.adPositionId)
                    .setTrack_type(String.valueOf(mAppInfo.track_type))
                    .setReportSource(HisavanaSdkManager.REPORT_SOURCE_EW);
            TRAnalysticsUtil.trackClick(builder);
        }
}

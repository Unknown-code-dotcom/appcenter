package com.afmobi.palmplay.appmanage.holder;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.FileManageDownloadAdapterItem;
import com.afmobi.palmplay.appmanage.adapter.FileManageDownloadAdapter;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideApp;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutManagePreorderedListItemBinding;

import java.util.Iterator;
import java.util.List;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by sk on 21-9-13.
 */

public class ChildPreOrderedRecyclerViewHolder extends RecyclerView.ViewHolder {
    private Activity mActivity;
    private FileManageDownloadAdapter adapter;
    private List<FileManageDownloadAdapterItem> mDatas;
    private PageParamInfo mPageParamInfo;
    private LayoutManagePreorderedListItemBinding binding;
    private FileDownloadInfo fileDownloadInfo;
    protected String mScreenPageName;
    protected String mFeatureName;
    public String mFrom;//新型打点的from值
    private FileManageDownloadAdapterItem mDownloadingInfo;

    public ChildPreOrderedRecyclerViewHolder(View itemView) {
        super(itemView);
        binding = DataBindingUtil.getBinding(itemView);
        if (binding != null) {
            binding.setHolder(this);
        }
    }

    public void bind(FileManageDownloadAdapterItem preorderedDownloadingInfo, final int position) {
        itemView.setTag(preorderedDownloadingInfo);
        if (binding == null) {
            return;
        }

        mDownloadingInfo = preorderedDownloadingInfo;
        fileDownloadInfo = preorderedDownloadingInfo.fileDownloadInfo;

        binding.tvName.setText(fileDownloadInfo.name);

        int iCount = 0;
        try {
            iCount = TextUtils.isEmpty(fileDownloadInfo.downloadCount) ? 0 : Integer.parseInt(fileDownloadInfo.downloadCount);
        }catch(NumberFormatException e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        binding.tvDownloadCount.setText(CommonUtils.getDownloadCountStr(iCount));
        binding.tvSize.setText(CommonUtils.replace(PalmplayApplication.getAppInstance().getString(R.string.text_download_size), CommonUtils.TARGET_NAME
                , FileUtils.getSizeName(fileDownloadInfo.sourceSize)));
        binding.tvScore.setText(String.valueOf(preorderedDownloadingInfo.star));
        binding.tvDescription.setText(preorderedDownloadingInfo.simpleDescription);

        int defaultIcon = R.drawable.layer_list_app_default_01_bg_l;
        if (!TextUtils.isEmpty(fileDownloadInfo.iconUrl)) {
            GlideUtils.setImageUrl(binding.ivIcon, fileDownloadInfo.iconUrl, defaultIcon, defaultIcon);
        } else {
            GlideApp.with(PalmplayApplication.getAppInstance()).load(PalmplayApplication.getAppInstance().getDrawable(defaultIcon))
                    .apply(GlideUtils.newCommonRequestOptions())
                    .into(binding.ivIcon);
        }


        if(!fileDownloadInfo.hasTrack){
            fileDownloadInfo.hasTrack = true;
            long taskid = fileDownloadInfo.extraInfo != null ? fileDownloadInfo.extraInfo.taskId : 0;
            String expId = fileDownloadInfo.extraInfo != null ? fileDownloadInfo.extraInfo.expId : null;
            String value = TRStringUtil.generateString(mScreenPageName,mFeatureName,"",String.valueOf(mDownloadingInfo.placementId));
            ComponentExposureBuilder builder = new ComponentExposureBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(fileDownloadInfo.itemID)
                    .setItemValue(fileDownloadInfo.packageName)
                    .setExpId(expId)
                    .setTaskId(taskid);
            TRAnalysticsUtil.trackExposure(builder);
        }
    }

    public ChildPreOrderedRecyclerViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public ChildPreOrderedRecyclerViewHolder setScreenPageName(String screenPageName) {
        this.mScreenPageName = screenPageName;
        return this;
    }

    public ChildPreOrderedRecyclerViewHolder setFeatureName(String featureName) {
        this.mFeatureName = featureName;
        return this;
    }

    public ChildPreOrderedRecyclerViewHolder setActivity(Activity curActivity) {
        mActivity = curActivity;
        return this;
    }

    public ChildPreOrderedRecyclerViewHolder setAdapter(FileManageDownloadAdapter adapter) {
        this.adapter = adapter;
        return this;
    }

    public ChildPreOrderedRecyclerViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        this.mPageParamInfo = pageParamInfo;
        return this;
    }

    public ChildPreOrderedRecyclerViewHolder setDatas(List<FileManageDownloadAdapterItem> datas) {
        mDatas = datas;
        return this;
    }

    public void onDeleteBtnClick() {
        if (binding == null || fileDownloadInfo == null) {
            return;
        }
        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
            deleteTask(fileDownloadInfo);
        } else {
            final DialogBuilder mDialogBuilder = new DialogBuilder();
            new CustomDialog(mActivity).showCheckBoxFunctionDialog(
                    mDialogBuilder
                            .hideTitle()
                            .setMessage(mActivity.getString(R.string.delete_task))
                            .setCheckBoxChecked(false)
                            .setCheckBoxText(mActivity.getString(R.string.no_again))
                            .setNegativeBtnText(mActivity.getString(R.string.text_cancel))
                            .setPositiveBtnText(mActivity.getString(R.string.text_ok))
                            .setPositiveBtnOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View view) {
                                    SPManager.putBoolean(Constant.preferences_delete_tips_downloading_record, mDialogBuilder.isCheckBoxChecked());
                                    deleteTask(fileDownloadInfo);
                                }
                            }));
        }
    }

    public void onOperationBtnClick() {
        //for test
//        EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
//        eventMainThreadEntity.setAction(NetworkActions.ACTION_PREORDER_STATUS);
//        eventMainThreadEntity.isSuccess=true;
//        List<String> list = new ArrayList<>();
//        list.add(fileDownloadInfo.packageName);
//        DownloadManager.getInstance().movePreOrderedToDownloading(list);
//        eventMainThreadEntity.putList(Constant.KEY_PACKAGES, list);
//        EventBus.getDefault().post(eventMainThreadEntity);
    }

    public void onItemLayoutClick(View view) {
        if (fileDownloadInfo == null) {
            return;
        }
        RankDataListItem item = new RankDataListItem();
        item.name = fileDownloadInfo.name;
        item.versionName = fileDownloadInfo.versionName;
        item.downloadCount = CommonUtils.sting2IntNoException(fileDownloadInfo.downloadCount);
        item.downloadID = fileDownloadInfo.downloadID;
        item.downloadUrl = fileDownloadInfo.downloadUrl;
        item.iconUrl = fileDownloadInfo.iconUrl;
        item.imgUrl = fileDownloadInfo.iconUrl;
        item.observerStatus = fileDownloadInfo.downloadStatus;
        item.packageName = fileDownloadInfo.packageName;
        item.itemID = fileDownloadInfo.itemID;

        String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", mDownloadingInfo.placementId);
        AppBuilder appBuilder = new AppBuilder()
                .setFromPage(PageConstants.My_Download)
                .setLastPage(PageConstants.My_Download)
                .setValue(value)
                .setParamsByData(item, "");
        TRJumpUtil.switcToAppDetailOptions(mActivity, appBuilder);

        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(fileDownloadInfo.itemID)
                .setButtonType(TRAnalyticsConstant.ICON)
                .setItemValue(fileDownloadInfo.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private void deleteTask(FileDownloadInfo info) {
        if (info == null) {
            return;
        }

        //避免用户点击删除按钮之前，该应用已经下载完成了
        if (FileDownloadInfo.STATUS_DOWNLOADED != fileDownloadInfo.downloadStatus) {
            Iterator iterator = mDatas.iterator();
            while (iterator.hasNext()) {
                FileManageDownloadAdapterItem item = (FileManageDownloadAdapterItem)iterator.next();
                if (item.fileDownloadInfo != null && !TextUtils.isEmpty(item.fileDownloadInfo.packageName) && TextUtils.equals(item.fileDownloadInfo.packageName, fileDownloadInfo.packageName)) {
                    iterator.remove();
                    break;
                }
            }
        }

        String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", mDownloadingInfo.placementId);
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(info.itemID)
                .setButtonType(TRAnalyticsConstant.DELETE)
                .setItemValue(info.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }
}

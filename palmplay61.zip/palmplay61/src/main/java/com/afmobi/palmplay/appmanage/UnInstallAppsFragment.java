package com.afmobi.palmplay.appmanage;

import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.afmobi.palmplay.base.BaseFragment;
import com.afmobi.util.DisplayUtil;
import com.transsnet.store.R;

public class UnInstallAppsFragment extends BaseFragment {

    /**
     * 空态页整体居中
     * @param emptyView
     */
    protected void setEmptyViewCenter(LinearLayout emptyView) {
        if (getActivity() == null || getActivity().isFinishing() || getActivity().isDestroyed() || emptyView == null) {
            return;
        }
        int height = DisplayUtil.getScreenHeight(getActivity());
        int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.uninstall_empty_view_height);
        int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
        int tabHeight = getResources().getDimensionPixelSize(R.dimen.detail_tab_h);
        int halfMarginTop = (height - emptyLayoutHeight) / 2;
        int statusBarHeight = (int) DisplayUtil.getStatusBarHeight(getActivity());
        int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight - tabHeight;
        if (finalMarginTop <= 0) {
            finalMarginTop = 0;
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) emptyView.getLayoutParams();
        params.topMargin = finalMarginTop;
        emptyView.setLayoutParams(params);
    }
}

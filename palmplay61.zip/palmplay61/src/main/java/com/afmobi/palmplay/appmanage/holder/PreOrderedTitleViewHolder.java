package com.afmobi.palmplay.appmanage.holder;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.afmobi.palmplay.appmanage.FileManageDownloadAdapterItem;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.transsnet.store.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 预约模块的title
 * Created by sk
 */
public class PreOrderedTitleViewHolder extends RecyclerView.ViewHolder {
    private Context mContext;
    private PageParamInfo mPageParamInfo;
    private TextView tv_preordered_task;
    /**
     * 新型打点的from值
     */
    public String mFrom;

    public PreOrderedTitleViewHolder(@NonNull View itemView) {
        super(itemView);
        tv_preordered_task = itemView.findViewById(R.id.tv_preordered_task);
    }

    public PreOrderedTitleViewHolder setContext(Context context) {
        mContext = context;
        return this;
    }

    public PreOrderedTitleViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        mPageParamInfo = pageParamInfo;
        return this;
    }

    public PreOrderedTitleViewHolder setFrom(String from) {
        mFrom = from;
        return this;
    }

    public PreOrderedTitleViewHolder bind(FileManageDownloadAdapterItem itemData, int position) {
        if (tv_preordered_task != null) {
            String downloading = mContext.getString(R.string.txt_preordered);
            int preOrderedCount = itemData.preOrderedCount;
            if (preOrderedCount > 99) {
                downloading = downloading + "(99+)";
            } else if (preOrderedCount > 0) {
                downloading = downloading + "(" + preOrderedCount + ")";
            }
            tv_preordered_task.setText(downloading);
        }

        return this;
    }
}

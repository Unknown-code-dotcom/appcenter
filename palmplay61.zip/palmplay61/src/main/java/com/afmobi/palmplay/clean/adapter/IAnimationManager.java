package com.afmobi.palmplay.clean.adapter;

import android.view.View;
import android.view.ViewGroup;

/**
 * Created by xiangfei.wei on 2017/12/24.
 */

public interface IAnimationManager {
    void startRightAppearanceAnimation(int position, View view, ViewGroup parent);
}

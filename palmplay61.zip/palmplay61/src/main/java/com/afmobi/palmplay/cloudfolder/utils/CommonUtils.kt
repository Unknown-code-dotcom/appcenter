package com.afmobi.palmplay.cloudfolder.utils

import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toDrawable
import com.afmobi.palmplay.cloudfolder.AppFolderProvider
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.GameFolderProvider
import com.afmobi.palmplay.cloudfolder.page.AppCloudFolderActivity
import com.afmobi.palmplay.cloudfolder.page.BaseCloudFolderActivity
import com.afmobi.palmplay.cloudfolder.page.CloudFolderFragment
import com.afmobi.palmplay.cloudfolder.page.GameCloudFolderActivity
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsnet.store.R
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.lang.ref.WeakReference
import java.lang.reflect.Method
import java.util.Locale


const val KEY_CLOUD_FOLDER_TYPE = "KEY_CLOUD_FOLDER_TYPE"

const val KEY_CLOUD_FOLDER_TAB_DEFAULT = "KEY_CLOUD_FOLDER_TAB_DEFAULT"

const val KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG = "palm.cloud.folder.preinstall.app.config"
const val KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG = "palm.cloud.folder.preinstall.game.config"

const val KEY_CLOUD_FOLDER_USE_LAUNCHER_BG = "KEY_CLOUD_FOLDER_USE_LAUNCHER_BG"

//值和非解耦之前保持一致
const val CATEGORY_APP = 13
const val CATEGORY_GAMES = 12

val ADD_WIDGET_SUCCESS_ACTION = "addWidgetSuccess"

const val TYPE_GET_ALL = 1  //获取全部物料
const val TYPE_GET_CACHED = 2  //获取已缓存物料

const val CREATE_SHORTCUT = "create_shortcuts"
const val CREATE_SHORTCUT_ID = "shortcuts_id"

const val EXTRA_SHORTCUT_ID_KEY: String = "extra_shortcut_package_name"

fun  Int.isHotAppsFolder() : Boolean {
   return this == CATEGORY_APP
}

enum class FOLDER(val title: String, val categoryType : Int, val index : Int, val defaultDrawable : Int,val defaultShortcutDrawable : Int, val widgetClass : Class<out AppWidgetProvider>, val pageClass : Class<out AppCompatActivity>, val shortcutId: String, val shortcutAction: String) {
    //todo 移除id
    APPS(CloudFolderManager.getInstance().getAppFolderName(useSystemLanguage = true), CATEGORY_APP, 0, R.drawable.cloud_folder_hot_icon,R.drawable.cloud_folder_shortcut_hot_icon, AppFolderProvider::class.java, AppCloudFolderActivity::class.java, "id_palmstore_shortcuts", "store.action.shortcuts.app"),
    GAMES(CloudFolderManager.getInstance().getGameFolderName(useSystemLanguage = true), CATEGORY_GAMES, 1, R.drawable.cloud_folder_game_icon, R.drawable.cloud_folder_shortcut_game_icon, GameFolderProvider::class.java, GameCloudFolderActivity::class.java, "id_test", "store.action.shortcuts.game")
}

fun FOLDER.getFolderTitle() : String {
    return if(this == FOLDER.APPS) {
        CloudFolderManager.getInstance().getAppFolderName(useSystemLanguage = true)
    } else {
        CloudFolderManager.getInstance().getGameFolderName(useSystemLanguage = true)
    }
}

object FOLDER_STATUS {

    const val STATUS_FILE_FOLDER_PERMISSION_DEFAULT = 0  //未授权
    const val STATUS_FILE_FOLDER_PERMISSION_GRANT = 1   //同意创建
    const val STATUS_FILE_FOLDER_PERMISSION_NO_GRANT = 2 //主动关闭

    const val SWITCH_CLOSE_CLOUD_FOLDER = 5 //关闭文件夹， 与launcher断连(解耦版本认定为关闭)
    const val SWITCH_OPEN_HOT_FOLDER = 6    //单独开启hot apps
    const val SWITCH_OPEN_GAME_FOLDER = 7   //单独开启hot games
    const val SWITCH_OPEN_BOTH_FOLDER = 8   //两个文件夹都开启
    const val SWITCH_CLOUD_FOLDER_CLOSE_PS = 15   //关闭文件夹，与launcher不断连 (解耦版本同5)
    const val SWITCH_CLOUD_FOLDER_OPEN = 16   //文件夹开启
}



/**
 * 将dip或dp值转换为px值，保证尺寸大小不变
 *
 * @param dipValue
 * （DisplayMetrics类中属性density）
 * @return
 */
fun dip2px(dipValue: Float): Int {
    val scale = TRApplicationContextUtil.getInstance()?.resources?.displayMetrics?.density ?: 0f
    return (dipValue * scale + 0.5f).toInt()
}

/**
 * 获取屏幕宽度
 *
 * @return
 */
fun getScreenWidth(): Int {
    return TRApplicationContextUtil.getInstance()?.resources?.displayMetrics?.widthPixels ?: 0
}

fun isUsingSilentInstall(): Boolean {
    return TRApplicationContextUtil.ismHasSlientPermission()
}

object SystemProperties {

    private var getMethod: Method? = null
    private var getBooleanMethod: Method? = null

    fun getInt(key: String?, def: Int): Int {
        try {
            val method =
                Class.forName("android.os.SystemProperties").getMethod(
                    "getInt",
                    String::class.java,
                    Int::class.javaPrimitiveType
                )
            return method.invoke(null, key, def) as Int
        } catch (e: java.lang.Exception) {
            Log.e(
                "SystemProperties",
                "SystemProperties.getInt error : ",
                e
            )
        }
        return 0
    }

    fun get(key: String): String {
        return try {
            if (getMethod == null) {
                getMethod = Class.forName("android.os.SystemProperties")
                    .getMethod("get", String::class.java)
            }
            val ret = getMethod!!.invoke(null, key) as String
            ret ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    fun getBoolean(key: String, default: Boolean): Boolean {
        return try {
            if (getBooleanMethod == null) {
                getBooleanMethod = Class.forName("android.os.SystemProperties")
                    .getMethod("getBoolean", String::class.java, Boolean::class.java)
            }
            val ret = getBooleanMethod!!.invoke(null, key, default) as Boolean
            ret ?: default
        } catch (e: Exception) {
            default
        }
    }
}

fun drawableToBitmap(drawable: Drawable?): Bitmap? {
    try {
        if (drawable is BitmapDrawable) {
            if (drawable.bitmap != null) {
                return drawable.bitmap
            }
        }
        if (null != drawable) {
            val w = drawable.intrinsicWidth
            val h = drawable.intrinsicHeight
            val config =
                if (drawable.opacity != PixelFormat.OPAQUE) Bitmap.Config.ARGB_8888 else Bitmap.Config.RGB_565
            val bitmap = Bitmap.createBitmap(w, h, config)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, w, h)
            drawable.draw(canvas)
            return bitmap
        }
    }catch (e: Exception) {
    }
    return null
}

fun decodeBitmapFromResource(drawableId: Int): Bitmap? {
    return TRApplicationContextUtil.getInstance()?.let {
        try {
            val drawable = ContextCompat.getDrawable(it, drawableId)
            var bitmap : Bitmap ?= null
            drawable?.apply {
                bitmap = Bitmap.createBitmap(
                    intrinsicWidth,
                    intrinsicHeight,
                    Bitmap.Config.ARGB_8888
                )
                val canvas = Canvas(bitmap!!)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
            }
            return bitmap
        }catch (_: Exception) {
        }
        null
    }
}

suspend inline fun <T> suspendCoroutineWithTimeout(
    timeout: Long, crossinline block: (CancellableContinuation<T>) -> Unit
) = withTimeout(timeout) {
    suspendCancellableCoroutine(block = block)
}

/**
 * 获取安装源
 */
fun getInstalledSourcePackageName(packageManager: PackageManager?, installedPackage: String): String? {
    var installSource: String? = null
    try {
        packageManager?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val info = it.getInstallSourceInfo(installedPackage)
                installSource = info.initiatingPackageName
            } else {
                installSource = it.getInstallerPackageName(installedPackage)
            }
        }
    } catch (e: Exception) {
        LogUtils.e(e)
    }
    return installSource
}

/**
 * 是否ota后首次重启
 * @param context
 * @return
 */
fun isFirstBootAfterOta(context: Context): Boolean {
    try {
        val packageManager = context.packageManager
        val isDeviceUpgrading = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            packageManager.isDeviceUpgrading
        } else {
            false
        }
        var isUpgrade = false
        if(!isDeviceUpgrading) {
            val pm = context.packageManager

            // 1. 获取 pm 对象的类 (通常是 ApplicationPackageManager)
            val pmClass: Class<*> = pm.javaClass
            // 2. 查找名为 "isUpgrade" 的方法，无参数
            val method = pmClass.getMethod("isUpgrade")
            // 3. 调用该方法
            isUpgrade = method.invoke(pm) as Boolean
        }
        LogUtils.d(CloudFolderManager.TAG, " isFirstBootAfterOta isUpgrade:$isUpgrade.   isDeviceUpgrading:$isDeviceUpgrading")
        return isUpgrade || isDeviceUpgrading
    } catch (e: Exception) {
        LogUtils.e(e)
    }
    return false
}

/**
 * 封装内部跳转逻辑，自动处理 Activity 的离开标志位
 */
fun CloudFolderFragment.navigateToInternalActivity() {
    val host = activity
    if (host is BaseCloudFolderActivity) { // 替换为你真实的 Activity 类名
        host.isInternalNavigation = true
    }
}

/**
 * UI线程协程作用域--主线程TASK
 */
val mainScope by lazy { MainScope() }

/**
 * IO线程协程作用域--IO密集型TASK
 */
val ioScope by lazy { CoroutineScope(SupervisorJob() + Dispatchers.IO) }

fun bitmap2Drawable(context: Context, bitmap: Bitmap?): Drawable? {
    return bitmap?.toDrawable(context.resources)
}

/**
 * 根据地区自动选择格式化策略
 * 中国地区 (ZH): 强制使用 Locale.ENGLISH (标准阿拉伯数字)
 * 其他地区: 使用系统默认 Locale (可能会替换为当地数字符号)
 */
fun String.formatLocalized(vararg args: Any?): String {
    val currentLocale = Locale.getDefault()

    val targetLocale = if (currentLocale.language == "zh") {
        // 如果是中文环境（包含简体、繁体、港澳台），强制使用英文/标准数字格式
        Locale.ENGLISH
    } else {
        // 其他国家使用本地 Locale
        currentLocale
    }
    return String.format(targetLocale, this, *args)
}

private var cachedLocaleKey: String? = null
private var cachedLocaleContext: java.lang.ref.WeakReference<Context>? = null
private val localeContextLock = Any()
private fun Context.getCachedLocaleContext(locale: Locale): Context {
    // 优先使用 applicationContext，避免持有 Activity 导致内存泄漏
    val appContext = this.applicationContext ?: this
    val localeKey = locale.toLanguageTag()

    synchronized(localeContextLock) {
        if (cachedLocaleKey == localeKey) {
            cachedLocaleContext?.get()?.let { return it }
        }
        return try {
            val config = Configuration(appContext.resources.configuration)
            config.setLocale(locale)
            val newCtx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                appContext.createConfigurationContext(config)
            } else {
                @Suppress("DEPRECATION")
                config.locale = locale
                appContext.createConfigurationContext(config)
            }
            cachedLocaleKey = localeKey
            cachedLocaleContext = WeakReference(newCtx)
            newCtx
        } catch (_: Exception) {
            appContext
        }
    }
}

/**
 * 安全地获取格式化字符串
 * @param resId 字符串资源 ID
 * @param isCheckSimplifiedChinese 是否执行“简体中文强制英文”的逻辑，默认为 false
 * @param formatArgs 格式化参数
 */
fun Context.getSafeString(
    resId: Int,
    isCheckSimplifiedChinese: Boolean = false,
    useSystemLanguage: Boolean = false,
    vararg formatArgs: Any?
): String {
    // 获取需要使用的 Context
    val targetContext = if (useSystemLanguage) {
        try {
            val sysLocale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Resources.getSystem().configuration.locales[0]
            } else {
                @Suppress("DEPRECATION")
                Resources.getSystem().configuration.locale
            }
            getCachedLocaleContext(sysLocale)
        } catch (_: Exception) {
            this
        }
    } else {
        this
    }
    // 快速路径：不需要强制英文
    if (!isCheckSimplifiedChinese) {
        return try {
            targetContext.getString(resId, *formatArgs)
        } catch (e: Exception) {
            Log.e("ResourceError", "Error loading string for resId:  $ resId", e)
            ""
        }
    }

    // 判断是否为简体中文环境
    val currentLocale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        targetContext.resources.configuration.locales[0]
    } else {
        @Suppress("DEPRECATION")
        targetContext.resources.configuration.locale
    }
    val isSimplifiedChinese = currentLocale.language == "zh"
    // 如果不是简体中文，直接返回正常字符串
    if (!isSimplifiedChinese) {
        return try {
            targetContext.getString(resId, *formatArgs)
        } catch (e: Exception) {
            Log.e("ResourceError", "Error loading string for resId:  $ resId", e)
            ""
        }
    }

    // === 关键：强制使用英文资源 ===
    return try {
        // 创建英文配置
        val config = Configuration(targetContext.resources.configuration).apply {
            setLocale(Locale.US) // 或 Locale.ENGLISH
        }
        // 创建新资源上下文（兼容新旧 API）
        val localizedContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            targetContext.createConfigurationContext(config)
        } else {
            @Suppress("DEPRECATION")
            targetContext.resources.updateConfiguration(config, targetContext.resources.displayMetrics)
            targetContext
        }
        // 从英文资源中加载字符串并格式化
        localizedContext.getString(resId, *formatArgs)
    } catch (e: Exception) {
        Log.e("ResourceError", "Failed to load English string for resId:  $ resId", e)
        // 回退到原始字符串（可能是中文）
        try {
            targetContext.getString(resId, *formatArgs)
        } catch (ex: Exception) {
            ""
        }
    }
}
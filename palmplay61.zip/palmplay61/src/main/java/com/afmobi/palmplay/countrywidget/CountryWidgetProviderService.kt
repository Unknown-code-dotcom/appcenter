package com.afmobi.palmplay.countrywidget


import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import com.afmobi.palmplay.countrywidget.CountrySwitchManager.loadCountrySwitchData
import com.transsnet.adservice.util.GsonUtils

class CountryWidgetProviderService : ContentProvider() {
    override fun onCreate(): Boolean {
        return true
    }

    override fun call(authority: String, method: String, arg: String?, extras: Bundle?): Bundle? {
        if (TextUtils.equals(method, "on_perception_event")) {
            when (arg) {
                "city_location_change" -> {
                    try {
                        val businessData = extras?.getString("business_data")
                        val map =
                            GsonUtils.getInstance().fromJson(businessData, HashMap::class.java)
                        val cityCode : String? = map?.get("city_code")?.toString()
                        val countryCode: String? = map?.get("country_code")?.toString()
                        if (!TextUtils.isEmpty(countryCode)) {
                            loadCountrySwitchData(countryCode!!)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
        return super.call(authority, method, arg, extras)
    }

    override fun query(
        p0: Uri,
        p1: Array<out String>?,
        p2: String?,
        p3: Array<out String>?,
        p4: String?
    ): Cursor? {
        return null
    }

    override fun getType(p0: Uri): String? {
        return null
    }

    override fun insert(p0: Uri, p1: ContentValues?): Uri? {
        return null
    }

    override fun delete(p0: Uri, p1: String?, p2: Array<out String>?): Int {
        return -1
    }

    override fun update(p0: Uri, p1: ContentValues?, p2: String?, p3: Array<out String>?): Int {
        return -1
    }

}

package com.afmobi.palmplay.cloudfolder.view

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable

/**
 * Pad 榜单卡片背景 + 投影。
 * 在 bounds 内按 shadowRadius / offsetY 内缩绘制卡片，给阴影留出空间。
 */
class PadRankCardShadowDrawable(
    private val shadowRadius: Float,
    private val cornerRadius: Float,
    private val bgColor: Int,
    private val shadowColor: Int,
    private val offsetY: Float
) : Drawable() {

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = bgColor
        if (shadowRadius > 0f) {
            setShadowLayer(shadowRadius, 0f, offsetY, shadowColor)
        }
    }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = bgColor
    }
    private val cardRect = RectF()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val insetH = shadowRadius
        val insetTop = (shadowRadius - offsetY).coerceAtLeast(0f)
        val insetBottom = shadowRadius + offsetY
        cardRect.set(
            bounds.left + insetH,
            bounds.top + insetTop,
            bounds.right - insetH,
            bounds.bottom - insetBottom
        )
    }

    override fun draw(canvas: Canvas) {
        if (shadowRadius > 0f) {
            canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, shadowPaint)
        }
        canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, bgPaint)
    }

    override fun setAlpha(alpha: Int) {
        shadowPaint.alpha = alpha
        bgPaint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        shadowPaint.colorFilter = colorFilter
        bgPaint.colorFilter = colorFilter
    }

    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

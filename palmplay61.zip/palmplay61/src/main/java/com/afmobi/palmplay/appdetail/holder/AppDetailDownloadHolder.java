package com.afmobi.palmplay.appdetail.holder;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.appdetail.GdprDialogInstance;
import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;
import com.afmobi.palmplay.appnext.AppNextConstants;
import com.afmobi.palmplay.appnext.AppNextProcessor;
import com.afmobi.palmplay.category.DetailDownloadButtonListener;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.manager.Code;
import com.afmobi.palmplay.manager.PalmPlayNetworkDownloadStateManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.quickinstall.PreInstallManager;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.animations.AnimationFactory;
import com.afmobi.util.animations.AnimationFactoryParams;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.util.MD5;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.launcherlib.callback.IDispensePlanCallBack;
import com.transsnet.launcherlib.database.DispensePlan;
import com.transsnet.launcherlib.services.DispenseDataProcessor;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.lang.ref.WeakReference;

public class AppDetailDownloadHolder extends BaseAppDetailHolder implements View.OnClickListener {
    private DownClicker downClicker;
    private WeakReference<DetailDownloadButtonListener> mStatusChangeListener;
    private long statusTag;

    public AppDetailDownloadHolder(FragmentActivity activity, TRNewAppViewModel mAppDetailModel, CommonAppDetailView commonAppDetailView, DownClicker downClicker) {
        super(activity, mAppDetailModel, commonAppDetailView);
        this.downClicker = downClicker;
    }

    @Override
    public void initHolder() {
        commonAppDetailView.mBinding.statusPanel.setOnClickListener(this);
        commonAppDetailView.mBinding.downMsgClose.setOnClickListener(this);
        commonAppDetailView.mBinding.statusPanel.setVisibility(View.VISIBLE);

        // 判断速开标记，设置按钮样式
        AppInfo appInfo = commonAppDetailView.mAppInfo;
        if(appInfo != null) {
            appInfo.isQuickOpen = PreInstallManager.INSTANCE.isQuickOpenApp(appInfo.itemID, appInfo.version);
            commonAppDetailView.mBinding.statusPanel.setQuickOpenStyle(appInfo.isQuickOpen);
        }

        final DetailDownloadButtonListener listener = new DetailDownloadButtonListener(mActivity, commonAppDetailView.mBinding.statusPanel, null, commonAppDetailView.mAppInfo, commonAppDetailView.isCustomizedStyle());
        mStatusChangeListener = new WeakReference<>(listener);
        if (mStatusChangeListener.get() != null) {
            mStatusChangeListener.get().setIMessenger(new IMessenger() {

                @Override
                public void onMessenger(Object... objects) {
                    setUpdatedAppCount();
                }
            }, false);

        }
        statusTag = System.currentTimeMillis();
        DownloadStatusManager.getInstance().putStatusChangeListener(statusTag, listener); //不用tag是因为，详情页里面还可以继续调用详情页，key如果一样就会导致有状态显示问题h
    }

    public void updateStatusChanged(){
        if (mStatusChangeListener != null && mStatusChangeListener.get() != null) {
            mStatusChangeListener.get().updateStatusChanged();
        }
    }

    public void updateStatusChanged(AppInfo mAppInfo){
        if (mStatusChangeListener != null && mStatusChangeListener.get() != null) {
            PsVaManager.getInstance().dealVaGameData(mAppInfo);
            // 同步速开状态
            boolean isQuickOpen = mAppInfo != null && PreInstallManager.INSTANCE.isQuickOpenApp(mAppInfo.itemID, mAppInfo.version);
            if(mAppInfo != null) {
                mAppInfo.isQuickOpen = isQuickOpen;
            }
            commonAppDetailView.mBinding.statusPanel.setQuickOpenStyle(isQuickOpen);
            mStatusChangeListener.get().setmDataInfo(mAppInfo);
            mStatusChangeListener.get().updateStatusChanged();
        }
    }

    public void updateVaUI(){
        if (mStatusChangeListener != null && mStatusChangeListener.get() != null) {
            mStatusChangeListener.get().updateVaUI();
        }
    }

    public void setUpdatedAppCount() {
        if (mActivity.isDestroyed() || mActivity.isFinishing()) {
            return;
        }

        TRHomeUtil.refreshAppCount(commonAppDetailView.mBinding.titleInclude.tvDownloadingCount, commonAppDetailView.mBinding.titleInclude.downloadingAnimView);
        TextView tvVaDownloadingCount= commonAppDetailView.mBinding.titleInclude.gameDetailVaGame.findViewById(R.id.tv_va_downloading_count);
        if (tvVaDownloadingCount != null) {
            TRHomeUtil.refreshVaAppCount(tvVaDownloadingCount);
        }
    }

    public void onDestroy() {
        DownloadStatusManager.getInstance().removeStatusChangeListener(statusTag);
        mStatusChangeListener = null;
        //兜底删除所有详情页的key
        DownloadStatusManager.getInstance().removeStatusChangeListenerByKey("TR_detail_"+ this);
    }

    public void preHandleAutoDownload(boolean isAutoDownload, AppInfo mAppInfo, View statusPanel, String mFrom){

        if (isAutoDownload) {
            if (!GdprDialogInstance.getInstance().isGdprAgreed()) {
                return;
            }
            if (null == mAppInfo) {
                mAppInfo = (AppInfo) mAppDetailModel.buildObject(new AppInfo());
            }

            if (TextUtils.isEmpty(mAppInfo.packageName)) {
                return;
            }

            if (TextUtils.isEmpty(mAppInfo.itemID)){
                mAppInfo.itemID = MD5.md5Of32(mAppInfo.packageName);
            }
            //网络正常 模拟用户点击
            if (NetworkUtils.isNetworkAvailable(mActivity)){
                if (needAddToDownloadingList(mAppInfo)){
                    mAppInfo.sourceType = 2;
                    if (NetworkUtils.isGPRSNetwork(PalmplayApplication.getAppInstance()) && PalmPlayNetworkDownloadStateManager.isDataChargesLimit()) {
                        addToDownloadList(true, mAppInfo);
                    }else {
                        handDownload(statusPanel, mAppInfo, mFrom);
                    }
                }
            }
            else {//网络异常情况

                if (TextUtils.isEmpty(mAppInfo.name)) {
                    if( mAppInfo.externalId > 0 ){
                        //名字为空情况，查询本地分发数据库兜底
                        AppInfo finalMAppInfo = mAppInfo;
                        DispenseDataProcessor.getInstance().obtainDispensePlanInfo(mAppInfo.externalId, new IDispensePlanCallBack() {
                            @Override
                            public void callBack(DispensePlan plan) {
                                if (plan != null && !TextUtils.isEmpty(plan.materialName)) {
                                    finalMAppInfo.name = plan.materialName;
                                    addToDownloadList(false, finalMAppInfo);
                                }
                            }
                        });
                    }
                    return;
                }
                addToDownloadList(false, mAppInfo);
            }
        }
    }

    private void addToDownloadList(boolean isPause, AppInfo mAppInfo){

        FileDownloadInfo downloadingItem = DownloadManager.getInstance().getDownloadingInfo(mAppInfo.packageName);
        if (null != downloadingItem) {
            return;
        }
        //todo 外部传了搜索词时做更新
        if(!TextUtils.isEmpty(mAppDetailModel.getSearchKeyWord())) {
            mAppInfo.searchWord = mAppDetailModel.getSearchKeyWord();
            mAppInfo.searchType = mAppDetailModel.getSearchType();
        }

        if (needAddToDownloadingList(mAppInfo)) {
            FileDownloadInfo loadingInfo = new FileDownloadInfo(mAppInfo);
            loadingInfo.fromPage = (String) mAppDetailModel.getParam("fromPageID");
            loadingInfo.pageParamInfo = (PageParamInfo) mAppDetailModel.getParam("mPageParamInfo");
            if (isPause) {
                DownloadManager.getInstance().addDownloadingInfoWithPause(loadingInfo);
            }else {
                DownloadManager.getInstance().addDownloadingInfo(loadingInfo);
            }

            String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.MODULE_DETAIL_INSTALL, "", "");
            mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,TRAnalyticsConstant.VIRTUAL_CLICK,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                    mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);

        }
    }

    private boolean needAddToDownloadingList(AppInfo mAppInfo) {
        return !FileDownloadInfo.isDownloading(mAppInfo.observerStatus)
                && FileDownloadInfo.STATUS_DOWNLOADED != mAppInfo.observerStatus
                && FileDownloadInfo.STATUS_APP_INSTALLED != mAppInfo.observerStatus;
    }

    public void handDownload(View v, AppInfo mAppInfo, String mFrom) {
        if (null == mAppInfo) {
            mAppInfo = (AppInfo) mAppDetailModel.buildObject(new AppInfo());
            if (TextUtils.isEmpty(mAppInfo.name)) {
                mAppInfo.name = (String) mAppDetailModel.getParam("mArgumentsTitle");
            }
        }

        AppInfo finalMAppInfo = mAppInfo;
        PsVaManager.getInstance().checkDownloadInfo(mAppInfo, LaunchInfo.LAUNCH_FROM_DETAIL,mFrom,
                () -> onClickDownload((String) mAppDetailModel.getParam("fromPageID"), v, finalMAppInfo,
                        (String) mAppDetailModel.getParam("mItemID"),
                        (PageParamInfo) mAppDetailModel.getParam("mPageParamInfo"), mFrom));

    }

    public void onClickDownload(String fromPageID, View v, AppInfo mAppInfo, String mItemID, PageParamInfo pageParamInfo, String mFrom) {

        String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.MODULE_DETAIL_INSTALL, "", "");
        if (mAppInfo.isVa) {
            if (BuildConfig.DEBUG) {
                Log.e("cwxxx", "openVaLoadingActivity", new Throwable("who call me"));
            }
            mAppDetailModel.statusClickAnalytics(mAppInfo.isVa, value, TRAnalyticsConstant.PLAY, mAppInfo.itemID, mAppInfo.packageName, mAppInfo.item_type,
                    mAppInfo.topicID, "", mAppInfo.expId, mAppInfo.isQuickOpen);
            TRJumpUtil.openVaLoadingActivity(new FileDownloadInfo(mAppInfo), new LaunchInfo(LaunchInfo.LAUNCH_FROM_DETAIL, mFrom));
            return;
        }

        Context context = v == null ? PalmplayApplication.getAppInstance() : v.getContext();
        if (mAppInfo != null) {
            AnimationFactoryParams params = null;
            AnimationFactory mAnimationFactory = null;
            if (commonAppDetailView.mOnViewLocationInScreen != null && v != null) {
                params = new AnimationFactoryParams(commonAppDetailView.headerViewBinding.ivIcon, commonAppDetailView.mOnViewLocationInScreen, 24);
                mAnimationFactory = AppDetailAnimationUtil.getInstance();
            }
            if (FileDownloadInfo.STATUS_DOWNING == mAppInfo.observerStatus) {
                mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,mAppInfo.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                        mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);
                DownloadManager.getInstance().pauseDownload(mAppInfo.packageName);
            } else if (FileDownloadInfo.STATUS_WAIT == mAppInfo.observerStatus) {
                if ((mAppInfo.isVa)) {
                    DownloadManager.getInstance().resumeDownload(mAppInfo.packageName);
                } else {
                    DownloadManager.getInstance().pauseDownload(mAppInfo.packageName);
                }
                mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,mAppInfo.isVa ? TRAnalyticsConstant.CONTINUE : TRAnalyticsConstant.PAUSE,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                        mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);
            } else if (FileDownloadInfo.STATUS_PAUSE == mAppInfo.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == mAppInfo.observerStatus) {
                mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,TRAnalyticsConstant.CONTINUE,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                        mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);
                DownloadUtil.resumeDownload(context, mAppInfo.packageName);
            } else {
                if (DownloadDecorator.checkJumpToGooglePlay(context, mAppInfo.outerUrl, mAppInfo.packageName, pageParamInfo, mItemID, mAppInfo.version, mAppInfo.verifyGoogle)) {
                    return;
                }
                String fromPageIsDetail = fromPageID + Constant.FROM_DETAIL_SEPARATOR + Constant.FROM_DETAIL;

                if(FileDownloadInfo.STATUS_NONE == mAppInfo.observerStatus) {
                    if (!TextUtils.isEmpty(mAppDetailModel.getClickReportUrl())) {
                        AppNextProcessor.addAsyncTask(mAppInfo.packageName, AppNextConstants.ITEM_CLICK, mAppDetailModel.getClickReportUrl());
                    }

                    mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,TRAnalyticsConstant.INSTALL,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                            mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);

                } else if(FileDownloadInfo.STATUS_APP_UPDATE == mAppInfo.observerStatus) {
                    mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,TRAnalyticsConstant.UPDATE,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                            mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);
                } else if(FileDownloadInfo.STATUS_APP_INSTALLED == mAppInfo.observerStatus) {
                    mAppDetailModel.statusClickAnalytics(mAppInfo.isVa,value,TRAnalyticsConstant.OPEN,mAppInfo.itemID,mAppInfo.packageName,mAppInfo.item_type,
                            mAppInfo.topicID,"", mAppInfo.expId, mAppInfo.isQuickOpen);
                }

                if(FileDownloadInfo.STATUS_NONE == mAppInfo.observerStatus || FileDownloadInfo.STATUS_APP_UPDATE == mAppInfo.observerStatus){
                    params = null;
                    if (v != null) {
                        commonAppDetailView.jump2FeatureTab();
                    }
                }

                if(mAppInfo!=null && mAppInfo.taNativeInfo!=null && CommonUtils.isFirstClick(mAppInfo.observerStatus)) {
                    mAppInfo.taNativeInfo.handleClick(HisavanaSdkManager.FIRST_CREATE);
                }

                //todo 外部传了搜索词时做更新
                if(!TextUtils.isEmpty(mAppDetailModel.getSearchKeyWord())) {
                    mAppInfo.searchWord = mAppDetailModel.getSearchKeyWord();
                    mAppInfo.searchType = mAppDetailModel.getSearchType();
                }
                DownloadDecorator.startDownloading(mAppInfo, fromPageIsDetail, new PageParamInfo(mFrom, value), mAnimationFactory, params);
            }
        }
    }

    @Override
    @SingleClick(800)
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.status_panel){
            if (downClicker !=null){
                downClicker.downLoadClick();
            }
        } else if (id == R.id.down_msg_close){
            commonAppDetailView.mBinding.downMsgLayout.setVisibility(View.GONE);
        }
    }

    public void checkButton(AppInfo mAppInfo, int code){
        if (code == Code.CODE_506_NEGATIVE || (mAppInfo != null && !mAppInfo.itemCheckFlag)){
            CommonUtils.setDownloadButtonGray(commonAppDetailView.mBinding.statusPanel, PalmplayApplication.getAppInstance().getResources().getDrawable(R.drawable.selector_common_gray_btn_bg));
            commonAppDetailView.mBinding.statusPanel.setEnabled(true);
            checkDownInfo(mAppInfo, code);
        }
    }

    public void checkDownInfo(AppInfo mAppInfo, int code){
        if (mAppInfo != null && !TextUtils.isEmpty(mAppInfo.itemCheckReason)){
            commonAppDetailView.mBinding.downMsgLayout.setVisibility(View.VISIBLE);
            commonAppDetailView.mBinding.txtDownMsg.setText(mAppInfo.itemCheckReason);
        } else {
            if (code == Code.CODE_506_NEGATIVE){
                commonAppDetailView.mBinding.downMsgLayout.setVisibility(View.VISIBLE);
                commonAppDetailView.mBinding.txtDownMsg.setText(R.string.no_related_resource_2);
            } else {
                commonAppDetailView.mBinding.downMsgLayout.setVisibility(View.GONE);
            }
        }
    }

    public interface DownClicker{
        void downLoadClick();
    }
}

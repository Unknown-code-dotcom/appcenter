package com.afmobi.palmplay.cloudfolder.utils

import android.content.Context
import android.content.res.Resources
import android.graphics.Paint
import android.graphics.Point
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsion.palmstorecore.util.getContextDisplayId
import com.transsion.palmstorecore.util.isPadDisplay
import com.transsnet.store.R
import kotlin.jvm.JvmOverloads

class DeviceProfile private constructor() {
    companion object {
        @Volatile
        private var INSTANCE: DeviceProfile? = null

        @JvmStatic
        fun getInstance(): DeviceProfile {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: DeviceProfile().also { INSTANCE = it }
            }
        }
    }

    @JvmField
    var folderCellMarginStartEnd: Int = dip2px(51f)
    private val countX = 4
    private var mCellWidth = 0

    private var padding = 0
    private var paddingTop = 0
    private var paddingBottom = 0
    private val mCountY = 4
    private var mCellHeight = 0

    private var folderTitleTopOffset = 0

    private var folderPaddingTop = 0

    var folderIconPreviewPadding = 0

    val STATUS_BAR_HEIGHT_RES_NAME = "status_bar_height"

    var iconSizePx = dip2px(56f)

    private var availableWidthPx : Int = 0
    var cloudFolderRvMargin = dip2px(20f)

    var folderBottomPadding : Int = 0

    val folderBottomSpace = dip2px(4f)
    val folderBottomExtraSpace = dip2px(3f)

    var folderBottomItemWidth : Int = -1

    var isPadLayout: Boolean = false
        private set

    var bottomIconItemWidth: Int = dip2px(60f)
        private set
    var bottomIconGap: Int = dip2px(6f)
        private set
    var bottomIconInnerPadding: Int = 0
        private set
    var bottomIconInnerPaddingEnd: Int = 0
        private set

    @JvmOverloads
    fun initData(configContext: Context? = null) {
        try {
            val appContext = TRApplicationContextUtil.getInstance()
            val context = configContext ?: appContext
            val res = context.resources
            isPadLayout = isPadDisplay(
                context,
                res.configuration,
                context.getContextDisplayId()
            )
            val folderCellLayoutPaddingTop =
                res.getDimensionPixelSize(R.dimen.folder_celllayout_padding_top_column_4)
            val folderCellLayoutPaddingBottom =
                res.getDimensionPixelSize(R.dimen.folder_celllayout_padding_bottom_column_4)
            padding = dip2px(10f)
            paddingTop = dip2px(16f)
            paddingBottom = dip2px(8f)
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            val display = wm?.defaultDisplay
            val realSize = getRealSize(display)
            val dm = DisplayMetrics()
            display?.getMetrics(dm)
            // 修复兼容性问题：原先使用 display?.getCurrentSizeRange 是废弃方法，
            // 且在分屏/多窗口模式下会返回整个物理屏幕大小，导致布局在分屏下错乱。
            // 使用 displayMetrics.widthPixels 能更准确地获取当前应用可用窗口的宽度。
            availableWidthPx = dm.widthPixels
            val folderCellMarginStartEnd =
                res.getDimensionPixelSize(R.dimen.folder_cell_margin_start_end_column_4)
            val folderCellLayoutPaddingStartEnd =
                res.getDimensionPixelSize(R.dimen.folder_celllayout_padding_start_end_column_4)
            val folderMaxWidth =
                availableWidthPx - 2 * folderCellMarginStartEnd - 2 * folderCellLayoutPaddingStartEnd
            mCellHeight =
                res.getDimensionPixelSize(R.dimen.folder_cell_height) //cellHeightPx + edgeMarginPx;
            mCellWidth = folderMaxWidth / countX
            val folderCellLayoutHeight = mCountY * mCellHeight

            // 横屏时用实际屏幕高度，竖屏用长边（保持原有逻辑不受系统栏影响）
            val isLandscape = res.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
            val effectiveHeight = if (isLandscape) dm.heightPixels else realSize.y

            folderPaddingTop =
                maxOf(0, (effectiveHeight - folderCellLayoutHeight - folderCellLayoutPaddingTop - folderCellLayoutPaddingBottom) / 2)
            folderTitleTopOffset =
                maxOf(0, folderPaddingTop - (calculateTextHeight(res.getDimension(R.dimen.folder_title_text_size)) + 2 * res.getDimensionPixelSize(
                    R.dimen.folder_titles_padding_bottom
                ) + res.getDimensionPixelSize(R.dimen.folder_titles_padding_bottom_portrait)).toInt())

            folderIconPreviewPadding =
                res.getDimensionPixelSize(R.dimen.folder_icon_preview_padding)

            folderBottomPadding = res.getDimensionPixelSize(R.dimen.cloud_folder_bottom_padding)

            if (isPadLayout) {
                calculatePadBottomLayout(res)
            } else {
                calculatePhoneBottomLayout(res.displayMetrics.widthPixels)
            }
        } catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    private fun calculatePhoneBottomLayout(screenWidth: Int) {
        val bottomIconPadding = folderBottomPadding * 2
        val bottomIconTotalMargin = folderBottomSpace * 6
        val totalSpace = bottomIconPadding + bottomIconTotalMargin + folderBottomExtraSpace * 3
        folderBottomItemWidth = (screenWidth - totalSpace) / countX
    }

    private fun calculatePadBottomLayout(res: Resources) {
        bottomIconItemWidth = res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_bottom_item_width)
        folderBottomItemWidth = bottomIconItemWidth
        // 样式 1/4 底栏相对中间内容宽合计收窄 bottom_narrow_width。
        val contentWidth = getPadBottomContentWidth(res)
        val iconRowWidth = countX * bottomIconItemWidth
        bottomIconGap = ((contentWidth - iconRowWidth) / (countX - 1)).coerceAtLeast(0)
        val sidePadding = ((availableWidthPx - contentWidth) / 2).coerceAtLeast(0)
        bottomIconInnerPadding = sidePadding
        bottomIconInnerPaddingEnd = sidePadding
    }

    fun getDesiredHeight(): Int {
        return paddingTop + paddingBottom + mCountY * mCellHeight + dip2px(5f)
    }

    fun getDesiredWidth(): Int {
        return padding * 2 + countX * mCellWidth
    }

    /**
     * Pad 中间竖向增量（行距 / 搜索到宫格 / 榜单到宫格）。手机为 0。
     */
    fun padSpaceExtra(res: Resources): Int {
        return if (isPadLayout) {
            res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_space_extra)
        } else {
            0
        }
    }

    /** 手机 dimen + Pad 竖向增量。 */
    fun withPadSpaceExtra(res: Resources, phoneDimenRes: Int): Int {
        return res.getDimensionPixelSize(phoneDimenRes) + padSpaceExtra(res)
    }

    /**
     * 搜索框到主列表 RV 的 topMargin。
     * Pad 非固定榜单单独用 search_to_list_top；固定榜单 / 手机仍走 phoneDimen + padSpaceExtra。
     */
    fun recyclerViewTopMargin(res: Resources, fixedRankVisible: Boolean): Int {
        if (isPadLayout && !fixedRankVisible) {
            return res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_search_to_list_top)
        }
        return withPadSpaceExtra(
            res,
            if (fixedRankVisible) R.dimen.dp_22 else R.dimen.dp_15
        )
    }

    /** Pad 标题到搜索框额外拉开的间距。手机为 0。 */
    fun padTitleToSearchExtra(res: Resources): Int {
        return if (isPadLayout) {
            res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_title_search_extra)
        } else {
            0
        }
    }

    /**
     * Pad 搜索栏左右 padding，与内容宽、标题 start 共用同一 token。
     */
    fun padSearchSidePadding(res: Resources): Int {
        return res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_search_side_padding)
    }

    /** Pad 底栏顶部间距：竖屏 45dp，横屏 10dp。 */
    fun padBottomTopMargin(res: Resources): Int {
        val isLandscape =
            res.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        return res.getDimensionPixelSize(
            if (isLandscape) {
                R.dimen.ps_cloud_folder_pad_bottom_top_landscape
            } else {
                R.dimen.ps_cloud_folder_pad_bottom_top
            }
        )
    }

    /** Pad 根容器为中间加高的间距补高度；样式 2/3 按榜单 + 3 行宫格补。 */
    fun padContentHeightExtra(res: Resources, layoutStyle: Int): Int {
        val extra = padSpaceExtra(res)
        if (extra == 0) return 0
        val isRankStyle = layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_GRID ||
            layoutStyle == CloudFolderManager.LAYOUT_STYLE_RANK_LIST
        val gridRows = if (isRankStyle) 3 else 4
        val topGaps = if (isRankStyle) 2 else 1
        return extra * (topGaps + gridRows)
    }

    /**
     * Pad 搜索栏容器宽度：在设计稿最大宽上再加 search_extra_width（+20dp）。
     */
    fun getPadSearchContainerWidth(res: Resources): Int {
        val extraWidth = res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_search_extra_width)
        return (padSearchMaxWidth(res) + extraWidth)
            .coerceAtMost(getAvailableWidthPx())
            .coerceAtLeast(0)
    }

    /**
     * Pad 内容区 / 底栏对齐基准宽：与搜索输入框 + 右侧 icon 的可视宽度对齐，
     * 再整体加 content_extra_width。不含搜索栏左右 padding。
     */
    fun getPadSearchAlignedContentWidth(res: Resources): Int {
        val searchSidePadding = padSearchSidePadding(res)
        val extraWidth = res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_content_extra_width)
        return (getPadSearchContainerWidth(res) - searchSidePadding * 2 + extraWidth)
            .coerceAtMost(getAvailableWidthPx())
            .coerceAtLeast(0)
    }

    /** Pad 底栏宽度：相对中间内容宽合计收窄 bottom_narrow_width。 */
    fun getPadBottomContentWidth(res: Resources): Int {
        val narrow = res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_bottom_narrow_width)
        return (getPadSearchAlignedContentWidth(res) - narrow)
            .coerceAtMost(getAvailableWidthPx())
            .coerceAtLeast(0)
    }

    /** Pad 横竖屏共用竖屏搜索最大宽，保证内容区宽度一致。 */
    private fun padSearchMaxWidth(res: Resources): Int {
        return res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_search_max_width)
    }

    fun getTitleTopOffset(): Int {
        return folderTitleTopOffset
    }

    fun getFolderPaddingTop(): Int {
        return if(CloudFolderManager.getInstance().isShortcutSplit()) {
            folderPaddingTop - dip2px(20f)
        } else {
            folderPaddingTop - dip2px(24f)
        }
    }

    private fun getRealSize(display: Display?): Point {
        val realSize = Point()
        if (display == null) {
            return realSize
        }
        display.getRealSize(realSize)
        val smallSide = Math.min(realSize.x, realSize.y)
        val largeSide = Math.max(realSize.x, realSize.y)
        realSize[smallSide] = largeSide
        return realSize
    }

    fun getAvailableWidthPx() : Int {
        if (availableWidthPx == 0) {
            try {
                val context = TRApplicationContextUtil.getInstance()
                availableWidthPx = context.resources.displayMetrics.widthPixels
            } catch (e: Exception) {
                LogUtils.e(e)
            }
        }
        return availableWidthPx
    }


    /**
     * 获取状态栏的高度
     * @param context
     * @return
     */
    private fun getStatusBarHeight(context: Context): Int {
        return getInternalDimensionSize(context.resources, STATUS_BAR_HEIGHT_RES_NAME)
    }

    /**
     * 获取一些系统隐藏的试题值
     * @param res
     * @param key
     * @return
     */
    private fun getInternalDimensionSize(
        res: Resources,
        key: String
    ): Int {
        val resId = res.getIdentifier(key, "dimen", "android")
        return if (resId > 0) res.getDimensionPixelSize(resId) else 0
    }


    /**
     * Calculates the height of a given string at a specific text size.
     */
    private fun calculateTextHeight(textSizePx: Float): Float {
        val p = Paint()
        p.textSize = textSizePx
        val fm = p.fontMetrics
        return -fm.top + fm.bottom
    }

    fun getRealSize(context: Context): Point {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        val realSize = Point()
        wm?.defaultDisplay?.getRealSize(realSize)
        return realSize
    }

}

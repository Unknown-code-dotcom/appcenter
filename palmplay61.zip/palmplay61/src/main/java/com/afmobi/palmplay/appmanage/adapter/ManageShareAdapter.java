package com.afmobi.palmplay.appmanage.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.transsnet.store.R;

import java.util.List;

/**
 * Created by hxy on 2017-03-22.
 */

public class ManageShareAdapter extends RecyclerView.Adapter<ManageShareAdapter.ViewHolder> {

    private Context context;
    private LayoutInflater inflater;
    private List<String> shareList;

    private OnRecyclerViewItemListener mOnRecyclerViewItemListener;

    public interface OnRecyclerViewItemListener {
        public void onItemClickListener(View view, int position);
    }

    public void setOnRecyclerViewItemListener(OnRecyclerViewItemListener listener) {
        mOnRecyclerViewItemListener = listener;
    }

    public ManageShareAdapter(Context mContext, List<String> mShareList) {
        this.context = mContext;
        this.shareList = mShareList;
        this.inflater = LayoutInflater.from(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.layout_manage_share_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (holder == null) {
            return;
        }
        if (mOnRecyclerViewItemListener != null) {
            itemOnClick(holder);
        }
        String platform = shareList.get(position);
        if(platform.equals(context.getResources().getString(R.string.text_facebook))){
            holder.iv_icon.setBackgroundResource(R.drawable.ic_facebook);
        }else if(platform.equals(context.getResources().getString(R.string.text_whatsapp))){
            holder.iv_icon.setBackgroundResource(R.drawable.ic_whatsapp);
        }else if(platform.equals(context.getResources().getString(R.string.text_twitter))){
            holder.iv_icon.setBackgroundResource(R.drawable.ic_twitter);
        }else if(platform.equals(context.getResources().getString(R.string.text_messenger))){
            holder.iv_icon.setBackgroundResource(R.drawable.ic_message);
        }else if(platform.equals(context.getResources().getString(R.string.text_google))){
            holder.iv_icon.setBackgroundResource(R.drawable.ic_googleplus);
        }
        holder.tv_name.setText(platform);
    }

    @Override
    public int getItemCount() {
        return shareList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_name;
        ImageView iv_icon;

        public ViewHolder(View itemView) {
            super(itemView);
            tv_name = (TextView) itemView.findViewById(R.id.item_share_name);
            iv_icon = (ImageView) itemView.findViewById(R.id.item_share_icon);
        }

    }

    private void itemOnClick(final RecyclerView.ViewHolder holder) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = holder.getLayoutPosition();
                mOnRecyclerViewItemListener.onItemClickListener(holder.itemView, position);
            }
        });
    }
}

package com.afmobi.palmplay.clean.dialog;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import com.afmobi.util.PadUtils;
import com.afmobi.palmplay.clean.FloatingBallManager;
import com.afmobi.palmplay.setting.fragment.DesktopWindowSettingsFragment;
import com.transsion.palmstorecore.util.ChangeAppNameUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.lang.ref.WeakReference;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;
import androidx.appcompat.app.AlertDialog;

/**
 * 悬浮球只在桌面显示 开启权限提示弹框
 *
 * @author xiangfei.wei
 * @date 2017/12/5
 */

public class HomeOnlyOpenDialog extends AlertDialog implements View.OnClickListener {
    WeakReference<Activity> mWeakReferenceActivity;
    private TextView tvDes;
    public HomeOnlyOpenDialog(@NonNull Context context) {
        super(context);
    }

    public HomeOnlyOpenDialog(@NonNull Context context, @StyleRes int themeResId) {
        super(context, themeResId);
    }

    public HomeOnlyOpenDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_open_floatball_home_only);
        /*WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = (int) (DisplayUtil.getScreenWidthPx(getContext()) * 0.9);
        params.height = (int) (DisplayUtil.getScreenHeightPx(getContext()) * 0.54);
        getWindow().setAttributes(params);*/
        findViewById(R.id.iv_close).setOnClickListener(this);
        findViewById(R.id.btn_cancel).setOnClickListener(this);
        findViewById(R.id.btn_authiorise).setOnClickListener(this);
        tvDes = findViewById(R.id.tv_desc);
        tvDes.setText(ChangeAppNameUtil.INSTANCE.changeAppName(getContext(), R.string.home_only_accessibility_dialog_content));

        /*ClientOperationRecordNode node = new ClientOperationRecordNode(ClientOperationRecordNode.TYPE_AUTO_SETUP,
                new ClientOperationRecordNode.OperationShareArgs(PageConstants.Auto_Install_Tips, null, null, null, null, null, null));
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(node);*/
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                dismiss();
                break;

            case R.id.btn_cancel:
                dismiss();
                break;

            case R.id.btn_authiorise:
                openSettingActivity();
                dismiss();
                break;
        }
    }

    public void openSettingActivity() {
        try {
            if (mWeakReferenceActivity != null && mWeakReferenceActivity.get() != null) {
                Activity curActivity = mWeakReferenceActivity.get();
                if (!curActivity.isFinishing() && !curActivity.isDestroyed()) {
                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                    intent.setFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS | Intent.FLAG_ACTIVITY_NO_HISTORY);
                    curActivity.startActivityForResult(intent, DesktopWindowSettingsFragment.REQUEST_CODE_USAGE_ACCESS_SETTINGS);
                    FloatingBallManager.createFloatingPermissionGuide(getContext(), R.string.access_usage, R.string.txt_tip_turn_on);
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    public void showOnActivity(Activity activity) {
        mWeakReferenceActivity = new WeakReference<>(activity);
        show();
    }
    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadDialog(this);
    }

}

package com.afmobi.palmplay.cache.v6_4;

import android.text.TextUtils;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommonInfo;
import com.afmobi.palmplay.model.v6_4.SearchFilterTermModel;
import com.afmobi.palmplay.network.NetworkActions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.log.LogUtils;

import java.lang.reflect.Type;

import androidx.collection.LruCache;

/**
 * Created by HJG on 2017/3/9.
 */

public class SearchFilterCache {


    private static String CACHE_URI = NetworkActions.ACTION_SEARCH_REAL;
    private static String CACHE_URI_OFFLINE = NetworkActions.ACTION_SEARCH_REAL + "offline";

    private static volatile SearchFilterCache mInstance;
    private static byte[] lock = new byte[0];

    private static final int MAX_CACHE_SIZE = 24;

    private LruCache<String, SearchFilterTermModel> mLruCache;


    private SearchFilterCache(){
        mLruCache = new LruCache<>(MAX_CACHE_SIZE);
    }

    public static SearchFilterCache getInstance() {
        if (mInstance == null) {
            synchronized (lock) {
                if (mInstance == null) {
                    mInstance = new SearchFilterCache();
                }
            }
        }
        return mInstance;
    }

    public static void resetInstance() {
        mInstance = null;
    }

    public void initCache(JsonObject jsonObject, String tabType, int detailType, String searchKey, boolean isOffline) {
        if (jsonObject == null || TextUtils.isEmpty(tabType) || TextUtils.isEmpty(searchKey))
            return;

        SearchFilterTermModel tempSearchFilterTermModel = null;

        try {
            if (DetailType.isApp(detailType)) {
                Type type = new TypeToken<SearchFilterTermModel>() {}.getType();

                Gson gson = new Gson();
                tempSearchFilterTermModel = gson.fromJson(jsonObject, type);
            }

        } catch (Exception e){
            LogUtils.e(e);

        } finally {
            // check data
//            if(tempSearchFilterTermModel!=null){
//                if(tempSearchFilterTermModel.item!=null){
//                    if(TextUtils.isEmpty(tempSearchFilterTermModel.item.packageName) && TextUtils.isEmpty(tempSearchFilterTermModel.item.itemID)){
//                        tempSearchFilterTermModel.item = null;
//                    }
//                }
//
//                if((tempSearchFilterTermModel.termList==null || tempSearchFilterTermModel.termList.length <= 0 ) && tempSearchFilterTermModel.item==null){
//                    tempSearchFilterTermModel = null;
//                }
//            }


            mLruCache.put(getCacheKey(tabType, detailType, searchKey, isOffline), tempSearchFilterTermModel);
        }
    }

    public SearchFilterTermModel getDataModel(String tabType, int detailType, String searchKey, boolean isOffline){
        if(mLruCache!=null){
            return mLruCache.get(getCacheKey(tabType, detailType, searchKey, isOffline));
        }

        return null;
    }


    public String getCacheKey(String tabType, int detailType, String searchKey, boolean isOffline) {
        if (!TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(tabType))
            return (!isOffline ? CACHE_URI : CACHE_URI_OFFLINE) + tabType + detailType + searchKey;
        return "";
    }

}

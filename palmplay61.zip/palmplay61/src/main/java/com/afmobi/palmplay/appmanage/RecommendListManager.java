package com.afmobi.palmplay.appmanage;

import android.app.Activity;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkCallBack;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.configs.v6_3.RankStyleType;
import com.afmobi.palmplay.configs.v6_3.RankType;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.main.adapter.HomeRecyclerViewAdapter;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.ResponseBuilder;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.model.v6_3.RankDataModel;
import com.afmobi.palmplay.model.v6_3.RankModel;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.PackageUtil;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.lang.ref.WeakReference;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class RecommendListManager {
    private View converView;
    private RecyclerView recommend_recyle;
    private LinearLayout layout_recommend_change;
    private Activity mActivity;
    private HomeRecyclerViewAdapter mAdapter;
    private String fromPageID;
    private String mItemID = null;
    private boolean isRecommendRequesting = false;
    private boolean isNeedLoad = false;
    private PageParamInfo mPageParamInfo = new PageParamInfo();
    public RecommendRequestListener mRecommendListener;
    private String mScreenPageName = "";
    private String mFeatureName = "";
    private String mFrom = "";

    private TFeedNative mTFeedNative;
    private boolean isFeatureAdFinished = false;
    private CountDownTimer mAdLoadTimer;
    protected static volatile long requestTime;//api接口请求的开始时间
    private MutableLiveData<ResponseBuilder> respBuilderLiveData = new MutableLiveData<>();
    private boolean isAdTimerFinished = false;
    private boolean isFeatureRequestFinished = false;
    public List<TaNativeInfo> updateAdInfos;  //垃圾清理底部广告

    public RecommendListManager(Activity activity, PageParamInfo pageParamInfo,String from,String screenPageName,String featureName) {
        mActivity = activity;
        mPageParamInfo = pageParamInfo;
        mScreenPageName = screenPageName;
        mFeatureName = featureName;
        mFrom = from;
        mRecommendListener = new RecommendRequestListener(this);
    }

    public void findViews(ViewGroup itemView) {
        converView = itemView;
        recommend_recyle = (RecyclerView) converView.findViewById(R.id.recommend_recyle);
        //Recommend Layout
        layout_recommend_change = (LinearLayout) converView.findViewById(R.id.layout_recommend_change);
        layout_recommend_change.setVisibility(View.GONE);
    }

    public void initData(){
        GridLayoutManager gridLayoutManager = new GridLayoutManager(PalmplayApplication.getAppInstance(), 4);
        gridLayoutManager.setSmoothScrollbarEnabled(true);
        gridLayoutManager.setAutoMeasureEnabled(true);
        recommend_recyle.setHasFixedSize(true);
        recommend_recyle.setNestedScrollingEnabled(false);
        recommend_recyle.setLayoutManager(gridLayoutManager);
        fromPageID = mPageParamInfo.getLastPage();
        mAdapter = new HomeRecyclerViewAdapter(mActivity, recommend_recyle, gridLayoutManager, null
                , null, null, fromPageID, mPageParamInfo, false, 0, 0);
        mAdapter.onCreateView();
        mAdapter.setCurScreenPage(mScreenPageName);
        mAdapter.setFeatureName(mFeatureName);
        mAdapter.setFrom(mFrom);
        recommend_recyle.setAdapter(mAdapter);
    }

    public void startLoadRecommend() {
        isFeatureRequestFinished = false;
        requestTime = System.currentTimeMillis();
        startCountDownTimer();
        String serailNum = CommonUtils.generateSerialNum();
        hisavanaSdkUpdateAdLoad(serailNum, 0, 0);

        mItemID = getNeedRecommendAppItemID();
        NetworkClient.getDownloadRecommendList(mItemID, mPageParamInfo, mRecommendListener);
    }

    /**
     * 请求应用升级底部广告数据
     */
    public void hisavanaSdkUpdateAdLoad(String serialNum, int pageIndex, int pageMax) {
        mTFeedNative = HisavanaSdkManager.getInstance().sdkLoad(SceneCode.UP_YM, "", serialNum, pageIndex, pageMax, new HisavanaSdkCallBack() {
            @Override
            public void onError(TaErrorCode adError) {
                //广告获取失败，不插入广告
                onUpdateAdCallback(null);
            }

            @Override
            public void onAdLoaded(List<TaNativeInfo> adInfo) {
                onUpdateAdCallback(adInfo);
            }

            @Override
            public void onAdClicked() {

            }

            @Override
            public void onTimeOut() {

            }

            @Override
            public void onAdCache(List<TaNativeInfo> adInfos) {

            }

            private void onUpdateAdCallback(List<TaNativeInfo> adInfo) {
                stopCountDownTimer();
                isFeatureAdFinished = true;

                //每次获取到新广告先判断上一次广告是否destory
                destorySdkAdInfo();

                if (isFeatureRequestFinished) {
                    if (!isAdTimerFinished) {
                        updateAdInfos = adInfo;
                    } else  {
                        TRAnalysticsUtil.trackEwFilterInfo(SceneCode.UP_YM, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                    }
                }else {
                    updateAdInfos = adInfo;
                }
                if (respBuilderLiveData.getValue() != null) {

                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    onUpdateDataCallback(builder.updateResp);
                }
            }
        });
    }

    private void stopCountDownTimer() {
        if (mAdLoadTimer != null) {
            mAdLoadTimer.cancel();
        }
    }

    public void destorySdkAdInfo() {
        if (updateAdInfos != null && !updateAdInfos.isEmpty()) {
            for (TaNativeInfo nativeInfo : updateAdInfos) {
                if (nativeInfo != null) {
                    nativeInfo.destroy();
                }
            }
            updateAdInfos.clear();
        }
        if (mTFeedNative != null) {
            mTFeedNative.destroy();
        }
    }

    public String getNeedRecommendAppItemID() {
        mItemID = null;
        List<FileDownloadInfo> list = DownloadManager.getInstance().getShadowDownloadingInfoList();
        if (list != null && list.size() > 0) {
            for (int i = list.size() - 1; i >= 0; i--) {
                FileDownloadInfo item = list.get(i);
                if (item != null && DetailType.isApp(item.type) && !TextUtils.isEmpty(item.itemID)) {
                    mItemID = new String(item.itemID);
                    return mItemID;
                }
            }
        }

        list = DownloadManager.getInstance().getShadowDownloadedInfoList();
        if (list != null && list.size() > 0) {
            for (int i = list.size() - 1; i >= 0; i--) {
                FileDownloadInfo item = list.get(i);
                if (item == null || item.isDeletedTag == 1)
                    continue;

                int status = DownloadStatusManager.getInstance().getObserverStatus(item, FileDownloadInfo.STATUS_DOWNLOADED);
                if (DetailType.isApp(item.type)) {
                    if (item.downloadStatus != FileDownloadInfo.STATUS_APP_INSTALLED && status != FileDownloadInfo.STATUS_APP_INSTALLED
                    && !TextUtils.isEmpty(item.itemID)) {
                        mItemID = new String(item.itemID);
                        return mItemID;
                    }
                }
            }
        }

        return mItemID;
    }

    public void initRecommenList(List<RankDataListItem> listVideoItem) {

        int MAX_H_LINE_COUNT = 4;
        List<RankModel> temp_list = new ArrayList<RankModel>();
        RankModel rankModel = new RankModel();
        rankModel.rankType = "LIST";
        RankDataModel rankDataModel = new RankDataModel();
        rankDataModel.style = RankStyleType.H_RECOMMEND_TITLE;
        rankDataModel.itemType = "SOFT";
        rankDataModel.name = "";
        rankDataModel.rankID = "-11";
        rankDataModel.itemList = listVideoItem;
        rankModel.rankData = rankDataModel;
        temp_list.add(rankModel);

        List<RankModel> list = new ArrayList<>();

        for (RankModel mRankModel : temp_list) {

            if (mRankModel == null || TextUtils.isEmpty(mRankModel.rankType))
                continue;

            if (mRankModel.rankType.equals(RankType.LIST)) {
                if (mRankModel.rankData == null
                        || TextUtils.isEmpty(mRankModel.rankData.style)
                        || TextUtils.isEmpty(mRankModel.rankData.itemType)
                        || mRankModel.rankData.sizeItemList() <= 0) {
                    continue;
                }

                int size = mRankModel.rankData.sizeItemList();
                //4的整数倍
                int minus_count = size % MAX_H_LINE_COUNT;
                if (mRankModel.rankData.style.equals(RankStyleType.H_RECOMMEND_TITLE)) {
                    for (int i = 0; i < size - minus_count; i++) {
                        RankModel newRankModel = mRankModel.copy();
                        newRankModel.rankData.itemList.clear();
                        newRankModel.rankData.itemList.add(mRankModel.rankData.itemList.get(i));
                        list.add(newRankModel);
                    }
                }
            }
        }

        if (list != null && converView != null && mAdapter != null) {
            int listSize = list.size();
            converView.setVisibility((listSize > 0) ? (View.VISIBLE) : (View.GONE));
            if (listSize > 0) {
                List<TaNativeInfo> adInfo = updateAdInfos;
                if (adInfo != null) {
                    int size = adInfo.size();
                    for (int i = 0; i < size; i++) {
                        TaNativeInfo taNativeInfo = adInfo.get(i);
                        if (!taNativeInfo.isIconType()) {
                            //continue
                        } else {
                            //icon类广告
                            RankDataListItem appinfo = null;
                            try {
                                appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), RankDataListItem.class);
                                if(appinfo != null) {
                                    appinfo.tNativeInfo = taNativeInfo;
                                    appinfo.nativeId = taNativeInfo.getNativeAdId();
                                    appinfo.adPositionId = taNativeInfo.getPlacementId();
                                    appinfo.reportSource = HisavanaSdkManager.REPORT_SOURCE_EW;
                                }
                            } catch (GsonUtil.GsonParseException e) {
                                if (BuildConfig.DEBUG) e.printStackTrace();
                            }

                            if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName))) {

                                int col = taNativeInfo.getTopicColumn();
                                if (col >= (listSize - 1)) {
                                    col = (listSize - 1);
                                }

                                int row = taNativeInfo.getTopicRow();

                                filterEWData(list, appinfo);
                                if (PackageUtil.isInstalled(appinfo.isVa, appinfo.packageName)) {
                                    //如果ew广告已安装过滤，则记录下来位置 （场景码 + 行）作为唯一键
                                    HisavanaSdkManager.getInstance().saveInstalledPosition(SceneCode.UP_YM, row, col);

                                    TRAnalysticsUtil.trackEwFilterInstalled(SceneCode.UP_YM, TRAnalyticsConstant.ERROR_MSG_INSTALLED,appinfo.packageName);
                                    LogUtils.d("HisavanaSdk add ad for feature failed, because the app:" + appinfo.packageName + ", is installed.");
                                } else {
                                    //获取已安装过滤的广告位置，并把当前广告位置前移
                                    int installedPosition = HisavanaSdkManager.getInstance().getInstalledPosition(SceneCode.UP_YM + row, row, col);
                                    if (installedPosition > 0) {
                                        col = installedPosition;
                                    }

                                    List<RankDataListItem> adlist = new ArrayList<RankDataListItem>();
                                    adlist.add(appinfo);
                                    RankModel rankModelInfo = new RankModel();
                                    rankModelInfo.rankType = "LIST";
                                    RankDataModel rankDataModelInfo = new RankDataModel();
                                    rankDataModelInfo.style = RankStyleType.H_RECOMMEND_TITLE;
                                    rankDataModelInfo.itemType = "SOFT";
                                    rankDataModelInfo.name = "";
                                    rankDataModelInfo.rankID = "-11";
                                    rankDataModelInfo.itemList = adlist;
                                    rankModelInfo.rankData = rankDataModelInfo;
                                    if (col >= listSize) {
                                        list.remove(col - 1);
                                    }

                                    list.add(col, rankModelInfo);

                                    TRAnalysticsUtil.trackAddShowQueue(taNativeInfo.getPlacementId(), SceneCode.UP_YM,
                                            HisavanaSdkManager.TRACK_LOAD_ADS_ADD_QUEUE, appinfo.packageName, taNativeInfo.getTopicRow(), col);
                                }
                            }
                        }
                    }
                }
                mAdapter.setData(list, null, false, true);
            }
        }
    }

    public void setPageParamInfo(PageParamInfo pageParamInfo) {
        if (mAdapter != null) {
            mAdapter.setPageParamInfo(pageParamInfo);
        }
    }

    public void bind() {
        if (mAdapter != null) {
            int itemCount = mAdapter.getItemCount();
            if (converView != null && itemCount > 0) {
                converView.setVisibility((mAdapter.getItemCount() > 0) ? (View.VISIBLE) : (View.GONE));
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    public void onRecommendCallback(List<RankDataListItem> listRankDataListItem) {

        if(layout_recommend_change != null) {
            layout_recommend_change.setClickable(!(isRecommendRequesting = false));
        }

        if (listRankDataListItem != null && listRankDataListItem.size() > 0) {
            initRecommenList(listRankDataListItem);
        }
    }

    public void destory() {
        if(mRecommendListener != null) {
            mRecommendListener = null;
        }
        if (mAdapter != null) {
            mAdapter.onDestroy();
        }
    }

    static class RecommendRequestListener implements StringRequestListener {

        WeakReference<RecommendListManager> mWeakRef;
        public RecommendRequestListener(RecommendListManager recommendListManager) {
            mWeakRef = new WeakReference<>(recommendListManager);
        }
        @Override
        public void onResponse(String response) {
            try {
                if (TextUtils.isEmpty(response)) {
                    return;
                }
                JsonObject jsonObject = (JsonObject) new JsonParser().parse(response);
                if (!jsonObject.has("itemList")) {
                    return;
                }

                if(mWeakRef != null && mWeakRef.get() != null) {
                    mWeakRef.get().onUpdateDataPreCallback(response);
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        @Override
        public void onError(ANError anError) {

        }
    }

    private void onUpdateDataPreCallback(String response) {
        isFeatureRequestFinished = true;
        long interval = System.currentTimeMillis() - requestTime;
        if (interval <= HisavanaSdkManager.SDK_LOAD_TIMEOUT) {
            if (isFeatureAdFinished) {
                stopCountDownTimer();
            }else {
                ResponseBuilder builder = new ResponseBuilder()
                        .setUpdateResp(response);
                respBuilderLiveData.setValue(builder);
                return;
            }
        }else { //大于300ms
            destorySdkAdInfo();
            if (!isFeatureAdFinished) {
                TRAnalysticsUtil.trackEwFilterInfo(SceneCode.UP_YM, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                destorySdkAdInfo();
            }
        }

        onUpdateDataCallback(response);
    }

    private void onUpdateDataCallback(String response) {
        if (TextUtils.isEmpty(response)) {
            return;
        }
        JsonObject jsonObject = (JsonObject) new JsonParser().parse(response);
        if (!jsonObject.has("itemList")) {
            return;
        }
        JsonElement listJson = jsonObject.get("itemList");
        List<RankDataListItem> listRankDataListItem = null;
        Type type = new TypeToken<List<RankDataListItem>>() {
        }.getType();
        listRankDataListItem = new Gson().fromJson(listJson, type);
        onRecommendCallback(listRankDataListItem);

        respBuilderLiveData.setValue(null);
        isAdTimerFinished = false;
    }

    /**
     * ew数据和返回列表数据比较， 如果包名一致，去除本地列表返回项
     * @param data
     */
    public void filterEWData(List<RankModel> itemList, RankDataListItem data) {
        if (itemList == null) {
            return;
        }
        if(itemList == null || itemList.isEmpty()) {
            return;
        }

        if (data == null || TextUtils.isEmpty(data.packageName)) {
            return;
        }

        if (PackageUtil.isInstalled(data.isVa, data.packageName)) {
            return;
        }

        try {
            HisavanaSdkManager.getInstance().filterValidateAdByRankDataListItem(itemList, data.packageName);
        }catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

    }

    private void startCountDownTimer() {
        isAdTimerFinished = false;
        if (mAdLoadTimer == null) {
            mAdLoadTimer = new CountDownTimer(HisavanaSdkManager.SDK_LOAD_TIMEOUT, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    isAdTimerFinished = true;
                    if (isFeatureRequestFinished) {
                        destorySdkAdInfo();
                    }

                    if (!isFeatureAdFinished && respBuilderLiveData.getValue() != null) {
                        TRAnalysticsUtil.trackEwFilterInfo(SceneCode.UP_YM, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                        ResponseBuilder builder = respBuilderLiveData.getValue();
                        onUpdateDataCallback(builder.updateResp);
                    }
                }
            };
        }else {
            mAdLoadTimer.cancel();
        }

        mAdLoadTimer.start();
    }
}

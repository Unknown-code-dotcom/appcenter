package com.afmobi.palmplay.activate

import android.app.Activity
import android.text.TextUtils
import android.view.View
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.dialog.TRDialogUtil
import com.afmobi.palmplay.main.dialog.TipNetworkDialog
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil
import com.transsion.palmstorecore.BuildConfig.DEBUG

class TRTipNetworkExecutor : TRBaseExecutor<Any?>() {

    var tipNetworkDialog: TipNetworkDialog? = null
    var from: String? = null
    override fun isCanShow(fromType: String): Boolean {
        return TRDialogUtil.noNetTipDialogCanShow()
    }

    override fun show(fromType: String,  from: String?, activity: Activity?): Boolean {
        if(activity == null || activity.isFinishing || activity.isDestroyed) {
            return false
        }
        if(TipNetworkDialog.getDialog(activity).isShow) {
            return false
        }

        if (!isCanShow(fromType) || com.afmobi.util.NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) { //真正show的时候判断是否已有弹框先于自己展现了。
            return false
        }

        if(UINetworkErrorUtil.create().visibility == View.VISIBLE) {
            return false
        }

        try {
            if(tipNetworkDialog?.isShow == true) {
                tipNetworkDialog?.dismiss()
            }
            tipNetworkDialog = TipNetworkDialog()
            if(!TextUtils.isEmpty(from)) {
                tipNetworkDialog?.setFrom(from)
            }
            tipNetworkDialog?.showDialogWithPop(activity)
        }catch (e: Exception) {
            if(DEBUG) {
                e.printStackTrace()
            }
        }



        return true
    }

    override fun dismiss(): Boolean {
        if(isShowing) {
            tipNetworkDialog?.dismiss()
            TRNewManager.instance.resetShowStatus()
        }
        return true
    }

    override fun isShowing(): Boolean {
        return (tipNetworkDialog != null && tipNetworkDialog!!.isShow)
    }


}

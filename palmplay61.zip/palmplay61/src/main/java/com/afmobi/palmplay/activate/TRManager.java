package com.afmobi.palmplay.activate;

import android.content.Intent;

import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.activate.state.TRPopUpScene;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.language.LanguageSelectActivity;
import com.afmobi.palmplay.model.v6_5.MarketEventInfo;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.recommendinstall.TRInstallManager;
import com.afmobi.palmplay.switchcountry.SwitchCountryManager;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.util.CommonUtils;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.LanguageSelectManager;
import com.transsion.palmstorecore.util.TRStringUtil;

import java.util.ArrayList;
import java.util.List;


/***
 * created by yongli.li
 * 所有活动的api入口。 业务管理的大boss
 * 不干实事，只会下发命令，任命下属去干
 */
public class TRManager {
    private volatile static TRManager instance;
    private TRBaseExecutor navActivateExecutor;//底部tab活动的执行者
    private TRBaseExecutor tipActivateExecutor;//四种活动的执行者
    private TRBaseExecutor splashExecutor;//开屏广告的执行者
    private TRBaseExecutor updateVersionExecutor;//升级执行者
    private TRBaseExecutor recomInstallExecutor;//一键安装执行者

    private TRBaseExecutor guideWidgetExecutor; // widget
    private TRBaseExecutor mustInstallExecutor;//装机必备执行者
    private TRBaseExecutor mNotificatoinToggleExecutor;//引导打开tools开关弹框
    private TRBaseExecutor mDiskSpaceLimitExecutor;//空间不足执行者
    private TRBaseExecutor mFileFolderExecutor;//云文件夹的执行者

    private TRManagerDispatcher activateManagerDispatcher;//manager调度者
    private int showStatus = TRActivateConstant.NEED_SHOW;
    private volatile static boolean isInited = false;
    private List<TRBaseExecutor> mSequenceExecutorList = new ArrayList<>();
    private boolean isNeedDisplay = true;

    public static TRManager getInstance() {
      if (instance == null) {
          synchronized (TRManager.class) {
              if (instance == null) {
                  instance = new TRManager();
              }
          }
      }
      return instance;
    }

    public void resetShowStatus(){
        showStatus = TRActivateConstant.NEED_SHOW;
        isNeedDisplay = true;
//        resetTipsShowData();
    }

    public void resetTipsShowData(){
        getTipExecutor().clearNeedShowData();
    }

    /***
     * 初始化活动的管理者
     */
    public void init() {
        if (isInited) {
            return;
        }
        TRNewManager.Companion.getInstance().initNewPop();
        if (activateManagerDispatcher == null) {
            activateManagerDispatcher = new TRManagerDispatcher();
        }
        if(!TRNewManager.Companion.getInstance().isNewPopEnable()) {
            if (navActivateExecutor == null) {
                navActivateExecutor = new TRNavActivateExecutor();
            }
            if (tipActivateExecutor == null) {
                tipActivateExecutor = new TRTipActivateExecutor();
            }
            if (splashExecutor == null) {
                splashExecutor = new TRSplashActivateExecutor();
            }
            if (updateVersionExecutor == null) {
                updateVersionExecutor = new TRUpdateVersionExecutor();
            }
            if (recomInstallExecutor == null) {
                recomInstallExecutor = new TRRecomInstallExecutor();
            }
            if (mustInstallExecutor == null) {
                mustInstallExecutor = new TRMustInstallExecutor();
            }

            if (guideWidgetExecutor == null) {
                guideWidgetExecutor = new TRWidgetGuideExecutor();
            }
            if (mNotificatoinToggleExecutor == null) {
                mNotificatoinToggleExecutor = new TRNotificationToggleExecutor();
            }
            if (mDiskSpaceLimitExecutor == null) {
                mDiskSpaceLimitExecutor = new TRDiskSpaceLimitExecutor();
            }
            if (AppDataManager.FEATURE_FILE_FOLDER_SWITCH) {
                if (mFileFolderExecutor == null) {
                    mFileFolderExecutor = new TRFileFolderPermissionExecutor();
                }
                //P0功能初始授权-云文件夹授权
                mSequenceExecutorList.add(mFileFolderExecutor);
            }

            //p0优先级的执行者满足展示，则调起自己的方法展示
            mSequenceExecutorList.add(updateVersionExecutor);
            //p1优先级的执行者满足展示的条件
            mSequenceExecutorList.add(recomInstallExecutor);
            //p1优先级的执行者满足展示的条件，装机必备低于一键安装
            mSequenceExecutorList.add(mustInstallExecutor);
            //widget引导
            mSequenceExecutorList.add(guideWidgetExecutor);
            //p2优先级的执行者满足展示的条件
            // mSequenceExecutorList.add(mGiftRainExecutor);
            mSequenceExecutorList.add(tipActivateExecutor);
        }else{
            TRNewManager.Companion.getInstance().ensureInitialized();
            navActivateExecutor = TRNewManager.Companion.getInstance().getExecutor(TRPopUpScene.POP_UP_NAV_ACTIVATE);
            tipActivateExecutor = TRNewManager.Companion.getInstance().getExecutor(TRPopUpScene.POP_UP_TIP_ACTIVATE);
            splashExecutor = TRNewManager.Companion.getInstance().getExecutor(TRPopUpScene.POP_UP_SPLASH_ACTIVATE);
        }
        isInited = true;
    }

    /***
     * 开放一个接口，如果有些场景想直接再捞取数据，比如有些业务应用起来就想直接取捞取数据
     * 数据捞取实际是异步的
     * @param types
     */
    public void loadDataDirectly(String[] types) {
        if (types == null || types.length <= 0) {
            return;
        }
        for (int i = 0; i < types.length; i++) {
            String type = types[i];
            if (TRStringUtil.isBlank(type)) {
                continue;
            }
            switch (type) {
                case TRActivateConstant.TIP_ACTIVATE:
                    if (tipActivateExecutor != null) {
                        tipActivateExecutor.loadData();
                    }
                    break;
                case TRActivateConstant.NAV_BAR_ACTIVATE:
                    if (navActivateExecutor != null) {
                        navActivateExecutor.loadData();
                    }
                    break;
                case TRActivateConstant.SPLASH_AD:
                    if (splashExecutor != null) {
                        splashExecutor.loadData();
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 获取数据，执行者内部会根据二级缓存的优先获取
     * 获取一级活动下的所有活动数据
     * @param activateType
     * @return
     */
    public Object getActivateData(String activateType) {
        switch (activateType) {
            case TRActivateConstant.NAV_BAR_ACTIVATE:
                if (navActivateExecutor != null) {
                    return navActivateExecutor.getData();
                }
            case TRActivateConstant.TIP_ACTIVATE:
                if (tipActivateExecutor != null) {
                    return tipActivateExecutor.getActivateData();
                }
            default:
                return null;
        }
    }

    /**
     * 获取数据，执行者内部会根据二级缓存的优先获取
     * 暴漏更多接口，可以直接获取单个活动的一条子活动数据
     * @param activateType
     * @return
     */
    public Object getSubActivateData(String activateType, String subActivateType) {
        if (TRStringUtil.isBlank(activateType)) {
            return null;
        }
        switch (activateType) {
            case TRActivateConstant.NAV_BAR_ACTIVATE://此种活动没有子活动
                if (navActivateExecutor != null) {
                    return navActivateExecutor.getSubActivateData(subActivateType);
                }
            case TRActivateConstant.TIP_ACTIVATE:
                if (tipActivateExecutor != null) {
                    return tipActivateExecutor.getSubActivateData(subActivateType);
                }
            default:
                return null;
        }
    }

    /***
     * 点击的时间分发，根据不同的类别和跳转类别处理事件
     * @param type
     * @param o
     */
    public void dispatchEvent(String type, Object o) {
        if (activateManagerDispatcher != null) {
            activateManagerDispatcher.dispatchEvent(type, o);
        }
    }

    /***
     * 弹框互斥展现的规则
     * @param fromType 不同得触发入口
     */
    public void show(String fromType) {
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {      // todo 国家切换弹框也加进来
            return;
        }

        if(TRNewManager.Companion.getInstance().isNewPopEnable()) {
            TRNewManager.Companion.getInstance().show(fromType);
            return;
        }

        if (!isInited) {//当show方法比init先走时，再判断一下，作下保护
            init();
        }
        if (showStatus == TRActivateConstant.NEED_SHOW) {//试用场景：假设home键得时候，弹框正在起还未起来得时候，各自得显示status还未设置，showstatus得值被改成了0，
            //home键再次回来时候弹框出现，如果不再去判断下当前有没有弹框得话，可能会在一时间出现弹框覆盖。
            if (TRDialogUtil.hasDialogShowing()) {
                showStatus = TRActivateConstant.SHOWED;
            }
        }

        String sence = null;
        String reason = null;
        for(TRBaseExecutor executor : mSequenceExecutorList){
             if(executor instanceof TRTipActivateExecutor) {
                sence = "TipActivate";
                if(executor.isPromptTip() && showStatus == TRActivateConstant.SHOWED && isNeedDisplay) {
                    executor.showOthers();
                    reason = "TipActivate others show called";
                }else {
                    if (executor.isCanShow(fromType)) {
                        showStatus = TRActivateConstant.SHOWED;//内部展现失败得时候会把值恢复，避免浪费一次机会
                        if (executor.show(fromType)) {
                            isNeedDisplay = false;
                            reason = "TipActivate show called";
                            break;
                        } else {
                            showStatus = TRActivateConstant.NEED_SHOW;
                        }
                    }

                }
            }else {
                if(executor instanceof TRUpdateVersionExecutor) {
                    sence = "AppUpdate";
                } else if(executor instanceof TRRecomInstallExecutor) {
                    sence = "RecommondInstall";
                } else if (executor instanceof TRMustInstallExecutor) {
                    sence = "MustInstall";
                } else if (executor instanceof TRFileFolderPermissionExecutor) {
                    sence = "FileFolder";
                }

                if (showStatus == TRActivateConstant.SHOWED) {//如果本次活跃已经显示过或者有正在显示得，则直接return
                    reason = "It is already showed and return";
                    continue;
                }

                if (executor.isCanShow(fromType)) {
                    showStatus = TRActivateConstant.SHOWED;//内部展现失败得时候会把值恢复，避免浪费一次机会
                    if (executor.show(fromType)) {
                        reason = sence + " show called";
                        break;
                    } else {
                        showStatus = TRActivateConstant.NEED_SHOW;
                    }
                }
            }
        }

        TRAnalysticsUtil.trackPopSenceInfo(reason, fromType, sence);
    }

    /***
     * 从callback回来的show显示
     * @param type 不同的业务callback
     * @param fromType 不同得触发入口
     */
    public boolean callbackShow(int type, String fromType) {

        if(TRNewManager.Companion.getInstance().canShow()) {
            return TRNewManager.Companion.getInstance().callbackShow(type, fromType);
        }

        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false;
        }
        if(CommonUtils.isBlockAllPopUps()){
            return false;
        }

        if(type == TRActivateConstant.FROM_MUST_INSTALL) {
            if (TRMustInstallExecutor.getMustInstallExclude()){
                TRInstallManager.trackCommonInstall(TRAnalyticsConstant.SHOW_TYPE, -1,
                        "14", 4, 0, null, "", "", "", "", "", "", "", fromType);    // 新增埋点
                return false;    //新增，被拦截
            }
        }

        if(type == TRActivateConstant.FROM_RECOM_INSTALL) {
            if (TRRecomInstallExecutor.getMustInstallExclude()){
                TRInstallManager.trackCommonInstall(TRAnalyticsConstant.SHOW_TYPE, -1,
                        "14", 4, 0, null, "", "", "", "", "", "", "", fromType);    // 新增埋点
                return false;    //新增，被拦截
            }
        }

        if (type == TRActivateConstant.FROM_SPACE_LIMIT) {
            if(mDiskSpaceLimitExecutor != null && mDiskSpaceLimitExecutor.isCanShow(fromType)){
                LogUtils.d("Disk space limit activity is called, will prepare showing, value:" + fromType);
                return mDiskSpaceLimitExecutor.show(fromType);
            }
            return false;
        }

        if (showStatus == TRActivateConstant.SHOWED || TRDialogUtil.hasDialogShowing()) {
            return false;
        }
        TRBaseExecutor executor = null;
        switch (type) {
            case TRActivateConstant.FROM_UPDATE:
                executor = updateVersionExecutor;
                break;
            case TRActivateConstant.FROM_MUST_INSTALL:
                executor = mustInstallExecutor;
                break;
            case TRActivateConstant.FROM_RECOM_INSTALL:
                executor = recomInstallExecutor;
                break;
            case TRActivateConstant.FROM_ACTIVATE:
                executor = tipActivateExecutor;
                break;
            case TRActivateConstant.FROM_FILE_FOLDER:
                executor = mFileFolderExecutor;
                break;
            case TRActivateConstant.FROM_NOTIFICATION_TOGGLE:
                executor = mNotificatoinToggleExecutor;
                break;
            case TRActivateConstant.FROM_SPLASH_AD:
                executor = splashExecutor;
                break;
            case TRActivateConstant.FROM_WIDGET:
                executor = guideWidgetExecutor;
                break;
            default:
                break;
        }
        if(executor != null && executor.isCanShow(fromType)){
            showStatus = TRActivateConstant.SHOWED;
            if(!executor.show(fromType)){
                showStatus = TRActivateConstant.NEED_SHOW;
                return false;
            }
        }else {
            return false;
        }
        return true;
    }

    /**
     * 获取数据，执行者内部会根据二级缓存的优先获取
     * 暴漏更多接口，可以直接获取单个活动的一条子活动数据
     * @param activateType
     * @return
     */
    public void updateTipAfterShow(MarketEventInfo item, boolean isPreload, String activateType) {
        if (TRStringUtil.isBlank(activateType)) {
            return;
        }
        switch (activateType) {
            case TRActivateConstant.NAV_BAR_ACTIVATE://此种活动没有子活动
                if (navActivateExecutor != null) {
                    navActivateExecutor.updateTipAfterShow(item, false);
                }
                break;
            case TRActivateConstant.TIP_ACTIVATE:
                if (tipActivateExecutor != null) {
                    tipActivateExecutor.updateTipAfterShow(item, false);
                }
                break;
            default:
                break;
        }
    }

    public void onClear(){
        if(tipActivateExecutor != null) {
            tipActivateExecutor.onClear();
        }
    }

    public TRTipActivateExecutor getTipExecutor() {
        return (TRTipActivateExecutor)tipActivateExecutor;
    }

}

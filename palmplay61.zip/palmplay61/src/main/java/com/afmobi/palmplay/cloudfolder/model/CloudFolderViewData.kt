package com.afmobi.palmplay.cloudfolder.model

import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import java.io.Serializable

/**
 * 页面整体状态
 */
data class CloudFolderViewData(
    val layoutStyle: Int,
    val fixRankTile: Boolean = false, // 是否顶部榜单固定（不随列表滚动）
    val showFixedBottom: Boolean = false,
    val fixedBottomList: List<CloudAppInfo> = emptyList(), // 底部固定推荐列表
    val scrollableItems: List<BaseFolderUiModel> = emptyList() // 主滚动区域数据流
) : Serializable

/**
 * 主滚动区条目抽象基类
 */
sealed class BaseFolderUiModel(val viewType: Int) : Serializable {
    companion object {
        const val TYPE_NORMAL_APP = 1    // 普通应用
        const val TYPE_RANK_APP = 2      // 普通榜单应用
        // 榜单皇冠（section header + 内部 3 个皇冠子项统一标记，由 FixedRankSectionView 渲染）
        const val TYPE_RANK_SECTION = 3
    }
}

/**
 * 普通应用条目
 */
data class NormalAppUiModel(val appInfo: CloudAppInfo) : BaseFolderUiModel(TYPE_NORMAL_APP)

/**
 * 榜单应用条目
 */
data class RankAppUiModel(val appInfo: CloudAppInfo) : BaseFolderUiModel(TYPE_RANK_APP)

/**
 * 榜单标题条目（带皇冠/排名标识的应用）
 */
data class RankTitleUiModel(val title: String, val appInfo: CloudAppInfo) : BaseFolderUiModel(TYPE_RANK_SECTION)

package com.afmobi.palmplay.alonefuction;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;

import com.afmobi.palmplay.activate.TRUpdateVersionExecutor;
import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.base.BaseUpgradeActivity;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.util.Constant;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsnet.store.R;

import java.io.File;

public class ForceUpgradeActivity extends BaseUpgradeActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		TRUpdateVersionExecutor.STATUS = true;
		String newVer = mClientVersion == null ? "" : mClientVersion.versionName;
		String upgradeFashion = mClientVersion == null ? "" : mClientVersion.upgradeFashion;
		String id = mClientVersion == null ? "" : mClientVersion.id;
		int versionCode = mClientVersion == null ? -100 : mClientVersion.versionCode;
		TRAnalysticsUtil.trackSelftUpdateShow(-1,newVer, upgradeFashion, id, versionCode);
	}

	@Override
	protected int getDefaultUpdateMessage() {
		return R.string.text_force_upgrade_content;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			AtyManager.getAtyManager().clear();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		String upgradeFashion = mClientVersion == null ? "" : mClientVersion.upgradeFashion;
		String id = mClientVersion == null ? "" : mClientVersion.id;
		int versionCode = mClientVersion == null ? -100 : mClientVersion.versionCode;
		switch (v.getId()) {
			case R.id.tv_cancel:
				TRAnalysticsUtil.trackSelfUpdateClick(5, mNewVerStr, upgradeFashion, id, versionCode);
				AtyManager.getAtyManager().clear();
				finish();
				break;
			case R.id.tv_ok:
				String newVersionFilePath = FilePathManager.myselfNewVersionFilePath();
				File newVersionFile = new File(newVersionFilePath);
				if (!newVersionFile.exists()) {
					SPManager.remove(Constant.preferences_key_downloaded_version_code);
				}
				startUpgrading(TRAnalyticsConstant.FROMPAGE_CLICK);
				TRAnalysticsUtil.trackSelfUpdateClick(1, mNewVerStr, upgradeFashion, id, versionCode);
				break;
			default:
				break;
		}
	}

	@Override
	protected boolean isForceUpdate() {
		return true;
	}


	@Override
	public void finish() {
		super.finish();
		TRUpdateVersionExecutor.STATUS = false;

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		TRUpdateVersionExecutor.STATUS = false;
		TRNewManager.getCloseListener().onDialogClosed();
	}
}
package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.manager.HttpRequestTracerManager;
import com.afmobi.palmplay.model.FeatureSinglePageData;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.RankBean;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.Constant;
import com.afmobi.util.NetworkUtils;
import com.androidnetworking.error.ANError;
import com.transsion.palmstorecore.analytics.AppDistributionTimeManager;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import androidx.collection.LruCache;

public class FeatureSinglePageCache {

    private static volatile FeatureSinglePageCache mInstance = null;
    private static byte[] lock = new byte[0];

    private static final int MAX_CACHE_SIZE = 5;
    public final static int FEATURE_PAGE_MAX = 10;
    private final static int RETRY_TIMES_MAX = 1; //重试次数

    private LruCache<String, FeatureSinglePageData> mFeaturePageCache;

    private List<RankBean> mRankIdList;

    public static FeatureSinglePageCache getInstance() {
        if (mInstance == null) {
            synchronized (lock) {
                if (mInstance == null) {
                    mInstance = new FeatureSinglePageCache();
                }
            }
        }

        return mInstance;
    }

    public FeatureSinglePageCache() {
        this.mFeaturePageCache = new LruCache<>(MAX_CACHE_SIZE);
        this.mRankIdList = new ArrayList<>();


    }

    public void initCache(FeatureSinglePageData data, String rankID, int pageIndex) {

        if(data == null || TextUtils.isEmpty(rankID)) {
            return;
        }

        try {
            if (pageIndex == 0) {
                PsCommonCache.getInstance().saveToDoubleCache(rankID, data, FeatureSinglePageData.class);
            }
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }



    /**
     * 根据rankId获取对应的缓存数据
     *
     * @param rankId   专题id
     * @return
     * */
    public FeatureSinglePageData getFeatureSinglePageDataByRankId(String rankId) {
        if(TextUtils.isEmpty(rankId)) {
            return null;
        }

//        if(mFeaturePageCache == null) {
//            return null;
//        }

        return PsCommonCache.getInstance().loadFromCache(rankId, FeatureSinglePageData.class);
    }


    /**
     * 保存需要预加载的专题id
     * */
    public void addPreLoadRankId(FeaturedModel featuredModel) {

        LogUtils.d("begin add rankId who is not cached to [mRankIdList] for cache.");
        if(featuredModel == null || featuredModel.featureList == null || featuredModel.featureList.isEmpty()) {
            return;
        }

        for (FeatureBean featureBean : featuredModel.featureList) {
            String rankId = featureBean.getId();
            if(!TextUtils.isEmpty(rankId) && featureBean.isNeedPreloadRank()) {
                FeatureSinglePageData data = getFeatureSinglePageDataByRankId(rankId);
                if(data != null) { //已缓存的无需再次预加载
                    continue;
                }

                if (!isContainsRankId(rankId)) {
                    RankBean rankBean = new RankBean();
                    rankBean.rankId = rankId;
                    rankBean.retryTimes = 0;
                    mRankIdList.add(rankBean);
                }
            }
        }

        preLoadFeatureSinglePage();
    }


    /**
     * 是否包含指定专题
     * */
    private boolean isContainsRankId(String rankId) {
        if(TextUtils.isEmpty(rankId)) {
            return false;
        }

        Iterator<RankBean> it = mRankIdList.iterator();
        while (it.hasNext()) {
            RankBean item = it.next();
            if(!TextUtils.isEmpty(item.rankId) && TextUtils.equals(item.rankId, rankId)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 删除指定的id的专题
     *
     * @param id             专题id
     * @param isForceDelete  是否直接删除，true:直接删除,  false:超过重试次数删除
     * */
    private void removeRankId(String id, boolean isForceDelete) {
        if (mRankIdList == null || mRankIdList.isEmpty()) {
            return;
        }

        if(TextUtils.isEmpty(id)) {
            return;
        }

        Iterator<RankBean> it = mRankIdList.iterator();
        while (it.hasNext()) {
            RankBean item = it.next();
            if(item != null && !TextUtils.isEmpty(item.rankId) && TextUtils.equals(item.rankId, id)) {
                if(isForceDelete || item.retryTimes >= RETRY_TIMES_MAX) {
                    it.remove();
                }else {
                    item.retryTimes++;
                }
                break;
            }
        }
    }


    /**
     * 预加载独立专题页
     * */
    public void preLoadFeatureSinglePage() {

        LogUtils.d("begin preload feature single page data.");

        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            return;
        }

        if(mRankIdList == null || mRankIdList.isEmpty()) {
            return;
        }

        Iterator<RankBean> it = mRankIdList.iterator();
        while (it.hasNext()) {
            RankBean item = it.next();
            final String rankId = (item != null) ? item.rankId : null;

            if(TextUtils.isEmpty(rankId)) {
                continue;
            }

            //专题已经存在就不进行预加载
            FeatureSinglePageData rankListData = getFeatureSinglePageDataByRankId(rankId);
            if (rankListData != null) {
                continue;
            }

            final int pageIndex = 0;
            final String tag = rankId;
            NetworkClient.requestFeatureSinglePage(Constant.SOURCE_SCHEDULE, rankId, pageIndex, FEATURE_PAGE_MAX,null, null, tag, new AbsRequestListener<GenericResponseInfo<FeatureSinglePageData>>() {

                @Override
                public void onResponse(GenericResponseInfo<FeatureSinglePageData> response) {
                    super.onResponse(response);

                    if(response != null && response.getData() != null) {
                        FeatureSinglePageData data = response.getData();
                        TRHomeUtil.resetVaStatus4FeatureSinglePageData(data);
                        TRHomeUtil.checkTraceId(data);

                        initCache(data, rankId, pageIndex);

                        boolean ret = (data != null && data.getData() != null && data.getData().size() > 0);
                        removeRankId(rankId, ret);
                    }

                    HttpRequestTracerManager.getInstance().remove(tag);
                }

                @Override
                public void onError(ANError anError) {
                    super.onError(anError);

                    removeRankId(rankId, false);

                    HttpRequestTracerManager.getInstance().remove(tag);
                }
            }, false);
        }
    }



}

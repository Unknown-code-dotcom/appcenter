package com.afmobi.palmplay.activate;

import android.app.Activity;
import android.content.DialogInterface;

import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.main.dialog.UserGuideDialog;
import com.transsnet.store.BuildConfig;

public class TRUserDialogExecutor extends TRBaseExecutor{

    private UserGuideDialog mUserGuideDialog;

    @Override
    public boolean show(String fromType, Activity activity, boolean isShowGuide, DialogInterface.OnDismissListener listener) {
        if(isCanShow(fromType)) {
            if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
                if (mUserGuideDialog != null) {
                    try {
                        mUserGuideDialog.cancel();
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
                try {
                    mUserGuideDialog = new UserGuideDialog(activity, false);
                    isNeedH5TabGuide(isShowGuide);
                    mUserGuideDialog.setDismissListener(listener);
                    mUserGuideDialog.show();
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }

            }
        }
        return false;
    }

    @Override
    public boolean isCanShow(String fromType) {
        return TRNewManager.Companion.getInstance().canShow();
    }

    public void isNeedH5TabGuide(boolean needTabGuide) {
        mUserGuideDialog.isNeedH5TabGuide(needTabGuide);
    }
}

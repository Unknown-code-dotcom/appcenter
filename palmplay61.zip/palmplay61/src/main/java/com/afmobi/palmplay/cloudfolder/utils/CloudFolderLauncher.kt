package com.afmobi.palmplay.cloudfolder.utils

import com.transsion.palmstorecore.util.ToastManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.text.TextUtils
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.AttributionUploadManager
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.util.CommonUtils
import com.transsion.core.log.LogUtils
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.model.FileFolderData
import com.transsnet.store.R


object CloudFolderLauncher {

    fun launchFromOtherType(cloudAppInfo: CloudAppInfo?) : String{
        cloudAppInfo?.apply {
            //点击归因链接上报
            AttributionUploadManager.getInstance().enqueueNewRequest(clickTracking, name)
            if(isLaunchOtherStore()) {
                return launchAppDetail(deeplink, storePkgName, html5Url)
            } else if(isLaunchWeb()) {
                html5Url?.let {
                    return openUrlWithBrowser(it, storePkgName, name)
                }
            }
        }
        return ""
    }

    fun launchFromOtherType(cloudAppInfo: FileFolderData.DataItem.AppBottomInfo?) : String{
        cloudAppInfo?.apply {
            //点击归因链接上报
            AttributionUploadManager.getInstance().enqueueNewRequest(clickTracking, name)
            if(jumpType == Constants.JUMP_TYPE_STORE) {
                return launchAppDetail(deeplink, storePkgName, html5Url)
            } else if(jumpType == Constants.JUMP_TYPE_WEB) {
                html5Url?.let {
                    return openUrlWithBrowser(it, storePkgName, name)
                }
            }
        }
        return ""
    }

    /**
     * 跳转到指定应用在RuStore的详情页
     * @param context 上下文
     * @param deepLink 指定商店的deepLink
     * @param storePkgName: 指定商店的包名
     */
    private fun launchAppDetail(deepLink: String?, storePkgName: String?, defaultUrl: String?) : String{
        val appInstance = PalmplayApplication.getAppInstance()
        appInstance?.let { context->
            try {
                // 构建RuStore应用内的详情页URI
                val appDetailUri = Uri.parse(deepLink)

                // 创建跳转Intent
                val intent = Intent(Intent.ACTION_VIEW, appDetailUri).apply {
                    // 指定RuStore包名，确保跳转至该应用
                    setPackage(storePkgName)
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                // 检查是否安装了RuStore
                if (context.packageManager.resolveActivity(intent, 0) != null) {
                    // 已安装，直接跳转应用内详情页
                    context.startActivity(intent)
                    //默认方式
                    return "spc"
                } else {
                    // 未安装，跳转至网页版详情页
                    val webUri = Uri.parse(defaultUrl)
                    val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    if (context.packageManager.resolveActivity(webIntent, 0) != null) {
                        context.startActivity(webIntent)
                        //兜底方式
                        return "fbk"
                    } else {
                        return "error1"
                    }
                }
            }catch (e: Exception) {
                LogUtils.e("CloudFolderManager", e)
            }
        }
        return "error2"
    }

    /**
     * 使用指定浏览器打开网页，若不存在则使用默认浏览器
     * @param context 上下文
     * @param url 网页地址
     * @param targetBrowserPackage 指定浏览器的包名
     */
    private fun openUrlWithBrowser(
        url: String,
        targetBrowserPackage: String?,
        name: String
    ) : String
    {
        val appInstance = PalmplayApplication.getAppInstance()
        appInstance?.let { context ->
            try {
                // 验证URL有效性
                if (url.isEmpty() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
                    openFailToast(context, name)
                    return "error1"
                }

                val uri = Uri.parse(url)

                // 尝试使用指定浏览器
                val specificIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(targetBrowserPackage)
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                }


                // 检查指定浏览器是否存在
                if (context.packageManager.resolveActivity(specificIntent, 0) != null) {
                    // 存在则使用指定浏览器打开
                    context.startActivity(specificIntent)
                    return "spc"
                } else {
                    // 不存在则使用默认浏览器
                    val defaultIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                        addCategory(Intent.CATEGORY_BROWSABLE)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    if (context.packageManager.resolveActivity(defaultIntent, 0) != null) {
                        context.startActivity(defaultIntent)
                        return "fbk"
                    } else {
                        openFailToast(context, name)
                        return "error2"
                    }
                }
            } catch (e: Exception) {
                openFailToast(context, name)
            }
        }
        return "error3"
    }

    private fun openFailToast(context : Context, name : String?) {
        var tipsStr: String? = PalmplayApplication.getAppInstance().getResources().getString(R.string.unable_launch)
        tipsStr = CommonUtils.replace(tipsStr, CommonUtils.TARGET_NAME, name)
        ToastManager.getInstance().showS(context, tipsStr)
    }

    fun launchFromPreInstall(cloudAppInfo: CloudAppInfo?) {
        cloudAppInfo?.let { appInfo ->
            val appInstance = PalmplayApplication.getAppInstance()
            try {
                appInfo.launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                appInstance?.startActivity(appInfo.launchIntent)
            }catch (e: Exception) {
                LogUtils.e(e)
            }
        }
    }

    /**
     * 云文件夹「最近安装」拉活：点击拉起目标应用。
     * 优先使用预存的 launchIntent；为空时兜底用 PackageManager 现查一次。
     * 都拿不到则提示无法启动。
     */
    fun launchFromRecentlyInstalled(cloudAppInfo: CloudAppInfo?) {
        val appInfo = cloudAppInfo ?: return
        val appInstance = PalmplayApplication.getAppInstance() ?: return
        val pkg = appInfo.packageName
        try {
            val intent = appInfo.launchIntent
                ?: pkg?.let { appInstance.packageManager.getLaunchIntentForPackage(it) }
            if (intent == null) {
                LogUtils.w("RecentlyInstalled", "【最近安装·点击】pkg=$pkg launchIntent为空，无法启动")
                openFailToast(appInstance, appInfo.name)
                return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appInstance.startActivity(intent)
            LogUtils.i("RecentlyInstalled", "【最近安装·点击】拉起应用 pkg=$pkg")
        } catch (e: Exception) {
            LogUtils.e("RecentlyInstalled", e)
            openFailToast(appInstance, appInfo.name)
        }
    }

    fun launchFromPreinstallItem(
        position: Int,
        appInfo: CloudAppInfo,
        menuStr: String,
        categoryType: Int,
        callback: (() -> Unit)? = null
    ) {
        val appInstance = PalmplayApplication.getAppInstance()
        appInstance?.let {
            val eventName = if(TextUtils.equals(menuStr, it.getString(R.string.string_file_folder_move_app))) {
                //
                CloudFolderManager.getInstance().moveItemToHomeScreen(appInfo, categoryType, callback)
                CloudFolderTrackUtil.BUTTON_TYPE_SEND
            } else if(TextUtils.equals(menuStr, it.getString(R.string.shortcut_pop_appinfo))) {
                openAppInfo(it, appInfo.packageName)
                CloudFolderTrackUtil.BUTTON_TYPE_APP_INFO
            } else {
                ""
            }
            if(eventName.isNotEmpty()) {
                CloudFolderTrackUtil.businessItemClickTrack(
                    position,
                    eventName,
                    appInfo.packageName,
                    categoryType,
                    appInfo.isOffer
                )
            }

        }
    }

    private fun openAppInfo(context: Context, packageName: String?) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", packageName, null)
            intent.setData(uri)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP) // 非 Activity 上下文需加此 flag
            context.startActivity(intent)
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }

}
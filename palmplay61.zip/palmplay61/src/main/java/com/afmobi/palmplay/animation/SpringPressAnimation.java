package com.afmobi.palmplay.animation;

import android.content.res.Resources;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.FloatValueHolder;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;

/**
 * Created by guisheng.wang5 on 2021/7/2.
 */
public class SpringPressAnimation implements View.OnTouchListener {
    private final float mStartValue;
    private final float mEndValue;
    private float mCurrentStartValue;
    private float mCurrentEndValue;
    private final float mStartStiffness, mEndStiffness;
    private final float mDampingRatio;
    private final FloatValueHolder mFloatValueHolder;
    private final float mVelocity;
    private View mView;
    private float mTouchSlop;
    private OnSpringClickListener mClickListener;
    private View.OnTouchListener mOnTouchListener;
    private OnAnimationEndListener mOnAnimationEndListener;
    private OnAnimationUpdateListener mOnAnimationUpdateListener;
    public interface OnSpringClickListener {
        void onClick(View view, boolean isDown);
    }

    private SpringPressAnimation(Builder builder) {


        this.mStartValue = builder.startValue;
        this.mEndValue = builder.finalValue;
        this.mEndStiffness = builder.endStiffness;
        this.mStartStiffness = builder.startStiffness;
        this.mDampingRatio = builder.dampingRatio;
        this.mFloatValueHolder = builder.floatValueHolder;
        this.mVelocity = builder.velocity;
        this.mView = builder.view;
        this.mClickListener = builder.clickListener;
        this.mOnTouchListener = builder.onTouchListener;
        this.mOnAnimationEndListener = builder.onAnimationEndListener;
        this.mOnAnimationUpdateListener = builder.onAnimationUpdateListener;
        if (mView != null) {
            mTouchSlop = dp2px(20);
        }
        this.mCurrentStartValue = this.mStartValue;
        this.mCurrentEndValue = this.mEndValue;
        if (mView != null) {
            mView.setOnTouchListener(this);
        }

    }

    static int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                Resources.getSystem().getDisplayMetrics());
    }

    private SpringAnimation createStartAnimation(float startValue, float endValue) {
        SpringForce springForce = new SpringForce().setStiffness(mStartStiffness)
                .setDampingRatio(mDampingRatio);
        springForce.setFinalPosition(endValue);
        SpringAnimation springAnimation = new SpringAnimation(mFloatValueHolder);
        springAnimation.setSpring(springForce);
        springAnimation.setStartValue(startValue);
        springAnimation.setStartVelocity(mVelocity);
        springAnimation.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);

        springAnimation.addUpdateListener(new DynamicAnimation.OnAnimationUpdateListener() {
            @Override
            public void onAnimationUpdate(DynamicAnimation animation, float value, float velocity) {

                if (mView != null) {
                    mView.setScaleX(value);
                    mView.setScaleY(value);
                }

                if (mOnAnimationUpdateListener != null) {
                    mOnAnimationUpdateListener.onAnimationUpdate(true,animation,value,velocity);
                }

            }
        });


        springAnimation.addEndListener(new DynamicAnimation.OnAnimationEndListener() {
            @Override
            public void onAnimationEnd(DynamicAnimation animation, boolean canceled, float value, float velocity) {
                if (!canceled) {
                    mCurrentStartValue = mEndValue;
                } else {
                    mCurrentStartValue = value;
                }
                mCurrentEndValue = mStartValue;
                if(mOnAnimationEndListener != null) {
                    mOnAnimationEndListener.onAnimationEnd(true,animation, canceled, value, velocity);
                }
            }
        });

        return springAnimation;
    }

    private SpringAnimation createEndAnimation(float startValue, float endValue) {
        SpringForce springForce = new SpringForce().setStiffness(mEndStiffness)
                .setDampingRatio(mDampingRatio);
        springForce.setFinalPosition(endValue);
        SpringAnimation springAnimation = new SpringAnimation(mFloatValueHolder);
        springAnimation.setSpring(springForce);
        springAnimation.setStartValue(startValue);
        springAnimation.setStartVelocity(mVelocity);
        springAnimation.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE);

        springAnimation.addUpdateListener(new DynamicAnimation.OnAnimationUpdateListener() {
            @Override
            public void onAnimationUpdate(DynamicAnimation animation, float value, float velocity) {

                if (mView != null) {
                    mView.setScaleX(value);
                    mView.setScaleY(value);
                }
                if (mOnAnimationUpdateListener != null) {
                    mOnAnimationUpdateListener.onAnimationUpdate(false,animation,value,velocity);
                }
            }
        });


        springAnimation.addEndListener(new DynamicAnimation.OnAnimationEndListener() {
            @Override
            public void onAnimationEnd(DynamicAnimation animation, boolean canceled, float value, float velocity) {
                if (!canceled) {
                    mCurrentStartValue = mStartValue;
                } else {
                    mCurrentStartValue = value;
                }
                mCurrentEndValue = mEndValue;
                if(mOnAnimationEndListener != null) {
                    mOnAnimationEndListener.onAnimationEnd(false,animation, canceled, value, velocity);
                }
            }
        });

        return springAnimation;
    }


    boolean regret = false;
    float mDownX, mDownY;
    private SpringAnimation startAnimation, endAnimation;

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (mOnTouchListener != null) {
            mOnTouchListener.onTouch(v, event);
        }
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            mDownX = event.getX();
            mDownY = event.getY();
            if (endAnimation != null && endAnimation.isRunning()) {
                endAnimation.cancel();
            }
            startAnimation = createStartAnimation(mCurrentStartValue, mCurrentEndValue);
            startAnimation.start();
            if (mClickListener != null && mView != null) {
                mClickListener.onClick(mView, true);
            }
            return true;
        } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {

            if (!regret) {
                if (startAnimation != null && startAnimation.isRunning()) {
                    startAnimation.cancel();
                }
                endAnimation = createEndAnimation(mCurrentStartValue, mCurrentEndValue);
                endAnimation.start();
            }
            if (event.getAction() == MotionEvent.ACTION_UP && mClickListener != null && mView != null) {
                mClickListener.onClick(mView, false);
            }
            regret = false;
            return true;
        } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
            if ((event.getX() < 0 || event.getY() < 0
                    || event.getX() > v.getWidth() || event.getY() > v.getHeight()
                    || judgeDistance(event)) && !regret) {
//                    if (!regret) {
                regret = true;
                if (startAnimation != null && startAnimation.isRunning()) {
                    startAnimation.cancel();
                }
                endAnimation = createEndAnimation(mCurrentStartValue, mCurrentEndValue);
                endAnimation.start();
            }

        }
        return false;
    }

    private boolean judgeDistance(MotionEvent event) {
        double sqrt = Math.sqrt(Math.pow(event.getX() - mDownX, 2) + Math.pow(event.getY() - mDownY, 2));
        return sqrt > mTouchSlop;
    }

    public static class Builder {
        private float startValue;
        private float finalValue;
        private float startStiffness, endStiffness;
        private float dampingRatio;
        private FloatValueHolder floatValueHolder;
        private float velocity;
        private ViewParent viewParent;
        private OnAnimationUpdateListener onAnimationUpdateListener;
        private OnAnimationEndListener onAnimationEndListener;
        private View.OnTouchListener onTouchListener;
        private View view;
        private OnSpringClickListener clickListener;

        public Builder() {
            this.startStiffness = 350f;
            this.endStiffness = 350f;
            this.dampingRatio = 1.2f;
            this.startValue = 1f;
            this.velocity = 0f;
        }

        public Builder startValue(float startValue) {
            this.startValue = startValue;
            return this;
        }

        public Builder addOnAnimationUpdateListener(OnAnimationUpdateListener onAnimationUpdateListener) {
            this.onAnimationUpdateListener = onAnimationUpdateListener;
            return this;
        }

        public Builder addOnAnimationEndListener(OnAnimationEndListener onAnimationEndListener) {
            this.onAnimationEndListener = onAnimationEndListener;
            return this;
        }

        public Builder setOnTouchListener(View.OnTouchListener onTouchListener) {
            this.onTouchListener = onTouchListener;
            return this;
        }

        public Builder finalValue(float finalValue) {
            this.finalValue = finalValue;
            return this;
        }

        public Builder view(View view) {
            this.view = view;
            return this;
        }

        public Builder floatVlaueHolder(FloatValueHolder floatValueHolder) {
            this.floatValueHolder = floatValueHolder;
            return this;
        }


        public Builder startStiffness(float stiffness) {
            this.startStiffness = stiffness;
            return this;
        }

        public Builder endStiffness(float stiffness) {
            this.endStiffness = stiffness;
            return this;
        }

        public Builder velocity(float velocity) {
            this.velocity = velocity;
            return this;
        }

        public Builder dampingRatio(float dampingRatio) {
            this.dampingRatio = dampingRatio;
            return this;
        }

        public Builder setViewParent(ViewParent viewParent) {
            this.viewParent = viewParent;
            return this;
        }

        public Builder setOnClickListener(OnSpringClickListener clickListener) {
            this.clickListener = clickListener;
            return this;
        }

        public SpringPressAnimation build() {
            if (floatValueHolder == null) throw new IllegalStateException("property == null");
            return new SpringPressAnimation(this);
        }
    }



    public interface OnAnimationUpdateListener {

        /**
         * Notifies the occurrence of another frame of the animation.
         *
         * @param isDownAnimation animation is DownAnimation or not
         * @param animation animation that the update listener is added to
         * @param value the current value of the animation
         * @param velocity the current velocity of the animation
         */
        void onAnimationUpdate(boolean isDownAnimation, DynamicAnimation animation, float value, float velocity);
    }


    public interface OnAnimationEndListener {
        /**
         * Notifies the end of an animation. Note that this callback will be invoked not only when
         * an animation reach equilibrium, but also when the animation is canceled.
         *
         * @param isDownAnimation animation is DownAnimation or not
         * @param animation animation that has ended or was canceled
         * @param canceled whether the animation has been canceled
         * @param value the final value when the animation stopped
         * @param velocity the final velocity when the animation stopped
         */
        void onAnimationEnd(boolean isDownAnimation, DynamicAnimation animation, boolean canceled, float value,
                            float velocity);
    }
}

package com.afmobi.palmplay.comment;

public interface onAvatarSelectChanged {

    /**
     * 选择图像改变监听
     * */
    public void onAvatarChanged();
}

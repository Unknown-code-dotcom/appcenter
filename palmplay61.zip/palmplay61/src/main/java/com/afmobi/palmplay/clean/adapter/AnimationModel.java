package com.afmobi.palmplay.clean.adapter;

import android.view.View;
import android.view.ViewGroup;

import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.AnimatorSet;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.view.ViewHelper;

/**
 * Created by xiangfei.wei on 2017/12/24.
 */

public class AnimationModel implements IAnimationManager {
    private boolean ifCanAnimation = true;//是否启动动画，true运行动画，false动画停止
    private AnimatorSet set;

    /**
     * listView item从右边出现动画效果
     */
    @Override
    public void startRightAppearanceAnimation(int position, View view, ViewGroup parent) {
        if (!ifCanAnimation) return;
        //隐藏itemView
        /*ObjectAnimator animator = ObjectAnimator.ofFloat(view, "alpha", 0);
        AnimatorSet hiddenSet = new AnimatorSet();
        hiddenSet.play(animator);
        hiddenSet.setDuration(0);
        hiddenSet.start();*/
        ViewHelper.setAlpha(view, 0);
        //item从右出现动画
        ObjectAnimator translationAnim = ObjectAnimator.ofFloat(view, "translationX", parent.getWidth(), 0);
        Animator alphaAnimator = ObjectAnimator.ofFloat(view, "alpha", 0, 1);
        set = new AnimatorSet();
        long delay = 100 * (position + 1);
        set.playTogether(translationAnim, alphaAnimator);
        set.setStartDelay(delay);
        set.setDuration(500);
        set.start();
    }

    public boolean getIfCanAnimation() {
        return ifCanAnimation;
    }

    public void setIfCanAnimation(boolean ifCanAnimation) {
        this.ifCanAnimation = ifCanAnimation;
    }

    public void cancelAnimation() {
        if (set != null && set.isRunning()) {
            set.cancel();
            set = null;
        }
    }
}

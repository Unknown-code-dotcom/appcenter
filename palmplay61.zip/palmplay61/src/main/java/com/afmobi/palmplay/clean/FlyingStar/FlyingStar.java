package com.afmobi.palmplay.clean.FlyingStar;

import android.graphics.Bitmap;

/**
 * Created by xiangfei.wei on 2017/11/26.
 */

public class FlyingStar {
    float x, y;
    float rotation;
    float alpha;
    float scale;
    float speed;
    float rotationSpeed;
    float alphaSpeed;
    float scaleSpeed;
    int width, height;
    Bitmap bitmap;
    float originalY, originalX;

    static FlyingStar createFlake(float xRange, float yRange, Bitmap originalBitmap) {
        if (originalBitmap == null || originalBitmap.isRecycled()) {
            return null;
        }
        FlyingStar flake = new FlyingStar();
        double random = Math.random();
        if (random <= 0.2)
            random += 0.4;
        else if (random <= 0.4 && random > 0.2)
            random += 0.2;

        flake.width = (int) (originalBitmap.getWidth() * random);
        /*if (flake.width <= 0)
            flake.width = originalBitmap.getWidth() / 2;*/
        float hwRatio = originalBitmap.getHeight() / originalBitmap.getWidth();
        flake.height = (int) (flake.width * hwRatio);

        // Position the flake horizontally between the left and right of the range
        flake.originalX = flake.x = (float) Math.random() * (xRange - flake.width);
        // Position the flake vertically slightly off the top of the display
        flake.originalY = flake.y = (float) Math.random() * yRange;

//        flake.speed = 50 + (float) Math.random() * 150;
        flake.speed = (float) Math.random() + 0.5f;

        flake.alpha = (float) Math.random() * 1;
        flake.alphaSpeed = (float) Math.random() * 1;
        flake.scale = (float) (Math.random() + 0.2);
        if (flake.scale > 1)
            flake.scale = 1;
        flake.scaleSpeed = (float) (Math.random() * 1);

        // Get the cached bitmap for this size if it exists, otherwise create and cache one
        /*flake.bitmap = bitmapMap.get(flake.width);
        if (flake.bitmap == null) {
            flake.bitmap = Bitmap.createScaledBitmap(originalBitmap,
                    flake.width, flake.height, true);
            bitmapMap.put(flake.width, flake.bitmap);
        }*/

        flake.bitmap = Bitmap.createScaledBitmap(originalBitmap,
                flake.width, flake.height, true);
        return flake;
    }
}

package com.afmobi.palmplay.cache.widgetprocess

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.launchwidget.ShowWidgetDialog
import com.afmobi.palmplay.launchwidget.WidgetDialogActivity
import com.afmobi.palmplay.launchwidget.widgetprovider.PSWidgetProvider
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.model.DeskWidgetPopup
import com.afmobi.palmplay.thirdlauncher.ThirdEnterUtil
import com.afmobi.util.Constants
import com.transsion.gslb.GslbSdk.context
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsnet.launcherlib.util.PhoneUtils


object DeskWidgetProcessor {
    const val KV_DESTWIDGET_ENABLE = "KV_DESTWIDGET_ENABLE"
    const val KV_TIME_GAP = "KV_TIME_GAP"
    const val KV_SHOW_TIME = "KV_SHOW_TIME"
    const val DEFAULT_GAP = 7
    const val TIME_DAY = Constants.TIME_DAY_UNIT
    val gapTime = MMKVUtils.getMMKV().getInt(KV_TIME_GAP, DEFAULT_GAP)
    val isEnable = MMKVUtils.getMMKV().getInt(KV_DESTWIDGET_ENABLE, 0)
    var isShowing = false


    fun processDeskInfoConfig(deskInfo: DeskWidgetPopup) {
        MMKVUtils.getMMKV().putInt(KV_DESTWIDGET_ENABLE, deskInfo.parameterValue.enabled)
        MMKVUtils.getMMKV().putInt(KV_TIME_GAP, deskInfo.parameterValue.popupInterval)
    }

    private fun setShowDialogTime() {
        MMKVUtils.getMMKV().putLong(KV_SHOW_TIME, System.currentTimeMillis())

    }

    fun showDialog() {
        if (AtyManager.isTopIsMain()){
            if (PhoneUtils.checkCloudFolderIsSplit()) {
                try {
                    val intent = Intent(
                        PalmplayApplication.getAppInstance(),
                        WidgetDialogActivity::class.java
                    )
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    PalmplayApplication.getAppInstance().startActivity(intent)

                    LogUtils.d("start file folder toggle activity")
                } catch (e: Exception) {
                    LogUtils.e(e.stackTraceToString())
                }
            } else {
                ShowWidgetDialog.addWidgetCompat(PalmplayApplication.getAppInstance())
            }
            setShowDialogTime()
        }
    }

    fun isCanShowDeskWidget(): Boolean {
        if (ThirdEnterUtil.isNotAllowAddWidgetGuide) {
            return false
        }
        if (isEnable == 1) {
            if (isWidgetAdd()) {
                return false
            }
            val lastTime = MMKVUtils.getMMKV().getLong(KV_SHOW_TIME, 0L)
            val currentTime = System.currentTimeMillis()
            return currentTime - lastTime >= gapTime * TIME_DAY
        } else {
            return false
        }
    }

    private fun isWidgetAdd(): Boolean {
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val widgetComponent: ComponentName = ComponentName(
            context,
            PSWidgetProvider::class.java
        )
        val widgetIds = appWidgetManager.getAppWidgetIds(widgetComponent)
        return widgetIds != null && widgetIds.isNotEmpty()
    }
}
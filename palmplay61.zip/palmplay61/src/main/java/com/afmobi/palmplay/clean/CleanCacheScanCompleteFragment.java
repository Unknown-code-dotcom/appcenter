package com.afmobi.palmplay.clean;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.base.BaseFragment;
import com.afmobi.palmplay.clean.adapter.AnimationModel;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_6.ScanResult;
import com.afmobi.palmplay.service.CleanNativeMemoryService;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import androidx.annotation.Nullable;


/**
 * 深度清理页下半部分扫描完成状态
 * Created by xiangfei.wei on 2017/11/30.
 */

public class CleanCacheScanCompleteFragment extends BaseFragment implements View.OnClickListener {

    private Activity mActivity;
    private PinnedSectionListView listview;
    private Button one_key_clean;
    private ScanResult scanResult;
    /**
     * 缓存数据
     */
    private List<CacheListItem> cacheList;
    /**
     * 卸载残留数据
     */
    private List<CacheListItem> uninstallList;
    /**
     * apk文件数据
     */
    private List<CacheListItem> mountingList;
    /**
     * 内存进程数据
     */
    private List<CacheListItem> memoryList;

    /**
     * 系统缓存
     */
    private List<CacheListItem> systemList;

    private HashSet<Integer> cacheCheckedIdSet, uninstallCheckedIdSet, mountingCheckedIdSet, memoryCheckedIdSet, sysCheckedIdSet;

    /**
     * 待清理的总size
     */
    private long waitingCleanCacheSize;
    private Handler mHandler;
    private CacheListAdapter adapter;
    private boolean isUsePmScan = false;

    private boolean isApksCheck = false;

    private boolean isCacheCheck = false;

    private boolean isUnInstallCheck = false;

    public static CleanCacheScanCompleteFragment newInstance() {
        return new CleanCacheScanCompleteFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = (Activity) context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_clean_cache_scan_complete, container, false);
        listview = (PinnedSectionListView) contentView.findViewById(R.id.listview);
        one_key_clean = (Button) contentView.findViewById(R.id.one_key_clean);
        one_key_clean.setOnClickListener(this);
        one_key_clean.setText(getString(R.string.one_key_clean) + " " + ProcessAndMemoryUtil.formatSizeKbMbGb(waitingCleanCacheSize, 1));
        //item选中态的缓存集合，存储已选中item的下标；
        cacheCheckedIdSet = new HashSet<>();
        uninstallCheckedIdSet = new HashSet<>();
        mountingCheckedIdSet = new HashSet<>();
        memoryCheckedIdSet = new HashSet<>();
        sysCheckedIdSet = new HashSet<>();
        if (mHandler == null) {
            mHandler = new Handler();
        }
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                initData();
            }
        }, 50);
        return contentView;
    }

    /**
     * 更新底部按钮的显示
     *
     * @param increase
     * @param size
     */
    private void updateWaitingCleanSize(boolean increase, long size) {
        if (increase)
            waitingCleanCacheSize += size;
        else
            waitingCleanCacheSize -= size;
        one_key_clean.setText(getText(R.string.one_key_clean).toString() + " " + ProcessAndMemoryUtil.formatSizeKbMbGb(waitingCleanCacheSize, 1));
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.one_key_clean) {
            SPManager.putLong(CleanNativeMemoryActivity.LAST_CLEAN_TIME, System.currentTimeMillis());
            CleanNativeMemoryService.CACHE_TEMP_SIZE = 0;
            CleanNativeMemoryService.RESIDUAL_JUNK_TEMP_SIZE = 0;
            if (mActivity != null && !mActivity.isFinishing() && !mActivity.isDestroyed()) {
                ((CleanNativeMemoryActivity) mActivity).onKeyCleanClick(waitingCleanCacheSize, getScanResult());
            }
        }
    }

    public void setIsUsePmScan(boolean isPmScan) {
        this.isUsePmScan = isPmScan;
    }

    public void setWaitingCleanCacheSize(long waitingCleanCacheSize) {
        this.waitingCleanCacheSize = waitingCleanCacheSize;
    }

    public void setScanResult(ScanResult scanResult) {
        this.scanResult = scanResult;
        if (this.scanResult == null) {
            this.scanResult = new ScanResult();
        }
    }

    public ScanResult getScanResult() {
        if (cacheList != null) {
            for (int i = 0; i < cacheList.size(); i++) {
                if (cacheCheckedIdSet.contains(i))
                    cacheList.get(i).setSelected(true);
                else
                    cacheList.get(i).setSelected(false);
            }
        }

        if (uninstallList != null) {
            for (int i = 0; i < uninstallList.size(); i++) {
                if (uninstallCheckedIdSet.contains(i))
                    uninstallList.get(i).setSelected(true);
                else
                    uninstallList.get(i).setSelected(false);
//            uninstallList.get(i).setSelected(adapter.getDatas().get(1 + cacheList.size() + 1 + i).isSelected());
            }
        }

        if (mountingList != null) {
            for (int i = 0; i < mountingList.size(); i++) {
                if (mountingCheckedIdSet.contains(i))
                    mountingList.get(i).setSelected(true);
                else
                    mountingList.get(i).setSelected(false);
            }
        }

        if (memoryList != null) {
            for (int i = 0; i < memoryList.size(); i++) {
                if (memoryCheckedIdSet.contains(i))
                    memoryList.get(i).setSelected(true);
                else
                    memoryList.get(i).setSelected(false);
            }
        }

        if (scanResult == null) {
            scanResult = new ScanResult();
        }

        if (!isCacheCheck){
            scanResult.setAppCacheList(cacheList);
        }
        if (!isUnInstallCheck){
            scanResult.setUninstallCacheList(uninstallList);
        }
        if (!isApksCheck){
            scanResult.setApkList(mountingList);
        }
        if (isUsePmScan) {
            scanResult.memoryList = memoryList;
            scanResult.setSystemCacheList(systemList);
        }
        return scanResult;
    }

    private void initData() {
        if (scanResult == null || mActivity == null || mActivity.isFinishing() || mActivity.isDestroyed()) {
            return;
        }
        //构建一级item的数据
        List<CacheListItem> originalDatas = new ArrayList<>();
        //缓存
        CacheListItem item = new CacheListItem();
        item.setApplicationName(getString(R.string.text_cache));
        item.setSize(scanResult.cacheSize);
        item.level = CacheListItem.ITEM_TYPE_FIRST_LEVEL;
        item.categoryId = CacheListItem.Type.CACHE;
        originalDatas.add(item);
        //卸载残留
        item = new CacheListItem();
        item.setApplicationName(getString(R.string.text_residual_junk_files));
        item.setSize(scanResult.uninstallSize);
        item.level = CacheListItem.ITEM_TYPE_FIRST_LEVEL;
        item.categoryId = CacheListItem.Type.UNINSTALL;
        originalDatas.add(item);
        //apk文件
        item = new CacheListItem();
        item.setApplicationName(getString(R.string.text_mounting));
        item.setSize(scanResult.apkFilesSize);
        item.level = CacheListItem.ITEM_TYPE_FIRST_LEVEL;
        item.categoryId = CacheListItem.Type.MOUNTING;
        originalDatas.add(item);

        if (isUsePmScan) {

            item = new CacheListItem();
            item.setApplicationName(getString(R.string.text_system_junk));
            item.setSize(scanResult.systemCacheSize);
            item.level = CacheListItem.ITEM_TYPE_FIRST_LEVEL;
            item.categoryId = CacheListItem.Type.MOUNTING;
            originalDatas.add(item);
        }
        if (adapter == null) {
            adapter = new CacheListAdapter(mActivity, originalDatas);
        }
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                view.findViewById(R.id.rl_bg).performClick();
            }
        });
        listview.setAdapter(adapter);

        /*// 存储二级item的数据
        mountingList = scanResult.getApkList();
        for (int i = 0; i < mountingList.size(); i++) {
            mountingList.get(i).parentCategoryId = CacheListItem.Type.MOUNTING;
            mountingList.get(i).secondLevelId = i;
            mountingCheckedIdSet.add(i);
        }*/
    }

    public class CacheListAdapter extends BaseAdapter implements PinnedSectionListView.PinnedSectionListAdapter {
        Context mContext;
        private List<CacheListItem> mDatas;
        private AnimationModel animationModel;

        public CacheListAdapter(Context context, List<CacheListItem> datas) {
            mContext = context;
            mDatas = new ArrayList<>();
            mDatas.addAll(datas);
            animationModel = new AnimationModel();
        }

        private void startAnimations(int position, View view, ViewGroup parent) {
            animationModel.startRightAppearanceAnimation(position, view, parent);
            if (getCount() - 1 == position) {
                animationModel.setIfCanAnimation(false);
            }
        }

        public void setDatas(List<CacheListItem> datas) {
            mDatas.clear();
            mDatas.addAll(datas);
        }

        public List<CacheListItem> getDatas() {
            return mDatas;
        }

        @Override
        public int getCount() {
            return mDatas.size();
        }

        @Override
        public Object getItem(int position) {
            return mDatas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getItemViewType(int position) {
            return mDatas.get(position).level;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }

        @Override
        public boolean isItemViewTypePinned(int viewType) {
            return viewType == CacheListItem.ITEM_TYPE_FIRST_LEVEL;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final CacheListItem item = mDatas.get(position);
            final ViewHolder viewHolder;
            //LogUtils.e("测试中啊啊", "++++++++++++++++++++++++++++++++++++++++++++position=" + position + " convertView==" + convertView);
            if (getItemViewType(position) == CacheListItem.ITEM_TYPE_FIRST_LEVEL) {//第一级
                if (convertView == null) {
                    convertView = LayoutInflater.from(mContext).inflate(R.layout.layout_cache_first_level, parent, false);
                    viewHolder = new ViewHolder();
                    viewHolder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
                    viewHolder.tv_memory_size = (TextView) convertView.findViewById(R.id.tv_memory_size);
                    viewHolder.iv_arrow = (ImageView) convertView.findViewById(R.id.iv_arrow);
                    viewHolder.iv_checked = (ImageButton) convertView.findViewById(R.id.iv_checked);
                    viewHolder.rl_bg = (RelativeLayout) convertView.findViewById(R.id.rl_bg);
                    convertView.setTag(viewHolder);
                    startAnimations(position, convertView, parent);
                } else {
                    viewHolder = (ViewHolder) convertView.getTag();
                }
                viewHolder.tv_name.setText(item.getApplicationName());

                //打开或折叠的箭头、CheckBox 处理
                if (item.getApplicationName().equals(getString(R.string.text_cache))) {
                    showArrowAndCheckBox(cacheList, item, viewHolder, cacheCheckedIdSet);
                    isCacheCheck = item.isSelected();
                } else if (item.getApplicationName().equals(getString(R.string.text_residual_junk_files))) {
                    showArrowAndCheckBox(uninstallList, item, viewHolder, uninstallCheckedIdSet);
                    isUnInstallCheck = item.isSelected();
                } else if (item.getApplicationName().equals(getString(R.string.text_mounting))) {
                    showArrowAndCheckBox(mountingList, item, viewHolder, mountingCheckedIdSet);
                    isApksCheck = item.isSelected();
                } else {
                    if (isUsePmScan) {
                        if (item.getApplicationName().equals(getString(R.string.text_system_junk))) {
                            showArrowAndCheckBox(systemList, item, viewHolder, sysCheckedIdSet);
                        }
                    }
                }

                viewHolder.tv_memory_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(item.getSize(), 1));
                viewHolder.rl_bg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //打开或者折叠第一级
                        if (item.collapse) {
                            item.collapse = false;
                            if (item.getApplicationName().equals(getString(R.string.text_cache))) {
                                openFirstLevel(cacheList, position);
                            } else if (item.getApplicationName().equals(getString(R.string.text_residual_junk_files))) {
                                openFirstLevel(uninstallList, position);
                            } else if (item.getApplicationName().equals(getString(R.string.text_mounting))) {
                                openFirstLevel(mountingList, position);
                            } else {
                                if (isUsePmScan) {
                                    if (item.getApplicationName().equals(getString(R.string.text_system_junk))) {
                                        openFirstLevel(memoryList, position);
                                    }
                                }
                            }
                        } else {
                            item.collapse = true;
                            if (item.getApplicationName().equals(getString(R.string.text_cache))) {
                                collapseFirstLevel(cacheList, position);
                            } else if (item.getApplicationName().equals(getString(R.string.text_residual_junk_files))) {
                                collapseFirstLevel(uninstallList, position);
                            } else if (item.getApplicationName().equals(getString(R.string.text_mounting))) {
                                collapseFirstLevel(mountingList, position);
                            } else{
                                if (isUsePmScan) {
                                    if (item.getApplicationName().equals(getString(R.string.text_system_junk))) {
                                        collapseFirstLevel(systemList, position);
                                    }
                                }
                            }
                        }
                        notifyDataSetChanged();
                    }
                });
            } else {//第二级
                if (convertView == null) {
                    convertView = LayoutInflater.from(mContext).inflate(R.layout.layout_cache_second_level, parent, false);
                    viewHolder = new ViewHolder();
                    viewHolder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
                    viewHolder.tv_memory_size = (TextView) convertView.findViewById(R.id.tv_memory_size);
                    viewHolder.iv_icon = convertView.findViewById(R.id.iv_icon);
                    viewHolder.iv_checked = (ImageButton) convertView.findViewById(R.id.iv_checked);
                    viewHolder.tv_reason = (TextView) convertView.findViewById(R.id.tv_reason);
                    convertView.setTag(viewHolder);
                } else {
                    viewHolder = (ViewHolder) convertView.getTag();
                }
                viewHolder.tv_name.setText(item.getApplicationName());
                viewHolder.tv_memory_size.setText(ProcessAndMemoryUtil.formatSizeKbMbGb(item.getSize(), 1));
                viewHolder.iv_checked.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (item.isSelected()) {
                            item.setSelected(false);
                            viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_unsel);
                        } else {
                            item.setSelected(true);
                            viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_sel);
                        }
                        updateWaitingCleanSize(item.isSelected(), item.getSize());//更新底部按钮总size的显示
                        //修改父item的选中状态
                        if (item.parentCategoryId == CacheListItem.Type.CACHE) {
                            changeParentChecked(item, cacheCheckedIdSet, cacheList);
                        } else if (item.parentCategoryId == CacheListItem.Type.UNINSTALL) {
                            changeParentChecked(item, uninstallCheckedIdSet, uninstallList);
                        } else if (item.parentCategoryId == CacheListItem.Type.MOUNTING) {
                            changeParentChecked(item, mountingCheckedIdSet, mountingList);
                        } else {
                            if (isUsePmScan) {
                                if (item.parentCategoryId == CacheListItem.Type.SYSTEM) {
                                    changeParentChecked(item, sysCheckedIdSet, systemList);
                                }
                            }
                        }
                    }
                });
                if (item.isSelected()){
                    viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_sel);
                } else{
                    viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_unsel);
                }

                viewHolder.iv_icon.setTag(item.apkPath);
                TRThreadPool.getInstance(TRThreadPool.PRIORITY_MEDIUM).submit(new TRRunnable(new TRRunnableInterface() {
                    @Override
                    public void doRun() {
                        final Drawable drawable = TRBitmapManager.getApkIcon(PalmplayApplication.getAppInstance(), item.getApkGlideSimpleInfo().getApkFilePath());
                        listview.post(new Runnable() {
                            @Override
                            public void run() {
                                if (viewHolder.iv_icon == null || (mActivity != null && (mActivity.isFinishing() || mActivity.isDestroyed()))) {
                                    return;
                                }
                                try {
                                    if (drawable == null) {
                                        int defResId;
                                        if (getString(R.string.text_system_cache).equals(item.getApplicationName())) {
                                            //系统缓存
                                            defResId = R.drawable.img_system_cache;
                                        } else if (!TextUtils.isEmpty(item.apkPath)) {
                                            //损坏的apk
                                            defResId = R.drawable.img_apkfile_damaged;
                                        } else {
                                            defResId = R.drawable.layer_list_app_default_01_bg;
                                        }
                                        viewHolder.iv_icon.setImageResource(defResId);
                                    } else {
                                        if (!TextUtils.isEmpty(item.apkPath) && item.apkPath.equals(viewHolder.iv_icon.getTag())) {
                                            viewHolder.iv_icon.setImageDrawable(drawable);
                                        }
                                    }
                                } catch (Exception e) {

                                }
                            }
                        });
                    }
                }));

                if (!TextUtils.isEmpty(item.apkPath)) {
                    viewHolder.tv_reason.setVisibility(View.VISIBLE);
                    viewHolder.tv_reason.setText(item.reason);
                } else {
                    viewHolder.tv_reason.setVisibility(View.GONE);
                }

            }
            return convertView;
        }

        /**
         * 更改父亲item的选中状态；
         *
         * @param item
         * @param checkedIdSet
         * @param itemList
         */
        private void changeParentChecked(CacheListItem item, HashSet<Integer> checkedIdSet, List<CacheListItem> itemList) {
            boolean parentChecked = false;
            if (item.isSelected()) {
                if (!checkedIdSet.contains(item.secondLevelId))
                    checkedIdSet.add(item.secondLevelId);

                if (checkedIdSet.size() == itemList.size()) {
                    parentChecked = true;
                }

            } else {
                checkedIdSet.remove(item.secondLevelId);
                parentChecked = false;
            }
            for (CacheListItem temp : mDatas) {
                if (item.parentCategoryId == temp.categoryId) {
                    temp.setSelected(parentChecked);
                    break;
                }
            }
            notifyDataSetChanged();
        }

        private void showArrowAndCheckBox(final List<CacheListItem> list, final CacheListItem item, final ViewHolder viewHolder, final HashSet<Integer> checkedIdSet) {
            viewHolder.iv_checked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.isSelected()) {
                        item.setSelected(false);
                        viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_unsel);
                    } else {
                        item.setSelected(true);
                        viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_sel);
                    }

                    //如果选中了该一级item，那么先把该item的所有子item中已选中的item的size从等待清理总size中减去
                    if (item.isSelected()) {
                        if (item.collapse) {//折叠状态
                            if (list != null) {
                                for (CacheListItem subItem : list) {
                                    if (subItem.isSelected())
                                        waitingCleanCacheSize -= subItem.getSize();
                                }
                            }
                        } else {//展开状态
                            for (CacheListItem subItem : mDatas) {
                                if (item.categoryId == subItem.parentCategoryId && subItem.isSelected())
                                    waitingCleanCacheSize -= subItem.getSize();
                            }
                        }

                    }
                    updateWaitingCleanSize(item.isSelected(), item.getSize());//更新底部按钮总size的显示
                    //该item的所有子item的选中状态跟该item保持一致
                    if (!item.collapse) {//折叠状态和不折叠状态要分开处理
                        for (CacheListItem temp : mDatas) {
                            if (item.categoryId == temp.parentCategoryId) {
                                temp.setSelected(item.isSelected());
                                cacheSelectedSecondLevelItem(temp);
                            }

                        }
                    } else {
                        if (item.isSelected()) {
                            if (list != null) {
                                for (CacheListItem temp : list) {
                                    temp.setSelected(item.isSelected());
                                    if (!checkedIdSet.contains(temp.secondLevelId))
                                        checkedIdSet.add(temp.secondLevelId);
                                }
                            }
                        } else {
                            if (list != null) {
                                for (CacheListItem temp : list) {
                                    temp.setSelected(item.isSelected());
                                }
                            }

                            checkedIdSet.clear();
                        }

                    }
                    notifyDataSetChanged();
                }
            });
            if (list == null || list.size() == 0) {
                viewHolder.iv_checked.setVisibility(View.VISIBLE);
                viewHolder.iv_arrow.setVisibility(View.GONE);
            } else {
                viewHolder.iv_checked.setVisibility(View.VISIBLE);
                if (item.isSelected()) {
                    viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_sel);
                } else {
                    viewHolder.iv_checked.setImageResource(R.drawable.ic_retrieve_unsel);
                }
                viewHolder.iv_arrow.setVisibility(View.VISIBLE);
                if (item.collapse)
                    viewHolder.iv_arrow.setImageResource(R.drawable.img_list_down);
                else
                    viewHolder.iv_arrow.setImageResource(R.drawable.img_list_up);
            }
        }

        private void cacheSelectedSecondLevelItem(CacheListItem secondLevelItem) {
            if (secondLevelItem.parentCategoryId == CacheListItem.Type.CACHE) {
                cacheSecondLevelId(cacheCheckedIdSet, secondLevelItem);
            } else if (secondLevelItem.parentCategoryId == CacheListItem.Type.UNINSTALL) {
                cacheSecondLevelId(uninstallCheckedIdSet, secondLevelItem);
            } else if (secondLevelItem.parentCategoryId == CacheListItem.Type.MOUNTING) {
                cacheSecondLevelId(mountingCheckedIdSet, secondLevelItem);
            } else{
                if (isUsePmScan) {
                    if (secondLevelItem.parentCategoryId == CacheListItem.Type.SYSTEM) {
                        cacheSecondLevelId(sysCheckedIdSet, secondLevelItem);
                    }
                }
            }
        }

        private void cacheSecondLevelId(HashSet<Integer> cacheSet, CacheListItem secondLevelItem) {
            if (secondLevelItem.isSelected()) {
                if (!cacheSet.contains(secondLevelItem.secondLevelId))
                    cacheSet.add(secondLevelItem.secondLevelId);
            } else {
                cacheSet.remove(secondLevelItem.secondLevelId);
            }
        }

        private void openFirstLevel(List<CacheListItem> list, int position) {
            if (list == null || list.size() == 0)
                return;
            for (int i = 0; i < list.size(); i++) {
                mDatas.add(position + 1 + i, list.get(i));//.copy());
            }
        }

        private void collapseFirstLevel(List<CacheListItem> list, int position) {
            if (list == null || list.size() == 0)
                return;
            List<CacheListItem> tempListNew = new ArrayList<>();
            List<CacheListItem> tempListOld = new ArrayList<>();
            for (int i = position + 1; i < position + 1 + list.size(); i++) {
                tempListNew.add(mDatas.get(i).copy());
                tempListOld.add(mDatas.get(i));
            }
            //为了避免java.util.ConcurrentModificationException
            for (int i = 0; i < tempListOld.size(); i++) {
                if (mDatas.contains(tempListOld.get(i)))
                    mDatas.remove(tempListOld.get(i));
            }

            list = tempListNew;
        }

        public class ViewHolder {
            public TextView tv_name;
            public TextView tv_memory_size;
            public ImageView iv_arrow;
            public ImageButton iv_checked;
            public ImageView iv_icon;
            public RelativeLayout rl_bg;
            public TextView tv_reason;
        }

        public void onRelease() {
            if (animationModel != null) {
                animationModel.cancelAnimation();
                animationModel = null;
            }
            if (mDatas != null) {
                mDatas.clear();
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }
        if (adapter != null) {
            adapter.onRelease();
            adapter = null;
        }
        mActivity = null;
    }
}

package com.afmobi.palmplay.activate;

import android.app.Activity;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.ProcessLifecycleChecker;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.main.utils.NotificationLayoutManager;
import com.afmobi.palmplay.main.utils.PSNotificationManager;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.push.TRPushMsgsManager;
import com.afmobi.palmplay.scavenger.DiskSpaceLimitActivity;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;

public class TRDiskSpaceLimitExecutor extends TRBaseExecutor {

    public static volatile boolean STATUS = false;//代表本身是否正在显示

    public TRDiskSpaceLimitExecutor() {
    }

    @Override
    public boolean isCanShow(String fromType) {
        return TRDialogUtil.diskSpaceLimitCanShow();
    }


    @Override
    public boolean show(String fromType) {
        if(TextUtils.isEmpty(fromType)) {
            TRPushMsgsManager.getInstance().trackPushTechUV("Space", "1", "", "",1, "1");
            return false;
        }

        String args[] = fromType.split(Constant.KEY_SPLIT_CHAR);
        if (args == null || args.length < 4) {
            TRPushMsgsManager.getInstance().trackPushTechUV("Space", "1", "", "",1, "2");
            return false;
        }

        String packageName = args[0];
        int tmp = 0;
        long avariableSize = 0;
        long appSize = 0;
        try {
            tmp = Integer.parseInt(args[1]);
            avariableSize = Long.parseLong(args[2]);
            appSize = Long.parseLong(args[3]);
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        boolean isInstall = (tmp == 1);
        FileDownloadInfo currFileDownloadInfo = null;
        if(isInstall) {
            currFileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(packageName);
        }else {
            currFileDownloadInfo = DownloadManager.getInstance().getDownloadingInfo(packageName);
        }

        if (currFileDownloadInfo == null) {
            TRPushMsgsManager.getInstance().trackPushTechUV("Space", "1", "", "",1, "3");
            return false;
        }

        if(appSize <= 0) {
            appSize = currFileDownloadInfo.sourceSize;
        }

        boolean isDiskSpaceActivity = CommonUtils.isCurrentDiskSpaceLimitActivity();
        if (isDiskSpaceActivity) {
            //TODO:当前在空间不足提示页面，暂停处理，切下一个下载
            LogUtils.d("DiskSpaceLimitActivity is already open, will not show agian");
        }else {
            if (CommonUtils.isNeedShowStorageCleanTips()) {
                Activity activity = AtyManager.getAtyManager().getCurrentActivity();
                DiskSpaceLimitActivity.startDiskSpaceLimitActivity(activity, currFileDownloadInfo.packageName, appSize, currFileDownloadInfo.fromPage, isInstall, avariableSize);
            } else {
                if (!ProcessLifecycleChecker.isAppInBackground()) {
                    LogUtils.d("PS is on forground,will not show space limit notify");
                    TRPushMsgsManager.getInstance().trackPushTechUV("Space", "1", "", "",2, "4");
                    return false;
                }
                //GT 关闭普通通知
                if(CommonUtils.commonNotificationIsNeedShow() && NotificationExtKt.isSwitchOpen(TRSharedPreferenceUtils.KV_CLEAN_SWITCH)){
                    //TODO: 后台或者非支持弹框页，弹空间不足通知+悬挂
                    FileDownloadInfo finalCurrFileDownloadInfo = currFileDownloadInfo;
                    PSNotificationManager.checkCondition(()->{
                        NotificationLayoutManager.INSTANCE.initNotification(PalmplayApplication.getAppInstance(), NotificationExtKt.getNOTIFY_ID_CLEAN())
                                .notifyCleanSpace(finalCurrFileDownloadInfo, isInstall);
                    });
                } else {
                    boolean isNeedShow = CommonUtils.commonNotificationIsNeedShow();
                    boolean isSwitchOpen = NotificationExtKt.isSwitchOpen(TRSharedPreferenceUtils.KV_CLEAN_SWITCH);
                    String error = "";
                    if (!isNeedShow){
                        error += "1";
                    }
                    if (!isSwitchOpen){
                        error += "A";
                    }
                    TRPushMsgsManager.getInstance().trackPushTechUV("Space", "1", "", "",3, error);
                }
            }
        }

        return true;
    }

    @Override
    public boolean isShowing() {
        return STATUS;
    }
}

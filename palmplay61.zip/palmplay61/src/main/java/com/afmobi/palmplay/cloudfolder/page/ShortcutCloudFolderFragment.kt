package com.afmobi.palmplay.cloudfolder.page

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.SimpleItemAnimator
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.cloudfolder.CloudFolderPreviewManager
import com.afmobi.palmplay.cloudfolder.adapter.ShortcutCloudFolderAdapter
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.isAdxItem
import com.afmobi.palmplay.cloudfolder.model.CloudFolderViewData
import com.afmobi.palmplay.cloudfolder.model.NormalAppUiModel
import com.afmobi.palmplay.cloudfolder.model.RankAppUiModel
import com.afmobi.palmplay.cloudfolder.model.RankTitleUiModel
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil.SCENE_CENTER
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.KEY_CLOUD_FOLDER_TYPE
import com.afmobi.palmplay.cloudfolder.utils.PaletteControls
import com.afmobi.palmplay.cloudfolder.utils.TYPE_GET_CACHED
import com.afmobi.palmplay.cloudfolder.utils.WallpaperUtils
import com.afmobi.palmplay.cloudfolder.utils.getSafeString
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.view.CloudClickPopupWindow
import com.afmobi.palmplay.cloudfolder.view.CloudFolderPauseDialog
import com.afmobi.palmplay.cloudfolder.view.CloudFolderRecyclerView
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.GsonUtils
import com.transsion.palmstorecore.util.NetworkUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsion.phonehelper.floatwindow.function.RVItemExposureListener
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.model.FileFolderAdTrackData
import com.transsnet.store.R
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume


class ShortcutCloudFolderFragment : BaseCloudFolderFragment() {

    private val TAG = "CloudFolderFragment"

    private var shotCutExposureListener: RVItemExposureListener? = null
    private var mGridAdapter: ShortcutCloudFolderAdapter? = null
    private lateinit var mRecyclerView: CloudFolderRecyclerView
    private var mLayoutManager: GridLayoutManager? = null
    private lateinit var searchItem: LinearLayout
    private lateinit var searchIcon: ImageView
    private lateinit var layoutContainer: LinearLayout
    private var iconSearch: ImageView ?= null
    private var textHint: TextView ?= null
    private var textNoNet: TextView ?= null
    private var iconNoNet: ImageView ?= null

    private var layoutFolderEmptyContent: LinearLayout? = null
    private var textEmptyContent: TextView? = null
    private var layoutEmptyNoNet: LinearLayout? = null

    private var mPopMenuWindow: CloudClickPopupWindow? = null

    private var mPopMenuItemSelectedListener: CloudClickPopupWindow.PopMenuItemSelectedListener? = null

    val MAX_ROW = 4

    private var triggerId = ""

    private var cancelList = arrayListOf<String>()

    private val paletteControls : PaletteControls by lazy {
        PaletteControls.getInstance(PalmplayApplication.getAppInstance())
    }


    companion object {
        fun createCloudFolder(categoryType: Int) : ShortcutCloudFolderFragment{
            val cloudFolderFragment = ShortcutCloudFolderFragment()
            val bundle = Bundle()
            bundle.putInt(KEY_CLOUD_FOLDER_TYPE, categoryType)
            cloudFolderFragment.arguments = bundle
            return cloudFolderFragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val inflate: View = LayoutInflater.from(context)
            .inflate(R.layout.fragment_launcher_shortcuts, container, false)
        initData(inflate, arguments)
        return inflate
    }

    private fun initData(view: View, arguments: Bundle?) {
        arguments?.let {
            categoryType = it.getInt(KEY_CLOUD_FOLDER_TYPE)
        }
        val rootView = view.findViewById<RelativeLayout>(R.id.rl_shortcut_root_view)
        textHint = view.findViewById(R.id.textHint)
        iconNoNet = view.findViewById(R.id.iconNoNet)
        iconSearch = view.findViewById(R.id.iconSearch)
        searchItem = view.findViewById(R.id.searchItem)
        textNoNet = view.findViewById(R.id.textNoNet)
        searchItem = view.findViewById(R.id.searchItem)
        textEmptyContent = view.findViewById(R.id.textEmptyContent)
        updateDarkUI()
        val layoutParams = rootView.layoutParams
        layoutParams.width = DeviceProfile.getInstance().getDesiredWidth()
        layoutParams.height = DeviceProfile.getInstance().getDesiredHeight()
        initRecyclerView(view)
        initTrackEvent()
        initClickEvent(view)
        initCloudFolderData()

    }

    override fun updateDarkUI() {
        if(WallpaperUtils.getInstance().isLightMode()) {
            iconSearch?.setImageResource(R.drawable.ic_folder_search_dark)
            searchItem.setBackgroundResource(R.drawable.bg_folder_search_dark)
            iconNoNet?.setImageResource(R.drawable.ic_cloud_folder_no_net_dark)
            textHint?.setTextColor(resources.getColor(R.color.color_cloud_folder_search_dark))
            textNoNet?.setTextColor(resources.getColor(R.color.color_cloud_folder_search_dark))
            textEmptyContent?.setTextColor(resources.getColor(R.color.color_cloud_folder_search_dark))
        }
    }

    /**
     * 埋点事件统计
     */
    private fun initTrackEvent() {
        shotCutExposureListener = RVItemExposureListener(
            mRecyclerView
        ) { position: Int ->
            val appInfo = mGridAdapter?.getAppInfo(position) ?: return@RVItemExposureListener
            LogUtils.d("onItemExposure:  position: $position   name:  ${appInfo.name}    isOffer: ${appInfo.isOffer}")
            var adType = 0
            if(appInfo.isOffer == Constants.IS_ADX && FileDownloadInfo.STATUS_NONE == appInfo.observerStatus) {
                if (TextUtils.isEmpty(triggerId)) {
                    triggerId = CloudFolderManager.getInstance().generateTriggerId()
                }
                adType = 1
                val trackList = arrayListOf(
                    FileFolderAdTrackData(
                        appInfo.packageName,
                        triggerId,
                        CloudFolderManager.getInstance().generateShowId()
                    )
                )

                CloudFolderManager.getInstance().uploadAdxExposure(GsonUtils.getInstance().toJson(trackList), categoryType)
            }
            CloudFolderTrackUtil.businessItemExposureTrack(
                position,
                appInfo.packageName,
                CloudFolderTrackUtil.getDownloadStatus(appInfo.observerStatus),
                enterFrom,
                categoryType,
                adType
            )

        }
    }

    private fun initClickEvent(view: View) {
        searchIcon = view.findViewById(R.id.searchIcon)
        layoutContainer = view.findViewById(R.id.layoutContainer)
        layoutFolderEmptyContent = view.findViewById(R.id.layoutFolderEmptyContent)
        layoutEmptyNoNet = view.findViewById(R.id.layoutEmptyNoNet)
        layoutContainer.setOnClickListener {
            activity?.let {
                if (!it.isFinishing) {
                    it.finish()
                }
            }
        }

        searchItem.setOnClickListener {
            CloudFolderTrackUtil.tecTrack(
                CloudFolderTrackUtil.TYPE_CLICK,
                CloudFolderTrackUtil.STATUS_CLICK_ICON,
                "",
                categoryType.toString()
            )

            CloudFolderManager.getInstance().goToPsSearchPage(categoryType)
        }

        searchIcon.setOnClickListener {
            CloudFolderTrackUtil.tecTrack(
                CloudFolderTrackUtil.TYPE_CLICK,
                CloudFolderTrackUtil.STATUS_CLICK_SEARCH,
                "",
                categoryType.toString()
            )

            CloudFolderManager.getInstance().goToPsHomePage(categoryType)
        }
    }

    private fun initRecyclerView(view: View) {
        context?.let {
            mRecyclerView = view.findViewById(R.id.shortcut_recyclerView)
            mLayoutManager = GridLayoutManager(context, MAX_ROW)
            mRecyclerView.layoutManager = mLayoutManager
            mGridAdapter =
                ShortcutCloudFolderAdapter(
                    it, categoryType
                )
            mRecyclerView.adapter = mGridAdapter
            mGridAdapter?.onCreateView()
            mGridAdapter?.setGridLayoutManager(mLayoutManager)
            val itemAnimator = mRecyclerView.itemAnimator
            if (itemAnimator is SimpleItemAnimator) {
                itemAnimator.supportsChangeAnimations =
                    false //解决刷新单个item时，该item闪烁的问题
            }

            mPopMenuItemSelectedListener = object : CloudClickPopupWindow.PopMenuItemSelectedListener {
                override fun onItemClicked(itemInfo: Any?, menuStr: String, position: Int) {
                    if (itemInfo == null) {
                        return
                    }
                    val appInfo = itemInfo as AppInfo
                    val eventName: String = if (TextUtils.equals(menuStr, context?.getSafeString(R.string.text_uninstall, useSystemLanguage = true))) {
                        val packageName = appInfo.packageName
                        if(!cancelList.contains(packageName) && NetworkUtils.getNetworkState(context) != NetworkUtils.NET_WIFI) {
                            activity?.apply {
                                if(isFinishing || isDestroyed) {
                                    DownloadManager.getInstance().cancelDownload(packageName)
                                    return
                                }
                                CloudFolderPauseDialog(this, CloudFolderPauseDialog.STYLE_CANCEL,
                                    object : CloudFolderPauseDialog.OnDialogListener {
                                        override fun onClick(status: Int) {
                                            if (status == CloudFolderPauseDialog.STATUS_KEY_BACK) {
                                                return
                                            }
                                            if (status == CloudFolderPauseDialog.STATUS_CONFIRM) {
                                                cancelList.add(packageName)
                                                DownloadManager.getInstance()
                                                    .pauseDownloadForRetieveDownload(packageName)

                                            } else {
                                                DownloadManager.getInstance().cancelDownload(packageName)
                                            }
                                        }
                                    }
                                ).show()
                            }?: DownloadManager.getInstance().cancelDownload(packageName)
                        } else {
                            DownloadManager.getInstance().cancelDownload(packageName)
                        }

                        CloudFolderTrackUtil.BUTTON_TYPE_CANCEL
                    } else if(TextUtils.equals(menuStr, context?.getSafeString(R.string.text_install, useSystemLanguage = true))) {
                        val sign = if (categoryType == CATEGORY_APP) "A" else "G"
                        val fromPage = "FL_${sign}_${SCENE_CENTER}_$position"
                        CloudFolderManager.getInstance().startDownload(appInfo, categoryType, fromPage)
                        CloudFolderTrackUtil.BUTTON_TYPE_INSTALL
                    } else {
                        val sign = if (categoryType == CATEGORY_APP) "A" else "G"
                        val isAdx = appInfo.isAdxItem()
                        val valueScene = if (isAdx) CloudFolderTrackUtil.SCENE_ADX else SCENE_CENTER
                        val value = "FL_${sign}_${valueScene}_$position"
                        CloudFolderManager.getInstance().showAppDetailPage(
                            isAdx,
                            appInfo.packageName,
                            categoryType,
                            value,
                            null,
                        )
                        CloudFolderTrackUtil.BUTTON_TYPE_OPEN
                    }
                    CloudFolderTrackUtil.businessItemClickTrack(
                        position,
                        eventName,
                        appInfo.packageName,
                        categoryType,
                        appInfo.isOffer
                    )
                }

            }

            mGridAdapter?.apply {
                setOnItemClickListener(object : ShortcutCloudFolderAdapter.OnRecyclerViewItemClickListener{

                    override fun onItemLongClick(view: View?) {
                        mGridAdapter?.let { adapter->
                            val pos = view!!.tag as Int
                            if (pos >= 0 && pos < adapter.itemCount) {
                                val appInfo = mGridAdapter?.getAppInfo(pos) ?: return
                                if(appInfo.observerStatus == FileDownloadInfo.STATUS_APP_INSTALLED) {
                                    return
                                }
                                if (null == mPopMenuWindow) {
                                    mPopMenuWindow =
                                        CloudClickPopupWindow(PalmplayApplication.getAppInstance(), appInfo, pos)
                                }
                                mPopMenuWindow?.setData(
                                    appInfo,
                                    pos,
                                    mPopMenuItemSelectedListener
                                )
                                mPopMenuWindow?.onShow(view)

                            }
                        }
                    }

                    override fun onItemClick(appInfo: AppInfo) {
                        activity?.apply {
                            if (isFinishing || isDestroyed) {
                                DownloadManager.getInstance().cancelDownload(packageName)
                                return
                            }
                            if (NetworkUtils.getNetworkState(this) != NetworkUtils.NET_WIFI) {
                                CloudFolderPauseDialog(
                                    this,
                                    CloudFolderPauseDialog.STYLE_PAUSE,
                                    { status ->
                                        if (status == CloudFolderPauseDialog.STATUS_CONFIRM) {
                                            DownloadManager.getInstance()
                                                .pauseDownloadForRetieveDownload(appInfo.packageName)
                                        }
                                    }).show()
                            }
                        }
                    }

                })
            }
        }
    }

    private fun initCloudFolderData() {
        lifecycleScope.launchWhenCreated {
            val viewData = getCloudFolderData()
            val folderInfo = if(categoryType == CATEGORY_APP) FOLDER.APPS else FOLDER.GAMES
            if(viewData == null || viewData.scrollableItems.isEmpty()) {
                CloudFolderManager.getInstance().showEmptyCloudFolderPreviewImage(folderInfo, folderInfo.defaultShortcutDrawable)
                dealEmptyLayout()
            } else {
                // 从 scrollableItems 中提取 CloudAppInfo 列表
                val folderList = viewData.scrollableItems.mapNotNull { item ->
                    when (item) {
                        is NormalAppUiModel -> item.appInfo
                        is RankAppUiModel -> item.appInfo
                        is RankTitleUiModel -> item.appInfo
                        else -> null
                    }
                }
                mGridAdapter?.setListData(folderList)

                // 异步校验与更新桌面图标，防止下载阻塞列表展示
                val previewImageFromData =
                    CloudFolderPreviewManager.getInstance().generatePreviewImageFromData(folderInfo, folderList)
                if (previewImageFromData != null) {
                    ioScope.launch {
                        CloudFolderManager.getInstance().updateFolder(folderInfo, previewImageFromData)
                    }
                }
            }
        }
    }

    private suspend fun getCloudFolderData() : CloudFolderViewData? {
        return suspendCancellableCoroutine { ctn->
            ioScope.launch {
                CloudFolderManager.getInstance().getCloudFolderData(categoryType, TYPE_GET_CACHED,{
                    if(ctn.isActive) {
                        ctn.resume(null)
                    }
                }) {
                    if(ctn.isActive) {
                        ctn.resume(it)
                    }
                }
            }
        }
    }

    private fun dealEmptyLayout() {
        CloudFolderTrackUtil.tecTrack(
            CloudFolderTrackUtil.TYPE_SHOW,
            CloudFolderTrackUtil.STATUS_SHOW_FOLDER_EMPTY,
            "1",
            categoryType.toString()
        )

        layoutFolderEmptyContent ?.apply {
            if (mGridAdapter?.itemCount == 0) {
                layoutFolderEmptyContent!!.visibility = View.VISIBLE
                //显示空页面
                if (NetworkUtils.isNetworkAvailable(TRApplicationContextUtil.getInstance())) {
                    textEmptyContent!!.visibility = View.VISIBLE
                    layoutEmptyNoNet!!.visibility = View.GONE
                } else {
                    layoutEmptyNoNet!!.visibility = View.VISIBLE
                    textEmptyContent!!.visibility = View.GONE
                }
            } else {
                layoutFolderEmptyContent!!.visibility = View.GONE
            }
        }
    }

    override fun onPause() {
        super.onPause()
        shotCutExposureListener?.resetExposureData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mGridAdapter?.onDestroy()
    }

}

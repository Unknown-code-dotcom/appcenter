package com.afmobi.palmplay.appdetail.holder;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.afmobi.palmplay.appdetail.AppDetailUtils;
import com.afmobi.palmplay.appdetail.DownloadHandlerInf;
import com.afmobi.palmplay.appdetail.TrackUtils;
import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;
import com.afmobi.palmplay.detail.AppDetailsComponentHeadViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentTagViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentUdsTransitionViewHolder;
import com.afmobi.palmplay.detail.AppDetailsComponentWelfareViewHolder;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.manager.PreciseTrackManager;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.DetailResponseData;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.IMessenger;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;

public class AppDetailTopHolder extends BaseAppDetailHolder{
    private final static float WELFARE_RATIO = 167f / 328f;
    private final static float WELFARE_IMG_RATIO = 120f / 328f;
    private DownloadHandlerInf downloadHandlerInf;
    private String mValue;

    public AppDetailTopHolder(FragmentActivity mActivity, TRNewAppViewModel mAppDetailModel, CommonAppDetailView commonAppDetailView, DownloadHandlerInf downloadHandlerInf, String mValue) {
        super(mActivity, mAppDetailModel, commonAppDetailView);
        this.downloadHandlerInf = downloadHandlerInf;
        this.mValue = mValue;
    }

    @Override
    public void initHolder() {

    }

    public void onAppDetailHeaderLayout() {

        DetailResponseData data = mAppDetailModel.getDetailResponseLiveData().getValue();
        List<DetailComponentItemData> list = (data != null) ? data.getComponentListByStyle(AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD) : null;

        onTopLayoutViewObserver(list);

        int height;
        int marginBottom = mActivity.getResources().getDimensionPixelSize(R.dimen.dp_06);
        int componentMargin = mActivity.getResources().getDimensionPixelSize(R.dimen.component_margin);
        if (commonAppDetailView.isCustomizedStyle()) {
            height = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_offer_appbar_h);
        }else {
            height = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_head_bg_h);
        }

        int margin = DisplayUtil.dip2px(mActivity, 16);
        int screenWidthPx = DisplayUtil.getScreenWidthPx(mActivity) + DisplayUtil.getInsetsMargin(mActivity);
        int width = screenWidthPx - 2 * margin;
        int welfareBtnHeight = mActivity.getResources().getDimensionPixelSize(R.dimen.gift_get_h);
        int realheight = (int) (WELFARE_IMG_RATIO * width) + welfareBtnHeight;

        // welfare height
        int welfareHeight = realheight + componentMargin;
        int finalHeight = height;
        int welfareCount = getWelfareCount();
        for (int i = 0;i < welfareCount;i ++) {
            finalHeight += welfareHeight;
        }

        // TAG HEIGHT
        int tagCount = getTagCount();
        int tagHeight = mActivity.getResources().getDimensionPixelSize(R.dimen.tag_h) + componentMargin;
        for (int j = 0;j < tagCount;j++) {
            finalHeight += tagHeight;
        }
        CoordinatorLayout.LayoutParams lp = (CoordinatorLayout.LayoutParams) commonAppDetailView.mBinding.appbarLayout.getLayoutParams();
        lp.height = finalHeight;
        commonAppDetailView.mBinding.appbarLayout.setLayoutParams(lp);

        CollapsingToolbarLayout.LayoutParams lp2 = (CollapsingToolbarLayout.LayoutParams) commonAppDetailView.mBinding.layoutTop.getLayoutParams();
        lp2.bottomMargin = marginBottom;
        commonAppDetailView.mBinding.layoutTop.setLayoutParams(lp2);

    }

    public void onTopLayoutViewObserver() {

        List<DetailComponentItemData> list = new ArrayList<>();
        DetailComponentItemData baseInfoItem = new DetailComponentItemData();
        baseInfoItem.itemName = (String) mAppDetailModel.getParam("mArgumentsTitle");
        baseInfoItem.packageName = (String) mAppDetailModel.getParam("mPackageName");
        baseInfoItem.dataType = AppDetailsRecyclerViewAdapter.COMPONET_BASE_INFO;
        baseInfoItem.hasTrack = true;
        list.add(baseInfoItem);

        DetailComponentItemData udsItem = new DetailComponentItemData();
        udsItem.dataType = AppDetailsRecyclerViewAdapter.COMPONET_UDS_TRANSITION;
        udsItem.hasTrack = true;
        list.add(udsItem);

        onTopLayoutViewObserver(list);
    }

    private void onTopLayoutViewObserver(List<DetailComponentItemData> list) {
        LayoutInflater inflater = LayoutInflater.from(mActivity);

        if (list != null && !list.isEmpty()) {

            //add view
            if (commonAppDetailView.mBinding.layoutTop.getChildCount() > 0) {
                commonAppDetailView.mBinding.layoutTop.removeAllViews();
            }
            OfferInfo offerInfo = AppDetailUtils.getOfferInfo(commonAppDetailView.mAppInfo, commonAppDetailView.isCustomizedStyle());

            for (int i = 0;i < list.size();i ++) {
                DetailComponentItemData item = list.get(i);
                if (TextUtils.isEmpty(item.dataType)) {
                    continue;
                }

                switch (item.dataType) {
                    case AppDetailsRecyclerViewAdapter.COMPONET_BASE_INFO:
                        removeViewFromParent(commonAppDetailView.headerViewBinding.getRoot());
                        commonAppDetailView.mBinding.layoutTop.addView(commonAppDetailView.headerViewBinding.getRoot());

                        AppDetailsComponentHeadViewHolder headViewHolder = new AppDetailsComponentHeadViewHolder(commonAppDetailView.headerViewBinding.getRoot());
                        headViewHolder.setFrom(commonAppDetailView.mFrom)
                                .setFromCache(false)
                                .setFeatureName(TRAnalyticsConstant.COMPONENT_TOP_CARD)
                                .setScreenPageName(TRAnalyticsConstant.DETAIL_PAGE)
                                .setItemID(commonAppDetailView.mAppInfo.itemID)
                                .setFromPage((String) mAppDetailModel.getParam("fromPageID"))
                                .setPageParamInfo(commonAppDetailView.mPageParamInfo)
                                .setOnViewLocationInScreen(commonAppDetailView.mOnViewLocationInScreen)
                                .setOfferInfo(offerInfo)
                                .setAppInfo(commonAppDetailView.mAppInfo)
                                .setActivity(mActivity)
                                .bind(item, i);

                        mAppDetailModel.trackNfId(item);//命中实验id需要放在曝光和点击的埋点里上报，基础信息是一定会上报的，因此放在这里取
                        onComponentTrack(TRAnalyticsConstant.COMPONENT_TOP_CARD, i, item);
                        break;

                    case AppDetailsRecyclerViewAdapter.COMPONET_ITEM_INFO:
                        removeViewFromParent(commonAppDetailView.appInfoViewBinding.getRoot());
                        commonAppDetailView.mBinding.layoutTop.addView(commonAppDetailView.appInfoViewBinding.getRoot());
                        NewAppDetailsComponentUdsViewHolder udsViewHolder = new NewAppDetailsComponentUdsViewHolder(commonAppDetailView.appInfoViewBinding.getRoot());
                        udsViewHolder.setmValue(mValue);
                        udsViewHolder.setLayoutStarClickInf(new NewAppDetailsComponentUdsViewHolder.LayoutStarClickInf() {
                            @Override
                            public void clickLayoutStar(View v) {
                                int curItem = commonAppDetailView.mBinding.viewpager.getCurrentItem();
                                if(curItem != 1) {
                                    commonAppDetailView.mBinding.viewpager.setCurrentItem(1, true);
                                    commonAppDetailView.currentPosition=1;

                                    TrackUtils.clickLayoutStar(commonAppDetailView.mFrom, commonAppDetailView.mAppInfo);
                                }
                            }
                        });
                        udsViewHolder.setFrom(commonAppDetailView.mFrom)
                                .setFromCache(false)
                                .setFeatureName(TRAnalyticsConstant.COMPONENT_APP_INFO)
                                .setScreenPageName(TRAnalyticsConstant.DETAIL_PAGE)
                                .setItemID(commonAppDetailView.mAppInfo.itemID)
                                .setFromPage((String) mAppDetailModel.getParam("fromPageID"))
                                .setPageParamInfo(commonAppDetailView.mPageParamInfo)
                                .setOnViewLocationInScreen(commonAppDetailView.mOnViewLocationInScreen)
                                .setOfferInfo(offerInfo)
                                .setActivity(mActivity)
                                .setAppInfo(commonAppDetailView.mAppInfo)
                                .bind(item, i);

                        onComponentTrack(TRAnalyticsConstant.COMPONENT_APP_INFO, i, item);
                        break;

                    case AppDetailsRecyclerViewAdapter.COMPONET_TAG:
                        View tagView = DataBindingUtil.inflate(inflater, R.layout.z_layout_app_details_component_tag, null, false).getRoot();
                        commonAppDetailView.mBinding.layoutTop.addView(tagView);
                        AppDetailsComponentTagViewHolder tagViewHolder = new AppDetailsComponentTagViewHolder(tagView);
                        tagViewHolder.setTab(AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD);
                        tagViewHolder.setFrom(commonAppDetailView.mFrom)
                                .setFromCache(false)
                                .setFeatureName(TRAnalyticsConstant.COMPONENT_TAG)
                                .setScreenPageName(TRAnalyticsConstant.DETAIL_PAGE)
                                .setItemID(commonAppDetailView.mAppInfo.itemID)
                                .setFromPage((String) mAppDetailModel.getParam("fromPageID"))
                                .setPageParamInfo(commonAppDetailView.mPageParamInfo)
                                .setOnViewLocationInScreen(commonAppDetailView.mOnViewLocationInScreen)
                                .setOfferInfo(offerInfo)
                                .setActivity(mActivity)
                                .bind(item, i);

                        tagViewHolder.addRecyclerViewExpouse(i, item);
                        break;

                    case AppDetailsRecyclerViewAdapter.COMPONET_WELFARE:
                        View welfareView = DataBindingUtil.inflate(inflater, R.layout.z_layout_app_details_component_welfare, null, false).getRoot();
                        commonAppDetailView.mBinding.layoutTop.addView(welfareView);
                        AppDetailsComponentWelfareViewHolder viewHolder = new AppDetailsComponentWelfareViewHolder(welfareView);
                        viewHolder.setUseSmallCache(AppDetailUtils.isUseSmallCache(commonAppDetailView.mType));
                        viewHolder.setTab(AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD);
                        viewHolder.setIMessager(new IMessenger() {
                            @Override
                            public void onMessenger(Object... objects) {
                                if(objects != null && objects.length > 0 && objects[0] instanceof String){
                                    String text = (String) objects[0];
                                    if (TextUtils.equals(text, AppDetailsRecyclerViewAdapter.COMPONET_WELFARE)) {
                                        if (downloadHandlerInf != null){
                                            downloadHandlerInf.handDownload(null, commonAppDetailView.mAppInfo, commonAppDetailView.mFrom);
                                        }
                                    }
                                }

                            }
                        });
                        viewHolder.setFrom(commonAppDetailView.mFrom)
                                .setFromCache(false)
                                .setFeatureName(TRAnalyticsConstant.COMPONENT_WELFARE)
                                .setScreenPageName(TRAnalyticsConstant.DETAIL_PAGE)
                                .setItemID(commonAppDetailView.mAppInfo.itemID)
                                .setFromPage((String) mAppDetailModel.getParam("fromPageID"))
                                .setPageParamInfo(commonAppDetailView.mPageParamInfo)
                                .setOnViewLocationInScreen(commonAppDetailView.mOnViewLocationInScreen)
                                .setOfferInfo(offerInfo)
                                .setActivity(mActivity)
                                .setAppInfo(commonAppDetailView.mAppInfo)
                                .bind(item, i);

                        viewHolder.addRecyclerViewExpouse(i, item);
                        break;

                    case AppDetailsRecyclerViewAdapter.COMPONET_UDS_TRANSITION:
                        View udsTransitionView = DataBindingUtil.inflate(inflater, R.layout.z_layout_app_details_component_uds_transition, null, false).getRoot();
                        commonAppDetailView.mBinding.layoutTop.addView(udsTransitionView);
                        AppDetailsComponentUdsTransitionViewHolder udsTransitionViewHolder = new AppDetailsComponentUdsTransitionViewHolder(udsTransitionView);
                        udsTransitionViewHolder.setOfferInfo(offerInfo)
                                .bind(item, i);
                        break;

                    default:
                        break;
                }
            }
        }
    }


    /**
     * 获取福利券个数
     * */
    private int getWelfareCount() {
        DetailResponseData detailResp = mAppDetailModel.getDetailResponseLiveData().getValue();
        if (detailResp == null) {
            return 0;
        }

        int count = 0;
        List<DetailComponentItemData> components = detailResp.getComponentListByStyle(AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD);
        if (components != null && !components.isEmpty()) {
            for (DetailComponentItemData item : components) {
                if (item != null && TextUtils.equals(item.dataType, AppDetailsRecyclerViewAdapter.COMPONET_WELFARE)
                        && item.couponList != null && !item.couponList.isEmpty() ) {
                    count++;
                }
            }
        }

        return count;
    }

    /**
     * 获取顶部tab 的TAG个数
     * */
    private int getTagCount() {
        DetailResponseData detailResp = mAppDetailModel.getDetailResponseLiveData().getValue();
        if (detailResp == null) {
            return 0;
        }

        int count = 0;
        List<DetailComponentItemData> components = detailResp.getComponentListByStyle(AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD);
        if (components != null && !components.isEmpty()) {
            for (DetailComponentItemData item : components) {
                if (item != null && TextUtils.equals(item.dataType, AppDetailsRecyclerViewAdapter.COMPONET_TAG)
                        && item.tagList != null && !item.tagList.isEmpty()) {
                    count++;
                }
            }
        }

        return count;
    }

    /**
     * 移除某个view的父View
     * */
    public void removeViewFromParent(View v) {
        if (v == null) {
            return;
        }

        ViewParent parent = v.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(v);
        }
    }

    private void onComponentTrack(String featureName, int pos, DetailComponentItemData componentItem) {
        if (!componentItem.hasTrack) {
            componentItem.hasTrack = true;
            String extra = CommonUtils.getDetailExtraValue(Constant.KEY_NONE, null, AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD, pos, null);
            PreciseTrackManager.onDetailTrack(TRAnalyticsConstant.DETAIL_PAGE, featureName, commonAppDetailView.mFrom,
                    commonAppDetailView.mAppInfo, extra, "", componentItem.nfAbId, componentItem.nfAbExpId);
        }
    }
}

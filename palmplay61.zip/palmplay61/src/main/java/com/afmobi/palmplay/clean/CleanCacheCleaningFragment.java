package com.afmobi.palmplay.clean;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.base.BaseEventFragment;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.clean.FlyingStar.FlyingStarView;
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.RankModel;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.ViewExtKt;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import java.util.List;

/**
 * 深度清理页面 清理中状态
 * Created by xiangfei.wei on 2017/12/1.
 */

public class CleanCacheCleaningFragment extends BaseEventFragment {

    private Activity mActivity;
    private TextView tv_size, tv_unit, tv_size_copy, tv_unit_copy;
    private FlyingStarView flyingStarView;
    private ImageView round_first, round_second, round_third, round_fifth, iv_rocket, iv_shield;
    private FrameLayout container_anim_view;
    private RelativeLayout rl_clean_bg, rl_size, rl_clean_bg_copy, rl_size_copy;
    private LinearLayout ll_recommend_container, ll_recommend_zone;
    private RecyclerView recommend_recycler;
    private TrHomeRecyclerViewAdapter mHomeRecyclerViewAdapter;

    private CleanCacheCleaningViewModel mCleanCacheCleaningViewModel;

    private long cacheSize;
    private List<RankModel> recommendList;

    private FeaturedModel mFeaturedModel;
    private final Runnable startFlyingStarAction = new Runnable() {
        @Override
        public void run() {
            flyingStarView.start();
        }
    };

    public static CleanCacheCleaningFragment newInstance() {
        return new CleanCacheCleaningFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = (Activity) context;
    }

    public void setCacheSize(long cacheSize) {
        this.cacheSize = cacheSize;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_clean_up_cleaning, container, false);
        rl_clean_bg = (RelativeLayout) contentView.findViewById(R.id.rl_clean_bg);

        tv_size = (TextView) contentView.findViewById(R.id.tv_size);
        tv_unit = (TextView) contentView.findViewById(R.id.tv_unit);
        String original = ProcessAndMemoryUtil.formatSizeKbMbGb(cacheSize, 1);
        if (original.endsWith("KB")) {
            tv_size.setText(original.substring(0, original.indexOf("KB")));
            tv_unit.setText("KB");
        } else if (original.endsWith("MB")) {
            tv_size.setText(original.substring(0, original.indexOf("MB")));
            tv_unit.setText("MB");
        } else if (original.endsWith("GB")) {
            tv_size.setText(original.substring(0, original.indexOf("GB")));
            tv_unit.setText("GB");
        } else if (original.endsWith("B")) {
            tv_size.setText(original.substring(0, original.indexOf("B")));
            tv_unit.setText("B");
        }
        flyingStarView = (FlyingStarView) contentView.findViewById(R.id.flyingStarView);
        flyingStarView.setDestX(DisplayUtil.getScreenWidthPx(mActivity) / 2);
        flyingStarView.setDrawableResource(R.drawable.img_accelerate_dot2);

        round_first = (ImageView) contentView.findViewById(R.id.round_first);
        round_second = (ImageView) contentView.findViewById(R.id.round_second);
        round_third = (ImageView) contentView.findViewById(R.id.round_third);
        round_fifth = (ImageView) contentView.findViewById(R.id.round_fifth);

        iv_rocket = (ImageView) contentView.findViewById(R.id.iv_rocket);
        container_anim_view = (FrameLayout) contentView.findViewById(R.id.container_anim_view);
        iv_shield = (ImageView) contentView.findViewById(R.id.iv_shield);

        rl_size = (RelativeLayout) contentView.findViewById(R.id.rl_size);
        rl_clean_bg_copy = (RelativeLayout) contentView.findViewById(R.id.rl_clean_bg_copy);
        rl_size_copy = (RelativeLayout) contentView.findViewById(R.id.rl_size_copy);
        ll_recommend_container = (LinearLayout) contentView.findViewById(R.id.ll_recommend_container);

        tv_size_copy = (TextView) contentView.findViewById(R.id.tv_size_copy);
        tv_unit_copy = (TextView) contentView.findViewById(R.id.tv_unit_copy);

        ll_recommend_zone = (LinearLayout) contentView.findViewById(R.id.ll_recommend_zone);
        recommend_recycler = (RecyclerView) contentView.findViewById(R.id.recommend_recyle);

        mPageParamInfo.setLastPage(PageConstants.Deep_Clean);
        mPageParamInfo.setCurPage(PageConstants.Deep_Clean_Finish);

        ViewExtKt.getStatusBarHeight(mActivity, statusBarHeight -> {
            View view = new View(mActivity);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    statusBarHeight);
            view.setLayoutParams(params);
            view.setBackgroundColor(getResources().getColor(R.color.color_0a9beb));
            try {
                ll_recommend_container.addView(view, 0);
            } catch (Throwable e) {
                //ignore
            }
            return null;
        });
        mCleanCacheCleaningViewModel = ViewModelProviders.of(getActivity()).get(CleanCacheCleaningViewModel.class);

        mCleanCacheCleaningViewModel.getFeaturedLiveData().observe(getActivity(), new Observer<FeaturedModel>() {
            @Override
            public void onChanged(FeaturedModel featuredModel) {
                if (featuredModel != null) {
                    mFeaturedModel = featuredModel;
                    if (mHomeRecyclerViewAdapter == null) {
                        showRecommendList(true);
                    }
                }
            }
        });

        initData();
        return contentView;
    }

    private void initData() {
        mCleanCacheCleaningViewModel.loadFeaturedData();
    }

    @Override
    public void onStart() {
        super.onStart();
        flyingStarView.removeCallbacks(startFlyingStarAction);
        if (View.VISIBLE == flyingStarView.getVisibility()) {
            flyingStarView.postDelayed(startFlyingStarAction, 300);

            Animation animRoundFirst = AnimationUtils.loadAnimation(mActivity, R.anim.anim_clean_up_round_first);
            animRoundFirst.setRepeatCount(Animation.INFINITE);
            animRoundFirst.setDuration(1000);
            animRoundFirst.setRepeatMode(Animation.REVERSE);
            round_first.startAnimation(animRoundFirst);
            Animation animRoundSecond = AnimationUtils.loadAnimation(mActivity, R.anim.anim_clean_up_round_second);
            animRoundSecond.setRepeatCount(Animation.INFINITE);
            animRoundSecond.setDuration(1500);
            animRoundSecond.setRepeatMode(Animation.REVERSE);
            round_second.startAnimation(animRoundSecond);
            Animation animRoundThird = AnimationUtils.loadAnimation(mActivity, R.anim.anim_clean_up_round_third);
            animRoundThird.setRepeatCount(Animation.INFINITE);
            animRoundThird.setDuration(1300);
            animRoundThird.setRepeatMode(Animation.REVERSE);
            round_third.startAnimation(animRoundThird);
            Animation animRoundFifth = AnimationUtils.loadAnimation(mActivity, R.anim.anim_clean_up_round_fifth);
            animRoundFifth.setRepeatCount(Animation.INFINITE);
            animRoundFifth.setDuration(1600);
            animRoundFifth.setRepeatMode(Animation.REVERSE);
            round_fifth.startAnimation(animRoundFifth);
            flyingStarView.postDelayed(cleaningAnimDelayAction, 3000);
        }
    }

    private Runnable cleaningAnimDelayAction = new Runnable() {
        @Override
        public void run() {
            onCleanComplete(0);
        }
    };

    @Override
    public void onStop() {
        flyingStarView.removeCallbacks(startFlyingStarAction);
        clearAnim();
        flyingStarView.removeCallbacks(cleaningAnimDelayAction);
        super.onStop();
    }

    private void clearAnim() {
        flyingStarView.cancel();
        round_first.clearAnimation();
        round_second.clearAnimation();
        round_third.clearAnimation();
        round_fifth.clearAnimation();
    }

    public void onCleanComplete(final long cacheSize) {
        clearAnim();
        flyingStarView.setVisibility(View.GONE);
        container_anim_view.setVisibility(View.GONE);
        iv_rocket.setVisibility(View.VISIBLE);
        Animation animator = AnimationUtils.loadAnimation(mActivity, R.anim.anim_rocket);
        animator.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                iv_rocket.setVisibility(View.GONE);
                iv_shield.setVisibility(View.VISIBLE);
                iv_shield.postDelayed(recommendContentAction, 2000);
                iv_shield.postDelayed(moveUpAnimationAction, 2500);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        iv_rocket.startAnimation(animator);
        animator.start();
    }

    private Runnable recommendContentAction = new Runnable() {
        @Override
        public void run() {
            joinRecommendedContent();
        }
    };

    private void joinRecommendedContent() {
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(mPageParamInfo);

        rl_clean_bg_copy.getLayoutParams().height = rl_clean_bg.getHeight() - DisplayUtil.dip2px(mActivity, 45);
        tv_size_copy.setText(tv_size.getText());
        tv_unit_copy.setText(tv_unit.getText());
        ll_recommend_container.setVisibility(View.VISIBLE);
        rl_clean_bg.setVisibility(View.GONE);

        showRecommendList(false);
    }

    private void showRecommendList(boolean isAll) {
        if (getActivity() == null || getActivity().isDestroyed() || getActivity().isFinishing()) {
            return;
        }
        if (mFeaturedModel != null && mFeaturedModel.featureList != null && mFeaturedModel.featureList.size() > 0) {
            ll_recommend_zone.setVisibility(View.VISIBLE);

            //加载推荐列表
            recommend_recycler.setVisibility(View.VISIBLE);
            LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false);
            recommend_recycler.setNestedScrollingEnabled(false);
            recommend_recycler.setLayoutManager(mLinearLayoutManager);

            if (mHomeRecyclerViewAdapter == null) {
                mHomeRecyclerViewAdapter = new TrHomeRecyclerViewAdapter(getActivity(), recommend_recycler, mLinearLayoutManager, null,null,
                        null, mPageParamInfo.getLastPage(), mPageParamInfo, false, 0, 0,false);
                mHomeRecyclerViewAdapter.setFrom(TRStringUtil.generateString(TRAnalyticsConstant.TOOLS, TRAnalyticsConstant.JUNK_FILE, "", ""));
                mHomeRecyclerViewAdapter.setCurScreenPage(TRAnalyticsConstant.JUNK_FILE);
                mHomeRecyclerViewAdapter.setFeatureName(TRAnalyticsConstant.JUNK_RECOMMOND);
                mHomeRecyclerViewAdapter.onCreateView();
            }
            if (isAll) {
                mHomeRecyclerViewAdapter.setData(mFeaturedModel.featureList, null,null,false,false, true);
            } else {
                mHomeRecyclerViewAdapter.setData(mFeaturedModel.featureList.subList(0,1), null,null,false,false, true);
            }
            recommend_recycler.setAdapter(mHomeRecyclerViewAdapter);
        }
    }

    private Runnable moveUpAnimationAction = new Runnable() {
        @Override
        public void run() {

            //推荐内容从底部滑出来；
            int originalValue = rl_clean_bg_copy.getLayoutParams().height;
            ValueAnimator anim = ValueAnimator.ofInt(originalValue, DisplayUtil.dip2px(mActivity, 151));
            anim.setDuration(1000);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    rl_clean_bg_copy.getLayoutParams().height = (int) valueAnimator.getAnimatedValue();
                    rl_clean_bg_copy.requestLayout();
                }
            });
            anim.addListener(new AnimatorListenerAdapter() {

                @Override
                public void onAnimationStart(Animator animation) {
                    super.onAnimationStart(animation);
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    //调整size显示控件的位置；
                    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) rl_size_copy.getLayoutParams();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        params.removeRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                        params.bottomMargin = 0;
                        params.topMargin = DisplayUtil.dip2px(mActivity, 35);// 80- 顶部title的45
                    } else {
                        params.bottomMargin = DisplayUtil.dip2px(mActivity, 35);
                    }
                    if (mHomeRecyclerViewAdapter != null && mFeaturedModel != null){
                        mHomeRecyclerViewAdapter.setData(mFeaturedModel.featureList, null,null,false,false, true);
                    }
                }
            });

            anim.start();
        }
    };


    @Override
    public void onDestroyView() {
        flyingStarView.removeCallbacks(startFlyingStarAction);
        clearAnim();
        flyingStarView.releaseView();
        iv_rocket.clearAnimation();
        flyingStarView.removeCallbacks(cleaningAnimDelayAction);
        iv_shield.removeCallbacks(recommendContentAction);
        iv_shield.removeCallbacks(moveUpAnimationAction);
        if (mHomeRecyclerViewAdapter != null) {
            mHomeRecyclerViewAdapter.onDestroy();
        }
        super.onDestroyView();
    }
}

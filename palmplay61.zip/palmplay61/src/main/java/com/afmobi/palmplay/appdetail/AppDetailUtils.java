package com.afmobi.palmplay.appdetail;

import android.app.Activity;
import android.text.TextUtils;
import android.view.Gravity;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.activate.TRActivateConstant;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.Code;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.OfferInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

public class AppDetailUtils {
    public static boolean isUseSmallCache(String mType) {
        if(TextUtils.isEmpty(mType)) {
            return false;
        }

        boolean ret = false;
        switch (mType) {
            case TRActivateConstant.SPLASH_AD:
            case TRActivateConstant.NAV_BAR_ACTIVATE:
            case TRActivateConstant.PUSH:
            case TRActivateConstant.TIP_ACTIVATE:
                ret = true;
                break;
            default:
                break;
        }

        return (ret);
    }

    public static boolean isTakeDown(int code, AppInfo mAppInfo) {
        boolean ret = true;

        if (code == Code.CODE_506_NEGATIVE){
            return true;
        }

        if (mAppInfo == null || TextUtils.isEmpty(mAppInfo.packageName) || mAppInfo.itemCheckFlag) {
            return false;
        }

        int status = mAppInfo.observerStatus;

        if (status == FileDownloadInfo.STATUS_DOWNLOADED || status == FileDownloadInfo.STATUS_APP_INSTALLED) {
            return false;
        }

        if (status == FileDownloadInfo.STATUS_WAIT || status == FileDownloadInfo.STATUS_PAUSE || status == FileDownloadInfo.STATUS_DOWNING) {
            FileDownloadInfo info = DownloadManager.getInstance().getDownloadingInfo(mAppInfo.packageName);
            if (info != null && !TextUtils.isEmpty(info.downloadUrl)) {
                ret = false;
            }
        }

        return ret;
    }

    public static void checkFdr(String mFrom){
    }

    public static OfferInfo getOfferInfo(AppInfo mAppInfo, boolean isCustomized) {
        OfferInfo mOfferInfo = new OfferInfo();
        if(mAppInfo != null && isCustomized) {
            mOfferInfo.convertData(mAppInfo);
            mOfferInfo.setCustomized(isCustomized);
        }
        return mOfferInfo;
    }

}

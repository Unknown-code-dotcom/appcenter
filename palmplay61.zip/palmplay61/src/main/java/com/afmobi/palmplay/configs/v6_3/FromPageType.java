package com.afmobi.palmplay.configs.v6_3;

/**
 * Created by zz on 2016/11/15.
 */

public interface FromPageType {

    String Banner = "Banner";

    String Rank = "Rank";//, 2) ,

    String Category = "Category";//, 3),

    String Message = "Message";//, 4),

    String Notify = "Notify";//, 5),

    String Search = "Search";//, 6),

    String Detail = "Detail";//, 7),

    String Home = "Home";//, 8),

    String RecommendInstall = "RecommendInstall";//, 9),

    //add Palmplay6.4 20170320 begin
    String Share_Link = "Share_Link";//, 10),
    String Scan_Local = "Scan_Local";//, 11)，
    String MustInstall = "necessary_popup";//, 12) ; 装机必备
    //add Palmplay6.4 20170320 end

    String Pluto = "Pluto";
    String NewRecommend = "NewRecommend";
    String PlayAutoInstall = "PAI";  //云预装
    String VAGAME = "VA";  //VAGAME
}

package com.afmobi.palmplay.cloudfolder.adapter

import android.graphics.Rect
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.transsnet.launcherlib.model.FileFolderData
import com.transsnet.store.R

class CloudFolderPagerAdapter(private val categoryType: Int,
    private val items: List<List<FileFolderData.DataItem.AppBottomInfo>>
) : RecyclerView.Adapter<CloudFolderPagerAdapter.ViewHolder>() {

    inner class ViewHolder(parent: ViewGroup) : RecyclerView.ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.cloud_item_bottom_viewpager, parent, false)
    ) {
        val recyclerView: RecyclerView = itemView.findViewById(R.id.pageRecyclerView)

        init {
            applyPadPageWidth()
            // 初始化每个页面中的RecyclerView
            recyclerView.layoutManager = LinearLayoutManager(
                parent.context,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            recyclerView.addItemDecoration(ItemDecoration())
            recyclerView.adapter = CloudBottomItemAdapter(categoryType, emptyList())
        }

        fun bind(index: Int, items: List<FileFolderData.DataItem.AppBottomInfo>) {
            applyPadPageWidth()
            (recyclerView.adapter as CloudBottomItemAdapter).updateItems(index, items)
        }

        private fun applyPadPageWidth() {
            val deviceProfile = DeviceProfile.getInstance()
            if (!deviceProfile.isPadLayout) return
            itemView.layoutParams = itemView.layoutParams.apply {
                width = 4 * deviceProfile.bottomIconItemWidth + 3 * deviceProfile.bottomIconGap
            }
        }
    }

    class ItemDecoration : RecyclerView.ItemDecoration() {

        private val itemCount = 4

        override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
            super.getItemOffsets(outRect, view, parent, state)

            val deviceProfile = DeviceProfile.getInstance()
            val position = parent.getChildAdapterPosition(view)
            if (deviceProfile.isPadLayout) {
                if (position > 0) {
                    outRect.left = deviceProfile.bottomIconGap
                }
                return
            }

            // 计算每个条目的左右间距
            // 总间距平均分配到所有条目之间（包括首尾）
            val eachSpace: Int = deviceProfile.folderBottomSpace

            // 第一个条目的左间距为eachSpace，右间距为eachSpace
            when (position) {
                0 -> {
                    outRect.right = eachSpace
                }
                itemCount - 1 -> {
                    outRect.left = eachSpace + deviceProfile.folderBottomExtraSpace
                }
                else -> {
                    outRect.left = eachSpace + deviceProfile.folderBottomExtraSpace
                    outRect.right = eachSpace
                }
            }

            // 手机保持现有的动态 item 宽度策略。
            view.layoutParams.width = deviceProfile.folderBottomItemWidth
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(parent)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // 计算实际位置，实现无限循环
        val realPosition = position % items.size
        holder.bind(position, items[realPosition])
    }

    override fun getItemCount(): Int {
        // 使用一个较大的值实现无限循环效果
        return items.size
    }
}

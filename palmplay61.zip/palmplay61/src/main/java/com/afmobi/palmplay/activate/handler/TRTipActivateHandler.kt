package com.afmobi.palmplay.activate.handler

import android.app.Activity
import android.content.DialogInterface
import android.view.View
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.TRTipActivateExecutor
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.activate.state.ShowStateManager.Companion.getInstance
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.switchcountry.SwitchCountryManager
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.log.LogUtils

class TRTipActivateHandler(
    executor: TRTipActivateExecutor?,
    sceneName: String,
    priority: TRPriority,
    popupType: TRPopupType
) :
    TRChainHandler(sceneName, priority, popupType) {
    private var mExecutor: TRBaseExecutor<*>? = executor

    init {
        mExecutor = executor
    }

    override fun canShow(fromType: String?): Boolean {
        if (mExecutor == null) {
            LogUtils.d(TRNewManager.TAG, "canShow -> ${sceneName} mExecutor= null, return")
            return false
        }

        if (mExecutor!!.isPromptTip) {
            mExecutor!!.showOthers()
            reason = "TipActivate others show called";
            TRAnalysticsUtil.trackPopSenceInfo(reason, fromType, sceneName)
            return false
        }
        return  mExecutor!!.isCanShow(fromType)
    }

    override fun show(fromType: String?): Boolean {
        if (SwitchCountryManager.getInstance().isCanShowSimSwitchCountry) {
            return false
        }
        if(canShow(fromType)) {
            return mExecutor!!.show(fromType)
        }
        return false
    }

    override fun showNext(fromType: String?): Boolean {
        if(AtyManager.getAtyManager().currentActivity != curActivity?.get()) {
            LogUtils.d(TRNewManager.TAG, "showNext -> ${sceneName} activity is not current activity, return")
            return false
        }
        if(canShow(fromType)) {
            LogUtils.d(TRNewManager.TAG, "showNext -> ${sceneName} can not show, return")
            return mExecutor?.show(fromType) == true
        }
        return false
    }

    override fun showing(): Boolean {
        return false
    }

    override fun getExecutor(): TRBaseExecutor<*>? {
        return mExecutor
    }

}

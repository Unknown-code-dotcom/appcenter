package com.afmobi.palmplay.category;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.main.adapter.v6_3.CommonSoftRecyclerAdapter;
import com.afmobi.palmplay.main.dialog.TipNetworkDialog;
import com.afmobi.palmplay.main.fragment.v6_3.BaseChildrenTabFragment;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CategoryListData;
import com.afmobi.palmplay.model.TagItemList;
import com.afmobi.palmplay.viewmodel.BaseChildrenTabViewModel;
import com.afmobi.palmplay.viewmodel.category.CategoryTabViewModel;
import com.afmobi.util.Constant;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.FragmentCategoryTabListBinding;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

/**
 * @author: zhiqiang.hao
 * @date: 2021/3/11 16:25
 * @Desc: 分类页Fragment
 */
public class CategoryTabFragment extends BaseChildrenTabFragment<CategoryListData> implements OnViewLocationInScreen {

    private static final String TAG = "CategoryTabFragment";
    private FragmentCategoryTabListBinding mDataBindingImpl;
    private String mCategoryTag = Constant.CATEGORY_HOT;
    private CommonSoftRecyclerAdapter mCommonSoftRecyclerAdapter;
    private TagItemList<AppInfo> mCategoryAppTagItemList = new TagItemList<>();

    private String mValue;
    private String mFrom;
    private String mCurrentPage;
    private boolean mSwitchTag = false;
    private Typeface mTypefaceMedium;
    private Typeface mTypefaceNormal;

    private int mPosition;
    public static boolean sIsFirstTime = true;
    private boolean mEqualsStatus = true;
    private boolean hasTrack = false;

    private String mCurTabName ="";
    public static CategoryTabFragment newInstance(String tabType, String tabSubId) {
        Bundle args = new Bundle();
        CategoryTabFragment fragment = new CategoryTabFragment();
        args.putString(Constant.SOFTTYPE, tabType);
        args.putString(Constant.SOFTSUBTYPE, tabSubId);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected void getArgParams() {
        super.getArgParams();
    }

    @Override
    protected void initView() {

        if (getActivity() != null) {
            mPageParamInfo.setCurPage(mCurrentPage);
            mPageParamInfo.setLastPage(((CategoryActivity) getActivity()).getLastPage());
        }

        mTypefaceMedium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        mTypefaceNormal = Typeface.create("sans-serif", Typeface.NORMAL);

        mDataBindingImpl.layoutLoadingGif.setVisibility(View.VISIBLE);
        mDataBindingImpl.rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                boolean checkNet = checkNet();
                if (!checkNet) {
                    return;
                }

                if (checkedId == R.id.rb_new) {
                    mCategoryTag = Constant.CATEGORY_NEW;
                    mDataBindingImpl.rbNew.setTypeface(mTypefaceMedium, Typeface.NORMAL);
                    mDataBindingImpl.rbHot.setTypeface(mTypefaceNormal, Typeface.NORMAL);
                } else {
                    mCategoryTag = Constant.CATEGORY_HOT;
                    mDataBindingImpl.rbHot.setTypeface(mTypefaceMedium, Typeface.NORMAL);
                    mDataBindingImpl.rbNew.setTypeface(mTypefaceNormal, Typeface.NORMAL);
                }
                mSwitchTag = true;

                mCommonSoftRecyclerAdapter.setCategoryTag(mCategoryTag);
                if (baseChildrenTabViewModel == null) {
                    baseChildrenTabViewModel = createViewModel();
                }
                ((CategoryTabViewModel) baseChildrenTabViewModel).setCategoryTag(mCategoryTag, true);
                loadData(false);

                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(mValue)
                        .setFrom(mFrom)
                        .setTopicType("")
                        .setTopicId(tabTopId)
                        .setItemType("")
                        .setItemId("")
                        .setButtonType(mCategoryTag)
                        .setItemValue("")
                        .setExtraValue(mCurTabName);
                TRAnalysticsUtil.trackClick(builder);

            }
        });

        TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mDataBindingImpl.xrecyclerview.setLayoutManager(linearLayoutManager);
        mDataBindingImpl.xrecyclerview.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
        mDataBindingImpl.xrecyclerview.isHeaderRefreshLayoutLimitHeight(true);
        mDataBindingImpl.xrecyclerview.setLoadingListener(mXRecyclerViewLoadingListener);
        mCommonSoftRecyclerAdapter = new CommonSoftRecyclerAdapter(getActivity(), mCategoryAppTagItemList.itemList, mDataBindingImpl.xrecyclerview, getFromPage(), mPageParamInfo, true, false, true);
        mCommonSoftRecyclerAdapter.setItemBgResId(android.R.color.transparent, false);
        mDataBindingImpl.xrecyclerview.setAdapter(mCommonSoftRecyclerAdapter);
        RecyclerView.ItemAnimator animator = mDataBindingImpl.xrecyclerview.getItemAnimator();
        if(animator instanceof SimpleItemAnimator) {
            SimpleItemAnimator simpleItemAnimator = (SimpleItemAnimator)animator;
            simpleItemAnimator.setSupportsChangeAnimations(false);
        }
        mCommonSoftRecyclerAdapter.setScreenPageName(getCurrentPage());
        mCommonSoftRecyclerAdapter.setCategoryTag(mCategoryTag);
        mCommonSoftRecyclerAdapter.setOnViewLocationInScreen(this);
        mCommonSoftRecyclerAdapter.setIMessenger(new IMessenger() {
            @Override
            public void onMessenger(Object... objects) {
                try {
                    if (getActivity() != null) {
                        ((CategoryActivity) getActivity()).refreshDownLoadCount();
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }
        });
        mCommonSoftRecyclerAdapter.onCreateView();
        mCommonSoftRecyclerAdapter.setFrom(mFrom);
        mCommonSoftRecyclerAdapter.setScreenPageName(mCurrentPage);
        addNoMore(mDataBindingImpl.xrecyclerview, linearLayoutManager, null);

        addRecycylerViewScrollListener(mDataBindingImpl.xrecyclerview);

    }

    private String generateValue() {
        if (TextUtils.isEmpty(mCurrentPage)) {
            mCurrentPage = getCurrentPage();
        }
        return TRStringUtil.generateString(mCurrentPage, "", "", "");
    }

    private String getCurrentPage() {
        String categoryPage = "";
        if (Constant.SOFTTYPE_APP.equals(tabType)) {
            categoryPage = TRAnalyticsConstant.APP_CATEGORY;
        } else {
            categoryPage = TRAnalyticsConstant.GAME_CATEGORY;
        }
        return categoryPage;
    }


    @Override
    protected void onRefreshComplete() {
        mDataBindingImpl.xrecyclerview.refreshComplete();
    }

    @Override
    protected void onLoadMoreComplete() {
        mDataBindingImpl.xrecyclerview.loadMoreComplete();
    }

    @Override
    protected void onSetNoMore(boolean noMore) {
        mDataBindingImpl.xrecyclerview.setNoMore(noMore);
    }

    private XRecyclerView.LoadingListener mXRecyclerViewLoadingListener = new XRecyclerView.LoadingListener() {
        @Override
        public void onRefresh() {
            boolean checkNet = checkNet();
            if (checkNet) {
                refreshData();
            }
        }

        @Override
        public void onLoadMore() {
            boolean checkNet = checkNet();
            if (checkNet){
                loadData(true);
            }
        }
    };

    private boolean checkNet(){
        if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
            TipNetworkDialog  tipNetworkDialog = TipNetworkDialog.getDialog(getActivity());
            if (tipNetworkDialog != null) {
                if (!tipNetworkDialog.isShow()) {
                    ToastManager.getInstance().show(getActivity(), R.string.tip_no_network);
                }
            }
            if (mDataBindingImpl.xrecyclerview != null) {
                mDataBindingImpl.xrecyclerview.loadMoreComplete();
            }
            mDataBindingImpl.xrecyclerview.setVisibility(View.GONE);

            return false;
        } else {
            mDataBindingImpl.xrecyclerview.setVisibility(View.VISIBLE);
            return true;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onResume();
    }


    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onDestroy();

        if (mDataBindingImpl.xrecyclerview != null) {
            mDataBindingImpl.xrecyclerview.loadMoreComplete();
            mDataBindingImpl.xrecyclerview.refreshComplete();
        }
        mXRecyclerViewLoadingListener = null;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            //屏蔽 点击非第一个fragment时，第一个fragment上报的埋点
            if (mPosition == 0 && !mEqualsStatus && sIsFirstTime) {
                sIsFirstTime = false;
            } else {
                if (!hasTrack) {
                    hasTrack = true;

                    PagePvBuilder pagePvBuilder = new PagePvBuilder();
                    pagePvBuilder.setValue(mValue)
                            .setFrom(mFrom).setGetTopicType(mCategoryTag).setTopicId(tabTopId).setItemType(mCurTabName);
                    TRAnalysticsUtil.trackPV(pagePvBuilder);
                }
            }
        }
    }

    @Override
    protected void lazyInit() {

    }


    @Override
    protected BaseChildrenTabViewModel createViewModel() {
        CategoryTabViewModel categoryTabViewModel = ViewModelProviders.of(this).get(CategoryTabViewModel.class);
        categoryTabViewModel.setCategoryType(getTabType());
        categoryTabViewModel.setCategoryId(getTabID());
        categoryTabViewModel.setCategoryTag(mCategoryTag, false);
        categoryTabViewModel.setFrom(mFrom);
        return categoryTabViewModel;
    }

    @Override
    protected ViewDataBinding createDataBinding(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mDataBindingImpl = DataBindingUtil.inflate(inflater, R.layout.fragment_category_tab_list, container, false);
        return mDataBindingImpl;
    }

    @Override
    public void onDataReceived(CategoryListData data) {
        mDataBindingImpl.layoutLoadingGif.setVisibility(View.GONE);

        if (data != null) {
            if (null != mCommonSoftRecyclerAdapter) {
                mCommonSoftRecyclerAdapter.setData(data.itemList);
                if (mSwitchTag) {
                    mDataBindingImpl.xrecyclerview.scrollToPosition(0);
                }
            }
        }
        mSwitchTag = false;
        if (mDataBindingImpl.rg.getVisibility() != View.VISIBLE) {
            mDataBindingImpl.rg.setVisibility(View.VISIBLE);
        }
        refreshUI();
    }

    public void setCategoryType(String type) {
        tabType = type;
        mCurrentPage = getCurrentPage();
        mValue = generateValue();
    }

    public void setCategoryId(String categoryId) {
        tabTopId = categoryId;
    }

    public void setCategoryName(String curTabName) {
        mCurTabName = curTabName;
    }

    public void setEqualsStatus(boolean status) {
        mEqualsStatus = status;
    }

    public void setCurrentPosition(int position) {
        mPosition = position;
    }

    public void setFrom(String from) {
        mFrom = from;
    }



    /**************************** for animation start *********************************/
    @Override
    public Object onPreparedCallback(Object obj) {
        return obj;
    }

    @Override
    public Object getObject(Object obj) {
        View v = null;
        try {
            if (getActivity() != null) {
                v = ((CategoryActivity) getActivity()).getIvDownLoad();
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return v;
    }

    @Override
    public int[] onEndTranslateAnimationLocationOnScreen(Object obj) {

        int[] endTranslateAnimationLocationOnScreen = new int[2];
        try {
            if (getActivity() != null) {
                endTranslateAnimationLocationOnScreen = ((CategoryActivity) getActivity()).getIvDownLoadPosition();
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return endTranslateAnimationLocationOnScreen;
    }

    @Override
    public Object onAnimationEndCallback(Object obj) {
        return obj;
    }


    /**************************** for animation end *********************************/
}

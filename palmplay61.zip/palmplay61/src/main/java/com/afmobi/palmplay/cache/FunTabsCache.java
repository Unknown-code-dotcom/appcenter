// TOP SECRET
package com.afmobi.palmplay.cache;


import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.FunTabItem;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.log.LogUtils;

import java.util.ArrayList;
import java.util.List;


public class FunTabsCache implements LocalCache {

    private static final String CACHE_URI = "Fun_TABS_CACHE";

    private static volatile FunTabsCache mCache;
    private static byte[] lock = new byte[0];

    private List<FunTabItem> listStartUpTabs = new ArrayList<FunTabItem>();

    private FunTabsCache() {
        loadFromCache();
    }

    public static FunTabsCache getInstance() {
        if (mCache == null) {
            synchronized (lock) {
                if (mCache == null) {
                    mCache = new FunTabsCache();
                }
            }
        }
        return mCache;
    }

    public void release() {
        listStartUpTabs.clear();
        mCache = null;
    }

    public void initPageCaches(JsonElement jsonElement, boolean isFromNetworkRequest) {

        if (jsonElement == null || !jsonElement.isJsonObject()) {
            return;
        }

        listStartUpTabs.clear();

        Gson gson = new Gson();

        JsonObject jo = (JsonObject) jsonElement;

        if (jo != null) {
            try {
                if (jo.has("tabData")) {
                    JsonElement tabJsonElement = jo.get("tabData");
                    if (tabJsonElement != null && tabJsonElement.isJsonArray()) {
                        java.lang.reflect.Type listType = new TypeToken<ArrayList<FunTabItem>>() {
                        }.getType();
                        ArrayList<FunTabItem> list = gson.fromJson(tabJsonElement, listType);
                        listStartUpTabs.addAll(list);
                    }
                }
            } catch (Exception e) {
                LogUtils.e(e);
            }
        }


        if (isFromNetworkRequest) {
            saveToCache(jsonElement.toString());
        }

    }

    @Override
    public String getFileName(Object... objects) {
        return CACHE_URI;
    }

    @Override
    public void saveToCache(String jsonBuffer, Object... objects) {
        String fileName = getFileName();

        if (fileName != null) {
            FilePathManager.jsonToFile(jsonBuffer, fileName);
        }

    }

    @Override
    public void loadFromCache(Object... objects) {
        String fileName = getFileName();

        JsonElement jsonObject = FilePathManager.fileToJson(fileName);

        if (jsonObject != null) {
            //initPageCaches(jsonObject, false);
        }
    }

    public List<FunTabItem> getFunTabs() {
        return listStartUpTabs;
    }
}

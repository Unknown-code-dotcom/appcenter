package com.afmobi.palmplay.appmanage.dialog;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;

import com.afmobi.util.PadUtils;
import com.transsion.palmstorecore.util.ApiUExtKt;
import com.transsnet.store.R;

/**
 * APP正在安装中的提示
 * Created by xiangfei.wei on 2017/8/1.
 */

public class InstallingDialog extends AlertDialog {
    private InstallingDialogReceiver mInstallingDialogReceiver;

    public InstallingDialog(@NonNull Context context) {
        super(context);

    }

    public InstallingDialog(@NonNull Context context, @StyleRes int themeResId) {
        super(context, themeResId);
        IntentFilter filter = new IntentFilter(
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        mInstallingDialogReceiver = new InstallingDialogReceiver();
        ApiUExtKt.registerReceiverExported(mInstallingDialogReceiver, getContext(), filter);
    }

    public InstallingDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_installing);
    }

    /**
     * 当Dialog的window type 设置为系统弹框的时候，Dialog出现后，点击物理home键会失效，但是系统会发出广播事件，所以定义接收者处理点击home的情况；
     */
    private class InstallingDialogReceiver extends BroadcastReceiver {
        final String SYSTEM_DIALOG_REASON_KEY = "reason";
        final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";

        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_CLOSE_SYSTEM_DIALOGS.equals(intent.getAction())) {
                String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
                if (SYSTEM_DIALOG_REASON_HOME_KEY.equals(reason)) {
                    getContext().unregisterReceiver(mInstallingDialogReceiver);
                    InstallingDialog.this.dismiss();
                }
            }

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        PadUtils.applyPadDialog(this);
    }

}

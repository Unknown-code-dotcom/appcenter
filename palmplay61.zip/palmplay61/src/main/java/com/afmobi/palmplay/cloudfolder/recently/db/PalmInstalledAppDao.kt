package com.afmobi.palmplay.cloudfolder.recently.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PalmInstalledAppDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOrUpdate(entity: PalmInstalledAppEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertIfAbsent(entity: PalmInstalledAppEntity): Long

    @Query("SELECT * FROM installed_apps_history WHERE packageName = :pkg LIMIT 1")
    fun queryByPackage(pkg: String): PalmInstalledAppEntity?

    /**
     * 查询 30 天内 全新安装（isUpdate=0） 的记录，按 installedTime 倒序
     */
    @Query("SELECT * FROM installed_apps_history WHERE isUpdate = 0 AND installedTime >= :since ORDER BY installedTime DESC")
    fun queryRecentFreshInstalled(since: Long): List<PalmInstalledAppEntity>

    @Query("DELETE FROM installed_apps_history WHERE packageName = :pkg")
    fun deleteByPackage(pkg: String)

    /** 查询安装时间早于 :before 的所有过期记录（用于过期清理前的逐条上报） */
    @Query("SELECT * FROM installed_apps_history WHERE installedTime < :before")
    fun selectExpired(before: Long): List<PalmInstalledAppEntity>

    @Query("DELETE FROM installed_apps_history WHERE installedTime < :before")
    fun deleteExpired(before: Long)
}

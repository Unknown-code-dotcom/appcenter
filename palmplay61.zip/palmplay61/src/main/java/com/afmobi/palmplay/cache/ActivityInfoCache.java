package com.afmobi.palmplay.cache;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.v7_x.ActivityInfo;
import com.afmobi.util.Constant;

public class ActivityInfoCache{

    public static final String ACTIVITY_INFO_CACHE = "ACTIVITY_INFO_CACHE";

    private static final int CHECK_SYSTEM_MESSAGE_SPACE = 4 * 60 * 60 * 1000;

    private long mLastCheckMessageTimeMillis = 0;

    private static ActivityInfoCache mInstance;

    public static ActivityInfoCache getInstance() {
        if (mInstance == null) {
            synchronized (ActivityInfoCache.class) {
                if (mInstance == null) {
                    mInstance = new ActivityInfoCache();
                }
            }
        }

        return mInstance;
    }

    public boolean isNeedRequestMessage() {
        long curTimeMillis = System.currentTimeMillis();
        long lastCheckMessageTimeMillis = SPManager.getLong(Constant.preferences_key_activity_info_resp, 0);
        if ((curTimeMillis - lastCheckMessageTimeMillis) >= CHECK_SYSTEM_MESSAGE_SPACE) {
            return true;
        }
        return false;
    }

//    public void saveToCacheNotify(ActivityInfo activityInfo) {
//        ACache.get(PalmplayApplication.getAppInstance()).put(ACTIVITY_INFO_CACHE, activityInfo);
//        //通知页面更新
//        EventMainThreadEntity mEventMainThreadEntity = new EventMainThreadEntity();
//        mEventMainThreadEntity.setAction(NetworkActions.GET_ACTIVITY_INFO_SUCCESS);
//        EventBus.getDefault().post(mEventMainThreadEntity);
//    }

    public ActivityInfo loadFromCache() {
        Object object = ACache.get(PalmplayApplication.getAppInstance()).getAsObject(ACTIVITY_INFO_CACHE);
        if(object != null && object instanceof ActivityInfo){
            return (ActivityInfo)object;
        }
        return null;
    }

}

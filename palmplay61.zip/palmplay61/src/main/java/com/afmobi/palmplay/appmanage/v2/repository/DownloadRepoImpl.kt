package com.afmobi.palmplay.appmanage.v2.repository

import android.text.TextUtils
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.appmanage.v2.model.DownloadStatus
import com.afmobi.palmplay.appmanage.v2.model.REFRESH_ALL
import com.afmobi.palmplay.appmanage.v2.model.REFRESH_BTN_TYPE
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.download.InterfaceBatchStatusChange
import com.afmobi.palmplay.download.InterfaceBatchStatusWithImageUrlChange
import com.afmobi.palmplay.main.utils.NOTIFY_ID_INSTALL_APP_LIST
import com.afmobi.palmplay.manager.FilePathManager
import com.afmobi.palmplay.model.SimpleDataInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.notify.db.NotifyInstallCompleteDatabase
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler
import com.afmobi.palmplay.va.proxy.VaStaticProxy
import com.afmobi.palmplay.pet.manager.XMPetSwitcher
import com.afmobi.util.CommonUtils
import com.afmobi.util.Constant
import com.afmobi.util.NotificationUtil
import com.trans.common.map.FlowMapManager
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.internal.filterList
import java.io.File

/**
 * 下载管理数据仓库实现类
 * 封装所有数据源访问逻辑
 */
class DownloadRepoImpl() : DownloadRepo {

    companion object {
        private const val TAG = "DownloadRepo"
    }

    private val flowManager = FlowMapManager<String, DownloadStatus>()
    private val refreshFlow =
        MutableSharedFlow<String>(1, 2, onBufferOverflow = BufferOverflow.SUSPEND)

    // 下载状态监听器
    private var statusChangeListener: InterfaceBatchStatusChange? = null

    init {
        // 注册下载状态监听器
        registerDownloadStatusListener()
    }

    /**
     * 获取下载中的任务列表
     * @return 下载中任务列表
     */
    override suspend fun getDownloadingList(): List<FileDownloadInfo> {
        // 不包含va
        val downloadingInfoList = DownloadManager.getInstance().getShadowDownloadingInfoListNoVa()
        val downloadingList = downloadingInfoList.filterList {
            // 过滤不可下载应用，以及副玩法 APK
            !(extraInfo != null && !extraInfo.itemCheckFlag && !extraInfo.canRetry)
                && !isPetPrivateApp(packageName)
        }
        return downloadingList
    }

    override suspend fun getDownloadedList(): List<FileDownloadInfo> {
        val downloadedInfoList = DownloadManager.getInstance().shadowDownloadedInfoList
        if (downloadedInfoList.isNullOrEmpty()) {
            return emptyList()
        }

        val needRemoveList = mutableListOf<FileDownloadInfo>()
        for (fileDownloadInfo in downloadedInfoList) {
            if (fileDownloadInfo.isVa) {
                // 已下载好未安装的va应用，不显示在下载中心
                needRemoveList.add(fileDownloadInfo)
            } else {
                // 下载好的文件已经不存在的，要从下载历史中移除掉
                if (!downloadedFileIsExist(fileDownloadInfo)) {
                    needRemoveList.add(fileDownloadInfo)
                }
            }
        }
        DownloadManager.getInstance().removeDownloadedInfos(needRemoveList)
        downloadedInfoList.removeAll(needRemoveList)

        if (downloadedInfoList.isEmpty()) {
            NotificationUtil.cancelNotification(
                PalmplayApplication.getAppInstance(),
                NOTIFY_ID_INSTALL_APP_LIST
            )
        }
        PalmstoreSysHandler.startService(
            PalmplayApplication.getAppInstance(),
            PalmstoreSysHandler.ACION_NOTIFICATION_CHECK_APP_DOWNLOADED
        )
        PalmstoreSysHandler.startService(
            PalmplayApplication.getAppInstance(),
            PalmstoreSysHandler.ACTION_NOTIFICATION_CHECK_APP_DOWNLOADING
        )
        val result = mutableListOf<FileDownloadInfo>()
        if (downloadedInfoList.isNotEmpty()) {
            for (item in downloadedInfoList) {
                if (!item.isVa) {
                    if (item.isDeletedTag == 1) {
                        continue
                    }
                    // 过滤掉再次安装失败的数据
                    if (item.extraInfo.isRetryInstallFail) {
                        continue
                    }
                    result.add(0, item)
                }
            }
        }
        return result.filterNot { isPetPrivateApp(it.packageName) }
    }

    override suspend fun getInstalledList(): List<FileDownloadInfo> {
        val installedList = DownloadManager.getInstance().installedInfoList
        val result = mutableListOf<FileDownloadInfo>()

        if (!installedList.isNullOrEmpty()) {
            for (fileDownloadInfo in installedList) {
                // 屏蔽PalmSpace
                if (VaStaticProxy.isInstantPluginApp(fileDownloadInfo.packageName)) {
                    continue
                }
                if (isPetPrivateApp(fileDownloadInfo.packageName)) {
                    continue
                }
                if (!fileDownloadInfo.isVa) {
                    result.add(fileDownloadInfo)
                }
            }
        }

        return result
    }

    override suspend fun getNoResList(): List<FileDownloadInfo> {
        return DownloadManager.getInstance().shadowErrorListWithoutVa
            .filterNot { isPetPrivateApp(it.packageName) }
    }

    override suspend fun getSavedDataList(): List<SimpleDataInfo> {
        return NotifyInstallCompleteDatabase.getDatabase(PalmplayApplication.getAppInstance())
            .savedDataDao.getSimpleDataList(Constant.SAVED_DATA_LIST_MAX)
    }

    override fun deleteNoResTask(info: FileDownloadInfo) {
        val errorType = TRAnalyticsConstant.APP_DOWNLOAD_USER_DELETE
        PalmplayApplication.getAppInstance()
            .appDataManager.recordDownladFailsInfo(errorType, info.packageName, "", true)

        CommonUtils.updateDownloadServiceStatus()
        if (VaStaticProxy.isInstantPluginApp(info.packageName)) {
            VaStaticProxy.disagree(info.packageName)
        }

        if ((info.isGrp && FileDownloadInfo.STATUS_DOWNLOADED == info.downloadStatus) || (info.extraInfo != null && info.extraInfo.isRetryInstallFail)) {
            DownloadManager.getInstance().removeDownloadedInfo(info.packageName)
        } else {
            DownloadManager.getInstance().onDownloadingCancel(info.packageName)
        }
    }

    override fun isExistDownloading(downloadingList: List<FileDownloadInfo>): Boolean {
        if (downloadingList.isEmpty()) {
            return false
        }

        for (downloadInfo in downloadingList) {
            if (downloadInfo.isVa) {
                continue
            }
            if (FileDownloadInfo.isDownloading(downloadInfo.downloadStatus)) {
                return true
            }
        }
        return false
    }

    override fun isExistUnDownload(downloadingList: List<FileDownloadInfo>): Boolean {
        if (downloadingList.isEmpty()) return false
        var isExistUnDownload = false
        for (info in downloadingList) {
            if (info.isVa) {
                continue
            }
            if (info.downloadStatus == FileDownloadInfo.STATUS_PAUSE || info.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR) {
                isExistUnDownload = true
                break
            }
        }
        return isExistUnDownload
    }

    override fun getRefreshFlow() = refreshFlow.asSharedFlow()

    override fun getProgressFlow(packageName: String): SharedFlow<DownloadStatus> {
        return flowManager.getOrCreateFlow(packageName).asSharedFlow()
    }

    override fun registerDownloadStatusListener() {
        statusChangeListener = object : InterfaceBatchStatusWithImageUrlChange {
            override fun onIconUrlUpdated(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onIconUrlUpdated:" + downloadInfo?.packageName)
                downloadInfo?.packageName ?: return
                val event = DownloadStatus(downloadInfo = downloadInfo)
                val flow = flowManager.getOrCreateFlow(downloadInfo.packageName)
                flow.tryEmit(event)
                flowManager.notifyActive(downloadInfo.packageName)
            }

            override fun onDownloadStart(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onDownloadStart:" + downloadInfo?.packageName)
                downloadInfo?.packageName ?: return
                updateInfoFlow(downloadInfo)
            }

            override fun onDownloadResume(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onDownloadResume:" + downloadInfo?.packageName)
                downloadInfo?.packageName ?: return
                updateInfoFlow(downloadInfo)
                refreshFlow.tryEmit(REFRESH_BTN_TYPE)
            }

            override fun onDownloadBatchResume(downloadInfoList: MutableList<FileDownloadInfo?>?) {
//                LogUtils.i(TAG, "onDownloadBatchResume:" + downloadInfoList?.size)
                downloadInfoList?.forEach { downloadInfo ->
                    updateInfoFlow(downloadInfo)
                }
                refreshFlow.tryEmit(REFRESH_BTN_TYPE)
            }

            override fun onDownloadBatchPause(downloadInfoList: MutableList<FileDownloadInfo?>?) {
//                LogUtils.i(TAG, "onDownloadBatchPause:" + downloadInfoList?.size)
                downloadInfoList?.forEach { downloadInfo ->
                    updateInfoFlow(downloadInfo)
                }
                refreshFlow.tryEmit(REFRESH_BTN_TYPE)
            }

            override fun onDownloadProgressUpdate(
                downloadInfo: FileDownloadInfo?,
                downloadedBytes: Long,
                fileLength: Long,
                speed: Int
            ) {
                // 进度更新不需要全量刷新
                downloadInfo?.packageName ?: return
                val event = DownloadStatus(
                    downloadInfo = downloadInfo,
                    speed = speed
                )
                val flow = flowManager.getOrCreateFlow(downloadInfo.packageName)
                flow.tryEmit(event)
                flowManager.notifyActive(downloadInfo.packageName)
//                LogUtils.i(TAG, "onDownloadProgressUpdate:" + downloadInfo.packageName)
            }

            override fun onDownloadPause(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onDownloadPause:" + downloadInfo?.packageName)
                downloadInfo?.packageName ?: return
                if (downloadInfo.extraInfo != null && !downloadInfo.extraInfo.itemCheckFlag && !downloadInfo.extraInfo.canRetry) {
                    // 不可下载任务删除刷新不可下载任务列表
//                    LogUtils.i(TAG, "onDownloadPause:" + downloadInfo?.packageName)
                    refreshFlow.tryEmit(REFRESH_ALL)
                    return
                }
                updateInfoFlow(downloadInfo)
                refreshFlow.tryEmit(REFRESH_BTN_TYPE)
            }

            override fun onDownloadError(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onDownloadError:" + downloadInfo?.packageName)
                downloadInfo?.packageName ?: return
                updateInfoFlow(downloadInfo)
                refreshFlow.tryEmit(REFRESH_BTN_TYPE)
            }

            override fun onDownloadDelete(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onDownloadDelete:" + downloadInfo?.packageName)
                refreshFlow.tryEmit(REFRESH_ALL)
                downloadInfo?.packageName ?: return
                flowManager.removeFlow(downloadInfo.packageName)
            }

            override fun onDownloadComplete(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onDownloadComplete:" + downloadInfo?.packageName)
                downloadInfo?.packageName ?: return
                updateInfoFlow(downloadInfo)
            }

            override fun onActivated(downloadInfo: FileDownloadInfo?) {
//                LogUtils.i(TAG, "onActivated:" + downloadInfo?.packageName)
            }

            override fun onAppPackageRemoved(
                packageName: String?,
                versionCode: Int,
                modifyStatusFrom: Int
            ) {
//                LogUtils.i(TAG, "onAppPackageRemoved:$packageName")
                refreshFlow.tryEmit(REFRESH_ALL)
                if (modifyStatusFrom == FileDownloadInfo.MODIFY_STATUS_FROM_INSTALL_FAILS) {
                    if (!packageName.isNullOrEmpty()) {
                        val fileDownloadInfo = DownloadManager.getInstance()
                            .getDownloadedInfobyPackageName(packageName)
                        fileDownloadInfo?.let {
                            val event = DownloadStatus(downloadInfo = fileDownloadInfo)
                            val flow = flowManager.getOrCreateFlow(packageName)
                            flow.tryEmit(event)
                        }
                    }
                }
            }

            override fun onAppPackageAdded(packageName: String?, versionCode: Int) {
//                LogUtils.i(TAG, "onAppPackageAdded:$packageName")
                refreshFlow.tryEmit(REFRESH_ALL)
            }
        }

        DownloadStatusManager.getInstance().putStatusChangeListener(TAG, statusChangeListener)
        DownloadStatusManager.getInstance().putStatusBatchChangeListener(TAG, statusChangeListener)
    }

    private fun updateInfoFlow(downloadInfo: FileDownloadInfo?) {
        if (downloadInfo == null || downloadInfo.packageName.isNullOrEmpty()) {
            return
        }
        if (!flowManager.containsKey(downloadInfo.packageName)) {
            // 新增加的任务刷新数据
            refreshFlow.tryEmit(REFRESH_ALL)
        }
        val event = DownloadStatus(downloadInfo = downloadInfo)
        val flow = flowManager.getOrCreateFlow(downloadInfo.packageName)
        flow.tryEmit(event)
        flowManager.notifyActive(downloadInfo.packageName)
    }

    override fun unregisterDownloadStatusListener() {
        DownloadStatusManager.getInstance().removeStatusChangeListener(TAG)
        DownloadStatusManager.getInstance().removeStatusBatchChangeListener(TAG)
        statusChangeListener = null
    }

    override fun destroy() {
        resetExpandFlag()
        flowManager.clear()
        unregisterDownloadStatusListener()
    }

    private fun resetExpandFlag() {
        val downloadingList = DownloadManager.getInstance().getShadowDownloadingInfoList()
        if (downloadingList != null && !downloadingList.isEmpty()) {
            val it = downloadingList.iterator()
            while (it.hasNext()) {
                val item = it.next()
                if (item.isExpand) {
                    item.setExpandFlag(false)
                }
            }
        }
        val downloadedList = DownloadManager.getInstance().getShadowDownloadedInfoList()
        if (downloadedList != null && !downloadedList.isEmpty()) {
            val it = downloadedList.iterator()
            while (it.hasNext()) {
                val item = it.next()
                if (item.isExpand) {
                    item.setExpandFlag(false)
                }
            }
        }
    }

    private fun isPetPrivateApp(packageName: String?): Boolean {
        val privatePkg = XMPetSwitcher.primaryApkPck
        return privatePkg.isNotBlank() && privatePkg == packageName
    }

    /**
     * 检查已下载的文件是否还存在
     */
    private fun downloadedFileIsExist(fileDownloadInfo: FileDownloadInfo?): Boolean {
        if (fileDownloadInfo == null) {
            return false
        }
        // 获取已下载文件的路径
        val downloadedFilePath = FilePathManager.getDownloadedFilePath(fileDownloadInfo)
        // 路径为空
        if (TextUtils.isEmpty(downloadedFilePath)) {
            return false
        }
        // 路径不为空检查文件是否存在
        var downloadedFile = File(downloadedFilePath)
        if (downloadedFile.exists()) {
            return true
        }

        // 检查是否命中老版本下载路径
        val downloadedFilePathForOldVersion =
            FilePathManager.getDownloadedFilePathForOldVersion(fileDownloadInfo)
        // 老版本路径为空
        if (TextUtils.isEmpty(downloadedFilePathForOldVersion)) {
            return false
        }
        // 老版本路径不为空检查文件是否存在
        downloadedFile = File(downloadedFilePathForOldVersion)
        return downloadedFile.exists()
    }
}
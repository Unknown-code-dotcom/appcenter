// TOP SECRET
package com.afmobi.palmplay.cache;

import android.text.TextUtils;
import android.util.LruCache;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.HttpRequestTracerManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.manager.UpdateControlManager;
import com.afmobi.palmplay.model.GenericResponseInfo;
import com.afmobi.palmplay.model.MessageInfo;
import com.afmobi.palmplay.model.MessageRespInfo;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.recall.RecallNotifyManager;
import com.afmobi.palmplay.sysmsg.db.SystemMessageDao;
import com.afmobi.palmplay.sysmsg.db.SystemMessageDatabase;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.afmobi.util.NetworkUtils;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppCacheUtil;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppSceneCache;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.ChangeAppNameUtil;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;


public class SystemMessageCache implements LocalCache {

	private final static String FILE_NAME = "SystemMessageCache";
	private static volatile SystemMessageCache mInstance;
	private final String mNewFileName = "SysMsgCache"; // new File Cache

	private final static long ONE_HOUR = 1 * 60 * 60 * 1000L; // 1h
	private final static long ONE_DAY = 1 * 24 * 60 * 60 * 1000L; // 1day
	private final static long LOAD_INTERVAL_DEFAULT = 1 * ONE_HOUR; //1h
	private final static long SHOW_INTERVAL_DEFAULT = 1 * ONE_DAY; //1d
	private final static long ACTIVATE_DAY_DEFAULT = 1 * ONE_DAY; //1d
	private final static String LAST_REQUEST_TIME = "sysmsg.last.request.time"; //站内信上次请求时间
	private final static String LAST_SHOW_TIME = "sysmsg.last.show.time"; //站内信上次展示时间
	private final static String TAG = "stationMail";
	private final static String SYSTEM_MSG_FILE_NEW = "sys.msg.file.new";
	public static final int MAX_COUNT = 30; // 最多保留30条数据，否则内存占用太高
	private static LruCache<String, MessageInfo> mMessageLru = new LruCache<>(MAX_COUNT);

	private final static String MESSAGE_DATA_MARK = "message_data_mark"; //站内信 更新标记
	private long mMessageDataMark = 0;

	private SystemMessageCache() {
		loadFromCache();
	}

	public static SystemMessageCache getInstance() {
		if (mInstance == null) {
			synchronized (SystemMessageCache.class) {
				if (mInstance == null) {
					mInstance = new SystemMessageCache();
				}
			}
		}

		return mInstance;
	}


	@Override
	public String getFileName(Object... objects) {
		// TODO Auto-generated method stub
		return FILE_NAME;
	}

	@Override
	public void saveToCache(String jsonBuffer, Object... objects) {
		// TODO Auto-generated method stub
		if (mMessageLru == null) {
			return;
		}

		Map<String, MessageInfo> map = mMessageLru.snapshot();
		List<MessageInfo> list = new ArrayList<>(map.values());
		String txt = "";
		try {
			txt = new Gson().toJson(list);
			FilePathManager.jsonToFile(txt, SYSTEM_MSG_FILE_NEW);
		}catch(Exception e) {
		    if (BuildConfig.DEBUG) e.printStackTrace();
		}

		LogUtils.d(TAG, "save stasionmail to cache:" + txt);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.afmobi.palmplay.cache.LocalCache#loadFromCache()
	 */
	@Override
	public void loadFromCache(Object... objects) {
		// 清理老版本内文件信息
		PalmplayApplication.getAppInstance().deleteFile(getFileName());
		mMessageDataMark = SPManager.getLong(MESSAGE_DATA_MARK,0);

		File file = new File(PalmplayApplication.getAppInstance().getFilesDir() + File.separator + mNewFileName);
		FileUtils.deleteFile(file);
		initData();
	}

	public long getMessageDataMark() {
		return mMessageDataMark;
	}

	private void initData() {
		try {

			JsonElement je = FilePathManager.fileToJson(SYSTEM_MSG_FILE_NEW);

			if (je != null && je.isJsonArray()) {

				Type type = new TypeToken<List<MessageInfo>>(){}.getType();
				List<MessageInfo> list = new Gson().fromJson(je, type);

				mMessageLru.evictAll();
				if (list != null && list.size() > 0) {
					for (int i = list.size()-1; i >= 0;i--) {
						MessageInfo item = list.get(i);
						String key = getMapKey(item);
						mMessageLru.put(key, item);
					}
				}
			}
		}catch(Exception e) {
		    if (BuildConfig.DEBUG) e.printStackTrace();
		}
	}

	/**
	 * 生成消息key
	 * */
	private String getMapKey(MessageInfo item) {
		String key = TAG;
		if (item != null) {
			key = (item.mailSource + item.materialUrl);
		}

		if (TextUtils.isEmpty(key)) {
			key = TAG;
		}

		return key;
	}

	/**
	 * 更新数据库中的消息
	 * */
	public void saveStationMailToDatabase(List<MessageInfo> list) {
		try {
			if (list != null && list.size() > 0) {
				SystemMessageDao db = SystemMessageDatabase.getDatabase(PalmplayApplication.getAppInstance()).getSystemMessageDao();
				Iterator<MessageInfo> it = list.iterator();
				while (it.hasNext()) {
					MessageInfo item = it.next();
					if (item != null && item.msgType != 2) {
						db.updateSystemMessages(item);
					}
				}
			}
			LogUtils.d(TAG, "save stationmail to database.");
		} catch (Exception e) {
			LogUtils.e(TAG, "save stationmail to database. error:" + e.getMessage());
		}
	}

	/**
	 * 站内信开关是否打开
	 * */
	public boolean isStationMailOpen() {
		boolean switchFlag = MMKVUtils.getMMKV().getBoolean(Constant.KV_STATIONMAIL_SWITCH, true);

		return switchFlag;
	}

	/**
	 * 激活天数限制
	 * */
	public long activeDayLimit() {
		long activityDay = MMKVUtils.getMMKV().getInt(Constant.KV_STATIONMAIL_ACTIVEDAY, 0);

		if (activityDay > 0) {
			activityDay = activityDay * ONE_DAY;
		}

		if (activityDay <= 0) {
			activityDay = ACTIVATE_DAY_DEFAULT;
		}

		return activityDay;
	}


	/**
	 * 展示间隔
	 * */
	public long showInterval() {
		long showTime = MMKVUtils.getMMKV().getInt(Constant.KV_STATIONMAIL_SHOWINTERVAL, 0);

		if (showTime > 0) {
			showTime = showTime * ONE_HOUR;
		}

		if (showTime <= 0) {
			showTime = SHOW_INTERVAL_DEFAULT;
		}

		return showTime;
	}

	/**
	 * 请求间隔
	 * */
	public long loadInterval() {
		long interval = MMKVUtils.getMMKV().getInt(Constant.KV_STATIONMAIL_INTERVAL, 0);

		if (interval > 0) {
			interval = interval * ONE_HOUR;
		}

		if (interval <= 0) {
			interval = LOAD_INTERVAL_DEFAULT;
		}

		return interval;
	}

	/**
	 * 通过key删除未读消息队列中的消息
	 * */
	private void removeMessageByKey(String key) {
		if (mMessageLru == null || mMessageLru.size() <= 0) {
			return;
		}

		if (TextUtils.isEmpty(key)) {
			return;
		}

		mMessageLru.remove(key);

		saveToCache(null);
	}

	/**
	 * 判断当前信息是否下发过
	 * 1. 未读队列中
	 * 2. 数据库中
	 * */
	private boolean isMessageExist(String key) {
		if (TextUtils.isEmpty(key)) {
			return true;
		}

		MessageInfo item = mMessageLru.get(key);
		if (item != null) {
			return true;
		}

		try {
			SystemMessageDao db = SystemMessageDatabase.getDatabase(PalmplayApplication.getAppInstance()).getSystemMessageDao();

			item = db.getMessageItem(key);
		}catch(Exception e) {
		    if (BuildConfig.DEBUG) e.printStackTrace();
		}

		return (item != null);
	}

	/**
	 * 请求站内信
	 * */
	public boolean onSystemMessageLoad(boolean needUpdate,final int reqType) {

		if (!CommonUtils.isPrivacyPolicyHasAllowed()) {
			LogUtils.d(TAG, "will not load stationmail, because gdpr not agree.");
			return false;
		}
		onSystemMessageHandle();

		if (!isStationMailOpen()) {
			LogUtils.d(TAG, "will not load stationmail, because stationMail is closed.");
			return false;
		}

		if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
			LogUtils.d(TAG, "will not load stationmail, because is no network.");
			return false;
		}

		//请求间隔
		long interval = loadInterval();
		long time = System.currentTimeMillis();
		long lastLoadTime = SPManager.getLong(LAST_REQUEST_TIME, 0);
		long diffTime = time - lastLoadTime;
		if (diffTime < interval) {
			LogUtils.d(TAG, "will not load stationmail, because load time limit.");

			ApmAppCacheUtil.getInstance().startCollectCacheTime(ApmAppCacheUtil.systemMessage_t, diffTime);
			return false;
		}
		SPManager.putLong(LAST_REQUEST_TIME, System.currentTimeMillis());
		LogUtils.d(TAG, "Load stationmail begining.....");
		if (needUpdate) {
			long mLastReqApiTime = System.currentTimeMillis();
			NetworkClient.requestStationMail(new AbsRequestListener<GenericResponseInfo<MessageRespInfo>>() {
				@Override
				public void onResponse(GenericResponseInfo<MessageRespInfo> response) {
					super.onResponse(response);

					int size = 0;
					long costTime = 0;
					String result = "E";

					if (BuildConfig.DEBUG) {
						String txt = (response != null) ? new Gson().toJson(response) : "response is null";
						LogUtils.d(TAG, "on stationmail load finish, response:" + txt);
					}

					HttpRequestTracerManager.getInstance().remove(TAG);

					if (response != null && response.isSuccess()) {
						result = "S";
						long startTime = System.currentTimeMillis();
						mMessageDataMark = response.data.dataMark;
						SPManager.putLong(MESSAGE_DATA_MARK, mMessageDataMark);
						int status = 0;
						String dataMark = "";
						List<MessageInfo> data = response.data.psFindList;
						if (data != null && data.size() > 0) {
							size = data.size();
							status = 1;
							dataMark = ""+ response.data.dataMark;
							boolean isNeedSave = false;
							try {
								ListIterator<MessageInfo> it = data.listIterator(data.size());
								while (it.hasPrevious()) {
									MessageInfo item = it.previous();
									String key = getMapKey(item);
									item.key = key;
									boolean ret = isMessageExist(key);

									if (!ret) {
										mMessageLru.put(key, item);
										isNeedSave = true;
									}
								}
							}catch(Exception e) {
								if (BuildConfig.DEBUG) e.printStackTrace();
							}

							if (isNeedSave) {
								saveToCache(null);
							}
						}
						TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,status, dataMark,
								com.afmobi.util.Constants.SCENE_PS_FIND_KEY,UpdateControlManager.getAbTestStatus(),-1,""+reqType);
						//TODO: notify
						onSystemMessageHandle();

						costTime = System.currentTimeMillis() - startTime;
					}

					ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.systemMessage_t,
							diffTime, mLastReqApiTime, result, size, costTime);
				}

				@Override
				public void onError(ANError anError) {
					super.onError(anError);
					HttpRequestTracerManager.getInstance().remove(TAG);
					String errorMsg = "";
					if(anError!=null) {
						if(TextUtils.isEmpty(anError.getMessage())) {
							errorMsg = anError.getErrorDetail() + anError.getErrorCode();
						} else {
							errorMsg = anError.getMessage() + anError.getErrorCode();
						}
					}
					TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,0, "",
							com.afmobi.util.Constants.SCENE_PS_FIND_KEY,UpdateControlManager.getAbTestStatus(),-1,errorMsg+"_"+reqType);
					LogUtils.d(TAG, "on stationmail load falied,msg:" + anError.getMessage());

					ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.systemMessage_t,
							diffTime, mLastReqApiTime, errorMsg);
				}

			}, TAG);
			return true;
		}
		return false;
	}


	public void onSystemMessageHandle() {

		if (!isStationMailOpen()) {
			LogUtils.d(TAG, "on system message handle, but switch flag is close.");
			return;
		}

		// 无前台活跃判断
		long realActiveDayLimit = activeDayLimit();
		long currTime = System.currentTimeMillis();
		long lastForeGroundTime = getLastForgroundTime();
		if ((currTime - lastForeGroundTime) < realActiveDayLimit) {
			LogUtils.d(TAG, "on system message handle, but recallActiveDay limit;  recallActiveDayLimit = " + realActiveDayLimit + ",lastForeGroundTime:" + lastForeGroundTime);
			return;
		}

		long interval = showInterval();
		long lastTime = SPManager.getLong(LAST_SHOW_TIME, 0);
		if ((currTime - lastTime) < interval) {
			LogUtils.d(TAG, "on system message handle, but show time limit.");
			return;
		}

		List<MessageInfo> list = new ArrayList<>();
		if (mMessageLru != null) {
			Map<String, MessageInfo> map = mMessageLru.snapshot();
			List<MessageInfo> sourceList = new ArrayList<>(map.values());
			ListIterator<MessageInfo> it = sourceList.listIterator(sourceList.size());
			while (it.hasPrevious()) {
				MessageInfo item = it.previous();
				if (item.msgType == 0 && item.msgStatus == MessageInfo.MSG_TYPE_UNREAD) {
					list.add(item);
					break;
				}
			}
		}

		if (list.size() <= 0) {
			LogUtils.d(TAG, "on system message handle, but no unread messages.");
			return;
		}

		Iterator<MessageInfo> it = list.iterator();
		while (it.hasNext()) {
			MessageInfo item = it.next();
			if (item != null) {
				item.msgStatus = MessageInfo.MSG_TYPE_NOTIFYED;
				item.time = System.currentTimeMillis();

				try {
					SystemMessageDatabase.getDatabase(PalmplayApplication.getAppInstance()).getSystemMessageDao()
							.add(item);
				}catch(Exception e) {
				    if (BuildConfig.DEBUG) e.printStackTrace();
				}

				removeMessageByKey(item.key);
			}
		}

		//桌面ICON角标
		TRHomeUtil.updateLaunchIconRedTips(true, "API", "SystemMessage");

		SPManager.putLong(LAST_SHOW_TIME, System.currentTimeMillis());

		LogUtils.d(TAG, "on system message handle, refresh desktop icon mark,Tools mark,My message red tip.");
	}

	/**
	 * 上一次进入前台的时间
	 * */
	public long getLastForgroundTime() {
		long mLastForeGroundTime = SPManager.getLong(RecallNotifyManager.LAST_FOREGROUND_TIME_KEY, 0);
		return mLastForeGroundTime;
	}

	/**
	 * 获取所有消息列表
	 * 获取最近的30条消息：MSG_TYPE_PUSH, MSG_TYPE_UNMARK, MSG_TYPE_READED
	 * */
	public List<MessageInfo> getMessageList() {

		List<MessageInfo> list = new ArrayList<>();

		try {
			List<MessageInfo> sourceList = SystemMessageDatabase.getDatabase(PalmplayApplication.getAppInstance()).getSystemMessageDao()
					.getMessageList(MessageInfo.MSG_TYPE_UNREAD, MAX_COUNT);

			if (sourceList != null && sourceList.size() > 0) {
				Iterator<MessageInfo> it = sourceList.iterator();
				while (it.hasNext()) {
					MessageInfo item = it.next();
					item.hasTrack = false;
					list.add(item);
				}
			}
		}catch(Exception e) {
		    if (BuildConfig.DEBUG) e.printStackTrace();
		}

		return list;
	}

	/**
	 * 获取未读的系统消息条数
	 * 分两种情况：如果进入过My Messages页面，则返回0，要清除桌面ICON角标，Tools角标
	 *           如果未进入过，则返回实际未读条数
	 * */
	public int getUnreadSystemMessageCount() {
		int count = 0;

		List<MessageInfo> list = null;
		try {
		    list = SystemMessageDatabase.getDatabase(PalmplayApplication.getAppInstance()).getSystemMessageDao()
					.getMessageList(MessageInfo.MSG_TYPE_UNREAD, MAX_COUNT);
		}catch(Exception e) {
		    if (BuildConfig.DEBUG) e.printStackTrace();
		}

		if (list != null && list.size() > 0) {
			Iterator<MessageInfo> it = list.iterator();
			while (it.hasNext()) {
				MessageInfo item = it.next();
				if (item.msgType == 0 && item.msgStatus == MessageInfo.MSG_TYPE_NOTIFYED) {
					count++;
				}
			}
		}

		LogUtils.d(TAG, "on stasionMail unread counts:" + count);

		return count;
	}

	/**
	 * 创建最后1条消息
	 * 此消息只做列表中展示，不加入数据库
	 * */
	public MessageInfo generateTopLimitMessage() {
		MessageInfo item = new MessageInfo();

		item.msgStatus = MessageInfo.MSG_TYPE_READED;
		item.materialUrl = "30";
		item.mailSource = "topLimit";
		item.msgType = 2;
		item.time = 0;

		String txt = PalmplayApplication.getAppInstance().getString(R.string.txt_msg_toplimit);
		String newTxt = CommonUtils.replace(txt, CommonUtils.TARGET_NUMBER, String.valueOf(MAX_COUNT));
		item.title = newTxt;
		item.key = getMapKey(item);

		return item;
	}

	/**
	 * 首次激活创建一条系统消息记录
	 * 系统消息创建即已读，存数据库
	 * */
	public void addSystemMessage() {
		LogUtils.d(TAG, "create and add one system message.");
		if (mMessageLru == null) {
			mMessageLru = new LruCache<>(MAX_COUNT);
		}

		MessageInfo item = new MessageInfo();
		item.msgStatus = MessageInfo.MSG_TYPE_UNMARK;
		item.materialUrl = "100";
		item.mailSource = "nativeMessage";
		item.msgType = 1;
		item.time = System.currentTimeMillis();
        item.title = ChangeAppNameUtil.INSTANCE.changeAppName(PalmplayApplication.getAppInstance().getBaseContext(), R.string.txt_preset_msg);
		item.key = getMapKey(item);
		try {
			SystemMessageDatabase.getDatabase(PalmplayApplication.getAppInstance()).getSystemMessageDao()
					.add(item);
		} catch (Exception e) {
			LogUtils.e(TAG, "add to SystemMessageDatabase. error:" + e.getMessage());
		}
	}
}

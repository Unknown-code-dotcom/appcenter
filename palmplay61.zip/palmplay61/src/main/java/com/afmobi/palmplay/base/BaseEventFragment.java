// TOP SECRET
package com.afmobi.palmplay.base;

import de.greenrobot.event.EventBus;

public abstract class BaseEventFragment extends BaseFragment{

	@Override
	public void registerEventBus() {
		EventBus.getDefault().register(this);
	}
	
	@Override
	public void unregisterEventBus() {
		EventBus.getDefault().unregister(this);
	}

}

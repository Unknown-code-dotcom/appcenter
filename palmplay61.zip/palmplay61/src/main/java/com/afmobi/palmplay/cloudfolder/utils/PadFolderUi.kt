package com.afmobi.palmplay.cloudfolder.utils

import android.view.View
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import com.transsnet.store.R

/**
 * Pad 云文件夹的 View 级适配。尺寸仍从 DeviceProfile / pad token 读取，不在 DeviceProfile 里改控件。
 */
object PadFolderUi {

    /**
     * Pad 底栏图标从 56dp 缩到 48dp 后，下载角标按同比例改为 19dp，
     * 并贴到图标右下角向外偏移 5dp（原 22dp / 外探 6dp）。
     */
    fun applyBottomDownloadBadge(itemView: View) {
        if (!DeviceProfile.getInstance().isPadLayout) return
        val badge = itemView.findViewById<ImageView>(R.id.iv_default_icon) ?: return
        val icon = itemView.findViewById<View>(R.id.card_icon) ?: return
        val res = itemView.resources
        val size = res.getDimensionPixelSize(R.dimen.ps_cloud_folder_pad_bottom_badge_size)
        val hang = res.getDimension(R.dimen.ps_cloud_folder_pad_bottom_badge_hang)
        val params = badge.layoutParams as? ConstraintLayout.LayoutParams ?: return
        params.width = size
        params.height = size
        params.endToEnd = icon.id
        params.bottomToBottom = icon.id
        params.bottomToTop = ConstraintLayout.LayoutParams.UNSET
        badge.layoutParams = params
        val rtl = itemView.layoutDirection == View.LAYOUT_DIRECTION_RTL
        badge.translationX = if (rtl) -hang else hang
        badge.translationY = hang
    }
}

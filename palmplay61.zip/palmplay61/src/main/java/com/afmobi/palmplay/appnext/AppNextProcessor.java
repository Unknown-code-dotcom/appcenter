package com.afmobi.palmplay.appnext;

import android.text.TextUtils;

import com.afmobi.palmplay.appnext.db.AppNextCache;
import com.afmobi.palmplay.appnext.db.AppNextDbManager;
import com.afmobi.palmplay.network.NetworkClient;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsnet.store.BuildConfig;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 16:26
 * @Desc: add your description
 */
public class AppNextProcessor {

    private static final String TAG = "AppNext";
    private static CopyOnWriteArrayList<AppNextCache> mAppNextCacheList = new CopyOnWriteArrayList<>();

    public static void addAsyncTask(final String packageName, final String action, final String reportUrl) {

        if(!BuildConfig.FEATURE_APP_NEXT_SWITCH){
            return;
        }
        if (TextUtils.isEmpty(reportUrl)) {
            LogUtils.d(TAG, " AppNextProcessor addAsyncTask reportUrl empty ");
            return;
        }
        AppNextCacheManager.getInstance().saveToDb(packageName + action, reportUrl);

        LogUtils.d(TAG, " AppNextProcessor addAsyncTask packageNameWithAction " + packageName + action);

        TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new Runnable() {
            @Override
            public void run() {
                NetworkClient.appNextReport(reportUrl, new StringRequestListener() {
                    @Override
                    public void onResponse(String response) {
                        LogUtils.d(TAG, "report app next success " + packageName + action);
                        AppNextDbManager.deleteCacheByPkg(packageName + action);
                    }

                    @Override
                    public void onError(ANError anError) {
                        LogUtils.d(TAG, "report app next fail");
                    }
                }, packageName + action);
            }
        });
    }


    private static volatile int mIndex = 0;

    public static void handleAppNextCacheList(List<AppNextCache> appNextCacheList) {

        if (mAppNextCacheList == null) {
            mAppNextCacheList = new CopyOnWriteArrayList<>();
        }

        if (mAppNextCacheList.size() > 0) {
            LogUtils.d(TAG, " handleAppNextCache is processing now ");
            return;
        } else {
            mIndex = 0;
            mAppNextCacheList.addAll(appNextCacheList);
        }
        LogUtils.d(TAG, " handleAppNextCacheList app next cache list " + mAppNextCacheList.size());

        LogUtils.d(TAG, "--- start loopReportTask ---");

        loopReportTask(getCacheTask());
    }

    private static void loopReportTask(final AppNextCache appNextCache) {

        if (appNextCache == null) {
            LogUtils.d(TAG, " all cache has done");
            return;
        }

        LogUtils.d(TAG, "loopReportTask" + appNextCache.packageNameWithAction);

        if(checkCondition(appNextCache)){
            TRThreadPool.getInstance(TRThreadPool.PRIORITY_HIGH).submit(new Runnable() {
                @Override
                public void run() {
                    NetworkClient.appNextReport(appNextCache.reportUrl, new StringRequestListener() {
                        @Override
                        public void onResponse(String response) {
                            LogUtils.d(TAG, "report app next success");
                            mIndex++;
                            AppNextDbManager.deleteCacheByPkg(appNextCache.packageNameWithAction);
                            loopReportTask(getCacheTask());
                        }

                        @Override
                        public void onError(ANError anError) {
                            mIndex++;
                            appNextCache.setRetryCount(appNextCache.retryCount + 1);
                            LogUtils.d(TAG, "report app next fail retryCount = " +
                                    "" + appNextCache.retryCount);

                            AppNextDbManager.updateAppNextCache(appNextCache);
                            loopReportTask(getCacheTask());
                        }
                    }, appNextCache.packageNameWithAction);
                }
            });

        } else {
            LogUtils.d(TAG, ": loopReportTask  retryCount >= 3 so deleteCacheByPkg" + appNextCache.packageNameWithAction);
            AppNextDbManager.deleteCacheByPkg(appNextCache.packageNameWithAction);
            mIndex++;
            loopReportTask(getCacheTask());
        }
    }

    /**
     * 重试次数小于3次 48小时内
     ** @return
     */
    private static boolean checkCondition(AppNextCache appNextCache) {
        return appNextCache.retryCount < AppNextConstants.APP_NEXT_MAX_RETRY_COUNT && System.currentTimeMillis() - appNextCache.createTime < AppNextConstants.APP_NEXT_CACHE_TIME_OUT;
    }

    private static AppNextCache getCacheTask() {
        if (mAppNextCacheList != null && mAppNextCacheList.size() > mIndex) {
            return mAppNextCacheList.get(mIndex);
        } else {
            mIndex = 0;
            if (mAppNextCacheList != null) {
                mAppNextCacheList.clear();
            }
        }
        return null;
    }

}

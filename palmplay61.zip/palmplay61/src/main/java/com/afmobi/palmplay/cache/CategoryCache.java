package com.afmobi.palmplay.cache;

import android.os.Looper;
import android.text.TextUtils;

import com.afmobi.apk.ThreadHelper;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.UpdateControlManager;
import com.afmobi.palmplay.model.CategoryData;
import com.afmobi.palmplay.model.CategoryInfo;
import com.afmobi.palmplay.model.CategoryListData;
import com.androidnetworking.interfaces.AbsRequestListener;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.androidnetworking.error.ANError;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppCacheUtil;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppSceneCache;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;

import java.util.List;

import androidx.collection.LruCache;

public class CategoryCache implements LocalCache {

    public static long DEFAULT_REQUEST_INTERVAL = BuildConfig.DEBUG ? 2 * 60 * 1000 : 24 * 60 * 60 * 1000;// 24小时间隔时间

    private static final String CACHE_URI = "CATEGORY_CACHE";
    private static final String CACHE_URI_APP = "APP_CATEGORY_CACHE_NEW";
    private static final String CACHE_URI_GAME = "GAME_CATEGORY_CACHE_NEW";
    private static volatile CategoryCache mInstance;


    //分类缓存
    private CategoryData mAppCategoryData;
    private CategoryData mGameCategoryData;

    //分类下面的数据cache
    private LruCache<String, CategoryListData> mCategoryDataCache;

    private static int MAX_CATEGORY_CACHE_SIZE = 20;

    private Gson mGson;

    private CategoryCache() {

        mGson = new Gson();
        initCategoryCache();

        if (TRApplicationContextUtil.isProject()) {
            MAX_CATEGORY_CACHE_SIZE = 20;
        }
        mCategoryDataCache = new LruCache<>(MAX_CATEGORY_CACHE_SIZE);

    }

    public static CategoryCache getInstance() {
        if (mInstance == null) {
            synchronized (CategoryCache.class) {
                if (mInstance == null) {
                    mInstance = new CategoryCache();
                }
            }
        }

        return mInstance;
    }

    private void initCategoryCache() {
        loadFromCache();
    }

    public void saveCategoryDataToCache(String categoryIdKey, CategoryListData list) {
        if (TextUtils.isEmpty(categoryIdKey)) {
            return;
        }

        if (mCategoryDataCache == null) {
            mCategoryDataCache = new LruCache<>(MAX_CATEGORY_CACHE_SIZE);
        }
        CategoryListData newList = copyToList(list);
        mCategoryDataCache.put(categoryIdKey, newList);

    }

    private CategoryListData copyToList(CategoryListData list) {
        CategoryListData newList = new CategoryListData();
        newList.itemList.addAll(list.itemList);
        newList.pageIndex = list.pageIndex;
        newList.pageSum = list.pageSum;
        return newList;
    }

    public CategoryListData getCategoryDataFromCache(String categoryIdKey) {
        if (TextUtils.isEmpty(categoryIdKey)) {
            return null;
        }
        CategoryListData newList = null;
        if (mCategoryDataCache != null && mCategoryDataCache.size() > 0) {
            CategoryListData categoryListData = mCategoryDataCache.get(categoryIdKey);
            LogUtils.d(LogUtils.TAG_CATEGORY, "from cache categoryIdKey = " + categoryIdKey + "categoryListData = " + categoryListData);
            if (categoryListData != null) {
                newList = copyToList(categoryListData);
            }
        }
        return newList;
    }

    public void clearCategoryDataCache() {
        if (mCategoryDataCache != null) {
            mCategoryDataCache.evictAll();
        }
    }

    public List<CategoryInfo> getCategoryCache(String categoryType) {
        if (Constant.SOFTTYPE_GAME.equals(categoryType)) {
            return mGameCategoryData != null ? mGameCategoryData.categoryList : null;
        } else {
            return mAppCategoryData != null ? mAppCategoryData.categoryList : null;
        }
    }

    @Override
    public void saveToCache(String categoryType, Object... objects) {
        if (objects != null && objects.length > 0) {
            try {
                CategoryData serverData = (CategoryData) objects[0];
                //存文件
                FilePathManager.jsonToFile(mGson.toJson(serverData), getFileName(categoryType));
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
    }

    @Override
    public void loadFromCache(Object... objects) {

        JsonElement appCategoryCache = FilePathManager.fileToJson(getFileName(Constant.SOFTTYPE_APP));
        JsonElement gameCategoryCache = FilePathManager.fileToJson(getFileName(Constant.SOFTTYPE_GAME));

        //App分类数据
        if (appCategoryCache != null && !TextUtils.isEmpty(appCategoryCache.toString())) {
            try {
                mAppCategoryData = mGson.fromJson(appCategoryCache, new TypeToken<CategoryData>() {
                }.getType());
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        if (mAppCategoryData == null || mAppCategoryData.categoryList == null || mAppCategoryData.categoryList.size() == 0) {
            CategoryData appCategory;

            try {
                if (BuildConfig.DEBUG) {
                    appCategory = mGson.fromJson(APP_CATEGORY_CACHE_DEBUG, new TypeToken<CategoryData>() {
                    }.getType());
                } else {
                    appCategory = mGson.fromJson(APP_CATEGORY_CACHE, new TypeToken<CategoryData>() {
                    }.getType());
                }
                mAppCategoryData = appCategory;
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }

        }

        //Game分类数据
        if (gameCategoryCache != null && !TextUtils.isEmpty(gameCategoryCache.toString())) {
            try {
                mGameCategoryData = mGson.fromJson(gameCategoryCache, new TypeToken<CategoryData>() {
                }.getType());
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }

        if (mGameCategoryData == null || mGameCategoryData.categoryList == null || mGameCategoryData.categoryList.size() == 0) {
            CategoryData gameCategory;
            try {
                if (BuildConfig.DEBUG) {
                    gameCategory = mGson.fromJson(GAME_CATEGORY_CACHE_DEBUG, new TypeToken<CategoryData>() {
                    }.getType());
                } else {
                    gameCategory = mGson.fromJson(GAME_CATEGORY_CACHE, new TypeToken<CategoryData>() {
                    }.getType());
                }
                mGameCategoryData = gameCategory;
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
        //最大容量 为最多子分类 * 2
        if (mAppCategoryData != null && mAppCategoryData.categoryList != null && mGameCategoryData != null && mGameCategoryData.categoryList != null) {
            MAX_CATEGORY_CACHE_SIZE = mAppCategoryData.categoryList.size() > mGameCategoryData.categoryList.size() ? 2 * mAppCategoryData.categoryList.size() : 2 * mGameCategoryData.categoryList.size();
        }
    }


    public String getFileName(Object... objects) {
        if (Constant.SOFTTYPE_GAME.equals(objects[0])) {
            return CACHE_URI_GAME;
        } else {
            return CACHE_URI_APP;
        }
    }


    private static final String APP_CATEGORY_CACHE_DEBUG = "{\"categoryList\": [{\"categoryID\": \"5488c2f9bff14921b8f3603a579eabfd\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/773/262d54c4527a41bab5076ff9d568bda8.png\", \"name\": \"Auto & Vehicles\"}, {\"categoryID\": \"8b95f549938542a287cd910b03cb858f\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/601/fea441340a9b42978227fdb007b86e8f.webp\", \"name\": \"Beauty\"}, {\"categoryID\": \"f2f876b0f1104027a9999273d1c2d507\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/843/784e061be20544d0acf3d58c07e7f3b6.png\", \"name\": \"Books & Reference\"}, {\"categoryID\": \"330094a40e53405d8837067ae46a293a\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/218/5e04b7daa30648ec8c632c637dedfd8f.png\", \"name\": \"Business\"}, {\"categoryID\": \"a0df11eae354407b811be3422805443e\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/500/8bea7743080845fb816892c84f7e4439.png\", \"name\": \"Comics\"}, {\"categoryID\": \"54a2e42a35fa478b8967e9350aedffc0\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/610/1b6ac64661e8407892b4d98fa48dc1b4.png\", \"name\": \"Communication\"}, {\"categoryID\": \"8eccf1d65aac4f87a85ab985d6d4ac1f\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/286/f909a7dbc0984906b35a0f416fddbd7c.webp\", \"name\": \"Dating\"}, {\"categoryID\": \"435d688ddfdb4767bebc7b931fbea5bb\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/643/7693c78485734f7a84fdc99a30ace766.png\", \"name\": \"Education\"}, {\"categoryID\": \"14a866877c8f4cae9f6a50179d239923\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/686/1302039252ec4e77abcb5c7318ceeaf7.png\", \"name\": \"Entertainment\"}, {\"categoryID\": \"e87d578b99dc4091a34af2b0226c30c3\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/812/d118bdc351d546a5878751e7413b0165.webp\", \"name\": \"Events\"}, {\"categoryID\": \"1896ff1657b2408daeb264ba6d370bf2\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/337/cb44623579d7474288d9bbbf400bde7e.png\", \"name\": \"Finance\"}, {\"categoryID\": \"b063e05c296443e580ae12500f3d6c76\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/914/69b5fcf156834a85bf650ed1c3b06dd8.webp\", \"name\": \"Food & Drink\"}, {\"categoryID\": \"d87a027c04b14bf6b8b2e157ed8f282b\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/6/8baeb4b6b7e74e33bf157b45d4d13303.png\", \"name\": \"Health & Fitness\"}, {\"categoryID\": \"5853da83563643b7bdb497d55506faf8\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/472/2a1c56962f2f43cab33201657aedbe54.webp\", \"name\": \"House & Home\"}, {\"categoryID\": \"5611b3da75a4460c95a6bae9903a7108\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/796/18c72153e8174386a5a6be79dd411cde.png\", \"name\": \"Libraries & Demo\"}, {\"categoryID\": \"ea61030aab42490d982867b5354cfe7d\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/461/b3f305ca0597495eb7dd7ca3095f3293.png\", \"name\": \"Lifestyle\"}, {\"categoryID\": \"a0d710be0f874b6ebc338b531df2af0f\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/632/5ac46e68883548a0b2eeff8445ce75b7.webp\", \"name\": \"Maps & Navigation\"}, {\"categoryID\": \"43ee4c9576c647cd9b618f7664c0bfd5\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/631/7722a69d95ac41bfa7f0b94be372d716.png\", \"name\": \"Medical\"}, {\"categoryID\": \"e9b17d1366924e7b98bbd673b3dcdc64\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/328/99d008706a4345998bc03782752efd62.png\", \"name\": \"Music & Audio\"}, {\"categoryID\": \"ea53608ada2e42f79488939f9c8da122\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/128/75ff952b0a9042788c39984d29966c8e.png\", \"name\": \"News & Magazines\"}, {\"categoryID\": \"f49709372ddf4b97bb3ba6ff0605ad26\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/464/38a6b0fc254945fcb7f7779be7e83864.webp\", \"name\": \"Parenting\"}, {\"categoryID\": \"ddde5c22996942beafe54a381a928acc\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/823/a3db7062f1e947f5a3658b228cb30f10.webp\", \"name\": \"Personalization\"}, {\"categoryID\": \"fc1b030fa1e14275832b300021bae095\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/291/7acbc90051b14a71a4f1823f739bdb68.png\", \"name\": \"Photography\"}, {\"categoryID\": \"6da765cfc6674b2dbeed4b55b21832d1\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/722/3f32d6d9ff8d46e1bc6f888cda0c02d5.png\", \"name\": \"Productivity\"}, {\"categoryID\": \"00c524c95acb4126a4d567d7831e4ab7\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/113/e0fc279716504ff0ba5f8be26a28329d.png\", \"name\": \"Shopping\"}, {\"categoryID\": \"3c8ca847fc0e4b4383e45849119895ee\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/404/a9de8b363de14ba0928e11e7cdc1e68e.png\", \"name\": \"Social\"}, {\"categoryID\": \"d834b0df4f43497d955d72e29113972b\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/413/cf7b5b665bd44ce3b2ead9e311031e74.png\", \"name\": \"Sports\"}, {\"categoryID\": \"674246bde11a4da1afa07ae93244cb69\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/348/623e88bca48f4225b73e44e58c4f0ae5.png\", \"name\": \"Tools\"}, {\"categoryID\": \"00a217702e7145cbb088ae5ac7089523\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/256/6c61d3cd49124cfebc3893fceb4f02e5.webp\", \"name\": \"Travel & Local\"}, {\"categoryID\": \"cf4eae0abf8e4328b4b0f7fd2925e470\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/777/be2595fe3f9b499db9337a6404783fbc.png\", \"name\": \"Video Editors\"}, {\"categoryID\": \"3acddf68b6fe440abf8bc01c869bd854\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/598/0d5176854a0c4038978fbf6ca0bc388e.png\", \"name\": \"Weather\"}]}";
    private static final String GAME_CATEGORY_CACHE_DEBUG = "{\"categoryList\": [{\"categoryID\": \"83cb0a135cca4f738d2b2dead16d9a21\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/470/06ed1c6da6ed4b39a559aebdff30989b.png\", \"name\": \"Action\"}, {\"categoryID\": \"5d15e5b18ace433b8bf8acb1253023ed\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/149/2cefd82c273a4efab6509a15cb6721e4.png\", \"name\": \"Adventure\"}, {\"categoryID\": \"5b2de85e6c1948f69437ca8da2aa957d\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/349/7bc74b93fdfa4324931cc88b3d552ae7.png\", \"name\": \"Arcade\"}, {\"categoryID\": \"1d6db5146c2c4e40a7eb9d9ed04f0415\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/765/84f18c2ed54142f5a95fd6b19c8daa22.png\", \"name\": \"Board\"}, {\"categoryID\": \"5c00d098ac8d4bc0924d23fa1d83b264\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/109/d4a6b2985599455983307e90ac5c8557.png\", \"name\": \"Card\"}, {\"categoryID\": \"dd3ced6e1ef8446c83026a18397551a0\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/673/5e0e17b89f784e80aadc0d16a8af1b3b.png\", \"name\": \"Casino\"}, {\"categoryID\": \"9bfd82fc7e5d417c8c689460d4f63779\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/801/9cc189f1bc9f40d883449f4c94970f32.png\", \"name\": \"Casual\"}, {\"categoryID\": \"b802e5cb3dcf4d238d1b97f906e801c2\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/453/d38bbefdb43e49419f896a15296faaa9.png\", \"name\": \"Educational\"}, {\"categoryID\": \"379f2b0039bf4b8b833d212b7c0de139\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/810/31f2a9ba155241d4bdfa6047169280bf.png\", \"name\": \"Music\"}, {\"categoryID\": \"a148b7535d9e45e799bc90df99227e7c\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/140/cf6704dd70b149a695e4fff83baad467.png\", \"name\": \"Puzzle\"}, {\"categoryID\": \"37bd4cc5e3e347f18a0aba8f69f320f6\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/307/666efffbb25448bfabcdfcb0ba6f42ee.png\", \"name\": \"Racing\"}, {\"categoryID\": \"3446d5c8b3ad40989d39701a3998c8a3\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/636/c2428a269f4a47b3a2b08a6e8878c006.png\", \"name\": \"Role Playing\"}, {\"categoryID\": \"04c87b63dc7141e3bb67ce122b7bdd5b\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/141/ba8b32f7913d47e39944d99b77d18e3b.png\", \"name\": \"Simulation\"}, {\"categoryID\": \"29903decd2044793961c672694135214\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/2/59ddb9783dc24d01a626750a51d89ff0.png\", \"name\": \"Sports\"}, {\"categoryID\": \"cfc2ef8c1e744e22b81316808f187f5e\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/575/9309de96323d42fdb9b0f5d9fc5c8a97.png\", \"name\": \"Strategy\"}, {\"categoryID\": \"5c195cf59d1e411ca623bc7f05845c2c\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/539/9f8ee977b705496fa4bbe5f8e4aed7fa.png\", \"name\": \"Trivia\"}, {\"categoryID\": \"9f410ee52a594ad3b75ebf41b9cb71da\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/263/f334c44894c640fdbc67b5dccceec0ae.png\", \"name\": \"Word\"}, {\"categoryID\": \"7deae206adf442c4a8a42801642e684a\", \"imgUrl\": \"http://uat-cdn.palmplaystore.com/static/840/cd6eb1b0412e4fc2b0a7c4df939dec55.png\", \"name\": \"Family\"}]}";

    private static final String APP_CATEGORY_CACHE = "{\"categoryList\": [{\"categoryID\": \"ab33ffd751914e5bab096d9df189eb94\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/615/e6b4ddd0ca554dc5bd5b0d1769735e1d.webp\", \"name\": \"Art & Design\"}, {\"categoryID\": \"5488c2f9bff14921b8f3603a579eabfd\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/773/262d54c4527a41bab5076ff9d568bda8.png\", \"name\": \"Auto & Vehicles\"}, {\"categoryID\": \"8b95f549938542a287cd910b03cb858f\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/601/fea441340a9b42978227fdb007b86e8f.webp\", \"name\": \"Beauty\"}, {\"categoryID\": \"f2f876b0f1104027a9999273d1c2d507\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/843/784e061be20544d0acf3d58c07e7f3b6.png\", \"name\": \"Books & Reference\"}, {\"categoryID\": \"330094a40e53405d8837067ae46a293a\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/218/5e04b7daa30648ec8c632c637dedfd8f.png\", \"name\": \"Business\"}, {\"categoryID\": \"a0df11eae354407b811be3422805443e\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/500/8bea7743080845fb816892c84f7e4439.png\", \"name\": \"Comics\"}, {\"categoryID\": \"54a2e42a35fa478b8967e9350aedffc0\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/610/1b6ac64661e8407892b4d98fa48dc1b4.png\", \"name\": \"Communication\"}, {\"categoryID\": \"8eccf1d65aac4f87a85ab985d6d4ac1f\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/286/f909a7dbc0984906b35a0f416fddbd7c.webp\", \"name\": \"Dating\"}, {\"categoryID\": \"435d688ddfdb4767bebc7b931fbea5bb\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/643/7693c78485734f7a84fdc99a30ace766.png\", \"name\": \"Education\"}, {\"categoryID\": \"14a866877c8f4cae9f6a50179d239923\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/686/1302039252ec4e77abcb5c7318ceeaf7.png\", \"name\": \"Entertainment\"}, {\"categoryID\": \"e87d578b99dc4091a34af2b0226c30c3\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/812/d118bdc351d546a5878751e7413b0165.webp\", \"name\": \"Events\"}, {\"categoryID\": \"1896ff1657b2408daeb264ba6d370bf2\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/337/cb44623579d7474288d9bbbf400bde7e.png\", \"name\": \"Finance\"}, {\"categoryID\": \"b063e05c296443e580ae12500f3d6c76\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/914/69b5fcf156834a85bf650ed1c3b06dd8.webp\", \"name\": \"Food & Drink\"}, {\"categoryID\": \"d87a027c04b14bf6b8b2e157ed8f282b\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/6/8baeb4b6b7e74e33bf157b45d4d13303.png\", \"name\": \"Health & Fitness\"}, {\"categoryID\": \"5853da83563643b7bdb497d55506faf8\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/472/2a1c56962f2f43cab33201657aedbe54.webp\", \"name\": \"House & Home\"}, {\"categoryID\": \"5611b3da75a4460c95a6bae9903a7108\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/796/18c72153e8174386a5a6be79dd411cde.png\", \"name\": \"Libraries & Demo\"}, {\"categoryID\": \"ea61030aab42490d982867b5354cfe7d\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/461/b3f305ca0597495eb7dd7ca3095f3293.png\", \"name\": \"Lifestyle\"}, {\"categoryID\": \"a0d710be0f874b6ebc338b531df2af0f\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/632/5ac46e68883548a0b2eeff8445ce75b7.webp\", \"name\": \"Maps & Navigation\"}, {\"categoryID\": \"43ee4c9576c647cd9b618f7664c0bfd5\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/631/7722a69d95ac41bfa7f0b94be372d716.png\", \"name\": \"Medical\"}, {\"categoryID\": \"e9b17d1366924e7b98bbd673b3dcdc64\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/328/99d008706a4345998bc03782752efd62.png\", \"name\": \"Music & Audio\"}, {\"categoryID\": \"ea53608ada2e42f79488939f9c8da122\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/128/75ff952b0a9042788c39984d29966c8e.png\", \"name\": \"News & Magazines\"}, {\"categoryID\": \"f49709372ddf4b97bb3ba6ff0605ad26\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/464/38a6b0fc254945fcb7f7779be7e83864.webp\", \"name\": \"Parenting\"}, {\"categoryID\": \"ddde5c22996942beafe54a381a928acc\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/823/a3db7062f1e947f5a3658b228cb30f10.webp\", \"name\": \"Personalization\"}, {\"categoryID\": \"fc1b030fa1e14275832b300021bae095\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/291/7acbc90051b14a71a4f1823f739bdb68.png\", \"name\": \"Photography\"}, {\"categoryID\": \"6da765cfc6674b2dbeed4b55b21832d1\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/722/3f32d6d9ff8d46e1bc6f888cda0c02d5.png\", \"name\": \"Productivity\"}, {\"categoryID\": \"00c524c95acb4126a4d567d7831e4ab7\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/113/e0fc279716504ff0ba5f8be26a28329d.png\", \"name\": \"Shopping\"}, {\"categoryID\": \"3c8ca847fc0e4b4383e45849119895ee\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/404/a9de8b363de14ba0928e11e7cdc1e68e.png\", \"name\": \"Social\"}, {\"categoryID\": \"d834b0df4f43497d955d72e29113972b\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/413/cf7b5b665bd44ce3b2ead9e311031e74.png\", \"name\": \"Sports\"}, {\"categoryID\": \"674246bde11a4da1afa07ae93244cb69\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/348/623e88bca48f4225b73e44e58c4f0ae5.png\", \"name\": \"Tools\"}, {\"categoryID\": \"00a217702e7145cbb088ae5ac7089523\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/256/6c61d3cd49124cfebc3893fceb4f02e5.webp\", \"name\": \"Travel & Local\"}, {\"categoryID\": \"cf4eae0abf8e4328b4b0f7fd2925e470\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/777/be2595fe3f9b499db9337a6404783fbc.png\", \"name\": \"Video Editors\"}, {\"categoryID\": \"3acddf68b6fe440abf8bc01c869bd854\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/598/0d5176854a0c4038978fbf6ca0bc388e.png\", \"name\": \"Weather\"}]}";
    private static final String GAME_CATEGORY_CACHE = "{\"categoryList\": [{\"categoryID\": \"83cb0a135cca4f738d2b2dead16d9a21\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/470/06ed1c6da6ed4b39a559aebdff30989b.png\", \"name\": \"Action\"}, {\"categoryID\": \"5d15e5b18ace433b8bf8acb1253023ed\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/149/2cefd82c273a4efab6509a15cb6721e4.png\", \"name\": \"Adventure\"}, {\"categoryID\": \"5b2de85e6c1948f69437ca8da2aa957d\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/349/7bc74b93fdfa4324931cc88b3d552ae7.png\", \"name\": \"Arcade\"}, {\"categoryID\": \"1d6db5146c2c4e40a7eb9d9ed04f0415\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/765/84f18c2ed54142f5a95fd6b19c8daa22.png\", \"name\": \"Board\"}, {\"categoryID\": \"5c00d098ac8d4bc0924d23fa1d83b264\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/109/d4a6b2985599455983307e90ac5c8557.png\", \"name\": \"Card\"}, {\"categoryID\": \"dd3ced6e1ef8446c83026a18397551a0\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/673/5e0e17b89f784e80aadc0d16a8af1b3b.png\", \"name\": \"Casino\"}, {\"categoryID\": \"9bfd82fc7e5d417c8c689460d4f63779\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/801/9cc189f1bc9f40d883449f4c94970f32.png\", \"name\": \"Casual\"}, {\"categoryID\": \"b802e5cb3dcf4d238d1b97f906e801c2\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/453/d38bbefdb43e49419f896a15296faaa9.png\", \"name\": \"Educational\"}, {\"categoryID\": \"379f2b0039bf4b8b833d212b7c0de139\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/810/31f2a9ba155241d4bdfa6047169280bf.png\", \"name\": \"Music\"}, {\"categoryID\": \"a148b7535d9e45e799bc90df99227e7c\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/140/cf6704dd70b149a695e4fff83baad467.png\", \"name\": \"Puzzle\"}, {\"categoryID\": \"37bd4cc5e3e347f18a0aba8f69f320f6\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/307/666efffbb25448bfabcdfcb0ba6f42ee.png\", \"name\": \"Racing\"}, {\"categoryID\": \"3446d5c8b3ad40989d39701a3998c8a3\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/636/c2428a269f4a47b3a2b08a6e8878c006.png\", \"name\": \"Role Playing\"}, {\"categoryID\": \"04c87b63dc7141e3bb67ce122b7bdd5b\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/141/ba8b32f7913d47e39944d99b77d18e3b.png\", \"name\": \"Simulation\"}, {\"categoryID\": \"29903decd2044793961c672694135214\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/2/59ddb9783dc24d01a626750a51d89ff0.png\", \"name\": \"Sports\"}, {\"categoryID\": \"cfc2ef8c1e744e22b81316808f187f5e\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/575/9309de96323d42fdb9b0f5d9fc5c8a97.png\", \"name\": \"Strategy\"}, {\"categoryID\": \"5c195cf59d1e411ca623bc7f05845c2c\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/539/9f8ee977b705496fa4bbe5f8e4aed7fa.png\", \"name\": \"Trivia\"}, {\"categoryID\": \"9f410ee52a594ad3b75ebf41b9cb71da\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/263/f334c44894c640fdbc67b5dccceec0ae.png\", \"name\": \"Word\"}, {\"categoryID\": \"7deae206adf442c4a8a42801642e684a\", \"imgUrl\": \"http://cdn2.palmplaystore.com/static/840/cd6eb1b0412e4fc2b0a7c4df939dec55.png\", \"name\": \"Family\"}]}";

    public long getCategoryDataMark() {
        if (mAppCategoryData == null || mGameCategoryData == null) {
            return 0;
        }
        return mAppCategoryData.dataMark;
    }

    private long mAppCategoryLastReqApiTime = 0;
    private long mGameCategoryLastReqApiTime = 0;

    /**
     * 每24小时获取一次category数据
     */
    public boolean fetchCategoryData(boolean needUpdate,final int reqType) {
        LogUtils.d(LogUtils.TAG_CATEGORY, "fetchCategoryData " + needUpdate);
        boolean check = getAppCategoryData(needUpdate,reqType);
        check = getGameCategoryData(needUpdate,reqType);
        return check;
    }

    public void fetchCategoryDataForce(final int reqType) {
        LogUtils.d(LogUtils.TAG_CATEGORY, "fetchCategoryData ");
        softCategoryTypeTabItemHttpRequestApp(reqType, System.currentTimeMillis() - mAppCategoryLastReqApiTime);
        softCategoryTypeTabItemHttpRequestGame(reqType, System.currentTimeMillis() - mGameCategoryLastReqApiTime);
    }

    public long loadInterval(boolean needUpdate) {

        if (mAppCategoryData != null) {
            return needUpdate ? mAppCategoryData.loadTimeInterval * Constants.TIME_HOUR_UNIT : mAppCategoryData.reloadTimeInterval * Constants.TIME_HOUR_UNIT;
        }
        if (mGameCategoryData != null) {
            return needUpdate ? mGameCategoryData.loadTimeInterval * Constants.TIME_HOUR_UNIT : mGameCategoryData.reloadTimeInterval * Constants.TIME_HOUR_UNIT;
        }

        return DEFAULT_REQUEST_INTERVAL;
    }

    private boolean getAppCategoryData(boolean needUpdate,final int reqType) {
        if (mAppCategoryLastReqApiTime == 0) {
            mAppCategoryLastReqApiTime = TRSharedPreferenceUtils.getAppCategoryRequestTime();
        }

        long interval = loadInterval(needUpdate);
        long diffTime = System.currentTimeMillis() - mAppCategoryLastReqApiTime;
        if (diffTime < interval) {
            LogUtils.d(LogUtils.TAG_CATEGORY,"getAppCategoryData request < interval time " + interval);
            ApmAppCacheUtil.getInstance().startCollectCacheTime(ApmAppCacheUtil.category_app_t, diffTime);
            return false;
        }
        mAppCategoryLastReqApiTime = System.currentTimeMillis();
        TRSharedPreferenceUtils.setAppCategoryRequestTime(mAppCategoryLastReqApiTime);

        if (needUpdate) {
            softCategoryTypeTabItemHttpRequestApp(reqType, diffTime);
            return true;
        }
        return false;
    }

    private void softCategoryTypeTabItemHttpRequestApp(final int reqType,long diffTime) {
        LogUtils.d(LogUtils.TAG_CATEGORY,"getAppCategoryData softCategoryTypeTabItemHttpRequest ");
        NetworkClient.softCategoryTypeTabItemHttpRequest(Constant.SOFTTYPE_APP, null, new AbsRequestListener<CategoryData>() {
            @Override
            public void onResponse(CategoryData response) {
                super.onResponse(response);

                int size = 0;
                long costTime = 0;
                String result = "E";

                if (response != null) {
                    result = "S";
                    mAppCategoryData = response;
                    if (mAppCategoryData.categoryList != null){
                        size = mAppCategoryData.categoryList.size();
                    }
                    TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,1, response.dataMark+"",
                            Constants.SCENE_CATEGORY_KEY+"_APP",UpdateControlManager.getAbTestStatus(),-1,""+reqType);

                    long startTime = System.currentTimeMillis();
                    saveData(Constant.SOFTTYPE_APP, mAppCategoryData);
                    costTime = System.currentTimeMillis() - startTime;
                } else {
                    TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,0, "",
                            Constants.SCENE_CATEGORY_KEY+"_APP",UpdateControlManager.getAbTestStatus(),-1,""+reqType);
                }

                ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.category_app_t,
                        diffTime, mAppCategoryLastReqApiTime, result, size, costTime);
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,0, "",
                        Constants.SCENE_CATEGORY_KEY+"_APP",UpdateControlManager.getAbTestStatus(),-1,""+reqType);
                ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.category_app_t,
                        diffTime, mAppCategoryLastReqApiTime, anError);
            }
        }, Constant.SOFTTYPE_APP + CategoryCache.class.getName());
    }

    private void softCategoryTypeTabItemHttpRequestGame(final int reqType,long diffTime) {
        LogUtils.d(LogUtils.TAG_CATEGORY,"getGameCategoryData softCategoryTypeTabItemHttpRequest ");
        LogUtils.d("softCategoryTypeTabItemHttpRequest", "thread:"+ Thread.currentThread().getName() +","+ Looper.getMainLooper().isCurrentThread());
        NetworkClient.softCategoryTypeTabItemHttpRequest(Constant.SOFTTYPE_GAME, null, new AbsRequestListener<CategoryData>() {
            @Override
            public void onResponse(CategoryData response) {
                super.onResponse(response);

                long costTime = 0;
                String result = "E";
                int size = 0;

                if (response != null) {
                    result = "S";
                    mGameCategoryData = response;
                    if (mGameCategoryData.categoryList != null){
                        size = mGameCategoryData.categoryList.size();
                    }

                    TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,1, response.dataMark+"",
                            Constants.SCENE_CATEGORY_KEY+"_GAME",UpdateControlManager.getAbTestStatus(),-1,""+reqType);
                    long startTime = System.currentTimeMillis();
                    saveData(Constant.SOFTTYPE_GAME, mGameCategoryData);
                    costTime = System.currentTimeMillis() - startTime;
                } else {
                    TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,0, "",
                            Constants.SCENE_CATEGORY_KEY+"_GAME",UpdateControlManager.getAbTestStatus(),-1,""+reqType);
                }

                ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.category_game_t,
                        diffTime, mGameCategoryLastReqApiTime, result, size, costTime);
            }

            @Override
            public void onError(ANError anError) {
                super.onError(anError);
                TRAnalysticsUtil.trackQpsEvent(UpdateControlManager.BUSSINESS,0, "",
                        Constants.SCENE_CATEGORY_KEY+"_GAME",UpdateControlManager.getAbTestStatus(),-1,""+reqType);
                ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.category_game_t,
                        diffTime, mGameCategoryLastReqApiTime, anError);
            }
        }, Constant.SOFTTYPE_GAME + CategoryCache.class.getName());
    }

    private boolean getGameCategoryData(boolean needUpdate,final int reqType) {
        if (mGameCategoryLastReqApiTime == 0) {
            mGameCategoryLastReqApiTime = TRSharedPreferenceUtils.getGameCategoryRequestTime();
        }

        long interval = loadInterval(needUpdate);

        long diffTime = System.currentTimeMillis() - mGameCategoryLastReqApiTime;
        if (System.currentTimeMillis() - mGameCategoryLastReqApiTime < interval) {
            LogUtils.d(LogUtils.TAG_CATEGORY,"getGameCategoryData request < interval time " + interval);

            ApmAppCacheUtil.getInstance().startCollectCacheTime(ApmAppCacheUtil.category_game_t, diffTime);
            return false;
        }

        mGameCategoryLastReqApiTime = System.currentTimeMillis();
        TRSharedPreferenceUtils.setGameCategoryRequestTime(mGameCategoryLastReqApiTime);
        if (needUpdate) {
            softCategoryTypeTabItemHttpRequestGame(reqType, diffTime);
            return true;
        }
        return false;
    }

    private void saveData(String categoryKey, CategoryData response) {
        LogUtils.d(LogUtils.TAG_CATEGORY, "fetchCategoryData saveData categoryKey = " + categoryKey);
        if (response != null) {
            saveToCache(categoryKey, response);
        }
    }
}

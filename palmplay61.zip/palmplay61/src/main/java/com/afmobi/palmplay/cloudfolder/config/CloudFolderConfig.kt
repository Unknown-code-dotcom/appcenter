package com.afmobi.palmplay.cloudfolder.config

import com.transsnet.launcherlib.model.FileFolderData
import com.transsnet.launcherlib.services.DispenseDataManager
import java.io.Serializable


data class CloudFolderConfig(
    val isOpen: Int = 1, //1:开 2：关
    var reqInterval: Int = 0, //请求间隔
    var count: Int = 0, //显示物料个数
    var clickType: Int = 0, //1:直接开始下载;2:跳转半屏详情页;3:web游戏跳转
    var isSupportWiFI: Int = 1, //是否支持wifi下载
    var attr: String? = null,
    var uiStyle: Int = 1,
    var leaderScroll: Int = 0,
    var dynamicIconSwitch: Int = 0,
    var dynamicIconLimit: Int = 0
) : Serializable

data class SwitchInfoDTO(

    val notDownAlpha: Float = 0f,

    val notDownStyle: Int = 0
) : Serializable

fun FileFolderData.DataItem.Config.convertToSplitConfig(): CloudFolderConfig {
    return CloudFolderConfig(
        DispenseDataManager.getInstance().fileFolderGetPermissionStatus,
        cloudReqPer,
        needNum,
        downloadType,
        1,
        attr,
        uiStyle,
        leaderScroll,
        dynamicIcon?.switchStatus ?: 0,
        dynamicIcon?.displayLimit ?: 0
    )
}



package com.afmobi.palmplay.cloudfolder

import android.annotation.SuppressLint
import android.app.Application
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.TypedArray
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.UserHandle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.content.pm.ShortcutManagerCompat.FLAG_MATCH_PINNED
import androidx.core.graphics.drawable.IconCompat
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfoMapper
import com.afmobi.palmplay.cloudfolder.config.CloudFolderConfig
import com.afmobi.palmplay.cloudfolder.config.SwitchInfoDTO
import com.afmobi.palmplay.cloudfolder.config.convertToSplitConfig
import com.afmobi.palmplay.cloudfolder.model.*
import com.afmobi.palmplay.cloudfolder.page.BaseCloudFolderActivity
import com.afmobi.palmplay.cloudfolder.page.getFlagState
import com.afmobi.palmplay.cloudfolder.page.setFlagState
import com.afmobi.palmplay.cloudfolder.receiver.CloudFolderShortcutReceiver
import com.afmobi.palmplay.cloudfolder.track.CloudFolderTrackUtil
import com.afmobi.palmplay.cloudfolder.utils.ADD_WIDGET_SUCCESS_ACTION
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_GAMES
import com.afmobi.palmplay.cloudfolder.utils.CREATE_SHORTCUT
import com.afmobi.palmplay.cloudfolder.utils.CREATE_SHORTCUT_ID
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.FOLDER_STATUS
import com.afmobi.palmplay.cloudfolder.utils.KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG
import com.afmobi.palmplay.cloudfolder.utils.KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG
import com.afmobi.palmplay.cloudfolder.utils.KEY_CLOUD_FOLDER_USE_LAUNCHER_BG
import com.afmobi.palmplay.cloudfolder.utils.PreInstallConfigUtils
import com.afmobi.palmplay.cloudfolder.utils.SystemProperties
import com.afmobi.palmplay.cloudfolder.utils.TYPE_GET_ALL
import com.afmobi.palmplay.cloudfolder.utils.TYPE_GET_CACHED
import com.afmobi.palmplay.cloudfolder.utils.WallpaperUtils
import com.afmobi.palmplay.cloudfolder.utils.decodeBitmapFromResource
import com.afmobi.palmplay.cloudfolder.utils.formatLocalized
import com.afmobi.palmplay.cloudfolder.utils.getFolderTitle
import com.afmobi.palmplay.cloudfolder.utils.getInstalledSourcePackageName
import com.afmobi.palmplay.cloudfolder.utils.getSafeString
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.utils.isFirstBootAfterOta
import com.afmobi.palmplay.cloudfolder.utils.isHotAppsFolder
import com.afmobi.palmplay.cloudfolder.utils.mainScope
import com.afmobi.palmplay.download.DownloadDecorator
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.support.SupportExternalDownload
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.model.AppInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.model.v6_0.TabType
import com.afmobi.palmplay.model.v6_3.PageConstants
import com.afmobi.palmplay.model.v6_3.PageParamInfo
import com.afmobi.palmplay.search.v9_3.SearchUtil
import com.afmobi.palmplay.stub.StubDownloadProvider
import com.afmobi.palmplay.stub.StubDownloadTwoProvider
import com.afmobi.palmplay.viewmodel.search.ISearchInterface
import com.google.gson.reflect.TypeToken
import com.transsion.hubsdk.common.init.TranHubSdkManager
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import com.transsion.palmstorecore.bitmap.TRBitmapManager
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.ChangeAppNameUtil
import com.transsion.palmstorecore.util.GsonUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsion.palmstorecore.util.registerReceiverExported
import com.transsion.uiengine.theme.common.UiEngineConstants
import com.transsion.uiengine.theme.utils.UiEngineUtilities
import com.transsion.widgetslib.util.Utils
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.model.FileFolderData.DataItem
import com.transsnet.launcherlib.services.DispenseDataManager
import com.transsnet.launcherlib.util.PhoneUtils
import com.transsnet.store.BuildConfig
import com.transsnet.store.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

class CloudFolderManager private constructor() {

    private val TAG = "CloudFolderManager"

    val FILE_FOLDER_FROM_SITE_APP = "FL_A"
    val FILE_FOLDER_FROM_SITE_GAME = "FL_G"

    private val DEEP_LINK_PS_HOME = "palmplay://thirdlauncher.com/?entryType=HomeFeatured&_source="

    val KEY_CLOUD_FOLDER_LAST_REQUEST = "key_cloud_folder_last_request"

    private var mRegistered = false

    /**
     * 硬预装应用列表
     */
    private var preInstallAppList : MutableList<CloudAppInfo> ?= null
    private var preInstallGameList : MutableList<CloudAppInfo> ?= null

    // 1. 定义状态标识
    private var isLauncherCallbackRegistered = false

    private var isPreinstallInitialized = false

    private val stateLock = Any()

    /**
     * characteristics值: pad:"tablet"
     */
    private var characteristics: String? = null

    private var isPad: Boolean? = null
    fun isPad(): Boolean {
        if(isPad == null) {
            if(characteristics == null) {
                characteristics = SystemProperties.get("ro.build.characteristics")
            }

            isPad = characteristics?.contains("tablet")
        }
        return isPad == true
    }

    /**
     * 底部推荐列表 - 使用 StateFlow 保证线程安全
     */
    private val _appBottomIconFlow = MutableStateFlow<List<CloudAppInfo>>(emptyList())
    val appBottomIconFlow: StateFlow<List<CloudAppInfo>> = _appBottomIconFlow.asStateFlow()

    private val _gameBottomIconFlow = MutableStateFlow<List<CloudAppInfo>>(emptyList())
    val gameBottomIconFlow: StateFlow<List<CloudAppInfo>> = _gameBottomIconFlow.asStateFlow()

    private val launcherAppCallback : LauncherApps.Callback by lazy {
        object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
                packageName?.let {
                    removePreInstallItem(it)
                }
            }
            override fun onPackageAdded(packageName: String?, user: UserHandle?) {
            }
            override fun onPackageChanged(packageName: String?, user: UserHandle?) {
                ioScope.launch {
                    onPackageChanged(packageName)
                }
            }
            override fun onPackagesAvailable(
                packageNames: Array<out String>?,
                user: UserHandle?,
                replacing: Boolean
            ) {

            }
            override fun onPackagesUnavailable(
                packageNames: Array<out String>?,
                user: UserHandle?,
                replacing: Boolean
            ) {
            }
        }
    }

    val isOriginWidgetStyle : Boolean by lazy {
        PhoneUtils.isOriginSplit()
    }

    val isRuCountry : Boolean by lazy {
            val os16DisplayId = SystemProperties.get("ro.tr_build.sw_market")
            if(!TextUtils.isEmpty(os16DisplayId)) {
                os16DisplayId.lowercase(Locale.getDefault()).contains("ru")
            } else {
                val displayId = SystemProperties.get("ro.tran.sw.market")
                if (TextUtils.isEmpty(displayId)) {
                    SystemProperties.get("ro.build.display.id").lowercase(Locale.getDefault())
                        .contains("-ru")
                } else {
                    displayId.lowercase(Locale.getDefault()).contains("ru")
                }
            }
    }

    val isIndCountry : Boolean by lazy {
        val os16DisplayId = SystemProperties.get("ro.tr_build.sw_market")
        if(!TextUtils.isEmpty(os16DisplayId)) {
            os16DisplayId.lowercase(Locale.getDefault()).contains("in") && isLauncherSupport
        } else {
            val displayId = SystemProperties.get("ro.tran.sw.market")
            if (TextUtils.isEmpty(displayId)) {
                SystemProperties.get("ro.build.display.id").lowercase(Locale.getDefault())
                    .contains("-in") && isLauncherSupport
            } else {
                displayId.lowercase(Locale.getDefault()).contains("in") && isLauncherSupport
            }
        }

    }

    private val useNewTitle : Boolean by lazy {
        ChangeAppNameUtil.isAfter1610()
    }

    private val isLauncherSupport : Boolean by lazy {
        val launcherPackageName = getLauncherPackageName()
        val result = PalmplayApplication.getAppInstance()?.let {
           try {
                val resources = it.createPackageContext(
                    launcherPackageName,
                    Context.CONTEXT_IGNORE_SECURITY
                )?.resources
                resources?.let { res->
                    var resId = res.getIdentifier("config_support_cloud_folder_in", "bool", launcherPackageName)
                    if(resId != 0) {
                        res.getBoolean(resId)
                    } else {
                        false
                    }
                } ?: false
           }catch (e : Exception) {
               LogUtils.e(TAG,e)
               false
           }
        } ?: false
        LogUtils.i(TAG, " isLauncherSupport: $result")
        result
    }

    /**
     * 是否 Android 17 (API 37) 及以上
     */
    fun isAndroid17OrAbove(): Boolean = Build.VERSION.SDK_INT >= 37

    /**
     * 桌面是否支持设置云文件夹背景
     */
    val isLauncherSupportBackground : Boolean by lazy {
        val launcherPackageName = getLauncherPackageName()
        val result = PalmplayApplication.getAppInstance()?.let {
            try {
                val resources = it.createPackageContext(
                    launcherPackageName,
                    Context.CONTEXT_IGNORE_SECURITY
                )?.resources
                resources?.let { res->
                    var resId = res.getIdentifier("support_cloud_folder_background", "bool", launcherPackageName)
                    if(resId != 0) {
                        res.getBoolean(resId)
                    } else {
                        false
                    }
                } ?: false
            }catch (e : Exception) {
                LogUtils.e(TAG,e)
                false
            }
        } ?: false
        LogUtils.i(TAG, " isLauncherSupport: $result")
        result
    }

    /**
     * 是否Launcher显示背景
     * Android 17+ 默认 true，后续链路以此为准
     */
    var isLauncherShowBg = isAndroid17OrAbove()

    companion object {
        private val ACTION_PALM_WIDGET_REMOVE = "ACTION_PALM_WIDGET_REMOVE"
        private val ACTION_PALM_SEND_TO_HOME= "add_app_to_desktop"
        private const val EXTRA_REMOVE_TYPE = "EXTRA_REMOVE_TYPE"
        private const val EXTRA_SEND_PACKAGE = "app_pkgname"
        private const val REMOVE_ALL = 0
        private const val REMOVE_APP_WIDGET = 1
        private const val REMOVE_GAME_WIDGET = 2

        const val TAG = "CloudFolderManager"
        private const val CLOSE_STATUS = "1"

        private const val CLOSE_TYPE_ITEL = 1

        // --- 样式枚举定义 ---
        const val LAYOUT_STYLE_ORIGINAL = 1      // 样式1: 原版 (Grid + Bottom)
        const val LAYOUT_STYLE_RANK_GRID = 2     // 样式2: 榜单 + 网格 (无底部)
        const val LAYOUT_STYLE_RANK_LIST = 3     // 样式3: 榜单 + 多列表 (无底部)
        const val LAYOUT_STYLE_SIMPLE_RANK = 4   // 样式4: 极简榜单 (Grid + Bottom)

        const val LEADER_SCROLL_OFF = 0 // 榜单皇冠部分固定
        const val LEADER_SCROLL_ON = 1  // 榜单皇冠部分滚动

        @Volatile
        private var INSTANCE: CloudFolderManager? = null

        fun getInstance(): CloudFolderManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudFolderManager().also { INSTANCE = it }
            }
        }
    }

    fun init(context: Context?) {
        ioScope.launch {
            DeviceProfile.getInstance().initData()
            context?.packageManager?.setComponentEnabledSetting(
                ComponentName(context, StubDownloadProvider::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
            context?.packageManager?.setComponentEnabledSetting(
                ComponentName(context, StubDownloadTwoProvider::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
            if(isWidgetSplit()) {
                CloudFolderRemoteController.getInstance()
                    .initCloudFolderRemoteConfigObserver(context)
                try {
                    TranHubSdkManager.getInstance().init(context)
                }catch (e: Exception) {
                    LogUtils.e(TAG, e)
                }
                AttributionUploadManager.getInstance().enqueueRetryRequest()
                initCloudFolderBackground()
                if (isWidgetHasAdded(FOLDER.APPS)) {
                    DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
                        FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT
                    updateWidgetRemoteView(context, FOLDER.APPS)
                } else {
                    context?.let {
                        setComponentEnable(it, ComponentName(it, AppFolderProvider::class.java))
                    }
                }
                if (isWidgetHasAdded(FOLDER.GAMES)) {
                    updateWidgetRemoteView(context, FOLDER.GAMES)
                } else {
                    context?.let {
                        setComponentEnable(it, ComponentName(it, GameFolderProvider::class.java))
                    }
                }
                initPreInstallData()
                mainScope.launch {
                    registerApkUninstall()
                }
            } else {
                context?.packageManager?.setComponentEnabledSetting(
                    ComponentName(context, AppFolderProvider::class.java),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
                )

                context?.packageManager?.setComponentEnabledSetting(
                    ComponentName(context, GameFolderProvider::class.java),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
                )
            }
        }
    }

    private fun initPreInstallData() {
        try {
            preInstallAppList = getPreInstallListFromJson(KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG)
            preInstallGameList = getPreInstallListFromJson(KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG)
            isPreinstallInitialized = true
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    private fun getPreInstallListFromJson(contentKey: String) : MutableList<CloudAppInfo>? {
        val contentValue = MMKVUtils.getMultiMMKV().getString(contentKey, "")
        return contentValue?.run {
            val packageList = GsonUtils.getInstance()
                .fromJson<List<String>>(
                    this,
                    object : TypeToken<List<String>>() {}.type
                )
            val preInstallList = packageList?.mapNotNull {
                generateInstallAppInfo(it)
            }?.toMutableList()
            savePreInstallListToLocal(preInstallList, contentKey)
            return preInstallList
        }
    }

    private fun registerApkUninstall()  {
        try {
            // 2. 如果已经注册过，直接返回，不再执行后续逻辑
            if (isLauncherCallbackRegistered) return
            if (preInstallAppList.isNullOrEmpty() && preInstallGameList.isNullOrEmpty()) {
                return
            }
            // 2. 检查双非空条件
            val appInstance = PalmplayApplication.getAppInstance()
            appInstance?.let {
                val service = it.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
                service.registerCallback(launcherAppCallback)
                // 4. 更新标识位
                isLauncherCallbackRegistered = true
            }
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    /**
     * 初始化云文件夹状态
     */
    private fun initCloudFolderBackground() {
        try {
            isLauncherShowBg = PalmplayApplication.getAppInstance()?.let {
                synchronized(stateLock) {
                    val appWidgetManager = AppWidgetManager.getInstance(it)
                    val widgetStatus =
                        readState(it, appWidgetManager, null, FOLDER.APPS.widgetClass)
                    val localStatus =
                        MMKVUtils.getMultiMMKV().getBoolean(KEY_CLOUD_FOLDER_USE_LAUNCHER_BG, false)
                    LogUtils.i(
                        Companion.TAG,
                        "initCloudFolderBackground:  $widgetStatus ----  $localStatus"
                    )
                    // Android 17+ 默认使用 Launcher 背景，不依赖其它条件；低版本仍按 Options/MMKV OR
                    val finalStatus = if (isAndroid17OrAbove()) {
                        true
                    } else {
                        widgetStatus || localStatus
                    }
                    // 同步 MMKV（含 Android 17 默认 true 落盘）
                    if (localStatus != finalStatus) {
                        MMKVUtils.getMultiMMKV().putBoolean(KEY_CLOUD_FOLDER_USE_LAUNCHER_BG, finalStatus)
                    }
                    //保存状态
                    saveWidgetState(it, FOLDER.APPS.widgetClass, finalStatus)
                    saveWidgetState(it, FOLDER.GAMES.widgetClass, finalStatus)
                    finalStatus
                }
            } ?: isAndroid17OrAbove()
        } catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    private fun setComponentEnable(context: Context?,componentName: ComponentName) {
        context?.packageManager?.apply {
            if(getComponentEnabledSetting(componentName) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                setComponentEnabledSetting(
                    componentName ,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
                )
            }
        }
    }

    private fun getLauncherPackageName(): String {
        return if(Build.VERSION.SDK_INT > 35) {
            "com.transsion.launcher3"
        } else {
            if (Utils.IS_HIOS) {
                "com.transsion.hilauncher"
            } else if (Utils.IS_XOS) {
                "com.transsion.XOSLauncher"
            } else {
                "com.transsion.itel.launcher"
            }
        }
    }

    /**
     * 跳转到ps搜索页
     */
    fun goToPsSearchPage(categoryType: Int) {
        try {
            val fromSite = if (categoryType.isHotAppsFolder()) "FL_A_S" else "FL_G_S"
            val paramInfo = PageParamInfo(PageConstants.None, PageConstants.Extern_Search)
            val searchIntent: Intent = Intent(
                TRApplicationContextUtil.getInstance(),
                SearchUtil.getSearchClass()
            )
                .putExtra(TabType::class.java.simpleName, TabType.SOFT)
                .putExtra(ISearchInterface.KEY_CUR_SEARCH, "")
                .putExtra(ISearchInterface.KEY_BACK_TO_PS, true)
                .putExtra(ISearchInterface.KEY_IS_EXCUTE_SEARCH, false)
                .putExtra(ISearchInterface.KEY_TEXT_HINT, "")
                .putExtra(ISearchInterface.KEY_IS_TEXT_HINT, true)
                .putExtra(ISearchInterface.KEY_DEF_TEXT_HINT, "")
                .putExtra(ISearchInterface.KEY_IS_HIDE_KEYBOARD, true)
                .putExtra(TRAnalyticsConstant.FROM_SITE, fromSite)
                .putExtra(PageParamInfo::class.java.simpleName, paramInfo)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            TRApplicationContextUtil.getInstance().startActivity(searchIntent)

        } catch (e: Exception) {
            LogUtils.e("PalmStoreDownloadModel", e)
        }
    }

    /**
     * 跳转到ps首页
     */
    fun goToPsHomePage(categoryType: Int) {
        try {
            val deeplink: String =
                DEEP_LINK_PS_HOME + if (categoryType.isHotAppsFolder()) "FL_A" else "FL_G"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(deeplink))
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            TRApplicationContextUtil.getInstance().startActivity(intent)
        } catch (e: java.lang.Exception) {
            LogUtils.e("PalmStoreDownloadModel", e)
        }
    }

    /**
     * 获取App云文件夹的名称
     * @param notUseChinese true 该字符串不使用中文
     * @param useSystemLanguage true 使用系统语言，false 使用本地设置的语言
     */
    fun getAppFolderName(notUseChinese: Boolean = false, useSystemLanguage: Boolean = false): String {
        val context = TRApplicationContextUtil.getInstance()
        context?.resources?.let {
            return if (isIndCountry) {
                context.getSafeString(R.string.dialog_file_folder_title_app_in, notUseChinese, useSystemLanguage)
            } else {
                if(isUseNewTitle()) {
                    context.getSafeString(R.string.dialog_file_folder_title_more_app, notUseChinese, useSystemLanguage)
                } else {
                    context.getSafeString(R.string.dialog_file_folder_title_app, notUseChinese, useSystemLanguage)
                }
            }
        }
        return "Hot Apps"
    }

    /**
     * 获取Game云文件夹的名称
     * @param notUseChinese true 该字符串不使用中文
     * @param useSystemLanguage true 使用系统语言，false 使用本地设置的语言
     */
    fun getGameFolderName(notUseChinese: Boolean = false, useSystemLanguage: Boolean = false): String {
        val context = TRApplicationContextUtil.getInstance()
        context?.resources?.let {
            return if (isRuCountry) {
                var isRuLanguage = true
                try {
                    val locale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        it.configuration.locales[0]
                    } else {
                        @Suppress("DEPRECATION")
                        it.configuration.locale
                    }
                    val language = locale.language
                    isRuLanguage = language.equals(Locale("ru").language)
                }catch (_: Exception) { }
                if (isInfinix()) {
                    if (isRuLanguage) {
                        context.getSafeString(R.string.dialog_file_folder_title_game_infinix_ru, notUseChinese, useSystemLanguage)
                    } else {
                        context.getSafeString(R.string.dialog_file_folder_title_game_infinix_ru_en, notUseChinese, useSystemLanguage)
                    }
                }else {
                    if (isRuLanguage) {
                        context.getSafeString(R.string.dialog_file_folder_title_game_ru_content, notUseChinese, useSystemLanguage)
                    } else {
                        context.getSafeString(R.string.dialog_file_folder_title_game_ru_content_en, notUseChinese, useSystemLanguage)
                    }
                }
            } else if(isIndCountry) {
                context.getSafeString(R.string.dialog_file_folder_title_game_in, notUseChinese, useSystemLanguage)
            } else {
                if(isUseNewTitle()) {
                    context.getSafeString(R.string.dialog_file_folder_title_more_game, notUseChinese, useSystemLanguage)
                } else {
                    context.getSafeString(R.string.dialog_file_folder_title_game, notUseChinese, useSystemLanguage)
                }
            }
        }
        return "Hot Games"
    }

    fun isUseNewTitle() : Boolean {
        return useNewTitle
    }

    /**
     * 获取setting页面的标题
     */
    fun getFolderSettingTitle() : String{
        val folderSettingTitle = StringBuilder()
        val separator = PalmplayApplication.getAppInstance().getString(R.string.cloud_folder_title_separator)

        if (CloudFolderRemoteController.getInstance().isCloudFolderShow(FOLDER.APPS)) {
            folderSettingTitle.append(getAppFolderName(true))
            folderSettingTitle.append(separator)
        }
        if (CloudFolderRemoteController.getInstance().isCloudFolderShow(FOLDER.GAMES)) {
            folderSettingTitle.append(getGameFolderName(true))
        } else {
            val index = folderSettingTitle.lastIndexOf(separator)
            if(index >= 0) {
                folderSettingTitle.delete(index, index + separator.length)
            }
        }
        return folderSettingTitle.toString()
    }

    /**
     * 获取setting页面的内容
     */
    fun getFolderSettingContent() : String{
        return TRApplicationContextUtil.getInstance()?.resources?.let {
            val folderSettingTitle = getFolderSettingTitle()
            val folderSettingContent = StringBuilder()
            val hotSwitchOpen = CloudFolderRemoteController.getInstance().isCloudFolderShow(FOLDER.APPS)
            val gameSwitchOpen = CloudFolderRemoteController.getInstance().isCloudFolderShow(FOLDER.GAMES)
            if(hotSwitchOpen) {
                if(gameSwitchOpen) {
                    folderSettingContent.append(it.getString(R.string.setting_file_folder_content_all))
                } else {
                    folderSettingContent.append(it.getString(R.string.setting_file_folder_content_hot))
                }
            } else if(gameSwitchOpen) {
                if(isRuCountry) {
                    folderSettingContent.append(it.getString(R.string.setting_file_folder_content_hot))
                } else {
                    folderSettingContent.append(it.getString(R.string.setting_file_folder_content_game))
                }
            }
            val content = it.getString(R.string.setting_file_folder_switch_content)
            content.formatLocalized(folderSettingTitle, folderSettingContent)
        } ?: ""
    }

    /**
     * 是否是Infinix手机
     * @return
     */
    private fun isInfinix(): Boolean {
        try {
            val product = Build.BRAND.lowercase(Locale.getDefault()).trim()
            return TextUtils.equals(product, "infinix")
        } catch (e: java.lang.Exception) {
        }
        return false
    }

    fun updateFolder(categoryType: FOLDER, bitmap: Bitmap?) {
        if(isShortcutSplit()) {
            updateShortCut(categoryType, bitmap)
        } else {
            updateWidget(categoryType, bitmap)
        }
    }

    /**
     * 更新快捷方式样式
     */
    private fun updateShortCut(categoryType: FOLDER, bitmap: Bitmap?) {
        val instance = TRApplicationContextUtil.getInstance()
        instance?.let {
            try {
                val folderIcon = if(bitmap != null && !bitmap.isRecycled) {
                    bitmap
                } else {
                    decodeBitmapFromResource(categoryType.defaultShortcutDrawable)
                } ?: return
                ShortcutManagerCompat.updateShortcuts(it, listOf(
                    ShortcutInfoCompat.Builder(it, categoryType.shortcutId)
                        .setShortLabel(categoryType.getFolderTitle())
                        .setIcon(IconCompat.createWithBitmap(folderIcon))
                        .setIntent(Intent(categoryType.shortcutAction))
                        .build()
                ))
            }catch (e: Exception) {
                LogUtils.i(TAG, " updateShortCut fail:  $e")
            }
        }

    }

    /**
     * 更新小部件样式
     */
    private fun updateWidget(categoryType: FOLDER, bitmap: Bitmap?) {
        val instance = TRApplicationContextUtil.getInstance()
        instance?.let {context->
            val widgetManager = AppWidgetManager.getInstance(context)
            widgetManager.updateAppWidget(
                ComponentName(context, categoryType.widgetClass),
                generateRemoteView(context, categoryType, bitmap)
            )
        }
    }

    private fun generateRemoteView(context : Context,categoryType: FOLDER, bitmap: Bitmap?) : RemoteViews{
        var remoteView: RemoteViews
        if(PhoneUtils.isOriginSplit()) {
            remoteView = RemoteViews(context.packageName, R.layout.layout_cloud_folder_widget_origin)
            remoteView.setTextViewText(R.id.tvFolderName, categoryType.getFolderTitle())
            val horizontalPadding = context.resources.getDimensionPixelSize(R.dimen.dp_4)
            remoteView.setViewPadding(R.id.tvFolderName, horizontalPadding, 0, horizontalPadding, 0)
        } else {
            remoteView = RemoteViews(context.packageName, R.layout.layout_widget_cloud_folder)
            LogUtils.e(Companion.TAG," generateRemoteView: $isLauncherShowBg ")
            if(isLauncherShowBg) {
                remoteView.setViewVisibility(R.id.ivFolderBg, View.GONE)
            }
        }
        if(bitmap != null && !bitmap.isRecycled) {
            remoteView.setImageViewBitmap(R.id.folderView, bitmap)
        } else {
            remoteView.setImageViewResource(R.id.folderView, categoryType.defaultDrawable)
        }
        val intent = Intent(context, categoryType.pageClass)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK )
        intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        remoteView.setOnClickPendingIntent(R.id.folderBackground, pendingIntent);
        return remoteView
    }

    /**
     * 获取云文件夹物料数据
     * @param type 1: 全量  2：图片缓存好的
     * @param categoryType 类型 1: apps 2: games
     */
    /**
     * 获取云文件夹物料数据 (重构版：返回结构化视图数据)
     * @param type 1: 全量  2：图片缓存好的
     * @param categoryType 类型 1: apps 2: games
     */
    fun getCloudFolderData(
        categoryType: Int,
        type : Int,
        fail: ((error: String?) -> Unit)?,
        success: ((response: CloudFolderViewData) -> Unit)?
    ) {
        val splitAppList: List<DataItem.Apps>? =
            try {
                DispenseDataManager.getInstance().getSplitFileFolderData(
                    categoryType,
                    getDownloadingPackageForSplit()
                )
            } catch (e: Exception) {
                LogUtils.e(e)
                null
            }

        val appListByType = getAppPreInstallListByType(categoryType)

        if (splitAppList.isNullOrEmpty() && appListByType.isNullOrEmpty()) {
            fail?.invoke("no data")
        } else {
            var responseList: List<CloudAppInfo>? = try {
                CloudAppInfoMapper.mapList(splitAppList)
            } catch (e: Exception) {
                LogUtils.e(TAG, "getCloudFolderData mapList failed", e)
                null
            }

            var serverApps = (responseList ?: emptyList()).toMutableList()

            // 1. 缓存过滤
            if(type == TYPE_GET_CACHED) {
                serverApps = serverApps.filter {
                    TRBitmapManager.isImageCached(it.iconUrl)
                }.toMutableList()
            }

            // 2. 获取样式配置
            val layoutStyle = getCloudFolderUiStyle()
            val leaderScroll = getCloudFolderLeaderScroll()
            val fixRankTile = leaderScroll == LEADER_SCROLL_OFF

            // 3. 底部推荐处理 (样式1, 4 支持)
            val bottomList = mutableListOf<CloudAppInfo>()
            val isRecentlyInstalledOn = isRecentlyInstalledEnabled(categoryType, layoutStyle)
            val isSupportBottom = (layoutStyle == LAYOUT_STYLE_ORIGINAL || layoutStyle == LAYOUT_STYLE_SIMPLE_RANK)
                    && !isRecentlyInstalledOn
            if (isSupportBottom && getBottomSwitch(categoryType)) {
                val isFilterAdx = isBottomFilterEwSource()
                val actualStartIndex = kotlin.math.max(0, getBottomIconOffset() - 1)

                val filteredList = mutableListOf<CloudAppInfo>()
                serverApps.forEachIndexed { index, item ->
                    val canPickForBottom = index >= actualStartIndex
                            && bottomList.size < 4
                            && item.jumpType == 0
                            && !(isFilterAdx && item.isAdxItem())

                    if (canPickForBottom) {
                        item.layoutStyle = layoutStyle
                        bottomList.add(item)
                    } else {
                        filteredList.add(item)
                    }
                }
                serverApps = filteredList

                // 预缓存底部列表图标
                if (bottomList.isNotEmpty()) {
                    bottomList.forEach { item ->
                        if (!item.iconUrl.isNullOrEmpty() && !TRBitmapManager.isImageCached(item.iconUrl)) {
                            TRBitmapManager.prefetchToBitmapCacheByFresco(item.iconUrl, 0, 0)
                        }
                    }
                }
            }

            // 4. 动态 Icon 策略分配
            applyDynamicIconStrategy(layoutStyle, serverApps, bottomList)

            // 5. 构建主滚动列表 (scrollableItems)
            val scrollableItems = mutableListOf<BaseFolderUiModel>()
            val preInstallList = appListByType?.filter { it.isEnable } ?: emptyList()
            if (layoutStyle == LAYOUT_STYLE_ORIGINAL) {
                // 【非榜单样式 - 样式1】: 预装在首位，均为普通应用
                val mainPool = (preInstallList + serverApps).take(getCloudFolderShowCount(categoryType) + preInstallList.size)
                scrollableItems.addAll(mainPool.map { NormalAppUiModel(it) })
            } else {
                // 【榜单样式 - 样式2, 3, 4】

                // A. 提取前3个榜单应用，按样式分配不同的 UiModel
                val rankApps = serverApps.take(3)
                when (layoutStyle) {
                    LAYOUT_STYLE_RANK_GRID, LAYOUT_STYLE_RANK_LIST -> {
                        // 样式2/3: RankTitleUiModel（带皇冠标识的榜单标题样式）
                        val title = if (categoryType == CATEGORY_APP) "Hot Apps" else "Hot Games"
                        scrollableItems.addAll(rankApps.map { RankTitleUiModel(title, it) })
                    }
                    LAYOUT_STYLE_SIMPLE_RANK -> {
                        // 样式4: RankAppUiModel（简易榜单应用样式）
                        scrollableItems.addAll(rankApps.map { RankAppUiModel(it) })
                    }
                }
                val remainingServerApps = serverApps.drop(3)

                // C. 插入硬预装与剩余应用 (插入到第4个位置之后，即 index 3 或 4)
                // 根据逻辑，预装接在榜单后面
                val normalAppsPool = (preInstallList + remainingServerApps).take(getCloudFolderShowCount(categoryType) + preInstallList.size)
                scrollableItems.addAll(normalAppsPool.map { NormalAppUiModel(it) })
            }

            if (scrollableItems.isEmpty() && bottomList.isEmpty()) {
                fail?.invoke("no data")
            } else {
                success?.invoke(CloudFolderViewData(
                    layoutStyle = layoutStyle,
                    fixRankTile = fixRankTile,
                    showFixedBottom = isSupportBottom,
                    fixedBottomList = ArrayList(bottomList),
                    scrollableItems = ArrayList(scrollableItems)
                ))
            }
        }
    }

    /**
     * 执行动态 Icon 分配策略 (合并控制版)
     */
    private fun applyDynamicIconStrategy(
        layoutStyle: Int,
        mainList: List<CloudAppInfo>,
        bottomList: List<CloudAppInfo>
    ) {
        val globalSwitch = getDynamicIconSwitch() == LEADER_SCROLL_ON
        val globalLimit = getDynamicIconLimit()

        LogUtils.i(TAG, "applyDynamicIconStrategy globalSwitch=$globalSwitch globalLimit=$globalLimit layoutStyle=$layoutStyle mainSize=${mainList.size} bottomSize=${bottomList.size}")

        if (!globalSwitch || globalLimit <= 0) {
            mainList.forEach { it.showDynamicIcon = false }
            bottomList.forEach { it.showDynamicIcon = false }
            return
        }

        val maxStructuralLimit = when (layoutStyle) {
            LAYOUT_STYLE_ORIGINAL, LAYOUT_STYLE_SIMPLE_RANK -> 12
            LAYOUT_STYLE_RANK_GRID -> 12
            LAYOUT_STYLE_RANK_LIST -> 19
            else -> 12
        }

        var assignedCount = 0

        // 1. 主列表管控区域 [0, maxStructuralLimit)
        // 在配额内且有 dynamicIconUrl → 保持 true + 预缓存
        // 超出配额或无 dynamicIconUrl → 置为 false
        for ((index, app) in mainList.withIndex()) {
            if (index >= maxStructuralLimit) break // 超出管控区域，保持默认 true
            if (!app.dynamicIconUrl.isNullOrEmpty() && assignedCount < globalLimit) {
                assignedCount++
                // 预缓存动态图标
                if (!TRBitmapManager.isImageCached(app.dynamicIconUrl)) {
                    TRBitmapManager.prefetchToBitmapCacheByFresco(app.dynamicIconUrl, 0, 0)
                }
            } else {
                app.showDynamicIcon = false
            }
        }

        // 2. 底部列表管控（仅样式1、4）
        if (layoutStyle == LAYOUT_STYLE_ORIGINAL || layoutStyle == LAYOUT_STYLE_SIMPLE_RANK) {
            for (app in bottomList) {
                if (!app.dynamicIconUrl.isNullOrEmpty() && assignedCount < globalLimit) {
                    assignedCount++
                    // 预缓存动态图标
                    if (!TRBitmapManager.isImageCached(app.dynamicIconUrl)) {
                        TRBitmapManager.prefetchToBitmapCacheByFresco(app.dynamicIconUrl, 0, 0)
                    }
                } else {
                    app.showDynamicIcon = false
                }
            }
        }
    }


    private fun getAppPreInstallListByType(actionType: Int): List<CloudAppInfo>? {
        if (preInstallAppList == null && preInstallGameList == null) {
            if (!isPreinstallInitialized) {
                // 如果还未初始化完，尝试从本地读取一次
                LogUtils.i(TAG, "getAppPreInstallListByType -> not initialized, try read local")
                initPreInstallData()
            }
        }
        readPreInstallList()
        return when (actionType) {
            CATEGORY_APP ->
                preInstallAppList
            else -> {
                preInstallGameList
            }
        }
    }

    /**
     * 预装配置列表读取
     */
    private fun getPreInstallKeyByLocal(actionType: Int) : String {
        return if(actionType == CATEGORY_APP) {
            if(isRuCountry) {
                "cloud_folder_apps_ee1"
            } else {
                "cloud_folder_apps"
            }
        } else {
            if(isRuCountry) {
                "cloud_folder_games_ee1"
            } else {
                "cloud_folder_games"
            }
        }
    }

    private fun readPreinstallList(
        itemKey: String,
        oobeUninstallApks: MutableList<String>?,
        preKey: String
    ) : MutableList<CloudAppInfo>?{
        var resultList : MutableList<CloudAppInfo>? = null
        try {
            val preInstallPkgList = PreInstallConfigUtils.readArrayFromPackage(
                PalmplayApplication.getAppInstance(),
                preKey
            )
            resultList = preInstallPkgList.mapNotNull {
                if(oobeUninstallApks != null && oobeUninstallApks.contains(it)) {
                    LogUtils.i(TAG, "getAppPreInstallListByType: oobe uninstall item ---   $it")
                    null
                } else {
                    generateInstallAppInfo(it, true)
                }
            }.distinct().toMutableList()

            LogUtils.i(TAG, "getAppPreInstallListByType: $preKey ---   $resultList")
            if (!resultList.isEmpty()) {
                savePreInstallListToLocal(resultList, itemKey)
            }
        }catch (e: Exception) {
            LogUtils.e(e)
        }

        return resultList

    }

    private fun readPreInstallList() {
        //写入解散配置到系统属性
        if(isReadFromSys()) {
            //从系统属性读取解散配置。 默认执行原有逻辑 .set(itemKey, "1")
            saveReadStatus()
            if(isFirstBootAfterOta(PalmplayApplication.getAppInstance())) {
                LogUtils.i(CloudFolderManager.TAG, " isFirstBootAfterOta not load preInstall")
                return
            }
            if(!isLauncherSupportPreinstall()) {
                LogUtils.i(CloudFolderManager.TAG, " launcher not support preInstall")
                return
            }
            val oobeUninstallApks = getOOBEUninstallApks()

            preInstallAppList =  readPreinstallList(KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG, oobeUninstallApks,getPreInstallKeyByLocal(CATEGORY_APP))
            preInstallGameList =  readPreinstallList(KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG, oobeUninstallApks, getPreInstallKeyByLocal(CATEGORY_GAMES))

            mainScope.launch {
                registerApkUninstall()
            }
        }
    }

    private fun isLauncherSupportPreinstall() : Boolean {
        val launcherPackageName = getLauncherPackageName()
        val result = PalmplayApplication.getAppInstance()?.let {
            try {
                val resources = it.createPackageContext(
                    launcherPackageName,
                    Context.CONTEXT_IGNORE_SECURITY
                )?.resources
                resources?.let { res->
                    val resId = res.getIdentifier("config_support_preinstall", "bool", launcherPackageName)
                    if(resId != 0) {
                        res.getBoolean(resId)
                    } else {
                        false
                    }
                } ?: false
            }catch (e : Exception) {
                LogUtils.e(TAG,e)
                false
            }
        } ?: false
        LogUtils.i(TAG, " isLauncherSupportPreInstall: $result")
        return result
    }

    /*
     * 由于不同机型场景的异常，导致OOBE 卸载的应用卸载太晚，引起布局问题 OS150V-5288
     * 协同OOBE修复，OOBE通过把需要卸载的应用写入Settings值 suw_uninstall_apps
     * */
    fun getOOBEUninstallApks() : MutableList<String>? {
        PalmplayApplication.getAppInstance().let { application ->
            try {
                var uninstallApps =
                    Settings.Global.getString(application.contentResolver, "suw_uninstall_apps")
                if (uninstallApps == null) {
                    LogUtils.i(TAG, "initOOBEUninstallApks no uninstallApps,get from OOBE resource.")
                    return getOOBEResources(application)
                }
                uninstallApps = uninstallApps.replace("[", "").replace("]", "").replace(" ", "")
                val uninstallList =
                    uninstallApps.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toMutableList()
                LogUtils.i(TAG, "uninstall List: $uninstallList")
                return uninstallList
            }catch (e: Exception) {
                LogUtils.e(e)
            }
            return null
        }
    }

    @SuppressLint("Recycle")
    fun getOOBEResources(context: Context) : MutableList<String>? {
        //OOBE package name
        val packagename = "com.transsion.trproduct.overlaysuw.resoverlay"
        UiEngineUtilities.initUserCountryCode()
        val resourcename = UiEngineConstants.COUNTRY_CODE + "_uninstall_apps"
        val typedArray: TypedArray?
        LogUtils.i(TAG, "getOOBEResources resourcename:$resourcename")
        val oobeUninstallApks = ArrayList<String>()
        try {
            val authContext = context.createPackageContext(packagename, 0)
            val id = authContext.resources.getIdentifier(resourcename, "array", packagename)
            LogUtils.i(TAG, "getOOBEResources resource name:$resourcename, id:$id")
            if (id != 0) {
                typedArray = authContext.resources.obtainTypedArray(id)
                if (typedArray.length() <= 0) {
                    return null
                }
                oobeUninstallApks.clear()
                for (i in 0..<typedArray.length()) {
                    val item = typedArray.getString(i)
                    item?.let {
                        oobeUninstallApks.add(it)
                    }
                    LogUtils.i(TAG, "getOOBEResources oobeUninstallApks add:" + typedArray.getString(i)
                    )
                }
            }
        } catch (e: PackageManager.NameNotFoundException) {
            LogUtils.i(TAG, "$packagename Exception", e)
        } catch (e: Exception) {
            LogUtils.i(TAG, "$packagename Exception", e)
        }
        return oobeUninstallApks;
    }

    private fun isReadFromSys() : Boolean {
        try {
            return !getFlagState(PalmplayApplication.getAppInstance())
        }catch (e: Exception) {
            LogUtils.e(e)
        }
        return false
    }

    fun saveReadStatus(isFlagged: Boolean = true) {
        try {
            setFlagState(PalmplayApplication.getAppInstance(), isFlagged)
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    private fun generateInstallAppInfo(packageName: String, isFirstLoad: Boolean = false): CloudAppInfo? {
        try {
            val context = TRApplicationContextUtil.getInstance()
            val pm = context.packageManager
            val packageInfo = pm.getPackageInfo(packageName, 0)
            if (packageInfo == null) {
                return null
            }
            val appInfo = packageInfo.applicationInfo
            if (appInfo == null) {
                return null
            }
            if(isFirstLoad) {
                val installedSource = getInstalledSourcePackageName(pm, packageName)
                if (installedSource != null && installedSource != "com.transsion.launcher3") {
                    LogUtils.e(
                        Companion.TAG,
                        "generateInstallAppInfo: $packageName not launcher install   ---  $installedSource"
                    )
                    return null
                }
            }
            val app = CloudAppInfo()
            app.name = appInfo.loadLabel(pm).toString()
            app.packageName = packageName
            app.jumpType = Constants.JUMP_TYPE_INSTALLED
            app.drawable = appInfo.loadIcon(pm);
            app.isEnable = appInfo.enabled
            app.launchIntent = pm.getLaunchIntentForPackage(packageName)
            app.observerStatus = FileDownloadInfo.STATUS_APP_INSTALLED
            return app
        } catch (e: Exception) {
            // 应用未安装，打印异常并返回null
            e.printStackTrace()
            return null
        }
    }

    /**
     * 移动到桌面
     */
    fun moveItemToHomeScreen(appInfo: CloudAppInfo, categoryType: Int, callback: (() -> Unit)?= null) {
        try {
            sendMessageToMoveItem(appInfo)
            var appList : MutableList<CloudAppInfo>?
            var key: String
            //调用移动到桌面
            if(categoryType == CATEGORY_APP) {
                appList = preInstallAppList
                key = KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG
            } else {
                appList = preInstallGameList
                key = KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG
            }

            if (appList.isNullOrEmpty()) {
                callback?.invoke()
                return
            }
            val wasModified = appList.removeIf {
                it.packageName == appInfo.packageName
            }
            if(wasModified) {
                savePreInstallListToLocal(appList, key)
            }
            callback?.invoke()
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    private fun savePreInstallListToLocal(appList: List<CloudAppInfo>?, key: String) {
        val packageNamesList: List<String>? = appList?.map { it.packageName }
        if(packageNamesList.isNullOrEmpty()) {
            MMKVUtils.getMultiMMKV().remove(key)
        } else {
            MMKVUtils.getMultiMMKV()
                .putString(
                    key,
                    GsonUtils.getInstance().toJson(packageNamesList)
                )
        }
    }

    private fun sendMessageToMoveItem(appInfo: CloudAppInfo) {
        try {
            val intent = Intent(ACTION_PALM_SEND_TO_HOME)
            intent.putExtra(EXTRA_SEND_PACKAGE, appInfo.packageName)
            intent.setPackage("com.transsion.launcher3")
            TRApplicationContextUtil.getInstance().sendBroadcast(intent)
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }


    /**
     * 解散时，所有硬预装应用移动到桌面上
     */
    fun moveAllItemToHomeScreen() {
        preInstallAppList?.let {
            if(it.isNotEmpty()) {
                for (appInfo in it) {
                    sendMessageToMoveItem(appInfo)
                }
                it.clear()
                MMKVUtils.getMultiMMKV().remove(KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG)
            }
        }
        preInstallGameList?.let {
            if(it.isNotEmpty()) {
                for (appInfo in it) {
                    sendMessageToMoveItem(appInfo)
                }
                it.clear()
                MMKVUtils.getMultiMMKV().remove(KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG)
            }
        }
    }

    fun removePreInstallItem(packageName: String?) {
        // 1. 安全调用 packageName：如果包名为空 (null)，则不执行任何操作。
        packageName?.let { pkgName ->
            // 对 App 列表执行移除操作，并获取结果
            val wasRemovedApp = handleRemoval(preInstallAppList, pkgName, KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG)

            // 对 Game 列表执行移除操作，并获取结果
            val wasRemovedGame = handleRemoval(preInstallGameList, pkgName, KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG)

            LogUtils.i(TAG, " removePreInstallItem  ->>   $wasRemovedApp  -- $wasRemovedGame")

            val resumeActivity = AtyManager.getAtyManager().resumeActivity
            LogUtils.i(TAG, " removePreInstallItem  ->>   $resumeActivity")

            // 只要其中一个列表发生了移除，就需要刷新界面
            if (wasRemovedApp || wasRemovedGame) {
                if(resumeActivity is BaseCloudFolderActivity) {
                    resumeActivity.refreshFragmentData()
                } else {
                    onCloudFolderRefresh()
                }
            }
        }
    }

    /**
     * 泛型函数，用于处理任何 MutableList<CloudAppInfo> 的移除和存储逻辑。
     * @param list 要操作的列表。
     * @param pkgName 要移除的包名。
     * @param listName 列表的名称，用于本地存储时的日志或标识。
     * @return Boolean - 如果列表因移除操作而发生了变化，则返回 true；否则返回 false。
     */
    private fun handleRemoval(list: MutableList<CloudAppInfo>?, pkgName: String, listName: String): Boolean {
        // 默认假设没有移除发生
        var wasRemoved = false
        // 如果 list 为 null，直接返回 false
        list?.let { safeList ->
            try {
                // 1. 使用 removeIf 移除满足条件的元素
                wasRemoved = safeList.removeIf { appInfo ->
                    // 即使在 lambda 内部也可能有异常，try-catch 提供了保护
                    appInfo.packageName == pkgName
                }

                // 2. 如果有元素被移除，则进行本地存储
                if (wasRemoved) {
                    savePreInstallListToLocal(safeList, listName)
                }

            } catch (e: Exception) {
                // 3. 捕获并处理异常（例如，记录日志）
                LogUtils.e(e)
                // 发生异常时，我们认为操作失败，wasRemoved 保持为 false
            }
        }

        // 返回移除结果（如果发生异常，返回 false）
        return wasRemoved
    }

    private fun onPackageChanged(packageName: String?) {
        if(packageName.isNullOrEmpty()) {
            return
        }
        val appSnapshot = preInstallAppList?.toMutableList()
        val changeItem = appSnapshot?.removeAll { appInfo ->
            if(appInfo.packageName == packageName) {
                var isEnable = true
                try {
                    isEnable = PalmplayApplication.getAppInstance().packageManager.getApplicationInfo(
                        packageName,
                        PackageManager.GET_UNINSTALLED_PACKAGES
                    ).enabled
                }catch (e: Exception) {
                    LogUtils.e(e)
                }
                !isEnable
            } else {
                false
            }
        } ?: false
        if(changeItem) {
            preInstallAppList = appSnapshot
            savePreInstallListToLocal(preInstallAppList, KEY_CLOUD_FOLDER_LOAD_PRE_APP_CONFIG)
            onCloudFolderRefresh(FOLDER.APPS)
        } else {
            val gameSnapshot = preInstallGameList?.toMutableList()
            val changeGameItem = gameSnapshot?.removeAll { appInfo ->
                if(appInfo.packageName == packageName) {
                    var isEnable = true
                    try {
                        isEnable = PalmplayApplication.getAppInstance().packageManager.getApplicationInfo(
                            packageName,
                            PackageManager.GET_UNINSTALLED_PACKAGES
                        ).enabled
                    }catch (e: Exception) {
                        LogUtils.e(e)
                    }
                    !isEnable
                } else {
                    false
                }
            } ?: false
            if(changeGameItem) {
                preInstallGameList = gameSnapshot
                savePreInstallListToLocal(preInstallGameList, KEY_CLOUD_FOLDER_LOAD_PRE_GAME_CONFIG)
                onCloudFolderRefresh(FOLDER.GAMES)
            }
        }
    }

    private val KEY_WIDGET_STATE = "key_show_cloud_folder_background"

    /**
     * 保存状态到 updateAppWidgetOptions
     * @param state 要保存的布尔值
     */
    fun saveWidgetState(context: Context, providerClass: Class<*>, state: Boolean) {
        synchronized(stateLock) {
            isLauncherShowBg = state
            MMKVUtils.getMultiMMKV().putBoolean(KEY_CLOUD_FOLDER_USE_LAUNCHER_BG, state)
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, providerClass)

            // 1. 通过 ComponentName 找到那个唯一的 ID
            val ids = appWidgetManager.getAppWidgetIds(componentName)
            LogUtils.i(TAG, "saveWidgetState :  $providerClass  --  $ids --  $state")
            if (ids.isNotEmpty()) {
                try {
                    val appWidgetId = ids[0] // 取第一个（也就是唯一的一个）
                    // 2. 获取现有的 Options (必须获取现有的，保留尺寸信息)
                    val options = appWidgetManager.getAppWidgetOptions(appWidgetId) ?: Bundle()

                    // 3. 写入你的值
                    options.putBoolean(KEY_WIDGET_STATE, state)

                    // 4. 提交更新到系统
                    appWidgetManager.updateAppWidgetOptions(appWidgetId, options)

                    // 注意：仅更新 Options 不会触发 onUpdate，如果需要刷新 UI，
                    // 需要手动再调用 appWidgetManager.updateAppWidget(appWidgetId, views)
                } catch (e: Exception) {
                    if (BuildConfig.DEBUG) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    /**
     * 从 updateAppWidgetOptions 读取状态
     * @return 存储的布尔值 (默认 false)
     */
    fun readState(context: Context,appWidgetManager: AppWidgetManager, widgetId : Int?, providerClass: Class<*>): Boolean {
        val componentName = ComponentName(context, providerClass)
        var appWidgetId: Int? = null
        if(widgetId == null) {
            // 1. 找 ID
            val ids = appWidgetManager.getAppWidgetIds(componentName)

            if (ids.isNotEmpty()) {
                appWidgetId = ids[0]
            }
        } else {
            appWidgetId = widgetId
        }
        return appWidgetId?.let {
            // 2. 读 Options
            val options = appWidgetManager.getAppWidgetOptions(appWidgetId)
            // 3. 返回值
            options.getBoolean(KEY_WIDGET_STATE, false)
        } ?: false
    }


    private fun getDownloadingPackageForSplit(): List<String> {
        return DownloadManager.getInstance().shadowDownloadingInfoList.filter {
            it.fromPage == null || !it.fromPage.startsWith("FL_")
        }.map {
            it.packageName
        }
    }


    private var isHotWidgetUpdate = false
    private var isGameWidgetUpdate = false

    private fun checkIsUpdate(folder: FOLDER) : Boolean{
        return isHotWidgetUpdate && folder == FOLDER.APPS || isGameWidgetUpdate && folder == FOLDER.GAMES
    }

    private fun setUpdateStatus(isUpdate: Boolean, folder: FOLDER) {
        if (folder == FOLDER.APPS) {
            isHotWidgetUpdate = isUpdate
        } else {
            isGameWidgetUpdate = isUpdate
        }
    }

    /**
     * 刷新小组件的状态
     *
     */
    @JvmOverloads
    fun updateWidgetRemoteView(context: Context?, folder: FOLDER, widgetManager: AppWidgetManager? = null, widgetId: Int?= null, forceUpdate: Boolean = false) {
        LogUtils.i(TAG, " updateWidgetRemoteView  ->>   ${folder.title}")
        context?.let {
            addWallpaperChangeReceiver()
            mainScope.launch {
                if(checkIsUpdate(folder)) {
                    LogUtils.i(TAG, " updateWidgetRemoteView   block  ->>   ${folder.title}")
                    return@launch
                }
                setUpdateStatus(true, folder)
                val manager = widgetManager?: AppWidgetManager.getInstance(it)
                val folderPreviewBitmap = CloudFolderPreviewManager.getInstance().getFolderPreviewImage(folder, forceUpdate, folder.defaultDrawable)
                manager?.apply {
                    if (widgetId == null) {
                        updateAppWidget(ComponentName(it, folder.widgetClass), generateRemoteView(it, folder, folderPreviewBitmap))
                    } else {
                        updateAppWidget(widgetId, generateRemoteView(it, folder, folderPreviewBitmap))
                    }
                }
                setUpdateStatus(false, folder)
                LogUtils.i(TAG, " updateWidgetRemoteView   update   ->>   ${folder.title}")
            }
        }
        LogUtils.i(TAG, " updateWidgetRemoteView   block   finish ->>   ${folder.title}")

    }

    /**
     * 从本地读取物料，重新生成缩略图
     */
    private fun refreshCloudFolderPreviewImage(folder: FOLDER, defaultDrawableId: Int) {
        ioScope.launch {
            LogUtils.i(TAG, "  refreshCloudFolderPreviewImage start   folder:  ${folder.title}")
            val bitmap = CloudFolderPreviewManager.getInstance().generateFolderPreviewImage(folder, TYPE_GET_ALL, defaultDrawableId = defaultDrawableId) ?: return@launch
            LogUtils.i(TAG, "  refreshCloudFolderPreviewImage end   folder:  ${folder.title}")
            updateFolder(folder, bitmap)
        }
    }

    /**
     * 显示空的缩略图
     */
    fun showEmptyCloudFolderPreviewImage(folder: FOLDER, defaultDrawableId: Int) {
        ioScope.launch {
            LogUtils.i(TAG, "  refreshCloudFolderPreviewImage start   folder:  ${folder.title}")
            val bitmap = decodeBitmapFromResource(defaultDrawableId) ?: return@launch
            LogUtils.i(TAG, "  refreshCloudFolderPreviewImage end   folder:  ${folder.title}")
            CloudFolderPreviewManager.getInstance().resetPreviewImage(folder)
            updateFolder(folder, bitmap)
        }
    }

    fun checkAndRefreshPreviewImage(folder: FOLDER) {
        if (CloudFolderPreviewManager.getInstance()
                .getFolderPreviewImageFromMemory(folder) == null
        ) {
            ioScope.launch {
                TRApplicationContextUtil.getInstance()?.let {
                    checkAndUpdateFolder(it, folder)
                }
            }
        }
    }

    private fun checkAndUpdateFolder(
        application: Application,
        folder: FOLDER
    ) {
        if(isShortcutSplit()) {
            refreshCloudFolderPreviewImage(folder, folder.defaultShortcutDrawable)
        } else {
            updateWidgetRemoteView(application, folder)
        }
    }


    fun createAllCloudFolder() {
        if(isShortcutSplit()) {
            createShortcutFolder()
        } else {
            createWidgetFolder()
        }
    }

    fun createWidgetFolder() {
        if (CloudFolderRemoteController.getInstance().isCloudFolderCreate(FOLDER.APPS)) {
            createWidgetCloudFolder(FOLDER.APPS, false)
        } else {
            createWidgetCloudFolder(FOLDER.GAMES)
        }
    }

    fun createShortcutFolder() {
        ioScope.launch {
            createShortcutFolder(FOLDER.APPS)
            delay(200)
            createShortcutFolder(FOLDER.GAMES)
        }
    }

     fun isCloudFolderAdded(categoryType: FOLDER) : Boolean {
        return if(isShortcutSplit()) {
            isShortcutHasAdded(categoryType)
        } else {
            isWidgetHasAdded(categoryType)
        }
    }

    fun isWidgetHasAdded(categoryType: FOLDER) : Boolean {
        try {
            TRApplicationContextUtil.getInstance()?.let {
                AppWidgetManager.getInstance(it).apply {
                    val hotWidgets = getAppWidgetIds(ComponentName(it, categoryType.widgetClass))
                    return hotWidgets != null && hotWidgets.isNotEmpty()
                }
            }
        } catch (e: Exception) {
            LogUtils.e(e)
        }
        return true
    }

    fun isShortcutHasAdded(categoryType: FOLDER) : Boolean {
        try {
            TRApplicationContextUtil.getInstance()?.let {
                return ShortcutManagerCompat.getShortcuts(it, FLAG_MATCH_PINNED).any { shortcutInfo ->
                    shortcutInfo.id == categoryType.shortcutId
                }
            }
        } catch (e: Exception) {
        }
        LogUtils.i(TAG, "isShortcutHasAdded: return false")
        return false;
    }

    private fun requestPinAppWidget(categoryType: FOLDER): Boolean {
        TRApplicationContextUtil.getInstance()?.let {context ->
            //Android8以下不支持
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false

            val appWidgetManager = AppWidgetManager.getInstance(context)

            //小组件的provider
            val provider = ComponentName(context, categoryType.widgetClass)


            //添加成功的广播
            val successBroadcast = PendingIntent.getBroadcast(
                context,
                0,
                Intent()
                    .setComponent(provider)
                    .setAction(ADD_WIDGET_SUCCESS_ACTION), //这里为了方便，将广播发到HelloWidgetProvider
                PendingIntent.FLAG_UPDATE_CURRENT.toImmutableCompatFlag()
            )

            return try {
                //请求添加小部件，如果不支持的话会返回false，支持的话返回true
                appWidgetManager.requestPinAppWidget(
                    provider,//添加的小部件provider
                    null,
                    successBroadcast//添加成功后会执行的intent
                )
            } catch (e: IllegalStateException) {
                // 没有存在前台的activity或者前台service会出现这个异常
                LogUtils.e(TAG, e)
                false
            }
        }
        return false
    }

    private fun Int.toImmutableCompatFlag(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            this or PendingIntent.FLAG_IMMUTABLE
        } else {
            this
        }
    }


    fun createWidgetCloudFolder(folder: FOLDER, needCheckSwitch: Boolean = true) {
        if (!isWidgetHasAdded(folder) && (!needCheckSwitch || CloudFolderRemoteController.getInstance().isCloudFolderCreate(folder))) {
            val result = requestPinAppWidget(folder)
            LogUtils.i(TAG, " createCloudFolder  ->> result: $result")
        }
    }

    fun removeWidgetCloudFolder(folder: FOLDER) {
        val removeType = if(folder == FOLDER.APPS) {
            REMOVE_APP_WIDGET
        } else {
            REMOVE_GAME_WIDGET
        }
        val intent = Intent(ACTION_PALM_WIDGET_REMOVE)
        intent.putExtra(EXTRA_REMOVE_TYPE, removeType)
        TRApplicationContextUtil.getInstance().sendBroadcast(intent)
    }

    /**
     * 移除云文件夹小部件
     */
    fun removeAllCloudFolder() {
        if(isShortcutSplit()) {
            removeAllShortcutFolder()
        } else {
            removeAllWidgetFolder()
        }
    }

    fun removeAllWidgetFolder() {
        val intent = Intent(ACTION_PALM_WIDGET_REMOVE)
        intent.putExtra(EXTRA_REMOVE_TYPE, REMOVE_ALL)
        TRApplicationContextUtil.getInstance().sendBroadcast(intent)
        checkCloudFolderCloseStatus()
    }

    fun removeAllShortcutFolder() {
        try {
            LogUtils.i(TAG, " removeAllShortcutFolder")
            TRApplicationContextUtil.getInstance().let {
                ShortcutManagerCompat.disableShortcuts(it, listOf(FOLDER.APPS, FOLDER.GAMES).map { it.shortcutId }, "user close")
                ShortcutManagerCompat.removeDynamicShortcuts(it, listOf(FOLDER.APPS, FOLDER.GAMES).map { it.shortcutId })
            }
        } catch (e: Throwable) {
        }
    }

    fun removeShortcutByFolder(shortcutId: String) {
        try {
            TRApplicationContextUtil.getInstance().let {
                ShortcutManagerCompat.disableShortcuts(it, listOf(shortcutId), "user close")
                ShortcutManagerCompat.removeDynamicShortcuts(it, listOf(shortcutId))
            }
        } catch (e: Throwable) {
        }
    }

    /**
     * 发送广播有关闭失败的情况， 延迟3s检测是否关闭成功
     */
    private fun checkCloudFolderCloseStatus() {
        ioScope.launch {
            delay(3000L)
            val status = MMKVUtils.getMultiMMKV().getInt(Constants.KEY_FILE_FOLDER_PERMISSION_STATUS)
            if(Constants.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT == status) {
                if(isWidgetHasAdded(FOLDER.APPS) || isWidgetHasAdded(FOLDER.GAMES)) {
                    val intent = Intent(ACTION_PALM_WIDGET_REMOVE)
                    intent.putExtra(EXTRA_REMOVE_TYPE, REMOVE_ALL)
                    TRApplicationContextUtil.getInstance().sendBroadcast(intent)
                }
            }
        }
    }

    fun createShortcutFolder(folder: FOLDER) {
        mainScope.launch {
            TRApplicationContextUtil.getInstance()?.let {
                try {
                    val folderPreviewBitmap = CloudFolderPreviewManager.getInstance().getFolderPreviewImageFromMemory(folder)
                    val folderIcon = if(folderPreviewBitmap != null && !folderPreviewBitmap.isRecycled) {
                        folderPreviewBitmap
                    } else {
                        decodeBitmapFromResource(folder.defaultShortcutDrawable)
                    } ?: return@launch
                    val shortcutInfoCompat = addDynamicShortcut(it, folder, folderIcon) ?: return@launch
                    val i = Intent(
                        PalmplayApplication.getAppInstance().applicationContext,
                        CloudFolderShortcutReceiver::class.java
                    )
                    i.putExtra(CREATE_SHORTCUT, true)
                        .putExtra(CREATE_SHORTCUT_ID, folder.shortcutId)
                    i.setPackage(BuildConfig.APPLICATION_ID)
                    val pendingIntent = PendingIntent.getBroadcast(
                        it, folder.hashCode(),
                        i, TRApplicationContextUtil.getPendingIntentFlag()
                    )
                    ShortcutManagerCompat.requestPinShortcut(
                        it,
                        shortcutInfoCompat,
                        pendingIntent.intentSender
                    )
                }catch (e: Exception) {
                    LogUtils.e(TAG, "createShortcutFolder: $e")
                }
            }
        }

    }

    fun preloadShortcutPreviewIcon() {
        ioScope.launch {
            if(isCloudFolderSplit() && isShortcutSplit()) {
                if(isShortcutHasAdded(FOLDER.APPS)) {
                    return@launch
                }
                if(CloudFolderPreviewManager.getInstance().getFolderPreviewImageFromMemory(FOLDER.APPS) == null) {
                    LogUtils.i(
                        TAG,
                        "preloadShortcutPreviewIcon cache image"
                    )
                    //提前缓存缩略图
                    mainScope.launch {
                        CloudFolderPreviewManager.getInstance()
                            .generateFolderPreviewImage(FOLDER.APPS, TYPE_GET_ALL, defaultDrawableId = FOLDER.APPS.defaultShortcutDrawable)
                        CloudFolderPreviewManager.getInstance()
                            .generateFolderPreviewImage(FOLDER.GAMES, TYPE_GET_ALL, defaultDrawableId = FOLDER.GAMES.defaultShortcutDrawable)
                    }
                }
            }
        }
    }

    private fun addDynamicShortcut(context: Context,folder: FOLDER, bitmap: Bitmap): ShortcutInfoCompat? {
        val intent = Intent(folder.shortcutAction)
        val builder =
            ShortcutInfoCompat.Builder(context, folder.shortcutId)
        builder.setShortLabel(folder.getFolderTitle())
        builder.setIcon(IconCompat.createWithBitmap(bitmap))
        builder.setIntent(intent)
        var shortcutInfoCompat: ShortcutInfoCompat? = null
        try {
            shortcutInfoCompat = builder.build()
        } catch (e: java.lang.Exception) {
            if (BuildConfig.DEBUG) e.printStackTrace()
        }
        return shortcutInfoCompat
    }


    /**
     * 获取云文件夹的配置信息
     */
    fun getCloudFolderConfig(): CloudFolderConfig? {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.convertToSplitConfig()
    }

    /**
     * 获取云文件夹开关
     */
    fun getCloudFolderSwitch(): Int {
        return DispenseDataManager.getInstance().fileFolderGetPermissionStatus
    }

    fun setCloudFolderSwitch(status: Int) {
        DispenseDataManager.getInstance().fileFolderGetPermissionStatus = status
    }

    /**
     * 获取配置请求间隔
     */
    private fun getCloudFolderRequestInterval(): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.introConf?.outerPer ?: 4
    }

    /**
     * 获取显示物料数量
     */
    private fun getCloudFolderShowCount(categoryType: Int): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.let {
            if(categoryType == CATEGORY_APP) {
                it.appCfg?.needNum ?: it.needNum
            } else {
                it.gameCfg?.needNum ?: it.needNum
            }
        } ?: 10
    }

    /**
     * 获取downloadType
     * 1:直接开始下载;2:跳转半屏详情页
     */
    fun getCloudFolderDownloadType(): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.downloadType ?: 1
    }

    /**
     * 获取云文件夹 UI 样式
     */
    fun getCloudFolderUiStyle(): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.uiStyle ?: 1
//        return LAYOUT_STYLE_RANK_GRID
    }

    /**
     * 获取榜单皇冠部分是否滚动
     */
    fun getCloudFolderLeaderScroll(): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.leaderScroll ?: 0
//        return LEADER_SCROLL_ON
    }

    /**
     * 获取动态 icon 开关
     */
    fun getDynamicIconSwitch(): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.dynamicIcon?.switchStatus ?: 0
    }

    /**
     * 获取动态 icon 展示限制
     */
    fun getDynamicIconLimit(): Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.dynamicIcon?.displayLimit ?: 0
    }

    /**
     * 获取downloadType
     */
    fun getCloudFolderDownAlpha(): Float {
        val attr = DispenseDataManager.getInstance().cloudFolderSplitConfig?.attr
        if (!TextUtils.isEmpty(attr)) {
            return GsonUtils.getInstance().fromJson(attr, SwitchInfoDTO::class.java)?.notDownAlpha
                ?: 0f
        }
        return 0f
    }

    /**
     * 是否显示蒙层
     */
    fun isIconMaskShow(): Boolean {
        return getCloudFolderDownStyle() == 1
    }

    /**
     * 获取downloadStyle
     */
    private fun getCloudFolderDownStyle(): Int {
        val attr = DispenseDataManager.getInstance().cloudFolderSplitConfig?.attr
        if (!TextUtils.isEmpty(attr)) {
            return GsonUtils.getInstance().fromJson(attr, SwitchInfoDTO::class.java)?.notDownStyle
                ?: 0
        }
        return 0
    }

    private fun getBottomSwitch(categoryType: Int): Boolean {
        // 假设这是你从服务端或本地缓存获取的开关状态
        val switchStatus = DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.directCfg?.switchStatus ?: 0 // 例如返回 0, 1, 2, 3

        if(isRuCountry && categoryType == CATEGORY_GAMES) {
            //ru的Russia文件不显示底部推荐
            return false;
        }
        return when (categoryType) {
            CATEGORY_APP -> switchStatus == 1 || switchStatus == 3 // Apps 开启条件：仅Apps开(1) 或 全开(3)
            CATEGORY_GAMES -> switchStatus == 2 || switchStatus == 3 // Games 开启条件：仅Games开(2) 或 全开(3)
            else -> false // 未知类型默认关闭，安全兜底
        }
    }

    /**
     * 是否选择ew物料
     */
    private fun isBottomFilterEwSource() : Boolean {
        return (DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.directCfg?.materialSource ?: 1) == 0
    }


    private fun getBottomIconOffset() : Int {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.directCfg?.firstOffset ?: 10
    }

    /**
     * 「最近安装」拉活底栏开关：按品类（Apps / Games）判定
     */
    fun isRecentlyInstalledEnabled(categoryType: Int, mLayoutStyle: Int): Boolean {
        //优先判断 mLayoutStyle 当为2、3时
        if (mLayoutStyle == LAYOUT_STYLE_RANK_GRID || mLayoutStyle == LAYOUT_STYLE_RANK_LIST) {
            return false
        }
        val status = DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.wakeup?.switchStatus ?: 0
        return when (categoryType) {
            CATEGORY_APP -> status == 1 || status == 3
            CATEGORY_GAMES -> status == 2 || status == 3
            else -> false
        }
    }

    /**
     * 「最近安装」点击归因上报开关：
     * 0=不上报；1=全部上报；2=7 天内不上报、7 天外上报
     * @param installedTime 应用安装完成时间戳
     */
    fun shouldReportRecentlyInstalledAttribution(installedTime: Long): Boolean {
        val attrSwitch = DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.wakeup?.attrSwitch ?: 0
        LogUtils.i("RecentlyInstalled", "checkFolderStatus: attrSwitch ==" + attrSwitch)
        return when (attrSwitch) {
            1 -> true
            2 -> {
                val sevenDaysMs = 7L * 24 * 60 * 60 * 1000
                System.currentTimeMillis() - installedTime > sevenDaysMs
            }
            else -> false  // 0 或未知值
        }
    }

    fun getRecentlyInstalledAcPkgs(): List<String>? {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.wakeup?.acPkgs
    }

    /**
     * 「最近安装」AC 端内拉活白名单：fromPage 前缀列表（startsWith 匹配，大小写忽略）。
     * null/空 → AC 端内全拒。
     */
    fun getRecentlyInstalledAcFromPages(): List<String>? {
        return DispenseDataManager.getInstance().cloudFolderSplitConfig?.bottom?.wakeup?.acFromPages
    }

    private val atomicInteger = AtomicInteger()

    // 生成trigger_id，最好可以通过sdk api方式调用，后续如果规则有变可以保持一致
    fun generateTriggerId(): String {
        val atomic = atomicInteger.incrementAndGet().toString()
        val math = ((Math.random() * 9 + 1) * 100000).toInt().toString()
        val longTime = System.currentTimeMillis().toString()
        return atomic + longTime + math
    }

    // 生成show_id
    fun generateShowId(): String {
        return UUID.randomUUID().toString().replace("-", "")
    }

    fun uploadAdxExposure(pkgName: String, categoryType: Int) {
        //云文件夹对接ADX曝光
        val actionType = if(categoryType == CATEGORY_APP) {
            Constants.PALMS_FILE_FOLDER_ADX_EXPOSURE_APP
        } else {
            Constants.PALMS_FILE_FOLDER_ADX_EXPOSURE_GAME
        }

        val exposureData =
            DispenseDataManager.getInstance().doFileFolderExposure(pkgName, actionType)
        LogUtils.i(
            TAG,
            "DispenseService exposure : $exposureData"
        )
        SupportExternalDownload.getInstance().doFileFolderTrack(Constants.TYPE_FILE_FOLDER_ADX_EXPOSURE, exposureData)
    }

    /**
     * Adx下载
     */
    private fun onAdxItemDownload(appInfo: AppInfo, categoryType: Int, fromPage: String) {
        //ADX下载
        val actionType = if(categoryType == CATEGORY_APP) {
            Constants.PALMS_FILE_FOLDER_2_DOWNLOAD_STATUS_APP_ADX
        } else {
            Constants.PALMS_FILE_FOLDER_2_DOWNLOAD_STATUS_GAME_ADX
        }
        val adsDTO =
            DispenseDataManager.getInstance().doFileFolderDownloadStatusADX(appInfo.packageName, actionType)
        if (adsDTO != null && adsDTO.sdk != null) {
            val json = GsonUtils.getInstance().toJson(adsDTO.sdk)
            SupportExternalDownload.getInstance().doFileFolderTrack(Constants.TYPE_FILE_FOLDER_ADX_CLICK, json)
            LogUtils.i(
                LogUtils.TAG_EXTERNAL_SERVICE_DISPENSE,
                "DispenseService click : $json"
            )
        }
        if (adsDTO != null) {
            appInfo.nativeId = adsDTO.sdk.uuid
            appInfo.reportSource = HisavanaSdkManager.REPORT_SOURCE_EW;
            appInfo.track_type = adsDTO.sdk.trackType
            appInfo.trackUrls = adsDTO.sdk.psClickTrackingUrls
            appInfo.adPositionId = adsDTO.sid
        }

        CloudFolderTrackUtil.addToDownloadQueue(appInfo.packageName, appInfo.name,
            fromPage, appInfo.reportSource, appInfo.countryCode, appInfo.isOffer)

        DownloadDecorator.startDownloading(
            appInfo,
            fromPage,
            PageParamInfo("", fromPage),
            null,
            null
        )
    }

    /**
     * 开始下载
     */
    fun startDownload(appInfo: AppInfo, categoryType: Int, fromPage: String) {
        //加入下载队列
        if(appInfo.isAdxItem()) {
            onAdxItemDownload(appInfo, categoryType, fromPage)
        } else {
            CloudFolderTrackUtil.addToDownloadQueue(appInfo.packageName, appInfo.name,
                fromPage, appInfo.reportSource, appInfo.countryCode, appInfo.isOffer)
            DownloadDecorator.startDownloading(
                appInfo,
                fromPage,
                PageParamInfo("", fromPage),
                null,
                null
            )
        }
    }

    /**
     * 显示appInfo 页面
     *
     * @param value   FL_{sign}_{sceneTag}_{position}，用于半屏详情页埋点 value/fromPage
     * @param cfValue 云文件夹埋点扩展字段（CloudAppInfo.getCloudStyleString）
     */
    fun showAppDetailPage(
        isAdx: Boolean,
        packageName: String,
        categoryType: Int,
        value: String? = null,
        cfValue: String? = null,
    ) {
        val actionType = if(categoryType == CATEGORY_APP) {
            Constants.PALMS_FILE_FOLDER_APP_STATUS
        } else {
            Constants.PALMS_FILE_FOLDER_GAME_STATUS
        }
        if (isAdx) {
            DispenseDataManager.getInstance().fileFolder2DetailADX(packageName, actionType, value, cfValue)
        } else {
            DispenseDataManager.getInstance().fileFolder2Detail(packageName, actionType, value, cfValue)
        }
    }

    //应用安装，刷新桌面图标
    fun onPackageAdded(downloadInfo: FileDownloadInfo?) {
        downloadInfo?.let {
            if(TextUtils.equals(it.fromPage, FILE_FOLDER_FROM_SITE_APP)) {
                onCloudFolderRefresh(FOLDER.APPS)
            }
            if(TextUtils.equals(it.fromPage, FILE_FOLDER_FROM_SITE_GAME)) {
                onCloudFolderRefresh(FOLDER.GAMES)
            }
        }

    }

    /**
     * 物料更新
     */
    fun onCloudFolderIntervalRefresh() {
        val lastRequestTime = getCloudFolderLastRequest()
        val currentTimeMillis = System.currentTimeMillis()
        if(currentTimeMillis - lastRequestTime > getCloudFolderRequestInterval() * 3600 * 1000L) {
            setCloudFolderLastRequest(currentTimeMillis)
            onCloudFolderRefresh()
        }
    }


    /**
     * 定时刷新，上次刷新时间
     */
    private fun getCloudFolderLastRequest(): Long {
        return MMKVUtils.getMMKV().getLong(KEY_CLOUD_FOLDER_LAST_REQUEST, 0)
    }

    private fun setCloudFolderLastRequest(time: Long) {
        MMKVUtils.getMMKV().putLong(KEY_CLOUD_FOLDER_LAST_REQUEST, time)
    }

    /**
     * 物料更新
     */
    fun onCloudFolderRefresh() {
        onCloudFolderRefresh(FOLDER.APPS)
        onCloudFolderRefresh(FOLDER.GAMES)
//        getInstance().preloadShortcutPreviewIcon()
    }

    fun onCloudFolderRefresh(categoryType: FOLDER) {
        ioScope.launch {
            if(isShortcutSplit()) {
                if(isShortcutHasAdded(categoryType)) {
                    refreshCloudFolderPreviewImage(categoryType, categoryType.defaultShortcutDrawable)
                }
            } else {
                if(isWidgetHasAdded(categoryType)) {
                    refreshCloudFolderPreviewImage(categoryType, categoryType.defaultDrawable)
                }
            }
        }
    }


    fun refreshFromThemeChange() {
        refreshFromIconStyleChange()
        WallpaperUtils.getInstance().generateBlurWallpaper()
    }

    fun refreshFromIconStyleChange() {
        val context = TRApplicationContextUtil.getInstance() ?: return
        if (isWidgetSplit()) {
            FOLDER.values()
                .filter { isWidgetHasAdded(it) }
                .forEach { updateWidgetRemoteView(context, it, forceUpdate = true) }
        }
    }

    private fun addWallpaperChangeReceiver() {
        TRApplicationContextUtil.getInstance()?.let {
            if(!mRegistered) {
                val receiver = WallpaperChangerReceiver()
                val intentFilter = IntentFilter(Intent.ACTION_WALLPAPER_CHANGED)
                receiver.registerReceiverExported(it, intentFilter)
                mRegistered = true
            }
        }
    }

    /**
     * 是否小部件解耦
     */
    fun isWidgetSplit() : Boolean {
        return DispenseDataManager.getInstance().folderSplitType == Constants.CLOUD_FOLDER_TYPE_WIDGET
    }

    /**
     * 是否快捷方式解耦(itel)
     */
    fun isShortcutSplit() : Boolean {
        return DispenseDataManager.getInstance().folderSplitType == Constants.CLOUD_FOLDER_TYPE_SHORTCUT
    }

    fun isCloudFolderSplit() : Boolean {
        return DispenseDataManager.isCloudFolderSplit()
    }

    fun checkFolderStatus(shortcutId : String) {
        LogUtils.i(TAG, "checkFolderStatus: start")
        ioScope.launch {
            if (getCloudFolderSwitch() == FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT) {
                if (isCloudFolderSplit() && isShortcutSplit()) {
                    val checkFolder = if (TextUtils.equals(shortcutId, FOLDER.APPS.shortcutId)) {
                        FOLDER.GAMES
                    } else {
                        FOLDER.APPS
                    }
                    if (!isShortcutHasAdded(checkFolder)) {
                        LogUtils.i(TAG, "checkFolderStatus: set no grant")
                        setCloudFolderSwitch(FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT)
                    }
                }
            }
        }
    }

    fun isOriginSplit() : Boolean {
        return PhoneUtils.isOriginSplit()
    }

    /**
     * 语言切换监听
     */
    fun onLanguageChange() {
        LogUtils.i(TAG, "onLanguageChanges  start")
        if(isCloudFolderSplit() && isShortcutSplit()) {
            refreshFolderIcon(FOLDER.APPS, true)
            refreshFolderIcon(FOLDER.GAMES, true)
        }
    }

    fun refreshFolderIcon(categoryType: FOLDER, isCheckFolder: Boolean) {
        ioScope.launch {
            if(isCheckFolder && !isShortcutHasAdded(categoryType)) {
                // 没有添加快捷方式，不刷新
                return@launch
            }
            LogUtils.i(
                TAG,
                "  refreshCloudFolderPreviewImage start  folder:  ${categoryType.title}"
            )
            val bitmap = CloudFolderPreviewManager.getInstance()
                .generateFolderPreviewImage(categoryType, TYPE_GET_ALL, true,  categoryType.defaultShortcutDrawable)
            LogUtils.i(
                TAG,
                "  refreshCloudFolderPreviewImage end   folder:  ${categoryType.title}"
            )
            updateFolder(categoryType, bitmap)
        }

    }

    /**
     * 线上专用， 入库不使用
     */
    fun doCloseSwitch(parameterValue: String, type: Int): Boolean {
        if(isCloudFolderSplit()) {
            if(TextUtils.equals(parameterValue, CLOSE_STATUS)) {
                removeAllShortcutFolder()
                if(CLOSE_TYPE_ITEL == type) {
                    DispenseDataManager.getInstance().setItelCloseStatus(parameterValue)
                } else {
                    DispenseDataManager.getInstance().setXianShangCloseStatus(parameterValue)
                }
                setCloudFolderSwitch(FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT)
                return false
            }
        }
        return true
    }

    fun queryFolderDisbandStatus(callingPackage: String?): Cursor? {
        try {
            if(callingPackage.isNullOrEmpty()) {
                return null
            }

            val launcherList = arrayListOf("com.transsion.hilauncher", "com.transsion.XOSLauncher", "com.transsion.itel.launcher", "com.transsion.launcher3")
            if(!launcherList.contains(callingPackage)) {
                return null
            }

            val cursor = MatrixCursor(
                arrayOf<String>(
                    "folderStatus"
                )
            )
            cursor.addRow(
                arrayOf<Any?>(
                    getInstance().getCloudFolderSwitch()
                )
            )
            return cursor
        }catch (e: Exception) {
            LogUtils.i(e)
        }
        return null
    }

    fun checkFolderStatus(categoryType: FOLDER) {
        LogUtils.i(TAG, "checkFolderStatus: start")
        ioScope.launch {
            if(getCloudFolderSwitch() == FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT) {
                if(isOriginSplit()) {
                    val checkFolder = if (FOLDER.APPS == categoryType) {
                        FOLDER.GAMES
                    } else {
                        FOLDER.APPS
                    }
                    if(!isWidgetHasAdded(checkFolder)) {
                        LogUtils.i(TAG, "checkFolderStatus: set no grant")
                        DispenseDataManager.getInstance().fileFolderGetPermissionStatus = FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT
                    }
                }
            }
        }
    }

    fun getBottomIconListByFolder(categoryType: Int) : List<DataItem.AppBottomInfo>? {
         return DispenseDataManager.getInstance().cloudFolderBottomIcons ?.let {
             val bottomIcons = if(categoryType == CATEGORY_APP) {
                 it.appBottomIcons
             } else {
                 it.gameBottomIcons
             }
             bottomIcons?.filter {item ->
                 TRBitmapManager.isImageCached(item.iconUrl) && !PhoneUtils.isAppInstall(TRApplicationContextUtil.getInstance(), item.packageName)
             }
         }
    }
}
class WallpaperChangerReceiver : BroadcastReceiver(){

    private var isExecute = false

    override fun onReceive(context: Context?, intent: Intent?) {
        //发现切换壁纸的时候，连续回调两次
        if(isExecute) {
            return
        }
        isExecute = true
        WallpaperUtils.getInstance().generateBlurWallpaper()
        isExecute = false
    }

}

fun AppInfo.isAdxItem() = isOffer == Constants.IS_ADX

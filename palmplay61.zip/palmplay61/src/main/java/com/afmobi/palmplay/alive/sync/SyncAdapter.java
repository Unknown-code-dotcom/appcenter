/*Transsion Top Secret*/
package com.afmobi.palmplay.alive.sync;

import android.accounts.Account;
import android.content.AbstractThreadedSyncAdapter;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SyncResult;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.afmobi.palmplay.alive.SyncUtils;
import com.transsion.palmstorecore.log.LogUtils;


public class SyncAdapter extends AbstractThreadedSyncAdapter {

    ContentResolver mContentResolver;
    private Handler mHandler;

    public SyncAdapter(Context context, boolean autoInitialize) {
        super(context, autoInitialize);
        /*
         * If your app uses a content resolver, get an instance of it
         * from the incoming Context
         */
        mContentResolver = context.getContentResolver();
    }

    /**
     * Set up the sync adapter. This form of the
     * constructor maintains compatibility with Android 3.0
     * and later platform versions
     */
    public SyncAdapter(
            Context context,
            boolean autoInitialize,
            boolean allowParallelSyncs) {
        super(context, autoInitialize, allowParallelSyncs);
        /*
         * If your app uses a content resolver, get an instance of it
         * from the incoming Context
         */
        mContentResolver = context.getContentResolver();
    }

    /*
     * Specify the code you want to run in the sync adapter. The entire
     * sync adapter runs in a background thread, so you don't have to set
     * up your own background processing.
     */
    @Override
    public void onPerformSync(
            Account account,
            Bundle extras,
            String authority,
            ContentProviderClient provider,
            SyncResult syncResult) {

        // add our business code here, such as sync data or update app
        LogUtils.i("SyncAdapter onPerformSync service is running...");
        /*bugID：MIPROAEE-4150--保活功能同步，子线程引起crash */
        if(mHandler == null){
            mHandler = new Handler(Looper.getMainLooper());
        }
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                SyncUtils.doBusinessSync();
            }
        });
//        SyncUtils.doBusinessSync(this.getContext());
    }
}

// TOP SECRET
package com.afmobi.palmplay.cache.v6_1;

import androidx.collection.LruCache;
import android.text.TextUtils;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.model.v6_1.TryListenInfo;
import com.afmobi.util.CommonUtils;

public class TryListenUrlCache {
	
	private final static int CACHE_SIZE = 64;

	private static volatile TryListenUrlCache mInstance;
	private LruCache<String, TryListenInfo> mCache;
	
	private static byte[] lock = new byte[0];

	private TryListenUrlCache() {
		mCache = new LruCache<String, TryListenInfo>(CACHE_SIZE);
	}

	public static TryListenUrlCache getInstance() {
		if (mInstance == null) {
			synchronized (lock) {
				if (mInstance == null) {
					mInstance = new TryListenUrlCache();
				}
			}
		}

		return mInstance;
	}
	
	public void clear(){
		mCache.evictAll();
	}
	
	public void releaseAndClear(){
		clear();
		mInstance = null;
	}

	public boolean put(String key, TryListenInfo value){
		if(TextUtils.isEmpty(key))
			return false;
		
		mCache.put(key, value);
		
		return true;
		
	}
	
	public TryListenInfo get(String key){
		if(!TextUtils.isEmpty(key))
			return mCache.get(key);
		
		return null;
	}
	
	public static String getCacheKey(String itemID, boolean isHK, int detailType, boolean isOffline){
		if(TextUtils.isEmpty(itemID))
			return null;
		
		if(detailType == DetailType.TYPE_VIDEO){
			return itemID + CommonUtils.getVideoPixelType(isHK);
		}
		
		return itemID;
	}

}

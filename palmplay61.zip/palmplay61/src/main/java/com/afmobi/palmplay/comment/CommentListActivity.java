// TOP SECRET
package com.afmobi.palmplay.comment;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.customview.CommentDialogView;
import com.afmobi.palmplay.customview.CustomPopuWin;
import com.afmobi.palmplay.customview.PopMenuItemSelectedListener;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.firebase.FirebaseAnalyticsTool;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil;
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil.UINetworkErrorOnClickListener;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.model.CommentInfo;
import com.afmobi.palmplay.model.keeptojosn.CommentRespInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.mvvm.BaseActivity;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.viewmodel.comment.CommentListNavigator;
import com.afmobi.palmplay.viewmodel.comment.CommentListViewModel;
import com.afmobi.palmplay.viewmodel.detail.CommentListAdapter;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.SysUtils;
import com.afmobi.util.UILoadingGifUtil;
import com.afmobi.util.statusbar.TRNavigationBarUtil;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.transsion.core.log.LogUtils;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.TRAnalyticsManager;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.BR;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;
import com.transsnet.store.databinding.ActivityCommentListBinding;

import java.util.List;

import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import xyz.doikki.videoplayer.util.PlayerUtils;

public class CommentListActivity extends BaseActivity<ActivityCommentListBinding, CommentListViewModel> implements CommentListNavigator {

	private CommentListAdapter mCommentListAdapter;
	private String appId;
	private int pageIndex = 1;
	private final int pageSize = 30;  //BUG #14109 “评论列表页，每次获取30条评论” 的功能未实现。
	private UILoadingGifUtil mUILoadingGifUtil = UILoadingGifUtil.create();
	private UINetworkErrorUtil mUINetworkErrorUtil = UINetworkErrorUtil.create();

	private CommentDialogView commentDialog;
	private boolean SEND_SUCCESS = false;//评论成功返回去得时候刷新，只有成功时才会刷新，避免无用刷新

	private CommentListViewModel mCommentListViewModel;
	private ActivityCommentListBinding mBinding;
	private PageParamInfo mPageParamInfo = new PageParamInfo();
	private String mPackageName = null, mAppName = null;
	private String mPageFrom = null,fromPage;
	private int mVersionCode;
	private int mSortType = Constant.SORT_TYPE_RELEVANT;//1:most recent, 2:most relevant
	private int mTotal = 0;
	private int mStar = 0;
	private CommentInfo mCommentInfo;
	private String mValues;
	private String mFrom;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mBinding = getViewDataBinding();

		mCommentListViewModel.getCommentList().observe(this, new Observer<CommentRespInfo>() {
			@Override
			public void onChanged(CommentRespInfo commentInfos) {
				onCommentListChanged(commentInfos);
			}
		});

		mPageParamInfo.deliverPageParamInfo(getIntent(), PageConstants.Comment_Soft);

		onInitArguments(getIntent());

		findViews();
		setEmptyViewCenter();

		TRAnalyticsManager.getmInstance().postClickEvent(TRAnalyticsConstant.MORE_COMMENTS_SHOW, FirebaseAnalyticsTool.getCommonParamBundle(), true);

		PagePvBuilder pagePvBuilder = new PagePvBuilder();
		pagePvBuilder.setValue(mValues)
				.setFrom(mFrom).setItemId(appId);
		TRAnalysticsUtil.trackPV(pagePvBuilder);
	}

	/**
	 * 空态页居中显示
	 */
	private void setEmptyViewCenter() {
		int height = DisplayUtil.getScreenHeight(this);
		int emptyLayoutHeight = getResources().getDimensionPixelSize(R.dimen.empty_view_height);
		int titleHeight = getResources().getDimensionPixelSize(R.dimen.dp_56);
		int halfMarginTop = (height - emptyLayoutHeight) / 2;
		int statusBarHeight = (int) PlayerUtils.getStatusBarHeight(this);
		int finalMarginTop = halfMarginTop - statusBarHeight - titleHeight;
		if (finalMarginTop <= 0) {
			finalMarginTop = 0;
		}
		RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mBinding.includeEmptyView.layoutEmptyViewRoot.getLayoutParams();
		params.topMargin = finalMarginTop;
		mBinding.includeEmptyView.layoutEmptyViewRoot.setLayoutParams(params);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);

		onInitArguments(intent);

		initSpinnerControl();

		pageIndex = 1;
		startLoadData();
	}

	private void onInitArguments(Intent intent) {
		if(intent != null) {
			try {
				mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE);
				appId = intent.getStringExtra("APP_ID");
				mPackageName = intent.getStringExtra(Constant.KEY_PACKAGE_NAME);
				mAppName = intent.getStringExtra(Constant.KEY_APPNAME);
				mSortType = intent.getIntExtra(Constant.KEY_SORTTYPE, Constant.SORT_TYPE_RELEVANT);
				mTotal = intent.getIntExtra(Constant.KEY_TOTAL, 0);
				mVersionCode = intent.getIntExtra(Constant.KEY_VERSIONCODE, 0);
				mPageFrom = intent.getStringExtra(PageConstants.PAGE_KEY_LASTPAGE);
				mCommentInfo = intent.getParcelableExtra(Constant.KEY_CURRENT_COMMENT);
				fromPage = intent.getStringExtra(Constant.KEY_FROM_PAGE);

				mValues = TRStringUtil.generateString(mPageFrom, TRAnalyticsConstant.MODULE_ALL_REVIEW, "", "");
			}catch (Exception e){
				if (BuildConfig.DEBUG) e.printStackTrace();
			}
		}

		if(TextUtils.equals(PageConstants.WRITE_COMMENT, fromPage)) {
			SEND_SUCCESS = true;
		}
	}

	@Override
	public String getValue() {
		return mValues;
	}

	private void onCommentListChanged(CommentRespInfo commentData) {

		mBinding.commentList.loadMoreComplete();
		mBinding.commentList.refreshComplete();

		if(commentData != null) {
			mStar = commentData.star;
			List<CommentInfo> list = commentData.commentList;
			if(commentData.pageIndex <= 1) {
				mCommentListAdapter.clearAll();
				mCommentListAdapter.addData(list);
			}else {
				mCommentListAdapter.addData(list);
			}

			mTotal = commentData.total;
			refreshTitle();

			if(list != null && list.size() >= commentData.pageSize) {
				mBinding.commentList.setLoadingMoreEnabled(true);
			}else {
				mBinding.commentList.setLoadingMoreEnabled(false);
				mBinding.commentList.setNoMore(true);
			}

			if(mCommentListAdapter.getItemCount() > 0) {
				mUILoadingGifUtil.setVisibility(View.GONE);
				mUINetworkErrorUtil.setVisibility(View.GONE);
				mBinding.includeEmptyView.getRoot().setVisibility(View.GONE);
				mBinding.commentList.setVisibility(View.VISIBLE);
			}else {
				mUILoadingGifUtil.setVisibility(View.GONE);
				mUINetworkErrorUtil.setVisibility(View.GONE);
				mBinding.includeEmptyView.getRoot().setVisibility(View.VISIBLE);
				mBinding.commentList.setVisibility(View.GONE);
			}
		}else {
			mUILoadingGifUtil.setVisibility(View.GONE);
			mUINetworkErrorUtil.setVisibility(View.VISIBLE);
			mBinding.commentList.setVisibility(View.GONE);
		}
	}

	private void refreshTitle() {
		String numStr = CommonUtils.getCommentCountStr(mTotal);
		String txt = CommonUtils.replace(getResources().getString(R.string.all_review), CommonUtils.TARGET_NUMBER, numStr);
		mBinding.layoutTitleContent.setText(txt);
	}

	private void initBottomButton() {
		RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams)mBinding.layoutIWantRate.getLayoutParams();
		int dp18 = getResources().getDimensionPixelSize(R.dimen.dp_18);
		lp.bottomMargin = TRNavigationBarUtil.isHaveNavigationBar(this) ? 0 : dp18;
		mBinding.layoutIWantRate.setLayoutParams(lp);
		mBinding.layoutIWantRate.setBackgroundColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));
	}

	@Override
	public int getBindingVariable() {
		return BR.commentListViewModel;
	}

	@Override
	public int getLayoutId() {
		return R.layout.activity_comment_list;
	}

	@Override
	public CommentListViewModel getViewModel() {
		mCommentListViewModel = new ViewModelProvider(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(CommentListViewModel.class);
		mCommentListViewModel.setNavigator(this);
		getLifecycle().addObserver(mCommentListViewModel);
		return mCommentListViewModel;
	}

	private void findViews() {
		refreshTitle();
		initSpinnerControl();
		initBottomButton();

		TRLinearLayoutManager linearLayoutManager = new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
		mBinding.commentList.setLayoutManager(linearLayoutManager);
		mBinding.commentList.setLoadingMoreProgressStyle(ProgressStyle.BallPulse);
		mBinding.commentList.setLoadingListener(mXRecyclerViewLoadingListener);

		mCommentListAdapter = new CommentListAdapter(this, true );
		mCommentListAdapter.setActivity(this);
		mCommentListAdapter.setAppName(mAppName);
		mCommentListAdapter.setPackageName(mPackageName);
		mCommentListAdapter.setScreenPageName(mPageFrom);
		mCommentListAdapter.setFeatureName(TRAnalyticsConstant.MODULE_ALL_REVIEW);
		mCommentListAdapter.setFrom(mFrom);
		mBinding.commentList.setAdapter(mCommentListAdapter);

		mBinding.commentList.setPullRefreshEnabled(false);
		//addNoMore(mXRecyclerView,linearLayoutManager,null);

		mUILoadingGifUtil.inflate(this, (ViewGroup)findViewById(R.id.layout_loading_gif));
		mUILoadingGifUtil.setVisibility(View.VISIBLE);

		mUINetworkErrorUtil.inflate(this, (ViewGroup) findViewById(R.id.layout_network_error), true)
				.setFrom(mFrom)
				.setVisibility(View.GONE)
				.setUINetworkErrorOnClickListener(new UINetworkErrorOnClickListener() {

					@Override
					public void onUINetworkErrorClick(View v) {
						if (v == null)
							return;
						if (v.getId() == R.id.tv_setting) {
							SysUtils.openSystemMobileNetworkSettings(CommentListActivity.this, TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS);
						}
					}
				});


		pageIndex = 1;
		startLoadData();
	}

	private XRecyclerView.LoadingListener mXRecyclerViewLoadingListener = new XRecyclerView.LoadingListener() {
		@Override
		public void onRefresh() {

		}

		@Override
		public void onLoadMore() {
			pageIndex++;
			startLoadData();
		}
	};


	public void startLoadData() {
		if (mCommentListAdapter != null && mCommentListAdapter.getItemCount() > 0) {
			mUILoadingGifUtil.setVisibility(View.GONE);
		} else {
			mUILoadingGifUtil.setVisibility(View.VISIBLE);
		}

		String itemId = isFromPluto() ? null : appId;
		mCommentListViewModel.loadCommentList(mStar ,mAppName, itemId, mPackageName, 0, pageIndex, pageSize);
		LogUtils.d("_dataShow","detail - CommentListActivity");
	}

	private void initSpinnerControl() {
		int sort = (mSortType == Constant.SORT_TYPE_RECENT) ? R.string.most_recent : R.string.most_relevant;
		mBinding.tvSort.setText(sort);
	}

	private boolean isFromPluto() {
		boolean isPluto = false;
		//isPluto
		FileDownloadInfo fileDownloadInfo = DownloadManager.getInstance().getDownloadingInfobyPackageName(mPackageName);
		if(fileDownloadInfo == null) {
			fileDownloadInfo = DownloadManager.getInstance().getDownloadedInfobyPackageName(mPackageName);
		}
		if(fileDownloadInfo != null && fileDownloadInfo.extraInfo != null) {
			isPluto = fileDownloadInfo.extraInfo.isPlutoOffer;
		}
		return isPluto;
	}

	@Override
	public void finish() {
		setResult(RESULT_OK, new Intent().putExtra("success", SEND_SUCCESS).putExtra(Constant.KEY_CURRENT_COMMENT, mCommentInfo));
		super.finish();

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(commentDialog != null){
			commentDialog.onClear();
			commentDialog = null;
		}

		if(mBinding.commentList != null){
			mBinding.commentList.loadMoreComplete();
			mBinding.commentList.refreshComplete();
		}
		mXRecyclerViewLoadingListener = null;
		mUINetworkErrorUtil = null;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.layout_sort:
				onSortSpinnerClick(v);
				break;

			case R.id.btn_write_comment:
				onSendButtonClick(v);
				break;
			case R.id.layout_title_back:
				onBackClick(v);
				break;
		}
	}

	@Override
	public void onBackPressed() {
		onBackClick(null);
	}

	private void onSortTypeChanged(int type, String menuStr) {

		mSortType = type;
		if(!TextUtils.isEmpty(menuStr)) {
			mBinding.tvSort.setText(menuStr);
		}

		//TODO:load comment
		pageIndex = 1;
		startLoadData();


		String itemType = (type == Constant.SORT_TYPE_RELEVANT) ? TRAnalyticsConstant.MOST_RELEVANT : TRAnalyticsConstant.MOST_RECENT;
		ComponentClickBuilder builder = new ComponentClickBuilder();
		builder.setValue(mValues)
				.setFrom(mFrom)
				.setTopicType("")
				.setTopicId("")
				.setItemType("")
				.setItemId(appId)
				.setButtonType(itemType)
				.setItemValue(mPackageName)
				.setExtraValue("");
		TRAnalysticsUtil.trackClick(builder);
	}

	private void onSortSpinnerClick(View view) {
		CustomPopuWin popuWin = new CustomPopuWin(this);
		int resid[] = {R.string.most_relevant, R.string.most_recent};
		popuWin.setData(resid, new PopMenuItemSelectedListener() {
			@Override
			public void onItemClicked(Object itemInfo, String menuStr) {
				if(itemInfo instanceof Integer) {
					Integer index = (Integer)itemInfo;
					if(index == 0) { // most_relevant
						onSortTypeChanged(Constant.SORT_TYPE_RELEVANT, menuStr);
					}else if(index == 1) { //most_recent
						onSortTypeChanged(Constant.SORT_TYPE_RECENT, menuStr);
					}
				}
			}
		}).onShow(view);
	}

	private void onSendButtonClick(View view) {
		if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
			ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
			return;
		}

		FileDownloadInfo downloadedInfo = PsVaManager.getInstance().getVaInstallResult(mPackageName);
		if(!InstalledAppManager.getInstance().isInstalled(mPackageName) && downloadedInfo == null) { // 只判断包名，不判断版本号
			ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_install_for_feedback);
			return;
		}

		Intent intent = new Intent(this, CommentActivity.class);
		intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, mPageFrom);
		intent.putExtra(TRAnalyticsConstant.VALUE, mValues);
		intent.putExtra(Constant.KEY_ITEMID, appId);
		intent.putExtra(Constant.KEY_APPNAME, mAppName);
		intent.putExtra(Constant.KEY_PACKAGE_NAME, mPackageName);
		intent.putExtra(Constant.KEY_VERSIONCODE, mVersionCode);
		intent.putExtra(Constant.KEY_CURRENT_COMMENT, mCommentInfo);
		startActivity(intent);

		ComponentClickBuilder builder = new ComponentClickBuilder();
		builder.setValue(mValues)
				.setFrom(mFrom)
				.setTopicType("")
				.setTopicId("")
				.setItemType("")
				.setItemId(appId)
				.setButtonType(TRAnalyticsConstant.WRITE)
				.setItemValue(mPackageName)
				.setExtraValue("");
		TRAnalysticsUtil.trackClick(builder);
	}

	private void onBackClick(View view) {
		finish();
		ComponentClickBuilder builder = new ComponentClickBuilder();
		builder.setValue(mValues)
				.setFrom(mFrom)
				.setTopicType("")
				.setTopicId("")
				.setItemType("")
				.setItemId(appId)
				.setButtonType(TRAnalyticsConstant.BUTTON_BACK)
				.setItemValue(mPackageName)
				.setExtraValue("");
		TRAnalysticsUtil.trackClick(builder);
	}
}

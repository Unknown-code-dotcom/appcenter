package com.afmobi.palmplay.activate

import android.app.Activity
import com.afmobi.palmplay.activate.manager.TRNewManager
import com.afmobi.palmplay.dialog.OfflineMoreGuideDialog

class TROfflineMoreGuideExecutor: TRBaseExecutor<Any?>() {

    private var offlineMoreGuideDialog : OfflineMoreGuideDialog? = null
    override fun isCanShow(fromType: String): Boolean {
        return TRNewManager.instance.canShow()
    }

    override fun show(fromType: String, activity: Activity?, listener: OfflineMoreGuideDialog.OnDialogBtnClickListener, isR2L: Boolean,location: IntArray ): Boolean {
        if(activity != null && !activity.isFinishing && !activity.isDestroyed)  {
            if(isCanShow(fromType)) {
                offlineMoreGuideDialog = OfflineMoreGuideDialog(activity)
                if(offlineMoreGuideDialog != null) {
                    offlineMoreGuideDialog!!.setOnDialogClickListener(listener)
                        .setLocation(location).setIsR2LDirection(isR2L)
                        .show()
                    return true
                }
            }
        }
        return false
    }

    override fun dismiss(): Boolean {
        if(offlineMoreGuideDialog != null && offlineMoreGuideDialog!!.isShowing) {
            offlineMoreGuideDialog!!.dismiss()
        }
        return true
    }
}
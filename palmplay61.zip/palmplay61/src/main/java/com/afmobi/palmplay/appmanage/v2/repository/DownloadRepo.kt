package com.afmobi.palmplay.appmanage.v2.repository

import androidx.lifecycle.LiveData
import com.afmobi.palmplay.appmanage.v2.model.DownloadStatus
import com.afmobi.palmplay.model.SimpleDataInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

/**
 * 下载管理数据仓库接口
 * 负责统一管理所有数据源的访问
 */
interface DownloadRepo {
    
    /**
     * 获取下载中的任务列表
     * @return 下载中任务列表
     */
    suspend fun getDownloadingList(): List<FileDownloadInfo>
    
    /**
     * 获取已下载未安装的任务列表
     * @return 已下载任务列表
     */
    suspend fun getDownloadedList(): List<FileDownloadInfo>
    
    /**
     * 获取已安装的任务列表
     * @return 已安装任务列表
     */
    suspend fun getInstalledList(): List<FileDownloadInfo>
    
    /**
     * 获取不可下载的任务列表
     * @return 不可下载任务列表
     */
    suspend fun getNoResList(): List<FileDownloadInfo>

    /**
     * 获取节省数据列表
     * @return 节省数据列表
     */
    suspend fun getSavedDataList(): List<SimpleDataInfo>
    
    /**
     * 删除不可下载任务
     * @param info 要删除的任务信息
     */
    fun deleteNoResTask(info: FileDownloadInfo)
    
    /**
     * 检查是否存在下载中的任务
     * @param downloadingList 下载列表
     * @return 是否存在下载中任务
     */
    fun isExistDownloading(downloadingList: List<FileDownloadInfo>): Boolean

    /**
     * 检查是否存在未开始下载的任务
     * @param downloadingList 下载列表
     * @return 是否存在未开始下载的任务
     */
    fun isExistUnDownload(downloadingList: List<FileDownloadInfo>): Boolean
    
    /**
     * 获取刷新通知LiveData
     * @return 刷新通知LiveData
     */
    fun getRefreshFlow(): SharedFlow<String>

    fun getProgressFlow(packageName: String): SharedFlow<DownloadStatus>
    
    /**
     * 注册下载状态监听器
     */
    fun registerDownloadStatusListener()
    
    /**
     * 注销下载状态监听器
     */
    fun unregisterDownloadStatusListener()
    
    /**
     * 销毁资源
     */
    fun destroy()
}
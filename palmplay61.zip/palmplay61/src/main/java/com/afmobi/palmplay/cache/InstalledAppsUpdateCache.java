// TOP SECRET
package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.apk.ThreadHelper;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.acpush.model.OnFetchedListener;
import com.afmobi.palmplay.acpush.repo.AcPushConfigRepo;
import com.afmobi.palmplay.appmanage.db.UpdateDatabase;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.ClientVersion.UpdateItem;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.AppsUpdateList;
import com.afmobi.palmplay.model.keeptojosn.CheckRequestItem;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.network.NetworkClient;
import com.afmobi.palmplay.service.PalmstoreService;
import com.afmobi.palmplay.service.dispatch.PalmstoreSysHandler;
import com.afmobi.palmplay.setting.IndividualCenterUpdateManageUtils;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.afmobi.util.NetworkState;
import com.afmobi.util.NetworkUtils;
import com.afmobi.util.PhoneDeviceInfo;
import com.afmobi.util.TimeUtil;
import com.androidnetworking.error.ANError;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtilExtKt;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.analytics.apm.cache.ApmAppCacheUtil;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.SignUtils;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;
import com.transsnet.store.BuildConfig;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import de.greenrobot.event.EventBus;

public class InstalledAppsUpdateCache implements LocalCache {

	private static final String CACHE_URI = "WHITE_CACHE";
	private final static String FILE_NAME = "InstalledAppsUpdateCache";
	private final static String HIGH_FREQ_SA_FILE_NAME = "InstalledAppsUpdateCacheHighFreqSA";
	private static final String LAST_REQUEST_API_KEY = "last_request_white_api_key";
	private static final String ph_key_update_date = "ph_key_update_date";
	private static volatile InstalledAppsUpdateCache mInstance;
	private AppsUpdateList mAppsUpdateItemList = new AppsUpdateList();
	private AppsUpdateList mHighFreqSAUpdateItemList = new AppsUpdateList();
	private AppsUpdateList mSlientUpdateItemList = new AppsUpdateList();  // 静默下载的数据
	private List<UpdateItem> mIgnoreUpdateItemList = new ArrayList<>();
	private long mDataMark = 0;
	private long mLastReqApiTime = 0;
	/**
	 * 已更新安装成功的应用。更新安装成功系统会先发卸载广播，然后发安装成功广播。卸载广播的时候就把当条记录移除了，所以先缓存下，等安装成功广播打点的时候使用
	 */
	private List<UpdateItem> removedAppList = new ArrayList<>(10);

	public static final int MAX_PAGE = 10;
	public static final int MAX_PAGE_SIZE = 25;
	public static final String REQUEST_TYPE_TIMER = "TIMER";
	public static final String REQUEST_TYPE_HAND = "HAND";
	/** AC-PUSH 高频拉取的 requestType（与已有 TIMER / HAND 并列）。 */
	public static final String REQUEST_TYPE_HIGH_FREQ_SA = "HIGH_FREQ_SA";
	public static final String KEY_LAST_HIGH_FREQ_MS = "acpush_last_high_freq_ms";
	public static final long ONE_HOUR = 1 * 60 * 60 * 1000L; //1h
	public static final long ONE_DAY = 1 * 24 * ONE_HOUR; //1d

	private InstalledAppsUpdateCache() {
		loadFromCache();
	}

	public static InstalledAppsUpdateCache getInstance() {
		if (mInstance == null) {
			synchronized (InstalledAppsUpdateCache.class) {
				if (mInstance == null) {
					mInstance = new InstalledAppsUpdateCache();
				}
			}
		}
		return mInstance;
	}

	public void setAppLastUpdateYMD() {
		long curTimeMillis = System.currentTimeMillis();
		String curYMD = TimeUtil.getDateToStringYMD(curTimeMillis);
		SPManager.putString(Constant.preferences_key_app_last_update_ymd, curYMD);
	}

	public boolean isNeedRequestUpdate(boolean needUpdate) {
		if (mLastReqApiTime == 0) {
			mLastReqApiTime = SPManager.getLong(LAST_REQUEST_API_KEY, 0);
		}

		long requestInterval = Constants.DEFAULT_REQUEST_INTERVAL;

		int loadinterval = SPManager.getInt(Constant.preferences_key_app_last_white_loadinterval, 0);
		int reloadinterval = SPManager.getInt(Constant.preferences_key_app_last_white_reloadinterval, 0);

		JsonElement white_cache = FilePathManager.fileToJson(CACHE_URI);
		if (needUpdate || white_cache == null) {
			if (loadinterval > 0) {
				requestInterval = loadinterval * Constants.TIME_HOUR_UNIT;
			}
		} else {
			if (reloadinterval > 0) {
				requestInterval = reloadinterval * Constants.TIME_HOUR_UNIT;
			}
		}

		if (requestInterval <= 0) {
			requestInterval = Constants.DEFAULT_REQUEST_INTERVAL;
		}

		if (System.currentTimeMillis() - mLastReqApiTime < requestInterval) {
            LogUtils.i(LogUtils.TAG_THIRD_UPDATE,"getUpdateWhiteList < interval,needUpdate = " + needUpdate);
			return false;
		}

		mLastReqApiTime = System.currentTimeMillis();
		SPManager.putLong(LAST_REQUEST_API_KEY, mLastReqApiTime);
		return true;
	}

	private boolean isHaveUpdateApp() {
		if (mAppsUpdateItemList != null && mAppsUpdateItemList.updateList != null
				&& mAppsUpdateItemList.updateList.size() > 0) {
			return true;
		}

		return false;
	}

	public void sendCheckAppsUpdateRequest() {
		UpdateRequestInfo requestInfo = buildScheduledUpdateRequest(null, true);
		if (requestInfo == null) {
			return;
		}
		onCheckAppsUpdateRequest(requestInfo.requestType, requestInfo.newUserFlag);
	}

	//单独方法，定时请求受GDPR、新手保护、getTimerUpdateIntervalHour下发的频率管控，
	// 但是 AC-PUSH的高频请求受GDPR、新手保护；不受getTimerUpdateIntervalHour的配置管控，高频的请求有额外的管控频率字段
	private UpdateRequestInfo buildScheduledUpdateRequest(String overrideRequestType, boolean checkTimerInterval) {

		if (!com.transsion.palmstorecore.util.NetworkUtils.sNetworkConnected) {
			LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService --> network not connected");
			TRAnalysticsUtil.trackRedIconTech("au_req", "no_net", 0);
			return null;
		}

		boolean isGdprAgree = TRSharedPreferenceUtils.isPrivacyPolicyAgree();
		if (!isGdprAgree) {
			if (!CommonUtils.isAboveAndroidT() ) {
				if (!ConfigManager.isOS12SkipGdpr()) {
					TRAnalysticsUtil.trackRedIconTech("au_req", "12b_i", 0);
					return null;
				} else {
					TRAnalysticsUtil.trackRedIconTech("au_req", "12b", 0);
				}
			} else {
				TRAnalysticsUtil.trackRedIconTech("au_req", "13u_i", 0);
				LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService -->  >=T isNeedRequestUpdate:privacy policy was not agreed.");
				return null;
			}
		}
		long lastRequest = SPManager.getLong(Constant.preferences_key_app_last_update_time, 0);
		long curTimeMillis = System.currentTimeMillis();
		long activeTime = SPManager.getLong(TRSharedPreferenceUtils.preferences_key_active_time, 0);
		long defaultProtectorTime = MMKVUtils.getMMKV().getInt(Constant.KV_UPDATE_PROTECTION_INTERVAL, 7*24); //新手保护期，默认7天
		int newUserFlag = 0; // 新手标记：0->老手或以获取数据，  1->新手且无数据
		String requestType = InstalledAppsUpdateCache.REQUEST_TYPE_TIMER;

		if (curTimeMillis - activeTime < defaultProtectorTime*ONE_HOUR) { //新用户更新保护期

			if (isHaveUpdateApp()) {  //保护期内已更新到内容，退出新手保护期；继续走定时逻辑请求更新；
				LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService -->isNeedRequestUpdate:will not request because update is already success.");

				if (checkTimerInterval) {
					long normalUserInterval = getTimerUpdateIntervalHour();//定时更新间隔，默认24小时；AC-PUSH 开启时使用 PM 下发 regular_interval_hour
					if (curTimeMillis - lastRequest < normalUserInterval * ONE_HOUR) {
						LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService --> isNeedRequestUpdate:request interval is not verify for timer with data, normalUserInterval:" + normalUserInterval + ", defaultProtecorTime:" + defaultProtectorTime);
						return null;
					}
				}
			}else {
				newUserFlag = 1;
				requestType = InstalledAppsUpdateCache.REQUEST_TYPE_HAND;

				//判断间隔
				if (lastRequest <= 0) { //新手第1次执行，间隔从激活时间开始算
					int newUserInterval = MMKVUtils.getMMKV().getInt(Constant.KV_UPDATE_FIRST_INTERVAL, 0); //新手更新间隔，首次默认0小时（立即执行）；
					if (curTimeMillis - activeTime < newUserInterval * ONE_HOUR) {
						LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService --> isNeedRequestUpdate:request interval is not verify for new user, first newUserInterval:"+newUserInterval + ", defaultProtecorTime:" + defaultProtectorTime);
						return null;
					}
				}else {// 新手第2...n次执行，间隔从上次请求开始算

					int newUserInterval = MMKVUtils.getMMKV().getInt(Constant.KV_UPDATE_OTHER_INTERVAL, 24); //新手更新间隔，第2...n次，默认24h；
					if (curTimeMillis - lastRequest < newUserInterval * ONE_HOUR) {
						LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService -->isNeedRequestUpdate:request interval is not verify for new user, seond newUserInterval:" + newUserInterval + ", defaultProtecorTime:" + defaultProtectorTime);

						if (!checkTimerInterval) {
							return null;
						}
						int normalUserInterval = getTimerUpdateIntervalHour();//定时更新间隔，默认24小时；AC-PUSH 开启时使用 PM 下发 regular_interval_hour
						if (curTimeMillis - lastRequest < normalUserInterval * ONE_HOUR) {
							LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService --> isNeedRequestUpdate:request interval is not verify for timer n,normalUserInterval:" + normalUserInterval + ", defaultProtecorTime:" + defaultProtectorTime);
							return null;
						}

						newUserFlag = 0;
						requestType = InstalledAppsUpdateCache.REQUEST_TYPE_TIMER;
					}
				}
			}
		}else {  //非新手保护期
			if (checkTimerInterval) {
				long normalUserInterval = getTimerUpdateIntervalHour();//老手更新间隔，默认24小时；AC-PUSH 开启时使用 PM 下发 regular_interval_hour
				if (curTimeMillis - lastRequest < normalUserInterval * ONE_HOUR) {
					LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "JobService --> isNeedRequestUpdate:request interval is not verify for timer, normalUserInterval:" + normalUserInterval + ", defaultProtectorTime:" + defaultProtectorTime);
					return null;
				}
			}
		}

		if (!TextUtils.isEmpty(overrideRequestType)) {
			requestType = overrideRequestType;
		}
		return new UpdateRequestInfo(requestType, newUserFlag);
	}

	private static class UpdateRequestInfo {
		final String requestType;
		final int newUserFlag;

		UpdateRequestInfo(String requestType, int newUserFlag) {
			this.requestType = requestType;
			this.newUserFlag = newUserFlag;
		}
	}

	private int getTimerUpdateIntervalHour() {
		boolean enabled = AcPushConfigRepo.INSTANCE.isEnabled();
		LogUtils.d(LogUtils.TAG_AC_PUSH, "timer update interval check, enabled=" + enabled);
		if (enabled) {
			int interval = AcPushConfigRepo.INSTANCE.regularHour();
			LogUtils.d(LogUtils.TAG_AC_PUSH, "timer update interval controlled by ac push, regularHour=" + interval);
			return interval;
		}
		return SPManager.getInt(Constant.preferences_key_app_last_update_interval, 24);
	}

	public void sendCheckAppsUpdateRequestByUser() {
//		if (!TRSharedPreferenceUtils.isPrivacyPolicyHasShowed()) { //主动请求无需用户激活
//			LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "isNeedRequestUpdate:privacy policy was not agreed.");
//			return;
//		}

		if (!com.transsion.palmstorecore.util.NetworkUtils.sNetworkConnected) {
			LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "network not connected");
			TRAnalysticsUtil.trackRedIconTech("au_req_hand", "no_net", 0);
			return;
		}

		long lastRequest = SPManager.getLong(Constant.preferences_key_app_last_update_time, 0);

		if (System.currentTimeMillis() - lastRequest < 10 * Constants.TIME_MIN_UNIT) {
			LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "sendCheckAppsUpdateRequestByUser:request interval < 10min");
			return;
		}

		long curTimeMillis = System.currentTimeMillis();
		int limit = SPManager.getInt(Constant.preferences_key_app_update_limit_count, 2); //单日主动更新限制，默认2次
		int count = SPManager.getInt(Constant.preferences_key_app_update_total, 0);
		String lastYMD = TimeUtil.getDateToStringYMD(lastRequest);
		String currYMD = TimeUtil.getDateToStringYMD(curTimeMillis);
		if (!TextUtils.isEmpty(lastYMD) && TextUtils.equals(lastYMD, currYMD)) {
			if (count >= limit) {
				LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "sendCheckAppsUpdateRequestByUser :request count over limit " + limit);
				return;
			}
		}else {
			count = 0;
		}


		count++;
		SPManager.putInt(Constant.preferences_key_app_update_total, count);
		onCheckAppsUpdateRequest(InstalledAppsUpdateCache.REQUEST_TYPE_HAND, 0);
	}

	//请求更新应用
	public void onCheckAppsUpdateRequest(final String requestType, final int newUserFlag) {
		//优化sendCheckAppsUpdateRequestByUser时线程池等待太久问题
		TRThreadPool.getInstance(TextUtils.equals(InstalledAppsUpdateCache.REQUEST_TYPE_HAND, requestType) ? TRThreadPool.PRIORITY_HIGH : TRThreadPool.PRIORITY_LOW).submit(new Runnable() {
			@Override
			public void run() {
				List<CheckRequestItem> installedList;
				if (REQUEST_TYPE_HIGH_FREQ_SA.equals(requestType)) {
					installedList = getHighFreqSARequestItems();
					if (installedList == null || installedList.isEmpty()) {
						LogUtils.i(LogUtils.TAG_AC_PUSH, "AC-PUSH high-freq: no S/A apps, skip request");
						return;
					}
				} else {
					List<String> whitelist = null;
					try {
						JsonArray jsonObject = (JsonArray) FilePathManager.fileToJson(CACHE_URI);
						if (jsonObject != null) {
							Type type = new TypeToken<List<String>>(){}.getType();
							whitelist = new Gson().fromJson(jsonObject,type);
						}
					} catch (Exception e) {
						LogUtils.e(e);
					}

                    if (BuildConfig.DEBUG) {
                        LogUtils.i(LogUtils.TAG_THIRD_UPDATE,"whitelist =  " + whitelist);
                    }
					//无配置白名单时即所有非系统应用都支持app
					installedList = InstalledAppManager.getInstance().getCheckUpdateItemList(whitelist);
				}

				LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "It will begin check apps udpate...");
				if (REQUEST_TYPE_HIGH_FREQ_SA.equals(requestType)) {
					MMKVUtils.getMMKV().encode(KEY_LAST_HIGH_FREQ_MS, System.currentTimeMillis());
				} else {
					SPManager.putLong(Constant.preferences_key_app_last_update_time, System.currentTimeMillis());
				}
				NetworkClient.checkAppsUpdateHttpRequest(NetworkActions.ACTION_SYS_APP_UPDATE, installedList, false, 0, 0, 0, System.currentTimeMillis(), requestType, newUserFlag);
			}
		});
	}


    public void onStartUpUpdateRequest() {
		ThreadHelper.runOnWorkThread(() -> {
			List<CheckRequestItem> installedList = InstalledAppManager.getInstance().getCheckStartUpUpdateItemList();
            if (installedList != null && !installedList.isEmpty()) {
                NetworkClient.checkStartUpUpdateHttpRequest(NetworkActions.ACTION_STARTUP_UPDATE, installedList);
            }
        });
    }

	public boolean preSendCheckAppsUpdateRequest(boolean needUpdate,final int reqType) {
		if(isNeedRequestUpdate(needUpdate)) {

			try {
				if (needUpdate) {
					long mLastRequestTime = System.currentTimeMillis();
                    LogUtils.i(LogUtils.TAG_THIRD_UPDATE,"getUpdateWhiteList request" + needUpdate);
                    NetworkClient.getUpdateWhiteList(NetworkActions.ACTION_GET_UPDATE_WHITELIST, reqType, new ApmAppCacheUtil.NetCall() {
						@Override
						public void onResponse(String result, int size, long costTime) {
							ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.checkApps_t,
									-1, mLastRequestTime, result, size, costTime);
						}

						@Override
						public void onError(ANError anError) {
							ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.checkApps_t,
									-1, mLastRequestTime, anError);
						}
					});
					return true;
				}
			} catch (NoSuchFieldError | Exception e) {
				if (BuildConfig.DEBUG) e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * WiFi下，并且开启了WiFi自动更新，就要去主动检查更新，或者开启下载
	 */
	public void wifiInstalledAppsUpdateHandle(boolean needUpdate){
		if(AppDataManager.FEATURE_AUTO_DOWNLOAD_UPDATE_ENABLE == false && isNeedRequestUpdate(needUpdate)) {
			if (needUpdate) {
				long mLastRequestTime = System.currentTimeMillis();
				NetworkClient.getUpdateWhiteList(NetworkActions.ACTION_GET_UPDATE_WHITELIST,2, new ApmAppCacheUtil.NetCall() {
					@Override
					public void onResponse(String result, int size, long costTime) {
						ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.checkApps_t_1,
								-1, mLastRequestTime, result, size, costTime);
					}

					@Override
					public void onError(ANError anError) {
						ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.checkApps_t_1,
								-1, mLastRequestTime, anError);
					}
				});
			}
		}
		// 以下根据开关判断是否需要自动下载更新包功能
		if(AppDataManager.FEATURE_AUTO_DOWNLOAD_UPDATE_ENABLE == false) {
			return;
		}
		if(PhoneDeviceInfo.isWifiAutoUpdate() && TextUtils.equals(NetworkUtils.getNetworkState(PalmplayApplication.getAppInstance()), NetworkState.WIFI)){
			if(isNeedRequestUpdate(needUpdate) && (boolean) TRSharedPreferenceUtils.getParam(TRSharedPreferenceUtils.SP_PERMISSION_FILE,TRSharedPreferenceUtils.HAS_PERMISSION,false)){
				long mLastRequestTime = System.currentTimeMillis();
				NetworkClient.getUpdateWhiteList(NetworkActions.ACTION_GET_UPDATE_WHITELIST,2, new ApmAppCacheUtil.NetCall() {
					@Override
					public void onResponse(String result, int size, long costTime) {
						ApmAppCacheUtil.getInstance().startCollectCacheResult(ApmAppCacheUtil.checkApps_t_2,
								-1, mLastRequestTime, result, size, costTime);
					}

					@Override
					public void onError(ANError anError) {
						ApmAppCacheUtil.getInstance().startCollectCacheError(ApmAppCacheUtil.checkApps_t_2,
								-1, mLastRequestTime, anError);
					}
				});
			}else {
				List<UpdateItem> updateItemList = IndividualCenterUpdateManageUtils.getUpdateList();
				if(null == updateItemList || updateItemList.size() <= 0){
					return;
				}
				//DownloadManager.batchUpdateNewVersion(updateItemList, null);
				DownloadManager.updateNewVersion(updateItemList, null, false);
			}
		}
	}

	public void updateDataMark(long dataMark) {
		mDataMark = dataMark;
	}

	public long getCategoryDataMark() {
		return mDataMark;
	}

	// ===== AC-PUSH hook =====

	/**
	 * AC-PUSH: 触发高频 S/A 拉取并复用普通定时更新的网络、GDPR、新手保护检查。
	 * 高频自己的 fastInterval 已在 AcPushUpdateRepository.tick 内检查，这里不再套普通 regularHour 间隔。
	 */
	public void sendHighGradeCheckAppsUpdateRequest() {
		UpdateRequestInfo requestInfo = buildScheduledUpdateRequest(InstalledAppsUpdateCache.REQUEST_TYPE_HIGH_FREQ_SA, false);
		if (requestInfo == null) {
			return;
		}
		onCheckAppsUpdateRequest(requestInfo.requestType, requestInfo.newUserFlag);
	}

	/**
	 * AC-PUSH: 高频 S/A 请求直接使用 PM update_config 下发的 hight_grade_list 包名集合，
	 * 不走更新白名单，也不依赖本地 UpdateItem cache。
	 */
	private List<CheckRequestItem> getHighFreqSARequestItems() {
		Set<String> packageNames = AcPushConfigRepo.INSTANCE.highFreqPackageNames();
		if (packageNames == null || packageNames.isEmpty()) {
			return new ArrayList<>();
		}

        String checkPm = "-1";
        InstalledAppInfo pmPackageInfo = null;

		List<CheckRequestItem> requestItems = new ArrayList<>();
		for (InstalledAppInfo packageInfo : InstalledAppManager.getInstance().getPackages()) {
            if (Constant.PM_PKG.equals(packageInfo.packageName)) {
                checkPm = "1";
                pmPackageInfo = packageInfo;
                if ((packageNames != null && packageNames.contains(packageInfo.packageName))){
                    checkPm = "2";
                }
            }

			if (packageInfo == null || TextUtils.isEmpty(packageInfo.packageName)
					|| !packageNames.contains(packageInfo.packageName)) {
				continue;
			}
			CheckRequestItem tmpInfo = new CheckRequestItem();
			tmpInfo.packageName = packageInfo.packageName;
			tmpInfo.version = packageInfo.versionCode;
			if (BuildConfig.FEATURE_APP_DIFF_SWITCH && !TextUtils.isEmpty(packageInfo.packageName)) {
				tmpInfo.md5 = SignUtils.getMd5ByFile(new File(InstalledAppManager.getInstance().getSourceDir(packageInfo.packageName)));
			}
			tmpInfo.appSign = packageInfo.signature;
			requestItems.add(tmpInfo);
		}

        TRAnalysticsUtilExtKt.trackUpdateTech(TRAnalyticsConstant.PS_SILENT_UPDATE_TYPE_PRE,checkPm,0, pmPackageInfo != null ? pmPackageInfo.packageName : null, pmPackageInfo != null ? pmPackageInfo.versionCode : 0);

        LogUtils.d(LogUtils.TAG_AC_PUSH, "high-freq request items prepared, gradePackageCount="
				+ packageNames.size() + ", installedMatchCount=" + requestItems.size());
		return requestItems;
	}

	/**
	 * AC-PUSH 监听拉取完成事件；由 AcPushUpdateRepository 注入。一次只允许一个 listener；
	 * 监听方需自行判断 AcPushConfigRepo.isEnabled。
	 */
	private volatile OnFetchedListener mOnFetchedListener;

	public void setOnFetchedListener(OnFetchedListener listener) {
		this.mOnFetchedListener = listener;
	}

	public OnFetchedListener getOnFetchedListener() {
		return mOnFetchedListener;
	}

	// ===== AC-PUSH hook end =====

	//保存更新应用
	public void saveToCacheFile(AppsUpdateList appsUpdateItemList) {
		if (null != appsUpdateItemList) {
			String msgbuffer = "";
			if(mSlientUpdateItemList!=null && mSlientUpdateItemList.updateList!=null) {
				mSlientUpdateItemList.updateList.clear();
			}

			if(mAppsUpdateItemList!=null && mAppsUpdateItemList.updateList!=null) {
				mAppsUpdateItemList.updateList.clear();
			}

			for(ClientVersion.UpdateItem item:appsUpdateItemList.updateList) {
				addNormalUpdateItemToMemory(item);
            }
			// 普通更新接口只覆盖普通缓存文件，但内存列表需要保持“普通 + S/A”的全集，
			// 这样更新页、角标、通知等其它读取 getUpdateItemList() 的业务不会漏掉高频 S/A 数据。
			mergeHighFreqSAToUpdateList();
			Gson gson = new Gson();
			msgbuffer = gson.toJson(appsUpdateItemList, AppsUpdateList.class);
			saveToCache(msgbuffer);
		}
	}

	/**
	 * 保存 AC-PUSH 高频 S/A 请求返回的数据。
	 *
	 * 高频 S/A 数据不能写入普通更新缓存文件，否则会把 TIMER/HAND 等旧流程保存的完整更新列表覆盖掉。
	 * 这里单独落文件，同时重新合成内存态 mAppsUpdateItemList：
	 * 1. 接口原始返回为空时不覆盖本地 S/A 文件，避免偶发空结果把可用缓存清掉；
	 * 2. S/A 是持续追加模型，本次返回只追加或更新同包名数据，不会整包替换本地 S/A 文件；
	 * 3. 保存前会重新校验本地版本，已更新完成的历史 S/A 项会被清理；
	 * 4. 对外仍通过 getUpdateItemList() 暴露全集，避免其它业务因为只读普通缓存而缺数据。
	 */
	public void saveHighFreqSAToCacheFile(AppsUpdateList appsUpdateItemList) {
		if (null == appsUpdateItemList || appsUpdateItemList.updateList == null || appsUpdateItemList.updateList.isEmpty()) {
			return;
		}
		ensureHighFreqSAUpdateList();
		// S/A 是追加保存，历史数据可能因为用户已经安装更新而失效。
		// 每次追加新数据前先清理一次，避免独立文件长期残留已更新完成的应用。
		Iterator<UpdateItem> iterator = mHighFreqSAUpdateItemList.updateList.iterator();
		while (iterator.hasNext()) {
			ClientVersion.UpdateItem item = iterator.next();
			if (!shouldKeepHighFreqSAItem(item)) {
				iterator.remove();
			}
		}
		for (ClientVersion.UpdateItem item : appsUpdateItemList.updateList) {
			if (!shouldKeepHighFreqSAItem(item)) {
				continue;
			}
			addOrReplaceHighFreqSAItem(item);
		}
		Gson gson = new Gson();
		String msgbuffer = gson.toJson(mHighFreqSAUpdateItemList, AppsUpdateList.class);
		saveHighFreqSAToCache(msgbuffer);
		// S/A 请求结果只代表高频集合，不能直接作为 mAppsUpdateItemList 的全部内容。
		// 这里重读的是普通更新缓存，不是旧 S/A 数据：目的是先清掉内存里上一轮合入的旧 S/A，
		// 再合并本地累计后的 S/A 集合，保证 getUpdateItemList() 是“普通 + 累计 S/A”的全集。
		reloadNormalUpdateCache();
		mergeHighFreqSAToUpdateList();
	}

	@Override
	public String getFileName(Object... objects) {
		// getIMEI need permission
		return FILE_NAME/* + PhoneDeviceInfo.getImei()*/;
	}

	@Override
	public void saveToCache(String jsonBuffer, Object... objects) {
		String fileName = getFileName();
		if (fileName != null) {
			FilePathManager.jsonToFile(jsonBuffer, fileName);
			SPManager.putString(ph_key_update_date, jsonBuffer);
		}
	}

	private void saveHighFreqSAToCache(String jsonBuffer) {
		// S/A 高频数据只通过独立文件恢复，当前没有 SP 读取方，避免额外写无用存储。
		FilePathManager.jsonToFile(jsonBuffer, HIGH_FREQ_SA_FILE_NAME);
	}

	@Override
	public void loadFromCache(Object... objects) {
		String fileName = getFileName();
		if (fileName != null) {
			reloadNormalUpdateCache();
		}
		// 普通缓存加载完成后，再加载 S/A 独立缓存并合入内存全集。
		// 顺序不能反过来，否则 reloadNormalUpdateCache 会清掉刚合入的 S/A 数据。
		loadHighFreqSAFromCache();

		//ignore update list
		try {
			List<UpdateItem> list = UpdateDatabase.getDatabase(PalmplayApplication.getAppInstance())
					.getIgnoreUpdateDao().getAllIgnoreUpdateApps();
			if (list != null && list.size() > 0) {
				mIgnoreUpdateItemList.clear();
				mIgnoreUpdateItemList.addAll(list);
			}
		} catch (Exception e) {
			if (BuildConfig.DEBUG) e.printStackTrace();
		}

	}

	private void loadHighFreqSAFromCache() {
		try {
			JsonObject jsonObject = (JsonObject) FilePathManager.fileToJson(HIGH_FREQ_SA_FILE_NAME);
			if (jsonObject == null) {
				return;
			}
			Gson gson = new Gson();
			AppsUpdateList appsUpdateList = gson.fromJson(jsonObject, AppsUpdateList.class);
			if (appsUpdateList == null || appsUpdateList.updateList == null) {
				return;
			}
			ensureHighFreqSAUpdateList();
			mHighFreqSAUpdateItemList.updateList.clear();
			boolean hasRemovedItem = false;
			for (ClientVersion.UpdateItem item : appsUpdateList.updateList) {
				// S/A 缓存是独立文件，可能跨进程/跨启动周期存在。
				// 加载时再校验本地版本，已更新完成的应用要从 S/A 缓存中剔除，避免页面和通知继续展示旧更新。
				if (!shouldKeepHighFreqSAItem(item)) {
					hasRemovedItem = true;
					continue;
				}
				int beforeSize = mHighFreqSAUpdateItemList.updateList.size();
				addOrReplaceHighFreqSAItem(item);
				if (mHighFreqSAUpdateItemList.updateList.size() == beforeSize) {
					hasRemovedItem = true;
				}
			}
			if (hasRemovedItem) {
				// 如果加载阶段发现本地已经更新过，立即把清理后的结果回写文件，
				// 避免下次启动又读到同一批已失效或重复的 S/A 数据。
				Gson cleanGson = new Gson();
				saveHighFreqSAToCache(cleanGson.toJson(mHighFreqSAUpdateItemList, AppsUpdateList.class));
			}
			mergeHighFreqSAToUpdateList();
		} catch (Exception e) {
			LogUtils.e(e);
		}
	}

	/**
	 * 只重建普通更新缓存对应的内存列表。
	 *
	 * 这个方法会清空 mAppsUpdateItemList 和 mSlientUpdateItemList，
	 * 所以调用方如果需要完整列表，必须在之后调用 mergeHighFreqSAToUpdateList() 合并 S/A 数据。
	 * 保存 S/A 追加数据时也会调用它，用来先移除内存中上一轮合入的 S/A，
	 * 再重新合入清理后的累计 S/A 集合。
	 */
	private void reloadNormalUpdateCache() {
		if (mSlientUpdateItemList != null && mSlientUpdateItemList.updateList != null) {
			mSlientUpdateItemList.updateList.clear();
		}
		if (mAppsUpdateItemList != null && mAppsUpdateItemList.updateList != null) {
			mAppsUpdateItemList.updateList.clear();
		}
		try {
			JsonObject jsonObject = (JsonObject) FilePathManager.fileToJson(getFileName());
			if (jsonObject == null) {
				return;
			}
			Gson gson = new Gson();
			AppsUpdateList appsUpdateList = gson.fromJson(jsonObject, AppsUpdateList.class);
			if (appsUpdateList == null || appsUpdateList.updateList == null) {
				return;
			}
			for (ClientVersion.UpdateItem item : appsUpdateList.updateList) {
				addNormalUpdateItemToMemory(item);
			}
		} catch (Exception e) {
			LogUtils.e(e);
		}
	}

	/**
	 * 把普通更新缓存中的单条数据放入内存列表。
	 *
	 * 普通缓存仍保持旧逻辑：静默更新数据进入 mSlientUpdateItemList，
	 * GameSpace/VA 插件不进入更新页相关列表，其它普通更新进入 mAppsUpdateItemList。
	 */
	private void addNormalUpdateItemToMemory(ClientVersion.UpdateItem item) {
		if (item == null || TextUtils.isEmpty(item.packageName)) {
			return;
		}
		if (item.updateWay == 1 && PalmplayApplication.mHasSlientPermission) {
			if (mSlientUpdateItemList != null && mSlientUpdateItemList.updateList != null) {
				mSlientUpdateItemList.updateList.add(item);
			}
			return;
		}
		if (VaStaticProxy.isInstantPluginApp(item.packageName)) {
			return;
		}
		addUpdateItemIfAbsent(item);
	}

	/**
	 * 判断 S/A 独立缓存中的单条数据是否仍然有效。
	 *
	 * S/A 数据可能来自上一次高频请求或上一次启动保存的文件，
	 * 所以除了过滤空包名、静默更新、VA 插件外，还要重新比较本地安装版本：
	 * 只有服务端版本仍然大于本地版本时，才继续保留这条 S/A 更新。
	 */
	private boolean shouldKeepHighFreqSAItem(ClientVersion.UpdateItem item) {
		if (item == null || TextUtils.isEmpty(item.packageName)) {
			return false;
		}
		if (item.updateWay == 1 && PalmplayApplication.mHasSlientPermission) {
			return false;
		}
		if (VaStaticProxy.isInstantPluginApp(item.packageName)) {
			return false;
		}
		Integer installVersion = InstalledAppManager.getInstance().getInstalledVersion(item.packageName);
		return installVersion == null || item.version > installVersion;
	}

	/**
	 * 将本次接口返回的 S/A 数据追加到本地累计缓存中。
	 *
	 * 同一个包名可能被后续请求再次返回，说明服务端给了更新后的元数据；
	 * 这里使用替换而不是跳过，保证名称、版本、图标、埋点等字段保持最新。
	 */
	private void addOrReplaceHighFreqSAItem(ClientVersion.UpdateItem item) {
		ensureHighFreqSAUpdateList();
		for (int i = 0; i < mHighFreqSAUpdateItemList.updateList.size(); i++) {
			ClientVersion.UpdateItem oldItem = mHighFreqSAUpdateItemList.updateList.get(i);
			if (oldItem != null && TextUtils.equals(oldItem.packageName, item.packageName)) {
				mHighFreqSAUpdateItemList.updateList.set(i, item);
				return;
			}
		}
		mHighFreqSAUpdateItemList.updateList.add(item);
	}

	/**
	 * 将 S/A 独立缓存合并到对外使用的更新列表中。
	 *
	 * mHighFreqSAUpdateItemList 只表示高频请求独立文件中的数据；
	 * mAppsUpdateItemList 才是其它业务读取的全集，因此这里按 packageName 去重合并。
	 */
	private void mergeHighFreqSAToUpdateList() {
		if (mHighFreqSAUpdateItemList == null || mHighFreqSAUpdateItemList.updateList == null) {
			return;
		}
		for (ClientVersion.UpdateItem item : mHighFreqSAUpdateItemList.updateList) {
			addUpdateItemIfAbsent(item);
		}
	}

	/**
	 * 按 packageName 去重添加更新项。
	 *
	 * 普通缓存和 S/A 缓存可能返回同一个包，这里保留已经在列表中的旧项，
	 * 避免更新页、角标、通知等业务看到重复应用。
	 */
	private void addUpdateItemIfAbsent(ClientVersion.UpdateItem item) {
		if (item == null || TextUtils.isEmpty(item.packageName)) {
			return;
		}
		if (mAppsUpdateItemList == null) {
			mAppsUpdateItemList = new AppsUpdateList();
		}
		if (mAppsUpdateItemList.updateList == null) {
			mAppsUpdateItemList.updateList = new ArrayList<>();
		}
		for (ClientVersion.UpdateItem updateItem : mAppsUpdateItemList.updateList) {
			if (updateItem != null && TextUtils.equals(updateItem.packageName, item.packageName)) {
				return;
			}
		}
		mAppsUpdateItemList.updateList.add(item);
	}

	/**
	 * 兜底保证 S/A 内存容器可用。
	 *
	 * 正常情况下 AppsUpdateList 构造方法会初始化 updateList，
	 * 这里额外保护是为了避免后续反序列化或字段调整导致空指针。
	 */
	private void ensureHighFreqSAUpdateList() {
		if (mHighFreqSAUpdateItemList == null) {
			mHighFreqSAUpdateItemList = new AppsUpdateList();
		}
		if (mHighFreqSAUpdateItemList.updateList == null) {
			mHighFreqSAUpdateItemList.updateList = new ArrayList<>();
		}
	}

	/**
	 * App支持静默更新列表信息
	 * @return
	 */
	public AppsUpdateList getSlientUpdateItemList() {
		return mSlientUpdateItemList;
	}

	/**
	 * 仅支持普通更新的列表信息
	 * @return
	 */
	public AppsUpdateList getUpdateItemList() {
		return mAppsUpdateItemList;
	}

	public boolean deleteUpdateItem(String packageName) {
		boolean reslut = false;
		if (!TextUtils.isEmpty(packageName) && mAppsUpdateItemList != null && mAppsUpdateItemList.updateList != null && mAppsUpdateItemList.updateList.size() > 0) {
			Iterator<UpdateItem> iterator = mAppsUpdateItemList.updateList.iterator();
			UpdateItem mUpdateItem;
			while (iterator.hasNext()) {
				mUpdateItem = iterator.next();
				if (mUpdateItem != null && packageName.equals(mUpdateItem.packageName)) {
					reslut = true;
					iterator.remove();
					break;
				}
			}
		}

		return reslut;
	}

	public boolean remove(String packageName){
		boolean b = false;
		if(!TextUtils.isEmpty(packageName) && mAppsUpdateItemList!=null && mAppsUpdateItemList.updateList!=null && mAppsUpdateItemList.updateList.size() > 0){
			for(UpdateItem mUpdateItem : mAppsUpdateItemList.updateList){
				if(mUpdateItem!=null && packageName.equals(mUpdateItem.packageName)){
					b = true;
					removedAppList.add(mUpdateItem);
					break;
				}
			}
		}

		if(b) {
			EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
			eventMainThreadEntity.setAction(Constant.ACTION_UNINSTALL_APK_REFRESH);
			EventBus.getDefault().post(eventMainThreadEntity);
		}

		return b;
	}

	public boolean removeVaGame(String packageName) {
		boolean b = false;
		if (!TextUtils.isEmpty(packageName) && mAppsUpdateItemList != null && mAppsUpdateItemList.updateList != null && mAppsUpdateItemList.updateList.size() > 0) {
			Iterator<UpdateItem> iterator = mAppsUpdateItemList.updateList.iterator();
			UpdateItem mUpdateItem;
			while (iterator != null && iterator.hasNext()) {
				mUpdateItem = iterator.next();
				if (mUpdateItem != null && packageName.equals(mUpdateItem.packageName)) {
					b = true;
					iterator.remove();
					break;
				}
			}
		}
		if (b) {
			EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
			eventMainThreadEntity.setAction(Constant.ACTION_UNINSTALL_APK_REFRESH);
			EventBus.getDefault().post(eventMainThreadEntity);

			if (!TextUtils.isEmpty(packageName)) {
				PalmstoreSysHandler.startService(PalmplayApplication.getAppInstance(), PalmstoreSysHandler.ACTION_NOTIFICATION_CHECK_APP_UPDATE, "ManagerUp", "removeVaG");
				EventMainThreadEntity eventMainThreadEntity1 = new EventMainThreadEntity();
				eventMainThreadEntity1.setAction(PalmstoreService.ACTION_NOTIFICATION_UPDATE_COUNT);
				EventBus.getDefault().post(eventMainThreadEntity1);
			}
		}

		return b;
	}
	/**
	 * 增加一个更新项
	 * */
	public void addUpdateItem(UpdateItem src) {
		if (src == null || TextUtils.isEmpty(src.packageName)) {
			return;
		}

		if (mAppsUpdateItemList == null) {
			return;
		}

		if (mAppsUpdateItemList.updateList == null) {
			mAppsUpdateItemList.updateList = new ArrayList<>();
		}

		Iterator<UpdateItem> it = mAppsUpdateItemList.updateList.iterator();
		while (it.hasNext()) {
			UpdateItem item = it.next();
			if (TextUtils.equals(item.packageName, src.packageName)) {
				it.remove();
				break;
			}
		}

		mAppsUpdateItemList.updateList.add(src);

		try {
			Gson gson = new Gson();
			String msgbuffer = gson.toJson(mAppsUpdateItemList, AppsUpdateList.class);
			saveToCache(msgbuffer);
		}catch(Exception e) {
		    if (BuildConfig.DEBUG) e.printStackTrace();
		}
	}

	/**
	 * 指定包名的应用是否属于待更新应用，该方法适用于包安装成功时候判断
	 * @param packageName
	 * @return
	 */
	public boolean isUpdateApp(String packageName){
		if(TextUtils.isEmpty(packageName)){
			return false;
		}
		if(removedAppList == null || removedAppList.size() <= 0) {
			return false;
		}
		for(UpdateItem item : removedAppList){
			if(packageName.equals(item.packageName)){
				return true;
			}
		}
		return false;
	}

	/**
	 * 指定包名的应用是否是待更新应用，该方法适用于应用安装成功之前判断
	 * @param packageName
	 * @return
	 */
	public boolean needUpdate(String packageName){
		if(TextUtils.isEmpty(packageName)){
			return false;
		}
		if(mAppsUpdateItemList == null || mAppsUpdateItemList.updateList == null || mAppsUpdateItemList.updateList.size() == 0){
			return false;
		}
		for(UpdateItem item : mAppsUpdateItemList.updateList){
			if(packageName.equals(item.packageName)){
				return true;
			}
		}
		return false;
	}


	/**
	 * measure page size
	 * @param listSize
	 * @param maxPage
	 * @param defPageSize
	 * @return
	 */
	public static int getMeasuredPageSize(int listSize, int maxPage, int defPageSize){
		int pageSize = defPageSize;
		int pageSum = getMeasuredPageSum(listSize, pageSize);
		while (pageSum > maxPage) {
			if(pageSize > 1){
				pageSize = pageSize + pageSize/2;
			} else {
				pageSize = pageSize + 1;
			}

			pageSum = getMeasuredPageSum(listSize, pageSize);
		}

		return pageSize;

	}


	/**
	 * measure page sum
	 * @param listSize
	 * @return
	 */
	public static int getMeasuredPageSum(int listSize, int pageSize){
		int pageSum = 0;
		if(listSize > pageSize){
			pageSum = listSize / pageSize;
			if((listSize % pageSize) !=0){
				pageSum = pageSum + 1;
			}
		}

		return pageSum;
	}

	/**
	 * 更新静默下载成功的数据
	 * @param updateItem
	 */
	public void updateSlientDataBase(UpdateItem updateItem, int downLoadStatus) {
		String fileName = getFileName();
		AppsUpdateList appsUpdateList;
		boolean canUpdate = false;
		JsonElement jsonElement = FilePathManager.fileToJson(fileName);
		if(jsonElement == null) {
			return;
		}
		JsonObject jsonObject = (JsonObject)jsonElement;
		if (jsonObject != null) {
			Gson gson = new Gson();
			appsUpdateList = gson.fromJson(jsonObject, AppsUpdateList.class);
			for(UpdateItem item:appsUpdateList.updateList){
				if(TextUtils.equals(updateItem.packageName,item.packageName)) {
					item.observerStatus = downLoadStatus;
					item.downloadUrl = updateItem.downloadUrl;
					item.downloadID = updateItem.downloadID;
					item.version = updateItem.version;
					item.versionName = updateItem.versionName;
					item.isSubPackage = updateItem.isSubPackage;
					item.size = updateItem.size;
					item.diffSize = updateItem.diffSize;
					item.downloadTypeBean = updateItem.downloadTypeBean;
					canUpdate = true;
					break;
				}
			}
			if(canUpdate) {
				String msgbuffer = gson.toJson(appsUpdateList, AppsUpdateList.class);
				saveToCache(msgbuffer);
			}
		}
	}

	/**
	 * 忽略一个更新项(忽略更新)
	 * */
	public void addIgnoreUpdateItem(UpdateItem src) {

		if (src == null || TextUtils.isEmpty(src.packageName)) {
			return;
		}

		if (mIgnoreUpdateItemList == null) {
			return;
		}
		Iterator<UpdateItem> it = mIgnoreUpdateItemList.iterator();
		while (it.hasNext()) {
			UpdateItem item = it.next();
			if (TextUtils.equals(item.packageName, src.packageName)) {
				it.remove();
				break;
			}
		}

		src.isExpandInAdapter = false;
		src.hasTrack = false;
		mIgnoreUpdateItemList.add(src);

		try {
			UpdateDatabase.getDatabase(PalmplayApplication.getAppInstance())
					.getIgnoreUpdateDao().saveIgnoreUpdateAppInfoList(mIgnoreUpdateItemList);
		} catch (Exception e) {
			if (BuildConfig.DEBUG) e.printStackTrace();
		}
	}

	/**
	 * 删除一个忽略更新项(恢复忽略更新)
	 * */
	public void restoreIgnoreUpdateItem(UpdateItem src) {
		if (src == null || TextUtils.isEmpty(src.packageName)) {
			return;
		}
		if (mIgnoreUpdateItemList == null || mIgnoreUpdateItemList.size() <= 0) {
			return;
		}
		Iterator<UpdateItem> it = mIgnoreUpdateItemList.iterator();
		while (it.hasNext()) {
			UpdateItem item = it.next();
			if (TextUtils.equals(item.packageName, src.packageName)) {
				it.remove();
				break;
			}
		}

		try {
			UpdateDatabase.getDatabase(PalmplayApplication.getAppInstance())
					.getIgnoreUpdateDao().deleteFixedItem(src.packageName);
		} catch (Exception e) {
			if (BuildConfig.DEBUG) e.printStackTrace();
		}
	}

	public List<UpdateItem> getIgnoreUpdateList() {

		List<UpdateItem> list = new ArrayList<>();

		if (mIgnoreUpdateItemList != null) {
			list.clear();
			list.addAll(mIgnoreUpdateItemList);
		}

		return list;
	}
}

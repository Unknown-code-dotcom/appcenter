package com.afmobi.palmplay.appmanage.v2.holder

import android.annotation.SuppressLint
import android.text.TextUtils
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.appmanage.v2.adapter.EventCombine
import com.afmobi.palmplay.appmanage.v2.model.MIN_CLICK_DURATION
import com.afmobi.palmplay.cache.ConfigManager
import com.afmobi.palmplay.download.DownloadStatusManager
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.va.proxy.VaStaticProxy
import com.afmobi.util.CommonUtils
import com.afmobi.util.FileUtils
import com.afmobi.util.TRNoDoubleClickListener
import com.transsion.palmstorecore.glide.GlideUtils
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.store.BuildConfig
import com.transsnet.store.R
import com.transsnet.store.databinding.LayoutManageDownloadItemV2Binding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * 下载项ViewHolder
 */
class DownloadItemViewHolder(
    private val binding: LayoutManageDownloadItemV2Binding,
    private val event: EventCombine,
    private val viewHolderScope: CoroutineScope
) : RecyclerView.ViewHolder(binding.root) {

    // 新增 Job 变量，用于管理协程任务
    private var statusCollectJob: Job? = null

    fun bind(downloadInfo: FileDownloadInfo) {
        // 绑定基本信息
        binding.tvName.text = downloadInfo.name
        binding.tvVersion.text = if (TextUtils.isEmpty(downloadInfo.versionName))
            ""
        else
            CommonUtils.replace(
                binding.root.context.getString(R.string.versionname_prefix),
                CommonUtils.TARGET_NAME,
                downloadInfo.versionName
            )
        binding.tvSize.text = FileUtils.getSizeName(downloadInfo.sourceSize)

        if (ConfigManager.getDownloadManagerDeleIsExpand()) {
            binding.ibDropdown.setImageResource(R.drawable.ic_close_grey_pressed)
        } else {
            binding.ibDropdown.setImageResource(R.drawable.selector_drop_down_bg)
            binding.ibDropdown.setSelected(downloadInfo.isExpand)
            binding.ibDelete.visibility = if (downloadInfo.isExpand) View.VISIBLE else View.GONE
        }

        // 设置点击事件
        setupClickListeners(downloadInfo)

        // 绑定图标
        bindIcon(downloadInfo)

        // 绑定下载状态
        bindDownloadStatus(downloadInfo)

        // 先取消上一次的监听任务，防止 item 复用导致重复监听
        statusCollectJob?.cancel()
        // 启动新协程来监听当前 item 的状态更新
        val pkg = downloadInfo.packageName
        if (!pkg.isNullOrEmpty()) {
            val itemView = binding.root
            // 确保 View 已 attach 才能获取 ViewTreeLifecycleOwner
            if (itemView.isAttachedToWindow) {
                startStatusCollection(itemView, pkg)
            } else {
                itemView.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                    override fun onViewAttachedToWindow(v: View) {
                        v.removeOnAttachStateChangeListener(this)
                        startStatusCollection(v, pkg)
                    }
                    override fun onViewDetachedFromWindow(v: View) {
                        // 可选：当 View 从窗口移除时，如果业务需要也可以在此取消任务
                        // statusCollectJob?.cancel()
                    }
                })
            }
        }
    }

    private fun startStatusCollection(view: View, pkg: String) {
        val lifecycleOwner = view.findViewTreeLifecycleOwner()
        if (lifecycleOwner != null) {
            statusCollectJob = viewHolderScope.launch {
                // 核心：只在 RESUMED 状态下执行 collect
                lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                    try {
                        val stateFlow = event.itemStatusFlow?.invoke(pkg)
                        stateFlow?.collect { downloadStatus ->
                            downloadStatus.downloadInfo ?: return@collect
                            if (BuildConfig.DEBUG) {
                                LogUtils.d("DownloadRepo", "itemStatusFlow collect")
                            }
                            // 更新下载状态
                            bindDownloadStatus(downloadStatus.downloadInfo)
                            // 更新下载速度
                            if (downloadStatus.downloadInfo.downloadStatus == FileDownloadInfo.STATUS_DOWNING) {
                                updateViewHolderProgressBar(
                                    downloadStatus.downloadInfo,
                                    downloadStatus.speed
                                )
                            }
                        }
                    } catch (e: Exception) {
                        if (BuildConfig.DEBUG) {
                            LogUtils.e("DownloadRepo", "itemStatusFlow collect error$e")
                        }
                    }
                }
            }
        } else {
            // 如果获取不到 LifecycleOwner (极少情况)，降级处理或记录日志
            if (BuildConfig.DEBUG) {
                LogUtils.e("DownloadRepo", "view.findViewTreeLifecycleOwner null")
            }
        }
    }

    private fun showLayoutDownloadInfo() {
        binding.tvProgress.visibility = View.VISIBLE
        binding.tvSpeed.visibility = View.VISIBLE
    }

    private fun hideLayoutDownloadInfo() {
        binding.tvProgress.visibility = View.GONE
        binding.tvSpeed.visibility = View.GONE
    }


    fun bindWithPayload(downloadInfo: FileDownloadInfo, changes: List<String>?) {
        LogUtils.d("DownloadRepo", "DownloadItemViewHolder bindWithPayload")
        changes?.forEach { change ->
            when (change) {
                "downloadStatus" -> bindDownloadStatus(downloadInfo)
                "icon" -> bindIcon(downloadInfo)
            }
        }
    }

    fun onRecycled() {
        LogUtils.d("DownloadRepo", "onRecycled")
        // item 被回收时，务必取消任务
        statusCollectJob?.cancel()
    }

    private fun bindIcon(downloadInfo: FileDownloadInfo) {
        val defaultIcon: Int = R.drawable.layer_list_app_default_01_bg
        GlideUtils.setImageUrl(
            binding.ivIcon,
            downloadInfo.iconUrl,
            defaultIcon
        )
    }

    private fun bindDownloadStatus(downloadInfo: FileDownloadInfo) {
        val observerStatus = DownloadStatusManager.getInstance()
            .getObserverStatus(downloadInfo, downloadInfo.downloadStatus)
        CommonUtils.checkDownloadingItemDisplay(
            downloadInfo,
            observerStatus,
            binding.tvSpeed,
            binding.tvProgress
        )

        CommonUtils.checkStatusItemDisplay(
            downloadInfo,
            observerStatus,
            binding.btnOperation,
            null,
            null,
            false,
            downloadInfo.packageName,
            downloadInfo.itemID
        )
        val context = binding.root.context
        if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isSpaceLimit) {
            binding.tvName.setTextColor(
                context.resources.getColor(R.color.download_manage_title)
            )
            binding.tvProgress.setTextColor(
                context.resources.getColor(R.color.download_manage_desc)
            )
            binding.tvSpeed.setTextColor(
                context.resources.getColor(R.color.download_manage_desc)
            )
            hideLayoutDownloadInfo()
            binding.layoutDownloaded.visibility = View.GONE
            binding.tvInstallFail.visibility = View.GONE
            binding.tvSpaceLimit.visibility = View.VISIBLE
            val dstStr: String? = context.getString(R.string.disk_space_not_enough_tips_title)
            binding.tvSpaceLimit.text = dstStr
            val drawable = ContextCompat.getDrawable(
                context,
                R.drawable.ic_clean_warn
            )
            binding.tvSpaceLimit.setCompoundDrawablesRelative(drawable, null, null, null)
        } else if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_PAUSE && downloadInfo.isWaitingWifi) {
            binding.tvName.setTextColor(
                context.resources.getColor(R.color.download_manage_title)
            )
            binding.tvProgress.setTextColor(
                context.resources.getColor(R.color.download_manage_desc)
            )
            binding.tvSpeed.setTextColor(
                context.resources.getColor(R.color.download_manage_desc)
            )
            hideLayoutDownloadInfo()
            binding.layoutDownloaded.visibility = View.GONE
            binding.tvInstallFail.visibility = View.GONE
            binding.tvSpaceLimit.visibility = View.VISIBLE
            val dstStr: String? = context.getString(R.string.txt_waiting_wifi)
            binding.tvSpaceLimit.text = dstStr //复用空间不足的view展示Waiting for Wi-Fi提示
            binding.tvSpaceLimit.setCompoundDrawablesRelative(null, null, null, null)
        } else if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_DOWNLOADED) {
            hideLayoutDownloadInfo()
            if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isInstallFail && !downloadInfo.extraInfo.isRetryInstallFail) {
                binding.layoutDownloaded.visibility = View.GONE
                binding.tvSpaceLimit.visibility = View.GONE
                binding.tvInstallFail.visibility = View.VISIBLE
                val err = CommonUtils.getInstallFailMsg(downloadInfo.extraInfo.installErrorCode)
                binding.tvInstallFail.text = err
                binding.btnOperation.setText(R.string.text_retry)
            } else {
                binding.layoutDownloaded.visibility = View.VISIBLE
                binding.tvSpaceLimit.visibility = View.GONE
                binding.tvInstallFail.visibility = View.GONE
            }
        } else {
            binding.tvName.setTextColor(
                context.resources.getColor(R.color.download_manage_title)
            )
            binding.tvProgress.setTextColor(
                context.resources.getColor(R.color.download_manage_desc)
            )
            binding.tvSpeed.setTextColor(
                context.resources.getColor(R.color.download_manage_desc)
            )
            showLayoutDownloadInfo()
            binding.layoutDownloaded.visibility = View.GONE
            binding.tvSpaceLimit.visibility = View.GONE
            binding.tvInstallFail.visibility = View.GONE
        }


        binding.btnOperation.setEnabled(true)
    }

    @SuppressLint("SetTextI18n")
    fun updateViewHolderProgressBar(downloadInfo: FileDownloadInfo, speed: Int) {
        val sizeStr =
            FileUtils.getSizeName(downloadInfo.downloadedSize) + "/" + FileUtils.getSizeName(
                downloadInfo.sourceSize
            )
        binding.tvProgress.text = sizeStr
        if (speed >= 0) {
            binding.tvSpeed.text = FileUtils.getFileSizeMapUnit(speed.toLong(), false) + "/S"
        }
        CommonUtils.updateViewHolderProgressBar(downloadInfo, binding.btnOperation, null, null)
    }

    private fun setupClickListeners(downloadInfo: FileDownloadInfo) {
        // 整个item点击
        binding.clItem.setOnClickListener(
            object : TRNoDoubleClickListener(MIN_CLICK_DURATION) {
                override fun onNoDoubleClick(v: View?) {
                    // 屏蔽PalmSpace插件的点击
                    if (VaStaticProxy.isInstantPluginApp(downloadInfo.packageName)) {
                        return
                    }
                    LogUtils.d("DownloadRepo", "item OnClick$layoutPosition")
                    event.onDownloadItemClick?.invoke(downloadInfo, false, layoutPosition)
                }
            }
        )
        // 下载状态按钮
        binding.btnOperation.setOnClickListener(
            object : TRNoDoubleClickListener(MIN_CLICK_DURATION) {
                override fun onNoDoubleClick(v: View?) {
                    LogUtils.d("DownloadRepo", "btnOperation OnClick")
                    if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_DOWNLOADED) {
                        if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isInstallFail && !downloadInfo.extraInfo.isRetryInstallFail) {
                            event.onDownloadItemClick?.invoke(downloadInfo, false, layoutPosition)
                            return
                        }
                    }
                    event.onStateBtnClick?.invoke(downloadInfo, layoutPosition)
                }
            }
        )
        // 删除按钮
        binding.ibDelete.setOnClickListener(
            object : TRNoDoubleClickListener(MIN_CLICK_DURATION) {
                override fun onNoDoubleClick(v: View?) {
                    LogUtils.d("DownloadRepo", "ibDelete OnClick")
                    event.onDownloadItemDelete?.invoke(downloadInfo, layoutPosition)
                }
            }
        )
        // 隐藏菜单
        binding.ibDropdown.setOnClickListener(
            object : TRNoDoubleClickListener(MIN_CLICK_DURATION) {
                override fun onNoDoubleClick(v: View?) {
                    LogUtils.d("DownloadRepo", "ibDropdown OnClick")
//                    onEmptyViewClick?.invoke()
                    if (ConfigManager.getDownloadManagerDeleIsExpand()) {
                        event.onDownloadItemDelete?.invoke(downloadInfo, layoutPosition)
                    } else {
                        val state = binding.ibDropdown.isSelected
                        binding.ibDropdown.setSelected(!state)
                        binding.ibDelete.visibility = if (state) View.GONE else View.VISIBLE
                        downloadInfo.setExpandFlag(!state)
                        event.onItemDropDown?.invoke(downloadInfo, layoutPosition)
                    }
                }
            }
        )
    }

}
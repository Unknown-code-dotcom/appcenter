package com.afmobi.palmplay.cache

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.util.LruCache
import com.transsion.palmstorecore.log.LogUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ApkIconLoader {

    private const val TAG = "ApkIconLoader"
    const val MAX_SIZE = 16

    private val apkIconCache: LruCache<String, Drawable> by lazy {
        object : LruCache<String, Drawable>(MAX_SIZE) {
            override fun sizeOf(key: String, drawable: Drawable): Int {
                return 1
            }
        }
    }

    /**
     * 从 APK 文件中异步获取图标，并使用 LRU 缓存。
     * 此方法应在协程中调用。
     *
     * @param context 上下文 (建议使用 ApplicationContext 以避免内存泄漏)
     * @param apkPath APK 文件路径
     * @return APK 的图标，如果获取失败则返回 null
     */
    suspend fun getApkIconAsync(context: Context, apkPath: String?): Drawable? =
        withContext(Dispatchers.IO) {
            return@withContext getApkIcon(context, apkPath)
        }

    /**
     * 从 APK 文件中获取图标，并使用 LRU 缓存。
     *
     * @param context 上下文 (建议使用 ApplicationContext 以避免内存泄漏)
     * @param apkPath APK 文件路径
     * @return APK 的图标，如果获取失败则返回 null
     */
    private fun getApkIcon(context: Context, apkPath: String?): Drawable? {
        if (apkPath.isNullOrBlank()) {
            return null
        }

        // 1. 尝试从缓存中获取
        val cachedIcon = apkIconCache.get(apkPath)
        if (cachedIcon != null) {
            LogUtils.d(TAG, "Icon loaded from cache for: $apkPath")
            return cachedIcon
        }

        // 2. 缓存中没有，则从 APK 文件中加载
        val pm = context.packageManager
        try {
            val info = pm.getPackageArchiveInfo(apkPath, PackageManager.GET_ACTIVITIES)

            if (info != null && info.applicationInfo != null) {
                val appInfo = info.applicationInfo!!
                appInfo.sourceDir = apkPath
                appInfo.publicSourceDir = apkPath

                val icon = appInfo.loadIcon(pm)
                if (icon != null) {
                    // 3. 加载成功，存入缓存
                    apkIconCache.put(apkPath, icon)
                    LogUtils.d(TAG, "Icon loaded from APK and cached for: $apkPath")
                }
                return icon
            } else {
                LogUtils.w(TAG, "Could not get PackageInfo for APK: $apkPath")
            }
        } catch (e: OutOfMemoryError) {
            LogUtils.e(
                TAG,
                "OutOfMemoryError while loading icon for $apkPath: ${e.message}"
            )
            // 可以在这里考虑清空部分缓存或进行其他内存回收操作
        } catch (e: Exception) {
            LogUtils.e(TAG, "Error loading icon for $apkPath: ${e.message}")
        }
        return null
    }

    fun clearCache() {
        apkIconCache.evictAll()
        LogUtils.d(TAG, "ApkIconLoader cache cleared.")
    }
}
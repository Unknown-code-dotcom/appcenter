package com.afmobi.palmplay.appmanage;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.StrikethroughSpan;
import android.util.Pair;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.appmanage.adapter.AsyncGetInstalledPackageListTask;
import com.afmobi.palmplay.appmanage.adapter.DownloadNoResAdapter;
import com.afmobi.palmplay.appmanage.adapter.ManageIgnoreUpdateAdapter;
import com.afmobi.palmplay.appmanage.adapter.ManagerUpdateAdapter;
import com.afmobi.palmplay.base.BaseEventFragmentActivity;
import com.afmobi.palmplay.cache.ConfigManager;
import com.afmobi.palmplay.cache.InstalledAppsUpdateCache;
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache;
import com.afmobi.palmplay.configs.HttpRequestTracer;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.customview.FilterPopupWindow;
import com.afmobi.palmplay.customview.PsFloatBallView;
import com.afmobi.palmplay.customview.PsFloatBallViewKit;
import com.afmobi.palmplay.dialog.CustomDialog;
import com.afmobi.palmplay.dialog.DialogBuilder;
import com.afmobi.palmplay.download.ObbFormatDataManager;
import com.afmobi.palmplay.home.MainActivity;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.home.model.FeatureItemData;
import com.afmobi.palmplay.main.PermissionsReqActivity;
import com.afmobi.palmplay.main.utils.NotificationExtKt;
import com.afmobi.palmplay.manager.AtyManager;
import com.afmobi.palmplay.manager.HttpRequestTracerManager;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.PalmPlayNetworkDownloadStateManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.manager.TRLinearLayoutManager;
import com.afmobi.palmplay.manager.UpdateControlManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_3.FeaturedModel;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.network.NetworkActions;
import com.afmobi.palmplay.permissions.PermissonsHintDialog;
import com.afmobi.palmplay.setting.IndividualCenterUpdateManageUtils;
import com.afmobi.palmplay.setting.WifiOnlyTipsActivity;
import com.afmobi.palmplay.viewmodel.UpdateViewModel;
import com.afmobi.palmplay.viewmodel.filedownload.AppUpdateViewModel;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.FileUtils;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NotificationUtil;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.TRNoDoubleClickListener;
import com.afmobi.util.TRPermissionUtil;
import com.afmobi.util.eventbus.IAction;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil;
import com.didi.drouter.annotation.Router;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.PagePvBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.MMKVUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.afmobi.palmplay.PalmplayApplication.getAppInstance;

import org.json.JSONObject;

/**
 * 管理更新页面
 */
@Router(path = "/page/manageUpdate")
public class ManageUpdateActivity extends BaseEventFragmentActivity {

    public static final String KEY_UPDATE_ALL = "key_update_all";
    public static final String KEY_APP_SORT = "key_app_sort"; // 用于外部跳转设置筛选类型
    private final int ATIVITY_REQUESTCODE_PERMISSIONS = 21;
    public static final String MODEL_UNVAILABLE = "UA";

    public static final String ALL_SORT_STR = "All Apps";
    public static final String SYSTEM_SORT_STR = "System Apps";
    public static final String OTHER_SORT_STR = "Other Apps";

    private RecyclerView mRecyclerView;
    private RelativeLayout layout_bottom;
    private Button btn_update_all;
    private ManagerUpdateAdapter mManagerUpdateAdapter;

    private TrHomeRecyclerViewAdapter mHomeRecyclerViewAdapter;
    private RecyclerView mRecomRecyclerView;
    private UpdateViewModel mUpdateViewModel;

    private AppUpdateViewModel mAppUpdateViewModel;

    protected List<String> mAlreadyAdList = new ArrayList<String>();  //记录已经展示过的广告包名

    private View mEmptyView;
    private TextView mUpdateTitle;
    private boolean hasInited;

    /**
     * 是否需要执行 更新所有 操作；true，需要；
     */
    private boolean needUpdateAll;

    private String mFrom = "";
    private String mValue = "";
    private String fromSite = "";
    private View layout_autoupdate;
    private TextView btn_autoupdate_ok;
    private TextView mTitleTextView;
    private RecyclerView ignore_list;
    private ManageIgnoreUpdateAdapter mIgnoreAdapter;
    private ImageButton v_toggle;
    private View layout_ignore;
    private TextView tv_ignore;
    private View layout_ignore_title;
    private boolean isIgnoreExpand = false;
    private boolean backFloatball;
    private String packageName;

    LinearLayout llUnavailable;

    LinearLayout llUnavailableList;
    RecyclerView rvUnavailable;

    TextView tvUnavailable;

    TextView tvCollapse;

    TextView tvUnavailableStart;

    TextView tvClearAll;
    private boolean isFromStartup;

    DownloadNoResAdapter downloadNoResAdapter;
    private DownloadNoResAdapter.OnItemDeleteListener onItemDeleteListener;


    @Override
    protected void onCreate(Bundle onSaveInstanceState) {
        super.onCreate(onSaveInstanceState);
        setContentView(R.layout.activity_manage_update);

        mUpdateViewModel = ViewModelProviders.of(this, PalmplayApplication.getAppInstance().getViewModelProviderFactory()).get(UpdateViewModel.class);
        getLifecycle().addObserver(mUpdateViewModel);

        mAppUpdateViewModel = ViewModelProviders.of(this).get(AppUpdateViewModel.class);
        mAppUpdateViewModel.getCurrentAppSort().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer sort) {
                // sort 可能为 null (首次未设置时)
                if (sort != null && mManagerUpdateAdapter != null) {
                    mManagerUpdateAdapter.setCurrentAppSort(sort);
                    updateFilteredSizes();
                    setState();
                }
            }
        });

        Intent intent = getIntent();
        mPageParamInfo.resetPageParamInfo(intent);
        mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE);
        mPageParamInfo.setCurPage(PageConstants.Update);
        needUpdateAll = intent.getBooleanExtra(KEY_UPDATE_ALL, false);
        fromSite = intent.getStringExtra(TRAnalyticsConstant.FROM_SITE);
        backFloatball = "true".equalsIgnoreCase(intent.getStringExtra("backFloatball"));
        packageName = intent.getStringExtra("packageName");
        isFromStartup = intent.getBooleanExtra(TRJumpUtil.ISFROM_STARTUP, false);

        // 确定当前筛选类型 - 优先使用 ViewModel 中保存的值,否则从 Intent 获取
        int currentAppSort;
        if (mAppUpdateViewModel != null && mAppUpdateViewModel.getCurrentAppSort().getValue() != null) {
            // 配置变更(如日夜间切换)时,使用 ViewModel 中保存的值
            currentAppSort = mAppUpdateViewModel.getCurrentAppSort().getValue();
        } else {
            // 首次启动时,从 Intent 获取初始值
            currentAppSort = intent.getIntExtra(KEY_APP_SORT, ManagerUpdateAdapter.ALL_SORT);
            // 设置到 ViewModel 以便后续使用和配置变更时保持
            if (mAppUpdateViewModel != null) {
                mAppUpdateViewModel.setAppSort(currentAppSort);
            }
        }

        mTitleTextView = findViewById(R.id.layout_title_content);
        mTitleTextView.setText(getString(R.string.text_update));

        if (isFromNotify) {
            PalmplayApplication.getPalmplayApplicationInstance().appInit();
        }
        initViews();

        // 恢复折叠按钮曝光标志和折叠状态
        if (onSaveInstanceState != null && mManagerUpdateAdapter != null) {
            boolean hasFoldTracked = onSaveInstanceState.getBoolean("hasFoldButtonTrackedExposure", false);
            mManagerUpdateAdapter.setFoldButtonTrackedExposure(hasFoldTracked);

            boolean isFolded = onSaveInstanceState.getBoolean("isFolded", true);
            mManagerUpdateAdapter.setFolded(isFolded);
        }
        mValue = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, "", "", "");

        PagePvBuilder pagePvBuilder = new PagePvBuilder();
        pagePvBuilder.setValue(mValue)
                .setFrom(mFrom)
                .setFromSite(fromSite)
                .setExtras(getPVExtraValue(currentAppSort)); // 传入确定的 currentAppSort 值
        TRAnalysticsUtil.trackPV(pagePvBuilder);
    }

    private String getPVExtraValue(int currentAppSort) {
        String txt = "";
        try {
            JSONObject obj = new JSONObject();
            obj.put("s_item", getCurrentFilterText(currentAppSort));

            txt = obj.toString();
        } catch (Exception e) {
            if (BuildConfig.DEBUG)  e.printStackTrace();
        }

        return txt;
    }

    private void initViews() {
        try {
            findViewById(R.id.layout_title_back).setOnClickListener(
                    new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            if (!checkOnBackPressed()) {
                                finish();
                            }
                        }
                    });

        } catch (Exception e) {
            LogUtils.e(e);
        }
        findViewById(R.id.layout_common_title).setBackgroundColor(ContextCompat.getColor(this, DisplayUtil.getBackgroundColorId()));

        //ImageView ivSearch = findViewById(R.id.tv_search);
        TextView tvSearch = findViewById(R.id.tv_search);
        tvSearch.setVisibility(View.VISIBLE);
        tvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TRJumpUtil.switchToSearchActivity(ManageUpdateActivity.this, TabType.SOFT, "", false, "", false, "",
                        mPageParamInfo, mValue, TRAnalyticsConstant.BUTTON_SEARCH_IMG, mFrom);
            }
        });

        if (InstalledAppManager.getInstance().isNotInitialized()) {
            HttpRequestTracer mHttpRequestTracer = HttpRequestTracerManager.getInstance().get(IAction.Action_GetInstalledPackageList_task);
            if (mHttpRequestTracer == null || !mHttpRequestTracer.isRequesting()) {
                AsyncGetInstalledPackageListTask.excuteDef(new AsyncGetInstalledPackageListTask.AsyncGetInstalledPackageListTaskListener() {

                    @Override
                    public void onPreExecute() {

                    }

                    @Override
                    public void onPostExecute(Map<String, InstalledAppInfo> map) {
                        if (mManagerUpdateAdapter != null)
                            mManagerUpdateAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public Map<String, InstalledAppInfo> doInBackground(
                            Map<String, InstalledAppInfo> map) {
                        return map;
                    }
                });
            }
        }

        // title显示update数量
        mUpdateTitle = findViewById(R.id.tv_update_task_title);
        // 添加点击事件，显示筛选菜单
        mUpdateTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击埋点
                String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, "", "", "");
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setButtonType("Option");
                TRAnalysticsUtil.trackClick(builder);

                showFilterPopupMenu(v);
            }
        });

        mEmptyView = findViewById(R.id.layout_empty_view_root);
        //mEmptyView.findViewById(R.id.iv_image).setBackgroundResource(R.drawable.img_download_manager_no_task);
        ((TextView) mEmptyView.findViewById(R.id.tv_content)).setText(R.string.no_uodate_content);

        mRecyclerView = findViewById(R.id.manage_update_recycler_view);
        layout_bottom = (RelativeLayout) findViewById(R.id.layout_bottom);
        btn_update_all = (Button) findViewById(R.id.btn_update_all);
        btn_update_all.setOnClickListener(new View.OnClickListener() {
            @Override
            @SingleClick(600)
            public void onClick(View v) {
                if (mManagerUpdateAdapter != null) {
                    mManagerUpdateAdapter.updateAll(1002, true, false);
                }
            }
        });
        mManagerUpdateAdapter = new ManagerUpdateAdapter(this, mRecyclerView, null, mPageParamInfo);
        mManagerUpdateAdapter.onCreateView();
        mManagerUpdateAdapter.setFrom(mFrom);
        mManagerUpdateAdapter.setScreenPageName(TRAnalyticsConstant.UPDATE_PAGE);
        //mRecyclerView.setAdapter(mManagerUpdateAdapter);
        mManagerUpdateAdapter.setIMessenger(objects -> {
            PsFloatBallViewKit.INSTANCE.checkNeedOpen(objects);
            refreshUpdateList(false);
//                setState();
        });

        mRecomRecyclerView = findViewById(R.id.recommend_recyle);

        //ignore update list
        ignore_list = findViewById(R.id.ignore_list);
        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setOrientation(LinearLayoutManager.VERTICAL);
        ignore_list.setLayoutManager(lm);
        mIgnoreAdapter = new ManageIgnoreUpdateAdapter(this, ignore_list, null);
        mIgnoreAdapter.setFrom(mFrom);
        mIgnoreAdapter.setScreenPageName(TRAnalyticsConstant.UPDATE_PAGE);
        mIgnoreAdapter.setIMessager(new IMessenger() {
            @Override
            public void onMessenger(Object... objects) {
                refreshUpdateList(false);
//                setState();
            }
        });
        ignore_list.setAdapter(mIgnoreAdapter);

        tv_ignore = findViewById(R.id.tv_ignore);
        layout_ignore = findViewById(R.id.layout_ignore);
        v_toggle = findViewById(R.id.v_toggle);
        layout_ignore_title = findViewById(R.id.layout_ignore_title);
        layout_ignore_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isIgnoreExpand = !isIgnoreExpand;
                onIgnoreLayoutChanged();
            }
        });

        initNoResViews();

        refreshUpdateList(true);
        mUpdateViewModel.loadFeaturedData();

        //tip for auto update
        layout_autoupdate = findViewById(R.id.layout_autoupdate);
        btn_autoupdate_ok = findViewById(R.id.btn_autoupdate_ok);
        boolean isAutoUpdate = PalmPlayNetworkDownloadStateManager.isAutoUpdateAllow();
        if (!isAutoUpdate) {
            layout_autoupdate.setVisibility(View.VISIBLE);
            onManageTabRefresh(mTitleTextView, getFilteredDataCount());

            String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, TRAnalyticsConstant.TIP_AUTO_UPDATE, "", "");
            ComponentExposureBuilder<?> builder = new ComponentExposureBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom);
            TRAnalysticsUtil.trackExposure(builder);
        }
        btn_autoupdate_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAutoUpdateOpen();
            }
        });

        int updateFlagByKey = UpdateControlManager.getInstance().getUpdateFlagByKey(Constants.SCENE_WHITE_KEY);
        InstalledAppsUpdateCache.getInstance().preSendCheckAppsUpdateRequest(Constants.NEED_UPDATE_FLAG == updateFlagByKey,2);

        if (needUpdateAll) {
            if (mManagerUpdateAdapter != null) {
                mManagerUpdateAdapter.updateAll(1002, true, true);
            }
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        layoutManager.setSmoothScrollbarEnabled(true);
        layoutManager.setAutoMeasureEnabled(true);
        mRecomRecyclerView.setHasFixedSize(true);
        mRecomRecyclerView.setNestedScrollingEnabled(true);
        mRecomRecyclerView.setLayoutManager(layoutManager);
        if (mHomeRecyclerViewAdapter == null) {
            mHomeRecyclerViewAdapter = new TrHomeRecyclerViewAdapter(this, mRecomRecyclerView, layoutManager, null,null,null
                    , PageConstants.Update, mPageParamInfo, false, 0, 0,false);
//            mHomeRecyclerViewAdapter = new TrHomeRecyclerViewAdapter(this, downloadManageActivityBinding.recomRecyclerView, layoutManager, null, null
//                    , null, mPageParamInfo.getLastPage(), mPageParamInfo, false, 0, 0);
//            mHomeRecyclerViewAdapter.setOnViewLocationInScreen(mOnViewLocationInScreen);
            mHomeRecyclerViewAdapter.setFrom(mFrom);
            mHomeRecyclerViewAdapter.onCreateView();
            mHomeRecyclerViewAdapter.setCurScreenPage(TRAnalyticsConstant.UPDATE_PAGE);
            mRecomRecyclerView.setAdapter(mHomeRecyclerViewAdapter);

        }
        mUpdateViewModel.getFeaturedLiveData().observe(this, new Observer<FeaturedModel>() {
            @Override
            public void onChanged(FeaturedModel featuredModel) {
                showRecommendView(featuredModel);
            }
        });

        if (!isFromStartup) {
            InstalledAppsUpdateCache.getInstance().sendCheckAppsUpdateRequestByUser();
        }
    }

    private void showRecommendView(FeaturedModel featuredModel) {
        if (featuredModel != null && featuredModel.featureList != null && featuredModel.featureList.size() > 0) {
            List<FeatureBean> listItems = featuredModel.featureList;
            if (View.VISIBLE != mRecomRecyclerView.getVisibility()) {
                mRecomRecyclerView.setVisibility(View.VISIBLE);
            }

            if (mHomeRecyclerViewAdapter != null) {
                if (listItems != null && listItems.size() > 0) {
                    List<TaNativeInfo> adInfo = mUpdateViewModel.updateAdInfos;
                    if (adInfo != null) {
                        int size = adInfo.size();
                        for (int i = 0; i < size; i++) {
                            TaNativeInfo taNativeInfo = adInfo.get(i);
                            if (!taNativeInfo.isIconType()) {
                                //continue
                            } else {
                                //icon类广告
                                FeatureItemData appinfo = null;
                                try {
                                    appinfo = GsonUtil.fromJson(taNativeInfo.getAppInfo(), FeatureItemData.class);
                                    if(appinfo != null) {
                                        appinfo.tNativeInfo = taNativeInfo;
                                    }
                                } catch (GsonUtil.GsonParseException e) {
                                    if (BuildConfig.DEBUG) e.printStackTrace();
                                }

                                if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName) && !mAlreadyAdList.contains(appinfo.packageName))) {
                                    mUpdateViewModel.filterEWData(featuredModel, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn());
                                    TRHomeUtil.addAdForFeatureData(featuredModel.featureList, appinfo, taNativeInfo.getTopicRow(), taNativeInfo.getTopicColumn(), mAlreadyAdList, SceneCode.UP_YM);
                                }
                            }
                        }
                    }

                    //移除已安装应用
                    for (FeatureBean bean: listItems){
                        TRHomeUtil.removeListInstalled(bean);
                    }
                    mHomeRecyclerViewAdapter.setData(listItems, null, null,false,false, true);
                }
            }
        }
    }

    long count_size = 0, count_diff_size = 0;

    private void refreshUpdateList(boolean isNeedTrack) {

        mAppUpdateViewModel.queryDataList(isFromStartup);

        List<ClientVersion.UpdateItem> ignoreList = InstalledAppsUpdateCache.getInstance().getIgnoreUpdateList();
        if (isNeedTrack && ignoreList != null && ignoreList.size() > 0) {
            for (ClientVersion.UpdateItem item : ignoreList) {
                item.hasTrack = false;
            }
        }
        mIgnoreAdapter.setData(ignoreList);
    }

    private void onAutoUpdateOpen() {

        layout_autoupdate.setVisibility(View.GONE);

        PalmPlayNetworkDownloadStateManager.saveAutoUpdateType(Constant.AUTO_UPDATE_APP_WIFI);

        //update title
        mTitleTextView.setText(R.string.text_update);

        String extraVal = "OK";
        String val = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, TRAnalyticsConstant.TIP_AUTO_UPDATE, "", "");
        ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
        builder.setValue(val)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON)
                .setItemValue("")
                .setExtraValue(extraVal);
        TRAnalysticsUtil.trackClick(builder);
    }

    private void setState() {
        //bugID: MIPROAEE-6557
        if (mManagerUpdateAdapter == null) {
            return;
        }

        layout_bottom.setVisibility(mManagerUpdateAdapter.getRealItemCount() > 0 ? View.VISIBLE : View.GONE);

        int downloadingCount = 0;
        int updateCount = 0;
        int downloadedCount = 0;
        int pauseCount = 0;

        int filteredCount = getFilteredDataCount();
        boolean hasRawData = mAppUpdateViewModel.getUpdateItemList() != null
                && !mAppUpdateViewModel.getUpdateItemList().isEmpty();

        if (filteredCount > 0) {
            int[] sa = IndividualCenterUpdateManageUtils.getListUpdateItemState(mManagerUpdateAdapter.getData(), false);
            downloadingCount = sa[0];
            updateCount = sa[1];
            pauseCount = sa[2];
            downloadedCount = sa[3];

            if (mManagerUpdateAdapter.isPauseAll(downloadingCount, downloadedCount, updateCount, pauseCount)) {
                btn_update_all.setText(getString(R.string.pause_all));
            } else {
                String str = getString(R.string.update_all);
                if (count_diff_size != count_size) {
                    Configuration config = getResources().getConfiguration();
                    if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
                        SpannableString span = new SpannableString(str + " (" + FileUtils.getSizeName(count_diff_size) + " " + FileUtils.getSizeName(count_size) + ")");
                        span.setSpan(new StrikethroughSpan(), str.length() + FileUtils.getSizeName(count_diff_size).length() + 3, str.length() + FileUtils.getSizeName(count_diff_size).length() + 3 + FileUtils.getSizeName(count_size).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        btn_update_all.setText(span);
                    } else {
                        SpannableString span = new SpannableString(str + " (" + FileUtils.getSizeName(count_size) + " " + FileUtils.getSizeName(count_diff_size) + ")");
                        span.setSpan(new StrikethroughSpan(), str.length() + 2, str.length() + 2 + FileUtils.getSizeName(count_size).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        btn_update_all.setText(span);
                    }

                } else {
                    btn_update_all.setText(str);
                }
            }

            mUpdateTitle.setVisibility(View.VISIBLE);
            mEmptyView.setVisibility(View.GONE);

        } else {
            if (hasRawData) { //更新列表有数据，但筛选后没数据 --展示mEmptyView，mUpdateTitle
                // 筛选后为空，显示标题和特定空视图文案
                mUpdateTitle.setVisibility(View.VISIBLE);
                mEmptyView.setVisibility(View.VISIBLE);
                ((TextView) mEmptyView.findViewById(R.id.tv_content)).setText(R.string.no_update_category);
            } else {
                // 更新列表完全无数据，隐藏mUpdateTitle，mEmptyView在更新列表 && 不可下载列表 && 忽略下载列表 都为空才展示
                mUpdateTitle.setVisibility(View.GONE);
                checkEmpty(mAppUpdateViewModel.getDataListLiveData().getValue());
                ((TextView) mEmptyView.findViewById(R.id.tv_content)).setText(R.string.no_uodate_content);
            }
        }

        // 更新标题显示（包含分类和数量）
        onManageTabRefresh(mUpdateTitle, filteredCount);

        if (layout_autoupdate.getVisibility() == View.VISIBLE) {
            onManageTabRefresh(mTitleTextView, filteredCount);
        }

        if (updateCount <= 0) {
            NotificationUtil.cancelNotification(PalmplayApplication.getAppInstance().getApplicationContext(), NotificationExtKt.getNOTIFY_ID_UPDATE_APP_LIST());
        }

        onIgnoreLayoutChanged();
    }

    private void refreshUpdateAllButton() {
        int downloadingCount = 0;
        int updateCount = 0;
        int downloadedCount = 0;
        int pauseCount = 0;

        if (btn_update_all != null && mManagerUpdateAdapter.getRealItemCount() > 0) {
            int[] sa = IndividualCenterUpdateManageUtils.getListUpdateItemState(mManagerUpdateAdapter.getData(), false);
            downloadingCount = sa[0];
            updateCount = sa[1];
            pauseCount = sa[2];
            downloadedCount = sa[3];

            if (mManagerUpdateAdapter.isPauseAll(downloadingCount, downloadedCount, updateCount, pauseCount)) {
                btn_update_all.setText(getString(R.string.pause_all));
            } else {
                String str = getString(R.string.update_all);
                if (count_diff_size != count_size) {
                    Configuration config = getResources().getConfiguration();
                    if (config.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
                        SpannableString span = new SpannableString(str + " (" + FileUtils.getSizeName(count_diff_size) + " " + FileUtils.getSizeName(count_size) + ")");
                        span.setSpan(new StrikethroughSpan(), str.length() + FileUtils.getSizeName(count_diff_size).length() + 3, str.length() + FileUtils.getSizeName(count_diff_size).length() + 3 + FileUtils.getSizeName(count_size).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        btn_update_all.setText(span);
                    } else {
                        SpannableString span = new SpannableString(str + " (" + FileUtils.getSizeName(count_size) + " " + FileUtils.getSizeName(count_diff_size) + ")");
                        span.setSpan(new StrikethroughSpan(), str.length() + 2, str.length() + 2 + FileUtils.getSizeName(count_size).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        btn_update_all.setText(span);
                    }

                } else {
                    btn_update_all.setText(str);
                }
            }
        }
    }


    public void onIgnoreLayoutChanged() {
        if (mIgnoreAdapter != null && mIgnoreAdapter.getItemCount() > 0) {
            layout_ignore.setVisibility(View.VISIBLE);
            ignore_list.setVisibility(isIgnoreExpand ? View.VISIBLE : View.GONE);
            onIgnoreUpdateRefresh(tv_ignore, mIgnoreAdapter.getItemCount());
            int resId = ignore_list.getVisibility() == View.VISIBLE ? R.drawable.btn_download_more_up_n : R.drawable.btn_download_more_down_n;
            v_toggle.setImageResource(resId);
        }else {
            layout_ignore.setVisibility(View.GONE);
        }
    }

    public void onIgnoreUpdateRefresh(TextView textView, int count) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        String text = getString(R.string.txt_ignored_updates);
        if (count > 99) {
            text = text + "(99+)";
        } else if (count > 0) {
            text = text + "(" + count + ")";
        }
        textView.setText(text);
    }

    public void onManageTabRefresh(TextView textView, int count) {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        // 获取当前筛选类型
        int sortType = ManagerUpdateAdapter.ALL_SORT;
        if (mManagerUpdateAdapter != null) {
            sortType = mManagerUpdateAdapter.getCurrentAppSort();
        }

        // 根据筛选类型获取对应的文本
        String text = "";
        switch (sortType) {
            case ManagerUpdateAdapter.ALL_SORT:
                text = getString(R.string.filter_all_apps);
                break;
            case ManagerUpdateAdapter.SYSTEM_SORT:
                text = getString(R.string.filter_system_apps);
                break;
            case ManagerUpdateAdapter.OTHER_SORT:
                text = getString(R.string.filter_other_apps);
                break;
        }

        // 拼接数量
        if (count > 99) {
            text = text + "(99+)";
        } else if (count > 0) {
            text = text + "(" + count + ")";
        }
        textView.setText(text);
    }

    @Override
    public void onResume() {
        super.onResume();
        setState();

        if (isPermissionHintDialogShowed) {
            if (CommonUtils.hasStoragePermissions()) {
                isPermissionHintDialogShowed = false;
                ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp();
            }
        }

        boolean isAutoUpdate = PalmPlayNetworkDownloadStateManager.isAutoUpdateAllow();
        if(isAutoUpdate) {
            if(layout_autoupdate!=null) {
                layout_autoupdate.setVisibility(View.GONE);
            }
            if(mTitleTextView!=null) {
                mTitleTextView.setText(R.string.text_update);
            }
        }
        showPsFloatView();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        fromSite = intent.getStringExtra(TRAnalyticsConstant.FROM_SITE);
        backFloatball = "true".equalsIgnoreCase(intent.getStringExtra("backFloatball"));
        packageName = intent.getStringExtra("packageName");

    }

    @Override
    public void onStart() {
        super.onStart();
        if (mManagerUpdateAdapter != null && hasInited && mManagerUpdateAdapter.getData() != null && mManagerUpdateAdapter.getData().size() > 0) {
            mManagerUpdateAdapter.notifyDataSetChanged();
        }
        if (!hasInited) {
            hasInited = true;
        }
    }


    private void releaseInfo() {
        if (mManagerUpdateAdapter != null) {
            mManagerUpdateAdapter.destory();
            mManagerUpdateAdapter = null;
        }

        if (mRecyclerView != null) {
            mRecyclerView = null;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        PsFloatBallView.getInstance(getAppInstance()).hideFloatView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseInfo();

        if (mHomeRecyclerViewAdapter != null) {
            mHomeRecyclerViewAdapter.onDestroy();
        }
        PsFloatBallView.getInstance(getAppInstance()).hideFloatView();
        PsFloatBallView.getInstance(getAppInstance()).removeFloatView();
    }

    private boolean checkOnBackPressed() {
        if (isFromNotify) {
            if (!AtyManager.getAtyManager().isExistsActivity(MainActivity.class)) {
                startActivity(new Intent(this, MainActivity.class).putExtra(FromPageType.Notify, false));
            }
            finish();
            return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ATIVITY_REQUESTCODE_PERMISSIONS) {
            initViews();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (checkOnBackPressed()) {
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {
        if (mEventMainThreadEntity.getAction().equals(Constant.ACTION_APP_UPDATE_FOR_WIFI_ONLY)) {
            boolean isUpdateAll = mEventMainThreadEntity.getBoolean(WifiOnlyTipsActivity.KEY_update_all, false);
            boolean waitingWiFi = mEventMainThreadEntity.getBoolean(WifiOnlyTipsActivity.KEY_WAITING_WIFI, false);
            if (mManagerUpdateAdapter != null) {
                if (isUpdateAll) {
                    mManagerUpdateAdapter.updateAll(true, waitingWiFi);
                    NotificationUtil.cancelNotification(PalmplayApplication.getAppInstance().getApplicationContext(), NotificationExtKt.getNOTIFY_ID_UPDATE_APP_LIST());
                } else {
                    if (mEventMainThreadEntity.getBoolean(WifiOnlyTipsActivity.KEY_is_app, false)) {
                        mManagerUpdateAdapter.updateSingle(mEventMainThreadEntity.getString(WifiOnlyTipsActivity.KEY_packgeName), true, waitingWiFi);
                    } else {
                        mManagerUpdateAdapter.updateSingle(mEventMainThreadEntity.getString(WifiOnlyTipsActivity.KEY_itemID), false, waitingWiFi);
                    }
                }
            }
        } else if (mEventMainThreadEntity.getAction().equals(NetworkActions.ACTION_SYS_APP_UPDATE)
                || mEventMainThreadEntity.getAction().equals(Constant.ACTION_UNINSTALL_APK_REFRESH)
                || mEventMainThreadEntity.getAction().equals(NetworkActions.ACTION_APP_UPDATE)) {
            if (!isFinishing() && mManagerUpdateAdapter != null) {
                LogUtils.i(LogUtils.TAG_THIRD_UPDATE, "ACTION_SYS_APP_UPDATE refreshUpdateList...");
                refreshUpdateList(true);
//                setState();
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), PalmPlayNetworkDownloadStateManager.ACTION_NETWORK_CHECK_FOR_RESUME_DOWNLOAD)) {
            if (mManagerUpdateAdapter != null) {
                mManagerUpdateAdapter.notifyDataSetChanged();
            }
        } else if (TextUtils.equals(mEventMainThreadEntity.getAction(), Constant.ACTION_APP_UPDATE_FOR_HSYNIINFO)) {
            if (mManagerUpdateAdapter != null) {
                String pkg = mEventMainThreadEntity.getString(Constant.KEY_PACKAGE_NAME);
                mManagerUpdateAdapter.notifyItemByPosition(pkg);

                refreshUpdateList(false);
                refreshUpdateAllButton();
            }
            LogUtils.d(LogUtils.TAG_HSYNI, "Check app updates and sync load by newDiff for hsyni.");
        }
    }

    @Override
    public void finish() {
        super.finish();
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(mValue)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    @Override
    public String getValue() {
        return mValue;
    }


    private boolean isPermissionHintDialogShowed;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (!TRPermissionUtil.isGranted(grantResults, permissions)) {
            boolean isTip = ActivityCompat.shouldShowRequestPermissionRationale(this, permissions.length > 0 ? permissions[0] : "");
            LogUtils.d("obbPermission", "onRequestPermissionsResult: refuse " + isTip);
            TRAnalysticsUtil.trackObbPermissionClick(TRAnalyticsConstant.OBB_PERMISSION_REFUSE,getValue());
            if (isTip) {//表明用户没有彻底禁止弹出权限请求
                // 用户选择了禁止权限

            } else {//表明用户已经彻底禁止弹出权限请求
                isPermissionHintDialogShowed = true;
                PermissonsHintDialog.getPermissionHintDlg(this, PermissionsReqActivity.SYS_SETTING_DETAILS_REQUEST_CODE, permissions.length > 0 ? permissions[0] : "");
            }
        } else {
            isPermissionHintDialogShowed = false;
            LogUtils.d("obbPermission", "onRequestPermissionsResult: agree");
            TRAnalysticsUtil.trackObbPermissionClick(TRAnalyticsConstant.OBB_PERMISSION_AGREE,getValue());
            ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp();
        }
    }

    /**
     * 展示悬浮球
     */
    private void showPsFloatView() {
        if (backFloatball && ((TRAnalyticsConstant.UPDATESDK.equals(fromSite))||TRAnalyticsConstant.PMUPDATE.equals(fromSite))) {
            if(ConfigManager.canShowFloatballCloudControl(TRAnalyticsConstant.FOLLATBALL_APPDETAIL,fromSite,packageName)){
                if(!MMKVUtils.getMMKV().getBoolean(Constant.KV_DEEPLINK_FLOATBALL_BACKGROUND,false)) {
                    //显示悬浮球
                    PsFloatBallView.getInstance(getApplicationContext()).showFloatView(packageName,"",fromSite, mFrom);
                }
            }
        }
    }

    private void initNoResViews() {
        llUnavailable = findViewById(R.id.ll_unavailable);
        rvUnavailable = findViewById(R.id.rv_unavailable);
        tvUnavailable = findViewById(R.id.tv_unavailable);
        tvCollapse = findViewById(R.id.tv_collapse);
        tvClearAll = findViewById(R.id.tv_clear_all);
        llUnavailableList = findViewById(R.id.ll_unavailable_list);
        tvUnavailableStart = findViewById(R.id.tv_unavailable_start);

        mAppUpdateViewModel.isNoResListFold().observe(this, state -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            List<FileDownloadInfo> noResList = mAppUpdateViewModel.getNoResList();
            if (noResList == null || noResList.isEmpty()){
                return;
            }
            boolean isFold = Boolean.TRUE.equals(state);
            onNoResFoldStateChange(isFold);
        });
        mAppUpdateViewModel.getDataListLiveData().observe(this, this::onUpdateDataChange);
        llUnavailable.setVisibility(View.GONE);
        rvUnavailable.setLayoutManager(new TRLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        tvUnavailable.setOnClickListener(v -> {
            mAppUpdateViewModel.isNoResListFold().postValue(Boolean.FALSE);
            String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, MODEL_UNVAILABLE, "", "");
            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setItemValue("")
                    .setButtonType("unavailable");
            TRAnalysticsUtil.trackClick(builder);
        });
        tvCollapse.setOnClickListener(v -> {
            mAppUpdateViewModel.isNoResListFold().postValue(Boolean.TRUE);
            String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, MODEL_UNVAILABLE, "", "");
            ComponentClickBuilder<?> builder = new ComponentClickBuilder<>();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setItemValue("")
                    .setButtonType("collapse");
            TRAnalysticsUtil.trackClick(builder);
        });
        tvClearAll.setOnClickListener(new TRNoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                LogUtils.d("DownloadNoRes", "onNoDoubleClick");
                onClearAll();
            }
        });
    }

    private void onUpdateDataChange(Pair<List<ClientVersion.UpdateItem>, List<FileDownloadInfo>> data) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        checkEmpty(data);
        if (data != null){
            onUpdateItemListChange();
            setState();
            onNoResListChange(data.second);
        }
    }

    private void checkEmpty(Pair<List<ClientVersion.UpdateItem>, List<FileDownloadInfo>> data){
        int visibility = View.VISIBLE;
        if (data != null) {
            if ((data.first != null && !data.first.isEmpty()) // 有可更新数据
                    || (data.second != null && !data.second.isEmpty()) // 有可更新数据，但不能下载
                    || (mIgnoreAdapter != null && mIgnoreAdapter.getItemCount() > 0)) // 有忽略更新数据
            {
                visibility = View.GONE;
            }
        }
        mEmptyView.setVisibility(visibility);
    }

    private void onUpdateItemListChange() {
        count_size = 0;
        count_diff_size = 0;
        Set<String> readList = new HashSet<>();
        List<ClientVersion.UpdateItem> list = mAppUpdateViewModel.getUpdateItemList();
        mManagerUpdateAdapter.setData(list);
        if (list != null && list.size() > 0) {
            // 使用筛选后的数据计算大小（而不是所有数据）
            updateFilteredSizes();
            // 记录所有数据的已读列表（不受筛选影响）
            for (ClientVersion.UpdateItem item : list) {
                readList.add(item.packageName);
            }

            //每次进来记录update已读列表
            SPManager.putStringSet(Constant.preference_key_update_date, readList);
        }
    }

    /**
     * 根据当前筛选更新大小计算
     */
    private void updateFilteredSizes() {
        count_size = 0;
        count_diff_size = 0;

        if (mManagerUpdateAdapter != null) {
            List<ClientVersion.UpdateItem> filteredList = mManagerUpdateAdapter.getData();
            if (filteredList != null) {
                for (ClientVersion.UpdateItem item : filteredList) {
                    count_size = count_size + item.size;
                    if (!TextUtils.isEmpty(item.diffSize)) {
                        try {
                            count_diff_size = count_diff_size + Long.parseLong(item.diffSize);
                        } catch (Exception e) {
                        }
                    } else {
                        count_diff_size = count_diff_size + item.size;
                    }
                }
            }
        }
    }

    private void onNoResListChange(List<FileDownloadInfo> noResList) {
        if (noResList == null || noResList.isEmpty()) {
            hideNoResList(); // 无不可下载数据
        } else {
            int size = noResList.size();
            LogUtils.d("DownloadNoRes", "noResList:" + size);
            updateNoResListCount(size);
            showNoResList();
        }
    }

    private void hideNoResList(){
        llUnavailable.setVisibility(View.GONE);
    }

    private void showNoResList(){
        llUnavailable.setVisibility(View.VISIBLE);
        boolean isFold = Boolean.TRUE.equals(mAppUpdateViewModel.isNoResListFold().getValue());
        onNoResFoldStateChange(isFold);
    }

    private void onNoResFoldStateChange(boolean isFold){
        if (isFold){
            foldUpNoResList();
        } else {
            unfoldNoResList();
        }
    }

    private void foldUpNoResList(){
        tvUnavailable.setVisibility(View.VISIBLE);
        llUnavailableList.setVisibility(View.GONE);
        tvCollapse.setVisibility(View.GONE);
    }

    private void unfoldNoResList(){
        tvUnavailable.setVisibility(View.GONE);
        llUnavailableList.setVisibility(View.VISIBLE);
        tvCollapse.setVisibility(View.VISIBLE);
        updateNoResListAdapter();
    }

    private void updateNoResListAdapter() {
        List<FileDownloadInfo> noResList = mAppUpdateViewModel.getNoResList();
        downloadNoResAdapter = new DownloadNoResAdapter(this, noResList, getOnItemDeleteListener());
        rvUnavailable.swapAdapter(downloadNoResAdapter, false);
    }

    private void updateNoResListCount(int count) {
        String display = this.getString(R.string.download_unavailable_list, "" + count);
        tvUnavailable.setText(display);
        tvUnavailableStart.setText(display);
    }

    private DownloadNoResAdapter.OnItemDeleteListener getOnItemDeleteListener() {
        if (onItemDeleteListener == null) {
            onItemDeleteListener = (pos) -> {
                if (downloadNoResAdapter != null) {
                    FileDownloadInfo info = downloadNoResAdapter.getItemById(pos);
                    if (info != null) {
                        LogUtils.d("DownloadNoRes", info.packageName + " pos:" + pos);
                        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
                            deleteNoResTask(info, pos);
                        } else {
                            final DialogBuilder mDialogBuilder = new DialogBuilder();
                            new CustomDialog(ManageUpdateActivity.this).showCheckBoxFunctionDialog(
                                    mDialogBuilder
                                            .hideTitle()
                                            .setMessage(ManageUpdateActivity.this.getString(R.string.delete_task))
                                            .setCheckBoxChecked(false)
                                            .setCheckBoxText(ManageUpdateActivity.this.getString(R.string.no_again))
                                            .setNegativeBtnText(ManageUpdateActivity.this.getString(R.string.text_cancel))
                                            .setPositiveBtnText(ManageUpdateActivity.this.getString(R.string.text_ok))
                                            .setPositiveBtnOnClickListener(new View.OnClickListener() {

                                                @Override
                                                public void onClick(View view) {
                                                    SPManager.putBoolean(Constant.preferences_delete_tips_downloading_record, mDialogBuilder.isCheckBoxChecked());
                                                    deleteNoResTask(info, pos);
                                                }
                                            }));
                        }
                    }
                }
            };
        }
        return onItemDeleteListener;
    }

    private void deleteNoResTask(FileDownloadInfo info, int pos) {
        if (info == null) {
            return;
        }
        mAppUpdateViewModel.deleteNoResTask(info);
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(PageConstants.getDeletePageParamInfo(mPageParamInfo, info.type));

        String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, "", "UN", String.valueOf(pos));
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(info.itemID)
                .setButtonType(TRAnalyticsConstant.DELETE)
                .setItemValue(info.packageName)
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

    private void onClearAll(){
        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
            clearAllNoResTasks();
        } else {
            final DialogBuilder mDialogBuilder = new DialogBuilder();
            new CustomDialog(ManageUpdateActivity.this).showCheckBoxFunctionDialog(
                    mDialogBuilder
                            .hideTitle()
                            .setMessage(ManageUpdateActivity.this.getString(R.string.download_dialog_clear_all_tips))
                            .setCheckBoxChecked(false)
                            .setCheckBoxText(ManageUpdateActivity.this.getString(R.string.no_again))
                            .setNegativeBtnText(ManageUpdateActivity.this.getString(R.string.text_cancel))
                            .setPositiveBtnText(ManageUpdateActivity.this.getString(R.string.text_ok))
                            .setPositiveBtnOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View view) {
                                    SPManager.putBoolean(Constant.preferences_delete_tips_downloading_record, mDialogBuilder.isCheckBoxChecked());
                                    clearAllNoResTasks();
                                }
                            }));
        }
    }

    private void clearAllNoResTasks() {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, "CA", "", "");
        mAppUpdateViewModel.clearAllNoResTasks(value, mFrom);
    }

    /**
     * 显示筛选PopupWindow
     */
    private void showFilterPopupMenu(View anchorView) {
        int currentSort = ManagerUpdateAdapter.ALL_SORT;
        if (mManagerUpdateAdapter != null) {
            currentSort = mManagerUpdateAdapter.getCurrentAppSort();
        }

        FilterPopupWindow popupWindow = new FilterPopupWindow(this);
        popupWindow.setData(currentSort, new FilterPopupWindow.OnFilterItemClickListener() {
            @Override
            public void onItemClicked(int itemIndex, String itemText) {
                int sortType = ManagerUpdateAdapter.ALL_SORT;
                switch (itemIndex) {
                    case 0: // All
                        sortType = ManagerUpdateAdapter.ALL_SORT;
                        break;
                    case 1: // System
                        sortType = ManagerUpdateAdapter.SYSTEM_SORT;
                        break;
                    case 2: // Other
                        sortType = ManagerUpdateAdapter.OTHER_SORT;
                        break;
                }

                // 更新adapter的筛选类型
                if (mAppUpdateViewModel != null) {
                    mAppUpdateViewModel.setAppSort(sortType);
                }

                // 埋点
                // 筛选菜单项点击埋点
                String value = TRStringUtil.generateString(TRAnalyticsConstant.UPDATE_PAGE, "", "", "");
                ComponentClickBuilder builder = new ComponentClickBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setButtonType(getCurrentFilterText(sortType).replaceAll("\\s", ""));
                TRAnalysticsUtil.trackClick(builder);
            }
        });
        popupWindow.onShow(anchorView);
    }

    /**
     * 获取筛选后的数据数量
     */
    private int getFilteredDataCount() {
        if (mManagerUpdateAdapter != null && mManagerUpdateAdapter.getData() != null) {
            return mManagerUpdateAdapter.getData().size();
        }
        return 0;
    }


    /**
     * 获取当前筛选类型的文本
     */
    public static String getCurrentFilterText(int sortType) {
        switch (sortType) {
            case ManagerUpdateAdapter.ALL_SORT:
                return ALL_SORT_STR;
            case ManagerUpdateAdapter.SYSTEM_SORT:
                return SYSTEM_SORT_STR;
            case ManagerUpdateAdapter.OTHER_SORT:
                return OTHER_SORT_STR;
            default:
                return ALL_SORT_STR;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // 保存折叠按钮曝光标志和折叠状态
        if (mManagerUpdateAdapter != null) {
            outState.putBoolean("hasFoldButtonTrackedExposure", mManagerUpdateAdapter.hasFoldButtonTrackedExposure());
            outState.putBoolean("isFolded", mManagerUpdateAdapter.isFolded());
        }
    }
}

package com.afmobi.palmplay.cloudfolder

import android.graphics.Bitmap
import android.text.TextUtils
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.afmobi.palmplay.cloudfolder.config.CloudAppInfo
import com.afmobi.palmplay.cloudfolder.config.CloudPreviewBean
import com.afmobi.palmplay.cloudfolder.model.NormalAppUiModel
import com.afmobi.palmplay.cloudfolder.model.RankAppUiModel
import com.afmobi.palmplay.cloudfolder.model.RankTitleUiModel
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.TYPE_GET_ALL
import com.afmobi.palmplay.cloudfolder.utils.bitmap2Drawable
import com.afmobi.palmplay.cloudfolder.utils.decodeBitmapFromResource
import com.afmobi.palmplay.cloudfolder.utils.dip2px
import com.afmobi.palmplay.cloudfolder.utils.drawableToBitmap
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.utils.mainScope
import com.afmobi.palmplay.cloudfolder.utils.suspendCoroutineWithTimeout
import com.afmobi.palmplay.cloudfolder.view.VirtualFolderIcon
import com.afmobi.palmplay.model.AppInfo
import com.transsion.palmstorecore.bitmap.TRBitmapManager
import com.transsion.palmstorecore.glide.GlideApp
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * 云文件夹预览图片生成管理类
 */
class CloudFolderPreviewManager private constructor() {

    private val TAG = "CloudFolderPreviewManager"

    private var appPreviewBitmap : Bitmap? = null
    private var gamePreviewBitmap : Bitmap? = null

    private var appDataList : List<AppInfo>? = null
    private var gameDataList : List<AppInfo>? = null

    companion object {
        private const val MAX_PREVIEW_LOAD_COUNT = 9
        private const val MAX_CONCURRENT_IMAGE_LOADS = 3

        /**
         * Apps 与 Games 共用的网络图片许可池，避免两个小组件同时刷新时批量提交 Glide 请求。
         */
        private val imageLoadSemaphore = Semaphore(MAX_CONCURRENT_IMAGE_LOADS)

        @Volatile
        private var INSTANCE: CloudFolderPreviewManager? = null

        fun getInstance(): CloudFolderPreviewManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudFolderPreviewManager().also { INSTANCE = it }
            }
        }
    }

    /**
     * 获取文件夹缩略图(桌面icon)
     * 内存有图片，直接使用内存图片
     * @param forceUpdate 是否强制重新生成
     * return bitmap
     */
    suspend fun getFolderPreviewImage(folder: FOLDER, forceUpdate: Boolean = false, defaultDrawableId: Int) : Bitmap?{
        return suspendCoroutine {  ct ->
            var previewImage = if(folder == FOLDER.APPS) {
                appPreviewBitmap
            } else {
                gamePreviewBitmap
            }
            LogUtils.d(TAG, " getFolderPreviewImage  ->>   ${folder.title}   image: $previewImage")
            if(forceUpdate || previewImage == null || previewImage.isRecycled) {
                mainScope.launch {
                    previewImage = generateFolderPreviewImage(folder, TYPE_GET_ALL, forceUpdate, defaultDrawableId) ?: decodeBitmapFromResource(defaultDrawableId)
//                    previewImage = decodeBitmapFromResource(folder.defaultShortcutDrawable)
                    LogUtils.d(TAG, " getFolderPreviewImage  step2:  ->>   ${folder.title}  previewImage:  $previewImage")
                    ct.resume(previewImage)
                }
            } else {
                LogUtils.d(TAG, " getFolderPreviewImage  step3:  ->>   ${folder.title}")
                ct.resume(previewImage)
            }
        }
    }

    /**
     * 从本地物料列表，读取最新的图片数据
     */
    suspend fun generateFolderPreviewImage(folder: FOLDER, type : Int, forceUpdate: Boolean = false, defaultDrawableId: Int) : Bitmap?{
        return suspendCoroutine { ct ->
            ioScope.launch {
                CloudFolderManager.getInstance().getCloudFolderData(folder.categoryType, type, {
                    LogUtils.d(TAG, "generateFolderPreviewImage step1-1 :  fail : ${folder.title}")
                    ct.resume( decodeBitmapFromResource(defaultDrawableId))
                }) { viewData ->
                    val appList = viewData.scrollableItems.mapNotNull { item ->
                        when (item) {
                            is NormalAppUiModel -> item.appInfo
                            is RankAppUiModel -> item.appInfo
                            is RankTitleUiModel -> item.appInfo
                            else -> null
                        }
                    }
                    if(appList.isEmpty()) {
                        LogUtils.d(TAG, "generateFolderPreviewImage step1-2 :  no data : ${folder.title}")
                        ct.resume( decodeBitmapFromResource(defaultDrawableId))
                    } else {
                        mainScope.launch {
                            val previewImageFromData = generatePreviewImageFromData(folder, appList, forceUpdate)
                            ct.resume(previewImageFromData)
                        }
                    }
                }
            }
        }
    }

    suspend fun generatePreviewImageFromData(folder: FOLDER, list: List<CloudAppInfo>, forceUpdate: Boolean = false) : Bitmap?{
        var previewImage : Bitmap? = null
        if(forceUpdate || checkIsNeedRefreshPreview(folder, list)) {
            LogUtils.d(TAG, "  generateFolderPreviewImage  step1   get new preview :  ${folder.title}")
            previewImage = getPreviewImage(list)
        }
        if (previewImage == null) {
            LogUtils.d(TAG, " generateFolderPreviewImage  step 1-1 ->>   ${folder.categoryType}   no need generate image")
        } else {
            setPreviewImage(previewImage, folder)
            val cachedList = list.take(MAX_PREVIEW_LOAD_COUNT).filter { appInfo ->
                appInfo.isCached
            }
            LogUtils.d(TAG, " generateFolderPreviewImage  step 1-2 ->>   ${folder.categoryType}  cacheFinish :  ${cachedList.size}")
            setListData(folder, cachedList)
        }
        return previewImage;
    }

    private fun setPreviewImage(bitmap: Bitmap, folder: FOLDER) {
        if(folder == FOLDER.APPS) {
            appPreviewBitmap = bitmap
        } else {
            gamePreviewBitmap = bitmap
        }
    }

    fun resetPreviewImage(folder: FOLDER) {
        if(folder == FOLDER.APPS) {
            appPreviewBitmap = null
        } else {
            gamePreviewBitmap = null
        }
    }

    /**
     * 校验是否需要重新生成图片
     */
    private fun checkIsNeedRefreshPreview(folder: FOLDER, newList: List<AppInfo>) : Boolean {
        LogUtils.d(TAG, "checkIsNeedRefreshPreview :  start :  ${folder.title}")
        if(getFolderPreviewImageFromMemory(folder) == null) {
            LogUtils.d(TAG, "checkIsNeedRefreshPreview :  no memory bitmap cache ")
            return true
        }
        val origin = if(folder == FOLDER.APPS) appDataList else gameDataList
        return origin?.let {
            val displayNewList = newList.take(MAX_PREVIEW_LOAD_COUNT)
            val sizeJudge =  it.size == displayNewList.size
            if(!sizeJudge) {
                LogUtils.d(TAG, "checkIsNeedRefreshPreview : size different ")
                return true
            }
            try {
                for (index in origin.indices) {
                    if(!TextUtils.equals(origin[index].packageName, displayNewList[index].packageName)) {
                        LogUtils.d(TAG, "checkIsNeedRefreshPreview : package differrent : $index   name:  ${origin[index].packageName}")
                        return true
                    }
                }
            }catch (e: Exception) {
                return true
            }
            false
        } ?: true
    }

    /**
     * 读取本地的物料数据
     */
    fun setListData(folder: FOLDER, list: List<AppInfo>) {
        if(folder == FOLDER.APPS) {
            appDataList = list
        } else {
            gameDataList = list
        }
    }

    fun getFolderPreviewImageFromMemory(folder: FOLDER) : Bitmap?{
        return if(folder == FOLDER.APPS) {
                appPreviewBitmap
            } else {
                gamePreviewBitmap
            }
    }

    /**
     * 物料是否缓存成功
     */
    fun isDataCached(folder: FOLDER) : Boolean {
        val origin = if(folder == FOLDER.APPS) appDataList else gameDataList
        return !origin.isNullOrEmpty()
    }

    private suspend fun getPreviewImage(itemList: List<CloudAppInfo>?): Bitmap? =
        withContext(Dispatchers.IO) {
            if (itemList.isNullOrEmpty()) return@withContext null

            val displayList = itemList.take(MAX_PREVIEW_LOAD_COUNT)

            val deferredList = displayList.map { cloudAppInfo ->
                async {
                    try {
                        val drawable = if (cloudAppInfo.isPreInstallItem()) {
                            CloudFolderRemoteController.getInstance().getCloudThemeIcon(
                                TRApplicationContextUtil.getInstance(),
                                cloudAppInfo.drawable
                        )
                        } else {
                            val iconUrl = cloudAppInfo.iconUrl
                            if (iconUrl.isNullOrBlank()) {
                                null
                            } else {
                                downloadImage(iconUrl).let { bitmap ->
                                    val remoteController = CloudFolderRemoteController.getInstance()
                                    val sourceBitmap = if (remoteController.hasGlobalIconShape()) {
                                        bitmap
                                    } else {
                                        TRBitmapManager.getRoundBorderBitmapByShader(
                                            bitmap,
                                            DeviceProfile.getInstance().iconSizePx,
                                            DeviceProfile.getInstance().iconSizePx,
                                            dip2px(18f),
                                            0, 0
                                        )
                                    }
                                    val iconDrawable = bitmap2Drawable(
                                        TRApplicationContextUtil.getInstance(),
                                        sourceBitmap
                                    )
                                    remoteController.getCloudThemeIcon(
                                        TRApplicationContextUtil.getInstance(),
                                        iconDrawable
                                    )
                                }
                            }
                        }
                        drawable?.mutate()?.let {
                            cloudAppInfo.isCached = true
                            CloudPreviewBean(!cloudAppInfo.isPreInstallItem(), it)
                        }
                    } catch (e: Exception) {
                        if (e is CancellationException) throw e
                        LogUtils.e(TAG, "getPreviewImage: failed to load icon for ${cloudAppInfo.packageName}", e)
                        null
                    }
                }
            }

            val drawableList = deferredList.awaitAll().filterNotNull()

            if (drawableList.isEmpty()) return@withContext null

            withContext(Dispatchers.Main) {
                generatePreviewImage(drawableList)
            }
        }

    private suspend fun downloadImage(iconUrl: String): Bitmap {
        getCachedBitmap(iconUrl)?.let { return it }

        return imageLoadSemaphore.withPermit {
            // 等待许可期间，其他图片任务可能已把同一个资源写入磁盘缓存。
            getCachedBitmap(iconUrl)?.let { return@withPermit it }
            loadNetworkImage(iconUrl)
        }
    }

    private fun getCachedBitmap(iconUrl: String): Bitmap? {
        val cacheBitmap = TRBitmapManager.getBitmap(iconUrl)
        return cacheBitmap?.takeUnless { it.isRecycled }
    }

    private suspend fun loadNetworkImage(iconUrl: String): Bitmap =
        suspendCoroutineWithTimeout(5000) { continuation ->
            val context = TRApplicationContextUtil.getInstance()
            val iconSize = DeviceProfile.getInstance().iconSizePx
            val requestManager = GlideApp.with(context)
            lateinit var target: CustomTarget<Bitmap>
            target = object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    if (continuation.isActive) {
                        continuation.resume(resource)
                    }
                }

                override fun onLoadCleared(placeholder: android.graphics.drawable.Drawable?) = Unit

                override fun onLoadFailed(errorDrawable: android.graphics.drawable.Drawable?) {
                    if (continuation.isActive) {
                        continuation.resumeWithException(IllegalStateException("Image load failed"))
                    }
                }
            }

            continuation.invokeOnCancellation {
                requestManager.clear(target)
            }
            LogUtils.d(TAG, "downloadImage :  download image from net")
            requestManager.asBitmap()
                .load(iconUrl)
                .apply(
                    RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .override(iconSize, iconSize)
                )
                .into(target)
        }


    /**
     * 生成预览图
     */
    private fun generatePreviewImage(drawableList: List<CloudPreviewBean>) : Bitmap?{
        if(drawableList.isEmpty()) {
            return null
        }
        val virtualFolderIcon = VirtualFolderIcon(TRApplicationContextUtil.getInstance())
        virtualFolderIcon.init(drawableList)
        return drawableToBitmap(virtualFolderIcon)
    }

}

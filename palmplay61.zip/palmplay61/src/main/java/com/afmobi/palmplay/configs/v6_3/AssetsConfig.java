package com.afmobi.palmplay.configs.v6_3;

/**
 * Created by zz on 2016/11/16.
 */

public class AssetsConfig {

    public static final String FILE_NAME_FEATURE_NAME_LANG = "feature_name_lang.txt";

    public static final String FILE_NAME_HOME_FEATURED = "home_featured.txt";
    /**
     * 尼日，NG,"Nigeria"：
     */
    public static final String FILE_NAME_HOME_FEATURED_NG = "home_featured_NG.txt";
    /**
     * //肯尼亚，KE,"Kenya"
     */
    public static final String FILE_NAME_HOME_FEATURED_KE = "home_featured_KE.txt";
    /**
     * //加纳，GH,"Ghana"：
     */
    public static final String FILE_NAME_HOME_FEATURED_GH = "home_featured_GH.txt";
    /**
     * //埃及，EG,"Egypt"
     */
    public static final String FILE_NAME_HOME_FEATURED_EG = "home_featured_EG.txt";
    /**
     * //印度，IN,"India"
     */
    public static final String FILE_NAME_HOME_FEATURED_IN = "home_featured_IN.txt";
    /**
     * //巴基斯坦， PK,"Pakistan"
     */
    public static final String FILE_NAME_HOME_FEATURED_PK = "home_featured_PK.txt";


    public static final String COUNTRY_CODE_BD = "BD"; //孟加拉国 (Bangladesh)
    public static final String COUNTRY_CODE_ID = "ID"; //印尼 (Indonesia)
    public static final String COUNTRY_CODE_PH = "PH"; //菲律宾 (Philippines)
    public static final String COUNTRY_CODE_PK = "PK"; //巴基斯坦 (Pakistan)
    public static final String COUNTRY_CODE_IN = "IN"; //印度 (India)
    public static final String COUNTRY_CODE_NG = "NG"; //尼日利亚 (Nigeria)
    public static final String COUNTRY_CODE_KE = "KE"; //肯尼亚 (Kenya)
    public static final String COUNTRY_CODE_EG = "EG"; //埃及 (Egypt)
    public static final String COUNTRY_CODE_GH = "GH"; //加纳 (Ghana)



    public static final String FILE_NAME_COUNTRY_MCC = "country_mcc.txt";
    public static final String TAB_TOOLS_CONFIG = "home_tools_config.json";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  默认
     * */
    public static final String FILE_NAME_FEATURE_TAB = "feature_tab.txt";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  尼日，NG,"Nigeria"：
     * */
    public static final String FILE_NAME_FEATURE_TAB_NG = "feature_tab_NG.txt";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  肯尼亚，KE,"Kenya"
     * */
    public static final String FILE_NAME_FEATURE_TAB_KE = "feature_tab_KE.txt";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  加纳，GH,"Ghana"：
     * */
    public static final String FILE_NAME_FEATURE_TAB_GH = "feature_tab_GH.txt";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  埃及，EG,"Egypt"
     * */
    public static final String FILE_NAME_FEATURE_TAB_EG = "feature_tab_EG.txt";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  印度，IN,"India"
     * */
    public static final String FILE_NAME_FEATURE_TAB_IN = "feature_tab_IN.txt";

    /**
     * HOME/APP/GAME 内置的子tab信息文件  巴基斯坦， PK,"Pakistan"
     * */
    public static final String FILE_NAME_FEATURE_TAB_PK = "feature_tab_PK.txt";


    //DEFAULT
    public static final String FILE_NAME_RECOMMEND_ALL = "Recommend_All.txt";
    //孟加拉国
    public static final String FILE_NAME_RECOMMEND_BD = "Recommend_BD.txt";
      //印度尼西亚
    public static final String FILE_NAME_RECOMMEND_ID = "Recommend_ID.txt";
    //印度，IN,"India"
    public static final String FILE_NAME_RECOMMEND_IN = "Recommend_IN.txt";
       //尼日，NG,"Nigeria"
    public static final String FILE_NAME_RECOMMEND_NG = "Recommend_NG.txt";
       //巴基斯坦， PK,"Pakistan"
    public static final String FILE_NAME_RECOMMEND_PK = "Recommend_PK.txt";

    //GTz专项拦截
    public static final String GT_INTERCEPT_CONFIG = "GTInterceptConfig.json";
    //Instant页本地缓存配置
    public static final String INSTANT_GAME_CACHE = "instant_game.json";

}

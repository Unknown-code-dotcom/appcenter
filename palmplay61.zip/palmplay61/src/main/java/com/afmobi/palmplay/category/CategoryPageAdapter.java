package com.afmobi.palmplay.category;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.afmobi.palmplay.model.CategoryInfo;

import java.util.List;

/**
 * @author: zhiqiang.hao
 * @date: 2021/3/10 15:08
 * @Desc: add your description
 */
public class CategoryPageAdapter extends FragmentStatePagerAdapter {

    private static final String TAG = "CategoryPageAdapter";

    private List<CategoryInfo> mCategoryList;
    private Context mContext;
    private String mTabType;
    private String mCategoryId;
    private String mFrom;

    public CategoryPageAdapter(FragmentActivity context, String tabType) {
        super(context.getSupportFragmentManager());
        mContext = context;
        mTabType = tabType;
    }

    public CategoryPageAdapter(FragmentActivity context, String tabType, List<CategoryInfo> categoryList, String categoryId, String from) {
        super(context.getSupportFragmentManager());
        mContext = context;
        mTabType = tabType;
        mCategoryList = categoryList;
        mCategoryId = categoryId;
        mFrom = from;
    }

    public void setCategoryList(List<CategoryInfo> categoryList) {
        mCategoryList = categoryList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        String categoryId = getCategoryId(position);
        CategoryTabFragment frm = CategoryTabFragment.newInstance(mTabType, categoryId);
        frm.setCategoryType(mTabType);
        frm.setCategoryId(categoryId);
        frm.setCategoryName(getPageTitle(position));
        frm.setEqualsStatus(TextUtils.equals(getCategoryId(position), mCategoryId));
        frm.setCurrentPosition(position);
        frm.setFrom(mFrom);

        return frm;
    }

    @Override
    public int getCount() {
        return mCategoryList == null ? 0 : mCategoryList.size();
    }

    @Override
    public String getPageTitle(int position) {
        if (mCategoryList != null && mCategoryList.size() > position && mCategoryList.get(position) != null) {
            return mCategoryList.get(position).name;
        }
        return "";
    }

    public String getCategoryId(int position) {
        if (mCategoryList != null && mCategoryList.size() > position && mCategoryList.get(position) != null) {
            return mCategoryList.get(position).categoryID;
        }
        return "";
    }

    // https://stackoverflow.com/questions/39098590/android-os-transactiontoolargeexception-on-nougat
    @Nullable
    @Override
    public Parcelable saveState() {
        Bundle bundle = (Bundle) super.saveState();
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putParcelableArray("states", null);
        return bundle;
    }
}

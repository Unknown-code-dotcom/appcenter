package com.afmobi.palmplay.appmanage.v2.adapter

import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.appmanage.adapter.DownloadNoResAdapter.OnItemDeleteListener
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.util.CommonUtils
import com.afmobi.util.TRNoDoubleClickListener
import com.transsion.palmstorecore.glide.GlideUtils
import com.transsnet.store.R
import com.transsnet.store.databinding.LayoutManageDownloadingListItemNoResBinding

/**
 * 不可下载列表适配器V2 - Kotlin版本
 * 用于显示下载失败或不可下载的应用列表
 */
class DownloadNoResAdapterV2(
    private val onItemDeleteListener: OnItemDeleteListener? = null
) : ListAdapter<FileDownloadInfo, DownloadNoResAdapterV2.NoResViewHolder>(NoResDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoResViewHolder {
        val binding = LayoutManageDownloadingListItemNoResBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return NoResViewHolder(binding, onItemDeleteListener)
    }

    override fun onBindViewHolder(holder: NoResViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onBindViewHolder(
        holder: NoResViewHolder,
        position: Int,
        payloads: MutableList<Any>
    ) {
        if (payloads.isEmpty()) {
            super.onBindViewHolder(holder, position, payloads)
        } else {
            // 处理局部更新
            val downloadInfo = getItem(position)
            val changes = payloads[0] as? List<String>
            holder.bindWithPayload(downloadInfo, changes, position)
        }
    }

    fun getItemById(position: Int): FileDownloadInfo? {
        if (position < 0 || position >= itemCount) {
            return null
        }
        return getItem(position)
    }

    /**
     * 不可下载项ViewHolder
     */
    inner class NoResViewHolder(
        private val binding: LayoutManageDownloadingListItemNoResBinding,
        private val onItemDeleteListener: OnItemDeleteListener?
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.ivDeleteNoResoures.setOnClickListener(object : TRNoDoubleClickListener() {
                override fun onNoDoubleClick(v: View) {
                    onItemDeleteListener?.onItemDelete(layoutPosition)
                }
            })
        }

        fun bind(downloadingInfo: FileDownloadInfo?) {
            if (downloadingInfo == null) {
                return
            }

            binding.tvName.text = downloadingInfo.name

            val defaultIcon = R.drawable.layer_list_app_default_01_bg
            GlideUtils.setImageUrl(
                binding.ivIcon,
                downloadingInfo.iconUrl,
                defaultIcon
            )

            binding.ivLayer.setVisibility(View.VISIBLE)
            binding.ivDeleteNoResoures.setVisibility(View.VISIBLE)
            var err: String? = ""
            if (downloadingInfo.extraInfo != null) {
                err = downloadingInfo.extraInfo.noResReason
            }
            if (downloadingInfo.extraInfo != null && downloadingInfo.extraInfo.isRetryInstallFail) {
                err = CommonUtils.getInstallFailMsg(downloadingInfo.extraInfo.installErrorCode)
            }
            if (TextUtils.isEmpty(err)) {
                err = PalmplayApplication.getAppInstance().getString(R.string.no_resource)
            }
            val resources = binding.root.resources
            binding.tvName.setTextColor(resources.getColor(R.color.pluto_item_desc_color))
            binding.tvReason.setTextColor(resources.getColor(R.color.pluto_item_desc_color))
            binding.tvReason.text = err
        }

        fun bindWithPayload(downloadInfo: FileDownloadInfo, changes: List<String>?, position: Int) {
            changes?.forEach { change ->
                when (change) {
                    "downloadStatus" -> bind(downloadInfo)
                }
            }
        }
    }

}
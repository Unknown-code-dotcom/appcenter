// TOP SECRET
package com.afmobi.palmplay.base;

import de.greenrobot.event.EventBus;


/**
 * 
 * @author HJG
 * @date 2016-1-22 下午3:21:30
 * @modifyAuthor: 
 * @modifyDate: 2016-1-22 下午3:21:30
 * @modifyContent:
 */
public abstract class BaseEventFragmentActivity extends BaseFragmentActivity {

	@Override
	public void registerEventBus() {
		EventBus.getDefault().register(this);
	}
	
	@Override
	public void unregisterEventBus() {
		EventBus.getDefault().unregister(this);
	}

}

package com.afmobi.palmplay.cloudfolder.adapter

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile

class NewBottomItemDecoration(private val itemCount: Int) : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        super.getItemOffsets(outRect, view, parent, state)

        val deviceProfile = DeviceProfile.getInstance()
        val position = parent.getChildAdapterPosition(view)
        if (deviceProfile.isPadLayout) {
            if (position > 0) {
                if (parent.layoutDirection == View.LAYOUT_DIRECTION_RTL) {
                    outRect.right = deviceProfile.bottomIconGap
                } else {
                    outRect.left = deviceProfile.bottomIconGap
                }
            }
            return
        }
        val eachSpace: Int = deviceProfile.folderBottomSpace

        when (position) {
            0 -> {
                outRect.right = eachSpace
            }
            itemCount - 1 -> {
                outRect.left = eachSpace + deviceProfile.folderBottomExtraSpace
            }
            else -> {
                outRect.left = eachSpace + deviceProfile.folderBottomExtraSpace
                outRect.right = eachSpace
            }
        }
    }
}

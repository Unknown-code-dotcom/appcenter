package com.afmobi.palmplay.appmanage.v2.factory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.afmobi.palmplay.appmanage.v2.repository.DownloadRepo
import com.afmobi.palmplay.appmanage.v2.repository.DownloadRepoImpl
import com.afmobi.palmplay.appmanage.v2.viewmodel.ManageDownloadViewModelV2

/**
 * ManageDownloadViewModelV2的工厂类
 * 用于创建带有依赖注入的ViewModel实例
 */
class ManageDownloadViewModelFactory() : ViewModelProvider.Factory {
    
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ManageDownloadViewModelV2::class.java)) {
            val repository: DownloadRepo = DownloadRepoImpl()
            return ManageDownloadViewModelV2(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
// TOP SECRET
package com.afmobi.palmplay.cache.v6_0;

import android.text.TextUtils;

import com.afmobi.palmplay.cache.InstalledAppsUpdateCache;
import com.afmobi.palmplay.cache.LocalCache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.ClientVersion.UpdateItem;
import com.afmobi.palmplay.model.v6_0.IgnoreUpdateEntity;
import com.afmobi.util.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IgnoreUpdateCache implements LocalCache{

	private static final String ignore_uri = FilePathManager.getCacheBaseFileUri()+ File.separator + "ignore_update_cache.txt";
	
	private List<IgnoreUpdateEntity> listIgnoreUpdateEntity;// = new ArrayList<CheckRequestItem>();
	private static volatile IgnoreUpdateCache instance;// = new IgnoerCache();
	private static byte[] lock = new byte[0];
	
	private IgnoreUpdateCache() {
		loadFromCache();
	}

	public static IgnoreUpdateCache getInstance() {
		if(instance==null)
			synchronized (lock) {
				if(instance==null){
					instance = new IgnoreUpdateCache();
				}
				
			}
		return instance;
	}
	
	private void putIgnoreListToFile(List<IgnoreUpdateEntity> ignoreList){
		FileUtils.put(new File(ignore_uri), ignoreList); 
	}
	
	public List<IgnoreUpdateEntity> getIgnoreList(){
		if(listIgnoreUpdateEntity == null) {
			loadFromCache();
		}
		return listIgnoreUpdateEntity;
	}
	
	public synchronized void append(String packageName, int version){
		
		if(getIgnoreList()!=null && !TextUtils.isEmpty(packageName) && !existIgnoreVersion(packageName, version)){
			if(!existIgnorePackageName(packageName)){
				IgnoreUpdateEntity mIgnoreUpdateEntity = new IgnoreUpdateEntity();
				mIgnoreUpdateEntity.packageName = packageName;
				mIgnoreUpdateEntity.itemList = new ArrayList<Integer>();
				mIgnoreUpdateEntity.itemList.add(version);
				getIgnoreList().add(mIgnoreUpdateEntity);
				
				putIgnoreListToFile(getIgnoreList());
				
			} else /*if(!existIgnoreVersion(packageName, version))*/ {
				boolean isExistVersion = false;
				for(IgnoreUpdateEntity mIgnoreUpdateEntity : getIgnoreList()){
					if(mIgnoreUpdateEntity!=null && mIgnoreUpdateEntity.existPackage(packageName)){
						if(mIgnoreUpdateEntity.isNotNullSize()){
							for(Integer ignoreVersion : mIgnoreUpdateEntity.itemList){
								if(ignoreVersion==version){
									isExistVersion = true;
									break;
								}
							}
							
							if(!isExistVersion){
								mIgnoreUpdateEntity.itemList.add(version);
								putIgnoreListToFile(getIgnoreList());
							}
							
						} else {
							if(mIgnoreUpdateEntity.isNullData())
								mIgnoreUpdateEntity.itemList = new ArrayList<Integer>();
							mIgnoreUpdateEntity.itemList.add(version);
							putIgnoreListToFile(getIgnoreList());
						}
						
						break;
					}
				}
			}
		}
		
	}

	public void checkIgnoreUpdateApp(List<UpdateItem> list){
		if(list!=null && list.size()>0){
			List<UpdateItem> mlist = InstalledAppsUpdateCache.getInstance().getIgnoreUpdateList();
			if (mlist == null  || mlist.size() <= 0) {
				return;
			}
			Iterator<UpdateItem> it = list.iterator();
			while(it.hasNext()) {
				UpdateItem item = it.next();
				if(item!=null && !TextUtils.isEmpty(item.packageName)) {
					for(UpdateItem mIgnoreUpdateEntity : mlist){
						if(mIgnoreUpdateEntity!=null && !TextUtils.isEmpty(mIgnoreUpdateEntity.packageName)
						&& TextUtils.equals(mIgnoreUpdateEntity.packageName, item.packageName)){
							it.remove();
							break;
						}
					}
				}
			}
		}
	}

//	public synchronized void checkIgnoreUpdateApp(List<UpdateItem> list){
//		if(list!=null && list.size()>0){
//			List<UpdateItem> tempListUpdateItem = new ArrayList<ClientVersion.UpdateItem>();
//			List<IgnoreUpdateEntity> mlist = getIgnoreList();
//			if (mlist == null  || mlist.size() <= 0) {
//				return;
//			}
//
//			for(UpdateItem mUpdateItem : list){
//
//				if(mUpdateItem==null || TextUtils.isEmpty(mUpdateItem.packageName))
//					continue;
//
//				for(IgnoreUpdateEntity mIgnoreUpdateEntity : mlist){
//
//					if(mIgnoreUpdateEntity!=null && mIgnoreUpdateEntity.existVersion(mUpdateItem.packageName, mUpdateItem.version)){
//						tempListUpdateItem.add(mUpdateItem);
//						break;
//					}
//				}
//			}
//			try{
//				list.removeAll(tempListUpdateItem);
//			} catch (Exception/*ConcurrentModificationException*/ e){
//
//			}
//		}
//
//	}
	
	public boolean existIgnoreVersion(String packageName, int version){
//		//detail and app list show ignored app
//		if(getIgnoreList()!=null && getIgnoreList().size() > 0 ){
//			for(IgnoreUpdateEntity mIgnoreUpdateEntity : getIgnoreList()){
//				if(mIgnoreUpdateEntity!=null && mIgnoreUpdateEntity.existVersion(packageName, version)){
//					return true;
//				}
//			}
//		}
		
		return false;
	}
	
	public boolean existIgnorePackageName(String packageName){
		if(getIgnoreList()!=null && getIgnoreList().size() > 0 ){
			for(IgnoreUpdateEntity mIgnoerUpdateEntity : getIgnoreList()){
				if(mIgnoerUpdateEntity!=null && mIgnoerUpdateEntity.existPackage(packageName)){
					return true;
				}
			}
		}
		
		return false;
	}
	
	@Override
	public void saveToCache(String jsonBuffer, Object... objects) {
		
	}

	@Override
	public synchronized void loadFromCache(Object... objects) {
		listIgnoreUpdateEntity = FileUtils.getAsListObject(new File(ignore_uri));
		if(listIgnoreUpdateEntity==null)
			listIgnoreUpdateEntity = new ArrayList<>();
//		putIgnoreListToFile(listIgnoreUpdateEntity);
	}

	@Override
	public String getFileName(Object... objects) {
		return null;
	}
}
// TOP SECRET
package com.afmobi.palmplay.base;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.StartActivity;
import com.afmobi.palmplay.activate.manager.TRNewManager;
import com.afmobi.palmplay.activate.state.TRPopUpScene;
import com.afmobi.palmplay.alonefuction.NewVersionTipActivity;
import com.afmobi.palmplay.configs.v6_3.FromPageType;
import com.afmobi.palmplay.customview.InstalledCompleteWindow;
import com.afmobi.palmplay.dialog.TRDialogUtil;
import com.afmobi.palmplay.main.dialog.TipNetworkDialog;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.recommendinstall.TRInstallActivity;
import com.afmobi.palmplay.setting.UpdateActivity;
import com.afmobi.palmplay.setting.WifiOnlyTipsActivity;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.PhoneDeviceInfo;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jcodecraeer.xrecyclerview.ScrollListener;
import com.transsion.palmstorecore.BaseCoreActivity;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.AndroidVUIUtils;
import com.transsion.palmstorecore.util.Constants;
import com.transsion.palmstorecore.util.LanguageSelectManager;
import com.transsnet.store.R;

import java.lang.ref.WeakReference;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 
 * @author HJG
 * @date 2016-1-22 下午3:21:40
 * @modifyAuthor:
 * @modifyDate: 2016-3-11 下午2:15:40
 * @modifyContent: listener Intent.ACTION_LOCALE_CHANGED
 */
public abstract class BaseFragmentActivity extends BaseCoreActivity {
	public boolean hasShowed = false;

	protected PageParamInfo mPageParamInfo = new PageParamInfo();

	// ====================== EventBus method start
	/**
	 * register EventBus
	 */
	public void registerEventBus() {
	}

	/**
	 * unregister EventBus
	 */
	public void unregisterEventBus() {
	}

	/**
	 * EventBus callback method
	 * 
	 * @param mEventMainThreadEntity
	 */

	public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {

	}
	public boolean isToastNetworkDisConnectedWhenResume(){
		return false;
	}

	/**
	 * true -: check on onResume when receive Intent.ACTION_LOCALE_CHANGED &&
	 * app is from background to foreground, else not check.
	 */
	protected boolean isNeedCheckOnResumeWithLocalChange = false;
	protected boolean isFromNotify = false;
	private long mEnterTime = 0;  // 统计进入页面时间
	private final String CLASS_NAME = getClass().getName();
	private boolean mIgnoreRecord = false;
    public boolean isVisibility = false;
	public TipNetworkDialog mTipNetworkDilog;
	protected boolean reMeasureStatusBar = false;
	@Override
	protected void onCreate(Bundle onSaveInstanceState) {
		if(!(this instanceof StartActivity || this instanceof TRInstallActivity)){
			DisplayUtil.onFitScreenType(this);
		}
		DisplayUtil.setGesturalSystemBar(this, reMeasureStatusBar);
		if (onSaveInstanceState != null) {
			onSaveInstanceState.remove("android:support:fragments");
		}
		super.onCreate(onSaveInstanceState);
		overridePendingTransition(0, 0);
		AndroidVUIUtils.INSTANCE.matchAndroid15UI(this, reMeasureStatusBar);
		Intent mainIntent = getIntent();

		try {
			if (mainIntent != null){
				isFromNotify = mainIntent.getBooleanExtra(FromPageType.Notify, false);
			}
		} catch (Exception e) {
			LogUtils.d("BaseFragmentActivity", "isFromNotify fail" + e);
		}

		if (!this.isTaskRoot()) { // 判断该Activity是不是任务空间的源Activity，“非”也就是说是被系统重新实例化出来
			// 如果你就放在launcher Activity中话，这里可以直接return了
			if (mainIntent != null) {
				String action = mainIntent.getAction();
				if (!TextUtils.isEmpty(action) && mainIntent.hasCategory(Intent.CATEGORY_LAUNCHER) && action.equals(Intent.ACTION_MAIN)) {
					finish();
					return;// finish()之后该活动会继续执行后面的代码，你可以logCat验证，加return避免可能的exception
				}
			}
		}
		registerEventBus();
		hasShowed = false;
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	public void setContentView(int layoutResID) {
		try {
			super.setContentView(layoutResID);
		} catch (Throwable e) {
			LogUtils.e("BaseFragmentActivity", e.toString());
		}
		if(!((this instanceof WifiOnlyTipsActivity)
	    		|| (this instanceof UpdateActivity)
	    		|| (this instanceof NewVersionTipActivity)
	    		)){
	    	setStatusBar();
	    }
		if(!(this instanceof TRInstallActivity)) {
			DisplayUtil.onFitWaterFall(this);
		}
	}
	
	/**
	 * 设置StatusBar颜色
	 */
	protected void setStatusBar() {
	}

	private boolean getCheckGPRSNetworkRestoreConnectedStartdownloadCondition() {
		return !((this instanceof WifiOnlyTipsActivity)
				|| (this instanceof StartActivity)
				);
	}

	@Override
	protected void onResume() {
		super.onResume();

		mEnterTime = System.currentTimeMillis();

		PhoneDeviceInfo.setBackgrounder(false);

		isVisibility = true;

		LogUtils.d("APM", "----onResume----" + this.getClass().getSimpleName());
		if (Constants.TipNetworkDialogHasClose) {
			onTipNetworkDialogDismiss();
		}
	}

	public void onTipNetworkDialogShow() {
		if(TRNewManager.Companion.getInstance().isNewPopEnable()) {
			if (!Constants.TipNetworkDialogHasClose && TRDialogUtil.noNetTipDialogCanShow()
					&& !com.afmobi.util.NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
				TRNewManager.Companion.getInstance().showPop(TRPopUpScene.POP_UP_TIP_NETWORK, getValue(), this);
			}
			return;
		}
		if (!Constants.TipNetworkDialogHasClose && TRDialogUtil.noNetTipDialogCanShow()
				&& !com.afmobi.util.NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
			if (mTipNetworkDilog == null) {
				mTipNetworkDilog = new TipNetworkDialog();
				mTipNetworkDilog.setFrom(getValue());
			}
			if (!hasShowed) {
				mTipNetworkDilog.showDialog(this);
			}
		}
	}

	public void onTipNetworkDialogDismiss(){
		if(TRNewManager.Companion.getInstance().isNewPopEnable()) {
			TRNewManager.Companion.getInstance().dismiss(TRPopUpScene.POP_UP_TIP_NETWORK, this);
		}else {
			if (mTipNetworkDilog != null && mTipNetworkDilog.isShow()) {
				mTipNetworkDilog.dismiss();
			}
		}
	}

	/**
	 * when GPRS network restore connected and last network is UNAVAILABLE, than
	 * need restore download
	 *
	 * //TODO:不再使用：后台切前台后不再展示数据网络提示框；
	 */
//	@Deprecated
//	private void checkGPRSNetworkRestoreConnectedStartdownloadOnResume() {
//		// add by HJG 2016-03-10 for GPRS download tip .
//		if (!getCheckGPRSNetworkRestoreConnectedStartdownloadCondition())
//			return;
//
//		if (!PalmPlayNetworkDownloadStateManager.getInstance().isNeedCheckGPRSNetworkRestoreConnectedStartdownloadOnResume())
//			return;
//
//		if (!TextUtils.equals(NetworkUtils.getNetworkState(this), NetworkState.WIFI) && TextUtils.equals(PhoneDeviceInfo.getLastNetworkState(), NetworkState.UNAVAILABLE)) {
//
//			PalmPlayNetworkDownloadStateManager.getInstance().getHandler()
//					.postDelayed(new Runnable() {
//
//						@Override
//						public void run() {
//
//							WifiOnlyTipsActivity.checkGPRSNetworkRestoreConnectedStartdownloadOnResume(BaseFragmentActivity.this);
//
//						}
//					}, 1500);
//
//		}
//	}

	@Override
	protected void onPause() {
		super.onPause();
		isNeedCheckOnResumeWithLocalChange = false;
	}

	@Override
	protected void onStop() {
		super.onStop();
		isNeedCheckOnResumeWithLocalChange = false;
		finishedRecordPageCostTime();
		isVisibility = false;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		isNeedCheckOnResumeWithLocalChange = false;

		unregisterEventBus();
		InstalledCompleteWindow.getInstance().removeInstalledCompleteWindow();
		if(TRNewManager.Companion.getInstance().isNewPopEnable() && !(this instanceof StartActivity)) {
		//	TRNewManager.Companion.getInstance().dismiss(TRPopUpScene.POP_UP_TIP_NETWORK, this);
		} else {
			if (mTipNetworkDilog != null && mTipNetworkDilog.isShow()) {
				mTipNetworkDilog.dismiss();
				mTipNetworkDilog = null;
			}
		}
	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(0, 0);
	}

	/** this activity layout must contains view id */
	protected void initOnClickTitleBack() {
		try {
			findViewById(R.id.layout_title_back).setOnClickListener(
					new OnClickListener() {

						@Override
						public void onClick(View v) {
							finish();
						}
					});

		} catch (Exception e) {
			LogUtils.e(e);
		}
	}

	/**
	 * Note: for listener language change, so some activity must use
	 * transaction().commitAllowingStateLoss when replace or add fragment, see
	 * language change (importance) .
	 * 
	 * @param containerViewId
	 * @param fragment
	 */
	protected void replaceFragmentCommitAllowingStateLoss(int containerViewId, Fragment fragment) {
		getSupportFragmentManager().beginTransaction().replace(containerViewId, fragment).commitAllowingStateLoss();
	}

	/**
	 * replace
	 * 
	 * @param containerViewId
	 * @param fragment
	 * @param tag
	 */
	protected void replaceFragmentCommit(int containerViewId,Fragment fragment, String tag) {
		getSupportFragmentManager().beginTransaction().replace(containerViewId, fragment, tag).commit();
	}

	protected void replaceFragmentCommitAllowingStateLoss(int containerViewId,Fragment fragment, String tag) {
		getSupportFragmentManager().beginTransaction().replace(containerViewId, fragment, tag).commitAllowingStateLoss();
	}

	/**
	 * @param toCls
	 *            - jump activity class
	 * @param replaceFragmentCls
	 *            - need replace fragment's simpleName
	 */
	public void replaceFragmentWithClassName(Class<?> toCls,
											 Class<?> replaceFragmentCls, PageParamInfo pageParamInfo) {
		Intent intent = new Intent(this, toCls);
		intent.putExtra(toCls.getSimpleName(),
				replaceFragmentCls.getSimpleName());
		PageConstants.putPageParamInfo(intent, pageParamInfo);
		try {
			startActivity(intent);
		} catch (Exception e) {
			try {
				intent.setPackage(replaceFragmentCls.getSimpleName());
				startActivity(intent);
			} catch (Exception ignored) {
			}
		}
	}

	/**
	 * 返回页面进入时间
	 * @return
	 */
	protected long getPageEnterTime() {
		return mEnterTime;
	}

	protected void addNoMore(RecyclerView rv , LinearLayoutManager linearLayout, AppBarLayout abl){

		ScrollListener scrollListener = new ScrollListener(linearLayout, abl, new ScrollListener.OnCusScrollListener() {
			@Override
			public void onFirstItemVisible(AppBarLayout appBarLayout) {

				if(appBarLayout!=null){
					appBarLayout.setExpanded(true);// 下拉滑动的时候有卡顿, 设置展开可以消除卡顿
				}
			}

			@Override
			public void onNoMoreToast(long lastToastTime) {
				//ToastManager.getInstance().showS(BaseFragmentActivity.this, BaseFragmentActivity.this.getResources().getString(R.string.no_more_contents));
			}
		});
		rv.addOnScrollListener(scrollListener);
	}

	public void setIgnoreRecordTime() {
		mIgnoreRecord = true;
	}

	/**
	 * 记录页面打点时长
	 */
	public void finishedRecordPageCostTime() {
		long interval = System.currentTimeMillis() - mEnterTime;

		if(mEnterTime == 0 || mIgnoreRecord) {
			/** time = 0 表示还没进过页面不做埋点记录
			 **/
			return;
		}
		if(BuildConfig.DEBUG) {
			LogUtils.e("BaseActivity",CLASS_NAME +" cost "+interval);
		}
		TRAnalysticsUtil.trackExposureTime(CLASS_NAME, interval);
	}

	/**
	 * 获取Athena打点的页面value值；
	 * @return
	 */
	public abstract String getValue();


	public boolean showInstalledCompleteWindow(Activity activity, InstalledAppInfo appInfo, FileDownloadInfo downloadInfo) {
		//当前界面可见的时候才可以展示
		if (isVisibility) {
			if (downloadInfo != null && downloadInfo.isVa()) {
				return false;
			}
			InstalledCompleteWindow.getInstance().showInstalledCompleteWindow(new WeakReference<>(activity), appInfo, downloadInfo, getValue());
			return true;
		}
		return false;
	}

	@Override
	protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
		try {
			super.onRestoreInstanceState(savedInstanceState);
		} catch (Exception e) {
			FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance()).logEvent("wrong_state", null);
			if (BuildConfig.DEBUG) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onConfigurationChanged(@NonNull Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		String configString =  newConfig.toString();
		boolean isSmallWindow = configString.contains("mMultiWindowMode=SMALL");
		AndroidVUIUtils.INSTANCE.isSmallWindow(isSmallWindow);
	}

}

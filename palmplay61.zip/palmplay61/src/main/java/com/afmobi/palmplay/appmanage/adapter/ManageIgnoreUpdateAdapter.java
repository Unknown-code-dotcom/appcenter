package com.afmobi.palmplay.appmanage.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.holder.IgnoreUpdateViewHolder;
import com.afmobi.palmplay.cache.InstalledAppsUpdateCache;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.service.PalmstoreService;
import com.afmobi.util.Constant;
import com.afmobi.util.IMessenger;
import com.afmobi.util.TRJumpUtil;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import de.greenrobot.event.EventBus;

public class ManageIgnoreUpdateAdapter extends RecyclerView.Adapter{

   private RecyclerView mRecyclerView;
   private List<ClientVersion.UpdateItem> mUpdateItemList = new ArrayList<ClientVersion.UpdateItem>();
   private Context mContext;
   private IMessenger mIMessenger;
   private String mScreenPageName;
   private String mFrom;

   public ManageIgnoreUpdateAdapter(Context context, RecyclerView recyclerView, List<ClientVersion.UpdateItem> updateItemList) {
      this.mContext = context;
      this.mRecyclerView = recyclerView;

      if (updateItemList != null) {
         this.mUpdateItemList.clear();
         this.mUpdateItemList.addAll(updateItemList);
      }
   }

   public void setData(List<ClientVersion.UpdateItem> list) {
      if (list != null) {
         this.mUpdateItemList.clear();
         this.mUpdateItemList.addAll(list);
      }

      notifyDataSetChanged();
   }

   public void setIMessager(IMessenger i) {
      this.mIMessenger = i;
   }

   public void setScreenPageName(String screenPageName) {
      this.mScreenPageName = screenPageName;
   }
   public void setFrom(String from) {
      this.mFrom = from;
   }

   @NonNull
   @Override
   public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      return new IgnoreUpdateViewHolder(LayoutInflater.from(mContext).inflate(R.layout.z_layout_manage_ignore_update_item, parent, false));
   }

   @Override
   public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
      if (holder instanceof IgnoreUpdateViewHolder) {
         ClientVersion.UpdateItem item = getItemById(position);
         IgnoreUpdateViewHolder viewHolder = (IgnoreUpdateViewHolder)holder;
         viewHolder.setIgnoreRestoreClickListener(new IgnoreRestoreClickListener(viewHolder, item, position));
         viewHolder.setFrom(mFrom);
         viewHolder.bind(item, position);
      }
   }

   @Override
   public int getItemCount() {
      return this.mUpdateItemList == null ? 0 : this.mUpdateItemList.size();
   }

   public ClientVersion.UpdateItem getItemById(int position) {
      if (position < 0 || position >= getItemCount()) {
         return null;
      }

      return mUpdateItemList.get(position);
   }

   public class IgnoreRestoreClickListener implements View.OnClickListener {

      private IgnoreUpdateViewHolder viewHolder;
      private ClientVersion.UpdateItem mUpdate;
      private int mPosition;

      public IgnoreRestoreClickListener(IgnoreUpdateViewHolder holder, ClientVersion.UpdateItem item, int pos) {
         this.viewHolder = holder;
         this.mUpdate = item;
         this.mPosition = pos;
      }

      @Override
      public void onClick(View v) {
         if(viewHolder == null || mUpdate == null) {
            return;
         }

         if(v.getId() == viewHolder.tv_restore.getId()){
            InstalledAppsUpdateCache.getInstance().restoreIgnoreUpdateItem(mUpdate);
            InstalledAppsUpdateCache.getInstance().addUpdateItem(mUpdate);

            if (mIMessenger != null) {
               mIMessenger.onMessenger();
            }

            EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
            eventMainThreadEntity.setAction(PalmstoreService.ACTION_NOTIFICATION_UPDATE_COUNT);
            EventBus.getDefault().post(eventMainThreadEntity);
         }else if (v.getId() == viewHolder.rootView.getId()) {
            String value = TRStringUtil.generateString(mScreenPageName, "","", mUpdate.placementId);
            AppBuilder appBuilder = new AppBuilder()
                    .setFromPage(Constant.NEW_FROMPAGE_UPDATE)
                    .setLastPage(PageConstants.Update)
                    .setValue(value)
                    .setParamsByData(TRJumpUtil.convetToRankDataItem(mUpdate), "");
            TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);

            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(mUpdate.detailType)
                    .setItemId(mUpdate.itemID)
                    .setButtonType(TRAnalyticsConstant.ICON)
                    .setReportSource(mUpdate.reportSource)
                    .setNativeId(mUpdate.nativeId)
                    .setItemValue(mUpdate.packageName)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);
         }
      }
   }
}

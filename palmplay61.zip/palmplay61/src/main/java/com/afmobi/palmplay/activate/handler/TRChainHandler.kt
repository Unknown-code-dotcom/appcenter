package com.afmobi.palmplay.activate.handler

import android.app.Activity
import android.content.DialogInterface
import android.content.DialogInterface.OnKeyListener
import android.content.DialogInterface.OnShowListener
import android.view.View
import android.view.View.OnClickListener
import com.afmobi.palmplay.activate.TRBaseExecutor
import com.afmobi.palmplay.activate.state.TRPopupType
import com.afmobi.palmplay.activate.state.TRPriority
import com.afmobi.palmplay.dialog.OfflineMoreGuideDialog
import java.lang.ref.WeakReference

abstract class TRChainHandler(
    var sceneName: String, protected var priority: TRPriority, // 在同一优先级内的顺序
    protected var popupType: TRPopupType,
) :
    Comparable<TRChainHandler> {

    abstract fun canShow(fromType: String?): Boolean
    open fun show(fromType: String?): Boolean= false
    open fun show(fromType: String?, activity: Activity?): Boolean = false

    open fun show(fromType: String?,from:String?, activity: Activity?): Boolean = false
    open fun dismiss(): Boolean= false

    open fun dismiss(activity: Activity?): Boolean = false
    abstract fun showNext(fromType: String?): Boolean
    open fun showing(): Boolean= false
    open fun hide() : Unit = Unit

    open fun getExecutor() : TRBaseExecutor<*>? = null

    open fun show(
        fromType: String?,
        activity: Activity?,
        clickListener: View.OnClickListener,
        dismissListener: DialogInterface.OnDismissListener
    ): Boolean {
        return false
    }

    open fun show(
        fromType: String?,
        activity: Activity?,
        isNeedGuide: Boolean,
        listener: DialogInterface.OnDismissListener
    ): Boolean {
        return false
    }

    open fun show(
        fromType: String?,
        activity: Activity?,
        showListener: OnShowListener,
        keyListener: OnKeyListener
    ): Boolean {
        return false
    }

    open fun show(
        fromType: String?,
        activity: Activity?,
        Listener: OfflineMoreGuideDialog.OnDialogBtnClickListener,
        isR2L: Boolean,
        position: IntArray
    ): Boolean {
        return false
    }

    open fun show(
        fromType: String?,
        activity: Activity?,
        y: Int
    ): Boolean {
        return false
    }

    var reason:String? = null
    var fromType:String?= null
    var  curActivity : WeakReference<Activity>? = null

    override fun compareTo(other: TRChainHandler): Int {
        // 首先按优先级排序，优先级高的在前
        val priorityCompare = Integer.compare(
            other.priority.getPriority(),
            priority.getPriority()
        )
        if (priorityCompare != 0) {
            return priorityCompare
        }
        return 1
    }

    fun getPopType(): TRPopupType {
        return popupType
    }
}

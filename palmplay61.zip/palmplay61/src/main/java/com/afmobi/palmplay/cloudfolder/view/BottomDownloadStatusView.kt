package com.afmobi.palmplay.cloudfolder.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PaintFlagsDrawFilter
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.afmobi.apk.ApkInstallUtils
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.util.DisplayUtil
import com.transsnet.store.R

/**
 * 桌面文件夹底部下载状态指示
 *
 * @author xiangfei.wei
 * @date 2019年10月30日
 */
class BottomDownloadStatusView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private val pfd: PaintFlagsDrawFilter?
    private val mPaint: Paint
    var progressColor: Int
    private var viewWidth: Int
    private var viewHeight: Int
    private var progressWidth: Int
    private var progressHeight: Int //中间内容区域的宽、高
    private var bitmapBg: Bitmap? = null
    private var bitmapPause: Bitmap? = null
    private var bitmapDownloaded: Bitmap? = null
    private var bgSrcRect: Rect? = null
    private var bgDstRect: Rect? = null
    private var pauseSrcRect: Rect? = null
    private var pauseDstRect: Rect? = null
    private var downloadedSrcRect: Rect? = null
    private var downloadedDstRect: Rect? = null

    private var mOuterRect: RectF
    private var mClipPath: Path
    private var progressRect: RectF? = null
    private var status = -1
    private var progress = 0f
    private val startAngle = 22.5f
    private val silentInstall: Boolean

    private val mAlphaColorPaint: Paint

    private var mCornerRadius: Float
    private var clipToIconShape = true

    init {
        viewHeight = context.resources.getDimension(R.dimen.folder_icon_size).toInt()
        viewWidth = viewHeight
        mPaint = Paint()
        mPaint.setAntiAlias(true)
        progressHeight = (viewHeight * PROGRESS_SIZE_RATIO).toInt()
        progressWidth = progressHeight
        pfd = PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        progressColor = Color.parseColor("#b2000000") //b2
        silentInstall = ApkInstallUtils.isUsingSilentInstall()
        mAlphaColorPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        mAlphaColorPaint.setColor(
            context.getResources().getColor(R.color.cloud_folder_downloading_fg_color, null)
        )
        val iconCornerPx = DisplayUtil.dip2px(context, ICON_CORNER_RADIUS_DP).toFloat()
        mCornerRadius = iconCornerPx
        mOuterRect = RectF(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat())
        mClipPath = Path().apply {
            addRoundRect(mOuterRect, iconCornerPx, iconCornerPx, Path.Direction.CW)
        }
    }

    protected override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0 && (w != oldw || h != oldh)) {
            this.viewWidth = w
            this.viewHeight = h
            this.progressHeight = (viewHeight * PROGRESS_SIZE_RATIO).toInt()
            this.progressWidth = progressHeight
            val iconCornerPx = DisplayUtil.dip2px(context, ICON_CORNER_RADIUS_DP).toFloat()
            this.mCornerRadius = iconCornerPx
            this.mOuterRect = RectF(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat())
            this.mClipPath = Path().apply {
                addRoundRect(mOuterRect, iconCornerPx, iconCornerPx, Path.Direction.CW)
            }


            // Reset cached rects to force recalculation on next draw
            this.progressRect = null
            this.pauseDstRect = null
            this.downloadedDstRect = null
            this.bgDstRect = null
        }
    }

    protected override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (status < 0) {
            return
        }
        val clipSaveCount = canvas.save()
        if (clipToIconShape) {
            canvas.clipPath(mClipPath)
        }
        canvas.setDrawFilter(pfd) //去锯齿

        if (status == STATUS_PAUSE) {
            if (bitmapPause == null || bitmapPause!!.isRecycled()) {
                bitmapPause =
                    BitmapFactory.decodeResource(getResources(), R.drawable.shortcut_icon_pause)
            }
            if (pauseSrcRect == null) {
                pauseSrcRect = Rect(0, 0, bitmapPause!!.getWidth(), bitmapPause!!.getHeight())
            }
            if (pauseDstRect == null) {
                pauseDstRect = Rect(
                    (viewWidth - progressWidth) / 2, (viewHeight - progressHeight) / 2,
                    (viewWidth + progressWidth) / 2, (viewHeight + progressHeight) / 2
                )
            }
            canvas.drawBitmap(bitmapPause!!, pauseSrcRect, pauseDstRect!!, mPaint)
        } else if (status == STATUS_DOWNLOADED) {
            if (bitmapDownloaded == null || bitmapDownloaded!!.isRecycled()) {
                bitmapDownloaded = BitmapFactory.decodeResource(
                    getResources(),
                    R.drawable.shortcut_icon_downloaded
                )
            }
            if (downloadedSrcRect == null) {
                downloadedSrcRect =
                    Rect(0, 0, bitmapDownloaded!!.getWidth(), bitmapDownloaded!!.getHeight())
            }
            if (downloadedDstRect == null) {
                downloadedDstRect = Rect(
                    (viewWidth - progressWidth) / 2, (viewHeight - progressHeight) / 2,
                    (viewWidth + progressWidth) / 2, (viewHeight + progressHeight) / 2
                )
            }
            canvas.drawBitmap(bitmapDownloaded!!, downloadedSrcRect, downloadedDstRect!!, mPaint)
        } else if (STATUS_DOWNING == status || FileDownloadInfo.STATUS_NETWORK_ERROR == status) {
            if (progressRect == null) {
                progressRect = RectF(
                    (viewWidth - progressWidth) / 2f, (viewHeight - progressHeight) / 2f,
                    (viewWidth + progressWidth) / 2f, (viewHeight + progressHeight) / 2f
                )
            }
            mPaint.setColor(progressColor)
            if (status == STATUS_WAIT && progress == 0f) {
                canvas.drawArc(progressRect!!, -(90 - startAngle), 360 - startAngle, true, mPaint)
            } else if (progress == 0f) {
                canvas.drawRoundRect(mOuterRect, mCornerRadius, mCornerRadius, mAlphaColorPaint)
                restoreClip(canvas, clipSaveCount)
                return
            } else {
                if (silentInstall) {
                    //静默安装手机，下载占位、安转中占位各十六分之一
                    canvas.drawArc(
                        progressRect!!,
                        (360 - startAngle * 2) * progress - (90 - startAngle),
                        (360 - startAngle * 2) * (1 - progress) + startAngle,
                        true,
                        mPaint
                    )
                } else {
                    //无静默安装手机，下载占位十六分之一
                    canvas.drawArc(
                        progressRect!!,
                        (360 - startAngle) * progress - (90 - startAngle),
                        (360 - startAngle) * (1 - progress),
                        true,
                        mPaint
                    )
                }
            }
        } else if (STATUS_INSTALLING == status) {
            if (progressRect == null) {
                progressRect = RectF(
                    (viewWidth - progressWidth) / 2f, (viewHeight - progressHeight) / 2f,
                    (viewWidth + progressWidth) / 2f, (viewHeight + progressHeight) / 2f
                )
            }
            mPaint.setColor(progressColor)
            canvas.drawArc(progressRect!!, 270 - startAngle, startAngle, true, mPaint)
        } else if (STATUS_WAIT == status) {
            canvas.drawRoundRect(mOuterRect, mCornerRadius, mCornerRadius, mAlphaColorPaint)
            restoreClip(canvas, clipSaveCount)
            return
        }

        if (bitmapBg == null || bitmapBg!!.isRecycled()) {
            bitmapBg = BitmapFactory.decodeResource(getResources(), R.drawable.cloud_icon_status_new_bg)
        }
        if (bgSrcRect == null) {
            bgSrcRect = Rect(0, 0, bitmapBg!!.getWidth(), bitmapBg!!.getHeight())
        }
        if (bgDstRect == null) {
            bgDstRect = Rect(0, 0, viewWidth, viewHeight)
        }
        mPaint.setColor(Color.parseColor("#000000"))
        canvas.drawBitmap(bitmapBg!!, bgSrcRect, bgDstRect!!, mPaint)
        restoreClip(canvas, clipSaveCount)
    }

    fun setClipToIconShape(clip: Boolean) {
        if (clipToIconShape == clip) {
            return
        }
        clipToIconShape = clip
        invalidate()
    }

    private fun restoreClip(canvas: Canvas, saveCount: Int) {
        canvas.restoreToCount(saveCount)
    }

    fun setStatus(status: Int, invalidate: Boolean) {
        this.status = status
        if (invalidate) {
            postInvalidate()
        }
    }

    fun setProgress(progress: Float) {
        this.progress = progress
        //setStatus(STATUS_DOWNING, false);
        postInvalidate()
    }

    companion object {
        private const val STATUS_WAIT = 1 //排队等待下载
        private const val STATUS_DOWNING = 2 //下载中
        private const val STATUS_PAUSE = 3 //暂停中
        private const val STATUS_DOWNLOADED = 4 //待安装
        private const val STATUS_INSTALLING = 11 //安装中

        const val DOWNLOAD_CORNER_RADIUS_RATIO: Float = 0.33f
        // 暂停/安装图标中心区域占整个 View 的比例 (与上方 DownloadStatusView 的 30dp/56dp 一致)
        private const val PROGRESS_SIZE_RATIO: Float = 0.535f
        // 与 CloudBottomAppInfoAdapter 中 Glide RoundedCorners 保持一致
        private const val ICON_CORNER_RADIUS_DP: Float = 15f
        private const val TAG: String = "BottomStatusView"
    }
}

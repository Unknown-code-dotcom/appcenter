package com.afmobi.palmplay.configs;

public class FireBaseConfig {
    public String countryCode;  // 国家码
    public String channelType;  // 渠道信息
    public boolean domainToIpSwitched = false; // 域名转IP抓取开关
    public boolean domainConnectTimeSwitched = false; // 下载联网时间抓取开关
    public int connectTimeout = 30;
    public String forbidVer;  // 禁止domainToIp的版本7.1.x,7.2.1 多个版本用逗号隔开
}

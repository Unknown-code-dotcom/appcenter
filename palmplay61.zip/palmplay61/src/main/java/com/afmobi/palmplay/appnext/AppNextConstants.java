package com.afmobi.palmplay.appnext;

/**
 * @author: zhiqiang.hao
 * @date: 2021/4/15 16:56
 * @Desc: add your description
 */
public interface AppNextConstants {

    int APP_NEXT_MAX_RETRY_COUNT = 20;
    int APP_NEXT_CACHE_TIME_OUT = 48 * 60 * 60 * 1000;

    String ITEM_SHOW = "_show";
    String ITEM_CLICK = "_click";

}

package com.afmobi.palmplay.cache.v6_4;

import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.transsion.palmstorecore.log.LogUtils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by sk on 17-5-18.
 */

public class DownloadRecommendCache {

    private static volatile DownloadRecommendCache instance;


    private static byte[] lock = new byte[0];

    private List<RankDataListItem> mList;
    private List<RankDataListItem> backupList;

    private DownloadRecommendCache() {

    }

    public static DownloadRecommendCache getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new DownloadRecommendCache();
                }
            }
        }
        return instance;
    }

    public void release() {
        if (mList != null) {
            mList.clear();
            mList = null;
        }

        if (backupList != null) {
            backupList.clear();
            backupList = null;
        }
        instance = null;
    }

    public void initPageCaches(JsonObject jo) {
        if (mList != null) {
            mList.clear();
            mList = null;
        }

        if (jo != null) {
            try {
                if (jo.has("itemList")) {
                    JsonArray itemListJsonArray = jo.getAsJsonArray("itemList");
                    if (itemListJsonArray != null) {
                        Type type = new TypeToken<List<RankDataListItem>>() {
                        }.getType();
                        mList = new Gson().fromJson(itemListJsonArray, type);
                    }
                }
            } catch (Exception e) {
                LogUtils.e(e);
            }
        }
    }

    public void saveListData(List<RankDataListItem> list) {
        if (mList != null) {
            mList.clear();
            mList = null;
        }
        mList = list;
    }

    public List<RankDataListItem> getData() {
        return mList;
    }


    /**
     * 存放备份数据；
     * @param list
     */
    public void setBackupList(List<RankDataListItem> list) {
        if (list == null || list.size() == 0) {
            return;
        }
        if (backupList == null) {
            backupList = new ArrayList<>(list.size());
        }
        backupList.clear();
        backupList.addAll(list);
    }

    /**
     * 取备份数据
     * @return
     */
    public RankDataListItem getBackupItem() {
        if (backupList == null || backupList.size() == 0) {
            return null;
        }

        RankDataListItem item = null;
        Iterator<RankDataListItem> iterator = backupList.iterator();
        while (iterator.hasNext()) {
            item = iterator.next();
            DownloadStatusManager.getInstance().registerInfoInstance(item);
            if(item.observerStatus == FileDownloadInfo.STATUS_NONE || item.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE) {
                iterator.remove();
                break;
            } else {
                iterator.remove();
                item = null;
            }
        }
        return item;
    }
}

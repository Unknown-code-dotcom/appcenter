package com.afmobi.palmplay.clean;

import com.transsion.palmstorecore.util.ToastManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.text.TextUtils;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.home.TRHomeUtil;
import com.afmobi.palmplay.home.TRToolsTabFragment;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.keeptojosn.CacheListItem;
import com.afmobi.palmplay.model.v6_6.ScanResult;
import com.afmobi.palmplay.service.CleanNativeMemoryService;
import com.afmobi.palmplay.service.PalmstoreService;
import com.afmobi.palmplay.startup.MeConfigInfo;
import com.afmobi.palmplay.startup.MeSwitch;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.TRPermissionUtil;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.io.File;

import de.greenrobot.event.EventBus;

public class ScanManager implements CleanNativeMemoryService.OnScanEventListener {
    public static String KV_LAST_TIME_JUNK_CLEAN = "meJunkCleanLastTime";//定时扫描缓存垃圾,上次时间
    private static volatile ScanManager sInstance;

    private PmScanAndCleanImpl pmScanAndClean;
    private boolean mIsUsePmClean;
    private ScanResult mScanResult;
//    private long waitingCleanCacheSize;

    private CleanServiceConnection mCleanServiceConnection;
    private CleanNativeMemoryService cleanService;

    public static ScanManager getInstance() {
        if (sInstance == null) {
            synchronized (ScanManager.class) {
                if (sInstance == null) {
                    sInstance = new ScanManager();
                }
            }
        }
        return sInstance;
    }

    public void scan(){
        // 控制调用频率
        long lastJunkCleanTime = SPManager.getLong(KV_LAST_TIME_JUNK_CLEAN, 0);
        if (Math.abs(System.currentTimeMillis() - lastJunkCleanTime) > MeSwitch.getMeJunkCleanTime() * 60 * 60 * 1000L){
            boolean hasPermissions = TRPermissionUtil.hasExternalStoragePermission();
            if (hasPermissions) {
                initScan();
                SPManager.putLong(KV_LAST_TIME_JUNK_CLEAN, System.currentTimeMillis());
            }
        }
    }

    public void scanNoTime(){
        boolean hasPermissions = TRPermissionUtil.hasExternalStoragePermission();
        if (hasPermissions) {
            initScan();
        }
    }

    private void initScan() {
        mIsUsePmClean = isCanUsePmScan();

        if (mIsUsePmClean) {
            if (BuildConfig.DEBUG){
                LogUtils.d("ScanManager----PmScanAndCleanImpl.getInstance");
            }
            pmScanAndClean = PmScanAndCleanImpl.getInstance();
            pmScanAndClean.addOnScanEventListener(this, this);
            pmScanAndClean.setOnCleanUpEventListener(new OnCleanUpEventListener() {
                @Override
                public void onCleanUpEvent(boolean isSuc) {
                    LogUtils.d("on Junk Files pm cleanup event callback, isSuc:" + isSuc);
                    if (!isSuc) {
                        mIsUsePmClean = false;
                        mCleanServiceConnection = new CleanServiceConnection();
                        PalmplayApplication.getAppInstance().bindService(new Intent(PalmplayApplication.getAppInstance(), CleanNativeMemoryService.class),
                                mCleanServiceConnection, Context.BIND_AUTO_CREATE);
                    }
                }
            });
            pmScanAndClean.initPmService();
        } else {
            if (BuildConfig.DEBUG){
                LogUtils.d("ScanManager----CleanServiceConnection");
            }
            mCleanServiceConnection = new CleanServiceConnection();
            PalmplayApplication.getAppInstance().bindService(new Intent(PalmplayApplication.getAppInstance(), CleanNativeMemoryService.class),
                    mCleanServiceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    @Override
    public void onScanStart() {
        if (BuildConfig.DEBUG){
            LogUtils.d("ScanManager----onScanStart");
            ToastManager.getInstance().showL(PalmplayApplication.getAppInstance(), "垃圾扫描开始");
        }
    }

    @Override
    public void onScanProgressUpdate(ScanResult scanResult, CacheListItem item) {
        if (BuildConfig.DEBUG){
            LogUtils.d("ScanManager----onScanProgressUpdate" + scanResult.toString());
        }
    }

    @Override
    public void onScanComplete(long cacheSize, ScanResult scanResult) {
        long waitingCleanCacheSize = 0;
        if (scanResult == null) {
            scanResult = new ScanResult();
        }

        if (!mIsUsePmClean) {
            long apkFilesSize = 0;
            if (null != scanResult.getApkList()) {
                for (CacheListItem apk : scanResult.getApkList()) {
                    if (apk.isSelected()) {
                        if (!TextUtils.isEmpty(apk.apkPath)) {
                            File file = new File(apk.apkPath);
                            if (file.exists()) {
                                apkFilesSize += apk.getSize();
                            }
                        }
                    }
                }
            }
            scanResult.apkFilesSize = apkFilesSize;
        }

        mScanResult = scanResult;
        if (mIsUsePmClean) {
            waitingCleanCacheSize = mScanResult.cacheSize + mScanResult.uninstallSize + mScanResult.apkFilesSize
                    + mScanResult.systemCacheSize;
        }else {
            waitingCleanCacheSize = mScanResult.cacheSize + mScanResult.uninstallSize + mScanResult.apkFilesSize;
        }
        // 存储扫描的大小
        SPManager.putLong(TRToolsTabFragment.KEY_MEMORY_CLEAN_CHECK_SIZE, waitingCleanCacheSize);
        if (BuildConfig.DEBUG){
            LogUtils.d("CleanPage----ScanManager----onScanComplete: " + mIsUsePmClean +
                    "----:" + waitingCleanCacheSize
                    + "----: "+ mScanResult.toString());
            ToastManager.getInstance().showL(PalmplayApplication.getAppInstance(), "垃圾扫描结束,一共："+ waitingCleanCacheSize);
        }

        int cleanSize = TRHomeUtil.checkJunkClean();
        if (cleanSize>0) {

            EventMainThreadEntity eventMainThreadEntity = new EventMainThreadEntity();
            eventMainThreadEntity.setAction(TRToolsTabFragment.ACTION_CLEAN_MEMORY_PAGE_RESULT);
            EventBus.getDefault().post(eventMainThreadEntity);
            TRHomeUtil.updateLaunchIconRedTips(true, "Scan", "time");
        }
    }

    @Override
    public void onCleanStart() {
        if (BuildConfig.DEBUG){
            LogUtils.d("ScanManager----onCleanStart");
        }
    }

    @Override
    public void onCleanComplete(long cacheSize) {
        SPManager.putLong(TRToolsTabFragment.KEY_MEMORY_CLEAN_CHECK_SIZE, 0);//todo 内存已清理
        String cleanedJunkFilesSize = ProcessAndMemoryUtil.formatSizeKbMbGb(cacheSize, 0);
        ProcessAndMemoryUtil.saveDeepCleanResult(cleanedJunkFilesSize);
        if (BuildConfig.DEBUG){
            LogUtils.d("ScanManager----onCleanComplete");
        }
    }

    private class CleanServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            cleanService = ((CleanNativeMemoryService.MyBinder) service).getService();
            cleanService.addOnScanEventListener(ScanManager.this);
            cleanService.startScan();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            ScanManager.this.onServiceDisconnected();
        }
    }

    private void onServiceDisconnected(){
        if(cleanService != null){//避免把service的其它调用者的listener覆盖了
            cleanService.removeOnScanEventListener(ScanManager.this);
        }
        cleanService = null;
    }

    private boolean isCanUsePmScan() {
        boolean isSupport = CommonUtils.isSupportPMCleanup();

        return isSupport;
    }
}

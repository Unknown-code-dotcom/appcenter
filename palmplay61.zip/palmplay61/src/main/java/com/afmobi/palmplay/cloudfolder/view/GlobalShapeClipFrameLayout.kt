package com.afmobi.palmplay.cloudfolder.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Path
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.core.graphics.PathParser
import com.transsion.palmstorecore.log.LogUtils

/** Clips all icon layers to the global launcher icon shape without rasterizing animations. */
class GlobalShapeClipFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private var shapePathData: String? = null
    private var sourceShapePath: Path? = null
    private var clippedShapePath: Path? = null

    fun setGlobalIconShapePath(pathData: String?) {
        val normalizedPath = pathData?.takeIf { it.isNotBlank() }
        if (shapePathData == normalizedPath) {
            return
        }
        shapePathData = normalizedPath
        sourceShapePath = parseShapePath(normalizedPath)
        updateClippedShapePath()
        invalidate()
    }

    override fun onSizeChanged(width: Int, height: Int, oldWidth: Int, oldHeight: Int) {
        super.onSizeChanged(width, height, oldWidth, oldHeight)
        updateClippedShapePath()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val clipPath = clippedShapePath
        if (clipPath == null) {
            super.dispatchDraw(canvas)
            return
        }
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(saveCount)
    }

    private fun parseShapePath(pathData: String?): Path? {
        if (pathData.isNullOrBlank()) {
            return null
        }
        return try {
            PathParser.createPathFromPathData(pathData)
        } catch (exception: RuntimeException) {
            LogUtils.e(TAG, "parse global icon shape failed: path=$pathData", exception)
            null
        }
    }

    private fun updateClippedShapePath() {
        val path = sourceShapePath
        if (path == null || width <= 0 || height <= 0) {
            clippedShapePath = null
            return
        }
        clippedShapePath = Path(path).apply {
            transform(
                Matrix().apply {
                    setScale(width / SHAPE_VIEWPORT_SIZE, height / SHAPE_VIEWPORT_SIZE)
                }
            )
        }
    }

    private companion object {
        const val SHAPE_VIEWPORT_SIZE = 100f
        const val TAG = "GlobalShapeClipFrame"
    }
}

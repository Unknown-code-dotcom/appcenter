package com.afmobi.palmplay.admgr.ownad;

public abstract class OwnAdLoadListener {

    public static final int AD_ERROR_NET = 200;
    public static final int AD_ERROR_URL = 201;
    public static final int AD_ERROR_EXPIRED = 202;
    public static final int AD_ERROR_UNKNOWN = 203;



    public abstract void onOwnAdLoaded(Object object);

    public abstract void onOwnAdError(int var);

    public abstract void onShow();

    public abstract void onClicked(Object object);

    public void onClosed() {}

    public void onSkipAd(Object object) {}

    public void onTimeReach() {}

}

package com.afmobi.palmplay.activate;

/***
 * created by yongli.li
 * 活动相关的常量都在此处定义
 */
public class TRActivateConstant {
    /*** 主活动类型 ***/
    public final static String SPLASH_AD = "splash_ad";//开屏页活动
    public final static String TIP_ACTIVATE = "tips";//首页活动的四个类型的活动
    public final static String NAV_BAR_ACTIVATE = "nav_bar_activite";//tab的活动
    public final static String ACTIVITY_CENTER_TAB = "activityCenterTab";//活动中心入口
    public final static String GIFTS_CENTER_TAB = "GiftsCenterTab";//活动中心入口
    public final static String GIFTS_COUPON_TAB = "GiftsCouponTab";//福利中心——优惠券
    public final static String GIFT_CENTER = "GiftCenter";//福利中心入口
    public final static String HOME_BANNER = "home_banner";//首页banner的活动
    public final static String RACE_LAMP = "race_lamp";//首页权益触达，跑马灯
    public final static String TOOL_SUDOKU = "tool_sudoku";//工具页九宫格

    public final static String HOME_ICON = "home_icon";//首页四个运营位
    public final static String HOME_LIST_BANNER = "home_list_banner";//首页list的banner的活动
    public final static String GIFT_RAIN = "gift_rain";//红包雨的活动
    public final static String SEARCH_TAG = "search_tag";//搜索页tag点击
    public final static String PUSH = "push";//push业务
    public final static String SEARCH_BANNER = "search_banner";//搜索页banner活动

    public final static String HOME_LIST_BANNER_NEW = "home_list_banner_new";//首页list的banner的活动
    public final static String TOOLBAR_ICON = "toolbar_icon";//常驻通知四个运营位
    public static final String TOOLS = "TOOLS";//跳转tools
    public final static String HOME_BIG_ICON_BANNER = "home_big_icon_banner";//首页大图双图标活动
    public final static String HOME_ITEM = "home_item_jump";//上新日历(视频或Banner大卡样式)的跳转

    public final static String HOME_SHORT_BANNER = "home_short_banner";//首页 short banner活动
    public final static String DETAIL_SHORT_BANNER = "detail_short_banner";//首页 short banner活动
    public final static String HOME_BANNER_TITLE = "home_banner_title";//推文横滑大卡活动


    /*** 主活动的子活动类型 ***/
    public final static String TIP_SUB_BANNER = "BANNER";//tip活动下banner活动类型
    public final static String TIP_SUB_PROMPT = "PROMPT";//tip活动下的promopt活动类型
    public final static String TIP_SUB_FLOAT = "FLOAT";//tip活动下的悬浮类型
    public final static String TIP_SUB_BUBBLE = "BUBBLE";//tip活动下的气泡类型

    /*** 活动跳转类型***/
    public static final String RANK = "RANK";//专题；
    public static final String SYS_APP_RANK = "SYS_APP_RANK";//tool页面九宫格system app专题；
    public static final String INNER_URL = "INNER_URL";//h5界面
    public static final String ITEM = "ITEM";//应用详情页;
    public static final String ACTIVITY_CENTER = "ActivityCenter";//活动中心页面;
    public static final String GIFTS_CENTER = "GiftsCenter";//福利中心页面;
    public static final String OUTER_URL = "OUTER_URL";//外链;
    public static final String FIND = "FIND";//find界面
    public static final String FIND_DETAIL = "FIND_DETAIL";//find详情页
    public static final String LIST = "LIST";//榜单
    public static final String REC_COLLECTION = "Collections";//推荐合集
    public static final String APP_CATEGORY = "APP_CATEGORY";//app tab
    public static final String GAME_CATEGORY = "GAME_CATEGORY";//game tab
    public static final String DEEP_LINK = "DEEP_LINK";//deeplink
    public static final String MINI_APP = "MINI_APP";//MiniApp

    public static final String JUMP_TYPE_DEEPLINK = "1";//推必达自有通道,走deeplink方式

    public static final String GAME_HALL = "GAME_HALL";//游戏大厅
    public static final String GP_LINK = "GP_LINK";//跳转gp
    public static final String OS_APK_ZIP_UPDATE = "OS_UPDATE";//跳转os小包升级
    public static final String STATUS_SAVER = "STATUS_SAVER";// Whatsapp status saver
    public static final String VABOX= "VABOX";//VA盒子;
    public static final String H5_GAME= "H5_GAME";//H5游戏类型;
    public static final String EBOOKS= "EBOOKS";//EBooks类型;
    public static final String MINI_APP_RICH= "MINI_APP_RICH";//新的小程序，PS内部集成
    public static final String AI_PETS = "AI_PETS";//跳转 AIPetSDK
    public static final String SET_LANG = "LANGUAGE_SETTING";//跳转语言设置页

    /*** 活动通知所需要的EventBus的action ***/
    public static final String SHOW_ACTION = "show_action";
    public static final String SHOW_ACTION_GAMEHALL = "game_show_action";
    public static final String ACTIVATE_TYPE = "activateType";//一级活动
    public static final String SUB_ACTIVATE_TYPE = "subActivateType";//子活动
    public static final String SHOW_ACTIVATE_PROMOTE = "showPrommote";//显示活动弹框的action
    public static final String SHOW_ACTIVATE_ITEM = "showItem";//活动相关数据

    /*** 活动请求时间 ***/
    public static final String TIP_AD_LOADTIME = "tip_ad_loadtime";//应用内四种活动类型最近一次捞取成功得时间

    public static final String TIP_ADS_IS_EMPTY = "tip_ads_is_empty";
    public static final String TIP_AD_CFG_LOAD_TIME_INTERVAL = "tip_ad_cfg_load_time_interval";
    public static final String TIP_AD_CFG_RELOAD_TIME_INTERVAL = "tip_ad_cfg_reload_time_interval";
    public static final String TIP_AD_SHOWTIME = "tip_ad_showtime";//应用内四种活动类型最近一次展示的时间
    public static final String NAV_AD_LOADTIME = "nav_ad_loadtime";//底部tab活动最近一次捞取成功得时间

    /*** 展示的常量值 ***/
    public static final int SHOWED = 1;//已经显示
    public static final int NEED_SHOW = 0;//待显示

    /*** 业务类型 ***/
    public static final int FROM_UPDATE = 0;//升级
    public static final int FROM_MUST_INSTALL = 1;//装机必备
    public static final int FROM_RECOM_INSTALL = 2;//一键安装
    public static final int FROM_ACTIVATE = 3;//活动弹框
    public static final int FROM_NOTIFICATION_TOGGLE = 4;//通知栏开关
    public static final int FROM_SPLASH_AD= 5;//开屏广告
    public static final int FROM_SPACE_LIMIT = 6;//下载安装空间不足
    public static final int FROM_GIFT_RAIN = 7;//红包雨
    public static final int FROM_FILE_FOLDER = 8;//云文件夹

    public static final int FROM_WIDGET =9;//小组件

    /*** show的入口来源 ***/
    public static final String FROM_HOME = "fromHome";//刚启动的home页面
    public static final String FROM_SCROLL = "fromScroll";//首页列表第一次滑动
    public static final String FROM_TAB_SWITCH = "fromTabSwitch";//tab切换
    public static final String FROM_CALLBACK = "fromCallback";//callBack回来的
    public static final String FROM_BACKGROUND_TO_FOREGROUND = "fromBgToFore";

    public static final String TAB_TOOLS_CONFIG = "tabToolsConfig";//Gt 常驻通知拦截配置


//    GT 专项
    public static final String GT_INSTALL_COMPLETE_NOT_FLOAT = "GTInstallCompleteNoFloat";//Gt 安装完成拦截配置
    public static final String GT_CLEAR_SPACE_NOT_FLOAT = "GTClearSpaceNoFloat";//Gt 空间不足
    public static final String GT_RECALL_NOT_FLOAT = "GTRecallNoFloat";//Gt 沉默用户召回
    public static final String GT_OFFLINE_NOT_FLOAT = "GTOfflineNoFloat";//Gt 离线通知


    public static final String GT_COMMON_NOTIFICATION= "GTCommonNotification";//Gt 普通通知开关
    public static final String GT_INSTALL_COMPLETE= "GTInstallCompleteNotification";//Gt 安装完成通知开关

    public static final String GT_TOOL_BAR_NOTIFY = "GTToolBarNotify";//Gt 常驻通知拦截配置

    public static final String GT_GUIDE = "GTGuide";//Gt 新手一键装机拦截配置
    public static final String GT_OLD_GUIDE = "GTOldGuide";//Gt 老手一键装机拦截配置
    public static final String GT_LAUNCHER_READ_DOT_TIPS = "GTLauncherRedDotTips";//Gt 桌面角标拦截配置

    public static final String EW_SPLASH_TYPE = "ew_splash_type";

}

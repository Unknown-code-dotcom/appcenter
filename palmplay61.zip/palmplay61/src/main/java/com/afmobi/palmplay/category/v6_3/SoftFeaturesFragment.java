package com.afmobi.palmplay.category.v6_3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.main.adapter.v6_3.CommonSoftRecyclerAdapter;
import com.afmobi.palmplay.main.v6_7.NetworkChangeListener;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.util.IMessenger;
import com.afmobi.util.NetworkUtils;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRStringUtil;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import java.lang.ref.WeakReference;

/**
 * GAME、APP tab下点击more跳转到的专题 页
 * Created by lenovo on 2016-11-17.
 */
public class SoftFeaturesFragment extends BaseFeaturesFragment<AppInfo> {

    private CommonSoftRecyclerAdapter mCommonSoftRecyclerAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBaseFeaturesViewModel.setScreenPageName(TRAnalyticsConstant.MORE_PAGE);
    }

    @Override
    protected void refreshData() {
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.setData(mBaseFeaturesViewModel.getDataList());
    }

    @Override
    protected String getTabType() {
        return TabType.SOFT;
    }


    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);

        mCommonSoftRecyclerAdapter = new CommonSoftRecyclerAdapter(getActivity(), mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview, mBaseFeaturesViewModel.getFromPage(), mPageParamInfo);
        mCommonSoftRecyclerAdapter.setScreenPageName(TRAnalyticsConstant.MORE_PAGE);
        mCommonSoftRecyclerAdapter.setFeatureName(mBaseFeaturesViewModel.getFeatureName());
        mCommonSoftRecyclerAdapter.setFrom(mBaseFeaturesViewModel.getFrom());
        mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.setAdapter(mCommonSoftRecyclerAdapter);
        RecyclerView.ItemAnimator itemAnimator = mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.getItemAnimator();
        if(itemAnimator instanceof SimpleItemAnimator) {
            SimpleItemAnimator simpleItemAnimator = (SimpleItemAnimator) itemAnimator;
            simpleItemAnimator.setSupportsChangeAnimations(false);
        }
        mCommonSoftRecyclerAdapter.setOnViewLocationInScreen(this);
        mCommonSoftRecyclerAdapter.onCreateView();
        mCommonSoftRecyclerAdapter.setIMessenger(new IMessenger() {

            @Override
            public void onMessenger(Object... objects) {
                setUpdatedAppCount();
            }
        });

        addNoMore(mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview, (LinearLayoutManager) mFragmentCommonTypeMoreXrecyviewBinding.xrecyclerview.getLayoutManager(), null);

        init();

        return viewRoot;
    }


    @Override
    public void onResume() {
        super.onResume();
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onResume();

        if (!isRequesting) {
            mUILoadingGifUtil.setVisibility(View.GONE);
        }
        setUpdatedAppCount();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mCommonSoftRecyclerAdapter != null)
            mCommonSoftRecyclerAdapter.onDestroy();

    }

    @Override
    public void backButtonPressed() {
        String value = TRStringUtil.generateString(TRAnalyticsConstant.MORE_PAGE, "","", "");
        ComponentClickBuilder builder = new ComponentClickBuilder();
        builder.setValue(value)
                .setFrom(mBaseFeaturesViewModel.getFrom())
                .setTopicType(mBaseFeaturesViewModel.getName())
                .setTopicId(mBaseFeaturesViewModel.getRankID())
                .setItemType("")
                .setItemId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                .setItemValue("")
                .setExtraValue("");
        TRAnalysticsUtil.trackClick(builder);
    }

}

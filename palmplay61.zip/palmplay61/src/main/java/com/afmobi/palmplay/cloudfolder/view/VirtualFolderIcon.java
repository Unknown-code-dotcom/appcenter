package com.afmobi.palmplay.cloudfolder.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.afmobi.palmplay.cloudfolder.CloudFolderManager;
import com.afmobi.palmplay.cloudfolder.config.CloudPreviewBean;
import com.afmobi.palmplay.cloudfolder.utils.DeviceProfile;
import com.afmobi.util.DisplayUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

public class VirtualFolderIcon extends Drawable {

    private static final String TAG = "VirtualFolderIcon ";

    private Context mContext;

    private Drawable mBGDrawable = null;

    private int folderPreviewNum;

    private int thumbPadding;

    private int iconSize;

    private int previewPadding;

    private ArrayList<CloudPreviewBean> drawables;


    private PreviewItemDrawingParams mParams = new PreviewItemDrawingParams(0, 0, 0, 0);
    private boolean iconMaskShow;
    private float cloudFolderDownAlpha;

    private boolean isShortcutSplit;

    private float itemZoom;

    public VirtualFolderIcon(Context context) {
        mContext = context;
        isShortcutSplit = CloudFolderManager.Companion.getInstance().isShortcutSplit();
    }

    public void init(List<CloudPreviewBean> drawableList) {
        DeviceProfile deviceProfile = DeviceProfile.Companion.getInstance();
        folderPreviewNum = 9;
        thumbPadding = deviceProfile.getFolderIconPreviewPadding();
        if(isShortcutSplit) {
            iconSize = DisplayUtil.dip2px(mContext, 80f);
            previewPadding = mContext.getResources().getDimensionPixelSize(R.dimen.dp_8);
            mBGDrawable = ContextCompat.getDrawable(TRApplicationContextUtil.getInstance(), R.drawable.cloud_folder_shortcut_default_bg);
            itemZoom = 0.91f;
        } else {
            iconSize = DisplayUtil.dip2px(mContext, 54f);
            previewPadding = mContext.getResources().getDimensionPixelSize(R.dimen.dp_7);
            mBGDrawable = ContextCompat.getDrawable(TRApplicationContextUtil.getInstance(), R.drawable.bg_cloud_folder_preview);
            itemZoom = 0.89f;
        }
//        XLog.d(TAG + mResName + ", iconSize=" + iconSize + ",folderPreviewNum=" + folderPreviewNum);
//        drawables = getDrawables(cn, mResName, iconSize, mContext, folderPreviewNum);
        drawables = getDrawables(drawableList);
//        mBGDrawable = new BitmapDrawable(mContext.getResources(), BitmapFactory.decodeResource(TRApplicationContextUtil.getInstance().getResources(), R.drawable.x_portal_ring_inner));
//        mBGDrawable = BitmapFactory.decodeResource(TRApplicationContextUtil.getInstance().getResources(), R.drawable.x_portal_ring_inner);

//        mBGDrawable = new BitmapDrawable(TRApplicationContextUtil.getInstance().getResources(),bitmap);

        mBGDrawable.setBounds(0, 0, iconSize, iconSize);

        iconMaskShow = CloudFolderManager.Companion.getInstance().isIconMaskShow();
        cloudFolderDownAlpha = CloudFolderManager.Companion.getInstance().getCloudFolderDownAlpha();

    }

    private ArrayList<CloudPreviewBean> getDrawables(List<CloudPreviewBean> originDrawables) {
        try {
            Rect bound = null;
            int count = Math.min(originDrawables.size(), 9);
            for (int i = 0; i < count; i ++) {
                CloudPreviewBean previewBean = originDrawables.get(i);
                Drawable drawable = previewBean.getPreviewDrawable();
                if(drawable == null) {
                    continue;
                }
                if (bound == null) {
                    bound = new Rect(0, 0, iconSize, iconSize);
                }
//                if (changeTheme) {
//                    drawable = new BitmapDrawable(res,
//                            XThemeAgent.getInstance().getThemeIcon(context, null, drawable, iconSize, iconSize));
//                }
                drawable.setBounds(bound);
                drawable.mutate();
            }
            return new ArrayList<>(originDrawables);
        } catch (Exception e) {
            LogUtils.e(TAG + "getDrawables:" + e);
        }
        return null;
    }

    @Override
    public void draw(@NonNull Canvas canvas) {

        if(isShortcutSplit) {
            if (mBGDrawable != null) {
                mBGDrawable.draw(canvas);
            }
        }

        if(drawables == null || drawables.isEmpty()) {
            return;
        }
        int nItemsInPreview = Math.min(drawables.size(), folderPreviewNum);

        for (int i = 0; i < nItemsInPreview; i++) {
            mParams = computePreviewItemDrawingParams(i, mParams);
            CloudPreviewBean previewBean = drawables.get(i);
            mParams.drawable = previewBean.getPreviewDrawable();
            mParams.isShowMask = previewBean.isShowMask();
            drawPreviewItem(canvas, mParams);
        }
    }

    private void drawPreviewItem(Canvas canvas, PreviewItemDrawingParams params) {
        canvas.save();
        canvas.translate(params.transX + previewPadding, params.transY + previewPadding);
        canvas.scale(params.scale, params.scale);
        Drawable d = params.drawable;
        if (d != null) {
            //不再频繁改变bounds来进行适配
            canvas.save();
            Rect bounds = d.getBounds();
            if (bounds.width() != 0 && bounds.height() != 0) {
                canvas.translate(-bounds.left, -bounds.top);
                canvas.scale(getIntrinsicWidth() / bounds.width() * itemZoom, getIntrinsicHeight() / bounds.height() * itemZoom);
            }
            if(iconMaskShow && params.isShowMask) {
                float alpha = cloudFolderDownAlpha;
                if(alpha > 0 && alpha <= 1) {
                    PorterDuffColorFilter colorFilter = new PorterDuffColorFilter(Color.argb(alpha, 0, 0, 0), PorterDuff.Mode.SRC_ATOP);
                    d.setColorFilter(colorFilter);
                }
            }
            d.draw(canvas);
            canvas.restore();
        }
        canvas.restore();
    }

    private PreviewItemDrawingParams computePreviewItemDrawingParams(int index,
                                                                     PreviewItemDrawingParams params) {
        float r = (index * 1.0f) / (folderPreviewNum - 1);
        float transY;
        float transX;
        float totalScale;
        final int overlayAlpha = (int) (80 * (1 - r));

        int cellX = (int)Math.sqrt(folderPreviewNum);

        int thumbSize = (int) (((getIntrinsicHeight() - 2 * previewPadding) - (cellX + 1) * thumbPadding) / cellX);
        totalScale = (thumbSize * 1.0f) / getIntrinsicHeight();
        transX = (index % cellX + 1) * thumbPadding + (index % cellX) * thumbSize;
        transY = (index / cellX + 1) * thumbPadding + (index / cellX) * thumbSize;

        if (params == null) {
            params = new PreviewItemDrawingParams(transX, transY, totalScale, overlayAlpha);
        } else {
            params.transX = transX;
            params.transY = transY;
            params.scale = totalScale;
            params.overlayAlpha = overlayAlpha;
        }
        return params;
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
    }

    private int getDrawableWidth(Drawable d) {
        int boundsWidth = d.getBounds().width();
        return boundsWidth != 0 ? boundsWidth : d.getIntrinsicWidth();
    }

    @Override
    public int getIntrinsicWidth() {
        return iconSize;
    }

    @Override
    public int getIntrinsicHeight() {
        return iconSize;
    }

    private Rect clipSquare(Rect rect) {
        int w = rect.width();
        int h = rect.height();
        int min = Math.min(w, h);
        int cx = rect.centerX();
        int cy = rect.centerY();
        int r = min / 2;
        return new Rect(cx - r, cy - r, cx + r, cy + r);
    }

    class PreviewItemDrawingParams {
        PreviewItemDrawingParams(float transX, float transY, float scale, int overlayAlpha) {
            this.transX = transX;
            this.transY = transY;
            this.scale = scale;
            this.overlayAlpha = overlayAlpha;
        }

        float transX;
        float transY;
        float scale;
        int overlayAlpha;
        Drawable drawable;
        boolean isShowMask;
    }

    @Override
    public void setAlpha(int alpha) {

    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return 0;
    }
}

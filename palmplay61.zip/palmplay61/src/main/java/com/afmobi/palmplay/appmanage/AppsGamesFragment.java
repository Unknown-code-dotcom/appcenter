package com.afmobi.palmplay.appmanage;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appmanage.adapter.ManagerAppGamesAdapter;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.pet.manager.XMPetSwitcher;
import com.afmobi.palmplay.va.proxy.VaStaticProxy;
import com.transsion.palmstorecore.thread.TRRunnable;
import com.transsion.palmstorecore.thread.TRRunnableInterface;
import com.transsion.palmstorecore.thread.TRThreadPool;
import com.transsnet.store.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class AppsGamesFragment extends UnInstallAppsFragment {
    private ManagerAppGamesAdapter mPalmPlayManagerAppGamesAdapter;
    //20190722 延迟获取已经安装的app名称。检测应用的名称，如果没有加载就放到子线程加载
    private Handler mCheckInstallHandler;
    private LinearLayout emptyView;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_apps_games_mgr, container, false);
        init(view);
        return view;
    }


    private void init(View view) {
        emptyView = view.findViewById(R.id.uninstall_empty_view);
        List<InstalledAppInfo> result = new ArrayList<>();
        List<InstalledAppInfo> installAppsInfo = InstalledAppManager.getInstance().getInstalledPackageList();
        if (installAppsInfo != null) {
            String petPkg = XMPetSwitcher.getPrimaryApkPck();
            for (InstalledAppInfo info : installAppsInfo) {
                //可卸载列表过滤掉GameSpace和副玩法APK
                if (!VaStaticProxy.isInstantPluginApp(info.packageName)
                        && !(petPkg != null && !petPkg.isEmpty() && petPkg.equals(info.packageName))) {
                    result.add(info);
                }
            }
        }

        if (result == null || result.size() == 0) {
            setEmptyViewCenter(emptyView);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
            mPalmPlayManagerAppGamesAdapter = new ManagerAppGamesAdapter(getActivity()
                    , (RecyclerView) view.findViewById(R.id.manage_install_list_view)
                    , result);
            mPalmPlayManagerAppGamesAdapter.setmFromShare(false);
            mPalmPlayManagerAppGamesAdapter.onCreate();

            mPalmPlayManagerAppGamesAdapter.setPageParamInfo(mPageParamInfo);
        }

        checkAppNameHasLoaded();
    }


    private void checkAppNameHasLoaded() {
        if (mCheckInstallHandler == null) {
            mCheckInstallHandler = new InstalledRefreshHandler(this);
            TRThreadPool.getInstance(TRThreadPool.PRIORITY_LOW).submit(new TRRunnable(new TRRunnableInterface() {
                @Override
                public void doRun() {
                    if (getActivity() == null || getActivity().isFinishing() || getActivity().isDestroyed()) {
                        return;
                    }
                    Boolean needRefresh = false;
                    List<InstalledAppInfo> installedAppInfoList = InstalledAppManager.getInstance().getInstalledPackageList();
                    for (InstalledAppInfo installedAppInfo : installedAppInfoList) {
                        if (!installedAppInfo.hasLoadAppName) {
                            needRefresh = true;
                            try {
                                PackageManager packageManager = PalmplayApplication.getAppInstance().getPackageManager();
                                ApplicationInfo applicationInfo = packageManager.getApplicationInfo(installedAppInfo.packageName, 0);
                                installedAppInfo.appName = applicationInfo.loadLabel(packageManager).toString();
                                installedAppInfo.hasLoadAppName = true;
                            } catch (Exception e) {

                            }
                        }
                    }

                    if (mCheckInstallHandler != null && needRefresh) {
                        mCheckInstallHandler.sendMessage(mCheckInstallHandler.obtainMessage());
                    }
                }
            }));
        }
    }



    private void refreshAppName() {
        if (getActivity() == null || getActivity().isFinishing() || getActivity().isDestroyed()) {
            return;
        }
        if (mPalmPlayManagerAppGamesAdapter != null) {
            mPalmPlayManagerAppGamesAdapter.notifyDataSetChanged();
        }
    }


    public static class InstalledRefreshHandler extends Handler {
        WeakReference<AppsGamesFragment> attachedFragment;

        public InstalledRefreshHandler(AppsGamesFragment fragment) {
            attachedFragment = new WeakReference<>(fragment);
        }

        @Override
        public void handleMessage(Message msg) {
            if (attachedFragment != null) {
                AppsGamesFragment manageInstalledFragment = attachedFragment.get();
                if (manageInstalledFragment != null) {
                    manageInstalledFragment.refreshAppName();
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        TRThreadPool.shutdown();
        if (mPalmPlayManagerAppGamesAdapter != null) {
            mPalmPlayManagerAppGamesAdapter.onDestroy();
        }
        if (mCheckInstallHandler != null) {
            mCheckInstallHandler.removeCallbacksAndMessages(null);
            mCheckInstallHandler = null;
        }
    }
}

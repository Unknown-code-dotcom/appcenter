package com.afmobi.palmplay.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afmobi.palmplay.category.DetailScreenShotActivity;
import com.afmobi.palmplay.main.adapter.EmptyRecyclerViewHolder;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.ScreenShotInfo;
import com.afmobi.palmplay.video.bean.Video;
import com.afmobi.palmplay.video.VideoHelper;
import com.afmobi.palmplay.detail.DetailVideoItemViewHolder;
import com.afmobi.palmplay.mvvm.data.AppDataManager;
import com.afmobi.palmplay.viewmodel.OnShotItemClickListener;
import com.afmobi.palmplay.viewmodel.detail.DetailHShotViewHolder;
import com.afmobi.palmplay.viewmodel.detail.DetailHVideoViewHolder;
import com.afmobi.palmplay.viewmodel.detail.DetailVShotViewHolder;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.bitmap.TRBitmapManager;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.util.ArrayList;
import java.util.List;

import xyz.doikki.videoplayer.player.VideoView;

public class TRAppDetailShotAdapter extends RecyclerView.Adapter implements OnShotItemClickListener{

    public interface OnDetailVideoPlayClickListener {
        void onPlayClick(com.afmobi.palmplay.video.helper.IVideoHolder holder);
    }

    private OnDetailVideoPlayClickListener mOnDetailVideoPlayClickListener;

    public void setOnDetailVideoPlayClickListener(OnDetailVideoPlayClickListener l) {
        this.mOnDetailVideoPlayClickListener = l;
    }
    public static final int VIEW_TYPE_V_SHOT = 0; // 竖屏截图
    public static final int VIEW_TYPE_H_SHOT = 1; // 横屏截图
    public static final int VIEW_TYPE_H_VIDEO = 3; // 横屏带视频的布局

    private List<String> bigImgUrls;
    private List<String> smallImgUrls;
    private int imgWidth, imgHeight;
    private int mCorner = 7;
    private int mLeftMargin = 16;
    private Context mContext;
    private LayoutInflater mInFlater;
    private RecyclerView mRecyclerView;

    private List<ScreenShotInfo> mList;
    private String mName;
    private String mFrom, mScreenPageName, mFeaturedName;
    private AppInfo mAppInfo;
    private boolean isUseSmallCache;
    private String halfDetailType;

    // 视频对象
    private Video mVideo;

    public TRAppDetailShotAdapter(Context context, RecyclerView recyclerView) {
        mContext = context;
        mInFlater = LayoutInflater.from(context);
        mRecyclerView = recyclerView;

        mRecyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View view) {
            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View view) {
                VideoView videoView = view.findViewById(R.id.id_videoview);
                if (videoView != null) {
                    if (videoView.isFullScreen()) {
                        videoView.stopFullScreen();
                    }
                    videoView.release();
                }
            }
        });
    }

    public void setScreenshots(List<String> smallImgUrls, List<String> bigImgUrls, List<Integer> modeList, List<Uri> uriList, String name) {
        initSmallUrls(smallImgUrls == null || smallImgUrls.size() <= 0 ? bigImgUrls : smallImgUrls);
        this.bigImgUrls = bigImgUrls == null || bigImgUrls.size() <= 0 ? smallImgUrls : bigImgUrls;
        this.mName = name;
        if(mList == null) {
            mList = new ArrayList<>();
        }
        generateScreenShots(this.smallImgUrls,this.bigImgUrls,modeList, uriList);
    }

    /**
     * 设置视频对象
     */
    public void setVideo(Video video) {
        this.mVideo = video;
    }

    /**
     * 检查是否有可播放的视频
     */
    private boolean hasVideo() {
        return mVideo != null && VideoHelper.hasValidVideoUrl(mVideo);
    }


    private void initSmallUrls(List<String> smallImgUrls) {
        if (smallImgUrls == null || smallImgUrls.size() == 0) return;
        this.smallImgUrls = new ArrayList<>();
        if (smallImgUrls.size() == 1) {
            this.smallImgUrls.add(smallImgUrls.get(0));
            this.smallImgUrls.add(smallImgUrls.get(0));
            this.smallImgUrls.add(smallImgUrls.get(0));
        } else if (smallImgUrls.size() == 2) {
            this.smallImgUrls.add(smallImgUrls.get(0));
            this.smallImgUrls.add(smallImgUrls.get(1));
            this.smallImgUrls.add(smallImgUrls.get(0));
        } else {
            this.smallImgUrls.addAll(smallImgUrls);
        }
    }

    private int getScreenShotMode(List<Integer> list, int pos) {
        if (list == null || list.isEmpty() || pos < 0) {
            return 0;
        }

        int len = list.size();

        return list.get(pos % len);
    }

    private Uri getUriByIndex(List<Uri> uriList, int i) {
        if (uriList == null || uriList.size() <= 0 || i >= uriList.size() || i < 0) {
            return null;
        }

        return uriList.get(i);
    }

    private void generateScreenShots(List<String> smallList, List<String> bigList, List<Integer> modeList, List<Uri> uriList) {

        if (smallList == null || bigList == null) {
            return;
        }
        mList.clear();

        for (int i = 0;i < smallList.size() && i < bigList.size(); i++) {
            ScreenShotInfo shotItem = new ScreenShotInfo();
            shotItem.type = getScreenShotMode(modeList, i);
            shotItem.smallImgUrl = smallList.get(i);
            shotItem.bigImgUrl = bigList.get(i);
            shotItem.uri = getUriByIndex(uriList, i);
            mList.add(shotItem);
        }
    }

    public void setFeatureName(String featureName) {
        mFeaturedName = featureName;
    }

    public void setCurScreenPage(String screenPage) {
        mScreenPageName = screenPage;
    }

    public void setFrom(String from) {
        mFrom = from;
    }

    public void setAppInfo(AppInfo appInfo) {
        this.mAppInfo = appInfo;
    }

    public void setUseSmallCache(boolean useSmallCache) {
        isUseSmallCache = useSmallCache;
    }

    public void setHalfDetail(String halfType) {
        halfDetailType = halfType;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(VIEW_TYPE_H_VIDEO == viewType) {
            View view = mInFlater.inflate(R.layout.layout_detail_video_item, parent, false);
            return new DetailVideoItemViewHolder(view, isUseSmallCache, halfDetailType);
        } else if(VIEW_TYPE_H_SHOT == viewType) {
            View view = mInFlater.inflate(R.layout.layout_app_detail_list_land_item, parent, false);
            return new DetailHShotViewHolder(view, isUseSmallCache, halfDetailType);
        } else if (VIEW_TYPE_V_SHOT == viewType){
            View view = mInFlater.inflate(R.layout.layout_app_detail_viewpage_item, parent, false);
            return new DetailVShotViewHolder(view, isUseSmallCache, halfDetailType);
        } else {
            return new EmptyRecyclerViewHolder(mInFlater.inflate(R.layout.layout_home_typeempty_list_item, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int position) {

        final ScreenShotInfo item = getItemByPosition(position);
        if(item == null) {
            return;
        }

        int viewType = getItemViewType(position);
        if(VIEW_TYPE_H_VIDEO == viewType)  {
            DetailVideoItemViewHolder holder = (DetailVideoItemViewHolder) viewHolder;
            holder.setOnInlinePlayClickListener(new DetailVideoItemViewHolder.OnInlinePlayClickListener() {
                @Override
                public void onClick(com.afmobi.palmplay.video.helper.IVideoHolder h) {
                    if (mOnDetailVideoPlayClickListener != null) {
                        mOnDetailVideoPlayClickListener.onPlayClick(h);
                    }
                }
            });
            holder.setmAppInfo(mAppInfo)
                    .setmFeaturedName(TRAnalyticsConstant.DETAIL_DETAILS_IP)
                    .setmScreenPageName(mScreenPageName)
                    .setmFrom(mFrom)
                    .bind(item, position, getItemCount());
        }else if(VIEW_TYPE_H_SHOT == viewType) {
            DetailHShotViewHolder holder = (DetailHShotViewHolder) viewHolder;
            holder.setOnShotItemClickListener(this)
                    .bind(item, position,getItemCount());
        }else if (VIEW_TYPE_V_SHOT == viewType) {
            DetailVShotViewHolder holder = (DetailVShotViewHolder) viewHolder;
            holder.setOnShotItemClickListener(this)
                    .setTotalScreenSize(getItemCount())
                    .bind(item, position,getItemCount());
        }

    }

    @Override
    public int getItemCount() {
        int count = (mList == null) ? 3 : mList.size();
        if (hasVideo()) {
            count++; // 视频占一个位置
        }
        return count;
    }

    @Override
    public int getItemViewType(int position) {
        // 检查第一个位置是否是视频
        if (position == 0 && hasVideo()) {
            return VIEW_TYPE_H_VIDEO;
        }

        // 调整位置（如果有视频，截图位置需要减1）
        int actualPos = hasVideo() ? position - 1 : position;

        if(mList != null && mList.size() > 0 && actualPos >= 0 && actualPos < mList.size()) {
            ScreenShotInfo item = mList.get(actualPos);
            if(item != null) {
                return item.type;
            }
        }

        return super.getItemViewType(position);
    }

    public ScreenShotInfo getItemByPosition(int pos) {
        // 如果有视频且位置是0，返回视频项
        if (hasVideo() && pos == 0) {
            ScreenShotInfo videoItem = new ScreenShotInfo();
            videoItem.type = VIEW_TYPE_H_VIDEO;
            videoItem.video = mVideo;
            videoItem.smallImgUrl = mVideo.coverImage;
            videoItem.bigImgUrl = mVideo.coverImage;
            return videoItem;
        }

        // 调整位置（如果有视频，截图位置需要减1）
        int actualPos = hasVideo() ? pos - 1 : pos;

        if(mList == null || actualPos < 0 || actualPos >= mList.size()) {
            return null;
        }

        return mList.get(actualPos);
    }

    @Override
    public void onShotItemClick(ScreenShotInfo shotInfo, int position) {
        if(shotInfo != null && TextUtils.isEmpty(halfDetailType)) {
            int len = mList == null ? 0 : mList.size();
            if (len > 0) {
                int actualPos = hasVideo() ? position - 1 : position;
                Intent intent = new Intent(mContext, DetailScreenShotActivity.class);
                intent.putExtra("position", actualPos);
                ArrayList<String> imageUrlList = new ArrayList<>();
                ArrayList<String> smallUrlList = new ArrayList<>();
                ArrayList<Integer> modeList = new ArrayList<>();
                for(ScreenShotInfo item : mList) {
                    imageUrlList.add(item.getBigImgUrl());
                    smallUrlList.add(item.getSmallImgUrl());
                    modeList.add(item.type);
                }
                intent.putStringArrayListExtra("ImageUrlList", imageUrlList);
                intent.putStringArrayListExtra("SmallUrlList", smallUrlList);
                intent.putIntegerArrayListExtra("ImageModeList", modeList);

                try {
                    mContext.startActivity(intent);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) {
                        e.printStackTrace();
                    }
                }

                if(mAppInfo != null) {
                    String value = TRStringUtil.generateString(mScreenPageName, mFeaturedName, "", "");
                    ComponentClickBuilder builder = new ComponentClickBuilder();
                    builder.setValue(value)
                            .setFrom(mFrom)
                            .setTopicType("")
                            .setTopicId("")
                            .setItemType(mAppInfo.detailType)
                            .setItemId(mAppInfo.itemID)
                            .setButtonType(TRAnalyticsConstant.PICTURE)
                            .setItemValue(mAppInfo.packageName)
                            .setExtraValue("");
                    TRAnalysticsUtil.trackClick(builder);
                }
            }
        }
    }

    private VideoView getVideoViewByHolder() {
        if(mRecyclerView == null) {
            return null;
        }

        LinearLayoutManager lm = (LinearLayoutManager) mRecyclerView.getLayoutManager();
        if(lm == null) {
            return null;
        }

        int startPos = lm.findFirstVisibleItemPosition();
        int endPos = lm.findLastVisibleItemPosition();
        for (int i = startPos; i <= endPos; i++) {
            View child = mRecyclerView.getChildAt(i);
            if (child != null) {
                RecyclerView.ViewHolder vm = mRecyclerView.getChildViewHolder(child);
                if (vm instanceof DetailHVideoViewHolder) {
                    DetailHVideoViewHolder holder = (DetailHVideoViewHolder)vm;
                    return holder.mVideoView;
                }
            }
        }

        return null;
    }

    public void onResume() {
        if(AppDataManager.FEATURE_DETAIL_VIDO_SWITCH) {
            VideoView videoView = getVideoViewByHolder();
            if(videoView != null) {
                videoView.resume();
            }
        }
    }

    public void onPause() {
        if(AppDataManager.FEATURE_DETAIL_VIDO_SWITCH) {
            VideoView videoView = getVideoViewByHolder();
            if(videoView != null) {
                videoView.pause();
            }
        }
    }

    public void onDestroy() {
        if(AppDataManager.FEATURE_DETAIL_VIDO_SWITCH) {
            VideoView videoView = getVideoViewByHolder();
            if(videoView != null) {
                videoView.release();
            }
        }
    }

    public boolean onBackPressed() {
        if(AppDataManager.FEATURE_DETAIL_VIDO_SWITCH) {
            VideoView videoView = getVideoViewByHolder();
            if(videoView != null) {
                return videoView.onBackPressed();
            }
        }
        return false;
    }

    public void releaseResource() {
        TRBitmapManager.clearCacheByUrl(smallImgUrls);
    }
}

package com.afmobi.palmplay.appdetail.repo;

import android.os.CountDownTimer;

import androidx.lifecycle.MutableLiveData;

import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkCallBack;
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager;
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode;
import com.afmobi.palmplay.appdetail.model.AppDetailData;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.home.model.FeatureBean;
import com.afmobi.palmplay.model.DetailComponentItemData;
import com.afmobi.palmplay.model.DetailResponseData;
import com.afmobi.palmplay.model.ResponseBuilder;
import com.afmobi.util.CommonUtils;
import com.cloud.hisavana.ac.sdk.api.adx.TFeedNative;
import com.cloud.hisavana.ac.sdk.common.bean.TaNativeInfo;
import com.cloud.hisavana.ac.sdk.common.constant.TaErrorCode;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsnet.store.BuildConfig;

import java.util.List;

public class AppDetailAdRepo {
    private TFeedNative mTFeedNative;
    public boolean isCacheLoadAd = false;
    private boolean isCacheOnError = false;
    private boolean isAdTimerFinished = false;
    private List<TaNativeInfo> detailAdInfos;  //详情页底部广告
    private CountDownTimer mAdLoadTimer;
    public boolean isFeatureAdFinished = false;
    public MutableLiveData<ResponseBuilder> respBuilderLiveData = new MutableLiveData<>();
    private AdLoadListener adLoadListener;
    private int pageIndex = 0;
    private static final int PAGE_SIZE = 4;

    private HisavanaSdkCallBack deatilCallBack = new HisavanaSdkCallBack() {
        @Override
        public void onError(TaErrorCode adError) {
            //获取实时广告失败，请求缓存广告
            if (!isCacheOnError) {
                onLoadAdCache();
            } else {
                if (respBuilderLiveData.getValue() != null) {
                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    onDetailDataCallback(builder.detailResp);
                }
            }
        }

        @Override
        public void onAdLoaded(List<TaNativeInfo> adInfo) {
            onDetailAdCallback(adInfo, false);
        }

        @Override
        public void onAdClicked() {

        }

        @Override
        public void onTimeOut() {
            //获取实时广告失败，请求缓存广告
            if (!isCacheOnError) {
                onLoadAdCache();
            } else {
                if (respBuilderLiveData.getValue() != null) {
                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    onDetailDataCallback(builder.detailResp);
                }
            }
        }

        @Override
        public void onAdCache(List<TaNativeInfo> adInfos) {
            onDetailAdCallback(adInfos, true);
        }

        private void onLoadAdCache() {
            stopCountDownTimer();
            isFeatureAdFinished = true;

            destorySdkAdInfo();

            if (AppDetailData.getInstance().isFeatureRequestFinished()) {
                if (respBuilderLiveData.getValue() != null) {
                    ResponseBuilder builder = respBuilderLiveData.getValue();
                    JsonObject response = builder.detailResp;
                    if (response != null) {
                        if (response != null) {
                            DetailResponseData detailResponseData = null;
                            try {
                                detailResponseData = new Gson().fromJson(response, DetailResponseData.class);
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG) e.printStackTrace();
                            }
                            List<FeatureBean> listItems = null;
                            if (detailResponseData != null) {
                                DetailComponentItemData component = detailResponseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
                                if (component != null) {
                                    listItems = component.featureDtoList;
                                }
                            }

                            if (listItems != null && listItems.size() > 0) {
                                hisavanaSdkDetailAdCacheLoad(listItems);
                                return;
                            }
                        }
                    }
                }
            } else {
                isCacheLoadAd = true;
            }
        }

        private void onDetailAdCallback(List<TaNativeInfo> adInfo, Boolean isCache) {
            stopCountDownTimer();
            isFeatureAdFinished = true;
            isCacheLoadAd = false;

            //每次获取到新广告先判断上一次广告是否destory
            destorySdkAdInfo();

            if (AppDetailData.getInstance().isFeatureRequestFinished()) {
                if (!isAdTimerFinished || isCache) {
                    detailAdInfos = adInfo;
                } else  {
                    TRAnalysticsUtil.trackEwFilterInfo(SceneCode.AD_de, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);

                    if (respBuilderLiveData.getValue() != null) {
                        ResponseBuilder builder = respBuilderLiveData.getValue();
                        JsonObject response = builder.detailResp;
                        if (response != null) {
                            DetailResponseData detailResponseData = null;
                            try {
                                detailResponseData = new Gson().fromJson(response, DetailResponseData.class);
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG) e.printStackTrace();
                            }
                            List<FeatureBean> listItems = null;
                            if (detailResponseData != null) {
                                DetailComponentItemData component = detailResponseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
                                if (component != null) {
                                    listItems = component.featureDtoList;
                                }
                            }

                            if (listItems != null && listItems.size() > 0) {
                                hisavanaSdkDetailAdCacheLoad(listItems);
                                return;
                            }
                        }
                    }
                }
            }else {
                detailAdInfos = adInfo;
            }
            if (respBuilderLiveData.getValue() != null) {

                ResponseBuilder builder = respBuilderLiveData.getValue();
                onDetailDataCallback(builder.detailResp);
            }
        }
    };

    public void loadAd(AdLoadListener adLoadListener){
        this.adLoadListener = adLoadListener;

        isCacheOnError = false;
        isCacheLoadAd = false;
        startCountDownTimer();
        String serailNum = CommonUtils.generateSerialNum();
        hisavanaSdkDetailAdLoad(serailNum, pageIndex, PAGE_SIZE);
    }

    /**
     * 请求详情页底部广告数据
     */
    private void hisavanaSdkDetailAdLoad(String serialNum, int pageIndex, int pageMax) {
        mTFeedNative = HisavanaSdkManager.getInstance().sdkLoad(SceneCode.AD_de, "", serialNum, pageIndex, pageMax, deatilCallBack);
    }

    /**
     * 请求详情页底部缓存广告数据
     */
    public void hisavanaSdkDetailAdCacheLoad(List<FeatureBean> featureList) {
        LogUtils.d("load cache ad..");
        isCacheOnError = true;
        String serailNum = CommonUtils.generateSerialNum();
        mTFeedNative = HisavanaSdkManager.getInstance().sdkLoad(SceneCode.AD_de, "", serailNum, pageIndex, PAGE_SIZE, true, false, featureList, null, null, deatilCallBack);
    }

    private void startCountDownTimer() {
        isAdTimerFinished = false;
        if (mAdLoadTimer == null) {
            mAdLoadTimer = new CountDownTimer(HisavanaSdkManager.SDK_LOAD_TIMEOUT, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    isAdTimerFinished = true;
                    if (AppDetailData.getInstance().isFeatureRequestFinished()) {
                        destroyDetailAd();
                    }

                    if (!isFeatureAdFinished && respBuilderLiveData.getValue() != null) {
                        TRAnalysticsUtil.trackEwFilterInfo(SceneCode.AD_de, TRAnalyticsConstant.ERROR_MSG_TIME_OUT);
                        ResponseBuilder builder = respBuilderLiveData.getValue();

                        JsonObject response = builder.detailResp;
                        if (response != null) {
                            DetailResponseData detailResponseData = null;
                            try {
                                detailResponseData = new Gson().fromJson(response, DetailResponseData.class);
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG) e.printStackTrace();
                            }
                            List<FeatureBean> listItems = null;
                            if (detailResponseData != null) {
                                DetailComponentItemData component = detailResponseData.getComponentItemByStyle(AppDetailsRecyclerViewAdapter.COMPONET_FEATURE);
                                if (component != null) {
                                    listItems = component.featureDtoList;
                                }
                            }

                            if (listItems != null && listItems.size() > 0) {
                                hisavanaSdkDetailAdCacheLoad(listItems);
                                return;
                            }
                        }

                        if (adLoadListener!=null){
                            adLoadListener.onDetailAdDataCallback(builder.detailResp);
                        }
                    }
                }
            };
        }else {
            mAdLoadTimer.cancel();
        }

        mAdLoadTimer.start();
    }

    public List<TaNativeInfo> getDetailAdInfos() {
        return detailAdInfos;
    }

    private void onDetailDataCallback(JsonObject response) {
        if (adLoadListener != null){
            adLoadListener.onDetailAdDataCallback(response);
        }

        respBuilderLiveData.setValue(null);
        isAdTimerFinished = false;
    }

    public void stopCountDownTimer() {
        if (mAdLoadTimer != null) {
            mAdLoadTimer.cancel();
        }
    }

    public void destorySdkAdInfo() {
        if (detailAdInfos != null && !detailAdInfos.isEmpty()) {
            for (TaNativeInfo nativeInfo : detailAdInfos) {
                if (nativeInfo != null) {
                    nativeInfo.destroy();
                }
            }
            detailAdInfos.clear();
        }
    }

    public void destroyDetailAd() {
        if (mTFeedNative != null) {
            mTFeedNative.destroy();
        }
    }

    public interface AdLoadListener{
        void onDetailAdDataCallback(JsonObject response);
    }

}

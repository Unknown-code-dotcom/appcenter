package com.afmobi.palmplay.appmanage.holder;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.cache.v6_4.DownloadRecommendCache;
import com.afmobi.palmplay.customview.XFermodeDownloadView;
import com.afmobi.palmplay.download.DownloadDecorator;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.DownloadStatusManager;
import com.afmobi.palmplay.download.DownloadUtil;
import com.afmobi.palmplay.floatball.DeeplinkManager;
import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.afmobi.palmplay.main.adapter.ItemViewStateListener;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.AppBuilder;
import com.afmobi.palmplay.model.LaunchInfo;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.model.v6_0.RankDataListItem;
import com.afmobi.palmplay.model.v6_3.PageConstants;
import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.palmplay.model.v6_3.RankModel;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.FileUtils;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.animations.AnimationFactory;
import com.afmobi.util.animations.AnimationFactoryParams;
import com.afmobi.util.animations.AppDetailAnimationUtil;
import com.afmobi.util.animations.OnViewLocationInScreen;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.aop.annotation.SingleClick;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * 推荐内容item
 * Created by xiangfei.wei on 2018/12/24.
 */
public class RecommendItemViewHolder extends BaseRecyclerViewHolder {
    private String mFromPage;
    private PageParamInfo mPageParamInfo;
    private OnViewLocationInScreen mOnViewLocationInScreen;
    private ItemViewStateListener mItemViewStateListener;

    private int iconPaddingAndMarginWith = 0;// map xml paddingLeft, paddingRight attr
    private int defIconWidth = 72;
    private static int screenWith = 0;

    private int layout_bottom_root_bgResId = android.R.color.transparent;

    private LinearLayout layout_01, ll_score_size1, layout_02, ll_score_size2, layout_03, ll_score_size3, layout_04, ll_score_size4;

    private ImageView iv_icon_01, iv_icon_02, iv_icon_03, iv_icon_04;
    private TextView tv_name_01, tv_name_02, tv_name_03, tv_name_04;
    private TextView tv_download_count_and_size_01, tv_download_count_and_size_02, tv_download_count_and_size_03, tv_download_count_and_size_04;
    private XFermodeDownloadView downloadView_01, downloadView_02, downloadView_03, downloadView_04;

    @Override
    public RecommendItemViewHolder setFromPage(String mFromPage) {
        this.mFromPage = mFromPage;
        return this;
    }

    @Override
    public RecommendItemViewHolder setPageParamInfo(PageParamInfo pageParamInfo) {
        this.mPageParamInfo = pageParamInfo;
        return this;
    }

    @Override
    public RecommendItemViewHolder setOnViewLocationInScreen(OnViewLocationInScreen l) {
        mOnViewLocationInScreen = l;
        return this;
    }

    @Override
    public RecommendItemViewHolder setItemViewStateListener(ItemViewStateListener l) {
        this.mItemViewStateListener = l;
        return this;
    }

    public RecommendItemViewHolder setLayoutBottomBgResId(int resId) {
        this.layout_bottom_root_bgResId = resId;
        return this;
    }

    public RecommendItemViewHolder(View itemView) {
        super(itemView);

        defIconWidth = DisplayUtil.dip2px(itemView.getContext(), defIconWidth);
        iconPaddingAndMarginWith = DisplayUtil.dip2px(itemView.getContext(), iconPaddingAndMarginWith);
        screenWith = DisplayUtil.getScreenWidthPx(itemView.getContext());
        layout_01 = itemView.findViewById(R.id.layout_01);
        iv_icon_01 = layout_01.findViewById(R.id.iv_icon);
        tv_name_01 = layout_01.findViewById(R.id.tv_name);
        tv_download_count_and_size_01 = layout_01.findViewById(R.id.tv_download_count_and_size);
        ll_score_size1 = layout_01.findViewById(R.id.ll_score_size);
        downloadView_01 = layout_01.findViewById(R.id.downloadView);

        layout_02 = itemView.findViewById(R.id.layout_02);
        iv_icon_02 = layout_02.findViewById(R.id.iv_icon);
        tv_name_02 = layout_02.findViewById(R.id.tv_name);
        tv_download_count_and_size_02 = layout_02.findViewById(R.id.tv_download_count_and_size);
        ll_score_size2 = layout_02.findViewById(R.id.ll_score_size);
        downloadView_02 = layout_02.findViewById(R.id.downloadView);

        layout_03 = itemView.findViewById(R.id.layout_03);
        iv_icon_03 = layout_03.findViewById(R.id.iv_icon);
        tv_name_03 = layout_03.findViewById(R.id.tv_name);
        tv_download_count_and_size_03 = layout_03.findViewById(R.id.tv_download_count_and_size);
        ll_score_size3 = layout_03.findViewById(R.id.ll_score_size);
        downloadView_03 = layout_03.findViewById(R.id.downloadView);

        layout_04 = itemView.findViewById(R.id.layout_04);
        iv_icon_04 = layout_04.findViewById(R.id.iv_icon);
        tv_name_04 = layout_04.findViewById(R.id.tv_name);
        tv_download_count_and_size_04 = layout_04.findViewById(R.id.tv_download_count_and_size);
        ll_score_size4 = layout_04.findViewById(R.id.ll_score_size);
        downloadView_04 = layout_04.findViewById(R.id.downloadView);
    }

    @Override
    public void bind(RankModel mRankModel, final int position) {
        itemView.setTag(mRankModel);
        if (mRankModel.rankData.sizeItemList() > 0) {
            itemView.getLayoutParams().height = RecyclerView.LayoutParams.WRAP_CONTENT;

            itemView.setVisibility(View.VISIBLE);

            int size = mRankModel.rankData.itemList.size();

            int nameWidth = 0;

            nameWidth = screenWith / size;
            if (nameWidth > iconPaddingAndMarginWith) {
                nameWidth = nameWidth - iconPaddingAndMarginWith;
            }
            if (nameWidth > defIconWidth) {
                nameWidth = defIconWidth;
            }
            int padding = (screenWith - nameWidth * 4) / (size + 1) / 2;
            itemView.setPadding(padding, 0, padding, 0);

            int desiredIconWidth = nameWidth - DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), 12);
            setItem(mRankModel,  0, desiredIconWidth,
                    layout_01, iv_icon_01, tv_name_01, tv_download_count_and_size_01, ll_score_size1, downloadView_01);

            setItem(mRankModel, 1, desiredIconWidth,
                    layout_02, iv_icon_02, tv_name_02, tv_download_count_and_size_02, ll_score_size2, downloadView_02);

            setItem(mRankModel, 2, desiredIconWidth,
                    layout_03, iv_icon_03, tv_name_03, tv_download_count_and_size_03, ll_score_size3, downloadView_03);

            setItem(mRankModel, 3, desiredIconWidth,
                    layout_04, iv_icon_04, tv_name_04, tv_download_count_and_size_04, ll_score_size4, downloadView_04);

            if (layout_01.getVisibility() == View.INVISIBLE) {
                itemView.setVisibility(View.GONE);
            }

        } else {
            itemView.setVisibility(View.GONE);
            itemView.getLayoutParams().height = 0;
        }
    }

    private void setItem(RankModel mRankModel, int index, int iconSize, LinearLayout layout, ImageView icon, TextView name, TextView download_count_and_size, LinearLayout ll_score_size,
                         XFermodeDownloadView downloadView) {
        RankDataListItem mRankDataListItem;
        int size = mRankModel.rankData.itemList.size();
        icon.getLayoutParams().width = iconSize;
        icon.getLayoutParams().height = iconSize;
        if (size > 0 && (mRankDataListItem = mRankModel.rankData.itemList.get(index)) != null) {
            //数据下沉过滤，只要用户点击过下载，该条数据就要下沉掉；
            DownloadStatusManager.getInstance().registerInfoInstance(mRankDataListItem);
            boolean defaultStatus = mRankDataListItem.observerStatus == FileDownloadInfo.STATUS_NONE || mRankDataListItem.observerStatus == FileDownloadInfo.STATUS_APP_UPDATE;
            if (!defaultStatus || InstalledAppManager.getInstance().isInstalled(mRankDataListItem.packageName, mRankDataListItem.version)) {
                RankDataListItem backupItem = DownloadRecommendCache.getInstance().getBackupItem();
                if (backupItem != null) {
                    mRankModel.rankData.itemList.set(index, backupItem);
                    mRankDataListItem = backupItem;
                }
            }

            mRankDataListItem.placementId = String.valueOf(index);

            layout.setTag(mRankDataListItem);
            layout.setVisibility(View.VISIBLE);
            layout.setOnClickListener(listener);

            downloadView.setOnClickListener(new RecommendItemViewHolder.DownloadBtnOnClickListener(this, mRankModel, layout));
            int defaultIcon = R.drawable.layer_list_app_default_01_bg;
            GlideUtils.setImageUrl(icon, mRankDataListItem.iconUrl, defaultIcon, defaultIcon);
            name.setText(mRankDataListItem.name);
            updateTextDownloadCountAndSize(mRankDataListItem, download_count_and_size);

            DownloadStatusManager.getInstance().registerInfoInstance(mRankDataListItem);
            CommonUtils.checkStatusItemDisplay(mRankDataListItem, downloadView, mOfferInfo, null);
            //checkStatus(mRankDataListItem, downloadView, ll_score_size);

            if(!mRankDataListItem.hasTrack){
                mRankDataListItem.hasTrack = true;
                if(TextUtils.isEmpty(mRankDataListItem.nativeId)) {
                    mRankDataListItem.nativeId = CommonUtils.generateSerialNum();
                }
                String value = TRStringUtil.generateString(mScreenPageName,mFeatureName,mRankDataListItem.topicPlace,mRankDataListItem.placementId);
                ComponentExposureBuilder builder = new ComponentExposureBuilder();
                builder.setValue(value)
                        .setFrom(mFrom)
                        .setTopicType(mRankModel.rankData.style)
                        .setTopicId(mRankDataListItem.topicID)
                        .setItemType(mRankDataListItem.detailType)
                        .setItemId(mRankDataListItem.itemID)
                        .setReportSource(mRankDataListItem.reportSource)
                        .setNativeId(mRankDataListItem.nativeId)
                        .setTaskId(mRankDataListItem.taskId)
                        .setIsVa(mRankDataListItem.isVa);
                TRAnalysticsUtil.trackExposure(builder);
            }
        } else {
            layout.setVisibility(View.INVISIBLE);
        }
    }

    private void updateTextDownloadCountAndSize(RankDataListItem mRankDataListItem, TextView tv_download_count_and_size) {
        if (0 != mRankDataListItem.size) {
            tv_download_count_and_size.setVisibility(View.VISIBLE);
            tv_download_count_and_size.setText(CommonUtils.replace(PalmplayApplication.getAppInstance().getString(R.string.text_download_size), CommonUtils.TARGET_NAME
                    , FileUtils.getSizeName(mRankDataListItem.size/*Transverter.stringToLong(mRankDataListItem.size, 0)*/)));
        } else {
            tv_download_count_and_size.setVisibility(View.GONE);
            tv_download_count_and_size.setText(FileUtils.getSizeName(mRankDataListItem.size/*Transverter.stringToLong(mRankDataListItem.size, 0)*/));
        }
    }

    @Override
    public void trimViewMemory() {
        if (itemView.getVisibility() == View.VISIBLE) {
            if (layout_04.getVisibility() == View.VISIBLE) {
//                Glide.clear(iv_icon_04);
                iv_icon_04.setImageDrawable(null);
            }
            if (layout_03.getVisibility() == View.VISIBLE) {
//                Glide.clear(iv_icon_03);
                iv_icon_03.setImageDrawable(null);
            }
            if (layout_02.getVisibility() == View.VISIBLE) {
//                Glide.clear(iv_icon_02);
                iv_icon_02.setImageDrawable(null);
            }
            if (layout_01.getVisibility() == View.VISIBLE) {
//                Glide.clear(iv_icon_01);
                iv_icon_01.setImageBitmap(null);
            }
        }
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        @SingleClick
        public void onClick(View v) {
            if (v == null){
                return;
            }
            Object objTag = v.getTag();
            if (objTag instanceof RankDataListItem) {
                RankDataListItem mRankDataListItem = (RankDataListItem) objTag;

                if (!TextUtils.isEmpty(mRankDataListItem.itemID)) {

                    String value = TRStringUtil.generateString(mScreenPageName,mFeatureName,mRankDataListItem.topicPlace,mRankDataListItem.placementId);

                    AppBuilder appBuilder = new AppBuilder()
                            .setFromPage(mFromPage)
                            .setTopicID(mRankDataListItem.topicID)
                            .setVarId(mRankDataListItem.getVarId())
                            .setExpId(mRankDataListItem.expId)
                            .setLastPage(PageConstants.getCurPageStr(mPageParamInfo))
                            .setValue(value)
                            .setParamsByData(mRankDataListItem, "");
                    TRJumpUtil.switcToAppDetailOptions(PalmplayApplication.getAppInstance(), appBuilder);

                    //D_ym_x_0
                    String val = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", mRankDataListItem.placementId);
                    ComponentClickBuilder builder = new ComponentClickBuilder();
                    builder.setValue(val)
                            .setFrom(mFrom)
                            .setTopicType("")
                            .setTopicId(mRankDataListItem.topicID)
                            .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                            .setItemId(mRankDataListItem.itemID)
                            .setButtonType(TRAnalyticsConstant.ICON)
                            .setItemValue(mRankDataListItem.packageName)
                            .setExtraValue("")
                            .setReportSource(mRankDataListItem.reportSource)
                            .setNativeId(mRankDataListItem.nativeId)
                            .setTaskId(mRankDataListItem.taskId)
                            .setExpId(mRankDataListItem.expId);
                    TRAnalysticsUtil.trackClick(builder);
                }
            }
        }
    };

    public class DownloadBtnOnClickListener implements View.OnClickListener {
        private RecommendItemViewHolder holder;
        private RankModel mRankModel;
        private View bindClickView;

        public DownloadBtnOnClickListener(RecommendItemViewHolder holder, RankModel mRankModel, View bindClickView) {
            this.holder = holder;
            this.mRankModel = mRankModel;
            this.bindClickView = bindClickView;
        }

        @Override
        public void onClick(View v) {
            if (bindClickView == null || holder == null || mRankModel == null || mRankModel.rankData == null)
                return;

            if (bindClickView.getId() == holder.layout_01.getId()) {
                if (mRankModel.rankData != null && mRankModel.rankData.sizeItemList() > 0)
                    startDownload(mRankModel.rankData.itemList.get(0), holder.iv_icon_01, holder.downloadView_01);

            } else if (bindClickView.getId() == holder.layout_02.getId()) {
                if (mRankModel.rankData != null && mRankModel.rankData.sizeItemList() > 1)
                    startDownload(mRankModel.rankData.itemList.get(1), holder.iv_icon_02, holder.downloadView_02);

            } else if (bindClickView.getId() == holder.layout_03.getId()) {
                if (mRankModel.rankData != null && mRankModel.rankData.sizeItemList() > 2)
                    startDownload(mRankModel.rankData.itemList.get(2), holder.iv_icon_03, holder.downloadView_03);
            } else if (bindClickView.getId() == holder.layout_04.getId()) {
                if (mRankModel.rankData != null && mRankModel.rankData.sizeItemList() > 3)
                    startDownload(mRankModel.rankData.itemList.get(3), holder.iv_icon_04, holder.downloadView_04);
            }

        }

        private void startDownload(RankDataListItem mRankDataListItem, ImageView iv_icon, View downloadView) {
            if (mRankDataListItem == null){
                return;
            }

            if (mRankDataListItem.isVa) {
                if (BuildConfig.DEBUG) {
                    Log.e("cwxxx", "openVaLoadingActivity", new Throwable("who call me"));
                }
                //下载管理中心里的推荐
                TRJumpUtil.openVaLoadingActivity(new FileDownloadInfo(mRankDataListItem), new LaunchInfo(LaunchInfo.LAUNCH_FROM_ICON, mFrom));
                return;
            }

            String value = TRStringUtil.generateString(mScreenPageName, mFeatureName, "", mRankDataListItem.placementId);
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(mRankDataListItem.itemID)
                    .setNativeId(mRankDataListItem.nativeId)
                    .setReportSource(mRankDataListItem.reportSource)
                    .setItemValue(mRankDataListItem.packageName)
                    .setExtraValue("")
                    .setFromPage(mFromPage)
                    .setTaskId(mRankDataListItem.taskId)
                    .setExpId(mRankDataListItem.expId);
            //点击You May Also Like功能的第1个应用的Icon&Install&Open&Update&Pause&&Continue&Pause&&Continue
            if (FileDownloadInfo.isDownloading(mRankDataListItem.observerStatus)) {
                DownloadManager.getInstance().pauseDownload(mRankDataListItem.packageName);
                builder.setButtonType(TRAnalyticsConstant.PAUSE);
                TRAnalysticsUtil.trackClick(builder);
            } else if (FileDownloadInfo.STATUS_PAUSE == mRankDataListItem.observerStatus || FileDownloadInfo.STATUS_NETWORK_ERROR == mRankDataListItem.observerStatus) {
                DownloadUtil.resumeDownload(PalmplayApplication.getAppInstance(), mRankDataListItem.packageName);
                builder.setButtonType(TRAnalyticsConstant.CONTINUE);
                TRAnalysticsUtil.trackClick(builder);
            } else {
                if (DownloadDecorator.checkJumpToGooglePlay(PalmplayApplication.getAppInstance(), mRankDataListItem.outerUrl, mRankDataListItem.packageName, mPageParamInfo, mRankDataListItem.itemID, mRankDataListItem.version, mRankDataListItem.verifyGoogle)) {
                    return;
                }

                AnimationFactory mAnimationFactory = null;
                AnimationFactoryParams param = null;

                if (mOnViewLocationInScreen != null) {
                    mAnimationFactory = AppDetailAnimationUtil.getInstance();
                    param = new AnimationFactoryParams(iv_icon, mOnViewLocationInScreen, 24);
                }
                DownloadDecorator.startDownloading(mRankDataListItem, mFromPage, new PageParamInfo(mFrom, value), mAnimationFactory, param);

                String buttonType;
                if(FileDownloadInfo.STATUS_APP_INSTALLED == mRankDataListItem.observerStatus){
                    buttonType = TRAnalyticsConstant.OPEN;
                } else if(FileDownloadInfo.STATUS_APP_UPDATE == mRankDataListItem.observerStatus){
                    buttonType = TRAnalyticsConstant.UPDATE;
                }else {
                    buttonType = TRAnalyticsConstant.INSTALL;
                }
                builder.setButtonType(buttonType);
                if (TRAnalyticsConstant.OPEN.equals(buttonType)) {
                    builder.setExtraValue(DeeplinkManager.getDeeplink(mRankDataListItem.packageName));
                }
                TRAnalysticsUtil.trackClick(builder);
            }
        }

    }

    public void updateItemProgress(View itemView, String packageName, FileDownloadInfo fileDownloadInfo) {
        LinearLayout layout_bottom_root = (LinearLayout) itemView.findViewById(R.id.layout_bottom_root);

        int childCount = layout_bottom_root.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childView = layout_bottom_root.getChildAt(i);
            Object objTag = childView.getTag();
            if (objTag instanceof RankDataListItem) {
                RankDataListItem tag_RankDataListItem = (RankDataListItem) objTag;
                if (!TextUtils.isEmpty(tag_RankDataListItem.packageName) && tag_RankDataListItem.packageName.equals(packageName)) {
                    XFermodeDownloadView downloadView = (XFermodeDownloadView) childView.findViewById(R.id.downloadView);
                    CommonUtils.updateViewHolderProgressBar(fileDownloadInfo, downloadView, null, null);
                }
            }
        }
    }
}

package com.afmobi.palmplay.appmanage.v2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.admgr.hisavana_sdk.HisavanaSdkManager
import com.afmobi.palmplay.admgr.hisavana_sdk.SceneCode
import com.afmobi.palmplay.appmanage.ManageDownloadActivity
import com.afmobi.palmplay.appmanage.adapter.DownloadNoResAdapter.OnItemDeleteListener
import com.afmobi.palmplay.appmanage.v2.adapter.DownloadNoResAdapterV2
import com.afmobi.palmplay.appmanage.v2.adapter.EventCombine
import com.afmobi.palmplay.appmanage.v2.adapter.FileManageDownloadAdapterV2
import com.afmobi.palmplay.appmanage.v2.adapter.ItemStatusFlow
import com.afmobi.palmplay.appmanage.v2.adapter.OnBtnAllClick
import com.afmobi.palmplay.appmanage.v2.adapter.OnDownloadItemClick
import com.afmobi.palmplay.appmanage.v2.adapter.OnDownloadItemDelete
import com.afmobi.palmplay.appmanage.v2.adapter.OnEmptyViewClick
import com.afmobi.palmplay.appmanage.v2.adapter.OnItemDropDown
import com.afmobi.palmplay.appmanage.v2.adapter.OnStateBtnClick
import com.afmobi.palmplay.appmanage.v2.factory.ManageDownloadViewModelFactory
import com.afmobi.palmplay.appmanage.v2.model.BTN_ALL_CONTINUE
import com.afmobi.palmplay.appmanage.v2.model.BTN_ALL_PAUSE
import com.afmobi.palmplay.appmanage.v2.model.BTN_GONE
import com.afmobi.palmplay.appmanage.v2.model.DownloadItem
import com.afmobi.palmplay.appmanage.v2.model.DownloadUiState
import com.afmobi.palmplay.appmanage.v2.model.REFRESH_ALL
import com.afmobi.palmplay.appmanage.v2.model.REFRESH_BTN_TYPE
import com.afmobi.palmplay.appmanage.v2.viewmodel.ManageDownloadViewModelV2
import com.afmobi.palmplay.base.BaseEventFragmentActivity
import com.afmobi.palmplay.cache.v6_3.ClientOperationStatisticCache
import com.afmobi.palmplay.configs.v6_3.FromPageType
import com.afmobi.palmplay.dialog.CustomDialog
import com.afmobi.palmplay.dialog.DialogBuilder
import com.afmobi.palmplay.download.DownloadDecorator
import com.afmobi.palmplay.download.DownloadManager
import com.afmobi.palmplay.download.DownloadUtil
import com.afmobi.palmplay.download.ObbFormatDataManager
import com.afmobi.palmplay.firebase.FirebaseConstants
import com.afmobi.palmplay.floatball.DeeplinkManager
import com.afmobi.palmplay.home.MainActivity
import com.afmobi.palmplay.home.TRHomeUtil
import com.afmobi.palmplay.home.adapter.TrHomeRecyclerViewAdapter
import com.afmobi.palmplay.home.instant.InstantVisibleState
import com.afmobi.palmplay.home.model.FeatureItemData
import com.afmobi.palmplay.main.PermissionsReqActivity
import com.afmobi.palmplay.manager.AtyManager
import com.afmobi.palmplay.manager.SPManager
import com.afmobi.palmplay.manager.TRLinearLayoutManager
import com.afmobi.palmplay.model.AppBuilder
import com.afmobi.palmplay.model.InstalledAppInfo
import com.afmobi.palmplay.model.SimpleDataInfo
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.afmobi.palmplay.model.v6_0.RankDataListItem
import com.afmobi.palmplay.model.v6_0.TabType
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import com.afmobi.palmplay.model.v6_3.PageConstants
import com.afmobi.palmplay.model.v6_3.PageParamInfo
import com.afmobi.palmplay.mvvm.data.AppDataManager
import com.afmobi.palmplay.network.NetworkActions
import com.afmobi.palmplay.permissions.PermissonsHintDialog
import com.afmobi.palmplay.saveddata.SavedDataActivity
import com.afmobi.palmplay.thirdlauncher.ThirdEnterUtil
import com.afmobi.palmplay.thirdlauncher.ThirdLauncherActivity
import com.afmobi.palmplay.va.proxy.VaStaticProxy
import com.afmobi.palmplay.viewmodel.filedownload.DownloadViewModel
import com.afmobi.util.CommonUtils
import com.afmobi.util.Constant
import com.afmobi.util.DisplayUtil
import com.afmobi.util.FileUtils
import com.afmobi.util.TRJumpUtil
import com.afmobi.util.TRPermissionUtil
import com.afmobi.util.TimeUtil
import com.afmobi.util.UILoadingGifUtil
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil
import com.cloud.sdk.ac.commonutil.gsonutil.GsonUtil.GsonParseException
import com.didi.drouter.annotation.Router
import com.google.firebase.analytics.FirebaseAnalytics
import com.trans.common.netstate.AppNetState
import com.trans.common.netstate.NetType
import com.trans.common.netstate.connected
import com.transsion.palmstorecore.analytics.ComponentClickBuilder
import com.transsion.palmstorecore.analytics.ComponentExposureBuilder
import com.transsion.palmstorecore.analytics.PagePvBuilder
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity
import com.transsion.palmstorecore.glide.GlideUtils
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.TRStringUtil
import com.transsnet.store.BuildConfig
import com.transsnet.store.R
import com.transsnet.store.databinding.DownloadManageActivityBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.internal.filterList

/**
 * 下载管理页面V2 - Kotlin版本
 * 采用MVVM架构，使用ViewBinding进行数据绑定
 */
@Router(path = "/page/manageDownloadV2")
class ManageDownloadV2Activity : BaseEventFragmentActivity() {

    companion object Companion {
        private const val TAG = "ManageDownloadActivityV2"
        private const val ACTIVITY_REQUEST_CODE_PERMISSIONS = 21

        private const val FEATURE_PAGE_VALUE_UA = "UA"

        private const val BTN_CLICK_TYPE_FOLD = "collapse"

        private const val BTN_CLICK_TYPE_UNFOLD = "unavailable"

        /**
         * 启动下载管理页面
         */
        @JvmStatic
        fun start(context: Context) {
            val intent = Intent(context, ManageDownloadV2Activity::class.java)
            context.startActivity(intent)
        }

        @JvmStatic
        fun getIntoIntent(
            mContext: Context?,
            isFromNotify: Boolean,
            pageParamInfo: PageParamInfo?,
            value: String?
        ): Intent {
            val intent = Intent(mContext, ManageDownloadActivity::class.java).putExtra(
                FromPageType.Notify,
                isFromNotify
            ).putExtra(
                TRAnalyticsConstant.VALUE, value
            )
            PageConstants.putPageParamInfo(intent, pageParamInfo)
            return intent
        }
    }

    private val mValue: String =
        TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "", "", "")

    private val dataSavedValue by lazy {
        TRStringUtil.generateString(
            TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
            TRAnalyticsConstant.SAVED_DATA,
            "",
            ""
        )
    }

    private val noResFoldValue by lazy {
        TRStringUtil.generateString(
            TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
            FEATURE_PAGE_VALUE_UA,
            "",
            ""
        )
    }

    private var mFrom: String? = null
    private var mFromSite: String? = null
    private var isFromDeepLink: Boolean = false

    private var isSavedDataTrack = false

    private val mAlreadyAdList: MutableList<String?> = kotlin.collections.ArrayList() //记录已经展示过的广告包名

    // ViewBinding
    private lateinit var binding: DownloadManageActivityBinding

    // ViewModel
    private val viewModel: ManageDownloadViewModelV2 by lazy {
        ViewModelProviders.of(this, ManageDownloadViewModelFactory())[ManageDownloadViewModelV2::class.java]
    }

    private val mDownloadViewModel: DownloadViewModel by lazy {
        ViewModelProviders.of(this, PalmplayApplication.getAppInstance().viewModelProviderFactory)[DownloadViewModel::class.java]
    }

    private val mUILoadingGifUtil: UILoadingGifUtil by lazy {
        UILoadingGifUtil.create()
    }

    // 适配器
    private lateinit var downloadAdapter: FileManageDownloadAdapterV2
    private lateinit var noResAdapter: DownloadNoResAdapterV2
    private lateinit var mHomeRecyclerViewAdapter: TrHomeRecyclerViewAdapter<*, *>

    private var isFromInstant = false

    private var updateJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (InstantVisibleState.getInstance().isVisible()) {
            isFromInstant = true
            InstantVisibleState.getInstance().setVisible(false)
        }
        // 初始化ViewBinding
        binding = DownloadManageActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        lifecycle.addObserver(mDownloadViewModel)
        // 初始化参数
        initParams()
        // 初始化UI
        initViews()
        // 观察数据变化
        observeViewModel()
        trackPv()
    }

    private fun trackPv() {
        //D_x_x_x
        val pagePvBuilder: PagePvBuilder<*> = PagePvBuilder<PagePvBuilder<*>>()
        pagePvBuilder.setValue(mValue)
            .setFrom(mFrom).setFromSite(mFromSite)
        TRAnalysticsUtil.trackPV(pagePvBuilder)
    }

    private fun initParams() {
        val intent = intent
        if (intent != null) {
            mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE)
            mFromSite = intent.getStringExtra("_source")
            isFromDeepLink = intent.getBooleanExtra(ManageDownloadActivity.IS_FROM_DEEP_LINK, false)
        }
        mPageParamInfo.deliverPageParamInfo(intent, PageConstants.My_Download)
        if (isFromNotify) {
            PalmplayApplication.getPalmplayApplicationInstance().appInit()
        }
    }

    /**
     * 初始化视图
     */
    private fun initViews() {
        // Loading
        val root = binding.root as ViewGroup
        mUILoadingGifUtil.inflate(this, root)
        // 设置标题栏
        setupToolbar()

        // 初始化RecyclerView
        setupRecyclerViews()

        // 设置点击事件
        setupClickListeners()
    }

    /**
     * 设置标题栏
     */
    private fun setupToolbar() {
        binding.layoutTitle.layoutTitleContent.text = getString(R.string.text_installation_manager)
        binding.layoutTitle.layoutTitleContent.setTextColor(getColor(R.color.download_manage_title))
        binding.layoutTitle.layoutCommonTitle.setBackgroundColor(
            ContextCompat.getColor(
                this,
                DisplayUtil.getBackgroundColorId()
            )
        )
        binding.layoutTitle.layoutTitleBack.setOnClickListener {
            if (!checkOnBackPressed()) {
                finish()
            }
            trackBack()
        }
        binding.layoutTitle.tvSearch.visibility = View.VISIBLE
        binding.layoutTitle.tvSearch.setOnClickListener {
            TRJumpUtil.switchToSearchActivity(
                this@ManageDownloadV2Activity, TabType.SOFT, "", false, "", false, "",
                mPageParamInfo, mValue, TRAnalyticsConstant.BUTTON_SEARCH_IMG, mFrom
            )
        }

    }

    private fun trackBack() {
        val builder: ComponentClickBuilder<*> = ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(mValue)
            .setFrom(mFrom)
            .setTopicType("")
            .setTopicId("")
            .setItemType("")
            .setItemId("")
            .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
            .setItemValue("")
            .setExtraValue("")
        TRAnalysticsUtil.trackClick(builder)
    }

    private fun checkOnBackPressed(): Boolean {

        if (isFromInstant) {
            InstantVisibleState.getInstance().setVisible(true)
        }
        if (isFromNotify || isFromDeepLink) {
            // MainActivity不存在时销毁当前页面跳转MainActivity
            if (!AtyManager.getAtyManager().isExistsActivity(MainActivity::class.java)) {
                startActivity(Intent(this, MainActivity::class.java))
            }
            finish()
            return true
        }
        return false
    }

    /**
     * 初始化RecyclerView
     */
    private fun setupRecyclerViews() {
        // 下载列表RecyclerView
        val eventCombine = EventCombine(
            itemStatusFlow = onItemFlowGetter,
            onEmptyViewClick = onEmptyViewClick,
            onBtnAllClick = onBtnAllClick,
            onDownloadItemClick = onDownloadItemClick,
            onStateBtnClick = onStateBtnClick,
            onDownloadItemDelete = onDownloadItemDelete,
            onItemDropDown = onItemDropDown
        )
        downloadAdapter = FileManageDownloadAdapterV2(eventCombine, lifecycleScope)
        binding.recyclerView.apply {
            layoutManager = TRLinearLayoutManager(this@ManageDownloadV2Activity)
            adapter = downloadAdapter
            itemAnimator = null
//            val itemAnimator: RecyclerView.ItemAnimator? = getItemAnimator()
//            if (itemAnimator is SimpleItemAnimator) {
//                itemAnimator.supportsChangeAnimations = false //解决刷新单个item时，该item闪烁的问题
//            }
        }

        // 不可下载列表RecyclerView
        noResAdapter = DownloadNoResAdapterV2(onItemDeleteListener)
        binding.llUnavailable.rvUnavailable.apply {
            layoutManager = TRLinearLayoutManager(this@ManageDownloadV2Activity)
            adapter = noResAdapter
            itemAnimator = null
        }

        val layoutManager = LinearLayoutManager(this).apply {
            setOrientation(RecyclerView.VERTICAL)
            isSmoothScrollbarEnabled = true
            setAutoMeasureEnabled(true)
        }

        mHomeRecyclerViewAdapter = TrHomeRecyclerViewAdapter(
            this,
            binding.recomRecyclerView,
            layoutManager,
            null,
            null,
            null,
            PageConstants.My_Download,
            mPageParamInfo,
            false,
            0,
            0,
            false
        ).apply {
            from = mFrom
            onCreateView()
            setCurScreenPage(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER)
            setFeatureName(TRAnalyticsConstant.MODULE_YOU_LIKE)
        }
        binding.recomRecyclerView.apply {
            setHasFixedSize(true)
            isNestedScrollingEnabled = true
            itemAnimator = null
            setLayoutManager(layoutManager)
            setAdapter(mHomeRecyclerViewAdapter)
        }
    }

    /**
     * 设置点击事件
     */
    private fun setupClickListeners() {

        // 清空不可下载列表按钮
        binding.llUnavailable.tvClearAll.setOnClickListener {
            onClearAll()
        }
        // 不可下载列表展开按钮
        binding.llUnavailable.tvUnavailable.setOnClickListener {
            handleFold(false)
        }
        // 不可下载列表折叠按钮
        binding.llUnavailable.tvCollapse.setOnClickListener {
            handleFold(true)
        }

        // 省流点击
        binding.savedInclude.layoutContent.setOnClickListener {
            val intent = Intent(this@ManageDownloadV2Activity, SavedDataActivity::class.java)
            intent.putExtra(PageConstants.PAGE_KEY_LASTPAGE, mPageParamInfo.getCurPage())
            intent.putExtra(TRAnalyticsConstant.VALUE, getValue())
            startActivity(intent)
            // 点击埋点
            val builder: ComponentClickBuilder<*> =
                ComponentClickBuilder<ComponentClickBuilder<*>?>()
            builder.setValue(dataSavedValue)
                .setFrom(mFrom)
                .setItemValue("")
                .setButtonType(TRAnalyticsConstant.ICON)
            TRAnalysticsUtil.trackClick(builder)
        }
    }

    private fun handleFold(fold: Boolean) {
        viewModel.toggleNoResListFoldState(fold)
        val btnType = if (fold) {
            BTN_CLICK_TYPE_FOLD
        } else {
            BTN_CLICK_TYPE_UNFOLD
        }
        val size = viewModel.getNoResList().size
        val builder: ComponentClickBuilder<*> =
            ComponentClickBuilder<ComponentClickBuilder<*>?>()
        builder.setValue(noResFoldValue)
            .setFrom(mFrom)
            .setItemValue(size.toString())
            .setButtonType(btnType)
        TRAnalysticsUtil.trackClick(builder)
    }

    /**
     * 观察ViewModel数据变化
     */
    private fun observeViewModel() {
        viewModel.uiState.observe(this) { uiState ->
            updateUI(uiState)
        }
        viewModel.dataSaved.observe(this) { list ->
            // 更新节省数据
            updateSavedData(list)
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.refreshMediator.collect { it ->
                    LogUtils.d("DownloadRepo", it)
                    when (it) {
                        REFRESH_ALL -> {
                            viewModel.refreshData()
                        }

                        REFRESH_BTN_TYPE -> {
                            viewModel.checkBtnAllType()
                        }

                        else -> {}
                    }
                }
            }
        }

        // 不可下载列表折叠
        viewModel.isNoResListFold.observe(this) {
            onNoResFoldStateChange(it)
        }

        // 推荐数据监听
        mDownloadViewModel.featuredLiveData.observe(this, object : Observer<FeaturedModel?> {
            override fun onChanged(value: FeaturedModel?) {
                showRecommendView(value)
            }
        })

        // 网络变化监听
        AppNetState.getNetType().observe(this, Observer { netType: NetType? ->
            if (netType.connected()) {
                onTipNetworkDialogDismiss()
                // 联网后如果推荐数据未显示，重新请求一下
                if (mHomeRecyclerViewAdapter.itemCount <= 0){
//                    LogUtils.d("DownloadRepo", "loadFeaturedData:")
                    lifecycleScope.launch {
                        mDownloadViewModel.loadFeaturedData()
                    }
                }
            } else {
                onTipNetworkDialogShow()
            }
        })
    }

    /**
     * 更新UI状态
     */
    private fun updateUI(uiState: DownloadUiState) {
        if (uiState.isLoading) {
            mUILoadingGifUtil.setVisibility(View.VISIBLE)
            return
        }
        mUILoadingGifUtil.setVisibility(View.GONE)
        // 更新下载列表
        updateDownloadList(uiState)

        // 更新不可下载列表
        updateNoResList(uiState)
    }

    /**
     * 更新下载列表
     */
    private fun updateDownloadList(uiState: DownloadUiState) {
        updateJob?.cancel()
        updateJob = lifecycleScope.launch(Dispatchers.Default) {
            // 合并所有下载相关列表
            val allItems = buildList {
                if (uiState.isDownloadDataEmpty()) {
                    // 空状态
                    add(DownloadItem.DownloadEmpty)
                } else {
                    val installingCount: Int = uiState.installingCount()
                    if (installingCount > 0) {
                        var downloading: String = getString(R.string.text_installing)
                        downloading = if (installingCount > 99) {
                            "$downloading(99+)"
                        } else {
                            "$downloading($installingCount)"
                        }
                        val downloadTitle = DownloadItem.DownloadTitle(downloading, uiState.btnAllType)
                        add(downloadTitle)
                        addAll(uiState.installingList)
                    }
                }
                // 添加已安装列表
                if (uiState.hasInstalledItems()) {
                    val title = getString(R.string.text_installed)
                    val downloadTitle = DownloadItem.DownloadTitle(title, BTN_GONE)
                    add(downloadTitle)
                    addAll(uiState.installedList)
                }
            }
            withContext(Dispatchers.Main) {
                downloadAdapter.submitList(allItems)
            }
        }
    }

    /**
     * 更新不可下载列表
     */
    private fun updateNoResList(uiState: DownloadUiState) {
        if (uiState.isDownloadDataEmpty()) {
            hideNoResList()
        } else {
            // 更新不可下载区域可见性
            val hasNoResItems = uiState.hasNoResItems()
            if (hasNoResItems) {
                updateNoResListCount(uiState.noResList.size)
                showNoResList(uiState.isNoResListFold)
            } else {
                hideNoResList()
            }
        }
        noResAdapter.submitList(uiState.noResList)
    }

    private fun hideNoResList() {
        binding.llUnavailable.getRoot().visibility = View.GONE
    }

    private fun showNoResList(isFold: Boolean) {
        binding.llUnavailable.getRoot().visibility = View.VISIBLE
        onNoResFoldStateChange(isFold)
    }

    private fun updateNoResListCount(count: Int) {
        val display: String? = this.getString(R.string.download_unavailable_list, "" + count)
        binding.llUnavailable.tvUnavailable.text = display
        binding.llUnavailable.tvUnavailableStart.text = display
    }

    private fun onNoResFoldStateChange(isFold: Boolean) {
        if (isFold) {
            foldUpNoResList()
        } else {
            unfoldNoResList()
        }
    }

    private fun foldUpNoResList() {
        binding.llUnavailable.tvUnavailable.visibility = View.VISIBLE
        binding.llUnavailable.llUnavailableList.visibility = View.GONE
        binding.llUnavailable.tvCollapse.visibility = View.GONE
    }

    private fun unfoldNoResList() {
        binding.llUnavailable.tvUnavailable.visibility = View.GONE
        binding.llUnavailable.llUnavailableList.visibility = View.VISIBLE
        binding.llUnavailable.tvCollapse.visibility = View.VISIBLE
    }

    override fun onPause() {
        super.onPause()
        updateJob?.cancel()  // 页面不可见时取消
    }

    /**
     * 更新推荐数据
     */
    private fun showRecommendView(featuredModel: FeaturedModel?) {
        lifecycleScope.launch(Dispatchers.Default) {
            if (featuredModel != null && featuredModel.featureList != null && featuredModel.featureList.size > 0) {
                val listItems = featuredModel.featureList
                if (mHomeRecyclerViewAdapter != null) {
                    if (listItems != null && listItems.size > 0) {
                        for (bean in listItems) {
                            ManageDownloadActivity.removeListInstalled(bean)
                        }
                        val adInfo = mDownloadViewModel.downloadAdInfos
                        if (adInfo != null) {
                            val size = adInfo.size
                            for (i in 0 until size) {
                                val taNativeInfo = adInfo.get(i)
                                if (!taNativeInfo.isIconType()) {
                                    //continue
                                } else {
                                    //icon类广告
                                    var appinfo: FeatureItemData? = null
                                    try {
                                        appinfo = GsonUtil.fromJson<FeatureItemData?>(
                                            taNativeInfo.getAppInfo(),
                                            FeatureItemData::class.java
                                        )
                                        if (appinfo != null) {
                                            appinfo.tNativeInfo = taNativeInfo
                                            if (appinfo.extJson != null) {
                                                appinfo.isVa = appinfo.extJson.isVa
                                            }
                                        }
                                    } catch (e: GsonParseException) {
                                        if (BuildConfig.DEBUG) e.printStackTrace()
                                    }

                                    if ((appinfo != null && !TextUtils.isEmpty(appinfo.packageName) && !mAlreadyAdList.contains(
                                            appinfo.packageName
                                        ))
                                    ) {
                                        mDownloadViewModel.filterEWData(
                                            featuredModel,
                                            appinfo,
                                            taNativeInfo.getTopicRow(),
                                            taNativeInfo.getTopicColumn(),
                                            null
                                        )
                                        TRHomeUtil.addAdForFeatureData(
                                            featuredModel.featureList,
                                            appinfo,
                                            taNativeInfo.getTopicRow(),
                                            taNativeInfo.getTopicColumn(),
                                            mAlreadyAdList,
                                            SceneCode.D_ym
                                        )
                                    }
                                }
                            }
                        }
                        TRHomeUtil.doBeddingData(
                            featuredModel,
                            mDownloadViewModel,
                            mAlreadyAdList,
                            SceneCode.D_ym,
                            HisavanaSdkManager.TRACK_LOAD_ADS_SUCCESS_ISCACHE_0
                        )

                        withContext(Dispatchers.Main) {
                            if (View.VISIBLE != binding.recomRecyclerView.getVisibility()) {
                                binding.recomRecyclerView.setVisibility(View.VISIBLE)
                            }
                            mHomeRecyclerViewAdapter.setData(
                                if (AppDataManager.FEATURE_FLOW_ALLOW_MULTI_COUNT) listItems else listItems.subList(
                                    0,
                                    1
                                ), null, null, false, false, true
                            )
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新节省数据
     */
    private fun updateSavedData(list: List<SimpleDataInfo>) {
        if (list.isEmpty()) {
            binding.savedInclude.root.visibility = View.GONE
            return
        }

        binding.savedInclude.root.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.Default) {
            //today
            val day = TimeUtil.getDateToStringDay(System.currentTimeMillis())
            val startDay = "$day 00:00:00"
            val endDay = "$day 23:59:59"
            val startTime = TimeUtil.getStringToDate(startDay)
            val endTime = TimeUtil.getStringToDate(endDay) + 1000
            var todaySize: Long = 0
            var totalSize: Long = 0
            for (item in list) {
                if (item.time >= startTime && item.time < endTime) {
                    todaySize += item.savedSize
                }
                totalSize += item.savedSize
            }

            withContext(Dispatchers.Main) {
                binding.savedInclude.tvTodaySize.text = FileUtils.getWebSizeName(todaySize)
                binding.savedInclude.tvTotalSize.text = FileUtils.getWebSizeName(totalSize)

                val item: SimpleDataInfo = list[0]
                val defaultIcon = R.drawable.layer_list_app_default_01_bg
                GlideUtils.setImageUrl(
                    binding.savedInclude.ivDetials,
                    item.iconUrl,
                    defaultIcon
                )
            }
        }

        if (!isSavedDataTrack) {
            // 曝光埋点
            isSavedDataTrack = true
            val builder: ComponentExposureBuilder<*> =
                ComponentExposureBuilder<ComponentExposureBuilder<*>?>()
            builder.setValue(dataSavedValue).setFrom(mFrom).setItemValue("")
            TRAnalysticsUtil.trackExposure(builder)
        }
    }

    private fun deleteNoResTask(info: FileDownloadInfo?, pos: Int) {
        if (info == null) {
            return
        }
        viewModel.deleteNoResTask(info)
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(
            PageConstants.getDeletePageParamInfo(
                mPageParamInfo,
                info.type
            )
        )

        val value = TRStringUtil.generateString(
            TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
            "",
            "UA",
            pos.toString()
        )
        val builder = ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(value)
            .setFrom(mFrom)
            .setTopicType("")
            .setTopicId("")
            .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
            .setItemId(info.itemID)
            .setButtonType(TRAnalyticsConstant.DELETE)
            .setItemValue(info.packageName)
            .setExtraValue("")
        TRAnalysticsUtil.trackClick(builder)
    }

    private fun onClearAll() {
        if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
            clearAllNoResTasks()
        } else {
            val mDialogBuilder = DialogBuilder()
            CustomDialog(this@ManageDownloadV2Activity).showCheckBoxFunctionDialog(
                mDialogBuilder
                    .hideTitle()
                    .setMessage(this@ManageDownloadV2Activity.getString(R.string.download_dialog_clear_all_tips))
                    .setCheckBoxChecked(false)
                    .setCheckBoxText(this@ManageDownloadV2Activity.getString(R.string.no_again))
                    .setNegativeBtnText(this@ManageDownloadV2Activity.getString(R.string.text_cancel))
                    .setPositiveBtnText(this@ManageDownloadV2Activity.getString(R.string.text_ok))
                    .setPositiveBtnOnClickListener {
                        SPManager.putBoolean(
                            Constant.preferences_delete_tips_downloading_record,
                            mDialogBuilder.isCheckBoxChecked
                        )
                        clearAllNoResTasks()
                    }
            )
        }
    }

    private fun clearAllNoResTasks() {
        val value =
            TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "CA", "", "")
        viewModel.clearAllNoResTasks(value, mFrom)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ACTIVITY_REQUEST_CODE_PERMISSIONS) {
            initViews()
        }
    }

    override fun onEventMainThread(mEventMainThreadEntity: EventMainThreadEntity?) {
        when (mEventMainThreadEntity?.action) {
            Constant.ACTION_DOWNLOAD_LIST_REFRESH -> {

            }

            Constant.ACTION_DOWNLOAD_NORES_LIST_REFRESH -> {
                viewModel.refreshData()
            }

            Constant.ACTION_REDOWNLOAD_FORCE_REFRESH -> {
                viewModel.refreshData()
            }

            NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS -> {
                val appInfo =
                    mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DATA) as InstalledAppInfo?
                val downloadInfo =
                    mEventMainThreadEntity.get(NetworkActions.ACTION_OFFER_FINISH_TOAST_TIPS_APP_DOWNLOADINFO) as FileDownloadInfo?
                showInstalledCompleteWindow(this, appInfo, downloadInfo)
            }

            NetworkActions.ACTION_SAVED_DATA_ADD -> {
                // 更新省流信息
                viewModel.refreshDataSaved()
            }

        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        mPageParamInfo.deliverPageParamInfo(intent, PageConstants.My_Download)
        if (intent != null) {
            this.isFromNotify = intent.getBooleanExtra(FromPageType.Notify, false)
            mFromSite = intent.getStringExtra("_source")
            mFrom = intent.getStringExtra(TRAnalyticsConstant.VALUE)
            trackPv()
        }
    }

    override fun onResume() {
        super.onResume()
        // 页面恢复时刷新数据
        // 延迟刷新，避免阻塞 onResume
        binding.root.postDelayed({
            viewModel.refreshData()
            if (isPermissionHintDialogShowed) {
                if (CommonUtils.hasStoragePermissions()) {
                    isPermissionHintDialogShowed = false
                    ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp()
                }
            }
        }, 100) // 延迟 100ms
    }

    private var isPermissionHintDialogShowed = false

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (!TRPermissionUtil.isGranted(grantResults, permissions)) {
            val isTip = ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                (if (permissions.size > 0) permissions[0] else "")!!
            )
            LogUtils.d("obbPermission", "onRequestPermissionsResult: refuse $isTip")
            TRAnalysticsUtil.trackObbPermissionClick(
                TRAnalyticsConstant.OBB_PERMISSION_REFUSE,
                getValue()
            )
            if (isTip) { //表明用户没有彻底禁止弹出权限请求
                // 用户选择了禁止权限
            } else { //表明用户已经彻底禁止弹出权限请求
                isPermissionHintDialogShowed = true
                PermissonsHintDialog.getPermissionHintDlg(
                    this,
                    PermissionsReqActivity.SYS_SETTING_DETAILS_REQUEST_CODE,
                    if (permissions.size > 0) permissions[0] else ""
                )
            }
        } else {
            isPermissionHintDialogShowed = false
            LogUtils.d("obbPermission", "onRequestPermissionsResult: agree")
            TRAnalysticsUtil.trackObbPermissionClick(
                TRAnalyticsConstant.OBB_PERMISSION_AGREE,
                getValue()
            )
            ObbFormatDataManager.getInstance().allowToDownloadObbFormatApp()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            trackBack()
            if (checkOnBackPressed()) {
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        if (::mHomeRecyclerViewAdapter.isInitialized) {
            mHomeRecyclerViewAdapter.onDestroy()
            // 不要在此处 setAdapter(null)：RecyclerView 1.2.1 在 item 动画未结束时
            // 回收 ViewHolder 会触发 ViewInfoStore "Already in the pool!" 崩溃，销毁场景无此必要
        }
        // Activity销毁时，ViewModel会自动调用onCleared()清理资源
        super.onDestroy()
    }

    override fun getValue(): String = mValue

    private val onItemDeleteListener: OnItemDeleteListener by lazy {
        OnItemDeleteListener { pos: Int ->
            val info: FileDownloadInfo? = noResAdapter.getItemById(pos)
            if (info != null) {
                LogUtils.d("DownloadNoRes", info.packageName + " pos:" + pos)
                if (SPManager.getBoolean(
                        Constant.preferences_delete_tips_downloading_record,
                        false
                    )
                ) {
                    deleteNoResTask(info, pos)
                } else {
                    val mDialogBuilder = DialogBuilder()
                    CustomDialog(this@ManageDownloadV2Activity).showCheckBoxFunctionDialog(
                        mDialogBuilder
                            .hideTitle()
                            .setMessage(this@ManageDownloadV2Activity.getString(R.string.delete_task))
                            .setCheckBoxChecked(false)
                            .setCheckBoxText(this@ManageDownloadV2Activity.getString(R.string.no_again))
                            .setNegativeBtnText(this@ManageDownloadV2Activity.getString(R.string.text_cancel))
                            .setPositiveBtnText(this@ManageDownloadV2Activity.getString(R.string.text_ok))
                            .setPositiveBtnOnClickListener {
                                SPManager.putBoolean(
                                    Constant.preferences_delete_tips_downloading_record,
                                    mDialogBuilder.isCheckBoxChecked()
                                )
                                deleteNoResTask(info, pos)
                            }
                    )
                }
            }
        }
    }

    private val onItemFlowGetter: ItemStatusFlow by lazy {
        { packageName ->
            if (TextUtils.isEmpty(packageName)) {
                null
            } else {
                viewModel.statusFlowOf(packageName!!)
            }
        }
    }

    private val onEmptyViewClick: OnEmptyViewClick by lazy {
        {
            lifecycleScope.launch {
                val homeEntry =
                    "palmplay://" + ThirdLauncherActivity.HOST_THIRD_LAUNCHER + "/?entryType=" + ThirdEnterUtil.EnterType.HomeFeatured.name
                val intent =
                    Intent(this@ManageDownloadV2Activity, ThirdLauncherActivity::class.java)
                val doValue = TRStringUtil.generateString(
                    TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
                    TRAnalyticsConstant.MODULE_DOWNLOADING, "", ""
                )
                intent.setData(homeEntry.toUri())
                intent.putExtra(Constant.FROMPAGE, doValue)
                intent.setAction(Intent.ACTION_VIEW)
                this@ManageDownloadV2Activity.startActivity(intent)
                val builder: ComponentClickBuilder<*> =
                    ComponentClickBuilder<ComponentClickBuilder<*>>()
                builder.setValue(doValue)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.DEEP_LINK)
                    .setItemId(ThirdEnterUtil.EnterType.HomeFeatured.name)
                    .setButtonType(TRAnalyticsConstant.ICON)
                    .setItemValue(TRAnalyticsConstant.SEE_INTERESTED_IN)
                    .setExtraValue("")
                TRAnalysticsUtil.trackClick(builder)
            }
        }
    }

    private val onBtnAllClick: OnBtnAllClick by lazy {
        { allBtnType ->
            lifecycleScope.launch {
                var buttonType = TRAnalyticsConstant.BUTTON
                when (allBtnType) {
                    BTN_GONE -> {}
                    BTN_ALL_CONTINUE -> {
                        resumeAll()
                        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                            .logEvent(FirebaseConstants.EVENT_DOWNLOAD_STARTALL_CLICK, null)

                        //打点
                        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(
                            PageConstants.deliverPageParamInfo(
                                mPageParamInfo,
                                PageConstants.Download_Soft_Allcontinue
                            )
                        )
                        buttonType = TRAnalyticsConstant.BUTTON_START_ALL
                    }

                    BTN_ALL_PAUSE -> {
                        pauseAll()
                        FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                            .logEvent(FirebaseConstants.EVENT_DOWNLOAD_PAUSEALL_CLICK, null)
                        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(
                            PageConstants.deliverPageParamInfo(
                                mPageParamInfo,
                                PageConstants.Download_Soft_Allpause
                            )
                        )
                        buttonType = TRAnalyticsConstant.BUTTON_STOP_ALL
                    }
                }
                //x	x	D_do_x_x	"点击Downlodaing的Start ALL&Pause All 按钮"
                val value = TRStringUtil.generateString(
                    TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
                    TRAnalyticsConstant.MODULE_DOWNLOADING,
                    "",
                    ""
                )
                val builder: ComponentClickBuilder<*> =
                    ComponentClickBuilder<ComponentClickBuilder<*>>()
                builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType("")
                    .setItemId("")
                    .setButtonType(buttonType)
                    .setItemValue("")
                    .setExtraValue("")
                TRAnalysticsUtil.trackClick(builder)
            }
        }
    }

    private fun pauseAll() {
        val downloadingList =
            DownloadManager.getInstance().getShadowDownloadingInfoListNoVa().filterList {
                // 过滤不可下载应用
                !(extraInfo != null && !extraInfo.itemCheckFlag && !extraInfo.canRetry)
            }
        val dstList = DownloadManager.getInstance()
            .onDownloadingBatchPause(downloadingList)
        CommonUtils.onHandleWiFiRetrieve(dstList, false)
        viewModel.checkBtnAllType()
    }

    private fun resumeAll() {
        val downloadingList =
            DownloadManager.getInstance().getShadowDownloadingInfoListNoVa().filterList {
                // 过滤不可下载应用
                !(extraInfo != null && !extraInfo.itemCheckFlag && !extraInfo.canRetry)
            }
        DownloadUtil.resumeDownload(
            this,
            downloadingList,
            true
        )
        viewModel.checkBtnAllType()
    }

    private val onDownloadItemClick: OnDownloadItemClick by lazy {
        { downloadInfo, installed, position ->
            if (installed) {
                // 打开应用
                installedItemClick(downloadInfo, position)
            } else {
                if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isInstallFail && !downloadInfo.extraInfo.isRetryInstallFail) {
                    // 安装错误处理
                    installErrItemClick(downloadInfo)
                } else {
                    // 打开详情页
                    installingItemClick(downloadInfo, position)
                }

            }
        }
    }

    fun installErrItemClick(downloadInfo: FileDownloadInfo) {
        if (TextUtils.isEmpty(downloadInfo.downloadUrl)) {
            val mDialogBuilder = DialogBuilder()
            CustomDialog(this).showCheckBoxFunctionDialog(
                mDialogBuilder.hideTitle()
                    .setMessage(
                        PalmplayApplication.getAppInstance()
                            .getString(R.string.cannot_installed_file_on_device)
                    ).hideCheckBox()
                    .setNegativeBtnText(
                        PalmplayApplication.getAppInstance()
                            .getString(R.string.text_ignore)
                    )
                    .setPositiveBtnText(
                        PalmplayApplication.getAppInstance()
                            .getString(R.string.text_delete)
                    ).setPositiveBtnOnClickListener {
                        DownloadManager.getInstance()
                            .removeDownloadedInfo(downloadInfo.packageName)
                    }
            )
        } else {
            if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isSpaceLimit) {
                downloadInfo.extraInfo.isSpaceLimit = false
            }
            DownloadDecorator.clickDownloadedInfo(this, downloadInfo, mPageParamInfo)
        }

        if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isInstallFail) {
            val value =
                TRStringUtil.generateString(TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER, "SF", "", "")
            val builder: ComponentClickBuilder<*> = ComponentClickBuilder<ComponentClickBuilder<*>>()
            builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setButtonType(TRAnalyticsConstant.BUTTON_RETRY)
                .setItemType(downloadInfo.extraInfo.detailType)
                .setItemId(downloadInfo.itemID)
                .setItemValue(downloadInfo.packageName)
            TRAnalysticsUtil.trackClick(builder)
        }
    }

    private fun installingItemClick(downloadInfo: FileDownloadInfo, position: Int) {
        val item = RankDataListItem()
        item.name = downloadInfo.name
        item.versionName = downloadInfo.versionName
        item.downloadCount = CommonUtils.sting2IntNoException(downloadInfo.downloadCount)
        item.downloadID = downloadInfo.downloadID
        item.downloadUrl = downloadInfo.downloadUrl
        item.iconUrl = downloadInfo.iconUrl
        item.imgUrl = downloadInfo.iconUrl
        item.observerStatus = downloadInfo.downloadStatus
        item.packageName = downloadInfo.packageName
        item.itemID = downloadInfo.itemID
        if (downloadInfo.extraInfo != null) {
            item.nativeId = downloadInfo.extraInfo.nativeId
        }


        val value = TRStringUtil.generateString(
            TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
            TRAnalyticsConstant.MODULE_DOWNLOADING,
            "0",
            (position - 1).toString()
        )
        val appBuilder = AppBuilder()
            .setFromPage(PageConstants.My_Download)
            .setLastPage(PageConstants.My_Download)
            .setValue(value)
            .setParamsByData(item, "")
        TRJumpUtil.switcToAppDetailOptions(this@ManageDownloadV2Activity, appBuilder)

        val builder: ComponentClickBuilder<*> =
            ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(value)
            .setFrom(mFrom)
            .setTopicType("")
            .setTopicId("")
            .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
            .setItemId(downloadInfo.itemID)
            .setButtonType(TRAnalyticsConstant.ICON)
            .setItemValue(downloadInfo.packageName)
            .setExtraValue("")
        TRAnalysticsUtil.trackClick(builder)
    }

    private fun installedItemClick(downloadInfo: FileDownloadInfo, position: Int) {
        DownloadDecorator.launchApp(
            downloadInfo.packageName,
            downloadInfo.name
        )

        var index = position - 1
        val installingCount = viewModel.uiState.value?.installingCount()
        if (installingCount != null && installingCount > 0) {
            index = index - installingCount - 1
        }
        if (index < 0) {
            index = 0
        }
        val value = TRStringUtil.generateString(
            TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
            TRAnalyticsConstant.MODULE_INSTALLED,
            "0",
            index.toString()
        )
        val builder: ComponentClickBuilder<*> = ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(value)
            .setFrom(mFrom)
            .setTopicType("")
            .setTopicId("")
            .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
            .setItemId(downloadInfo.itemID)
            .setButtonType(TRAnalyticsConstant.OPEN)
            .setItemValue(downloadInfo.packageName)
            .setExtraValue(DeeplinkManager.getDeeplink(downloadInfo.packageName))
        TRAnalysticsUtil.trackClick(builder)
    }

    private val onStateBtnClick: OnStateBtnClick by lazy {
        { downloadInfo, position ->
            val value = TRStringUtil.generateString(
                TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
                TRAnalyticsConstant.MODULE_DOWNLOADING,
                "0",
                (position - 1).toString()
            )
            if (downloadInfo.isOffline && downloadInfo.isGrp
                && DownloadManager.getInstance().isGrpCanUncompress(downloadInfo)
            ) {
                // PalmPlayGrpZipUtils.unCompressGroup(info);
            } else if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_DOWNLOAD_FILE_CHECKING) {
                // 文件下载完成，正在进行校验，此时不处理点击事件，页面显示进度100%
                if (BuildConfig.DEBUG) {
                    Log.e("checkDownloadInfo", "文件下载完成，校验中...", Throwable("who call me"))
                }
            } else if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_DOWNLOADED || downloadInfo.downloadStatus == FileDownloadInfo.STATUS_INSTALLING) {
                // 下载完成未安装成功时
                installErrItemClick(downloadInfo)
            } else if (downloadInfo.downloadStatus != FileDownloadInfo.STATUS_PAUSE
                && downloadInfo.downloadStatus != FileDownloadInfo.STATUS_NETWORK_ERROR
            ) { //点击暂停
                DownloadManager.getInstance().pauseDownload(downloadInfo.packageName)
                FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                    .logEvent(FirebaseConstants.EVENT_DOWNLOAD_PAUSE_CLICK, null)

                val builder: ComponentClickBuilder<*> =
                    ComponentClickBuilder<ComponentClickBuilder<*>>()
                builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(downloadInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.PAUSE)
                    .setItemValue(downloadInfo.packageName)
                    .setFromPage(downloadInfo.fromPage)
                    .setExtraValue("")
                TRAnalysticsUtil.trackClick(builder)

                ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(
                    PageConstants.getPausePageParamInfo(
                        mPageParamInfo,
                        downloadInfo.type
                    )
                )
            } else { //继续下载
                if (downloadInfo.extraInfo != null && downloadInfo.extraInfo.isSpaceLimit) {
                    downloadInfo.extraInfo.isSpaceLimit = false
                }
                DownloadUtil.resumeDownload(this@ManageDownloadV2Activity, downloadInfo.packageName)
                if (downloadInfo.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR || downloadInfo.isWifiLostPause) {
                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                        .logEvent(FirebaseConstants.EVENT_DOWNLOAD_FAILED_CONTINUE_CLICK, null)
                } else {
                    FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                        .logEvent(FirebaseConstants.EVENT_DOWNLOAD_PAUSE_CONTINUE_CLICK, null)
                }
                ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(
                    PageConstants.getContinuePageParamInfo(
                        mPageParamInfo,
                        downloadInfo.type
                    )
                )
                val builder: ComponentClickBuilder<*> =
                    ComponentClickBuilder<ComponentClickBuilder<*>>()
                builder.setValue(value)
                    .setFrom(mFrom)
                    .setTopicType("")
                    .setTopicId("")
                    .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                    .setItemId(downloadInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.CONTINUE)
                    .setItemValue(downloadInfo.packageName)
                    .setFromPage(downloadInfo.fromPage)
                    .setExtraValue("")
                TRAnalysticsUtil.trackClick(builder)
            }
        }
    }

    private val onDownloadItemDelete: OnDownloadItemDelete by lazy {
        { downloadInfo, position ->
            if (SPManager.getBoolean(Constant.preferences_delete_tips_downloading_record, false)) {
                deleteTask(downloadInfo, position)
            } else {
                val mDialogBuilder = DialogBuilder()
                CustomDialog(this@ManageDownloadV2Activity).showCheckBoxFunctionDialog(
                    mDialogBuilder
                        .hideTitle()
                        .setMessage(this@ManageDownloadV2Activity.getString(R.string.delete_task))
                        .setCheckBoxChecked(false)
                        .setCheckBoxText(this@ManageDownloadV2Activity.getString(R.string.no_again))
                        .setNegativeBtnText(this@ManageDownloadV2Activity.getString(R.string.text_cancel))
                        .setPositiveBtnText(this@ManageDownloadV2Activity.getString(R.string.text_ok))
                        .setPositiveBtnOnClickListener {
                            SPManager.putBoolean(
                                Constant.preferences_delete_tips_downloading_record,
                                mDialogBuilder.isCheckBoxChecked
                            )
                            deleteTask(downloadInfo, position)
                        }
                )
            }
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                .logEvent(FirebaseConstants.EVENT_DOWNLOAD_EXPAND_CLICK, null)
        }
    }

    private fun deleteTask(info: FileDownloadInfo?, position: Int) {
        if (info == null) {
            return
        }
        if (VaStaticProxy.isInstantPluginApp(info.packageName)) {
            // 取消下载对应插件，应当拒绝
            VaStaticProxy.disagree(info.packageName)
        }

        // 下载完成的调用removeDownloadedInfo
        if (FileDownloadInfo.STATUS_DOWNLOADED == info.downloadStatus || FileDownloadInfo.STATUS_INSTALLING == info.downloadStatus) {
            DownloadManager.getInstance().removeDownloadedInfo(info.packageName)
        } else {
            // 下载未完成的调用cancelDownload
            DownloadManager.getInstance().cancelDownload(info.packageName)
        }
        if (info.downloadStatus == FileDownloadInfo.STATUS_NETWORK_ERROR || info.isWifiLostPause) {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                .logEvent(FirebaseConstants.EVENT_DOWNLOAD_FAILED_DELETE, null)
        } else {
            FirebaseAnalytics.getInstance(PalmplayApplication.getAppInstance())
                .logEvent(FirebaseConstants.EVENT_DOWNLOAD_DOWNLOADING_DELETE, null)
        }
        ClientOperationStatisticCache.getInstance().putOneOperationRecordNode(
            PageConstants.getDeletePageParamInfo(
                mPageParamInfo,
                info.type
            )
        )

        val value = TRStringUtil.generateString(
            TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
            TRAnalyticsConstant.MODULE_DOWNLOADING,
            "0",
            (position - 1).toString()
        )
        val builder: ComponentClickBuilder<*> = ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(value)
            .setFrom(mFrom)
            .setTopicType("")
            .setTopicId("")
            .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
            .setItemId(info.itemID)
            .setButtonType(TRAnalyticsConstant.DELETE)
            .setItemValue(info.packageName)
            .setExtraValue("")
        TRAnalysticsUtil.trackClick(builder)
    }

    private val onItemDropDown: OnItemDropDown by lazy {
        { downloadInfo, position ->
            val value = TRStringUtil.generateString(
                TRAnalyticsConstant.PAGE_DOWNLOAD_MANAGER,
                TRAnalyticsConstant.MODULE_DOWNLOADING,
                "0",
                (position - 1).toString()
            )
            val builder: ComponentClickBuilder<*> =
                ComponentClickBuilder<ComponentClickBuilder<*>?>()
            builder.setValue(value)
                .setFrom(mFrom)
                .setTopicType("")
                .setTopicId("")
                .setItemType(TRAnalyticsConstant.ITEM_TYPE_PKG)
                .setItemId(downloadInfo.itemID)
                .setButtonType(TRAnalyticsConstant.MORE_TYPE)
                .setItemValue(downloadInfo.packageName)
                .setExtraValue("")
            TRAnalysticsUtil.trackClick(builder)
        }
    }
}

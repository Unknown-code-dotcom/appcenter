// TOP SECRET
package com.afmobi.palmplay.cache;

import android.text.TextUtils;

import com.afmobi.palmplay.configs.v6_3.RankItemType;
import com.transsion.palmstorecore.log.LogUtils;

public final class DetailType {

	public static final int TYPE_ERROR = 0;
	public static final int TYPE_SOFT = 0;
	public static final int TYPE_PICTURE = 1;
	public static final int TYPE_MUSIC = 2;
	public static final int TYPE_VIDEO = 3;

	public static final int TYPE_FEATURE = 4;
	public static final int TYPE_COLLECTION = 5;
	public static final int TYPE_APP = 6;
	public static final int TYPE_GAME = 7;

	public static final int TYPE_MULTI = 8;

	public static final int TYPE_PACK = 9; // for one pack download

	public static final int TYPE_BOOK = 11;

	public static final int TYPE_SINGER = 12;

	public static final int TYPE_ADMOB = 13;//will delete later

	public static final int TYPE_INVALID = 0XFFFFFFFF;

	// book
	public static final String[] mBookFormatArray = new String[] { "TXT", "PDF", "CBR", "CBZ", "EPUB" };
	private static final String[] mBookFileSuffixes = new String[] { ".txt", ".pdf", ".cbr", ".cbz", ".epub" };

	public static int getType(String typeName) {
		int type = 0;

		if (typeName == null) {
			return TYPE_SOFT;
		}

		if (typeName.equals("SOFT")) {
			type = TYPE_SOFT;
		} else if (typeName.equals("PICTURE")) {
			type = TYPE_PICTURE;
		} else if (typeName.equals("MUSIC")) {
			type = TYPE_MUSIC;
		} else if (typeName.equals("VIDEO")) {
			type = TYPE_VIDEO;
		} else if (typeName.equals("FEATURE")) {
			type = TYPE_FEATURE;
		} else if (typeName.equals("COLLECTION")) {
			type = TYPE_COLLECTION;
		} else if (typeName.equals("APP")) {
			type = TYPE_APP;
		} else if (typeName.equals("GAME")) {
			type = TYPE_GAME;
		} else if (typeName.equals("Mutil")) {
			type = TYPE_MULTI;
		} else if (typeName.equals("EBOOK") || typeName.equalsIgnoreCase("Book")) {
			type = TYPE_BOOK;
		} else if (typeName.equals("SINGER")){
			type = TYPE_SINGER;
		}

		return type;

	}

	public static int getSearchType(String typeName) {
		int type = 0;

		if (typeName == null) {
			return TYPE_SOFT;
		}

		if (typeName.equals("SOFT")) {
			type = TYPE_SOFT;
		}else if (typeName.equals("MUSIC")) {
			type = TYPE_MUSIC;
		} else if (typeName.equals("VIDEO")) {
			type = TYPE_VIDEO;
		} else if (typeName.equals("EBOOK")) {
			type = TYPE_BOOK;
		}

		return type;

	}

	public static int getSubType(String detailType) {
		if(!TextUtils.isEmpty(detailType)){
			if(detailType.equals(RankItemType.SOFT)){
				return DetailType.TYPE_SOFT;
			} else if(detailType.equals(RankItemType.VIDEO)){
				return DetailType.TYPE_VIDEO;
			} else if(detailType.equals(RankItemType.MUSIC)){
				return DetailType.TYPE_MUSIC;
			} else if(detailType.equals(RankItemType.SINGER)){
				return DetailType.TYPE_SINGER;
			} else if(detailType.equals(RankItemType.EBOOK)){
				return DetailType.TYPE_BOOK;
			}
		}
		return DetailType.TYPE_ERROR;
	}

	public static String getTypeName(int type) {
		String typeName = null;

		if (type == TYPE_SOFT) {
			typeName = "Soft";
		} else if (type == TYPE_PICTURE) {
			typeName = "Picture";
		} else if (type == TYPE_MUSIC) {
			typeName = "Music";
		} else if (type == TYPE_VIDEO) {
			typeName = "Video";
		} else if (type == TYPE_FEATURE) {
			typeName = "Feature";
		} else if (type == TYPE_COLLECTION) {
			typeName = "Collection";
		} else if (type == TYPE_APP) {
			typeName = "App";
		} else if (type == TYPE_GAME) {
			typeName = "Game";
		} else if (type == TYPE_MULTI) {
			typeName = "Mutil";
		} else if (type == TYPE_BOOK) {
			typeName = "Book";
		}
		return typeName;
	}
	//
//        return type == DetailType.TYPE_APP
//                || type == DetailType.TYPE_COLLECTION
//                || type == DetailType.TYPE_GAME
//                || type == DetailType.TYPE_SOFT;
	public static boolean isApp(int type) {
		if (type == TYPE_APP || type == TYPE_GAME || type == TYPE_SOFT) {
			return true;
		}

		return false;

	}

	public static boolean isGame(String category2) {
		LogUtils.d(LogUtils.TAG_TR_D_VA_DOWNLOAD,"isGame------category2:"+category2);
		if ("Game".equals(category2) || "local".equals(category2)) {
			return true;
		}

		return false;

	}

	public static String getBookFileSuffixes(String format) {

		if (!TextUtils.isEmpty(format)) {
			for (int i = 0; i < mBookFormatArray.length; i++) {
				if (mBookFormatArray[i].equals(format)) {
					return mBookFileSuffixes[i];
				}
			}
			return "." + format.toLowerCase();
		}
		return mBookFileSuffixes[0];
	}

}


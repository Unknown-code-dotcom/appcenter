package com.afmobi.palmplay.cloudfolder.recently

import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.afmobi.palmplay.download.DownloadTaskHelper
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.transsion.palmstorecore.log.LogUtils
import com.transsnet.launcherlib.config.Constants

object RecentlyInstalledFilter {

    private const val TAG = "RecentlyInstalled"

    private const val PREFIX_CLOUD_FOLDER_APP = "FL_A_"
    private const val PREFIX_CLOUD_FOLDER_GAME = "FL_G_"


    @JvmStatic
    fun shouldInsert(downloadInfo: FileDownloadInfo?, isReplace: Boolean): Boolean {
        if (downloadInfo == null) {
            log("拒绝：downloadInfo 为空")
            return false
        }
        // 规则 1：必须新下载
        if (isReplace) {
            log("拒绝 pkg=${downloadInfo.packageName} 原因=覆盖更新")
            return false
        }
//        val fromPage = downloadInfo.fromPage
        val fromPage: String? = if (downloadInfo.pageParamInfo != null) downloadInfo.pageParamInfo.curPage else ""
        log("开始校验 fromPage  pkg=${downloadInfo.packageName} ---fromPage == $fromPage -- ")
        return when {
            fromPage.isNullOrEmpty() -> {
                // fromPage 缺失：保守拒绝，避免脏数据
                log("拒绝 pkg=${downloadInfo.packageName} 原因=fromPage为空")
                false
            }
            fromPage.startsWith(PREFIX_CLOUD_FOLDER_APP) -> {
                // 规则 2：云文件夹 App 文件夹 → 仅 offer / ADX
                val isOffer = downloadInfo.extraInfo?.isOffer == DownloadTaskHelper.OFFER
                val isAdx = downloadInfo.extraInfo?.isOffer == Constants.IS_ADX
                val ok = isOffer || isAdx
                log(" pkg=${downloadInfo.packageName} --isOffer = "+ isOffer + "isAdx == " + isAdx)
                if (!ok) {
                    log("拒绝 pkg=${downloadInfo.packageName} 来源=云文件夹App 原因=非offer/非ADX")
                }
                ok
            }
            fromPage.startsWith(PREFIX_CLOUD_FOLDER_GAME) -> {
                // 规则 3：云文件夹 Game 文件夹 → 全部入库
                true
            }
            else -> {
                // 规则 4：AC 端内 —— 云控 acPkgs ∩ acFromPages 双白名单匹配
                matchAcWhitelist(downloadInfo.packageName, fromPage)
            }
        }
    }


    private fun matchAcWhitelist(pkg: String?, fromPage: String): Boolean {
        if (pkg.isNullOrEmpty()) {
            log("拒绝 来源=AC端内 原因=pkg为空")
            return false
        }
        val acPkgs = CloudFolderManager.getInstance().getRecentlyInstalledAcPkgs()
        val acFromPages = CloudFolderManager.getInstance().getRecentlyInstalledAcFromPages()
        if (acPkgs.isNullOrEmpty() || acFromPages.isNullOrEmpty()) {
            log("拒绝 pkg=$pkg 来源=AC端内 原因=白名单未下发(acPkgs或acFromPages为空)")
            return false
        }
        // 包名精确匹配（大小写忽略）
        val pkgMatched = acPkgs.any { it != null && it.equals(pkg, ignoreCase = true) }
        if (!pkgMatched) {
            log("拒绝 pkg=$pkg 来源=AC端内 原因=不在acPkgs白名单")
            return false
        }
        // fromPage 前缀匹配（大小写忽略）
        val fromPageLower = fromPage.lowercase()
        val fromPageMatched = acFromPages.any {
            !it.isNullOrEmpty() && fromPageLower.startsWith(it.lowercase())
        }
        if (!fromPageMatched) {
            log("拒绝 pkg=$pkg fromPage=$fromPage 来源=AC端内 原因=fromPage不命中acFromPages前缀")
            return false
        }
        if (LogUtils.debug) {
            LogUtils.d(TAG, "【入库过滤】通过 pkg=$pkg 来源=AC端内 fromPage=$fromPage 命中acPkgs+acFromPages双白名单")
        }
        return true
    }

    private inline fun log(msg: String) {
        if (LogUtils.debug) {
            LogUtils.d(TAG, "【入库过滤】$msg")
        }
    }
}

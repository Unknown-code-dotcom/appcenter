package com.afmobi.palmplay.collection

import android.graphics.Rect
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ItemDecoration
import com.afmobi.palmplay.PalmplayApplication
import com.afmobi.palmplay.collection.adapter.OuterCollectionAdapter
import com.afmobi.palmplay.download.DownloadDecorator
import com.afmobi.palmplay.download.DownloadUtil
import com.afmobi.palmplay.home.TRHomeUtil
import com.afmobi.palmplay.home.model.FeatureBean
import com.afmobi.palmplay.main.utils.UINetworkErrorUtil
import com.afmobi.palmplay.manager.PalmPlayNetworkDownloadStateManager
import com.afmobi.palmplay.manager.TRLinearLayoutManager
import com.afmobi.palmplay.model.CurrentTabConfig
import com.afmobi.palmplay.model.v6_3.FeaturedModel
import com.afmobi.palmplay.model.v6_3.PageParamInfo
import com.afmobi.palmplay.mvvm.BaseActivity
import com.afmobi.palmplay.setting.WifiOnlyTipsActivity
import com.afmobi.util.CommonUtils
import com.afmobi.util.Constant
import com.afmobi.util.DisplayUtil
import com.afmobi.util.NetworkState
import com.afmobi.util.NetworkUtils
import com.afmobi.util.SysUtils
import com.afmobi.util.TRJumpUtil
import com.afmobi.util.UILoadingGifUtil
import com.afmobi.util.statusbar.TRStatusBarUtil
import com.trans.common.netstate.AppNetState
import com.trans.common.netstate.NetType
import com.transsion.calculator.MustInstallExclude
import com.transsion.palmstorecore.analytics.ComponentClickBuilder
import com.transsion.palmstorecore.analytics.PagePvBuilder
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.AndroidVUIUtils.matchAndroid15UI
import com.transsion.palmstorecore.util.TRStringUtil
import com.transsnet.store.R
import com.transsnet.store.databinding.ActivityRecommendCollectionPageLayoutBinding
import kotlinx.coroutines.launch
import kotlin.math.abs

@MustInstallExclude
class RecommendCollectionActivity: BaseActivity<ActivityRecommendCollectionPageLayoutBinding, CollectionViewModel>(), ICollectionController {
    private val TAG = "${LogUtils.TAG_COLLECTION}RecommendCollectionActivity"
    private val mViewModel: CollectionViewModel by lazy {
        ViewModelProvider(this)[CollectionViewModel::class.java]
    }
    private var mBinding: ActivityRecommendCollectionPageLayoutBinding? = null
    private val mUILoadingGifUtil: UILoadingGifUtil = UILoadingGifUtil.create()
    private val mUINetworkErrorUtil: UINetworkErrorUtil = UINetworkErrorUtil.create()
    private val mPageParamInfo = PageParamInfo()
    private var statusBar: View? = null
    private var totalScrollY = 0
    private var alphaH = 0
    private var outAdapter: OuterCollectionAdapter? = null
    private var mLayoutManager: TRLinearLayoutManager? = null
    private var mViewHolderCallback: IViewHolder? = null
    private var mFeatureBean: FeatureBean? = null

    override fun getBindingVariable(): Int = 0

    override fun getLayoutId(): Int = R.layout.activity_recommend_collection_page_layout

    override fun getViewModel(): CollectionViewModel {
        return mViewModel
    }

    override fun getValue(): String {
        val value = TRStringUtil.generateString(TRAnalyticsConstant.COLLECTION_PAGE, "", "", "")
        return mViewModel.mValue.takeIf { it.isNotEmpty() } ?: value
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        matchAndroid15UI(this, true)
        mBinding = viewDataBinding
        mViewModel.initParams(intent, mPageParamInfo)
        initStatusBar()
        initView()
        initObserver()
        if (savedInstanceState == null) { // 暗夜模式切换，避免重复请求
            mViewModel.loadData(mViewModel.mTabId)
        }

    }

    private fun initObserver() {
        lifecycleScope.launch {
            mViewModel.uiState.collect { state ->
                LogUtils.d(TAG, "state=$state")
                when (state) {
                    is DataState.Init -> {/*do nothing*/}
                    is DataState.AdSuccess ->  {/*do nothing*/}
                    is DataState.Timeout ->  {/*do nothing*/}
                    is DataState.Loading -> showLoading()
                    is DataState.Empty -> showEmpty()
                    is DataState.NetworkError -> showNetworkError()
                    is DataState.Success -> showContent(state.data)
                }
            }
        }
    }

    private fun hideAllView() {
        mBinding?.collectionRecyclerview?.visibility = View.GONE
        mBinding?.collectionEmptyView?.layoutEmptyViewRoot?.visibility = View.GONE
        mUILoadingGifUtil.setVisibility(View.GONE)
        mUINetworkErrorUtil.setVisibility(View.GONE)
    }

    private fun setTitleVisible(visible: Boolean) {
        if (visible) {
            mBinding?.collectionIncludeTitle?.layoutCollectionTitle?.visibility = View.VISIBLE
        } else {
            mBinding?.collectionIncludeTitle?.layoutCollectionTitle?.visibility = View.GONE
        }
    }

    private val onScrollListener = object : RecyclerView.OnScrollListener(){
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            onTitleObserver()
            if (dy > 0) {
                mBinding?.collectionIncludeTitle?.layoutCollectionBack?.visibility = View.GONE
            } else {
                mBinding?.collectionIncludeTitle?.layoutCollectionBack?.visibility = View.VISIBLE
            }
        }
    }

    private val mItemDecoration = object : ItemDecoration(){
        override fun getItemOffsets(
            outRect: Rect,
            view: View,
            parent: RecyclerView,
            state: RecyclerView.State
        ) {
            super.getItemOffsets(outRect, view, parent, state)
            val position = parent.getChildAdapterPosition(view)
            if (position == 2) {
                outRect.top = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(), -18f)
            } else {
                outRect.top = 0
            }
        }
    }

    private fun showContent(data: FeaturedModel) {
        hideAllView()
        setTitleVisible(false)
        mBinding?.layoutRoot?.setBackgroundColor(this.getColor(R.color.recommend_collection_item_bg))
        mBinding?.collectionIncludeTitle?.vTitleBg?.setAlpha(0f)
        mBinding?.collectionIncludeTitle?.layoutCollectionBack?.setImageResource(R.drawable.selector_title_img_back_white)
        mLayoutManager = TRLinearLayoutManager(this)
        outAdapter = OuterCollectionAdapter(data).apply {
            _mActivity = this@RecommendCollectionActivity
            _mCollectionController = this@RecommendCollectionActivity
            _mRecyclerView = mBinding?.collectionRecyclerview
            _mLayoutManager = mLayoutManager
            mFromPage = mViewModel.mFromPage
            mFrom = mViewModel.mValue
            mPageParamInfo = mViewModel.mPageParamInfo
            mScreenName = TRAnalyticsConstant.COLLECTION_PAGE
            onCreate()
        }
        mBinding?.collectionRecyclerview?.apply{
            this.visibility = View.VISIBLE
            setPullRefreshEnabled(false)
            setLoadingMoreEnabled(false)
            this.layoutManager = mLayoutManager
            this.adapter = outAdapter
            removeOnScrollListener(onScrollListener)
            addOnScrollListener(onScrollListener)
            removeItemDecoration(mItemDecoration)
            addItemDecoration(mItemDecoration)
        }
        TRAnalysticsUtil.trackRecCollectionPageTech(mViewModel.mValue, mViewModel.mFromSite, 0, mViewModel.mFromPage)
    }

    private fun showTitleLayout() {
        setTitleVisible(true)
        mBinding?.layoutRoot?.setBackgroundColor(this.getColor(R.color.page_background))
        mBinding?.collectionIncludeTitle?.vTitleBg?.setAlpha(1f)
        mBinding?.collectionIncludeTitle?.layoutCollectionBack?.setImageResource(R.drawable.selector_title_img_back)
    }


    private fun showNetworkError() {
        hideAllView()
        showTitleLayout()
        mUINetworkErrorUtil.setVisibility(View.VISIBLE)
        TRAnalysticsUtil.trackRecCollectionPageTech(mViewModel.mValue, mViewModel.mFromSite, 2, mViewModel.mFromPage)
    }

    private fun showEmpty() {
        hideAllView()
        showTitleLayout()
        mBinding?.collectionEmptyView?.layoutEmptyViewRoot?.visibility = View.VISIBLE
        TRAnalysticsUtil.trackRecCollectionPageTech(mViewModel.mValue, mViewModel.mFromSite, 1, mViewModel.mFromPage)
    }

    private fun showLoading() {
        hideAllView()
        showTitleLayout()
        mUILoadingGifUtil.setVisibility(View.VISIBLE)
    }

    private fun initView() {
        initNetwork()
        mBinding?.collectionIncludeTitle?.layoutCollectionBack?.setOnClickListener {
            onBackClick()
        }
        val pagePvBuilder: PagePvBuilder<*> = PagePvBuilder<PagePvBuilder<*>>()
        pagePvBuilder.setValue(value)
            .setFrom(mViewModel.mFrom)
            .setExtraValue(mViewModel.mTabId)
        TRAnalysticsUtil.trackPV(pagePvBuilder)
    }

    private fun initNetwork() {
        val root = mBinding?.layoutRoot ?: return
        AppNetState.getNetType().observe(this, Observer { netType: NetType ->
            onNetChange(netType.connected())
        })
        mUILoadingGifUtil.inflate(this, root)
        mUINetworkErrorUtil.inflate(this, root, true)
            .setFrom(mViewModel.mFrom)
            .setVisibility(View.GONE)
            .setNetworkConfigureVisibility(View.GONE)
            .setUINetworkErrorOnClickListener(UINetworkErrorUtil.UINetworkErrorOnClickListener { v ->
                if (v == null) {
                    return@UINetworkErrorOnClickListener
                }
                if (v.id == R.id.tv_retry) {
                    if (CommonUtils.isInstantAvailable()) {
                        TRJumpUtil.jumpInstantTab(this@RecommendCollectionActivity)
                    } else {
                        networkErrorRetry()
                    }
                } else if (v.id == R.id.tv_setting) {
                    SysUtils.openSystemMobileNetworkSettings(
                        this@RecommendCollectionActivity,
                        TRHomeUtil.REQUEST_CODE_NETWORK_SETTINGS
                    )
                }
            })
    }

    private fun onNetChange(isConnected: Boolean) {
        if (isConnected && isNetworkErrorIsVisible()) {
            networkErrorRetry()
        }
    }

    private fun isNetworkErrorIsVisible(): Boolean {
        return mUINetworkErrorUtil.visibility == View.VISIBLE
    }

    private fun networkErrorRetry() {
        mViewModel.loadData(mViewModel.mTabId)
    }

    private fun onBackClick() {
        finish()
        val value = TRStringUtil.generateString(TRAnalyticsConstant.COLLECTION_PAGE, "", "", "")
        val builder: ComponentClickBuilder<*> = ComponentClickBuilder<ComponentClickBuilder<*>>()
        builder.setValue(value)
            .setFrom(mViewModel.mFrom)
            .setItemType("")
            .setItemId("")
            .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
            .setItemValue("")
            .setExtraValue(mViewModel.mTabId)
        TRAnalysticsUtil.trackClick(builder)
    }

    private fun initStatusBar() {
        TRStatusBarUtil.enableEdgeToEdge(this)
        TRStatusBarUtil.setStatusBarTransparent(this)
        statusBar = TRStatusBarUtil.createHomeStatusViewAndSetBarColor(this)
        if (statusBar != null) {
            statusBar?.alpha = 0f
            statusBar?.setBackgroundColor(getColor(R.color.recommend_collection_item_bg))
            TRStatusBarUtil.setStatusBarTextColor(window, true)
        }
        val bannerh = resources.getDimensionPixelSize(R.dimen.collection_head_height)
        val statusH = TRStatusBarUtil.getStatusBarHeight(this)

        alphaH = if ((bannerh > statusH)) {
            (bannerh - statusH)
        } else {
            if (bannerh > 0) bannerh else statusH
        }
    }

    private fun onTitleObserver() {
        if (isFinishing || isDestroyed || mLayoutManager == null) {
            return
        }
        var alpha = getTitleViewAlpha()

        if (alpha < 0) {
            alpha = 0f
        } else if (alpha > 1) {
            alpha = 1f
        }

        statusBar?.alpha = alpha

//        mBinding?.collectionIncludeTitle?.vTitleBg?.setAlpha(alpha)
//        changeTopUi(alpha)
    }

    private fun getTitleViewAlpha(): Float {
        val lm = mLayoutManager?:return 1f
        val startVisiblePos: Int = lm.findFirstVisibleItemPosition()
        val endVisiblePos: Int = lm.findLastVisibleItemPosition()
        for (i in startVisiblePos..endVisiblePos) {
            val itemView: View? = lm.findViewByPosition(i)
            if (itemView != null) {
                val objTag = itemView.tag
                if (objTag is CurrentTabConfig) {
                    if (!TextUtils.isEmpty(objTag.bgImageUrl)) {
                        val rect = Rect()
                        itemView.getLocalVisibleRect(rect)

                        var top = rect.top
                        if (top > alphaH) {
                            top = alphaH
                        }
                        totalScrollY = top
                        return ((abs(totalScrollY.toDouble()) * 1f / alphaH).toFloat())
                    }
                }
            }
        }
        return 1f
    }

    private fun changeTopUi(alpha: Float) {
        if (alpha > 0.4) {
            setTitleVisible(true)
            TRStatusBarUtil.setStatusBarTextColor(window, true)
            mBinding?.collectionIncludeTitle?.layoutCollectionBack?.setImageResource(R.drawable.selector_title_img_back)
        } else {
            setTitleVisible(false)
            TRStatusBarUtil.setStatusBarTextColor(window, false)
            mBinding?.collectionIncludeTitle?.layoutCollectionBack?.setImageResource(R.drawable.selector_title_img_back_white)
        }
    }

    override fun onStart() {
        super.onStart()
        outAdapter?.onStart()
    }

    override fun onStop() {
        super.onStop()
        outAdapter?.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        outAdapter?.onDestroy()
    }

    override fun onEventMainThread(mEventMainThreadEntity: EventMainThreadEntity?) {
        super.onEventMainThread(mEventMainThreadEntity)
        if ((mEventMainThreadEntity?.action == Constant.ACTION_GET_ALL_FOR_WIFI_ONLY)) {
            val waitingWiFi = mEventMainThreadEntity?.getBoolean(WifiOnlyTipsActivity.KEY_WAITING_WIFI, false)?:false
            mFeatureBean?.let {
                mViewHolderCallback?.continueExecuteGetAll(it, waitingWiFi)
            }
        }
    }

    override fun askWifiOnlyPermission(callback: IViewHolder, featureBean: FeatureBean) {
        mViewHolderCallback = callback
        mFeatureBean = featureBean
        if (NetworkUtils.isNetworkAvailable(this)) {
            if (!TextUtils.equals(NetworkUtils.getNetworkState(this), NetworkState.WIFI) && PalmPlayNetworkDownloadStateManager.isDataChargesLimit()) {
                val value = TRStringUtil.generateString(TRAnalyticsConstant.COLLECTION_PAGE, "", "", "")
                WifiOnlyTipsActivity.wifiDownloadOnlyUpdateAll(this, 0, value)
            } else {
                mViewHolderCallback?.continueExecuteGetAll(featureBean, false)
            }
        } else {
            mViewHolderCallback?.continueExecuteGetAll(featureBean, false)
        }
    }

    fun getInAppStatus(): String {
        LogUtils.d(LogUtils.TAG_TR_INSTALL_COLLECTION, "mInapp: ${mViewModel.mInApp}")
        return mViewModel.mInApp
    }

}
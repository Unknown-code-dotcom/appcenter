// TOP SECRET
package com.afmobi.palmplay.configs.v6_3;

import android.text.TextUtils;



/**
 * Created by zz on 2016/11/8.
 */
public class BannerType {

    public static final String BANNER = "Banner";
    public static final int BANNER_TYPE = 1;

    public static final String INNER_ITEM = "INNER_ITEM";
    public static final int INNER_ITEM_TYPE = 2;

    public static final String OUTER_URL = "OUTER_URL";
    public static final int OUTER_URL_TYPE = 3;

    public static final String INNER_SINGER = "INNER_SINGER";
    public static final int INNER_SINGER_TYPE = 4;

    public static final String INNER_RANK = "INNER_RANK";
    public static final int INNER_RANK_TYPE = 5;

    public static boolean isTypeBanner(String typeName){
        return BANNER.equals(typeName);
    }

    public static boolean isTypeInnerItem(String typeName){
        return TextUtils.isEmpty(typeName) ? false : typeName.equals(INNER_ITEM);
    }

    public static boolean isTypeOuterUrl(String typeName){
        return TextUtils.isEmpty(typeName) ? false : typeName.equals(OUTER_URL);
    }

    public static boolean isTypeInnerSinger(String typeName){
        return TextUtils.isEmpty(typeName) ? false : typeName.equals(INNER_SINGER);
    }

    public static boolean isTypeInnerRank(String typeName){
        return TextUtils.isEmpty(typeName) ? false : typeName.equals(INNER_RANK);
    }

}

package com.afmobi.palmplay.comment;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.category.v6_3.OnItemInteractionListener;
import com.afmobi.palmplay.customview.RatingBar;
import com.afmobi.palmplay.main.adapter.BaseRecyclerViewHolder;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.CommentInfo;

import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.palmplay.va.PsVaManager;
import com.afmobi.palmplay.viewmodel.detail.AppCommentsTabViewModel;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.NetworkUtils;

import com.transsion.core.log.LogUtils;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsnet.store.R;
import com.transsnet.store.databinding.LayoutDetailCommentInfoBinding;

//详情页第一项item的viewModel，包含ratingInfo，星级选项，热门/最新选项
public class DetailHeaderViewHolder extends BaseRecyclerViewHolder {

    public final LayoutDetailCommentInfoBinding binding;

    private int star; // 选择的星级

    private int itemCount;

    private CommentInfo commentInfo;

    private String appName;
    private String packageName;

    private String itemId;

    private int pageIndex;

    private int pageSize;
    private AppInfo appInfo;
    private boolean isCustomized;
    private boolean ifAiTranslateEnabled;
    private UserAvatarAdapter mAdapter;

    private AppCommentsTabViewModel viewModel;

    // 初始化RatingInfo信息
    private int displayType = 0;
    private int pbOneStar = 0; //星级进度条
    private int pbTwoStar = 0;
    private int pbThreeStar = 0;
    private int pbFourStar = 0;
    private int pbFiveStar = 0;
    private float ratingBar = 0; //自己的评星
    private int total = 0;
    private double ratingStar = 0; //应用的评星

    private int newRatingBar = 0; //记录新的自己的评星

    private boolean isChangeMyStar = false;

    //设置选择的星级
    public DetailHeaderViewHolder setStar(int star) {
        this.star = star;
        return this;
    }

    public DetailHeaderViewHolder setAppName(String appName) {
        this.appName = appName;
        return this;
    }


    public DetailHeaderViewHolder setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
        return this;
    }

    public DetailHeaderViewHolder setPageSize(int pageSize) {
        this.pageSize = pageSize;
        return this;
    }

    public DetailHeaderViewHolder setItemId(String itemId) {
        this.itemId = itemId;
        return this;
    }


    public DetailHeaderViewHolder setViewModel(AppCommentsTabViewModel viewModel) {
        this.viewModel = viewModel;
        return this;
    }

    public DetailHeaderViewHolder setAppInfo(AppInfo appInfo) {
        this.appInfo = appInfo;
        return this;
    }

    public DetailHeaderViewHolder setItemCount(int itemCount) {
        this.itemCount = itemCount;
        return this;
    }


    public DetailHeaderViewHolder setCustomized(boolean isCustomized) {
        this.isCustomized = isCustomized;
        return this;
    }

    public DetailHeaderViewHolder setAiTranslateEnabled(boolean enabled) {
        this.ifAiTranslateEnabled = enabled;
        return this;
    }


    public DetailHeaderViewHolder setPackageName(String packageName) {
        this.packageName = packageName;
        return this;
    }


    public DetailHeaderViewHolder(LayoutDetailCommentInfoBinding binding, Context context, OnItemInteractionListener interactionListener) {
        super(binding.getRoot());
        mAdapter = new UserAvatarAdapter();
        this.binding = binding;

        //初始化设置
        binding.buttonAll.setSelected(true);
        binding.layoutCommentYou.setIsContentVisible(true);

        binding.commentRatingbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public boolean onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (fromUser) {
                    if (appInfo == null) {
                        return false;
                    }

                    if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                        ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
                        return false;
                    }

                    FileDownloadInfo downloadedInfo = PsVaManager.getInstance().getVaInstallResult(appInfo.packageName);

                    if (!InstalledAppManager.getInstance().isInstalled(appInfo.packageName) && downloadedInfo == null) {
                        ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_install_for_feedback);
                        return false;
                    }

                    commentInfo.ratingInfo.myStar = (int)rating;
                    viewModel.submitRating(appInfo.name, appInfo.itemID, appInfo.packageName, (int) rating);
                    //newRatingBar = (int)rating ;
                    interactionListener.onUpdateMyStar((int) rating);

                    String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, "", "", "");
                    ComponentClickBuilder builder = new ComponentClickBuilder();
                    builder.setValue(value)
                            .setFrom(mFrom)
                            .setTopicType("")
                            .setTopicId("")
                            .setItemType(appInfo == null ? "" : appInfo.detailType)
                            .setItemId(appInfo == null ? "" : appInfo.itemID)
                            .setButtonType(TRAnalyticsConstant.RATING)
                            .setItemValue(appInfo == null ? "" : appInfo.packageName)
                            .setExtraValue("")
                            .setItemFrom(null);
                    TRAnalysticsUtil.trackClick(builder);
                }
                return true;
            }
        });

        View.OnClickListener buttonListener = v -> {
            if (interactionListener != null) {
                String buttonId = "";
                switch (v.getId()) {
                    case R.id.button_all:
                        //状态设置
                        buttonId = "buttonAll";
                        star = 0;
                        binding.button5Star.setSelected(false);
                        binding.button4Star.setSelected(false);
                        binding.button3Star.setSelected(false);
                        binding.button2Star.setSelected(false);
                        binding.button1Star.setSelected(false);
                        binding.buttonAll.setSelected(true);
                        break;
                    case R.id.button_5_star:
                        buttonId = "button5";
                        binding.button5Star.setSelected(true);
                        binding.button4Star.setSelected(false);
                        binding.button3Star.setSelected(false);
                        binding.button2Star.setSelected(false);
                        binding.button1Star.setSelected(false);
                        binding.buttonAll.setSelected(false);
                        star = 5;
                        break;
                    case R.id.button_4_star:
                        buttonId = "button4";
                        binding.button5Star.setSelected(false);
                        binding.button4Star.setSelected(true);
                        binding.button3Star.setSelected(false);
                        binding.button2Star.setSelected(false);
                        binding.button1Star.setSelected(false);
                        binding.buttonAll.setSelected(false);
                        star = 4;
                        break;
                    case R.id.button_3_star:
                        buttonId = "button3";
                        binding.button5Star.setSelected(false);
                        binding.button4Star.setSelected(false);
                        binding.button3Star.setSelected(true);
                        binding.button2Star.setSelected(false);
                        binding.button1Star.setSelected(false);
                        binding.buttonAll.setSelected(false);
                        star = 3;
                        break;
                    case R.id.button_2_star:
                        buttonId = "button2";
                        binding.button5Star.setSelected(false);
                        binding.button4Star.setSelected(false);
                        binding.button3Star.setSelected(false);
                        binding.button2Star.setSelected(true);
                        binding.button1Star.setSelected(false);
                        binding.buttonAll.setSelected(false);
                        star = 2;
                        break;
                    case R.id.button_1_star:
                        buttonId = "button1";
                        binding.button5Star.setSelected(false);
                        binding.button4Star.setSelected(false);
                        binding.button3Star.setSelected(false);
                        binding.button2Star.setSelected(false);
                        binding.button1Star.setSelected(true);
                        star = 1;
                        binding.buttonAll.setSelected(false);
                        break;

                    case R.id.softType_menu_button:
                        buttonId = "softType_menu_button";
                        break;

                    case R.id.ai_translate_button:
                        buttonId = "ai_translate_button";
                        break;

                    case R.id.edit_Your_Reviews_Button:
                        buttonId = "edit_Your_Reviews_Button";
                        break;

                    case R.id.tv_write_comment:
                        buttonId = "tv_write_comment";
                        break;

                }
                interactionListener.onButtonClicked(buttonId, v);

            }
        };
        binding.button5Star.setOnClickListener(buttonListener);
        binding.button4Star.setOnClickListener(buttonListener);
        binding.button3Star.setOnClickListener(buttonListener);
        binding.button2Star.setOnClickListener(buttonListener);
        binding.button1Star.setOnClickListener(buttonListener);
        binding.buttonAll.setOnClickListener(buttonListener);
        binding.softTypeMenuButton.setOnClickListener(buttonListener);
        binding.aiTranslateButton.setOnClickListener(buttonListener);
        binding.tvWriteComment.setOnClickListener(buttonListener);
        binding.layoutCommentYou.layoutCommentItem.editYourReviewsButton.setOnClickListener(buttonListener);
        binding.commentRatingbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public boolean onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (fromUser) {
                    if (appInfo == null) {
                        return false;
                    }

                    if (!NetworkUtils.isNetworkAvailable(PalmplayApplication.getAppInstance())) {
                        ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_no_network);
                        return false;
                    }

                    FileDownloadInfo downloadedInfo = PsVaManager.getInstance().getVaInstallResult(appInfo.packageName);

                    if (!InstalledAppManager.getInstance().isInstalled(appInfo.packageName) && downloadedInfo == null) {
                        ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.tip_install_for_feedback);
                        return false;
                    }

                    viewModel.submitRating(appInfo.name, appInfo.itemID, appInfo.packageName, (int) rating);

                    String value = TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, "", "", "");
                    ComponentClickBuilder builder = new ComponentClickBuilder();
                    builder.setValue(value)
                            .setFrom(mFrom)
                            .setTopicType("")
                            .setTopicId("")
                            .setItemType(appInfo == null ? "" : appInfo.detailType)
                            .setItemId(appInfo == null ? "" : appInfo.itemID)
                            .setButtonType(TRAnalyticsConstant.RATING)
                            .setItemValue(appInfo == null ? "" : appInfo.packageName)
                            .setExtraValue("")
                            .setItemFrom(null);
                    TRAnalysticsUtil.trackClick(builder);
                }
                return true;
            }
        });

    }


    public void bind(CommentInfo commentInfo) {
//        LogUtils.d("_dataShow","myStar = " +commentInfo.ratingInfo.myStar);
        this.commentInfo = commentInfo;
        // star初始化
        binding.button5Star.setSelected(star == 5);
        binding.button4Star.setSelected(star == 4);
        binding.button3Star.setSelected(star == 3);
        binding.button2Star.setSelected(star == 2);
        binding.button1Star.setSelected(star == 1);
        binding.buttonAll.setSelected(star == 0);

        boolean isContentNull = commentInfo.content == null;
        boolean isCpContentNull = commentInfo.cpContent == null;

        String date = viewModel.getTimeFormat(commentInfo.ddate);
        String cpDate = viewModel.getTimeFormat(commentInfo.cpDate);
        String txt = binding.tvTapToRate.getContext().getString(R.string.tap_to_rate) + ':';
        String txt_insufficient_ratings = binding.tvTapToRate.getContext().getString(R.string.txt_insufficient_ratings);
        String txt_no_ratings = binding.tvTapToRate.getContext().getString(R.string.txt_no_ratings);

        if (appInfo != null && isCustomized) {
            Drawable emptyDrawable = ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.ic_detail_comment_rating_star_hollow_offer_new);
            Drawable solidDrawable = ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.ic_detail_comment_rating_star_solid_offer_new);
            binding.commentRatingbar.setStarDrawable(emptyDrawable, solidDrawable);
            binding.setIsOfferStyle(true);
        }

        if (appInfo != null && isCustomized && !TextUtils.isEmpty(appInfo.backgroundRgb)) {
            int bg = CommonUtils.parseColor(appInfo.backgroundRgb);
            binding.softTypeMenuButton.setBackgroundColor(bg);
            binding.aiTranslateButton.setBackgroundColor(bg);
        }

        //RatingInfo设置
        if (commentInfo != null && commentInfo.ratingInfo != null) {
            pbFiveStar = commentInfo.ratingInfo.displayType == 1 ? 0 : viewModel.getStarSpargerByStart(commentInfo.ratingInfo.fiveStarCnt, commentInfo.ratingInfo.total);
            pbFourStar = commentInfo.ratingInfo.displayType == 1 ? 0 : viewModel.getStarSpargerByStart(commentInfo.ratingInfo.fourStarCnt, commentInfo.ratingInfo.total);
            pbThreeStar = commentInfo.ratingInfo.displayType == 1 ? 0 : viewModel.getStarSpargerByStart(commentInfo.ratingInfo.threeStarCnt, commentInfo.ratingInfo.total);
            pbTwoStar = commentInfo.ratingInfo.displayType == 1 ? 0 : viewModel.getStarSpargerByStart(commentInfo.ratingInfo.twoStarCnt, commentInfo.ratingInfo.total);
            pbOneStar = commentInfo.ratingInfo.displayType == 1 ? 0 : viewModel.getStarSpargerByStart(commentInfo.ratingInfo.oneStarCnt, commentInfo.ratingInfo.total);
            displayType = commentInfo.ratingInfo.displayType;
            ratingBar = commentInfo.ratingInfo.myStar; //点击我的评星，有新的RatingBar的值
            ratingStar = commentInfo.ratingInfo.star;
            total = commentInfo.ratingInfo.total;
        }

        binding.pbFivestar.setProgress(pbFiveStar);
        binding.pbFourstar.setProgress(pbFourStar);
        binding.pbThreestar.setProgress(pbThreeStar);
        binding.pbTwostar.setProgress(pbTwoStar);
        binding.pbOnestar.setProgress(pbOneStar);
        binding.commentRatingbar.setRating(ratingBar);
        binding.tvStarTotal.setText(getStarTotal(total));
        binding.tvRatingStar.setText(String.valueOf(ratingStar));

        if (displayType == 2) {
            binding.layoutDisplayType.setVisibility(View.GONE);
        } else {
            binding.layoutDisplayType.setVisibility(View.VISIBLE);
            String textResource = (displayType == 1) ? txt_insufficient_ratings : txt_no_ratings;
            binding.tvDisplayType.setText(textResource);
        }

        //可见性设置
        if (star == 0 && !isContentNull) {
            binding.layoutCommentYou.setIsContentVisible(true);
            if (!isCpContentNull) {
                binding.layoutCommentYou.layoutCommentItem.commentLayout.setVisibility(View.VISIBLE);
            } else {
                binding.layoutCommentYou.layoutCommentItem.commentLayout.setVisibility(View.GONE);
            }
        } else {
            binding.layoutCommentYou.setIsContentVisible(false);
        }

        if (isCustomized) {
            binding.layoutCommentYou.layoutCommentItem.cpContent.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector_offer));
            binding.layoutCommentYou.layoutCommentItem.cpContent.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector_offer));
            binding.layoutCommentYou.layoutCommentItem.tvComment.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector_offer));
            binding.layoutCommentYou.layoutCommentItem.tvComment.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector_offer));
        } else {
            binding.layoutCommentYou.layoutCommentItem.cpContent.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector));
            binding.layoutCommentYou.layoutCommentItem.cpContent.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector));
            binding.layoutCommentYou.layoutCommentItem.tvComment.setDrawableShrink(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_collapse_selector));
            binding.layoutCommentYou.layoutCommentItem.tvComment.setDrawableExpand(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.btn_detail_information_expand_selector));
        }

        //我的评论内容显示
        binding.layoutCommentYou.layoutCommentItem.cpContent.setText(commentInfo.cpContent);
        binding.layoutCommentYou.layoutCommentItem.cpNickName.setText(commentInfo.cpNickName + ':');
        binding.layoutCommentYou.layoutCommentItem.cpDate.setText(cpDate);
        binding.layoutCommentYou.layoutCommentItem.tvModel.setText(commentInfo.model);
        binding.layoutCommentYou.layoutCommentItem.tvName.setText(commentInfo.username);
        binding.layoutCommentYou.layoutCommentItem.tvComment.setText(commentInfo.content);
        binding.layoutCommentYou.layoutCommentItem.rbRate.setRating(commentInfo.star);
        binding.layoutCommentYou.layoutCommentItem.tvTime.setText(date);
        binding.tvTapToRate.setText(txt);

        //offer
        binding.layoutCommentYou.layoutCommentItem.setIsOfferStyle(isOfferStyle());
        binding.layoutCommentYou.setIsOfferStyle(isOfferStyle());
        binding.setIsOfferStyle(isOfferStyle());
        LogUtils.d("_dataShow","isCustomized =" + isCustomized);
        //UI更新
        binding.layoutCommentYou.layoutCommentItem.setMCommentInfo(commentInfo);
        binding.aiTranslateButton.setVisibility(ifAiTranslateEnabled ? View.VISIBLE : View.GONE);
        binding.executePendingBindings();
    }

    public String getStarTotal(int total) {
        String dst = String.valueOf(total);
        if (total > 99999) {
            dst = "99999+";
        }
        return dst;
    }

    public boolean isOfferStyle() {
        return isCustomized;
    }
}








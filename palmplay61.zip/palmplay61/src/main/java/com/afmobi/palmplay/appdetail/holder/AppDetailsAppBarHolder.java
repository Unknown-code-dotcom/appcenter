package com.afmobi.palmplay.appdetail.holder;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.palmplay.appdetail.TrackUtils;
import com.afmobi.palmplay.appdetail.model.AppDetailData;
import com.afmobi.palmplay.appdetail.viewmodel.TRNewAppViewModel;
import com.afmobi.palmplay.detail.AppDetailsRecyclerViewAdapter;
import com.afmobi.palmplay.diff.TRReflectManager;
import com.afmobi.palmplay.firebase.FirebaseConstants;
import com.afmobi.palmplay.manager.InstalledAppManager;
import com.afmobi.palmplay.manager.PreciseTrackManager;
import com.afmobi.palmplay.model.InstalledAppInfo;
import com.afmobi.palmplay.model.v6_0.TabType;
import com.afmobi.palmplay.model.v6_0.TagItem;
import com.afmobi.util.CommonUtils;
import com.afmobi.util.Constant;
import com.afmobi.util.Constants;
import com.afmobi.util.DisplayUtil;
import com.afmobi.util.PaletteHelper;
import com.afmobi.util.TRJumpUtil;
import com.afmobi.util.statusbar.TRNavigationBarUtil;
import com.afmobi.util.statusbar.TRStatusBarUtil;
import com.google.android.material.appbar.AppBarLayout;
import com.transsion.palmstorecore.util.ToastManager;
import com.transsion.palmstorecore.analytics.ComponentClickBuilder;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.glide.GlideUtils;
import com.transsion.palmstorecore.util.TRApplicationContextUtil;
import com.transsion.palmstorecore.util.TRReflectConstants;
import com.transsion.palmstorecore.util.TRStringUtil;
import com.transsnet.store.BuildConfig;
import com.transsnet.store.R;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

public class AppDetailsAppBarHolder extends BaseAppDetailHolder implements AppBarLayout.OnOffsetChangedListener, View.OnClickListener {

    private int statusColor;
    private View statusBar;
    private int currentOffset;
    private int setAlpha = 0;

    private HashSet<Uri> mSelectUri = new HashSet<>();
    private HashSet<String> mSelectTypes = new HashSet<>();

    private String mValue;

    public AppDetailsAppBarHolder(FragmentActivity activity, TRNewAppViewModel mAppDetailModel, CommonAppDetailView commonAppDetailView, String mValue) {
        super(activity, mAppDetailModel, commonAppDetailView);
        this.mValue = mValue;
    }

    @Override
    public void initHolder() {

        if (mActivity ==null || mActivity.isFinishing() || mActivity.isDestroyed()) {
            return;
        }
        initView();

        initStatusBar();
        onDetailStyleObserver();
        initTitleName();
    }

    private void initView(){
        commonAppDetailView.mBinding.titleInclude.ibDetailShare.setOnClickListener(this);
        commonAppDetailView.mBinding.titleInclude.ibDetailSearch.setOnClickListener(this);
        commonAppDetailView.mBinding.titleInclude.searchDetailImg.setOnClickListener(this);
        commonAppDetailView.mBinding.titleInclude.layoutDetailSearch.setOnClickListener(this);
        commonAppDetailView.mBinding.titleInclude.layotDetailBack.setOnClickListener(this);
        commonAppDetailView.mBinding.titleInclude.layoutDetailDownload.setOnClickListener(this);
        commonAppDetailView.mBinding.titleInclude.gameDetailVaGame.setOnClickListener(this);
    }

    public void initHotWord(TagItem tagItem) {
        if (tagItem == null) return;
        commonAppDetailView.mBinding.titleInclude.textSearchView.setIsOfferStyle(commonAppDetailView.isCustomizedStyle());
        commonAppDetailView.mBinding.titleInclude.textSearchView.setCurrentTagItem(tagItem);
    }

    public void updateHotWord(TagItem tagItem) {
        if (tagItem == null) return;
        commonAppDetailView.mBinding.titleInclude.textSearchView.setIsOfferStyle(commonAppDetailView.isCustomizedStyle());
        commonAppDetailView.mBinding.titleInclude.textSearchView.setTagItem(tagItem);
    }

    private void initStatusBar() {
        commonAppDetailView.mBinding.appbarLayout.addOnOffsetChangedListener(this);
        commonAppDetailView.mBinding.appbarLayout.post(new Runnable() {//AppbarLayout区域过大时，偶尔无法滑动问题解决
            @Override
            public void run() {
                CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) commonAppDetailView.mBinding.appbarLayout.getLayoutParams();
                AppBarLayout.Behavior behavior = (AppBarLayout.Behavior) layoutParams.getBehavior();
                if(behavior != null) {
                    behavior.setDragCallback(new AppBarLayout.Behavior.DragCallback() {
                        @Override
                        public boolean canDrag(@NonNull AppBarLayout appBarLayout) {
                            return true;
                        }
                    });
                }
            }
        });
        commonAppDetailView.mBinding.rlTab.setBackgroundResource(DisplayUtil.isScreenTypeOLED() ? R.drawable.detail_tab_bg_oled : R.drawable.detail_tab_bg);
        commonAppDetailView.mBinding.rootView.setBackgroundColor(ContextCompat.getColor(mActivity, DisplayUtil.getBackgroundColorId()));

        statusColor = ContextCompat.getColor(mActivity, DisplayUtil.getBackgroundColorId());
        TRStatusBarUtil.setStatusBarTransparent(mActivity);
        statusBar = TRStatusBarUtil.createDetailStatusViewAndSetBarColor(mActivity, statusColor);
        if(statusBar != null){
            statusBar.setAlpha(0);
        }

        TRStatusBarUtil.setStatusBarTextColor(mActivity.getWindow(), true);
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        if(mActivity.isFinishing() || mActivity.isDestroyed()) {
            return;
        }

        int abOffset = Math.abs(verticalOffset);
        float alpha = abOffset / (float) appBarLayout.getTotalScrollRange();//796

        if (abOffset > currentOffset) {//上拉
            setAlphaByScroll(abOffset, alpha);
        } else if (abOffset == currentOffset) {//静止
        } else {//下拉
            setAlphaByScroll(abOffset, alpha);
        }
        currentOffset = abOffset;

        if(statusBar != null){
            statusBar.setAlpha(alpha);
        }
    }

    public void initTitleName(){
        int supportOverlay = (Integer) mAppDetailModel.getParam(Constant.KV_SUPPORT_OVERLAY);
        String localName = (String) mAppDetailModel.getParam(Constant.KV_LOCAL_NAME);

        if (commonAppDetailView.mAppInfo == null) {
            String name = (String) mAppDetailModel.getParam("mArgumentsTitle");
            if (supportOverlay == 1 && !TextUtils.isEmpty(localName)) {
                name = localName;
            }
            commonAppDetailView.headerViewBinding.tvName.setText(name);
            commonAppDetailView.headerViewBinding.tvName.requestFocus();
            commonAppDetailView.mBinding.titleInclude.tvTitleName.setText(name);
        } else {
            String name = commonAppDetailView.mAppInfo.name;
            if (supportOverlay == 1 && !TextUtils.isEmpty(localName)) {
                name = localName;
            }
            commonAppDetailView.headerViewBinding.tvName.setText(name);
            commonAppDetailView.headerViewBinding.tvName.requestFocus();
            commonAppDetailView.mBinding.titleInclude.tvTitleName.setText(name);
        }
        updateDetailShare();
    }

    private void onDetailStyleObserver() {
        if(commonAppDetailView.isCustomizedStyle()) {
            CoordinatorLayout.LayoutParams lp = (CoordinatorLayout.LayoutParams) commonAppDetailView.mBinding.appbarLayout.getLayoutParams();
            lp.height = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_offer_appbar_h);
            commonAppDetailView.mBinding.appbarLayout.setLayoutParams(lp);
            if (commonAppDetailView.mBinding.vsBanner.getViewStub() != null) {
                commonAppDetailView.mBinding.vsBanner.getViewStub().inflate();
            }
            ImageView ivBanner = commonAppDetailView.mBinding.vsBanner.getRoot().findViewById(R.id.iv_banner);
            if (ivBanner!=null) {
                GlideUtils.setImageUrl(ivBanner, commonAppDetailView.mAppInfo.bannerUrl);
            }
            int bg = CommonUtils.parseColor(commonAppDetailView.mAppInfo.backgroundRgb);
            commonAppDetailView.mBinding.rootView.setBackgroundColor(bg);
//            commonAppDetailView.mBinding.layoutContent.setBackgroundColor(bg);

            RelativeLayout.LayoutParams lp2 = (RelativeLayout.LayoutParams) commonAppDetailView.mBinding.vGradient.getLayoutParams();
            lp2.height = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_offer_gradient_h);
            lp2.topMargin = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_offer_gradient_margin_top);
            commonAppDetailView.mBinding.vGradient.setLayoutParams(lp2);
            int s = PaletteHelper.getArgbByColor(bg, 0);
            int c = PaletteHelper.getArgbByColor(bg, 1f);
            int e = c;
            int y = mActivity.getResources().getDimensionPixelSize(R.dimen.detail_offer_gradient_end_y);
            PaletteHelper.setGradientDrawable(commonAppDetailView.mBinding.vGradient, s, c, e, 0, 0, y);

            commonAppDetailView.mBinding.titleInclude.rlTitle.setBackgroundColor(bg);
            commonAppDetailView.mBinding.titleInclude.setIsOfferStyle(true);

//            int mainColor = ContextCompat.getColor(mActivity, R.color.detail_offer_main_color);
            commonAppDetailView.mBinding.setIsOfferStyle(true);
            commonAppDetailView.mBinding.executePendingBindings();

//            commonAppDetailView.mBinding.tabLayout.setSelectedTabIndicatorColor(mainColor);
            int position = commonAppDetailView.mBinding.tabLayout.getSelectedTabPosition();
            commonAppDetailView.onTabPageChanged(position);
            commonAppDetailView.mBinding.rlTab.setBackgroundColor(bg);
            commonAppDetailView.mBinding.layoutBottom.setBackgroundColor(bg);

            statusBar.setBackgroundColor(bg);
            TRStatusBarUtil.setStatusBarTextColor(mActivity.getWindow(), false);
            TRNavigationBarUtil.setNavigationBarColor(mActivity, bg);

            //tab 挪到setupPager中
//            for(int i = 0; i < appDetailViewHolder.mBinding.tabLayout.getTabCount(); i++) {
//                TabLayout.Tab tab = appDetailViewHolder.mBinding.tabLayout.getTabAt(i);
//                if (tab != null && tab.getCustomView() != null) {
//                    TextView tv = tab.getCustomView().findViewById(android.R.id.text1);
//                    if (tv != null) {
//                        ColorStateList tabColor = ContextCompat.getColorStateList(mActivity, R.color.detail_tab_text_color_offer);
//                        tv.setTextColor(tabColor);
//                    }
//                }
//            }

            String extra = CommonUtils.getDetailExtraValue(Constant.KEY_NONE, null, AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD, -1, null);
            PreciseTrackManager.onDetailTrack(TRAnalyticsConstant.DETAIL_PAGE, TRAnalyticsConstant.COMPONENT_TOP_PICTURE, commonAppDetailView.mFrom,
                    AppDetailsRecyclerViewAdapter.TAB_TYPE_HEAD, String.valueOf(-1), commonAppDetailView.mAppInfo, extra, "");

            if(commonAppDetailView.isCustomizedStyle()){
                commonAppDetailView.mBinding.titleInclude.gameDetailVaGame.isOfferStyle();
            }
        }
    }

    protected void setAlphaByScroll(int offset, float alpha) {
        commonAppDetailView.mBinding.titleInclude.rlTitle.setAlpha(alpha);
        float reverseAlpha = Math.max(1 - alpha, 0);
        commonAppDetailView.mBinding.vTabBg.setAlpha(reverseAlpha);

        if(commonAppDetailView.isCustomizedStyle()) {
            int iAlpha = (int) (255 * reverseAlpha);
            if (commonAppDetailView.mBinding.titleInclude.layotDetailBack.getBackground() != null) {
                commonAppDetailView.mBinding.titleInclude.layotDetailBack.getBackground().setAlpha(iAlpha);
            }
            if (commonAppDetailView.mBinding.titleInclude.layoutDetailSearch.getBackground() != null) {
                commonAppDetailView.mBinding.titleInclude.layoutDetailSearch.getBackground().setAlpha(iAlpha);
            }
            if (commonAppDetailView.mBinding.titleInclude.ibDetailShare.getBackground() != null) {
                commonAppDetailView.mBinding.titleInclude.ibDetailShare.getBackground().setAlpha(iAlpha);
            }
            if (commonAppDetailView.mBinding.titleInclude.ivDownload.getBackground() != null) {
                commonAppDetailView.mBinding.titleInclude.ivDownload.getBackground().setAlpha(iAlpha);
            }
            if (commonAppDetailView.mBinding.titleInclude.gameDetailVaGame != null) {
                commonAppDetailView.mBinding.titleInclude.gameDetailVaGame.setAlpha(iAlpha);
            }
        }

        if(alpha >= 1) {
            if (setAlpha != 1) {//减少重复的情况
                setAlpha = 1;
                commonAppDetailView.mBinding.titleInclude.tvTitleName.setVisibility(View.VISIBLE);
                commonAppDetailView.mBinding.titleInclude.tvTitleName.requestFocus();

                commonAppDetailView.mBinding.titleInclude.layoutDetailSearch.setVisibility(View.GONE);
                commonAppDetailView.mBinding.titleInclude.ibDetailSearch.setVisibility(View.VISIBLE);
                // Activity manages hot word carousel lifecycle
            }
        }else {
            if (setAlpha != 0) {
                setAlpha = 0;
                if (commonAppDetailView.headerViewBinding != null) {
                    commonAppDetailView.headerViewBinding.tvName.requestFocus();
                }
                commonAppDetailView.mBinding.titleInclude.tvTitleName.setVisibility(View.GONE);

                commonAppDetailView.mBinding.titleInclude.layoutDetailSearch.setVisibility(View.VISIBLE);
                commonAppDetailView.mBinding.titleInclude.ibDetailSearch.setVisibility(View.GONE);
                // Activity manages hot word carousel lifecycle
            }
        }
    }

    //改造自 updateDetailInfo
    private void updateDetailShare() {
        InstalledAppInfo appInfo = InstalledAppManager.getInstance().get(commonAppDetailView.mAppInfo.packageName);
        if (appInfo != null && !TRApplicationContextUtil.isProject()) {
            File file = new File(appInfo.filePath);
            commonAppDetailView.mBinding.titleInclude.ibDetailShare.setVisibility(View.VISIBLE);
            String type = TRReflectManager.getInstance().getMimeType(file.getName());
            mSelectUri.add(Uri.fromFile(file));
            mSelectTypes.add(type);
        } else {
            commonAppDetailView.mBinding.titleInclude.ibDetailShare.setVisibility(View.GONE);
        }
    }

    private void confirmSend() {
        if (TRReflectManager.getInstance().isAtLeastQ()) {
            if (!TRReflectManager.getInstance().isLocationServiceEnable(mActivity.getApplicationContext())) {
                ToastManager.getInstance().showS(PalmplayApplication.getAppInstance(), R.string.warning_open_location_service);
                return;
            }
        }
        ArrayList<String> typeList = new ArrayList<>();
        TRReflectManager.getInstance().save(mSelectUri);
        typeList.addAll(mSelectTypes);
        try {
            Intent intent = new Intent(mActivity, TRReflectManager.getInstance().getDesClass(TRReflectConstants.P2P_MODEL, TRReflectConstants.P2P_SEND_MODEL));
            intent.putExtra("fromPage", Constants.Detail_SOFT);
            intent.setAction(Constants.XSHARE_SEND_ACTION);
            intent.putExtra("is_send", true);
            intent.putStringArrayListExtra("types", typeList);
            mActivity.startActivity(intent);
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        TRAnalysticsUtil.trackShareCommon(1, Constants.Detail_Ficon_Code, commonAppDetailView.mAppInfo == null ? "" : commonAppDetailView.mAppInfo.packageName, Constants.Detail_SOFT);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.layot_detail_back){
            String requestFinished = "0";
            if (!AppDetailData.getInstance().isFeatureRequestFinished()) {
                requestFinished = "1";
            }
            String value = mValue;
            ComponentClickBuilder builder = new ComponentClickBuilder();
            builder.setValue(value)
                    .setFrom(commonAppDetailView.mFrom)
                    .setTopicType("")
                    .setTopicId(commonAppDetailView.mAppInfo == null ? "" : commonAppDetailView.mAppInfo.topicID)
                    .setExtras(requestFinished)
                    .setItemType(commonAppDetailView.mAppInfo == null ? "" : commonAppDetailView.mAppInfo.detailType)
                    .setItemId(commonAppDetailView.mAppInfo == null ? "" : commonAppDetailView.mAppInfo.itemID)
                    .setButtonType(TRAnalyticsConstant.BUTTON_BACK)
                    .setItemValue(commonAppDetailView.mAppInfo == null ? "" : commonAppDetailView.mAppInfo.packageName)
                    .setExtraValue("");
            TRAnalysticsUtil.trackClick(builder);
            mActivity.finish();
        } else if (id == R.id.layout_detail_download){
            TRJumpUtil.into(mActivity, false, commonAppDetailView.mPageParamInfo, mValue);
            TrackUtils.trackCommon(FirebaseConstants.EVENT_HP_DOWNLOAD_CLICK);
            mActivity.finish();
        } else if (id == R.id.game_detail_va_game){
            TRJumpUtil.intoMyGames(mActivity, false, commonAppDetailView.mPageParamInfo, mValue);
        } else if (id == R.id.layout_detail_search){
            TagItem currentTag = commonAppDetailView.mBinding.titleInclude.textSearchView.getCurrentTagItem();
            String textTag = currentTag != null ? currentTag.term : "";
            String searchSoft = mActivity.getString(R.string.search_soft);
            if (TextUtils.isEmpty(textTag)){
                textTag = searchSoft;
            }
            TRJumpUtil.switchToSearchActivity(mActivity, TabType.SOFT, "",
                    false, textTag, true, searchSoft, commonAppDetailView.mPageParamInfo,
                    mValue, TRAnalyticsConstant.BUTTON_SEARCH_BOX,false);
            TrackUtils.trackCommon(FirebaseConstants.EVENT_SEARCH_BOX_CLICK);
        } else if(id == R.id.search_detail_img){
            TagItem currentTag = commonAppDetailView.mBinding.titleInclude.textSearchView.getCurrentTagItem();
            String textTag = currentTag != null ? currentTag.term : "";
            String searchSoft = mActivity.getString(R.string.search_soft);
            if (TextUtils.isEmpty(textTag)){
                textTag = searchSoft;
            }
            boolean isExcuteSearch = !textTag.equals(searchSoft);
            TRJumpUtil.switchToSearchActivity(mActivity, TabType.SOFT
                    , textTag, isExcuteSearch
                    , textTag, true, searchSoft
                    , commonAppDetailView.mPageParamInfo, mValue, TRAnalyticsConstant.BUTTON_SEARCH_BOX_IMG,true);
            TrackUtils.trackCommon(FirebaseConstants.EVENT_SEARCH_IMG_CLICK);
        } else if (id == R.id.ib_detail_search){
            TagItem currentTag = commonAppDetailView.mBinding.titleInclude.textSearchView.getCurrentTagItem();
            String textTag = currentTag != null ? currentTag.term : "";
            String searchSoft = mActivity.getString(R.string.search_soft);
            if (TextUtils.isEmpty(textTag)){
                textTag = searchSoft;
            }
            TRJumpUtil.switchToSearchActivity(mActivity, TabType.SOFT, "",
                    false, textTag, true, searchSoft, commonAppDetailView.mPageParamInfo,
                    TRStringUtil.generateString(TRAnalyticsConstant.DETAIL_PAGE, "","",""), TRAnalyticsConstant.BUTTON_SEARCH_IMG, false);
            TrackUtils.trackCommon(FirebaseConstants.EVENT_SEARCH_CLICK);
        } else if (id == R.id.ib_detail_share){
            confirmSend();
        }
    }

    public View getStatusBar() {
        return statusBar;
    }
}

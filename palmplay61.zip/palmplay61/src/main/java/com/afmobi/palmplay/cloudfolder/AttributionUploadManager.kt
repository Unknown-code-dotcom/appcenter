package com.afmobi.palmplay.cloudfolder

import android.text.TextUtils
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.utils.mainScope
import com.google.gson.reflect.TypeToken
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.GsonUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.NetworkUtils
import com.transsnet.attribution.listener.OnRequestListener
import com.transsnet.attribution.net.NetworkManager
import kotlinx.coroutines.launch
import java.io.Serializable
import java.lang.reflect.Type
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap


/**
 * 请求记录数据类
 * 用于序列化存储到MMKV
 */
data class RequestRecord(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    var retryCount: Float = 0.0f
) : Serializable

const val MAX_RETRY_COUNT = 4

const val KEY_CLOUD_FOLDER_ATTRIBUTION = "KEY_CLOUD_FOLDER_ATTRIBUTION"

class AttributionUploadManager private constructor(){

    private val TAG = "AttributionUploadManager"

    private var uploadMap = ConcurrentHashMap<String, RequestRecord>()

    init {
        try {
            var uploadString = MMKVUtils.getMultiMMKV().decodeString(KEY_CLOUD_FOLDER_ATTRIBUTION, "")
            if(!TextUtils.isEmpty(uploadString)) {
                uploadMap = jsonToMap(uploadString)
            }
            LogUtils.e(CloudFolderManager.TAG, "$TAG  -> init:  $uploadString  --   $uploadMap")
        }catch (e: Exception) {
            LogUtils.e(e)
        }
    }

    companion object {

        @Volatile
        private var INSTANCE: AttributionUploadManager? = null

        fun getInstance(): AttributionUploadManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AttributionUploadManager().also { INSTANCE = it }
            }
        }
    }

    /**
     * 提交请求并缓存到本地
     * @param url 请求链接
     */
    private fun enqueueSingleRequest(
        url: String,
        name: String?
    ) {
        val requestRecord = RequestRecord(url = url)
        saveRequestRecord(requestRecord)
        // 尝试执行请求
        mainScope.launch {
            executeRequest(requestRecord, name)
        }
    }

    /**
     * 上报归因链接
     * @param urlList 归因链接列表
     */
    fun enqueueNewRequest(urlList: List<String>?, name: String?) {
        urlList?.forEach {
            enqueueSingleRequest(it, name)
        }
    }

    /**
     * 联网后，重试请求
     */
    fun enqueueRetryRequest() {
        LogUtils.e(CloudFolderManager.TAG, "$TAG  -> enqueueRetryRequest  --   $uploadMap")
        if(uploadMap.isEmpty()) {
            LogUtils.e(CloudFolderManager.TAG, "$TAG  -> enqueueRetryRequest:  no List")
            return
        }
        if(!NetworkUtils.sNetworkConnected) {
            LogUtils.e(CloudFolderManager.TAG, "$TAG  -> enqueueRetryRequest:  no Net")
            return
        }
        ioScope.launch {
            uploadMap.values.forEach { it ->
                executeRequest(it, "")
            }
        }
    }

    /**
     * 执行请求并处理重试逻辑
     */
    private suspend fun executeRequest(
        record: RequestRecord,
        name: String?
    ) {
        if(!NetworkUtils.sNetworkConnected) {
            LogUtils.e(CloudFolderManager.TAG, "$TAG  -> executeRequest:  no Net")
            return
        }
        try {
            LogUtils.e(CloudFolderManager.TAG, "$TAG  -> executeRequest:  request - ${record.url}  -  name: $name")
            // 执行网络请求
            NetworkManager.getInstance().asyncRequest(record.url, object : OnRequestListener{
                override fun onRequestSuccess(code: Int) {
                    LogUtils.d(CloudFolderManager.TAG, "$TAG  request Success : $name")
                    deleteRequestRecord(record.id)
                }

                override fun onRequestFailed(code: Int, message: String?) {
                    mainScope.launch {
                        handleFailure(record, message, name)
                    }
                }
            })
        } catch (e: Exception) {
            handleFailure(record, e.message, name)
        }
    }

    /**
     * 处理请求失败
     */
    private suspend fun handleFailure(record: RequestRecord, message: String?, name: String?) {
        record.retryCount++
        LogUtils.d(CloudFolderManager.TAG, "$TAG  request Failure:  $message   retryCount: ${record.retryCount}    name: $name")
        if (record.retryCount < MAX_RETRY_COUNT) {
            // 还有重试次数，更新记录
            saveRequestRecord(record)
            executeRequest(record, name)
        } else {
            // 达到最大重试次数，可标记为失败或删除记录
            deleteRequestRecord(record.id)
        }
    }

    /**
     * 保存请求记录
     */
    private fun saveRequestRecord(record: RequestRecord) {
        uploadMap.put(record.id, record)
        MMKVUtils.getMultiMMKV().encode(KEY_CLOUD_FOLDER_ATTRIBUTION, GsonUtils.getInstance().toJson(uploadMap))
    }

    /**
     * 删除请求记录
     */
    private fun deleteRequestRecord(id: String) {
        uploadMap.remove(id)
        MMKVUtils.getMultiMMKV().encode(KEY_CLOUD_FOLDER_ATTRIBUTION, GsonUtils.getInstance().toJson(uploadMap))
    }

    /**
     * 将JSON字符串转换为 Map<String, Any?>
     * @param json JSON字符串
     * @return 转换后的Map，转换失败返回空Map
     */
    fun jsonToMap(json: String?): ConcurrentHashMap<String, RequestRecord> {
        return try {
            // 定义Map的类型令牌
            val type : Type= object : TypeToken<ConcurrentHashMap<String, RequestRecord>>() {}.type
            // 转换JSON到Map
            GsonUtils.getInstance().fromJson(json, type) ?: ConcurrentHashMap()
        } catch (e: Exception) {
            e.printStackTrace()
            ConcurrentHashMap()
        }
    }


}
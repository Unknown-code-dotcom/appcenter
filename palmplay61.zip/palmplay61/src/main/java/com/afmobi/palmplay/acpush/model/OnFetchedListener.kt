package com.afmobi.palmplay.acpush.model

import com.afmobi.palmplay.model.ClientVersion

/**
 * InstalledAppsUpdateCache 拉取成功后的回调接口。
 *
 * AC-PUSH 通过 InstalledAppsUpdateCache.setOnFetchedListener() 注入实现，
 * 在 CheckAppsUpdateRespHandler.onSuccess() 末尾触发。
 *
 * @param source 直接透传 InstalledAppsUpdateCache 的 requestType：TIMER / HAND / HIGH_FREQ_SA。
 * 监听方需自行判断 [AcPushConfigRepo.enabledState]；明确关闭时 return，未下发配置时仍需注册 provider。
 */
interface OnFetchedListener {
    fun onFetched(items: List<ClientVersion.UpdateItem>, source: String)
}

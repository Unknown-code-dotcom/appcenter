package com.afmobi.palmplay.cloudfolder.view

import android.content.Context
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView
import com.transsnet.store.R
import kotlin.math.min

class CloudFolderRecyclerView : RecyclerView {

    private var mFadingEdgeLength = 0

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        initData()
    }

    private fun initData() {
        // 设置需要渐变效果的边缘

        // 设置需要渐变效果的边缘
        isVerticalFadingEdgeEnabled = true
        // 设置渐变效果的长度
        // 设置渐变效果的长度
        mFadingEdgeLength =
            context.resources.getDimensionPixelSize(R.dimen.dp_48)
        setFadingEdgeLength(mFadingEdgeLength)
    }

    override fun getTopFadingEdgeStrength(): Float {
        return min(1f, computeVerticalScrollOffset().toFloat() / mFadingEdgeLength)
    }

    override fun getBottomFadingEdgeStrength(): Float {
        return if (canScrollVertically(VERTICAL)) {
                1.0f
            } else {
                0f
            }
    }


}
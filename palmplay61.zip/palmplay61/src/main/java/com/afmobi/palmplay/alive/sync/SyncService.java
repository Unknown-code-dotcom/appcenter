/*Transsion Top Secret*/
package com.afmobi.palmplay.alive.sync;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.log.LogUtils;


/**
 * Description:
 * Define a Service that returns an <code><a href="/reference/android/os/IBinder.html">IBinder</a></code> for the
 * sync adapter class, allowing the sync adapter framework to call onPerformSync().
 *
 */
public class SyncService extends Service {
    final String TAG = "Alive";

    private static SyncAdapter sSyncAdapter = null;
    // Object to use as a thread-safe lock
    private static final Object sSyncAdapterLock = new Object();


    @Override
    public void onCreate() {
        /*
         * Create the sync adapter as a singleton.
         * Set the sync adapter as syncable
         * Disallow parallel syncs
         */
        if (BuildConfig.DEBUG) {
            LogUtils.d(TAG, "onCreate SyncService");
        }
        synchronized (sSyncAdapterLock) {
            if (sSyncAdapter == null) {
                sSyncAdapter = new SyncAdapter(getApplicationContext(), true);
            }
        }
    }

    /**
     * Return Binder handle for IPC communication with {@link SyncAdapter}.
     *
     * <p>New sync requests will be sent directly to the SyncAdapter using this channel.
     *
     * @param intent Calling intent
     * @return Binder handle for {@link SyncAdapter}
     */
    @Override
    public IBinder onBind(Intent intent) {
        /*
         * Get the object that allows external processes
         * to call onPerformSync(). The object is created
         * in the base class code when the SyncAdapter
         * constructors call super()
         */
        if (BuildConfig.DEBUG) {
            LogUtils.d(TAG, "onBind SyncService");
        }

        return sSyncAdapter.getSyncAdapterBinder();
    }

    @Override
    public void onDestroy() {
        if (BuildConfig.DEBUG) {
            LogUtils.d(TAG, "onDestroy SyncService");
        }
        super.onDestroy();
    }
}

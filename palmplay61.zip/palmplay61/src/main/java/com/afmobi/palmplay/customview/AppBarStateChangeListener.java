package com.afmobi.palmplay.customview;


import android.util.Log;

import com.afmobi.palmplay.PalmplayApplication;
import com.afmobi.util.DisplayUtil;
import com.google.android.material.appbar.AppBarLayout;

public abstract class AppBarStateChangeListener implements AppBarLayout.OnOffsetChangedListener {
    private int currentOffset;

    private int offset;
    public enum State {
        SEARCH_HIDE,
        SEARCH_SHOW,
        EXPANDED,
        COLLAPSED,
        IDLE
    }

    public AppBarStateChangeListener(){
        offset = DisplayUtil.dip2px(PalmplayApplication.getAppInstance(),8);
    }

    private State mCurrentState = State.IDLE;

    @Override
    public final void onOffsetChanged(AppBarLayout appBarLayout, int i) {
        if (currentOffset == 0){
            currentOffset = i;
        }

        if (Math.abs(i) >= appBarLayout.getTotalScrollRange() - offset) {
            onStateChanged(appBarLayout, State.SEARCH_SHOW, currentOffset);
        } else {
            onStateChanged(appBarLayout, State.SEARCH_HIDE, currentOffset);
        }

        if (i - currentOffset > 0) {
            mCurrentState = State.EXPANDED;
        } else if (Math.abs(i) >= appBarLayout.getTotalScrollRange()) {
            mCurrentState = State.COLLAPSED;
        } else {
            onStateChanged(appBarLayout, State.IDLE, currentOffset);
            mCurrentState = State.IDLE;
        }
        currentOffset = i;
    }

    public abstract void onStateChanged(AppBarLayout appBarLayout, State state,int offset);
}
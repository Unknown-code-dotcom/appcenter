// TOP SECRET
package com.afmobi.palmplay.base;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.afmobi.util.BuildConstants;
import com.google.android.material.appbar.AppBarLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Lifecycle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.afmobi.palmplay.model.v6_3.PageParamInfo;
import com.afmobi.util.ActivityUtility.Params;
import com.afmobi.util.Constant;
import com.afmobi.util.IntentUtility;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.transsion.palmstorecore.analytics.apm.log.FileLogManager;
import com.transsion.palmstorecore.eventbus.EventMainThreadEntity;
import com.jcodecraeer.xrecyclerview.ScrollListener;
import com.transsion.palmstorecore.BuildConfig;
import com.transsion.palmstorecore.analytics.TRAnalysticsUtil;
import com.transsion.palmstorecore.log.LogUtils;
import com.transsion.palmstorecore.util.TRStringUtil;

public abstract class BaseFragment extends Fragment {

	protected PageParamInfo mPageParamInfo = new PageParamInfo();
	
	//====================== EventBus method start =============================
	/**
	 * register EventBus
	 */
	public void registerEventBus(){}
	
	/**
	 * unregister EventBus
	 */
	public void unregisterEventBus(){}
	
	/**
	 * EventBus callback method 
	 * @param mEventMainThreadEntity
	 */
	public void onEventMainThread(EventMainThreadEntity mEventMainThreadEntity) {

	}
	//onEvent, onEventMainThread, onEventBackgroundThread, onEventAsync
	//======================= EventBus method end   ===========================

	private long mEnterTime = 0;  // 进入页面时间
	private boolean mIsNeedEventBus = true;
	private final String CLASS_NAME = getClass().getName();  // 子类名称
	protected final String BASE_TAG = getClass().getSimpleName() + "_" + Integer.toHexString(hashCode());  // LOG TAG
	private boolean mIsUploadRecord = false; // 上报打点标识，主要防止Fragment在pause内上报过后再次重复上报
	private boolean mIgnoreRecord = false;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (BuildConstants.isDebug) {
			LogUtils.d("FragmentLifeCycle", "onCreate: " + BASE_TAG);
		}
		Bundle bundle = getArguments();
		if(bundle!=null) {
			mIsNeedEventBus = bundle.getBoolean(Constant.NEED_EVENT_BUS,true);
		}

		if(mIsNeedEventBus) {
			registerEventBus();
		}
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		mEnterTime = System.currentTimeMillis();
	}

	@Override
	public void onResume() {
		super.onResume();
		if (BuildConstants.isDebug) {
			LogUtils.d("FragmentLifeCycle", "onResume: " + BASE_TAG);
		}
		if(mEnterTime == 0 || getUserVisibleHint() == false) {
			LogUtils.e("BaseFragment: status = "+getUserVisibleHint()+" mEnterTime = "+mEnterTime);
			return;
		}
		mEnterTime = System.currentTimeMillis();
		mIsUploadRecord = false;
		LogUtils.d("APM", "----onResume----" + this.getClass().getSimpleName());
		FileLogManager.getInstance().addPage(this.getClass().getSimpleName());
		if (!com.google.firebase.FirebaseApp.getApps(requireContext()).isEmpty()) {
			FirebaseCrashlytics.getInstance().log("----log----onResume----" + this.getClass().getSimpleName());
		}
	}

	@Override
	public void onPause() {
		super.onPause();
		if (BuildConstants.isDebug) {
			LogUtils.d("FragmentLifeCycle", "onPause: " + BASE_TAG);
		}
		if(getUserVisibleHint() == false) {
			return;
		}
		finishedRecordPageCostTime();
	}


	@Override
	public void onDestroy() {
		if (BuildConstants.isDebug) {
			LogUtils.d("FragmentLifeCycle", "onDestroy: " + BASE_TAG);
		}
		super.onDestroy();
		if(mIsNeedEventBus) {
			unregisterEventBus();
		}
	}

	@Override
	public void onHiddenChanged(boolean hidden) {
		super.onHiddenChanged(hidden);
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (BuildConfig.DEBUG) {
			LogUtils.e("BaseFragment: " + CLASS_NAME + " setUserVisibleHint =" + isVisibleToUser);
		}

		if (isVisibleToUser) {
			LogUtils.d("APM", "----setUserVisibleHint----" + this.getClass().getSimpleName()+"----object----"+ this.getClass().hashCode());
			mEnterTime = System.currentTimeMillis();
			mIsUploadRecord = false;
		} else {
			finishedRecordPageCostTime();
		}

	}

	/**
	 * 返回页面进入时间
	 * @return
	 */
	public long getPageEnterTime() {
		return mEnterTime;
	}

	public void setPageEnterTime(long time) {
		mEnterTime = time;
	}
	@SuppressWarnings("unchecked")
	protected final  <T extends View> T findViewWithId(View parent, int resId){
		return (T) parent.findViewById(resId);
	}
	
	/**
	 * @param toCls
	 *            - jump activity class
	 * @param replaceFragmentCls
	 *            - neew replace fragment simpleName
	 */
	protected void replaceFragmentWithClassName(Class<?> toCls, Class<?> replaceFragmentCls) {
		replaceFragmentWithClassName(toCls, replaceFragmentCls, null);
	}
	
	protected void replaceFragmentWithClassName(Class<?> toCls, Class<?> replaceFragmentCls, Params params) {
		Intent intent = new Intent(getActivity(), toCls);
		if( null != params ){
			for(Params.NameValue item : params.nameValueArray){
				IntentUtility.setValueToIntent(intent, item.name, item.value);
			}
		}
		intent.putExtra(toCls.getSimpleName(), replaceFragmentCls.getSimpleName());
		try {
			startActivity(intent);
		} catch (Exception e) {
			try {
				intent.setPackage(replaceFragmentCls.getSimpleName());
				startActivity(intent);
			} catch (Exception ignored) {
			}
		}

	}

	protected void addNoMore(RecyclerView rv , LinearLayoutManager linearLayout, AppBarLayout abl){
		ScrollListener scrollListener = new ScrollListener(linearLayout, abl, new ScrollListener.OnCusScrollListener() {
			@Override
			public void onFirstItemVisible(AppBarLayout appBarLayout) {

				if(appBarLayout!=null){
					appBarLayout.setExpanded(true);// 下拉滑动的时候有卡顿, 设置展开可以消除卡顿
				}

			}


			@Override
			public void onNoMoreToast(long lastToastTime) {
				//ToastManager.getInstance().showS(getActivity(), getActivity().getResources().getString(R.string.no_more_contents));
			}
		});
		rv.addOnScrollListener(scrollListener);
	}

	protected void setSystemBarColor(int color) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			if(getActivity() != null){
				getActivity().getWindow().setStatusBarColor(color);
			}
		}
	}

	public void setPageParamInfo(PageParamInfo pageParamInfo) {
		if(pageParamInfo != null)
			this.mPageParamInfo = pageParamInfo;
	}

	public void setIgnoreRecordTime() {
		mIgnoreRecord = true;
	}

	/**
	 * 记录页面打点时长
	 */
	public void finishedRecordPageCostTime(){
		long interval = System.currentTimeMillis() - mEnterTime;

		if(mIgnoreRecord || mEnterTime == 0 || mIsUploadRecord) {
			/** time = 0 表示还没进过页面不做埋点记录
			 * mIsUploadRecord = true表示已经上报过，但没有重新开始记录
			**/
			return;
		}

		LogUtils.e("BaseFragment: " +CLASS_NAME +" cost "+interval);

		mIsUploadRecord = true;
		if (TRStringUtil.isBlank(mPageParamInfo.getCurPage())) {
			TRAnalysticsUtil.trackExposureTime(CLASS_NAME, interval);
		} else {
			TRAnalysticsUtil.trackExposureTime(CLASS_NAME + mPageParamInfo.getCurPage(), interval);
		}

	}

	public boolean isActivityResume() {
		FragmentActivity activity = getActivity();
		if (activity != null) {
			return activity.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.RESUMED);
		}
		return false;
	}

}

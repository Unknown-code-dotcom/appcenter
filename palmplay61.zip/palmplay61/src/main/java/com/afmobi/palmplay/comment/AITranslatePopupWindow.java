package com.afmobi.palmplay.comment;

import com.afmobi.palmplay.customview.PopMenuItemSelectedListener;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.transsnet.store.R;

public class AITranslatePopupWindow extends PopupWindow implements View.OnClickListener {

    private View contentView;
    private TextView tvAiTranslation;
    private ImageView tvAiTranslationIcon;
    private TextView tvShowOriginal;
    private ImageView tvShowOriginalIcon;

    private PopMenuItemSelectedListener mItemOnClickListener;
    private boolean isShowingAiTranslation;
    private Context context;

    public AITranslatePopupWindow(Context context) {
        super(context);
        this.context = context;
    }

    public AITranslatePopupWindow setData(boolean isShowingAi, PopMenuItemSelectedListener listener) {
        this.isShowingAiTranslation = isShowingAi;
        this.mItemOnClickListener = listener;

        LayoutInflater inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contentView = inflater.inflate(R.layout.layout_ai_translate_popup, null);
        this.setContentView(contentView);

//        // 自适应宽高
//        caculateView(contentView);
//        setWidth(contentView.getMeasuredWidth());
//        setHeight(contentView.getMeasuredHeight());

        this.setFocusable(true);
        this.setOutsideTouchable(true);
        this.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        initViews();
        updateSelection();
        return this;
    }

    private void initViews() {
        tvAiTranslation = contentView.findViewById(R.id.tv_ai_translation);
        tvAiTranslationIcon = contentView.findViewById(R.id.tv_ai_translation_icon);
        tvShowOriginal = contentView.findViewById(R.id.tv_show_original);
        tvShowOriginalIcon = contentView.findViewById(R.id.tv_show_original_icon);

        tvAiTranslation.setOnClickListener(this);
        tvShowOriginal.setOnClickListener(this);
    }

    private void updateSelection() {
        // 更稳的做法：不要依赖 drawable selector 自动跟随 selected 状态刷新，
        // 直接在这里重新 setCompoundDrawables，确保勾选图标一定更新。
        boolean aiSelected = isShowingAiTranslation;
        boolean originalSelected = !isShowingAiTranslation;

        tvAiTranslation.setSelected(aiSelected);
        tvAiTranslationIcon.setVisibility(aiSelected ? View.VISIBLE: View.INVISIBLE);

        tvShowOriginal.setSelected(originalSelected);
        tvShowOriginalIcon.setVisibility(originalSelected ? View.VISIBLE: View.INVISIBLE);
    }

    public void onShow(View v) {
        showAsDropDown(v, 0, 0);
    }

    @Override
    public void onClick(View v) {
        int index = -1;
        String menuStr = "";

        int id = v.getId();
        if (id == R.id.tv_ai_translation) {
            index = 0;
            menuStr = ((TextView) v).getText().toString();
        } else if (id == R.id.tv_show_original) {
            index = 1;
            menuStr = ((TextView) v).getText().toString();
        }

        if (index == -1) {
            dismiss();
            return;
        }

        // 先刷新选中态，让 textColor / drawableEnd（selector）立即生效
        isShowingAiTranslation = (index == 0);
        updateSelection();

        // 回调外部逻辑（刷新评论）
        if (mItemOnClickListener != null) {
            mItemOnClickListener.onItemClicked(index, menuStr);
        }

        // 给用户一个短暂的选中反馈后再关闭
        v.postDelayed(new Runnable() {
            @Override
            public void run() {
                dismiss();
            }
        }, 120);
    }

    private void caculateView(View view) {
        int w = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        view.measure(w, h);
    }
}
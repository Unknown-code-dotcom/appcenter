package com.afmobi.palmplay.cloudfolder.track

import android.os.Bundle
import android.text.TextUtils
import com.afmobi.palmplay.cloudfolder.utils.CATEGORY_APP
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo
import com.transsion.athenacust.AthenaCust
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * 埋点工具类
 */
object CloudFolderTrackUtil {
    var CLOUD_FOLDER_GRANT = "R_FL_X_X"
    var EXPOSURE_EVENT = "ps_common_exposure"
    var CLICK_EVENT = "ps_common_click"
    var TEC_EVENT = "ps_cloud_file_lc_tech"
    var TEC_ADD_QUEUE_EVENT = "cloudfolder_add_to_download_queue"
    var TID = 1044
    var TYPE_REQUEST = 1 //请求
    var TYPE_GRANT = 2 //授权框展示-点击-业务埋点有了-注意区分首次弹框和再次弹框；
    var TYPE_FOLDER_CREATE = 3 //文件夹创建-过滤的应用-其他业务埋点有了；
    var TYPE_SHOW = 4 //展示：-业务埋点已有；
    var TYPE_CLICK = 5 //点击：业务埋点有了；
    var TYPE_RECEIVE_PS_GRANT = 6 //接收PS授权状态；
    var TYPE_MOVE = 7 //文件夹-应用移动；
    var TYPE_DISBAND = 8 //文件夹解散
    var TYPE_DAILY_UPLOAD = 9 //状态上报
    var TYPE_PAUSE_DIALOG = 10 //暂停弹窗
    var TYPE_CACHE_STATUS = 11 //缓存状态
    const val STATUS_DEFAULT = -1
    var REQUEST_STATUS_START = 1
    var REQUEST_STATUS_SUCCESS = 2
    var REQUEST_STATUS_FAILURE = 3
    var STATUS_CLICK_DOWNLOAD = 1
    var STATUS_CLICK_DETAIL = 2
    var STATUS_CLICK_LONG_DOWNLOAD = 3
    var STATUS_CLICK_LONG_CANCEL = 4
    var STATUS_CLICK_LONG_DETAIL = 5
    var STATUS_CLICK_SEARCH = 6
    var STATUS_CLICK_ICON = 7
    var STATUS_CLICK_SETTING = 8
    var STATUS_UPLOAD_NOT_SUPPORT = 1
    var STATUS_UPLOAD_WAIT = 2
    var STATUS_UPLOAD_CREATE = 3
    var STATUS_UPLOAD_CREATE_CLOSE = 4
    var STATUS_ENTER_CLICK = 1
    var STATUS_ENTER_SCROLL = 2
    var BUTTON_TYPE_INSTALL = "install"
    var BUTTON_TYPE_CANCEL = "cancel"
    var BUTTON_TYPE_RESUME = "resume"
    var BUTTON_TYPE_PAUSE = "pause"
    var BUTTON_TYPE_OPEN = "openAD"
    var BUTTON_TYPE_SEND = "send"
    var BUTTON_TYPE_OPEN_APP = "openApp"
    var BUTTON_TYPE_APP_INFO = "openInfo"
    var TYPE_CREATE_FILTER = "1"
    var TYPE_CREATE = "2"
    var TYPE_RECREATE = "3"
    var TYPE_CREATE_EMPTY = "4"
    var TYPE_FILTER_ADX_EXPIRE = "5"
    var TYPE_FILTER_ADX_INSTALL = "6"
    const val STATUS_GRANT_DISAGREE = 0
    const val STATUS_GRANT_AGREE = 1
    const val STATUS_SHOW_FOLDER_EMPTY = 1
    const val STATUS_SHOW_FOLDER_CLOSE = 2
    const val STATUS_STAY_TIME = 12

    const val SCENE_CENTER = "X"
    const val SCENE_BOTTOM_NEW = "C"
    const val SCENE_BOTTOM_CDN = "B"
    const val SCENE_ADX = "ADX"

    private val reportedBottomExposureKeys = mutableSetOf<String>()

    /**
     * 底栏曝光按「本次可见会话」去重。转屏显隐不会清，离开页面后由 [resetBottomExposureReported] 清。
     */
    fun markBottomExposureOnce(
        categoryType: Int,
        position: Int,
        packageName: String?,
        sceneTag: String,
    ): Boolean {
        return reportedBottomExposureKeys.add("$categoryType|$sceneTag|$position|$packageName")
    }

    fun resetBottomExposureReported() {
        reportedBottomExposureKeys.clear()
    }

    fun businessItemExposureTrack(
        position: Int,
        packageName: String?,
        itemType: Int,
        from: Int,
        categoryType: Int,
        adType: Int = 0,
        rdtType: Int = 0,
        sceneTag: String = SCENE_CENTER,
        cfValue: String? = null,
    ) {
        if (sceneTag == SCENE_BOTTOM_NEW &&
            !markBottomExposureOnce(categoryType, position, packageName, sceneTag)
        ) {
            return
        }
        val bundle = Bundle()
        val sign = if (categoryType == CATEGORY_APP) "A" else "G"
        bundle.putString("value", "FL_" + sign + "_" + sceneTag + "_" + position)
        try {
            val js = JSONObject()
            js.put("package", packageName)
            js.put("itemType", itemType)
            js.put("from", from)
            js.put("adType", adType)
            js.put("folderType", "2")
            js.put("rdt_typ", rdtType)
            if (!cfValue.isNullOrEmpty()) {
                js.put("cfValue", cfValue)
            }
            bundle.putString("extraValue", js.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        postAthenaEvent(TID, EXPOSURE_EVENT, bundle)
    }

    fun businessItemClickTrack(
        position: Int,
        buttonType: String?,
        packageName: String?,
        categoryType: Int,
        isOffer: Int,
        rdtType: Int = 0,
        ctj: String? = null,
        sceneTag: String = SCENE_CENTER,
        cfValue: String? = null,
    ) {
        val bundle = Bundle()
        val sign = if (categoryType == CATEGORY_APP) "A" else "G"
        bundle.putString("value", "FL_" + sign + "_" + sceneTag + "_" + position)
        try {
            val js = JSONObject()
            js.put("package", packageName)
            js.put("folderType", "2")
            js.put("adType", isOffer)
            js.put("rdt_typ", rdtType)
            ctj?.let {
                js.put("ctj", it)
            }
            if (!cfValue.isNullOrEmpty()) {
                js.put("cfValue", cfValue)
            }
            bundle.putString("extraValue", js.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        bundle.putString("buttonType", buttonType)
        postAthenaEvent(TID, CLICK_EVENT, bundle)
    }

    /**
     * cfValue（云文件夹埋点扩展字段）JSON 子字段约定。
     * 仅在条件满足时由 [CloudAppInfo.getCloudStyleString] 写入：
     *  - sty: 样式1（LAYOUT_STYLE_ORIGINAL）默认不上报，其他样式上报
     *  - rk : 在榜单坑位中展示时上报 1，其他情况不上报
     *  - dyn: 使用动态 icon 展示时上报 1，其他情况不上报
     */
    const val STY_DEFAULT = 1            // 样式 1：默认值，意味"不上报"
    const val RK_NOT_RANK = 0            // 非榜单坑位
    const val RK_IS_RANK = 1             // 在榜单坑位中
    const val DYN_NOT_DYNAMIC = 0        // 非动态 icon
    const val DYN_IS_DYNAMIC = 1         // 动态 icon

    fun businessBottomItemExposureTrack(
        position: Int,
        packageName: String?,
        itemType: Int,
        categoryType: Int,
        rdtType: Int = 0,
    ) {
        val bundle = Bundle()
        val sign = if (categoryType == CATEGORY_APP) "A" else "G"
        bundle.putString("value", "FL_" + sign + "_B_" + position)
        try {
            val js = JSONObject()
            js.put("package", packageName)
            js.put("itemType", itemType)
            js.put("rdt_typ", rdtType)
            bundle.putString("extraValue", js.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        postAthenaEvent(TID, EXPOSURE_EVENT, bundle)
    }

    fun businessBottomItemClickTrack(
        position: Int,
        packageName: String?,
        categoryType: Int,
        rdtType: Int = 0,
        ctj : String? = null
    ) {
        val bundle = Bundle()
        val sign = if (categoryType == CATEGORY_APP) "A" else "G"
        bundle.putString("value", "FL_" + sign + "_B_" + position)
        try {
            val js = JSONObject()
            js.put("package", packageName)
            js.put("rdt_typ", rdtType)
            ctj?.let {
                js.put("ctj", it)
            }
            bundle.putString("extraValue", js.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        postAthenaEvent(TID, CLICK_EVENT, bundle)
    }

    /**
     * 技术埋点
     * @param type
     * @param status
     * @param content
     * @param extra
     */
    @JvmOverloads
    fun tecTrack(
        type: Int,
        status: Int,
        content: String?,
        extra: String?,
        start: String? = "",
        end: String? = ""
    ) {
        val bundle = Bundle()
        bundle.putInt("t", type)
        if (status > STATUS_DEFAULT) {
            bundle.putInt("s", status)
        }
        if (!TextUtils.isEmpty(content)) {
            bundle.putString("c", content)
        }
        if (!TextUtils.isEmpty(extra)) {
            bundle.putString("m", extra)
        }
        bundle.putString("n", "2")
        if (!TextUtils.isEmpty(start)) {
            bundle.putString("l_s", start)
        }
        if (!TextUtils.isEmpty(end)) {
            bundle.putString("l_n", end)
        }
        postAthenaEvent(TID, TEC_EVENT, bundle)
    }

    //itemType    -1 : 已安装 0 未下载 4 下载中 8 暂停 64 安装中
    fun getDownloadStatus(observerStatus: Int) : Int {
        return when(observerStatus) {
            FileDownloadInfo.STATUS_APP_INSTALLED -> -1
            FileDownloadInfo.STATUS_WAIT,
            FileDownloadInfo.STATUS_DOWNING,
            FileDownloadInfo.STATUS_NETWORK_ERROR -> 4
            FileDownloadInfo.STATUS_PAUSE -> 8
            FileDownloadInfo.STATUS_INSTALLING -> 64
            else -> 0
        }
    }

    /**
     * 技术埋点
     * @param type
     * @param status
     * @param content
     * @param extra
     */
    @JvmOverloads
    fun addToDownloadQueue(
        packageName: String?, name: String?, fromPage: String?, reportSource: String?, materialCountryCode: String?,
        isOffer: Int
    ) {
            val bundle = Bundle()
            bundle.putString("pkg", packageName)
            bundle.putString("name", name)
            bundle.putString("from", fromPage)
            bundle.putString("rs", reportSource)
            bundle.putString("country", materialCountryCode)
            bundle.putInt("adType", isOffer)
            postAthenaEvent(TID, TEC_ADD_QUEUE_EVENT, bundle)
    }

    fun trackPageStayTime(stayTime: Long, categoryType: Int) {
        val bundle = Bundle()
        bundle.putInt("t", TYPE_CLICK)
        bundle.putInt("s", STATUS_STAY_TIME)
        bundle.putString("c", stayTime.toString())
        bundle.putString("m", categoryType.toString())
        bundle.putString("n", "2")
        postAthenaEvent(TID, TEC_EVENT, bundle)
    }

    private fun postAthenaEvent(tid: Int,event : String, bundle: Bundle){
        ioScope.launch {
            try {
                AthenaCust(event, tid).trackCommon(bundle, null).submit()
            }catch (e: Exception) {

            }
        }
    }
}


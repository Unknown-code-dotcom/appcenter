package com.afmobi.palmplay.cloudfolder

import android.content.Context
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.TextUtils
import androidx.core.graphics.PathParser
import com.afmobi.palmplay.cloudfolder.utils.FOLDER
import com.afmobi.palmplay.cloudfolder.utils.FOLDER_STATUS
import com.afmobi.palmplay.cloudfolder.utils.SystemProperties
import com.afmobi.palmplay.cloudfolder.utils.bitmap2Drawable
import com.afmobi.palmplay.cloudfolder.utils.drawableToBitmap
import com.afmobi.palmplay.cloudfolder.utils.ioScope
import com.afmobi.palmplay.cloudfolder.utils.mainScope
import com.afmobi.util.PhoneDeviceInfo
import com.transsion.hubsdk.api.util.TranIconDrawableFactory
import com.transsion.hubsdk.common.init.TranHubSdkManager
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.MMKVUtils
import com.transsion.palmstorecore.util.TRApplicationContextUtil
import com.transsion.resource.theme.TranThemeManager
import com.transsion.resource.theme.TranThemePackageInfo
import com.transsion.uiengine.theme.SystemThemeManager
import com.transsion.uiengine.theme.plugin.XThemeAgent
import com.transsnet.launcherlib.services.DispenseDataManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


class CloudFolderRemoteController private constructor() {

    private val TAG = "CloudFolderRemoteController"

    //云文件夹的云控开关
    private val CLOUD_CONTROL_URI =
        "content://com.hoffnung.cloudControl.RemoteConfigProvider/config/"
    private val CLOUD_FOLDER_REMOTE_CONFIG = "os_launcher_cloud_folder_enable"
    private val HOT_CLOUD_FOLDER_REMOTE_CONFIG = "os_launcher_hot_cloud_folder_enable"
    private val GAME_CLOUD_FOLDER_REMOTE_CONFIG = "os_launcher_game_cloud_folder_enable"

    private val KEY_CLOUD_FILE_SWITCH_CONFIG = "key_cloud_file_switch_config"
    private val KEY_CLOUD_FILE_REMOTE_SWITCH_CONFIG = "key_cloud_file_remote_switch_status"

    private var cloudFolderSwitchStatus = 0


    @Volatile
    private var cloudFolderRemoteConfigEnable = true

    @Volatile
    private var hotCloudFolderRemoteConfigEnable = true

    @Volatile
    private var gameCloudFolderRemoteConfigEnable = true

    private val IS_FEATURE_ENABLED: Boolean = SystemProperties.getBoolean(
        "ro.system_theme_241204_sr_sa_0006_0001_support", false
    )

    /**
     * 全局主题主题管理类
     */
    private var mTranThemeManager: TranThemeManager? = null

    @Volatile
    private var globalIconShapePath: String? = null

    @Volatile
    private var globalIconShape: Path? = null

    private val iconStyleChangedListeners = CopyOnWriteArraySet<() -> Unit>()

    companion object {

        private const val GLOBAL_ICON_SHAPE_VIEWPORT_SIZE = 100f
        private const val KEY_GLOBAL_ICON_SHAPE_PATH = "key_global_icon_shape_path"
        private const val GLOBAL_ICON_SHAPE_SETTING =
            "tr_global_icon_coloring_shape_path"
        @Volatile
        private var INSTANCE: CloudFolderRemoteController? = null

        fun getInstance(): CloudFolderRemoteController {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudFolderRemoteController().also { INSTANCE = it }
            }
        }
    }

     init {
         cloudFolderSwitchStatus = MMKVUtils.getMMKV().getInt(KEY_CLOUD_FILE_SWITCH_CONFIG, FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT)
         globalIconShapePath = MMKVUtils.getMMKV().getString(
             getGlobalIconShapeCacheKey(),
             ""
         )?.takeIf { it.isNotBlank() }
         globalIconShape = parseGlobalIconShape(globalIconShapePath)
         LogUtils.i(TAG, "global icon shape loaded from cache: path=$globalIconShapePath")
     }

    private fun getGlobalIconShapeCacheKey(): String {
        return "${KEY_GLOBAL_ICON_SHAPE_PATH}_${Process.myUserHandle().hashCode()}"
    }

    fun initCloudFolderRemoteConfigObserver(context: Context?) {
        val uri = Uri.parse(CLOUD_CONTROL_URI + CLOUD_FOLDER_REMOTE_CONFIG)
        val hotUri = Uri.parse(CLOUD_CONTROL_URI + HOT_CLOUD_FOLDER_REMOTE_CONFIG)
        val gameUri = Uri.parse(CLOUD_CONTROL_URI + GAME_CLOUD_FOLDER_REMOTE_CONFIG)
        try {
            context?.let {
                initTheme(it)
                it.contentResolver.apply {
                    registerContentObserver(
                        uri, true, object : ContentObserver(Handler(Looper.getMainLooper())) {
                            override fun onChange(selfChange: Boolean) {
                                super.onChange(selfChange)
                                ioScope.launch {
                                    cloudFolderRemoteConfigEnable = getCloudFolderRemoteConfigEnable(it, CLOUD_FOLDER_REMOTE_CONFIG)
                                    LogUtils.i("$TAG  cloudFolderRemoteConfigEnable change = $cloudFolderRemoteConfigEnable")
                                    if (!cloudFolderRemoteConfigEnable) {
                                        if(isUserGrantStatus()) {
                                            doSaveRemoteSwitchClose(true)
                                        }
                                        DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
                                            FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT
                                        CloudFolderManager.getInstance().removeAllWidgetFolder()
                                    } else {
                                        if(isCreateFromRemoteSwitch() && !PhoneDeviceInfo.isBackgrounder()) {
                                            doSaveRemoteSwitchClose(false)
                                            DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
                                                FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT
                                            CloudFolderManager.getInstance().createAllCloudFolder()
                                        }
                                    }
                                }
                            }
                        })

                    registerContentObserver(
                        hotUri, true, object : ContentObserver(Handler(Looper.getMainLooper())) {
                            override fun onChange(selfChange: Boolean) {
                                super.onChange(selfChange)
                                ioScope.launch {
                                    hotCloudFolderRemoteConfigEnable = getCloudFolderRemoteConfigEnable(it, HOT_CLOUD_FOLDER_REMOTE_CONFIG)
                                    LogUtils.i("$TAG  hotCloudFolderRemoteConfigEnable change = $hotCloudFolderRemoteConfigEnable")
                                    if (!hotCloudFolderRemoteConfigEnable) {
                                        //hot关闭
                                        CloudFolderManager.getInstance().removeWidgetCloudFolder(FOLDER.APPS)
                                    } else {
                                        CloudFolderManager.getInstance().createWidgetCloudFolder(FOLDER.APPS)
                                    }
                                }
                            }
                        })

                    registerContentObserver(gameUri, true, object : ContentObserver(Handler(Looper.getMainLooper())) {
                            override fun onChange(selfChange: Boolean) {
                                super.onChange(selfChange)
                                ioScope.launch {
                                    gameCloudFolderRemoteConfigEnable = getCloudFolderRemoteConfigEnable(it, GAME_CLOUD_FOLDER_REMOTE_CONFIG)
                                    LogUtils.i("$TAG  gameCloudFolderRemoteConfigEnable change = $gameCloudFolderRemoteConfigEnable")
                                    if (!gameCloudFolderRemoteConfigEnable) {
                                        //game关闭
                                        CloudFolderManager.getInstance().removeWidgetCloudFolder(FOLDER.GAMES)
                                    } else {
                                        CloudFolderManager.getInstance().createWidgetCloudFolder(FOLDER.GAMES)
                                    }
                                }
                            }
                        })
                }
            }
            mainScope.launch {
                context?.let {
                    cloudFolderRemoteConfigEnable = getCloudFolderRemoteConfigEnable(it, CLOUD_FOLDER_REMOTE_CONFIG)
                    checkCloudFolderSwitch(cloudFolderRemoteConfigEnable)
                    hotCloudFolderRemoteConfigEnable = getCloudFolderRemoteConfigEnable(it, HOT_CLOUD_FOLDER_REMOTE_CONFIG)
                    gameCloudFolderRemoteConfigEnable = getCloudFolderRemoteConfigEnable(it, GAME_CLOUD_FOLDER_REMOTE_CONFIG)
                }
            }
        } catch (_: Exception) {
        }
    }

    /**
     * 打开，校验一下开关状态， 如果是关,但是文件夹未解散，强制解散
     */
    private fun checkCloudFolderSwitch(isOpen: Boolean) {
        if(CloudFolderManager.getInstance().isWidgetSplit()) {
            if (isOpen) {
                ioScope.launch {
                    delay(3000)
                    if (isCreateFromRemoteSwitch() && !PhoneDeviceInfo.isBackgrounder()) {
                        doSaveRemoteSwitchClose(false)
                        DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
                            FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT
                        CloudFolderManager.getInstance().createAllCloudFolder()
                    }
                }
            } else {
                if (CloudFolderManager.getInstance().isWidgetHasAdded(FOLDER.APPS)) {
                    if (isUserGrantStatus()) {
                        doSaveRemoteSwitchClose(true)
                    }
                    DispenseDataManager.getInstance().fileFolderGetPermissionStatus =
                        FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_NO_GRANT
                    CloudFolderManager.getInstance().removeAllCloudFolder()
                }
            }
        }
    }

    private suspend fun getCloudFolderRemoteConfigEnable(context: Context, key: String): Boolean {
        return suspendCoroutine {ct ->
            ioScope.launch {
                val uri =
                    Uri.parse(CLOUD_CONTROL_URI + key)
                val resolver = context.contentResolver
                var isResume = false
                try {
                    resolver.query(uri, null, null, null, null).use { cursor ->
                        if (cursor != null && cursor.moveToNext()) {
                            val index =
                                cursor.getColumnIndex(key)
                            val enable = java.lang.Boolean.parseBoolean(cursor.getString(index))
                            LogUtils.i("$TAG  $key  = $enable")
                            isResume = true
                            ct.resume(enable)
                        }
                    }
                } catch (e: Exception) {
                    LogUtils.e("$TAG  $key  exception: = ${e.message}")
                }
                if(!isResume) {
                    ct.resume(true)
                }
            }
        }
    }

    fun isCloudFolderCreate(cloudFolder: FOLDER) : Boolean {
        return if(cloudFolder == FOLDER.APPS) {
            isCloudFolderOpen() && hotCloudFolderRemoteConfigEnable && cloudFolderSwitchStatus != FOLDER_STATUS.SWITCH_OPEN_GAME_FOLDER
        } else {
            isCloudFolderOpen() && gameCloudFolderRemoteConfigEnable && cloudFolderSwitchStatus != FOLDER_STATUS.SWITCH_OPEN_HOT_FOLDER
        }
    }

    fun isCloudFolderShow(cloudFolder: FOLDER) : Boolean {
        return if(cloudFolder == FOLDER.APPS) {
            hotCloudFolderRemoteConfigEnable && cloudFolderSwitchStatus != FOLDER_STATUS.SWITCH_OPEN_GAME_FOLDER
        } else {
            gameCloudFolderRemoteConfigEnable && cloudFolderSwitchStatus != FOLDER_STATUS.SWITCH_OPEN_HOT_FOLDER
        }
    }

    fun isShowFolderFragment(cloudFolder: FOLDER) : Boolean {
        return if (CloudFolderManager.getInstance().isOriginWidgetStyle) {
            isCloudFolderShow(cloudFolder) && CloudFolderManager.getInstance().isWidgetHasAdded(cloudFolder)
        } else {
            isCloudFolderShow(cloudFolder)
        }
    }

    /**
     * 添加条件注释
     *
     */
    private fun isCloudFolderOpen() : Boolean {
        //tms 远程总开关  && 用户是否授权 &&  ps 云控开启
        return cloudFolderRemoteConfigEnable && isUserGrantStatus() && cloudFolderSwitchStatus != FOLDER_STATUS.SWITCH_CLOUD_FOLDER_CLOSE_PS && cloudFolderSwitchStatus != FOLDER_STATUS.SWITCH_CLOSE_CLOUD_FOLDER
    }

    /**
     * 用户授权创建云文件夹
     */
    fun isUserGrantStatus() : Boolean {
        return DispenseDataManager.getInstance().fileFolderGetPermissionStatus == FOLDER_STATUS.STATUS_FILE_FOLDER_PERMISSION_GRANT
    }

    /**
     * 云控开关是否关闭
     * tms云控和 ps云控
     */
    fun isRemoteSwitchClose() : Boolean {
        return !cloudFolderRemoteConfigEnable  || cloudFolderSwitchStatus == FOLDER_STATUS.SWITCH_CLOUD_FOLDER_CLOSE_PS || cloudFolderSwitchStatus == FOLDER_STATUS.SWITCH_CLOSE_CLOUD_FOLDER
    }

    fun doCloudFileSwitch(cloudFileSwitch: Int) {
        if(cloudFolderSwitchStatus != cloudFileSwitch) {
            LogUtils.i("$TAG  doCloudFileSwitch   cloudFileSwitch: $cloudFileSwitch")
            cloudFolderSwitchStatus = cloudFileSwitch
            MMKVUtils.getMMKV().putInt(KEY_CLOUD_FILE_SWITCH_CONFIG, cloudFolderSwitchStatus)
            when(cloudFileSwitch) {
                FOLDER_STATUS.SWITCH_CLOSE_CLOUD_FOLDER,
                FOLDER_STATUS.SWITCH_CLOUD_FOLDER_CLOSE_PS ->
                    CloudFolderManager.getInstance().removeAllCloudFolder()
                FOLDER_STATUS.SWITCH_OPEN_HOT_FOLDER -> CloudFolderManager.getInstance().removeWidgetCloudFolder(FOLDER.GAMES)
                    FOLDER_STATUS.SWITCH_OPEN_GAME_FOLDER-> CloudFolderManager.getInstance().removeWidgetCloudFolder(FOLDER.APPS)
            }
        }
    }

    fun doSaveRemoteSwitchClose(isOpen: Boolean) {
        LogUtils.i("$TAG  doSaveRemoteSwitchClose = $isOpen")
        MMKVUtils.getMMKV().putBoolean(KEY_CLOUD_FILE_REMOTE_SWITCH_CONFIG, isOpen)
    }

    fun isCreateFromRemoteSwitch() : Boolean {
        val boolean = MMKVUtils.getMMKV().getBoolean(KEY_CLOUD_FILE_REMOTE_SWITCH_CONFIG, false)
        LogUtils.i("$TAG  isCreateFromRemoteSwitch = $boolean")
        return boolean
    }


    /**
     * 判断是否需要从主题中解析应用图标
     */
    private var isNeedParseTheme = false

    /**
     * 判断是否启用全局主题
     */
    private var isGlobalTheme = false

    /**
     * 判断是否需要从主题中解析图标
     */
    fun analysisNeedParseTheme() {
        ioScope.launch {
            try {
                // BuildConfig.APPLICATION_ID表示请求的应用包名，此处传入接入模块自己的packageName即可
                val themeBean = SystemThemeManager.getInstance().getUsingThemeInfo(
                    TRApplicationContextUtil.getInstance(),
                    "com.transsnet.store"
                )

                LogUtils.i(TAG, "analysisNeedParseTheme  themeBean: $themeBean    systemTheme: ${SystemThemeManager.getInstance().isSystemTheme}")
                // 每次监听到主题切换后，需要先调用getUsingThemeInfo方法，才能通过
                // SystemThemeManager.getInstance().isSystemTheme()方法判断是否是系统主题
                if (themeBean != null && !TextUtils.isEmpty(themeBean.themeLocalPath)) {

                    // 根据主题信息初始化当前主题资源获取对象
                    XThemeAgent.getInstance().notifyThemeChanged(
                        TRApplicationContextUtil.getInstance(),
                        themeBean.themePackageName, themeBean.themeLocalPath,
                        themeBean.type, 0, 0
                    )
                }
                isNeedParseTheme = !SystemThemeManager.getInstance().isSystemTheme
            } catch (e: java.lang.Exception) {
                isNeedParseTheme = false
                LogUtils.e(TAG, "analysisNeedParseTheme: e = $e")
            }

            isGlobalTheme = isUseGlobalTheme()
        }
    }

    private fun initTheme(context: Context) {
        if(CloudFolderManager.getInstance().isWidgetSplit()) {
            refreshGlobalIconShapeFromSystemSettings(
                context.applicationContext,
                "initialization"
            )
            //初始化主题库
            SystemThemeManager.getInstance().init(context, "com.transsnet.store")
            analysisNeedParseTheme()
        }
    }

    fun hasGlobalIconShape(): Boolean {
        return globalIconShape != null
    }

    fun getGlobalIconShapePath(): String? = globalIconShapePath

    fun refreshGlobalIconColoringConfig(context: Context) {
        refreshGlobalIconShapeFromSystemSettings(
            context.applicationContext,
            "page entry"
        )
    }

    fun onGlobalIconShapeChanged(context: Context) {
        refreshGlobalIconShapeFromSystemSettings(
            context.applicationContext,
            "Launcher notifyIconChange"
        )
    }

    private fun refreshGlobalIconShapeFromSystemSettings(context: Context, source: String) {
        ioScope.launch {
            try {
                val resolver = context.contentResolver
                val newPath = Settings.System.getString(
                    resolver,
                    GLOBAL_ICON_SHAPE_SETTING
                ).orEmpty()
                LogUtils.i(
                    TAG,
                    "global icon shape read from Settings: source=$source, path=$newPath"
                )
                updateGlobalIconShape(newPath, "$source via Settings.System")
            } catch (exception: CancellationException) {
                throw exception
            } catch (throwable: Throwable) {
                LogUtils.e(TAG, "read global icon shape from Settings failed", throwable)
            }
        }
    }

    @Synchronized
    private fun updateGlobalIconShape(newPath: String, source: String) {
        val oldPath = globalIconShapePath.orEmpty()
        LogUtils.i(
            TAG,
            "global icon style refreshed: source=$source, oldPath=$oldPath, newPath=$newPath"
        )
        if (oldPath == newPath) {
            return
        }
        globalIconShapePath = newPath.takeIf { it.isNotBlank() }
        globalIconShape = parseGlobalIconShape(globalIconShapePath)
        MMKVUtils.getMMKV().putString(getGlobalIconShapeCacheKey(), newPath)
        notifyIconStyleChanged()
    }

    private fun notifyIconStyleChanged() {
        mainScope.launch {
            iconStyleChangedListeners.forEach { listener ->
                try {
                    listener()
                } catch (exception: CancellationException) {
                    throw exception
                } catch (throwable: Throwable) {
                    LogUtils.e(TAG, "notify icon style listener failed", throwable)
                }
            }
        }
    }

    fun addIconStyleChangedListener(listener: () -> Unit) {
        iconStyleChangedListeners.add(listener)
    }

    fun removeIconStyleChangedListener(listener: () -> Unit) {
        iconStyleChangedListeners.remove(listener)
    }

    fun getCloudThemeIcon(context: Context, drawable: Drawable?) : Drawable?{
        if(CloudFolderManager.getInstance().isWidgetSplit()) {
            if (hasGlobalIconShape() || isGlobalTheme) {
                if (drawable != null) {
                    return getTranIconDrawable(context, drawableToBitmap(drawable)) ?: drawable
                }
            } else if (isNeedParseTheme) {
                val themBitmap = XThemeAgent.getInstance()
                    .getThemeIconForCloudFolderApp(
                        context,
                        null,
                        drawable,
                        Process.myUserHandle()
                    )
                return themBitmap?.run {
                    bitmap2Drawable(context, this)
                } ?: drawable
            }
        }
        return drawable
    }

    fun getCloudThemeIcon(context: Context, bitmap: Bitmap) : Bitmap{
        var outputBitmap = bitmap
        if(hasGlobalIconShape() || isGlobalTheme) {
            val out = getTranIconDrawable(context, bitmap)
            if (out != null) {
                outputBitmap = drawableToBitmap(out) ?: bitmap
            }
        } else if(isNeedParseTheme) {
            outputBitmap = XThemeAgent.getInstance()
                .getThemeIconForCloudFolderApp(context, null, bitmap2Drawable(context, bitmap), Process.myUserHandle()) ?: bitmap
        }
        return outputBitmap
    }

    /**
     * 获取桌面Icon
     *
     * @param packageName
     * @return
     */
    private fun getTranIconDrawable(context: Context, bitmap: Bitmap?): Drawable? {
        val sourceBitmap = bitmap ?: return null
        val themedDrawable = try {
            run {
                if(TranHubSdkManager.getContext() == null) {
                    TranHubSdkManager.getInstance().init(TRApplicationContextUtil.getInstance());
                }
                TranIconDrawableFactory().getGlobalThemedIcon(context, sourceBitmap)
            }
        }catch (e: Exception) {
            LogUtils.e(TAG, e)
            null
        }
        if (!hasGlobalIconShape()) {
            return themedDrawable
        }
        val themedBitmap = drawableToBitmap(themedDrawable) ?: sourceBitmap
        return bitmap2Drawable(context, applyGlobalIconShape(themedBitmap))
    }

    private fun parseGlobalIconShape(pathData: String?): Path? {
        if (pathData.isNullOrBlank()) {
            return null
        }
        return try {
            PathParser.createPathFromPathData(pathData)
        } catch (exception: RuntimeException) {
            LogUtils.e(TAG, "parse global icon shape failed: path=$pathData", exception)
            null
        }
    }

    private fun applyGlobalIconShape(bitmap: Bitmap): Bitmap {
        val pathData = globalIconShapePath
        if (pathData.isNullOrBlank() || bitmap.width <= 0 || bitmap.height <= 0) {
            return bitmap
        }
        return try {
            val shapePath = Path(globalIconShape ?: return bitmap)
            Matrix().also { matrix ->
                matrix.setScale(
                    bitmap.width / GLOBAL_ICON_SHAPE_VIEWPORT_SIZE,
                    bitmap.height / GLOBAL_ICON_SHAPE_VIEWPORT_SIZE
                )
                shapePath.transform(matrix)
            }
            val output = Bitmap.createBitmap(
                bitmap.width,
                bitmap.height,
                Bitmap.Config.ARGB_8888
            ).apply {
                density = bitmap.density
            }
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            Canvas(output).run {
                drawPath(shapePath, paint)
                paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
                drawBitmap(bitmap, 0f, 0f, paint)
                paint.xfermode = null
            }
            output
        } catch (exception: RuntimeException) {
            LogUtils.e(TAG, "applyGlobalIconShape failed: path=$pathData", exception)
            bitmap
        }
    }

    private fun isUseGlobalTheme() : Boolean {
        try {
            LogUtils.e(TAG, "isUseGlobalTheme: $IS_FEATURE_ENABLED")
            if(!IS_FEATURE_ENABLED) {
                return false
            }
            if (mTranThemeManager == null) {
                mTranThemeManager = TranThemeManager(TRApplicationContextUtil.getInstance())
            }
            val themeList = getCurrentRunningGlobalThemeInfoList()
            return !themeList.isNullOrEmpty()
        }catch (e: Throwable) {
            LogUtils.e(TAG, e)
        }
        return false
    }

    private fun getCurrentRunningGlobalThemeInfoList(): List<TranThemePackageInfo?>? {
        mTranThemeManager?.let {
            return try {
                LogUtils.e(TAG, "getCurrentRunningGlobalThemeInfoList: throwable = ${it.currentRunningPackageInfoList}")
                it.currentRunningPackageInfoList
            } catch (throwable: Throwable) {
                LogUtils.e(TAG, "getCurrentRunningGlobalThemeInfoList: throwable = $throwable")
                ArrayList()
            }
        }
        LogUtils.e(TAG, "getCurrentRunningGlobalThemeInfoList:  return null")
        return ArrayList()
    }

}

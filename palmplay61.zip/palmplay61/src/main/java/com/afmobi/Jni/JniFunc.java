package com.afmobi.Jni;

import android.content.Context;

public class JniFunc {
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public static native void updateAppInfo(Context context);
    public static native byte[] nativeEncode(byte[] data, int offset, int length, int flag);
    public static native String nativeEncode2String(byte[] data, int offset, int length, int flag);
    public static native byte[] nativeDecode(byte[] data, int offset, int length, int flag);

}

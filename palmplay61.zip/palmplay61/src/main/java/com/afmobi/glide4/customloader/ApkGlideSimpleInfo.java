package com.afmobi.glide4.customloader;

import android.text.TextUtils;

public class ApkGlideSimpleInfo {
    private String packageName = "";


    private String apkFilePath;


    public String versionName = "";
    public int versionCode = 0;
    public long fileSzie = 0;

    public ApkGlideSimpleInfo(String apkFilePath, String packageName) {
        this.apkFilePath = apkFilePath;
        this.packageName = packageName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getApkFilePath() {
        return apkFilePath;
    }

    public void setApkFilePath(String apkFilePath) {
        this.apkFilePath = apkFilePath;
    }

    public String getKey() {
        if (TextUtils.isEmpty(packageName)) {
            return apkFilePath;
        }
        return packageName;
    }
}

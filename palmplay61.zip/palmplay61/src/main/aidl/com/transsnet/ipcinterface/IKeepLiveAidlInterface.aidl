// IKeepLiveAidlInterface.aidl
package com.transsnet.ipcinterface;

// Declare any non-default types here with import statements

interface IKeepLiveAidlInterface {
    /**
     * Demonstrates some basic types that you can use as parameters
     * and return values in AIDL.
     */
    void doSomeThing(String aString);
}

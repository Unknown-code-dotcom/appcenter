/*Transsion Top Secret*/
package com.transsion.phonemanager;

/***********************************************************************
 * Module:  IBinderPool.java
 * Author:  xinxin.shi
 * Purpose: Defines the Interface IBinderPool
 ***********************************************************************/


interface IBinderPool {

   IBinder queryBinder(String binderCode);

}

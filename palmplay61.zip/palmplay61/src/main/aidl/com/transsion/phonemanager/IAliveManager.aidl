// IAliveManager.aidl
package com.transsion.phonemanager;

// Declare any non-default types here with import statements

interface IAliveManager {
    void registerPlugin(String json);

    void unregisterPlugin(String json);
}
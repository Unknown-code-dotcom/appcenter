package com.transsion.appupdate.ipc;

import com.transsion.appupdate.ipc.IInstallFinishListener;

// Declare any non-default types here with import statements

interface IPalmIpcAidlInterface {
    /**
     * Demonstrates some basic types that you can use as parameters
     * and return values in AIDL.
     */
    void basicTypes(int anInt, long aLong, boolean aBoolean, float aFloat,double aDouble, String aString);

    void startMonitoringScreenOn(boolean enable,long currentTime,long grpTime,String channel);

    void startInstallPalmSApk(String uri,String apkPath,String pkg,String channel,IInstallFinishListener listener);

}


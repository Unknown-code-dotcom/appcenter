// IDialogStatusAidl.aidl
package com.transsion.dialog.service;

// Declare any non-default types here with import statements

interface IDialogStatusAidl {
    boolean isCanShowDialog(IBinder binder);
    void setDialogStatus(int status);
}

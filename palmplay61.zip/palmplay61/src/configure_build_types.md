### [使用源代码集构建](https://developer.android.com/build/build-variants?hl=zh-cn#sourceset-build)

您可以让源代码集目录包含您希望只针对某些配置打包在一起的代码和资源。例如，如果您要构建“demoDebug”build 变体（“demo”产品变种和“debug”build 类型的混合产物），Gradle 会查看这些目录，并为它们指定以下优先级：

1.  `src/demoDebug/`（build 变体源代码集）
2.  `src/debug/`（build 类型源代码集）
3.  `src/demo/`（产品变种源代码集）
4.  `src/main/`（主源代码集）

为产品变种组合创建的源代码集必须包含所有变种维度。 例如，build 变体源代码集必须是 build 类型及所有变种维度的组合。不支持合并涉及的文件夹涵盖多个（但并非全部）变种维度的代码和资源。

如果您将[多个产品变种组合在一起](#flavor-dimensions)，那么这些产品变种的优先级由它们所属的变种维度决定。使用 [`android.flavorDimensions`](https://developer.android.com/reference/tools/gradle-api/current/com/android/build/api/dsl/ProductFlavor?hl=zh-cn#dimension) 属性列出变种维度时，属于您列出的第一个变种维度的产品变种的优先级高于属于第二个变种维度的产品变种，依此类推。此外，您为产品变种组合创建的源代码集的优先级高于属于各个产品变种的源代码集。

优先级顺序决定了 Gradle 组合代码和资源时哪个源代码集的优先级更高。由于 `demoDebug/` 源代码集目录很可能包含该 build 变体特有的文件，因此如果 `demoDebug/` 包含的某个文件在 `debug/` 中也进行了定义，Gradle 会使用 `demoDebug/` 源代码集中的文件。同样，Gradle 会为 build 类型和产品变种源代码集中的文件指定比 `main/` 中的相同文件更高的优先级。在应用以下构建规则时，Gradle 会考虑这种优先级顺序：

+   `kotlin/` 或 `java/` 目录中的所有源代码将一起编译以生成单个输出。

    **注意**：对于给定的 build 变体，如果 Gradle 遇到两个或更多个源代码集目录定义了同一个 Kotlin 或 Java 类的情况，就会抛出构建错误。例如，在构建调试应用时，您不能同时定义 `src/debug/Utility.kt` 和 `src/main/Utility.kt`。这是因为，Gradle 在构建过程中会查看这两个目录并抛出“重复类”错误。如果您希望不同的 build 类型有不同版本的 `Utility.kt`，每个 build 类型必须定义各自的文件版本，而不是将其包含在 `main/` 源代码集中。

+   所有清单都将合并为一个清单。按照前面示例中列表项的顺序指定优先级。也就是说，build 类型的清单设置会替换产品变种的清单设置，依此类推。如需了解详情，请参阅[清单合并](https://developer.android.com/studio/build/manage-manifests?hl=zh-cn#merge-manifests)。
+   `values/` 目录中的文件也会合并在一起。如果两个文件同名，例如存在两个 `strings.xml` 文件，则按照前面示例中列表项的顺序指定优先级。也就是说，在 build 类型源代码集的文件中定义的值会替换在产品变种的同一文件中定义的值，依此类推。
+   `res/` 和 `asset/` 目录中的资源会打包在一起。如果在两个或更多个源代码集中定义了同名的资源，则按照前面示例中列表项的顺序指定优先级。
+   在构建应用时，Gradle 会为库模块依赖项随附的资源和清单指定最低优先级。
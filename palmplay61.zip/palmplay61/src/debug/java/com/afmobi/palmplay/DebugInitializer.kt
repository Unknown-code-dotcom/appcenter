package com.afmobi.palmplay

import android.app.Application
import com.transsion.debugkit.DebugKit

object DebugInitializer {

    fun init(application: Application) {
        // 初始化调试工具
        DebugKit.init(application)
    }
}
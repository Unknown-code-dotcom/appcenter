package com.afmobi.palmplay

import com.afmobi.palmplay.manager.FilePathManager
import com.afmobi.palmplay.quickinstall.PreInstallManager
import com.afmobi.palmplay.quickinstall.config.PreInstallConfigManager
import com.afmobi.palmplay.quickinstall.data.PreInstallDataManager
import com.afmobi.palmplay.quickinstall.data.PreInstallDataManager.KEY_PRE_INSTALL_CACHE_TODAY
import com.afmobi.palmplay.quickinstall.database.PreInstallDbManager
import com.didi.drouter.annotation.Service
import com.transsion.commonlib.util.SpUtil
import com.afmobi.palmplay.cloudfolder.CloudFolderManager
import com.transsion.core.CoreUtil
import com.transsion.palmstorecore.api.IAppActionService
import com.transsion.palmstorecore.log.LogUtils
import com.transsion.palmstorecore.util.GsonUtils
import com.transsnet.launcherlib.config.Constants
import com.transsnet.launcherlib.services.DispenseDataManager
import com.transsnet.launcherlib.util.SPManagerUtils
import com.transsnet.launcherlib.network.CloudFolderDebugManager
import java.io.File

@Service(function = [IAppActionService::class])
class AppActionServiceImpl : IAppActionService {

    private val TAG = "PreInstall-DEBUG"

    override fun requestPreInstallData() {
        PreInstallManager.requestPreInstallData()
    }

    override fun startPreDownloadTask() {
        PreInstallManager.startPreDownloadTask()
    }

    override fun clearPreInstallDailyLimit() {
        SpUtil.getSP().putLong(KEY_PRE_INSTALL_CACHE_TODAY, 0L)
    }

    override fun clearPreInstallRequestInterval() {
        PreInstallConfigManager.saveLastRequestTime(0L)
    }

    override fun clearPreInstallStartInterval() {
        PreInstallConfigManager.saveLastCheckTime(0L)
    }

    override fun getAllPreInstallList() {
        val allPreDownloadTaskList = PreInstallDbManager.getAllPreDownloadTaskList()
        LogUtils.i(TAG, "allTask:  ${GsonUtils.getInstance().toJson(allPreDownloadTaskList)}")

        val allReinstallItemTask = PreInstallDataManager.getAllReinstallItemTask()
        LogUtils.i(TAG, "reInstallTask:  ${GsonUtils.getInstance().toJson(allReinstallItemTask)}")

    }

    override fun showCacheList() {
        LogUtils.i(TAG, "cache List: ${getCacheContentInfo(FilePathManager.getDownloadingTempDirPath())}")
        LogUtils.i(TAG, "downloaded List: ${getCacheContentInfo(FilePathManager.getDownloadedDirPath())}")
    }

    /**
     * 获取缓存内容详情
     */
    fun getCacheContentInfo(path: String): String {
        try {
            val parentDir = File(path)
            if (!parentDir.exists() || !parentDir.isDirectory) {
                return "Cache Directory not found."
            }
            val files = parentDir.listFiles()
            if (files.isNullOrEmpty()) {
                return "No cached files found."
            }

            val sb = StringBuilder()
            var totalSize = 0L
            sb.append("\n")
            files.forEach { file ->
                val sizeVal = file.length()
                totalSize += sizeVal
                val sizeMb = String.format("%.2f MB", sizeVal / (1024.0 * 1024.0))
                sb.append("- ${file.name} ($sizeMb)\n")
            }
            val totalSizeMb = String.format("%.2f MB", totalSize / (1024.0 * 1024.0))
            sb.append("\nTotal Size: $totalSizeMb")
            return sb.toString()
        } catch (e: Exception) {
            LogUtils.e(TAG, "getCacheContentInfo error", e)
            return "Error retrieving cache info: ${e.message}"
        }
    }

    override fun clearLocalDatabase() {
        PreInstallDbManager.clear()
    }

    override fun requestCloudFolderData(callback: Runnable?) {
        SPManagerUtils.putLong(CoreUtil.getContext(), Constants.LAST_REQUEST_FILE_FOLDER_DATA_TIME, 0)
        DispenseDataManager.getInstance().fetchFileFolderData(true) {
            CloudFolderManager.getInstance().onCloudFolderRefresh()
            callback?.run()
        }
    }

    override fun isCloudFolderForceRelease(): Boolean {
        return CloudFolderDebugManager.isForceRelease
    }

    override fun setCloudFolderForceRelease(force: Boolean) {
        CloudFolderDebugManager.isForceRelease = force
    }

    override fun getCloudFolderOverrideCountryCode(): String? {
        return CloudFolderDebugManager.overrideCountryCode
    }

    override fun setCloudFolderOverrideCountryCode(countryCode: String?) {
        CloudFolderDebugManager.overrideCountryCode = countryCode
    }

    override fun getCloudFolderOverrideModel(): String? {
        return CloudFolderDebugManager.overrideModel
    }

    override fun setCloudFolderOverrideModel(model: String?) {
        CloudFolderDebugManager.overrideModel = model
    }
}
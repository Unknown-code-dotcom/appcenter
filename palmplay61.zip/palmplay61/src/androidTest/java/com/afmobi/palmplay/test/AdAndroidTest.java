package com.afmobi.palmplay.test;

import com.afmobi.palmplay.cache.AdCache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.OpenAdData;
import com.afmobi.palmplay.model.keeptojosn.OwnAdBean;
import com.afmobi.palmplay.utils.ReflectUtils;
import com.afmobi.util.TimeUtil;
import com.google.gson.Gson;
import com.transsnet.store.BuildConfig;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class AdAndroidTest {

   private static final String ADS_CFG_LAST = "ads_cfg_last";
   private static final String AD_CACHE_URI = "OPEN_AD_CACHE";

   private static final String ADS_STATUS_MAP = "ads_status_map";
   private static final String ADS_LAST_SHOW_TIME = "ads_last_show_time";
   private static final String ADS_CFG_LAST_LOAD_TIME = "ads_cfg_last_load_time"; //上次请求时间
   private final static long ONE_DAY = 24 * 60 * 60 * 60 * 1000L;

   private AdCache adCache;

   @Before
   public void init() {
      String jsonBuffer = "{\"adConfigDTO\":{\"adSwitchFlag\":1,\"loadTimeInterval\":4,\"reloadTimeInterval\":4,\"showAdType\":\"\",\"showFrequency\":5},\"adList\":[{\"adEndTime\":\"2023-01-31 00:00:00\",\"adIconUrl\":\"http://test-cdn.palmplaystore.com/static/198/37fc12ccff044189be5e0b1fc38bb636.webp\",\"adName\":\"分辨率定向\",\"adShowFlag\":true,\"adStartTime\":\"2021-12-01 00:00:00\",\"adStatus\":\"1\",\"adUrl\":\"\",\"cfgId\":\"123\",\"dealType\":0,\"endDate\":\"2023-01-31T00:00:00.000+0000\",\"fromPage\":\"splashAct\",\"id\":\"148\",\"isAutoDownload\":0,\"jumpExt\":\"palmplay://thirdlauncher.com/?entryType=WebView&URL=https://test-h5.tranactivity.com/my-money-loan/?utm_source=XX&_source=myMoneyLoan&hideTitleRightLayout=false&showTitle=T\",\"jumpType\":\"DEEP_LINK\",\"jumpUrl\":\"palmplay://thirdlauncher.com/?entryType=WebView&URL=https://test-h5.tranactivity.com/my-money-loan/?utm_source=XX&_source=myMoneyLoan&hideTitleRightLayout=false&showTitle=T\",\"pck\":\"com.transsnet.store\",\"reportSource\":\"1\",\"showTime\":\"5\",\"startDate\":\"2021-12-01T00:00:00.000+0000\",\"taskId\":0,\"versionCode\":\"1\"}]}";

      try {
         OpenAdData ad = new Gson().fromJson(jsonBuffer, OpenAdData.class);
         if (ad != null && ad.getAdList() != null) {
            long time = System.currentTimeMillis();
            long ONE_MONTH = 1 * 30 * 24 * 60 * 60 * 1000L;
            String startDate = TimeUtil.getDateToString(time - ONE_MONTH);
            String endDate = TimeUtil.getDateToString(time + ONE_MONTH);
            for (OwnAdBean item : ad.getAdList()) {
               item.setStartDate(startDate);
               item.setEndDate(endDate);
            }

            jsonBuffer = new Gson().toJson(ad);
         }
      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }
      FilePathManager.jsonToFile(jsonBuffer, AD_CACHE_URI);

      SPManager.remove(ADS_STATUS_MAP);

      adCache = new AdCache();

   }

   @Test
   public void test_isAdOpen() {
      boolean ret = adCache.isAdOpen();
      Assert.assertTrue(ret);

   }

   @Test
   public void test_AdRemoveOldVersionCache() {
      String oldAd = "test old version ad";
      SPManager.putString(ADS_CFG_LAST, oldAd);

      boolean ret = SPManager.containsKey(ADS_CFG_LAST);
      Assert.assertTrue(ret);

      SPManager.remove(ADS_CFG_LAST);

      ret = SPManager.containsKey(ADS_CFG_LAST);

      Assert.assertFalse(ret);
   }


   @Test
   public void test_isAdEmpty() {
      boolean isEmpty = adCache.isAdEmpty();
      Assert.assertFalse(isEmpty);
   }

   @Test
   public void test_AdSaveFileName() {
      String name = adCache.getFileName();

      Assert.assertEquals(name, AD_CACHE_URI);
   }



   @Test
   public void test_setLastShowTime() {
      long currTime = 0;

      adCache.setLastShowTime();

      long lastShowTime = adCache.getLastShowTime();

      long endTime = System.currentTimeMillis() + ONE_DAY;

      boolean ret = (lastShowTime > currTime && lastShowTime < endTime);
      Assert.assertTrue(ret);
   }
   @Test
   public void test_isOverTwoHours() {

      long time = System.currentTimeMillis();
      long threeHours = 3 * 60 * 60 * 1000L;
      SPManager.putLong(ADS_LAST_SHOW_TIME, time);

      boolean ret = adCache.isOverTwoHours();
      Assert.assertFalse(ret);

      SPManager.putLong(ADS_LAST_SHOW_TIME, time - threeHours);
      ret = adCache.isOverTwoHours();
      Assert.assertTrue(ret);
   }


   @Test
   public void test_isDateChanged() {

      adCache.setLastShowTime();
      boolean ret = adCache.isDateChanged();
      Assert.assertFalse(ret);

      long currTime = System.currentTimeMillis();
      long twoDay = 2 * 24 * 60 * 60 * 1000L;
      SPManager.putLong(ADS_LAST_SHOW_TIME, currTime-twoDay);

      ret = adCache.isDateChanged();
      Assert.assertTrue(ret);
   }

   @Test
   public void test_isAdValidate() {
      OwnAdBean info = adCache.getOwnAdBean("148");
      Assert.assertNotNull(info);

      long time = System.currentTimeMillis();
      long ONE_MONTH = 1 * 30 * 24 * 60 * 60 * 1000L;
      String startDate = TimeUtil.getDateToString(time);
      String endDate = TimeUtil.getDateToString(time - ONE_MONTH);
      info.setStartDate(startDate);
      info.setEndDate(endDate);
      boolean ret = adCache.isAdValidate(info);
      Assert.assertFalse(ret);

      startDate = TimeUtil.getDateToString(time - ONE_MONTH);
      endDate = TimeUtil.getDateToString(time + ONE_MONTH);
      info.setStartDate(startDate);
      info.setEndDate(endDate);

      ret = adCache.isAdValidate(info);
      Assert.assertTrue(ret);

   }


   @Test
   public void test_isUpperLimit() {
      adCache.resetTotalShowCount();

      boolean ret = adCache.isUpperLimit();
      Assert.assertFalse(ret);

      adCache.increaseShowCount();

      int count = adCache.getTotalShowCount();
      Assert.assertEquals(1, count);

      Object objAttr = ReflectUtils.getFieldObjByReclect(adCache, "com.afmobi.palmplay.cache.AdCache", "mOpenAdData");
      OpenAdData data = null;
      try {
          data = (OpenAdData) objAttr;
      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }

      Assert.assertNotNull(data);

      int frequency = data.getShowFrequency();
      for (int i = 0;i < frequency; i++) {
         adCache.increaseShowCount();
      }

      ret = adCache.isUpperLimit();
      Assert.assertTrue(ret);
   }


   @Test
   public void test_isAdConfigLoadExpired() {
      adCache.setLastConfigLoadTime();

      adCache.getLastRequestTime();

      boolean ret = adCache.isAdConfigLoadExpired();
      Assert.assertFalse(false);

      long time = System.currentTimeMillis();
      long oneDay = 1 * 24 * 60 * 60 * 1000L;
      SPManager.putLong(ADS_CFG_LAST_LOAD_TIME, time - oneDay);
      ret = adCache.isAdConfigLoadExpired();
      Assert.assertTrue(ret);
   }




   @After
   public void deInitData() {
      FilePathManager.jsonToFile("", AD_CACHE_URI);

      SPManager.remove(ADS_STATUS_MAP);

      adCache = null;
   }
}

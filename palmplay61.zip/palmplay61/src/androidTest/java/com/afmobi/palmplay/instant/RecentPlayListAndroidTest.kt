package com.afmobi.palmplay.instant

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.afmobi.palmplay.h5.offline.db.H5OfflineInfoDatabase
import com.afmobi.palmplay.h5.offline.db.GameFavoriteDao
import com.afmobi.palmplay.home.instant.model.TrInstantH5Bean
import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameDao
import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameDatabase
import com.afmobi.palmplay.home.instant.model.db.TrInstantH5GameInfo
import com.afmobi.palmplay.home.model.FeatureBean
import com.afmobi.palmplay.home.model.base.FeatureBaseData
import com.afmobi.palmplay.model.GameFavoriteInfo
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * 内置游戏替换（飞机大战 → 农场游戏）完整逻辑 androidTest
 *
 * 对应生产代码：TrInstantViewModel.getRecentPlayList() / checkFarmFavoriteStatus()
 *
 * 覆盖用例：
 *   用例 4/16 — 常量 FARM_GAME_ID=-2 / FARM_BASE_URL 正确
 *   用例 6    — gameId="-1" 飞机大战记录不进入 recentList
 *   用例 8    — hasPlayedFarm=true 时不插入农场预置位
 *   用例 9    — hasPlayedFarm=false 时在首位插入农场预置位
 *   用例 10   — openUrl 含 FARM_BASE_URL 的 H5 记录触发收藏去重
 *   用例 21   — 收藏 map 中 id=-1 的飞机大战不进入 recentList
 *   DB 查询   — 排序（lastPlayTime DESC）、LIMIT 截断
 *   缓存清理  — loadNetCache 时旧缓存中农场脏数据被移除
 *
 * 运行：
 *   ./gradlew :palmplay61:connectedSplitvaOnlineDebugAndroidTest \
 *     -Pandroid.testInstrumentationRunnerArguments.class=com.afmobi.palmplay.instant.RecentPlayListAndroidTest
 */
@RunWith(AndroidJUnit4::class)
class RecentPlayListAndroidTest {

    // 直接用字面量，避免引用系统包 9.3.6 里可能不存在的字段
    private val FARM_BASE_URL = "lxt.palminstant.com/Poultry_Farm/"
    private val FARM_GAME_ID_STR = "-2"
    private val FARM_OPEN_URL = "https://lxt.palminstant.com/Poultry_Farm/index.html?gamechannel=palm&sourceType=1&showTitle=F"

    private lateinit var h5Dao: TrInstantH5GameDao
    private lateinit var favoriteDao: GameFavoriteDao

    private lateinit var h5Snapshot: List<TrInstantH5GameInfo>
    private lateinit var favoriteSnapshot: List<GameFavoriteInfo>

    @Before
    fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        h5Dao = TrInstantH5GameDatabase.getDatabase(ctx).getTrInstantH5GameDao()
        favoriteDao = H5OfflineInfoDatabase.getDatabase(ctx).getGameFavoriteDao()

        h5Snapshot = h5Dao.getTrInstantH5GameRecentPlayedList()
        favoriteSnapshot = favoriteDao.getGameFavoriteList(1000)
        h5Dao.delete(h5Snapshot)
        favoriteDao.delete(favoriteSnapshot)
    }

    @After
    fun tearDown() {
        h5Dao.deleteAll()
        favoriteDao.deleteAll()
        h5Snapshot.forEach { h5Dao.add(it) }
        favoriteDao.saveGameFavoriteList(favoriteSnapshot)
    }

    // ── 用例 4/16：常量正确性 ─────────────────────────────────────

    @Test
    fun farmConstants_areCorrect() {
        assertEquals(-2, FARM_GAME_ID_STR.toInt())
        assertEquals("-2", FARM_GAME_ID_STR)
        assertTrue(FARM_BASE_URL.contains("lxt.palminstant.com/Poultry_Farm/"))
    }

    // ── 用例 6：飞机大战（gameId="-1"）被过滤 ────────────────────

    @Test
    fun airplaneBattle_isFiltered_fromH5RecentList() {
        h5Dao.add(makeH5Info("-1",  "飞机大战",    1000L))
        h5Dao.add(makeH5Info("101", "NormalGame1", 2000L))
        h5Dao.add(makeH5Info("102", "NormalGame2", 3000L))

        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList(50)
        // TrInstantViewModel.getRecentPlayList() L527-535
        val result = h5List.filter { it.gameId != "-1" }

        assertEquals(2, result.size)
        assertTrue(result.none { it.gameId == "-1" })
    }

    @Test
    fun airplaneBattle_only_resultsInEmptyList() {
        h5Dao.add(makeH5Info("-1", "飞机大战", 1000L))

        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList(50)
        val result = h5List.filter { it.gameId != "-1" }

        assertTrue(result.isEmpty())
    }

    // ── 用例 21：收藏表中 id=-1 的飞机大战不进入 recentList ──────

    @Test
    fun airplaneBattle_inFavorites_isNotAddedToRecentList() {
        favoriteDao.add(makeFavorite(-1,  "飞机大战", ""))
        favoriteDao.add(makeFavorite(101, "NormalGame", "https://other.game.com/"))

        val favorites = favoriteDao.getGameFavoriteList(100)
        val recentList = mutableListOf<String>()
        for (fav in favorites) {
            if (fav.id == -1) continue  // TrInstantViewModel.getRecentPlayList() L621-624
            recentList.add(fav.id.toString())
        }

        assertFalse(recentList.contains("-1"))
        assertTrue(recentList.contains("101"))
    }

    // ── 用例 10：openUrl 含 FARM_BASE_URL 时触发收藏去重 ─────────

    @Test
    fun farmOpenUrl_inH5List_removesMatchingFavorite() {
        favoriteDao.add(makeFavorite(-2, "Farm", "https://${FARM_BASE_URL}index.html"))
        favoriteDao.add(makeFavorite(101, "OtherGame", "https://other.game.com/"))

        h5Dao.add(makeH5Info("999", "FarmAlt", 5000L).apply {
            openUrl = "https://${FARM_BASE_URL}index.html"
        })

        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList(50)
        val favMap = favoriteDao.getGameFavoriteList(100)
            .associateBy { it.id.toString() }
            .toMutableMap()

        // TrInstantViewModel.getRecentPlayList() L596-610
        for (info in h5List) {
            var gameId = info.gameId
            if (!info.openUrl.isNullOrEmpty() && info.openUrl.contains(FARM_BASE_URL)) {
                gameId = FARM_GAME_ID_STR
            }
            favMap.remove(gameId)
        }

        assertFalse("H5 农场记录应把收藏 map 里的农场条目去重", favMap.containsKey("-2"))
        assertTrue("其他收藏不受影响", favMap.containsKey("101"))
    }

    @Test
    fun noFarmOpenUrl_inH5List_favoriteIsRetained() {
        favoriteDao.add(makeFavorite(-2, "Farm", "https://${FARM_BASE_URL}index.html"))
        h5Dao.add(makeH5Info("101", "NormalGame", 1000L).apply {
            openUrl = "https://other.game.com/"
        })

        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList(50)
        val favMap = favoriteDao.getGameFavoriteList(100)
            .associateBy { it.id.toString() }
            .toMutableMap()

        for (info in h5List) {
            var gameId = info.gameId
            if (!info.openUrl.isNullOrEmpty() && info.openUrl.contains(FARM_BASE_URL)) {
                gameId = FARM_GAME_ID_STR
            }
            favMap.remove(gameId)
        }

        assertTrue("H5 列表无农场 openUrl 时，收藏农场条目应保留", favMap.containsKey("-2"))
    }

    // ── 用例 8/9：hasPlayedFarm 决定是否插入预置位 ───────────────

    @Test
    fun hasPlayedFarm_true_doesNotInsertFarmPreset() {
        // 写入一条农场 H5 记录，模拟"已玩过"
        h5Dao.add(makeH5Info("farm_played", "Farm", 9000L).apply {
            openUrl = "https://${FARM_BASE_URL}index.html"
        })

        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList()
        val hasPlayedFarm = h5List.any {
            !it.openUrl.isNullOrEmpty() && it.openUrl.contains(FARM_BASE_URL)
        }

        val featureBean = makeFeatureBean("RANK_H_V_H5")
        val originalSize = featureBean.dataList.size

        // TrInstantViewModel checkFarmFavoriteStatus() / loadNetCache() 插入判断
        if (!hasPlayedFarm) featureBean.dataList.add(0, makeFarmH5Bean())

        assertTrue(hasPlayedFarm)
        assertEquals("已玩过农场时，预置位不应插入", originalSize, featureBean.dataList.size)
    }

    @Test
    fun hasPlayedFarm_false_insertsFarmPresetAtIndex0() {
        // DB 为空，未玩过农场
        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList()
        val hasPlayedFarm = h5List.any {
            !it.openUrl.isNullOrEmpty() && it.openUrl.contains(FARM_BASE_URL)
        }

        val featureBean = makeFeatureBean("RANK_H_V_H5")
        val originalSize = featureBean.dataList.size

        if (!hasPlayedFarm) featureBean.dataList.add(0, makeFarmH5Bean())

        assertFalse(hasPlayedFarm)
        assertEquals("未玩过农场时应插入一条", originalSize + 1, featureBean.dataList.size)
        val inserted = featureBean.dataList[0] as TrInstantH5Bean
        assertEquals(FARM_GAME_ID_STR, inserted.gameId)
    }

    @Test
    fun nonH5RankStyle_doesNotInsertFarmPreset() {
        val h5List = h5Dao.getTrInstantH5GameRecentPlayedList()
        val hasPlayedFarm = h5List.any {
            !it.openUrl.isNullOrEmpty() && it.openUrl.contains(FARM_BASE_URL)
        }

        val featureBean = makeFeatureBean("RANK_OTHER_STYLE")
        val originalSize = featureBean.dataList.size

        if ("RANK_H_V_H5" == featureBean.style && !hasPlayedFarm) {
            featureBean.dataList.add(0, makeFarmH5Bean())
        }

        assertEquals("非 RANK_H_V_H5 样式不应插入农场", originalSize, featureBean.dataList.size)
    }

    // ── 缓存清理：旧缓存中农场脏数据被移除 ───────────────────────

    @Test
    fun loadNetCache_removesStaleFarmEntry() {
        val featureBean = makeFeatureBean("RANK_H_V_H5")
        featureBean.dataList.add(makeFarmH5Bean())   // 模拟旧缓存脏数据
        val sizeBeforeClean = featureBean.dataList.size

        // TrInstantViewModel loadNetCache() 清理逻辑
        val it = featureBean.dataList.iterator()
        while (it.hasNext()) {
            val item = it.next()
            if (item is TrInstantH5Bean &&
                !item.openUrl.isNullOrEmpty() &&
                item.openUrl.contains(FARM_BASE_URL)
            ) it.remove()
        }

        assertEquals(sizeBeforeClean - 1, featureBean.dataList.size)
        assertFalse(featureBean.dataList.any {
            it is TrInstantH5Bean && it.openUrl?.contains(FARM_BASE_URL) == true
        })
    }

    // ── DB 查询行为：排序 / LIMIT ──────────────────────────────────

    @Test
    fun recentList_orderedByLastPlayTimeDesc() {
        h5Dao.add(makeH5Info("A", "Game_A", 1000L))
        h5Dao.add(makeH5Info("B", "Game_B", 3000L))
        h5Dao.add(makeH5Info("C", "Game_C", 2000L))

        val list = h5Dao.getTrInstantH5GameRecentPlayedList(50)

        assertEquals("B", list[0].gameId)
        assertEquals("C", list[1].gameId)
        assertEquals("A", list[2].gameId)
    }

    @Test
    fun recentList_respectsLimit() {
        for (i in 1..25) h5Dao.add(makeH5Info("$i", "Game$i", i.toLong() * 1000))

        val list = h5Dao.getTrInstantH5GameRecentPlayedList(20)

        assertEquals(20, list.size)
    }

    // ── 辅助方法 ──────────────────────────────────────────────────

    private fun makeH5Info(gameId: String, name: String, lastPlayTime: Long) =
        TrInstantH5GameInfo().apply {
            this.gameId = gameId
            this.name = name
            this.lastPlayTime = lastPlayTime
            this.openUrl = ""
        }

    private fun makeFavorite(id: Int, name: String, openUrl: String) =
        GameFavoriteInfo().apply {
            this.id = id
            this.name = name
            this.openUrl = openUrl
            this.favoriteTime = System.currentTimeMillis()
        }

    private fun makeFeatureBean(style: String): FeatureBean {
        val bean = FeatureBean()
        bean.style = style
        bean.dataList = mutableListOf<FeatureBaseData>().also { list ->
            list.add(TrInstantH5Bean().apply {
                gameId = "100"
                openUrl = "https://other.game.com/index.html"
            })
        }
        return bean
    }

    private fun makeFarmH5Bean() = TrInstantH5Bean().apply {
        gameId = FARM_GAME_ID_STR
        openUrl = "https://${FARM_BASE_URL}index.html?gamechannel=palm&sourceType=1&showTitle=F"
        name = "Poultry Farm"
    }
}

package com.afmobi.palmplay.smoke

import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaClickableAssertions.assertClickable
import com.afmobi.palmplay.appdetail.TRNewAppDetailViewActivity
import com.afmobi.palmplay.appmanage.downloadManagerRobot
import com.afmobi.palmplay.appmanage.updateManagerRobot
import com.afmobi.palmplay.home.mainPageRobot
import com.afmobi.palmplay.va.myGamesRobot
import com.transsnet.store.R
import org.junit.Test
import org.junit.runner.RunWith

/**
 * PalmStore 冒烟测试 — 10 个用例，目标 < 2 分钟
 *
 * 覆盖页面：
 *   - 底部 Tab 主页（MainActivity）
 *   - My Games 页（MyGamesActivity）
 *   - Update 更新管理页（ManageUpdateActivity）
 *   - App 详情页（TRNewAppDetailViewActivity）复用 AppDetailBaristaTest Robot 逻辑
 *   - 下载管理页（ManageDownloadV2Activity）复用 DownloadManagerRobot
 *
 * 运行：
 *   adb shell am instrument -w -r \
 *     -e class com.afmobi.palmplay.smoke.SmokeTest \
 *     com.transsnet.store.test/androidx.test.runner.AndroidJUnitRunner
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class SmokeTest {

    private val ctx get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 底部 Tab 主页 ─────────────────────────────────────────

    @Test
    fun smoke_homeMainPageLoads() {
        // Given 冷启动 App
        // When  MainActivity 渲染完成
        // Then  底部导航栏和内容区域可见
        mainPageRobot { launch() }
            .pageIsDisplayed()
            .bottomTabIsDisplayed()
            .contentContainerIsDisplayed()
    }

    @Test
    fun smoke_homeAppTabDoesNotCrash() {
        // Given 主页已加载
        // When  点击 App Tab（位置 1）
        // Then  页面不崩溃，底部导航仍可见
        mainPageRobot { launch() }
            .clickAppTab()
            .bottomTabIsDisplayed()
    }

    @Test
    fun smoke_homeGameTabDoesNotCrash() {
        // Given 主页已加载
        // When  点击 Game Tab（位置 3）
        // Then  页面不崩溃
        mainPageRobot { launch() }
            .clickGameTab()
            .bottomTabIsDisplayed()
    }

    @Test
    fun smoke_homeMeTabDoesNotCrash() {
        // Given 主页已加载
        // When  点击 Me Tab（位置 4）
        // Then  页面不崩溃
        mainPageRobot { launch() }
            .clickMeTab()
            .bottomTabIsDisplayed()
    }

    // ── My Games ─────────────────────────────────────────────

    @Test
    fun smoke_myGamesPageLoads() {
        // Given 用户进入 My Games 页
        // When  页面渲染完成
        // Then  标题栏和游戏列表可见
        myGamesRobot { launch() }
            .titleIsDisplayed()
            .gamesListIsDisplayed()
    }

    // ── Update 更新管理 ───────────────────────────────────────

    @Test
    fun smoke_updateManagerPageLoads() {
        // Given 用户进入更新管理页
        // When  页面渲染完成
        // Then  更新列表或空态视图可见（任意一个），不崩溃
        updateManagerRobot { launch() }
            .updateListOrEmptyViewDisplayed()
    }

    // ── App 详情页 ────────────────────────────────────────────

    @Test
    fun smoke_appDetailPageLoads() {
        // Given 用户打开 App 详情页
        // When  页面渲染完成
        // Then  根布局和下载按钮可见
        val intent = Intent(ctx, TRNewAppDetailViewActivity::class.java).apply {
            putExtra("mItemID", "123456")
            putExtra("packageName", "com.whatsapp")
            putExtra("value", "test_smoke")
        }
        ActivityScenario.launch<TRNewAppDetailViewActivity>(intent)
        Thread.sleep(1500)
        assertDisplayed(R.id.rootView)
        assertDisplayed(R.id.layout_bottom)
    }

    @Test
    fun smoke_appDetailDownloadButtonClickable() {
        // Given App 详情页已加载
        // When  下载按钮可见
        // Then  下载按钮可点击
        val intent = Intent(ctx, TRNewAppDetailViewActivity::class.java).apply {
            putExtra("mItemID", "123456")
            putExtra("packageName", "com.whatsapp")
            putExtra("value", "test_smoke")
        }
        ActivityScenario.launch<TRNewAppDetailViewActivity>(intent)
        Thread.sleep(1500)
        assertClickable(R.id.status_panel)
    }

    // ── 下载管理页 ────────────────────────────────────────────

    @Test
    fun smoke_downloadManagerPageLoads() {
        // Given 用户进入下载管理页
        // When  页面渲染完成
        // Then  下载列表可见
        downloadManagerRobot { launch() }
            .downloadListIsDisplayed()
    }

    @Test
    fun smoke_downloadManagerTitleVisible() {
        // Given 下载管理页已加载
        // When  标题栏渲染
        // Then  标题栏和返回按钮可见
        downloadManagerRobot { launch() }
            .titleBarIsDisplayed()
            .backButtonIsDisplayed()
    }
}

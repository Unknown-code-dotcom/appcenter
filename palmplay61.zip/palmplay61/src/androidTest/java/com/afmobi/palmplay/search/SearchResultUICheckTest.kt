package com.afmobi.palmplay.search

import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import androidx.test.platform.app.InstrumentationRegistry
import com.afmobi.palmplay.search.v9_3.SearchActivity_v9_3
import com.afmobi.palmplay.uicheck.UICheckReportRule
import com.afmobi.palmplay.uicheck.UIChecker
import com.afmobi.palmplay.viewmodel.search.ISearchInterface
import com.transsnet.store.R
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * 搜索结果页 UI 还原度校验测试。
 *
 * 设计稿来源：node-data-1439_19719.json（Figma 节点树）
 * 页面说明：360×820dp 搜索结果列表，每条 App item 高 80dp
 *
 * Figma 节点 → View ID 映射（基于第一条 item）：
 *   Scooper_News_Local_N%1439_19725 → tv_name       (App 名称, 16sp Regular)
 *   5.0%1439_19728                  → tv_score      (评分,    12sp Regular)
 *   53.7_MB%1439_19732              → tv_source_size (大小,   12sp Regular)
 *
 * 运行：
 *   ./gradlew :palmplay61:connectedSplitvaOnlineDebugAndroidTest \
 *     --tests "com.afmobi.palmplay.search.SearchResultUICheckTest"
 *
 * 报告拉取：
 *   adb shell ls /sdcard/ui-check-report*.html
 *   adb pull /sdcard/ui-check-report-<timestamp>.html
 *
 * 注意：测试需要网络，搜索词 "novel" 会触发真实请求返回结果列表。
 * 若 CI 无网络，可用 mock 或跳过（添加 @Ignore）。
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class SearchResultUICheckTest {

    @get:Rule
    val uiCheckRule = UICheckReportRule()

    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var scenario: ActivityScenario<SearchActivity_v9_3>

    @Before
    fun setUp() {
        // 直接启动搜索并执行关键词，跳过输入框交互
        val intent = Intent(ctx, SearchActivity_v9_3::class.java).apply {
            putExtra(ISearchInterface.KEY_CUR_SEARCH, "novel")
            putExtra(ISearchInterface.KEY_IS_EXCUTE_SEARCH, true)
        }
        scenario = ActivityScenario.launch(intent)

        // 等待 RecyclerView 可见，再等 header 下方第一条 item 渲染完成
        onView(withId(R.id.xrecyclerview))
            .check(matches(isDisplayed()))
        onView(withId(R.id.tv_name)).check(matches(isDisplayed()))
    }

    /**
     * 校验搜索结果第一条 App item 的视觉属性与 Figma 设计稿是否一致。
     *
     * 检测项：
     *   - tv_name：App 名称文字颜色、字体大小（16sp）、字重（Regular）
     *   - tv_score：评分文字颜色、字体大小（12sp）
     *   - tv_source_size：大小文字颜色、字体大小（12sp）
     */
    @Test
    fun checkFirstItemTextStyles() {
        scenario.onActivity { activity ->
            // RecyclerView item 的第一条（位置 0 处），通过 layoutManager 拿到 itemView
            val rv = activity.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.xrecyclerview)
            val firstItem = rv?.layoutManager?.findViewByPosition(1) // position 1：XRecyclerView 有 header 占位

            if (firstItem == null) {
                android.util.Log.w("SearchResultUICheckTest", "首条 item 未渲染，跳过校验（可能网络未返回）")
                return@onActivity
            }

            // App 名称 — Figma: 16sp Regular, 颜色 Text/Primary
            UIChecker.verifyInView(
                itemView = firstItem,
                viewId = R.id.tv_name,
                componentKey = "Scooper_News_Local_N%1439_19725",
                specFile = "node-data-1439_19719.json"
            )

            // 评分 — Figma: 12sp Regular, 颜色 Brand/Primary (#007BFF 系)
            UIChecker.verifyInView(
                itemView = firstItem,
                viewId = R.id.tv_score,
                componentKey = "5.0%1439_19728",
                specFile = "node-data-1439_19719.json"
            )

            // 文件大小 — Figma: 12sp Regular
            UIChecker.verifyInView(
                itemView = firstItem,
                viewId = R.id.tv_source_size,
                componentKey = "53.7_MB%1439_19732",
                specFile = "node-data-1439_19719.json"
            )
        }
    }

    /**
     * 校验整屏可见的所有 item 的 App 名称字号一致性。
     * 目的：发现因 RecyclerView 复用导致的样式污染。
     */
    @Test
    fun checkAllVisibleItemNameFontSize() {
        scenario.onActivity { activity ->
            val rv = activity.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.xrecyclerview)
                ?: return@onActivity
            val lm = rv.layoutManager ?: return@onActivity

            // XRecyclerView position 0 是 header，从 1 开始是实际 item
            for (pos in 1 until minOf(lm.itemCount, 8)) {
                val itemView = lm.findViewByPosition(pos) ?: continue
                UIChecker.verifyInView(
                    itemView = itemView,
                    viewId = R.id.tv_name,
                    componentKey = "Scooper_News_Local_N%1439_19725",
                    specFile = "node-data-1439_19719.json"
                )
            }
        }
    }
}

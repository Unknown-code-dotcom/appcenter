package com.afmobi.palmplay.test;

import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.google.gson.Gson;
import com.transsion.xwebview.asyncclick.UrlAsyncClickLogic;
import com.transsion.xwebview.asyncclick.UrlAsyncClickManager;
import com.transsion.xwebview.asyncclick.bean.AsyncClickCacheBean;
import com.transsnet.store.BuildConfig;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Field;
import java.util.concurrent.CopyOnWriteArrayList;

import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class AttributioLogicAndroidTest {

    private UrlAsyncClickManager manager;

    @Before
    public void initData() {
        manager = UrlAsyncClickManager.getInstance();
    }


    @Test
    public void testAttributioLogic() {

        Object obj = getFieldByReclect("com.transsion.xwebview.asyncclick.UrlAsyncClickLogic", "mAsyncClickCacheList");
        CopyOnWriteArrayList<AsyncClickCacheBean> list = (CopyOnWriteArrayList<AsyncClickCacheBean>) obj;

        String t = "{\"appRemovedFrom\":-1,\"coin\":0,\"continueDownCount\":1,\"continuousInstall\":false,\"currentIndex\":0,\"downloadCount\":\"20259\",\"downloadStatus\":4,\"downloadType\":\"\",\"downloadedSize\":0,\"downloadedTime\":\"1661365562064\",\"attributeUrl\":\"http://www.baidu.com\",\"downloadurl\":\"http://uat-cdn.palmplaystore.com/source/665/c5bc26afea5346c48c779d5e6c79c8c8.apk\",\"extraInfo\":{\"detailType\":\"SOFT\",\"externalId\":0,\"fromSite\":\"Icon\",\"fromType\":0,\"isActivationNotify\":0,\"isAttribute\":true,\"isAutoDownload\":0,\"isOffer\":0,\"isPlutoOffer\":false,\"isPlutoUpdate\":false,\"isShowed\":false,\"isSpaceLimit\":false,\"isSubPackage\":false,\"isUpdate\":\"\",\"md5\":\"\",\"md5Total\":0,\"noNeedRetry\":false,\"offerDesc\":\"\",\"placementId\":\"1\",\"reportSource\":\"1\",\"taskId\":0,\"time\":0,\"topicID\":\"613\",\"topicPlace\":\"3\"},\"fromPage\":\"Home\",\"hasTrack\":false,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/291/190c72d1ac534588b2e29cd2d070261e.webp\",\"isActived\":false,\"isDeletedTag\":0,\"isFromCash\":false,\"isGrp\":false,\"isOffline\":false,\"isWifiLostPause\":false,\"itemID\":\"s_d5d6b38f02fb470f9ed1b2a3437651d4\",\"mOfferShowed\":false,\"name\":\"Panda Slide\",\"packageName\":\"com.innockstudios.pandaslide\",\"pageParamInfo\":{\"mCurPage\":\"H_hfe_3_1\",\"mLastPage\":\"H_X_X_X\"},\"retryTimes\":0,\"sourceSize\":3870924,\"type\":0,\"unZipProgress\":0,\"version\":19,\"versionName\":\"1.5\"}";
        FileDownloadInfo fileDownloadInfo = new Gson().fromJson(t, FileDownloadInfo.class);

        UrlAsyncClickLogic.handleClickAttribute(fileDownloadInfo.extraInfo.isAttribute,fileDownloadInfo.packageName,fileDownloadInfo.version,fileDownloadInfo.attributeUrl,fileDownloadInfo.extraInfo.attributeType,fileDownloadInfo.downloadUrl);

        int size = (list != null) ? list.size() : 0;

        Assert.assertEquals(1, size);


        AsyncClickCacheBean item = getAsyncClickCacheBean(list);
        Assert.assertNotNull(item);

    }

    private AsyncClickCacheBean getAsyncClickCacheBean(CopyOnWriteArrayList<AsyncClickCacheBean> list) {
        if (list != null && list.size() > 0) {
            AsyncClickCacheBean item = (AsyncClickCacheBean) list.get(0);
            return item;
        }

        return null;
    }


    @Test
    public void testClearInvalidateData() {

        Object obj = getFieldByReclect("com.transsion.xwebview.asyncclick.UrlAsyncClickLogic", "mAsyncClickCacheList");
        CopyOnWriteArrayList<AsyncClickCacheBean> list = (CopyOnWriteArrayList<AsyncClickCacheBean>) obj;
        Assert.assertNotNull(list);

        String t = "{\"appRemovedFrom\":-1,\"coin\":0,\"continueDownCount\":1,\"continuousInstall\":false,\"currentIndex\":0,\"downloadCount\":\"20259\",\"downloadStatus\":4,\"downloadType\":\"\",\"downloadedSize\":0,\"downloadedTime\":\"1661365562064\",\"downloadurl\":\"http://uat-cdn.palmplaystore.com/source/665/c5bc26afea5346c48c779d5e6c79c8c8.apk\",\"extraInfo\":{\"detailType\":\"SOFT\",\"externalId\":0,\"fromSite\":\"Icon\",\"fromType\":0,\"isActivationNotify\":0,\"isAttribute\":false,\"isAutoDownload\":0,\"isOffer\":0,\"isPlutoOffer\":false,\"isPlutoUpdate\":false,\"isShowed\":false,\"isSpaceLimit\":false,\"isSubPackage\":false,\"isUpdate\":\"\",\"md5\":\"\",\"md5Total\":0,\"noNeedRetry\":false,\"offerDesc\":\"\",\"placementId\":\"1\",\"reportSource\":\"1\",\"taskId\":0,\"time\":0,\"topicID\":\"613\",\"topicPlace\":\"3\"},\"fromPage\":\"Home\",\"hasTrack\":false,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/291/190c72d1ac534588b2e29cd2d070261e.webp\",\"isActived\":false,\"isDeletedTag\":0,\"isFromCash\":false,\"isGrp\":false,\"isOffline\":false,\"isWifiLostPause\":false,\"itemID\":\"s_d5d6b38f02fb470f9ed1b2a3437651d4\",\"mOfferShowed\":false,\"name\":\"Panda Slide\",\"packageName\":\"com.innockstudios.pandaslide\",\"pageParamInfo\":{\"mCurPage\":\"H_hfe_3_1\",\"mLastPage\":\"H_X_X_X\"},\"retryTimes\":0,\"sourceSize\":3870924,\"type\":0,\"unZipProgress\":0,\"version\":19,\"versionName\":\"1.5\"}";
        FileDownloadInfo fileDownloadInfo = new Gson().fromJson(t, FileDownloadInfo.class);
        UrlAsyncClickLogic.handleClickAttribute(fileDownloadInfo.extraInfo.isAttribute,fileDownloadInfo.packageName,fileDownloadInfo.version,fileDownloadInfo.attributeUrl,fileDownloadInfo.extraInfo.attributeType,fileDownloadInfo.downloadUrl);

        AsyncClickCacheBean item = getAsyncClickCacheBean(list);
        if (item != null) {
            long lastTime = System.currentTimeMillis() - 31 * 24 * 60 * 60 * 1000L;
            item.setLastSuccessTime(lastTime);
        }

        UrlAsyncClickLogic.clearInvalidateData(list);

        int size = list.size();

        Assert.assertEquals(0, size);
    }



    private Object getFieldByReclect(String clsName, String attrName) {
        Object obj = null;
        try {
            Class clazz = Class.forName(clsName);
            Field field = clazz.getDeclaredField(attrName);
            field.setAccessible(true);
            obj = field.get(clazz);
        }catch(Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        return obj;
    }
}

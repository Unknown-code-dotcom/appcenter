package com.afmobi.palmplay.cucumber

import io.cucumber.junit.CucumberOptions

@CucumberOptions(
    features = ["features"],
    glue = ["com.afmobi.palmplay.cucumber.steps"],
    plugin = ["pretty"]
)
class AppDetailCucumberOptions

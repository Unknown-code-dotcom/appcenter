package com.afmobi.palmplay.utils;

import com.transsnet.store.BuildConfig;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimeUtils {

   public final static long ONE_HOUR = 1 * 60 * 60 * 1000L; // 1h
   public final static long ONE_DAY =  1 * 24 * 60 * 60 * 1000L;


   public static String getTodayDate() {

      String today = null;
      try {
         SimpleDateFormat srcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault());

         long time = System.currentTimeMillis();
         long s = time;
         Date date = new Date(s);
         today = srcFormat.format(date);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }


      return today;
   }

   public static String getYestodayDate() {

      String yestoday = null;
      try {
         SimpleDateFormat srcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault());

         long time = System.currentTimeMillis();
         long s = time - ONE_DAY;
         Date date = new Date(s);
         yestoday = srcFormat.format(date);
      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }


      return yestoday;
   }

   /**
    * format:  2022-03-07T16:00:00.000+0000
    *
    * */
   public static String getTomorrowDate() {

      String tomorrow = null;
      try {
         SimpleDateFormat srcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault());

         long time = System.currentTimeMillis();
         long s = time + ONE_DAY;
         Date date = new Date(s);
         tomorrow = srcFormat.format(date);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }


      return tomorrow;
   }
}

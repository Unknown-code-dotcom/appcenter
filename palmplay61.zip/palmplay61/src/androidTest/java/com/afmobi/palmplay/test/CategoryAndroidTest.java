package com.afmobi.palmplay.test;

import android.content.Context;

import com.afmobi.palmplay.cache.CategoryCache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.CategoryInfo;
import com.afmobi.palmplay.model.CategoryListData;
import com.afmobi.util.Constant;
import com.afmobi.util.FileUtils;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.lang.reflect.Type;
import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class CategoryAndroidTest {

   private static final String CACHE_URI_APP = "APP_CATEGORY_CACHE_NEW";
   private static final String CACHE_URI_GAME = "GAME_CATEGORY_CACHE_NEW";

   private Context mContext;
   private CategoryCache category;

   private String oldAppCategory, oldGameCategory;

   @Before
   public void init() {
      mContext = ApplicationProvider.getApplicationContext();

      JsonElement appCategoryCache = FilePathManager.fileToJson(CACHE_URI_APP);
      JsonElement gameCategoryCache = FilePathManager.fileToJson(CACHE_URI_GAME);

      oldAppCategory = appCategoryCache != null ? appCategoryCache.toString() : null;
      oldGameCategory = (gameCategoryCache != null) ? gameCategoryCache.toString() : null;

      String path = mContext.getFilesDir().getAbsolutePath();
      File f1 = new File(path + File.separator + CACHE_URI_APP);
      FileUtils.deleteFile(f1);

      File f2 = new File(path + File.separator + CACHE_URI_GAME);
      FileUtils.deleteFile(f2);

      category = CategoryCache.getInstance();
   }

   @Test
   public void test_getFileName_App() {

      String appName = category.getFileName(Constant.SOFTTYPE_APP);
      Assert.assertEquals(CACHE_URI_APP, appName);

   }

   @Test
   public void test_getFileName_Game() {

      String gameName = category.getFileName(Constant.SOFTTYPE_GAME);
      Assert.assertEquals(CACHE_URI_GAME, gameName);

   }

   @Test
   public void test_getCategoryCache_App() {
      List<CategoryInfo> list = category.getCategoryCache(Constant.SOFTTYPE_APP);
      Assert.assertTrue(list.size() > 0);
   }

   @Test
   public void test_getCategoryCache_Game() {
      List<CategoryInfo> list = category.getCategoryCache(Constant.SOFTTYPE_GAME);
      Assert.assertTrue(list.size() > 0);
   }

   @Test
   public void test_saveCategoryDataToCache_App() {

      category.clearCategoryDataCache();

      String categoryIdKey = "1896ff1657b2408daeb264ba6d370bf2Hot";
      String txt = "{\"isPageLast\":false,\"itemList\":[{\"category2\":\"App\",\"category3\":\"1896ff1657b2408daeb264ba6d370bf2\",\"commentCount\":0,\"curPageIndex\":0,\"curPosition\":0,\"diffSize\":0,\"hasEmptyPageTrack\":false,\"hasLoaded\":false,\"hasTrack\":false,\"isInstalled\":false,\"isNew\":false,\"isSearchKeyRecommApp\":false,\"isUsed\":false,\"item_type\":\"ITEM\",\"officialTag\":false,\"orgPosition\":0,\"outerLinkFlag\":false,\"progress\":0,\"score\":4.9,\"star\":5,\"styleType\":0,\"categoryName\":\"Finance\",\"cus_detailType\":6,\"detailType\":\"SOFT\",\"downloadCount\":894807,\"externalId\":0,\"flag\":0,\"fromType\":2,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/694/b6cfc3a83549481688f564bddf5776bb.webp\",\"isAttribute\":false,\"isGrp\":false,\"isOffer\":0,\"isReserve\":0,\"isSubPackage\":false,\"itemID\":\"s_3246f77c68e24fcb9cf137e4e651d7ff\",\"name\":\"Palmcredit-Personal loan, Fast Cash, Instant loan\",\"observerStatus\":0,\"offerDesc\":\"\",\"packageName\":\"com.transsnetfinancial.palmcredit\",\"price\":0,\"showPlay\":\"F\",\"simpleDescription\":\"Internet financial product\",\"size\":10486804,\"sourceType\":0,\"taskId\":0,\"varId\":-1,\"verifyGoogle\":\"F\",\"version\":215,\"versionName\":\"2.4.0\"}],\"pageIndex\":0,\"pageSum\":300}";
      Type type = new TypeToken<CategoryListData>(){}.getType();
      CategoryListData list = new Gson().fromJson(txt, type);

      category.saveCategoryDataToCache(categoryIdKey, list);

      CategoryListData data = category.getCategoryDataFromCache(categoryIdKey);
      Assert.assertNotNull(data);
   }

   @Test
   public void test_saveCategoryDataToCache_Game() {

      category.clearCategoryDataCache();

      String categoryIdKey = "1896ff1657b2408daeb264ba6d370bf2New";
      String txt = "{\"isPageLast\":false,\"itemList\":[{\"category2\":\"App\",\"category3\":\"1896ff1657b2408daeb264ba6d370bf2\",\"commentCount\":0,\"curPageIndex\":0,\"curPosition\":0,\"diffSize\":0,\"hasEmptyPageTrack\":false,\"hasLoaded\":false,\"hasTrack\":false,\"isInstalled\":false,\"isNew\":false,\"isSearchKeyRecommApp\":false,\"isUsed\":false,\"item_type\":\"ITEM\",\"officialTag\":false,\"orgPosition\":0,\"outerLinkFlag\":false,\"progress\":0,\"score\":4.9,\"star\":5,\"styleType\":0,\"categoryName\":\"Finance\",\"cus_detailType\":6,\"detailType\":\"SOFT\",\"downloadCount\":894807,\"externalId\":0,\"flag\":0,\"fromType\":2,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/694/b6cfc3a83549481688f564bddf5776bb.webp\",\"isAttribute\":false,\"isGrp\":false,\"isOffer\":0,\"isReserve\":0,\"isSubPackage\":false,\"itemID\":\"s_3246f77c68e24fcb9cf137e4e651d7ff\",\"name\":\"Palmcredit-Personal loan, Fast Cash, Instant loan\",\"observerStatus\":0,\"offerDesc\":\"\",\"packageName\":\"com.transsnetfinancial.palmcredit\",\"price\":0,\"showPlay\":\"F\",\"simpleDescription\":\"Internet financial product\",\"size\":10486804,\"sourceType\":0,\"taskId\":0,\"varId\":-1,\"verifyGoogle\":\"F\",\"version\":215,\"versionName\":\"2.4.0\"}],\"pageIndex\":0,\"pageSum\":300}";
      Type type = new TypeToken<CategoryListData>(){}.getType();
      CategoryListData list = new Gson().fromJson(txt, type);

      category.saveCategoryDataToCache(categoryIdKey, list);

      CategoryListData data = category.getCategoryDataFromCache(categoryIdKey);
      Assert.assertNotNull(data);
   }

   @Test
   public void test_clearCategoryDataCache() {

      test_saveCategoryDataToCache_App();

      category.clearCategoryDataCache();

      String categoryIdKey = "1896ff1657b2408daeb264ba6d370bf2Hot";
      CategoryListData data = category.getCategoryDataFromCache(categoryIdKey);
      Assert.assertNull(data);
   }


   @After
   public void deInit() {
      FilePathManager.jsonToFile(oldAppCategory, CACHE_URI_APP);
      FilePathManager.jsonToFile(oldGameCategory, CACHE_URI_GAME);

      category.clearCategoryDataCache();
      category = null;

   }

}

package com.afmobi.palmplay.uicheck

/**
 * 全局单例，收集测试执行期间所有 UIChecker.verify() 产生的结果。
 * 线程安全：使用 @Synchronized 保护写入。
 */
object CheckResultCollector {

    private val results = mutableListOf<CheckResult>()

    @Synchronized
    fun add(result: CheckResult) {
        results.add(result)
    }

    @Synchronized
    fun getAll(): List<CheckResult> = results.toList()

    @Synchronized
    fun clear() {
        results.clear()
    }

    fun summary(): String {
        val all = getAll()
        val pass = all.count { it.status == CheckStatus.PASS }
        val warn = all.count { it.status == CheckStatus.WARN }
        val fail = all.count { it.status == CheckStatus.FAIL }
        return "共 ${all.size} 项，通过 $pass，警告 $warn，失败 $fail"
    }
}

package com.afmobi.palmplay.test;

import android.content.Context;

import com.afmobi.palmplay.cache.PlutoOfferInfoCache;
import com.afmobi.palmplay.cache.PlutoPushIdCache;
import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.PlutoOfferResponseModel;
import com.afmobi.palmplay.receivers.PalmstoreReceiver;
import com.afmobi.palmplay.utils.ReflectUtils;
import com.afmobi.util.FileUtils;
import com.google.gson.Gson;
import com.transsnet.store.BuildConfig;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.lang.reflect.Method;
import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class PlutoAndroidTest {

   private static String pluto_push_id_uri = null;

   private PlutoOfferInfoCache plutoCache;
   private Context mContext;

   @Before
   public void initData() {
      mContext = ApplicationProvider.getApplicationContext();

      pluto_push_id_uri = FilePathManager.getCacheBaseFileUri()+ File.separator + "pluto_push_id_cache.txt";

      plutoCache = PlutoOfferInfoCache.getInstance();

      saveToCacheNotify();
   }




   private void saveToCacheNotify() {

      ACache.get(mContext).remove(PlutoOfferInfoCache.PLUTO_OFFER_INFO_CACHE);
      FileUtils.deleteFile(new File(pluto_push_id_uri));

      String t = "{\"code\":\"1000\",\"data\":{\"config\":{\"downloadTime\":\"1\",\"impressionTime\":\"1\",\"induceInterval\":240,\"isReportCrash\":0,\"jobSerAliveTime\":8,\"locationReportTime\":6,\"offLineTime\":\"1\",\"reminderBuriedPointTime\":9,\"retryCount\":\"20\"},\"push\":{\"apkList\":[{\"apkFileUrl\":\"http://public.shtranssion.com/admaster_poll/apk/1619608907040/Lazada.apk\",\"apkIconUrl\":\"http://public.shtranssion.com/admaster_poll/image/1620466204192.png\",\"apkName\":\"Lazada\",\"apkPkgName\":\"com.lazada.android\",\"apkSize\":20788226,\"apkVersion\":1096,\"apkVersionName\":\"6.67.0.1\",\"apkWeight\":1,\"awakeProp\":100,\"awakeValidPeriod\":60,\"decayRate\":1,\"desc\":\"- Greate music videos with beautiful magic\\\\u003cbr\\\\u003e\",\"firstDoc\":\"Greate music videos with beautiful magic 111111\",\"firstImg\":\"http://public.shtranssion.com/admaster_poll/image/1611816175821.png\",\"iconHasCached\":false,\"isChecked\":true,\"isInstalled\":false,\"isUpdate\":0,\"lastShowTime\":0,\"md5\":\"\",\"numberLimit\":0,\"secondDoc\":\"Greate music videos with beautiful magic 222222\",\"secondImg\":\"http://public.shtranssion.com/admaster_poll/image/1611816179149.png\",\"showCount\":0,\"stableValue\":95,\"taskId\":0,\"thirdDoc\":\"Greate music videos with beautiful magic 333333\",\"thirdImg\":\"http://public.shtranssion.com/admaster_poll/image/1611816181446.png\",\"userTagSwitch\":\"0\"},{\"apkFileUrl\":\"http://public.shtranssion.com/admaster_poll/apk/1620464264596/MiChat.apk\",\"apkIconUrl\":\"http://public.shtranssion.com/admaster_poll/image/1620466194160.png\",\"apkName\":\"MiChat\",\"apkPkgName\":\"com.michatapp.im\",\"apkSize\":30981855,\"apkVersion\":2670,\"apkVersionName\":\"1.3.134\",\"apkWeight\":3,\"awakeProp\":0,\"awakeValidPeriod\":60,\"decayRate\":0,\"desc\":\"describe\",\"firstDoc\":\"111111\",\"firstImg\":\"http://public.shtranssion.com/admaster_poll/image/1620464316366.png\",\"iconHasCached\":false,\"isChecked\":true,\"isInstalled\":false,\"isUpdate\":0,\"lastShowTime\":0,\"md5\":\"\",\"numberLimit\":0,\"secondDoc\":\"22222222\",\"secondImg\":\"http://public.shtranssion.com/admaster_poll/image/1620464321095.png\",\"showCount\":0,\"stableValue\":0,\"taskId\":0,\"thirdDoc\":\"33333333\",\"thirdImg\":\"http://public.shtranssion.com/admaster_poll/image/1620464325698.png\",\"userTagSwitch\":\"0\"}],\"boldDesc\":\"\",\"commonDesc\":\"The update will consume a small amount of traffic\",\"count\":999999,\"downloadDesc1\":\"\\\\u003cfont color\\\\u003d\\\\\\\"#222222\\\\\\\" size\\\\u003d\\\\\\\"5\\\\\\\"\\\\u003e\\n- Greate music videos with beautiful magic\\\\u003cbr\\\\u003edescribe\\\\u003c/font\\\\u003e\\\\u003cbr\\\\u003e\\nThe update will consume a small amount of traffic\",\"downloadDesc2\":\"\",\"endTime\":1664090700088,\"garyTime\":\"\",\"grayTime\":\"\",\"iconUrl\":\"http://public.shtranssion.com/admaster_poll/image/1620466204192.png\",\"installDesc\":\"Top Apps Recommended Install\",\"isDownloadIcon\":1,\"lastFillTime\":1661498706931,\"launcherIconUrl\":\"http://public.shtranssion.com/admaster_poll/image/1620466204192.png\",\"launcherMd5\":\"\",\"launcherPkgName\":\"\",\"launcherUrl\":\"\",\"launcherVersion\":\"\",\"loadDesc\":\"Updating. Please do not turn off your phone during the process\",\"mainDesc\":\"\\\\u003cfont color\\\\u003d\\\\\\\"#222222\\\\\\\" size\\\\u003d\\\\\\\"5\\\\\\\"\\\\u003e\\n- Greate music videos with beautiful magic\\\\u003cbr\\\\u003edescribe\\\\u003c/font\\\\u003e\\\\u003cbr\\\\u003e\\nThe update will consume a small amount of traffic\",\"network\":\"wifi|4g|3g|2g\",\"popTitle\":\"App Update\",\"pushId\":\"10007\",\"pushPercent\":99,\"securityStrategy\":1,\"startTime\":1661498700088,\"userTags\":\"all\"},\"requestId\":\"0a966d5bl7a5fj6w-7369\"},\"desc\":\"success\",\"isAllIconCached\":false}";
      try {
         PlutoOfferResponseModel info = new Gson().fromJson(t, PlutoOfferResponseModel.class);
         plutoCache.saveToCacheNotify(info);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }
   }


   @Test
   public void test_loadFromCache() {

      PlutoOfferResponseModel info = plutoCache.loadFromCache();

      Assert.assertNotNull(info);
   }


   @Test
   public void test_getApkList() {

      PlutoOfferResponseModel info = plutoCache.loadFromCache();

      List<PlutoOfferResponseModel.DataBean.PushBean.ApkListBean> list = plutoCache.getApkList(info);

      Assert.assertEquals(2, list.size());
   }

   @Test
   public void test_getLastFillTime() {
      long lastTime = plutoCache.getLastFillTime();

      Assert.assertTrue(lastTime > 0);
   }

   @Test
   public void test_getInduceInterval() {
      long interval = plutoCache.getInduceInterval(); // 4h
      long defaultInterval = 192  * 60 * 1000L; // 8h

      Assert.assertNotEquals(defaultInterval, interval);

   }


   @Test
   public void test_getIntervalShowTime() {
      long interval = plutoCache.getIntervalShowTime(null);

      Assert.assertTrue(interval > 0);
   }


   @Test
   public void test_getPushIdList() {
      List<String> list = PlutoPushIdCache.getInstance().getPushIdList();

      Assert.assertEquals(1, list.size());
   }


   @Test
   public void test_aaa() {
      PalmstoreReceiver re = new PalmstoreReceiver();

      try {
         Method method = ReflectUtils.getMethodByReclect("com.afmobi.palmplay.receivers.PalmstoreReceiver", "startPushService", Context.class);
         Object obj = ReflectUtils.invokeMethodByReclectReturn(method, re, mContext);
         Assert.assertFalse((boolean) obj);




      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }
   }







}

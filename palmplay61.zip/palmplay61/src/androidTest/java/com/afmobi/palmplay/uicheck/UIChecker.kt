package com.afmobi.palmplay.uicheck

import android.app.Activity
import android.util.Log
import android.view.View
import androidx.test.platform.app.InstrumentationRegistry

/**
 * 公开入口。在 Espresso 测试中调用：
 *
 *   UIChecker.verify(activity, R.id.app_name_tv,
 *       "Scooper_News_Local_N%1439_19725", "node-data-1439_19719.json")
 *
 * 默认软断言：不抛异常，只记录结果到 CheckResultCollector。
 * failOnError=true 时，有 FAIL 项则抛出 AssertionError。
 */
object UIChecker {

    private const val TAG = "UIChecker"

    // 容差：颜色通道偏差，尺寸 dp 偏差
    private const val COLOR_DELTA = 2
    private const val SIZE_DELTA_DP = 1f

    // 缓存已加载的 spec loader，避免重复 IO
    private val loaderCache = java.util.concurrent.ConcurrentHashMap<String, DesignSpecLoader>()

    fun verify(
        activity: Activity,
        viewId: Int,
        componentKey: String,
        specFile: String = "node-data-1439_19719.json",
        failOnError: Boolean = false
    ) {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val loader = loaderCache.getOrPut(specFile) {
            DesignSpecLoader.load(context, specFile)
        }
        val spec = loader.getSpec(componentKey)
        if (spec == null) {
            Log.w(TAG, "componentKey not found in spec: $componentKey")
            return
        }

        val view = activity.findViewById<View>(viewId)
        if (view == null) {
            Log.w(TAG, "View not found for id: $viewId")
            return
        }

        runVerify(view, spec, componentKey, failOnError)
    }

    /**
     * 从任意 itemView 子树中查找 viewId，适用于 RecyclerView item 场景。
     */
    fun verifyInView(
        itemView: View,
        viewId: Int,
        componentKey: String,
        specFile: String = "node-data-1439_19719.json",
        failOnError: Boolean = false
    ) {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val loader = loaderCache.getOrPut(specFile) {
            DesignSpecLoader.load(context, specFile)
        }
        val spec = loader.getSpec(componentKey)
        if (spec == null) {
            Log.w(TAG, "componentKey not found in spec: $componentKey")
            return
        }

        val view = itemView.findViewById<View>(viewId)
        if (view == null) {
            Log.w(TAG, "View not found in itemView for id: $viewId")
            return
        }

        runVerify(view, spec, componentKey, failOnError)
    }

    private fun runVerify(view: View, spec: ComponentSpec, componentKey: String, failOnError: Boolean) {
        val actual = ViewAttributeReader.read(view)
        val viewIdHex = "0x${Integer.toHexString(view.id)}"

        val results = compareSpecs(spec, actual, componentKey, viewIdHex)
        results.forEach { CheckResultCollector.add(it) }

        if (failOnError && results.any { it.status == CheckStatus.FAIL }) {
            val failures = results.filter { it.status == CheckStatus.FAIL }
                .joinToString("\n") { "  ${it.attribute}: 设计=${it.designValue}, 实际=${it.actualValue} ${it.delta}" }
            throw AssertionError("UIChecker FAIL [$componentKey]:\n$failures")
        }
    }

    private fun compareSpecs(
        design: ComponentSpec,
        actual: ComponentSpec,
        componentKey: String,
        viewIdHex: String
    ): List<CheckResult> {
        val results = mutableListOf<CheckResult>()

        fun colorResult(attr: String, dv: Int?, av: Int?) {
            if (dv == null) return
            if (av == null) {
                results.add(CheckResult(componentKey, design.nodeName, viewIdHex, attr,
                    colorHex(dv), "null", CheckStatus.FAIL))
                return
            }
            val maxDelta = maxOf(
                Math.abs((dv shr 16 and 0xFF) - (av shr 16 and 0xFF)),
                Math.abs((dv shr 8 and 0xFF) - (av shr 8 and 0xFF)),
                Math.abs((dv and 0xFF) - (av and 0xFF))
            )
            val status = when {
                maxDelta <= COLOR_DELTA -> CheckStatus.PASS
                maxDelta <= COLOR_DELTA * 2 -> CheckStatus.WARN
                else -> CheckStatus.FAIL
            }
            results.add(CheckResult(componentKey, design.nodeName, viewIdHex, attr,
                colorHex(dv), colorHex(av), status,
                if (status != CheckStatus.PASS) "(Δ$maxDelta)" else ""))
        }

        fun floatResult(attr: String, dv: Float?, av: Float?, unit: String) {
            if (dv == null) return
            if (av == null) {
                results.add(CheckResult(componentKey, design.nodeName, viewIdHex, attr,
                    "$dv$unit", "null", CheckStatus.FAIL))
                return
            }
            val delta = Math.abs(dv - av)
            val status = when {
                delta <= SIZE_DELTA_DP -> CheckStatus.PASS
                delta <= SIZE_DELTA_DP * 2 -> CheckStatus.WARN
                else -> CheckStatus.FAIL
            }
            val deltaStr = if (status != CheckStatus.PASS) "(+${"%.1f".format(delta)}$unit)" else ""
            results.add(CheckResult(componentKey, design.nodeName, viewIdHex, attr,
                "${"%.1f".format(dv)}$unit", "${"%.1f".format(av)}$unit", status, deltaStr))
        }

        fun strResult(attr: String, dv: String?, av: String?) {
            if (dv == null) return
            val status = if (dv == av) CheckStatus.PASS else CheckStatus.FAIL
            results.add(CheckResult(componentKey, design.nodeName, viewIdHex, attr,
                dv, av ?: "null", status))
        }

        colorResult("backgroundColor", design.backgroundColor, actual.backgroundColor)
        colorResult("textColor", design.textColor, actual.textColor)
        floatResult("fontSize", design.fontSize, actual.fontSize, "sp")
        strResult("fontWeight", design.fontWeight, actual.fontWeight)
        floatResult("letterSpacing", design.letterSpacing, actual.letterSpacing, "")
        floatResult("paddingTop", design.paddingTop, actual.paddingTop, "dp")
        floatResult("paddingBottom", design.paddingBottom, actual.paddingBottom, "dp")
        floatResult("paddingStart", design.paddingStart, actual.paddingStart, "dp")
        floatResult("paddingEnd", design.paddingEnd, actual.paddingEnd, "dp")
        floatResult("cornerRadius", design.cornerRadius, actual.cornerRadius, "dp")
        floatResult("elevation", design.elevation, actual.elevation, "dp")
        floatResult("width", design.width, actual.width, "dp")
        floatResult("height", design.height, actual.height, "dp")

        return results
    }

    private fun colorHex(color: Int): String = "#%08X".format(color)
}

package com.afmobi.palmplay.download.support

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * GdprDialogActivity UI 集成测试
 *
 * 验证GDPR隐私弹窗页面的核心流程：
 * - 页面正常启动
 * - 隐私弹窗展示
 * - 同意/取消操作
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class GdprDialogActivityTest {

    @Before
    fun setUp() {
        // 清除之前可能残留的回调
        GdprDialogActivity.clearCallback()
    }

    @After
    fun tearDown() {
        GdprDialogActivity.clearCallback()
    }

    @Test
    fun `正常主流程_页面启动并展示隐私弹窗`() {
        gdprDialogRobot()
            .launch()
            .assertPageDisplayed()
            .assertPrivacyDialogShown()
    }

    @Test
    fun `云端备份下载action_启动页面正常`() {
        gdprDialogRobot()
            .launch(actionFrom = GdprDialogActivity.CLOUD_BACKUP_DOWNLOAD)
            .assertPageDisplayed()
    }

    @Test
    fun `外部下载服务action_启动页面正常`() {
        gdprDialogRobot()
            .launch(actionFrom = GdprDialogActivity.SUPPORT_EXTERNAL_DOWNLOAD, sourceType = "test_source")
            .assertPageDisplayed()
    }

    @Test
    fun `setCallback和clearCallback_正确设置和清除`() {
        var called = false
        val callback = GdprDialogActivity.Igdpr { called = true }
        GdprDialogActivity.setCallback(callback)
        GdprDialogActivity.clearCallback()
        // 清理后不应崩溃
    }
}

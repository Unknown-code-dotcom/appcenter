package com.afmobi.palmplay.uicheck

import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 将 CheckResultCollector 中的结果渲染为 HTML 文件，写入 /sdcard/。
 * 使用：adb pull /sdcard/ui-check-report-<timestamp>.html
 */
object HtmlReportGenerator {

    private fun String.toRgbHex(): String =
        if (length == 9 && startsWith("#")) "#${substring(3)}" else this

    fun generate(): String {
        val results = CheckResultCollector.getAll()
        val pass = results.count { it.status == CheckStatus.PASS }
        val warn = results.count { it.status == CheckStatus.WARN }
        val fail = results.count { it.status == CheckStatus.FAIL }
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

        val rows = results.joinToString("\n") { r ->
            val statusCell = when (r.status) {
                CheckStatus.PASS -> "<td class='pass'>✅ 通过</td>"
                CheckStatus.WARN -> "<td class='warn'>⚠️ 警告 ${r.delta}</td>"
                CheckStatus.FAIL -> "<td class='fail'>❌ 失败 ${r.delta}</td>"
            }
            val designDisplay = if (r.attribute.contains("color", ignoreCase = true))
                "${r.designValue} <span class='swatch' style='background:${r.designValue.toRgbHex()}'></span>"
            else r.designValue
            val actualDisplay = if (r.attribute.contains("color", ignoreCase = true))
                "${r.actualValue} <span class='swatch' style='background:${r.actualValue.toRgbHex()}'></span>"
            else r.actualValue

            """<tr>
              <td>${r.nodeName}</td>
              <td>${r.componentKey}</td>
              <td>${r.attribute}</td>
              <td>$designDisplay</td>
              <td>$actualDisplay</td>
              $statusCell
            </tr>"""
        }

        val html = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>UI 校验报告</title>
<style>
  body { font-family: sans-serif; margin: 20px; background: #f9f9f9; }
  h1 { font-size: 18px; }
  .summary { background: #1a1a2e; color: white; padding: 12px 20px; border-radius: 6px;
             margin-bottom: 16px; font-size: 14px; }
  table { width: 100%; border-collapse: collapse; background: white; border-radius: 6px;
          overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.1); }
  th { background: #f0f0f0; padding: 10px; text-align: left; font-size: 13px; }
  td { padding: 9px 10px; font-size: 13px; border-bottom: 1px solid #eee; }
  .pass { color: #34a853; font-weight: bold; }
  .warn { color: #f57c00; font-weight: bold; }
  .fail { color: #e53935; font-weight: bold; }
  .swatch { display:inline-block; width:12px; height:12px; border-radius:2px;
            vertical-align:middle; margin-left:4px; border:1px solid #ccc; }
</style>
</head>
<body>
<h1>UI 校验报告</h1>
<div class="summary">共 ${results.size} 项 &nbsp;·&nbsp; ✅ 通过 $pass &nbsp;·&nbsp; ⚠️ 警告 $warn &nbsp;·&nbsp; ❌ 失败 $fail &nbsp;·&nbsp; $ts</div>
<table>
  <tr><th>节点名</th><th>unique_id</th><th>属性</th><th>设计值</th><th>实际值</th><th>状态</th></tr>
  $rows
</table>
</body>
</html>"""

        // Android 10+ 此 API 已废弃，测试工具用途可接受，如需兼容可改用 context.getExternalFilesDir(null)
        val outputDir = Environment.getExternalStorageDirectory()
        val file = File(outputDir, "ui-check-report-$ts.html")
        file.writeText(html)
        return file.absolutePath
    }
}

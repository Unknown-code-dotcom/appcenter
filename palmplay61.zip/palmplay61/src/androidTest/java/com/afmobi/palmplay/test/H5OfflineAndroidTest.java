package com.afmobi.palmplay.test;

import android.content.Context;
import android.text.TextUtils;

import com.afmobi.palmplay.h5.offline.H5OfflineManager;
import com.afmobi.palmplay.h5.offline.db.H5OfflineInfoDao;
import com.afmobi.palmplay.h5.offline.db.H5OfflineInfoDatabase;
import com.afmobi.palmplay.model.H5OfflineConfigInfo;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.transsnet.store.BuildConfig;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class H5OfflineAndroidTest {

   private H5OfflineManager manager;

   private H5OfflineInfoDao db;
   private List<H5OfflineConfigInfo> oldH5Configlist;
   private List<H5OfflineConfigInfo> newConfigList;

   @Before
   public void init() {
      Context context = ApplicationProvider.getApplicationContext();
      db = H5OfflineInfoDatabase.getDatabase(context)
              .getH5OfflineInfoDao();
      oldH5Configlist = db.getH5OfflineConfigList(); //读取老数据保存，带单元测试完成再写回去

      db.delete(oldH5Configlist);

      try {
         String txt = "[{\"acId\":3,\"acName\":\"wincash\",\"downloadUrl\":\"https://test-cdn.palmplaystore.com/source/975/aa464e2229ca49979ff1d541de4eb8ad.zip\",\"startTime\":\"2022-07-19 00:00:00\",\"endTime\":\"2023-08-31 00:00:00\",\"version\":23,\"urlMatchFlag\":\"winca.palmplaystore.com\",\"md5\":\"9751e41e36a770cce50c13931066c191\",\"offlineFirst\":1,\"resourceId\":62},{\"acId\":6,\"acName\":\"feiji\",\"downloadUrl\":\"https://test-cdn.palmplaystore.com/source/255/3cf91a0fc3ad48478368e2b77f136c86.zip\",\"startTime\":\"2022-09-04 00:00:00\",\"endTime\":\"2022-09-30 00:00:00\",\"version\":15,\"urlMatchFlag\":\"63158fd8ad738\",\"md5\":\"b2d4a144974737aa6acee245cd88df32\",\"offlineFirst\":1,\"resourceId\":140}]";
         List<H5OfflineConfigInfo> list = new Gson().fromJson(txt, new TypeToken<List<H5OfflineConfigInfo>>(){}.getType());
         newConfigList = list;
         db.saveH5OfflineConfigList(list);
      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }


      manager = H5OfflineManager.getInstance();

   }



   @Test
   public void test_getH5OfflineConfigList() {
      List<H5OfflineConfigInfo> list = db.getH5OfflineConfigList();
      Assert.assertNotNull(list);

      Assert.assertEquals(2, list.size());
   }

   @Test
   public void test_deleteItem() {


      H5OfflineConfigInfo item = newConfigList.get(0);
      if (item != null) {
         db.deleteItem(item);
      }

      boolean isDeleteOk = true;
      List<H5OfflineConfigInfo> list = db.getH5OfflineConfigList();
      for (H5OfflineConfigInfo tmp : list) {
         if (tmp.resourceId == item.resourceId) {
            isDeleteOk = false;
            break;
         }
      }
      Assert.assertTrue(isDeleteOk);

      //利用resourceId删除
      isDeleteOk = true;
      if (list != null && !list.isEmpty()) {
         H5OfflineConfigInfo second = newConfigList.get(0);
         db.deleteByResourceId(String.valueOf(second.resourceId));

         list = db.getH5OfflineConfigList();
         for (H5OfflineConfigInfo tmp : list) {
            if (tmp.resourceId == item.resourceId) {
               isDeleteOk = false;
               break;
            }
         }
      }
      Assert.assertTrue(isDeleteOk);

   }


   @Test
   public void test_updateH5OfflineInfo() {

      db.saveH5OfflineConfigList(newConfigList);


      if (newConfigList.size() > 0) {
         H5OfflineConfigInfo item = newConfigList.get(0);
         item.acName = "testNameNew";
         db.updateH5OfflineInfo(item);

         List<H5OfflineConfigInfo> list = db.getH5OfflineConfigList();

         boolean updateOk = false;
         for (H5OfflineConfigInfo tmp : list) {
            if (tmp.resourceId == item.resourceId) {
               if (TextUtils.equals(tmp.acName, item.acName)) {
                  updateOk = true;
                  break;
               }
            }
         }

         Assert.assertTrue(updateOk);
      }

   }


   @After
   public void deInit() {
      //恢复老数据
      db.saveH5OfflineConfigList(oldH5Configlist);
   }

}

package com.afmobi.palmplay.test;

import android.content.Context;
import android.text.TextUtils;

import com.afmobi.palmplay.cache.InstalledAppsUpdateCache;
import com.afmobi.palmplay.download.slient.SlientDownloadManager;
import com.afmobi.palmplay.download.slient.database.SlientUpdateDao;
import com.afmobi.palmplay.download.slient.database.SlientUpdateDatabase;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.model.ClientVersion;
import com.afmobi.palmplay.model.keeptojosn.AppsUpdateList;
import com.afmobi.palmplay.model.keeptojosn.CheckVersionBean;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.afmobi.util.FileUtils;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.transsnet.store.BuildConfig;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class SilentDownloadAndroidTest {

   private final static String FILE_NAME = "InstalledAppsUpdateCache";

   private SlientDownloadManager manager;
   private SlientUpdateDao db;
   private boolean hasSilentPermission = false;
   private List<ClientVersion.UpdateItem> oldUpdatelist;
   private List<ClientVersion.UpdateItem> listNew;
   private String oldCacheFile = null;

   private InstalledAppsUpdateCache cacheManager;

   @Before
   public void init() {

      Context context = ApplicationProvider.getApplicationContext();
      db = SlientUpdateDatabase.getDatabase(context)
              .getSlientUpdateDao();

      oldUpdatelist = db.getAllSlientUpdateApps();

      JsonElement jsonObject = FilePathManager.fileToJson(getFileName());
      oldCacheFile = (jsonObject != null) ? jsonObject.toString() : "";
      File oldFile = new File(context.getFilesDir() + File.separator + getFileName());
      FileUtils.deleteFile(oldFile);

      cacheManager = InstalledAppsUpdateCache.getInstance();

      try {
          String t = "{\"code\":0,\"message\":\"Success!\",\"data\":{\"delayTimeInterval\":0,\"config\":{\"loadTimeInterval\":4,\"reloadTimeInterval\":4},\"updateList\":[{\"itemID\":\"s_a4530fc08bc34ddcbf02af4ba6e5b990\",\"name\":\"Phoenix Browser -Video Download, Private & Fast\",\"cpID\":\"0941\",\"packageName\":\"com.transsion.phoenix\",\"iconUrl\":\"http://cdn2.palmplaystore.com/static/857/2b577211c1c04373b9d295cd1d44c978.webp\",\"version\":4005,\"versionName\":\"11.0.1.4005\",\"itemNum\":\"s_a4530fc08bc34ddcbf02af4ba6e5b990\",\"md5\":\"3180b2ca1be397368eb10ba5b2f800ad\",\"size\":\"27991548\",\"isOuter\":\"false\",\"outerUrl\":\"\",\"fromType\":\"2\",\"updateWay\":\"1\",\"taskId\":0,\"updateNetType\":\"WIFI\",\"diffSize\":null},{\"itemID\":\"s_016b4b1ecbd94047ba188b4678fac3eb\",\"name\":\"Phone Master–Junk Clean Master\",\"cpID\":\"100732\",\"packageName\":\"com.transsion.phonemaster\",\"iconUrl\":\"http://cdn2.palmplaystore.com/static/584/54c882e0314b4780801dd327f11dc3e1.webp\",\"version\":5646,\"versionName\":\"5.3.6.00012\",\"itemNum\":\"s_016b4b1ecbd94047ba188b4678fac3eb\",\"md5\":\"eec42b010940350bbe4b9dd41c194c8a\",\"size\":\"31321550\",\"isOuter\":\"false\",\"outerUrl\":\"\",\"fromType\":\"2\",\"updateWay\":\"1\",\"taskId\":0,\"updateNetType\":\"WIFI\",\"diffSize\":null},{\"itemID\":\"s_cee936fc36f34f49adbb4f886eebb9e2\",\"name\":\"FaceApp\",\"cpID\":\"0686\",\"packageName\":\"io.faceapp\",\"iconUrl\":\"http://cdn2.palmplaystore.com/static/464/c7a78abfe56944eb923a0dc1e14b4e94.webp\",\"version\":8418,\"versionName\":\"10.2.4\",\"itemNum\":\"s_ap494f68658f254d46b76c2a7c1e2cd054\",\"md5\":\"5e193b3620215681f69b7a8edb53d353\",\"size\":\"48795042\",\"isOuter\":\"false\",\"outerUrl\":\"\",\"fromType\":\"8\",\"updateWay\":\"2\",\"taskId\":0,\"updateNetType\":\"\",\"diffSize\":null}]}}";
          Type type = new TypeToken<CheckVersionBean>(){}.getType();
          CheckVersionBean resp = new Gson().fromJson(t, type);
          if (resp != null) {
             listNew = resp.getData().getUpdateList();
          }
          AppsUpdateList mAppsUpdateList = new AppsUpdateList();
          mAppsUpdateList.updateList = listNew;

          cacheManager.saveToCacheFile(mAppsUpdateList);

          db.saveSlientUpdateAppInfoList(listNew);
      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }

      manager = new SlientDownloadManager();

   }

   @Test
   public void test_getFileName() {
      String newName = cacheManager.getFileName();
      String localName = getFileName();

      Assert.assertEquals(localName, newName);
   }


   private ClientVersion.UpdateItem getItemByPkg(List<ClientVersion.UpdateItem> list, String pkg) {
      if (TextUtils.isEmpty(pkg) || list == null) {
         return null;
      }

      for (ClientVersion.UpdateItem item : list) {
         if (TextUtils.equals(item.packageName, pkg)) {
            return item;
         }
      }


      return null;
   }


   @Test
   public void test_updateLocalSlientListFromServer() {
      List<ClientVersion.UpdateItem> sourceList = db.getAllSlientUpdateApps();;

      // list为空
      List<ClientVersion.UpdateItem> list = new ArrayList<>();
      manager.updateLocalSlientListFromServer(list);
      List<ClientVersion.UpdateItem> tmpList = db.getAllSlientUpdateApps();
      Assert.assertEquals(sourceList.size(), tmpList.size());

      // 状态下载完成
      ClientVersion.UpdateItem item = new ClientVersion.UpdateItem();
      item.observerStatus = FileDownloadInfo.STATUS_DOWNLOADED;
      list.clear();
      list.add(item);
      manager.updateLocalSlientListFromServer(list);
      tmpList = db.getAllSlientUpdateApps();
      Assert.assertEquals(sourceList.size(), tmpList.size());

      //本地已安装
      item = new ClientVersion.UpdateItem();
      item.observerStatus = FileDownloadInfo.STATUS_NONE;
      item.packageName = "com.transsnet.store";
      item.version = 1;
      list.clear();
      list.add(item);
      manager.updateLocalSlientListFromServer(list);
      tmpList = db.getAllSlientUpdateApps();
      Assert.assertEquals(sourceList.size(), tmpList.size());

      item = new ClientVersion.UpdateItem();
      item.observerStatus = FileDownloadInfo.STATUS_NONE;
      item.packageName = "com.android.test.abcedfg1";
      item.version = 1;
      list.clear();
      list.add(item);
      manager.updateLocalSlientListFromServer(list);
      tmpList = db.getAllSlientUpdateApps();

      ClientVersion.UpdateItem dst = getItemByPkg(tmpList, item.packageName);
      Assert.assertNotNull(dst);

      db.delete(list);
   }


   @Test
   public void test_updateSlientItem() {
      ClientVersion.UpdateItem item = listNew.get(0);
      item.version = 10000;
      db.updateSlientItem(item);

      List<ClientVersion.UpdateItem> list = db.getAllSlientUpdateApps();
      ClientVersion.UpdateItem dst = getItemByPkg(list, item.packageName);
      Assert.assertNotNull(dst);

      Assert.assertEquals(item.version, dst.version);
   }


   @Test
   public void test_deleteFixedItem() {
      List<ClientVersion.UpdateItem> list = new ArrayList<>(listNew);
      ClientVersion.UpdateItem item = list.get(0);
      db.deleteFixedItem(item.packageName);

      List<ClientVersion.UpdateItem> dstlist = db.getAllSlientUpdateApps();
      ClientVersion.UpdateItem dst = getItemByPkg(dstlist, item.packageName);
      Assert.assertNull(dst);

   }

   @Test
   public void test_deleteItem() {

      db.saveSlientUpdateAppInfoList(listNew);
      List<ClientVersion.UpdateItem> list = new ArrayList<>(listNew);
      ClientVersion.UpdateItem item = list.get(0);
      db.deleteItem(item);

      List<ClientVersion.UpdateItem> dstlist = db.getAllSlientUpdateApps();
      ClientVersion.UpdateItem dst = getItemByPkg(dstlist, item.packageName);
      Assert.assertNull(dst);

   }


   @Test
   public void test_delete() {

      db.saveSlientUpdateAppInfoList(listNew);
      List<ClientVersion.UpdateItem> list = db.getAllSlientUpdateApps();
      Assert.assertTrue(list.size() > 0);

      db.delete(list);

      list = db.getAllSlientUpdateApps();
      Assert.assertEquals(0, list.size());

   }

   @Test
   public void test_deleteAll() {

      List<ClientVersion.UpdateItem> srclist = new ArrayList<>(listNew);
      db.saveSlientUpdateAppInfoList(srclist);

      List<ClientVersion.UpdateItem> list = db.getAllSlientUpdateApps();
      Assert.assertEquals(srclist.size(), listNew.size());

      db.deleteAll();
      list = db.getAllSlientUpdateApps();
      Assert.assertEquals(0, list.size());

   }


   @Test
   public void test_getSlientUpdateItemList() {
      AppsUpdateList updateList = cacheManager.getSlientUpdateItemList();
      Assert.assertEquals(2, updateList.updateList.size());
   }

   @Test
   public void test_getUpdateItemList() {
      AppsUpdateList updateList = cacheManager.getUpdateItemList();
      Assert.assertEquals(1, updateList.updateList.size());
   }


   @Test
   public void test_needUpdate() {
      cacheManager.loadFromCache();

      String pkg = "com.android.test.appupdate";
      boolean ret = cacheManager.isUpdateApp(pkg);
      Assert.assertFalse(ret);

      pkg = "io.faceapp";
      ret = cacheManager.needUpdate(pkg);
      Assert.assertTrue(ret);

   }


   @Test
   public void test_remove() {
      cacheManager.loadFromCache();

      String pkg = "io.faceapp";
      cacheManager.remove(pkg);

      boolean ret = cacheManager.isUpdateApp(pkg);
      Assert.assertTrue(ret);
   }


   @Test
   public void test_getMeasuredPageSize() {
      int counts = 20;
      int size = InstalledAppsUpdateCache.getMeasuredPageSize(counts,
              InstalledAppsUpdateCache.MAX_PAGE,
              InstalledAppsUpdateCache.MAX_PAGE_SIZE);

      Assert.assertEquals(25, size);

      counts = 100;
      InstalledAppsUpdateCache.getMeasuredPageSize(counts,
              InstalledAppsUpdateCache.MAX_PAGE,
              InstalledAppsUpdateCache.MAX_PAGE_SIZE);

      Assert.assertEquals(25, size);

   }

   @Test
   public void test_updateSlientDataBase() {

      ClientVersion.UpdateItem item = listNew.get(0);
      item.version = 10000;
      cacheManager.updateSlientDataBase(item, FileDownloadInfo.STATUS_DOWNING);

      cacheManager.loadFromCache();
      AppsUpdateList updateList = cacheManager.getSlientUpdateItemList();

      ClientVersion.UpdateItem newItem = getItemByPkg(updateList.updateList, item.packageName);
      Assert.assertNotNull(newItem);

      Assert.assertEquals(10000, newItem.version);
   }









   public String getFileName() {
      return FILE_NAME;
   }



   @After
   public void deInit() {

      if (oldUpdatelist != null) {
         db.saveSlientUpdateAppInfoList(oldUpdatelist);
      }

      FilePathManager.jsonToFile(oldCacheFile, getFileName());
   }
}

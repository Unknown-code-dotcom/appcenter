package com.afmobi.palmplay.va

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaEnabledAssertions.assertEnabled
import com.transsnet.store.R

/**
 * My Games 页面 Robot（MyGamesActivity）
 *
 * Intent 参数：
 *   VALUE(_source) — 来源追踪，非必传
 *   isFromInstant  — 是否来自即玩模式，默认 false
 */
class MyGamesRobot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────

    fun launch(): MyGamesRobot {
        val intent = Intent(ctx, MyGamesActivity::class.java).apply {
            putExtra("value", "test_robot")
            putExtra("isFromInstant", false)
        }
        ActivityScenario.launch<MyGamesActivity>(intent)
        Thread.sleep(1500)
        return this
    }

    // ── 断言（Then）──────────────────────────────────────────

    fun titleIsDisplayed(): MyGamesRobot {
        assertDisplayed(R.id.layout_title)
        return this
    }

    fun gamesListIsDisplayed(): MyGamesRobot {
        assertDisplayed(R.id.recyclerView)
        assertEnabled(R.id.recyclerView)
        return this
    }
}

fun myGamesRobot(block: MyGamesRobot.() -> Unit = {}): MyGamesRobot =
    MyGamesRobot().apply(block)

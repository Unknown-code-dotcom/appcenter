package com.afmobi.palmplay.test;


import android.content.Context;

import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.search.v6_4.offline.OfflineSearchManager;
import com.afmobi.palmplay.search.v6_4.offline.bean.SearchOfflineResponse;
import com.afmobi.palmplay.search.v6_4.offline.database.OfflineAppInfo;
import com.afmobi.palmplay.search.v6_4.offline.database.OfflineSearchDatabase;
import com.afmobi.palmplay.utils.BinaryUtils;
import com.afmobi.palmplay.utils.FileUtils;
import com.afmobi.palmplay.utils.ReflectUtils;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.transsion.palmstorecore.util.TRPath;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;
import java.lang.reflect.Method;
import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import static com.afmobi.palmplay.search.v6_4.offline.Constants.MAX_RESULT_COUNT;

@RunWith(AndroidJUnit4.class)
public class OfflineAndroidTest {

    private final static String clsNamePath = "com.afmobi.palmplay.search.v6_4.offline.OfflineSearchManager";

    private final static String SP_SEARCH_OFFLINE_INFO = "sp_search_offline_info";
    private final static String SP_DOWNLOAD_FAIL_COUNT = "sp_download_fail_count";

    private OfflineSearchManager manager;

    private SearchOfflineResponse srcSearchOfflineResp;

    private String oldSearchOfflineInfo = null;
    private List<OfflineAppInfo> listOffline;
    private final static String ZIP_FILE_SUFFIX = ".zip";
    private final static String md5 = "a28eabe52eb7585a59d44e13c371ca7a";
    private Context mContext;

    @Before
    public void init() {
        mContext = ApplicationProvider.getApplicationContext();

        //原来默认数据
        oldSearchOfflineInfo = SPManager.getString(SP_SEARCH_OFFLINE_INFO, "");

        manager = OfflineSearchManager.getInstance();

        String txt = "{\"code\":0,\"message\":\"success\",\"intervalTime\":24,\"data\":{\"downloadUrl\":\"http://public.transacme.com/libra-search/zip/1663634858347/KE.zip\",\"md5\":\"a28eabe52eb7585a59d44e13c371ca7a\"}}";
        srcSearchOfflineResp = new Gson().fromJson(txt, SearchOfflineResponse.class);
        manager.onResponse(srcSearchOfflineResp);


        offlineData2DB();
    }

    private void offlineData2DB()  {

        String path = TRPath.getSearchOfflineDataPath() + File.separator + md5 + ZIP_FILE_SUFFIX;
        FileUtils.saveBytesToZip(path, BinaryUtils.offlineSearchZip);

        Method method = ReflectUtils.getMethodByReclect(clsNamePath, "unzip", String.class);

        ReflectUtils.invokeMethodByReclectReturn(method, manager, md5);
    }



    @Test
    public void test_getCurrentOfflineDataMd5() {
        Method method = ReflectUtils.getMethodByReclect(clsNamePath, "getCurrentOfflineDataMd5");
        Object obj = ReflectUtils.invokeMethodByReclectReturn(method, manager);
        Assert.assertNotNull(obj);


    }

    @Test
    public void test_onDownloadFailMD5Error() {
        int counts = SPManager.getInt(SP_DOWNLOAD_FAIL_COUNT, 0);

        manager.onDownloadFailMD5Error();

        int newCounts = SPManager.getInt(SP_DOWNLOAD_FAIL_COUNT, 0);

        Assert.assertEquals((counts+1), newCounts);
    }

    @Test
    public void test_saveOfflineSearchAppInfoList() {
        String listStr = "[{\"category\":\"App\",\"category3\":\"1896ff1657b2408daeb264ba6d370bf2\",\"categoryName\":\"Finance\",\"downloadCount\":\"63667\",\"fromType\":2,\"iconUrl\":\"http://cdn2.palmplaystore.com/static/771/89d202df0bd74701bc41d0bd5bd52a0a.webp\",\"isOffer\":\"1\",\"isReserve\":\"0\",\"itemID\":\"s_91d688e027e54914bd4487c88445991b\",\"name\":\"LionCash\",\"offerDesc\":\"\",\"officialTag\":\"true\",\"packageName\":\"com.fayetech.chaos\",\"score\":\"5.0\",\"simpleDescription\":\"LionCash - Instant Loan to M-Pesa in Kenya\",\"size\":5746730,\"star\":\"5\",\"taskId\":\"0\",\"verifyGoogle\":\"F\",\"version\":\"11\",\"versionName\":\"1.0.0.9\"},{\"category\":\"Game\",\"category3\":\"83cb0a135cca4f738d2b2dead16d9a21\",\"categoryName\":\"Action\",\"downloadCount\":\"1967165\",\"fromType\":2,\"iconUrl\":\"http://cdn2.palmplaystore.com/static/54/0850bc56e7254c37bdacd12c9c9cbda4.webp\",\"isOffer\":\"0\",\"isReserve\":\"0\",\"itemID\":\"s_520e7e089bef4e18af196ac2f944fbd3\",\"name\":\"Happy Cups\",\"offerDesc\":\"\",\"officialTag\":\"true\",\"packageName\":\"com.cybertron.happycups\",\"score\":\"4.5\",\"simpleDescription\":\"Drop the water into the cups below\",\"size\":11107595,\"star\":\"5\",\"taskId\":\"0\",\"verifyGoogle\":\"F\",\"version\":\"1000030\",\"versionName\":\"V1.0.30.UP\"}]";
        listOffline = new Gson().fromJson(listStr, new TypeToken<List<OfflineAppInfo>>(){}.getType());
        OfflineSearchDatabase.getDatabase(mContext).getOfflineSearchDao().saveOfflineSearchAppInfoList(listOffline);

        String searchKey = "%" + "App" +"%";
        List<OfflineAppInfo> list = OfflineSearchDatabase.getDatabase(mContext).getOfflineSearchDao().searchOfflineData(searchKey, MAX_RESULT_COUNT);
        Assert.assertTrue(list.size() > 0);
    }


    @After
    public void deInit() {

        SPManager.putString(SP_SEARCH_OFFLINE_INFO, oldSearchOfflineInfo);

        String path = TRPath.getSearchOfflineDataPath() + File.separator + md5 + ZIP_FILE_SUFFIX;
        File file = new File(path);
        file.delete();
    }
}

package com.afmobi.palmplay;

import android.content.Intent;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;
import androidx.test.platform.app.InstrumentationRegistry;

import com.transsnet.store.R;

import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

/**
 * StartActivity（启动页/闪屏页）Espresso 集成测试
 *
 * 测试策略：
 *   StartActivity 是闪屏页，onCreate 立刻 finish() 跳到 MainActivity。
 *   测试无法观察 StartActivity 自身的 UI（已消失），
 *   只验证「启动完成后落地页面是否正常」。
 *
 *   每个测试用独立的 ActivityScenario 启动，避免前一个 Activity 已 destroy 的 NPE。
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class StartActivityTest {

    private static Intent buildIntent(String... extras) {
        Intent intent = new Intent(
                InstrumentationRegistry.getInstrumentation().getTargetContext(),
                StartActivity.class
        );
        for (int i = 0; i + 1 < extras.length; i += 2) {
            intent.putExtra(extras[i], extras[i + 1]);
        }
        return intent;
    }

    /**
     * P0-01：正常冷启动，落地 MainActivity
     *
     * given: 无额外参数启动 StartActivity
     * when:  ViewModel 调度完成，StartActivity finish() 跳到 MainActivity
     * then:  MainActivity Tab 栏（R.id.tabs）可见
     */
    @Test
    public void launch_navigatesToMainActivity_successfully() {
        try (ActivityScenario<StartActivity> ignored =
                     ActivityScenario.launch(buildIntent())) {
            onView(withId(R.id.tabs))
                    .check(matches(isDisplayed()));
        }
    }

    /**
     * P1-01：携带 formType 参数启动，落地正常
     *
     * given: 从通知栏点击进入，携带 formType="notification"
     * when:  StartActivity 解析 formType 初始化 source 字段
     * then:  正常落地 MainActivity，不崩溃
     */
    @Test
    public void launch_withFormTypeParam_landedSuccessfully() {
        try (ActivityScenario<StartActivity> ignored =
                     ActivityScenario.launch(buildIntent("formType", "notification"))) {
            onView(withId(R.id.tabs))
                    .check(matches(isDisplayed()));
        }
    }

    /**
     * P1-02：携带 isOpenStatusSaver=true 启动，落地正常
     *
     * given: 从状态保存快捷方式进入
     * when:  StartActivity 读取参数路由
     * then:  不崩溃，页面正常显示
     */
    @Test
    public void launch_withStatusSaverParam_landedSuccessfully() {
        Intent intent = new Intent(
                InstrumentationRegistry.getInstrumentation().getTargetContext(),
                StartActivity.class
        );
        intent.putExtra("isOpenStatusSaver", true);

        try (ActivityScenario<StartActivity> ignored = ActivityScenario.launch(intent)) {
            onView(withId(R.id.tabs))
                    .check(matches(isDisplayed()));
        }
    }

    /**
     * P1-03：携带 fromGame=true 启动，不崩溃
     *
     * given: 点击 VA 游戏快捷方式进入
     * when:  StartActivity 读取 fromGame=true，路由到 openVaGamePage()（不跳 MainActivity）
     * then:  不崩溃（不验证具体落地页，因为路由目标不是 MainActivity）
     */
    @Test
    public void launch_withFromGameParam_doesNotCrash() {
        Intent intent = new Intent(
                InstrumentationRegistry.getInstrumentation().getTargetContext(),
                StartActivity.class
        );
        intent.putExtra("fromGame", true);

        // fromGame=true 时跳到 VA 游戏页，不经过 MainActivity，只验证不崩溃
        try (ActivityScenario<StartActivity> scenario = ActivityScenario.launch(intent)) {
            // CREATED / STARTED / RESUMED / DESTROYED 任意状态均不崩溃即通过
        }
    }
}

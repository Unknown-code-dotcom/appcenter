package com.afmobi.palmplay.cache;

import android.content.Context;

import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.FindListData;
import com.afmobi.palmplay.model.keeptojosn.FindDetailInfo;
import com.google.gson.Gson;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.File;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class PsCommonCacheAndroidTest {

   private PsCommonCache psCommonCache;

   private Context mContext;
   private String mFilePath;

   @Before
   public void createPsCommonCache() {
      mContext = ApplicationProvider.getApplicationContext();
      mFilePath = mContext.getFilesDir().getAbsolutePath();
      // 确保缓存目录存在
      File cacheDir = new File(mFilePath);
      if (!cacheDir.exists()) {
         cacheDir.mkdirs();
      }
      psCommonCache = PsCommonCache.getInstance();
   }



   @Test
   public void testFindCacheAndDelete() {
      testFindSaveToDoubleCache();
      // 给异步写入一些时间完成
      try {
         Thread.sleep(500);
      } catch (InterruptedException e) {
         e.printStackTrace();
      }
      testFindDeleteInvalidCache();
   }

   @Test
   public void testFindDetailCacheAndDelete() {
      String key = "47";
      testFindDetailSaveToDoubleCache(key);
      // 给异步写入一些时间完成
      try {
         Thread.sleep(500);
      } catch (InterruptedException e) {
         e.printStackTrace();
      }
      testFindDetailDeleteInvalidCache(key);
   }

   @Test
   public void testDetailCacheAndDelete() {
      testDetailSaveToDoubleCache();
      // 给异步写入一些时间完成
      try {
         Thread.sleep(500);
      } catch (InterruptedException e) {
         e.printStackTrace();
      }
      testDetailDeleteInvalidCache();
   }

   @Test
   public void testFinDetailOver25Items() {

      Class<FindDetailInfo> cls = FindDetailInfo.class;
      String key = "47";
      testFindDetailSaveToMemory(key);

      FindDetailInfo newData = psCommonCache.loadFromCache(key, cls);
      assertNotNull(newData);

      // 添加更多缓存数据，验证内存缓存容量
      for (int i=0;i<25;i++) {
         key = String.valueOf(i);
         testFindDetailSaveToMemory(key);
      }

      // 验证最新添加的数据存在（LRU 缓存策略保留最近使用的数据）
      key = "0";
      newData = psCommonCache.loadFromCache(key, cls);
      assertNotNull("Latest added data should exist in memory cache", newData);
   }


   private void testFindSaveToDoubleCache() {

      String txt = "{\"code\":0,\"data\":[{\"id\":44,\"countryCode\":\"NG,ML,BD,SN,KE,ET,TZ,UG,CM,CN,FR,ES,PT,DZ,AO,BH,BT,CF,TD,CG,CD,CR,CI,DM,DO,EG,GQ,ER,EE,GF,PF,GA,GM,GE,DE,GH,GI,GN,GW,HK,HU,IS,IN,IQ,IR,IT,JM,JO,KZ,KW,LR,LY,MO,MW,MQ,MR,MU,MC,RW,WS,SA,SO,ZA,TW,TJ,TG,TT,TN,TR,AE,GB,US,VG,VI,ZM,ZW,ID,VN,PK,NP,OT,MA,RU,CA,SD,PH,TH\",\"cardStyle\":\"1\",\"cardBannerUrl\":\"http://uat-cdn.palmplaystore.com/static/480/e6864b02006e46eb95b3f73c3e43d4ee.webp\",\"title\":\"Build your dream Garden\",\"subTitle\":\"Unique gameplay\",\"issueNo\":\"43\",\"cardType\":\"GAME\",\"tag\":\"\",\"isTop\":true,\"pageView\":\"28.3K\",\"modifyTime\":1608533855000,\"itemList\":[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/953/db36a92a2ea14368aa4a72d6cf808628.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.playrix.gardenscapes\",\"taskId\":0}]},{\"id\":50,\"countryCode\":\"NG,ML,BD,SN,KE,ET,TZ,UG,CM,CN,FR,ES,PT,DZ,AO,BH,BT,CF,TD,CG,CD,CR,CI,DM,DO,EG,GQ,ER,EE,GF,PF,GA,GM,GE,DE,GH,GI,GN,GW,HK,HU,IS,IN,IQ,IR,IT,JM,JO,KZ,KW,LR,LY,MO,MW,MQ,MR,MU,MC,RW,WS,SA,SO,ZA,TW,TJ,TG,TT,TN,TR,AE,GB,US,VG,VI,ZM,ZW,ID,VN,PK,NP,OT,MA,RU,CA,SD,PH,TH\",\"cardStyle\":\"2\",\"cardBannerUrl\":\"http://uat-cdn.palmplaystore.com/static/215/d9c71e2d2a524c37ad6d8ecf40fe67df.webp\",\"title\":\"SUBWAY SURF\",\"subTitle\":\"Escape the grumpy officer\",\"issueNo\":\"5000\",\"cardType\":\"APP\",\"tag\":\"\",\"isTop\":false,\"pageView\":\"20.4K\",\"modifyTime\":1616124515000,\"itemList\":[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/484/9e189e5a5c0c4c998a3db29fe13e98a9.gif\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.transsnet.palmpay\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/874/48dbe8abb0f8432790c0895c76bf8e91.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.zhiliaoapp.musically.go\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/908/416e955862b24300a33f08f94469d2fd.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.light.reader.books\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/228/15388a05557b44beb6f8ed07c2d32a2c.png\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.transsion.phoenix\",\"taskId\":0}]},{\"id\":45,\"countryCode\":\"NG,ML,BD,SN,KE,ET,TZ,UG,CM,CN,FR,ES,PT,DZ,AO,BH,BT,CF,TD,CG,CD,CR,CI,DM,DO,EG,GQ,ER,EE,GF,PF,GA,GM,GE,DE,GH,GI,GN,GW,HK,HU,IS,IN,IQ,IR,IT,JM,JO,KZ,KW,LR,LY,MO,MW,MQ,MR,MU,MC,RW,WS,SA,SO,ZA,TW,TJ,TG,TT,TN,TR,AE,GB,US,VG,VI,ZM,ZW,ID,VN,PK,NP,OT,MA,RU,CA,SD,PH,TH\",\"cardStyle\":\"1\",\"cardBannerUrl\":\"http://uat-cdn.palmplaystore.com/static/918/c6850b4e241541dab2b67cf1428f32f0.webp\",\"title\":\"SUBWAY SURF\",\"subTitle\":\"Escape the grumpy officer\",\"issueNo\":\"45\",\"cardType\":\"GAME\",\"tag\":\"\",\"isTop\":false,\"pageView\":\"35.5K\",\"modifyTime\":1609134044000,\"itemList\":[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/677/97ce6a34002d4061b075b60cab1589a3.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.kiloo.subwaysurf\",\"taskId\":0}]},{\"id\":43,\"countryCode\":\"NG,ML,BD,SN,KE,ET,TZ,UG,CM,CN,FR,ES,PT,DZ,AO,BH,BT,CF,TD,CG,CD,CR,CI,DM,DO,EG,GQ,ER,EE,GF,PF,GA,GM,GE,DE,GH,GI,GN,GW,HK,HU,IS,IN,IQ,IR,IT,JM,JO,KZ,KW,LR,LY,MO,MW,MQ,MR,MU,MC,RW,WS,SA,SO,ZA,TW,TJ,TG,TT,TN,TR,AE,GB,US,VG,VI,ZM,ZW,ID,VN,PK,NP,OT,MA,RU,CA,SD,PH,TH\",\"cardStyle\":\"2\",\"cardBannerUrl\":\"http://uat-cdn.palmplaystore.com/static/524/4f308e2c87e94765bc118a62b48b6a2e.webp\",\"title\":\"Funny Christmas games\",\"subTitle\":\"Enjoying your holiday\",\"issueNo\":\"43\",\"cardType\":\"CATEGORY\",\"tag\":\"\",\"isTop\":false,\"pageView\":\"18.3K\",\"modifyTime\":1608519894000,\"itemList\":[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/347/4418c1e999c8473fb9ea56e904421dcf.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"br.com.tapps.tappyrunxmas\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/884/72c5e406359242fd89d29202acb79e95.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.dolphingames.fun.santa.runner\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/838/16830cb870ad49eebba08370f029dd05.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.rvappstudios.fsseasons\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/629/93ad1cfad6d645658e68f3aa1d51956a.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"bubble.shooter.christmas\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/561/de2ea2e76ade4afab1644663357d5062.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.mery.crush.match\",\"taskId\":0},{\"productType\":\"\",\"productLink\":\"\",\"packageName\":\"\",\"taskId\":0}]},{\"id\":42,\"countryCode\":\"NG,ML,BD,SN,KE,ET,TZ,UG,CM,CN,FR,ES,PT,DZ,AO,BH,BT,CF,TD,CG,CD,CR,CI,DM,DO,EG,GQ,ER,EE,GF,PF,GA,GM,GE,DE,GH,GI,GN,GW,HK,HU,IS,IN,IQ,IR,IT,JM,JO,KZ,KW,LR,LY,MO,MW,MQ,MR,MU,MC,RW,WS,SA,SO,ZA,TW,TJ,TG,TT,TN,TR,AE,GB,US,VG,VI,ZM,ZW,ID,VN,PK,NP,OT,MA,RU,CA,SD,PH,TH\",\"cardStyle\":\"2\",\"cardBannerUrl\":\"http://uat-cdn.palmplaystore.com/static/10/ae66395b2b0a49878f9471c9ad935825.webp\",\"title\":\"Best of 2020\",\"subTitle\":\"\",\"issueNo\":\"42\",\"cardType\":\"CATEGORY\",\"tag\":\"\",\"isTop\":false,\"pageView\":\"64.9K\",\"modifyTime\":1607915094000,\"itemList\":[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/677/97ce6a34002d4061b075b60cab1589a3.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.kiloo.subwaysurf\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/320/32356131a6244989883d7e1f65006d85.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.tencent.ig\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/43/aa64db41d12040658583b332686f0619.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.innersloth.spacemafia\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/29/89e95ca207c34049a3b47ff15e7f7f36.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.miHoYo.GenshinImpact\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/363/86934ec09825401b9572bcbc913ed22e.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.game.colorroll3d\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/2/f86092c10c2147dfaed50de8364167ff.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"us.zoom.videomeetings\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/535/c4d8e3be35724e679d28c16005a3fa37.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.intsig.camscanner\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/818/8fe3f17ceb6e4147b1a75501bb9ee8f4.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.fiton.android\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/50/abcd58f36db24345bd09b018a1e166b4.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.canva.editor\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/902/442405b574564af7b234aebfcd8d9f18.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.playit.videoplayer\",\"taskId\":0},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/840/1bc5ee7052d847089b2b4ae6d02253a0.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.in.mvbit\",\"taskId\":0},{\"productType\":\"\",\"productLink\":\"\",\"packageName\":\"\",\"taskId\":0}]},{\"id\":41,\"countryCode\":\"NG,ML,BD,SN,KE,ET,TZ,UG,CM,CN,FR,ES,PT,DZ,AO,BH,BT,CF,TD,CG,CD,CR,CI,DM,DO,EG,GQ,ER,EE,GF,PF,GA,GM,GE,DE,GH,GI,GN,GW,HK,HU,IS,IN,IQ,IR,IT,JM,JO,KZ,KW,LR,LY,MO,MW,MQ,MR,MU,MC,RW,WS,SA,SO,ZA,TW,TJ,TG,TT,TN,TR,AE,GB,US,VG,VI,ZM,ZW,ID,VN,PK,NP,OT,MA,RU,CA,SD,PH,TH\",\"cardStyle\":\"0\",\"cardBannerUrl\":\"http://uat-cdn.palmplaystore.com/static/932/6c21b1e6a5f24e2ba099ebab22ee65c6.webp\",\"title\":\"Race, Clash, and Win!\",\"subTitle\":\"Try this original game.\",\"issueNo\":\"41\",\"cardType\":\"APP\",\"tag\":\"\",\"isTop\":false,\"pageView\":\"26.5K\",\"modifyTime\":1607311569000,\"itemList\":[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/45/c0c074ff789b454ea95b7636a0de26e1.webp\",\"productType\":\"1\",\"productLink\":\"\",\"packageName\":\"com.freeplay.runandfight\",\"taskId\":0}]}],\"total\":36}";

      String key = PsCommonCache.KEY_FIND_LIST;
      Class<FindListData> cls = FindListData.class;
      FindListData data = new Gson().fromJson(txt, cls);
      psCommonCache.saveToDoubleCache(key, data, cls);
      FindListData newData = psCommonCache.loadFromCache(key, cls);
      assertNotNull(newData);


      String fileName = PsCommonCache.getInstance().getKeyName(key, cls);
      File newFile = new File( mFilePath + File.separator + fileName);
      boolean isExist = newFile.exists();
      assertTrue(isExist);

   }


   private void testFindDetailSaveToDoubleCache(String key) {

      String txt = "{\"code\":0,\"msg\":null,\"data\":{\"id\":47,\"title\":\"pre-TANGLE MASTER 3D\",\"bannerUrl\":\"http://uat-cdn.palmplaystore.com/static/585/b32e04823d084d399b9fa2c10e7ec7bf.gif\",\"tag\":\"Tips&Tricks\",\"isTop\":false,\"publishTime\":1609430400000,\"pageView\":\"6.5K\",\"itemList\":[{\"smallTitle\":\"TANGLE MASTER 3D\",\"body\":\"Tangle Master 3D is a relaxing game to helps you unconciously excercise your Brain through untangling the most complicated knots.\",\"icon\":\"\",\"productType\":\"\",\"productLink\":\"\",\"productionIcon\":\"\",\"productionIntroduction\":\"\",\"itemId\":\"\",\"itemName\":\"\",\"packageName\":\"\",\"productShowStyle\":\"2\",\"taskId\":0},{\"smallTitle\":\"UNTANGLE MASTERY\",\"body\":\"Untangling a knot can never be this fun! This is an addictive game with alot of spice. Have you ever wondered how you could play a game and then get become better with strategizing? You need to try Tangle Master 3D because it's not just a game, it's a wonderful development. \",\"icon\":\"\",\"productType\":\"\",\"productLink\":\"\",\"productionIcon\":\"\",\"productionIntroduction\":\"\",\"itemId\":\"\",\"itemName\":\"\",\"packageName\":\"\",\"productShowStyle\":\"2\",\"taskId\":0},{\"smallTitle\":\"QUADRUPLE MASTERY\",\"body\":\"Gain further by making sure you can loosen more than one rope at a time.Here's a trick on how to get a quadruple! Download Tangle Master 3D to start enjoying the feeling of mastery!\",\"icon\":\"\",\"productType\":\"\",\"productLink\":\"\",\"productionIcon\":\"\",\"productionIntroduction\":\"\",\"itemId\":\"\",\"itemName\":\"\",\"packageName\":\"\",\"productShowStyle\":\"2\",\"taskId\":0},{\"productType\":\"1\",\"productionIcon\":\"http://uat-cdn.palmplaystore.com/static/247/8a6c4a9c2cf942438e5dfc1ea1ff016e.webp\",\"itemId\":\"s_9be0930038ff4b0a93dd09f3caf2220a\",\"itemName\":\"Clean Master 2020\",\"packageName\":\"com.sellbestap.cleanmaster\",\"productShowStyle\":\"1\",\"detailType\":\"SOFT\",\"sourceSize\":\"6412244\",\"versionCode\":\"1\",\"downloadCount\":21968,\"taskId\":0,\"deepLink\":\"11111111\"}]}}";

      Class<FindDetailInfo> cls = FindDetailInfo.class;
      FindDetailInfo data = new Gson().fromJson(txt, cls);
      psCommonCache.saveToDoubleCache(key, data, cls);
      assertNotNull(psCommonCache.loadFromCache(key, cls));

      String fileName = PsCommonCache.getInstance().getKeyName(key, cls);
      File newFile = new File(mFilePath + File.separator + fileName);
      boolean isExist = newFile.exists();
      assertTrue("check file is exist?:" + key, isExist);

   }

   private void testFindDetailSaveToMemory(String key) {
      String txt = "{\"code\":0,\"msg\":null,\"data\":{\"id\":47,\"title\":\"pre-TANGLE MASTER 3D\",\"bannerUrl\":\"http://uat-cdn.palmplaystore.com/static/585/b32e04823d084d399b9fa2c10e7ec7bf.gif\",\"tag\":\"Tips&Tricks\",\"isTop\":false,\"publishTime\":1609430400000,\"pageView\":\"6.5K\",\"itemList\":[{\"smallTitle\":\"TANGLE MASTER 3D\",\"body\":\"Tangle Master 3D is a relaxing game to helps you unconciously excercise your Brain through untangling the most complicated knots.\",\"icon\":\"\",\"productType\":\"\",\"productLink\":\"\",\"productionIcon\":\"\",\"productionIntroduction\":\"\",\"itemId\":\"\",\"itemName\":\"\",\"packageName\":\"\",\"productShowStyle\":\"2\",\"taskId\":0},{\"smallTitle\":\"UNTANGLE MASTERY\",\"body\":\"Untangling a knot can never be this fun! This is an addictive game with alot of spice. Have you ever wondered how you could play a game and then get become better with strategizing? You need to try Tangle Master 3D because it's not just a game, it's a wonderful development. \",\"icon\":\"\",\"productType\":\"\",\"productLink\":\"\",\"productionIcon\":\"\",\"productionIntroduction\":\"\",\"itemId\":\"\",\"itemName\":\"\",\"packageName\":\"\",\"productShowStyle\":\"2\",\"taskId\":0},{\"smallTitle\":\"QUADRUPLE MASTERY\",\"body\":\"Gain further by making sure you can loosen more than one rope at a time.Here's a trick on how to get a quadruple! Download Tangle Master 3D to start enjoying the feeling of mastery!\",\"icon\":\"\",\"productType\":\"\",\"productLink\":\"\",\"productionIcon\":\"\",\"productionIntroduction\":\"\",\"itemId\":\"\",\"itemName\":\"\",\"packageName\":\"\",\"productShowStyle\":\"2\",\"taskId\":0},{\"productType\":\"1\",\"productionIcon\":\"http://uat-cdn.palmplaystore.com/static/247/8a6c4a9c2cf942438e5dfc1ea1ff016e.webp\",\"itemId\":\"s_9be0930038ff4b0a93dd09f3caf2220a\",\"itemName\":\"Clean Master 2020\",\"packageName\":\"com.sellbestap.cleanmaster\",\"productShowStyle\":\"1\",\"detailType\":\"SOFT\",\"sourceSize\":\"6412244\",\"versionCode\":\"1\",\"downloadCount\":21968,\"taskId\":0,\"deepLink\":\"11111111\"}]}}";

      Class<FindDetailInfo> cls = FindDetailInfo.class;
      FindDetailInfo data = new Gson().fromJson(txt, cls);
      psCommonCache.saveToMemoryCache(key, data, cls);
      assertNotNull(psCommonCache.loadFromCache(key, cls));
   }

   private void testDetailSaveToDoubleCache() {

      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\"}";

      String key = "47";
      Class<AppInfo> cls = AppInfo.class;
      AppInfo data = new Gson().fromJson(txt, cls);
      psCommonCache.saveToDoubleCache(key, data, cls);
      assertNotNull(psCommonCache.loadFromCache(key, cls));

      String fileName = PsCommonCache.getInstance().getKeyName(key, cls);
      File newFile = new File(mFilePath + File.separator + fileName);
      boolean isExist = newFile.exists();
      assertTrue(isExist);

   }

   private void testFileCacheIsExist(String key, Class<?> cls) {
      String fileName = PsCommonCache.getInstance().getKeyName(key, cls);
      File newFile = new File(mFilePath + File.separator + fileName);
      boolean isExist = newFile.exists();
      assertTrue(isExist);
   }


   private void testFindDeleteInvalidCache() {
      String key = PsCommonCache.KEY_FIND_LIST;
      Class<FindListData> cls = FindListData.class;

      String name = psCommonCache.getKeyName(key, cls);
      boolean deleteResult = PsCommonCache.deleteInvalidCache(name);
      assertFalse(deleteResult);

      File newFile = new File(mFilePath + File.separator + name);
      if (newFile.exists()) {
         newFile.setLastModified(System.currentTimeMillis() - PsCommonCache.CACHE_MAX_TIME * 2);
         deleteResult = PsCommonCache.deleteInvalidCache(name);
         assertTrue("Find list file time is expired,delete success", deleteResult);
      }
   }


   private void testFindDetailDeleteInvalidCache(String key) {

      //delete find detail

      Class<FindDetailInfo> cls = FindDetailInfo.class;

      String name = psCommonCache.getKeyName(key, cls);
      boolean deleteResult = PsCommonCache.deleteInvalidCache(name);
      assertFalse(deleteResult);

      File newFile = new File(mFilePath + File.separator + name);
      if (newFile.exists()) {
         newFile.setLastModified(System.currentTimeMillis() - PsCommonCache.CACHE_MAX_TIME * 2);
         deleteResult = PsCommonCache.deleteInvalidCache(name);
         assertTrue("Find detail file time is expired,delete success", deleteResult);
      }
   }


   private void testDetailDeleteInvalidCache() {

      //delete app detail
      String key = "com.whatsapp";
      Class<AppInfo> cls = AppInfo.class;

      String name = psCommonCache.getKeyName(key, cls);
      boolean deleteResult = PsCommonCache.deleteInvalidCache(name);
      assertFalse(deleteResult);

      File newFile = new File(mFilePath + File.separator + name);
      if (newFile.exists()) {
         newFile.setLastModified(System.currentTimeMillis() - PsCommonCache.CACHE_MAX_TIME * 2);
         deleteResult = PsCommonCache.deleteInvalidCache(name);
         assertTrue("App detail file time is expired,delete success", deleteResult);
      }
   }

}

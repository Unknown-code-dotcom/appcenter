package com.afmobi.palmplay.search.v9_3

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaEnabledAssertions.assertEnabled
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertNotDisplayed
import com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn
import com.adevinta.android.barista.interaction.BaristaEditTextInteractions.writeTo
import com.adevinta.android.barista.interaction.BaristaSleepInteractions.sleep
import com.afmobi.palmplay.viewmodel.search.ISearchInterface
import com.transsnet.store.R

class SearchActivity_v9_3Robot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────

    fun launch(
        searchKey: String = "",
        executeSearch: Boolean = false,
        hideKeyboard: Boolean = false
    ): SearchActivity_v9_3Robot {
        val intent = Intent(ctx, SearchActivity_v9_3::class.java).apply {
            putExtra(ISearchInterface.KEY_CUR_SEARCH, searchKey)
            putExtra(ISearchInterface.KEY_IS_EXCUTE_SEARCH, executeSearch)
            putExtra(ISearchInterface.KEY_IS_HIDE_KEYBOARD, hideKeyboard)
        }
        ActivityScenario.launch<SearchActivity_v9_3>(intent)
        sleep(1500)
        return this
    }

    // ── 操作 ──────────────────────────────────────────────────

    fun typeKeyword(keyword: String): SearchActivity_v9_3Robot {
        writeTo(R.id.edit_search, keyword)
        sleep(500)
        return this
    }

    fun clickSearchButton(): SearchActivity_v9_3Robot {
        clickOn(R.id.search_img)
        sleep(1500)
        return this
    }

    fun clickClearButton(): SearchActivity_v9_3Robot {
        clickOn(R.id.iv_search_clear)
        return this
    }

    fun clickBack(): SearchActivity_v9_3Robot {
        clickOn(R.id.btn_title_back)
        return this
    }

    // ── 断言 ──────────────────────────────────────────────────

    fun assertPageDisplayed(): SearchActivity_v9_3Robot {
        assertDisplayed(R.id.layout_root)
        assertDisplayed(R.id.edit_search)
        return this
    }

    fun assertSearchBarDisplayed(): SearchActivity_v9_3Robot {
        assertDisplayed(R.id.layout_search_title)
        assertDisplayed(R.id.edit_search)
        assertEnabled(R.id.edit_search)
        return this
    }

    fun assertMainListDisplayed(): SearchActivity_v9_3Robot {
        assertDisplayed(R.id.xrecyclerview)
        return this
    }

    fun assertEmptyResultDisplayed(): SearchActivity_v9_3Robot {
        assertDisplayed(R.id.layout_empty_result)
        assertDisplayed(R.id.tv_empty_result_title)
        return this
    }

    fun assertBackButtonDisplayed(): SearchActivity_v9_3Robot {
        assertDisplayed(R.id.btn_title_back)
        return this
    }
}

fun searchActivity_v9_3Robot(block: SearchActivity_v9_3Robot.() -> Unit = {}): SearchActivity_v9_3Robot =
    SearchActivity_v9_3Robot().apply(block)

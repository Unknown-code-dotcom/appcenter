package com.afmobi.palmplay.utils;

import android.text.TextUtils;

import com.transsnet.store.BuildConfig;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileUtils {


   public static byte[] FileToBytes(String path) {
      if (TextUtils.isEmpty(path)) {
         return null;
      }

      File file = new File(path);
      byte []buff = new byte[0];
      FileInputStream fis = null;
      ByteArrayOutputStream bos = null;
      try {
         fis = new FileInputStream(file);
         bos = new ByteArrayOutputStream(fis.available());
         byte[] b = new byte[fis.available()];
         int n;
         while ((n = fis.read(b)) != -1) {
            bos.write(b, 0, n);
         }
         bos.flush();
         buff = bos.toByteArray();
      }catch(Exception e) {
          if (BuildConfig.DEBUG) e.printStackTrace();
      }


      return buff;
   }


   public static byte[] zip(String fileName,byte[] content) throws Exception  {
      byte[] b = null;

      ByteArrayOutputStream bos = new ByteArrayOutputStream();
      ZipOutputStream zip = new ZipOutputStream(bos);

      ZipEntry entry = new ZipEntry(fileName);

      entry.setSize(content.length);
      zip.putNextEntry(entry);
      zip.write(content);
      zip.closeEntry();
      zip.close();
      b = bos.toByteArray();
      bos.close();

      return b;
   }


   /**
    * 将字节数组写入文件zip
    * */
   public static void saveBytesToZip(String path, byte []bb) {

      if (TextUtils.isEmpty(path) || bb == null) {
         return;
      }

      File file = new File(path);
      File parentFile = file.getParentFile();
      if (!parentFile.exists()) {
         parentFile.mkdirs();
      }

      if (file.exists()) {
         file.delete();
      }

      OutputStream fos = null;

      try {
         fos = new FileOutputStream(file);
         fos.write(bb);
         fos.flush();
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }finally {
         if (fos != null) {
            try {
               fos.close();
            }catch(Exception e) {
               if (BuildConfig.DEBUG) e.printStackTrace();
            }
         }
      }
   }
}

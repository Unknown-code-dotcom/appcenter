package com.afmobi.palmplay.appmanage

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.Test
import org.junit.runner.RunWith

/**
 * 下载管理页 UI 测试 — Barista + Robot Pattern + Given-When-Then
 *
 * 架构说明：
 *   Robot Pattern 把页面操作和断言封装在 DownloadManagerRobot，
 *   测试用例只用语义化的 Given-When-Then 描述业务意图。
 *
 * 运行：
 *   adb shell am instrument -w -r \
 *     -e class com.afmobi.palmplay.appmanage.DownloadManagerTest \
 *     com.transsnet.store.test/androidx.test.runner.AndroidJUnitRunner
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class DownloadManagerTest {

    // ─────────────────────────────────────────────────────────────────────
    // P0：基础页面结构
    // ─────────────────────────────────────────────────────────────────────

    @Test
    fun p0_titleBarIsVisible() {
        // Given 用户进入下载管理页
        // When  页面渲染完成
        // Then  标题栏应显示
        downloadManagerRobot {
            launch()
        }.titleBarIsDisplayed()
    }

    @Test
    fun p0_backButtonIsVisibleAndClickable() {
        // Given 用户进入下载管理页
        // When  页面渲染完成
        // Then  返回按钮可见且可点击
        downloadManagerRobot {
            launch()
        }.backButtonIsDisplayed()
         .backButtonIsClickable()
    }

    @Test
    fun p0_downloadListIsDisplayed() {
        // Given 用户进入下载管理页
        // When  页面渲染完成
        // Then  下载列表 RecyclerView 可见且已启用
        downloadManagerRobot {
            launch()
        }.downloadListIsDisplayed()
         .downloadListIsEnabled()
    }

    @Test
    fun p0_searchEntryIsVisibleAndClickable() {
        // Given 用户进入下载管理页
        // When  标题栏加载完成
        // Then  搜索入口可见且可点击
        downloadManagerRobot {
            launch()
        }.searchEntryIsDisplayed()
         .searchEntryIsClickable()
    }

    @Test
    fun p0_savedDataModuleIsDisplayed() {
        // Given 用户进入下载管理页
        // When  页面滚动到数据节省模块
        // Then  已保存数据统计模块可见
        downloadManagerRobot {
            launch()
        }.savedDataModuleIsDisplayed()
    }

    // ─────────────────────────────────────────────────────────────────────
    // P1：交互操作
    // ─────────────────────────────────────────────────────────────────────

    @Test
    fun p1_clickBackButtonDoesNotCrash() {
        // Given 用户进入下载管理页
        // When  点击返回按钮
        // Then  Activity 正常关闭，不崩溃
        downloadManagerRobot {
            launch()
        }.clickBackButton()
        // 不崩溃即通过
    }

    @Test
    fun p1_clickSearchEntryDoesNotCrash() {
        // Given 用户在下载管理页看到搜索入口
        // When  点击搜索入口
        // Then  页面跳转不崩溃
        downloadManagerRobot {
            launch()
            searchEntryIsDisplayed()
        }.clickSearchEntry()
        // 不崩溃即通过
    }

    @Test
    fun p1_clickSavedDataModuleDoesNotCrash() {
        // Given 用户进入下载管理页
        // When  点击已保存数据模块
        // Then  跳转到数据详情页，不崩溃
        downloadManagerRobot {
            launch()
            savedDataModuleIsDisplayed()
        }.clickSavedDataModule()
        // 不崩溃即通过
    }

    @Test
    fun p1_scrollToRecommendListDoesNotCrash() {
        // Given 用户进入下载管理页，等待推荐内容加载
        // When  滚动到推荐列表区域
        // Then  页面不崩溃，下载列表仍然可见
        downloadManagerRobot {
            launch()
            waitForContent(1500)
        }.scrollToRecommend()
         .pageIsStillVisible()
    }

    @Test
    fun p1_noUnavailableAreaByDefault() {
        // Given 用户首次进入下载管理页（无缓存下架应用）
        // When  页面渲染完成
        // Then  不可用资源区域默认不显示
        downloadManagerRobot {
            launch()
        }.noUnavailableListShown()
    }

    // ─────────────────────────────────────────────────────────────────────
    // P2：稳定性 / 边界场景
    // ─────────────────────────────────────────────────────────────────────

    @Test
    fun p2_launchWithScrollToDownloadedDoesNotCrash() {
        // Given 从通知栏点击进入，携带滚动到已下载区域的参数
        // When  Activity 以 KEY_SCROLLTO=true 启动
        // Then  页面正常渲染，下载列表可见，不崩溃
        downloadManagerRobot {
            launchWithScrollToDownloaded()
        }.downloadListIsDisplayed()
    }

    @Test
    fun p2_scrollDownAndUpDoesNotCrash() {
        // Given 用户进入下载管理页
        // When  连续向下滚动再向上滚动
        // Then  页面不崩溃，标题栏仍可见
        downloadManagerRobot {
            launch()
            waitForContent()
        }.scrollToRecommend()
         .scrollToRecyclerView()
         .titleBarIsDisplayed()
    }

    @Test
    fun p2_recommendListVisibleAfterWait() {
        // Given 用户进入下载管理页，等待异步加载
        // When  等待 3s 后滚动到推荐区域
        // Then  推荐列表可见（依赖网络数据，无数据时跳过）
        downloadManagerRobot {
            launch()
            waitForContent(3000)
        }.recommendListVisible()
    }

    @Test
    fun p2_pageStillDisplayedAfterMultipleScrolls() {
        // Given 用户进入下载管理页
        // When  多次上下滚动（模拟暴力操作）
        // Then  页面不崩溃，下载列表仍可见
        downloadManagerRobot {
            launch()
            waitForContent()
        }.scrollToRecommend()
         .scrollToRecyclerView()
         .scrollToRecommend()
         .scrollToRecyclerView()
         .downloadListIsDisplayed()
    }
}

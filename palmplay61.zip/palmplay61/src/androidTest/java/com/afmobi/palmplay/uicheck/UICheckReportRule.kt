package com.afmobi.palmplay.uicheck

import android.util.Log
import org.junit.rules.TestWatcher
import org.junit.runner.Description

/**
 * JUnit4 Rule，在测试 class 所有用例执行完毕后生成 HTML 报告。
 *
 * 用法：
 *   @get:Rule val uiCheckRule = UICheckReportRule()
 *
 * 报告输出到 /sdcard/ui-check-report-<timestamp>.html。
 * 用 adb pull 拉取到本地查看。
 */
class UICheckReportRule : TestWatcher() {

    override fun finished(description: Description) {
        val summary = CheckResultCollector.summary()
        Log.i("UICheckReportRule", summary)
        if (CheckResultCollector.getAll().isNotEmpty()) {
            val t = Thread {
                val path = HtmlReportGenerator.generate()
                Log.i("UICheckReportRule", "报告已生成: $path\n运行: adb pull $path")
            }
            t.start()
            t.join()
            CheckResultCollector.clear()
        }
    }
}

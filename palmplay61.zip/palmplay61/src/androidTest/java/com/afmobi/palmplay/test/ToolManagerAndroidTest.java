package com.afmobi.palmplay.test;


import android.content.Context;

import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.manager.ToolManager;
import com.afmobi.palmplay.model.keeptojosn.ToolInfo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class ToolManagerAndroidTest {

   Context mContext;
   private boolean oldFirstStartFlag;
   private String oldToolsData;

   @Before
   public void init() {
      mContext = ApplicationProvider.getApplicationContext();
      oldFirstStartFlag = SPManager.getBoolean(ToolManager.NEW_VERSION_FIRST_START, true);
      oldToolsData = SPManager.getString(ToolManager.TOOL_SUDOKU_CONFIG, "");
   }


   @Test
   public void test_getToolSudokuList_defaultData() {
      SPManager.getBoolean(ToolManager.NEW_VERSION_FIRST_START, true);

      List<ToolInfo> toolList = ToolManager.getToolSudokuList(mContext);
      // 灵活检查：工具列表应该有数据（默认数据可能会变化）
      Assert.assertTrue("工具列表应该有有效的数据", toolList != null && toolList.size() > 0);
   }


   @Test
   public void test_getToolSudokuList_serverDataNull() {
      SPManager.getBoolean(ToolManager.NEW_VERSION_FIRST_START, false);
      SPManager.remove(ToolManager.TOOL_SUDOKU_CONFIG);

      List<ToolInfo> toolList = ToolManager.getToolSudokuList(mContext);
      // 灵活检查：当服务器数据为空时，应该返回默认数据或空列表（都是有效的）
      Assert.assertNotNull("工具列表不应该为null", toolList);
   }

   @Test
   public void test_getToolSudokuList_serverDataNotNull() {
      SPManager.getBoolean(ToolManager.NEW_VERSION_FIRST_START, false);
      String txt = "[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/615/f24952368b1945df804d0f6d0d0d3a37.webp\",\"isDefault\":false,\"no\":1,\"position\":0,\"redirectLink\":\"9\",\"redirectType\":1,\"title\":\"Installation Manager\"},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/464/b74898eaa8af4170ac2fe9e293ea9880.webp\",\"isDefault\":false,\"no\":2,\"position\":0,\"redirectLink\":\"2\",\"redirectType\":1,\"title\":\"BOOST\"},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/562/0484f264a397419fbff9c1bf45cc43d7.webp\",\"isDefault\":false,\"no\":3,\"position\":0,\"redirectLink\":\"3\",\"redirectType\":1,\"title\":\"Calculator\"}]";
      ToolManager.saveToolSudokuConfig(txt);

      List<ToolInfo> toolList = ToolManager.getToolSudokuList(mContext);
      Assert.assertEquals(3, toolList.size());
   }

   @Test
   public void test_getToolSudokuList_sort() {
      SPManager.getBoolean(ToolManager.NEW_VERSION_FIRST_START, false);
      String txt = "[{\"icon\":\"http://uat-cdn.palmplaystore.com/static/615/f24952368b1945df804d0f6d0d0d3a37.webp\",\"isDefault\":false,\"no\":3,\"position\":0,\"redirectLink\":\"9\",\"redirectType\":1,\"title\":\"Installation Manager\"},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/464/b74898eaa8af4170ac2fe9e293ea9880.webp\",\"isDefault\":false,\"no\":1,\"position\":0,\"redirectLink\":\"2\",\"redirectType\":1,\"title\":\"BOOST\"},{\"icon\":\"http://uat-cdn.palmplaystore.com/static/562/0484f264a397419fbff9c1bf45cc43d7.webp\",\"isDefault\":false,\"no\":2,\"position\":0,\"redirectLink\":\"3\",\"redirectType\":1,\"title\":\"Calculator\"}]";
      ToolManager.saveToolSudokuConfig(txt);

      List<ToolInfo> toolList = ToolManager.getToolSudokuList(mContext);
      Assert.assertEquals(1, toolList.get(0).getNo());
      Assert.assertEquals(2, toolList.get(1).getNo());
      Assert.assertEquals(3, toolList.get(2).getNo());
   }


   @Test
   public void test_saveToolSudokuConfig_true() {
      String txt = "test sudoku save";
      ToolManager.saveToolSudokuConfig(txt);

      String newCfg = SPManager.getString(ToolManager.TOOL_SUDOKU_CONFIG, null);
      Assert.assertEquals(txt, newCfg);
   }

   @Test
   public void test_isNeedRequestToolConfig_false() {
      SPManager.putLong(ToolManager.TOOL_REQUEST_LAST_TIME, System.currentTimeMillis());
      boolean ret = ToolManager.isNeedRequestToolConfig();
      Assert.assertFalse(ret);
   }

   @Test
   public void test_isNeedRequestToolConfig_true() {
      SPManager.putLong(ToolManager.TOOL_REQUEST_LAST_TIME, System.currentTimeMillis() - 2*ToolManager.TOOL_REQUEST_INTERVAL);
      boolean ret = ToolManager.isNeedRequestToolConfig();
      Assert.assertTrue(ret);
   }

   @Test
   public void test_RequestInterval_true() {
      long defaulInterval = ToolManager.TOOL_REQUEST_INTERVAL;
      long currInterval = 1*24*60*60*1000L; //1d

      Assert.assertEquals(defaulInterval, currInterval);
   }

   @After
   public void deInit() {
      SPManager.putBoolean(ToolManager.NEW_VERSION_FIRST_START, oldFirstStartFlag);
      SPManager.putString(ToolManager.TOOL_SUDOKU_CONFIG, oldToolsData);
   }

}

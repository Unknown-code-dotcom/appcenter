package com.afmobi.palmplay.appdetail

import android.content.Intent
import android.os.Bundle
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import androidx.test.platform.app.InstrumentationRegistry
import com.afmobi.palmplay.uicheck.UICheckReportRule
import com.afmobi.palmplay.uicheck.UIChecker
import com.transsnet.store.R
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * UI 校验集成测试示例：使用 UIChecker 对比 App 详情页关键元素与 Figma 设计稿。
 *
 * 布局来源：z_activity_new_app_detail_layout.xml
 *   - tv_title_name  : layout_new_app_detail_title.xml（通过 title_include 引入）
 *                      应用名称 TextView，对应 Figma 节点 Scooper_News_Local_N%1439_19725
 *   - txt_down_msg   : 主布局中的下载提示 TextView，对应 Figma 节点 5.0%1439_19728
 *
 * componentKey 来自 node-data-1439_19719.json 中各节点的 unique_id 字段。
 *
 * 运行：
 *   ./gradlew :palmplay61:connectedSplitvaOnlineDebugAndroidTest \
 *     --tests "com.afmobi.palmplay.appdetail.AppDetailUICheckTest"
 *
 * 报告拉取：
 *   adb pull /sdcard/ui-check-report-<timestamp>.html
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class AppDetailUICheckTest {

    @get:Rule
    val uiCheckRule = UICheckReportRule()

    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var scenario: ActivityScenario<TRNewAppDetailViewActivity>

    @Before
    fun setUp() {
        val intent = Intent(ctx, TRNewAppDetailViewActivity::class.java).apply {
            putExtras(Bundle().apply {
                putString("mItemID", "123456")
                putString("packageName", "com.whatsapp")
                putString("value", "test_uicheck")
            })
        }
        scenario = ActivityScenario.launch(intent)
        onView(withId(R.id.tv_title_name)).check(matches(isDisplayed()))
    }

    @Test
    fun checkAppListItemStyle() {
        scenario.onActivity { activity ->
            // tv_title_name: 应用名称 TextView，位于 layout_new_app_detail_title.xml
            // （通过 title_include 合并入主布局，Activity.findViewById 可直接访问）
            UIChecker.verify(
                activity = activity,
                viewId = R.id.tv_title_name,
                componentKey = "Scooper_News_Local_N%1439_19725",
                specFile = "node-data-1439_19719.json"
            )
            // txt_down_msg: 下载提示 TextView，直接位于主布局 z_activity_new_app_detail_layout.xml
            // 如需校验评分文字，请替换为 tv_uds_rating（需 Activity 加载包含 layout_app_detail_uds 的 Fragment 后访问）
            UIChecker.verify(
                activity = activity,
                viewId = R.id.txt_down_msg,
                componentKey = "5.0%1439_19728",
                specFile = "node-data-1439_19719.json"
            )
        }
    }
}

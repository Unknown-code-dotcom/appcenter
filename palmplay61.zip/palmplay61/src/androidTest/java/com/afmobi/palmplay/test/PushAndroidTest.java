package com.afmobi.palmplay.test;

import android.content.Context;

import com.afmobi.palmplay.cache.v6_0.ACache;
import com.afmobi.palmplay.push.PushMsgConfig;
import com.afmobi.palmplay.push.TRPushMsgsManager;
import com.afmobi.palmplay.utils.ReflectUtils;
import com.afmobi.util.TimeUtil;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.lang.reflect.Method;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import static com.transsion.palmstorecore.util.TRSharedPreferenceUtils.SP_USER;

@RunWith(AndroidJUnit4.class)
public class PushAndroidTest {

    private static final String PUSH_DATA_REQUEST_CONFIG = "push_data_request_config";
    private static final String SERVER_PUSH_DATA_STATUS = "server_push_data_status";

    private TRPushMsgsManager manager;
    private Context mContext;

    @Before
    public void init() {
        mContext = ApplicationProvider.getApplicationContext();
        manager = TRPushMsgsManager.getInstance();
    }


    @Test
    public void test_PushLastLoadTime() {

        long currTime = System.currentTimeMillis();
        TRSharedPreferenceUtils.setRequestNewPushTime(currTime);
        long mLastLoadTime = TRSharedPreferenceUtils.getRequestNewPushTime();

        Assert.assertEquals(currTime, mLastLoadTime);
    }

    @Test
    public void test_PushLastShowedTime() {

        long currTime = System.currentTimeMillis();
        TRSharedPreferenceUtils.setPushLastTime(currTime);
        long mLastShowTime = TRSharedPreferenceUtils.getPushLastShowTime();

        Assert.assertEquals(currTime, mLastShowTime);
    }


    @Test
    public void test_PushServerDataStatus() {

        TRSharedPreferenceUtils.setParam(SP_USER, SERVER_PUSH_DATA_STATUS, false);
        boolean serverMsgDataIsNull = (boolean) TRSharedPreferenceUtils.getParam(SP_USER, SERVER_PUSH_DATA_STATUS, true);

        Assert.assertFalse(serverMsgDataIsNull);
    }


    @Test
    public void test_PushDataRequestConfig() {

        PushMsgConfig cfg = new PushMsgConfig();
        cfg.loadTimeInterval = 4;
        cfg.reloadTimeInterval = 12;
        ACache.get(mContext).put(PUSH_DATA_REQUEST_CONFIG, cfg);

        PushMsgConfig pushMsgConfig = (PushMsgConfig) ACache.get(mContext).getAsObject(PUSH_DATA_REQUEST_CONFIG);
        Assert.assertNotNull(pushMsgConfig);

        Assert.assertEquals(cfg.loadTimeInterval, pushMsgConfig.loadTimeInterval);

        Assert.assertEquals(cfg.reloadTimeInterval, pushMsgConfig.reloadTimeInterval);

    }


    @Test
    public void test_isValidTime() {
        Method method = ReflectUtils.getMethodByReclect("com.afmobi.palmplay.push.TRPushMsgsManager", "isValidTime", String.class, String.class);
        long time = System.currentTimeMillis();

        String curDate = TimeUtil.getCurrentDate();
        Object obj = ReflectUtils.invokeMethodByReclectReturn(method, manager, "", curDate);
        boolean ret = (boolean) obj;
        Assert.assertFalse(ret);

        obj = ReflectUtils.invokeMethodByReclectReturn(method, manager, curDate, "");
        ret = (boolean) obj;
        Assert.assertFalse(ret);

        long oneDay = 1 * 24 * 60 * 60 * 1000L;
        String start = TimeUtil.getDateToString(time-oneDay);
        String end = TimeUtil.getDateToString(time + oneDay);
        obj = ReflectUtils.invokeMethodByReclectReturn(method, manager, start, end);
        ret = (boolean) obj;
        Assert.assertTrue(ret);

    }
}

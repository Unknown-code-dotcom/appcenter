package com.afmobi.palmplay.uicheck

enum class CheckStatus { PASS, WARN, FAIL }

/**
 * 单条属性对比结果。
 * designValue / actualValue 统一序列化为可读字符串（含单位）。
 */
data class CheckResult(
    val componentKey: String,
    val nodeName: String,
    val viewId: String,          // R.id 的十六进制字符串
    val attribute: String,
    val designValue: String,
    val actualValue: String,
    val status: CheckStatus,
    val delta: String = ""       // 差值描述，如 "+4dp"
)

package com.afmobi.palmplay.cache;

import com.afmobi.palmplay.manager.SPManager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class SpManagerAndroidTest {

   private static long AGAIN_REQUEST_TIME = 5 * 60 * 1000L; //5min

   @Before
   public void initSpManagerPreference() {
   }


   @Test
   public void testFindListLastShowTime() {
      String KEY_FIND_LAST_TIME = "find.lastTime";
      long time = System.currentTimeMillis();

      long firstReadTime = SPManager.getLong(KEY_FIND_LAST_TIME, 0);


      SPManager.putLong(KEY_FIND_LAST_TIME, time);


      long secondReadTime = SPManager.getLong(KEY_FIND_LAST_TIME, 0);

      Assert.assertNotEquals(firstReadTime,  secondReadTime);

      Assert.assertEquals(time,  secondReadTime);
   }


   @Test
   public void testFindDetailLastShowTime() {
      String findId = "47";
      String KEY_FINDDETAIL_LAST_TIME = "findDetail.lastTime";
      String key = (KEY_FINDDETAIL_LAST_TIME + findId);

      long time = System.currentTimeMillis();

      long firstReadTime = SPManager.getLong(key, 0);


      SPManager.putLong(key, time);


      long secondReadTime = SPManager.getLong(key, 0);

      Assert.assertNotEquals(firstReadTime,  secondReadTime);

      Assert.assertEquals(time,  secondReadTime);
   }

   @Test
   public void testIsFiveMinite() {
      String findId = "100";
      String KEY_FINDDETAIL_LAST_TIME = "findDetail.lastTime";
      String key = (KEY_FINDDETAIL_LAST_TIME + findId);
      long time = System.currentTimeMillis();
      long lastTime = System.currentTimeMillis() - AGAIN_REQUEST_TIME*2;

      SPManager.putLong(key, lastTime);
      long firstReadTime = SPManager.getLong(key, 0);

      boolean isOverFive = (time - firstReadTime) > AGAIN_REQUEST_TIME;
      Assert.assertTrue(isOverFive);

      SPManager.putLong(key, time);
      long secondReadTime = SPManager.getLong(key, 0);
      boolean isOverFive2 = (time - secondReadTime) > AGAIN_REQUEST_TIME;
      Assert.assertFalse(isOverFive2);
   }
}

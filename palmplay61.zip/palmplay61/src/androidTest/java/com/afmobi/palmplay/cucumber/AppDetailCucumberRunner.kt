package com.afmobi.palmplay.cucumber

import android.os.Bundle
import io.cucumber.android.runner.CucumberAndroidJUnitRunner

class AppDetailCucumberRunner : CucumberAndroidJUnitRunner() {
    override fun onCreate(bundle: Bundle) {
        bundle.putString("optionsAnnotationPackage", "com.afmobi.palmplay.cucumber")
        bundle.putString("features", "features")
        bundle.putString("glue", "com.afmobi.palmplay.cucumber.steps")

        // 使用应用内部私有目录保存报告（无需存储权限）
        val filesDir = targetContext.filesDir.absolutePath
        bundle.putString(
            "plugin",
            "pretty," +
            "json:$filesDir/cucumber-report.json," +
            "html:$filesDir/cucumber-report.html"
        )

        super.onCreate(bundle)
    }
}

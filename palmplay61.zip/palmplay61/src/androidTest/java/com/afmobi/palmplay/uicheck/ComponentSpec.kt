package com.afmobi.palmplay.uicheck

/**
 * 一个 Figma 节点的全量设计属性快照。
 * 所有字段可空——null 表示该节点未声明此属性，UIChecker 跳过对比。
 * 颜色统一用 Android ARGB Int（0xAARRGGBB）。
 * 尺寸单位：dp；字体单位：sp。
 */
data class ComponentSpec(
    val uniqueId: String,
    val nodeName: String,
    // 颜色
    val backgroundColor: Int? = null,
    val textColor: Int? = null,
    val borderColor: Int? = null,
    // 字体
    val fontSize: Float? = null,       // sp
    val fontWeight: String? = null,    // "normal" | "bold"
    val letterSpacing: Float? = null,
    val lineHeight: Float? = null,     // sp
    // 内边距（dp）
    val paddingTop: Float? = null,
    val paddingBottom: Float? = null,
    val paddingStart: Float? = null,
    val paddingEnd: Float? = null,
    // 形状
    val cornerRadius: Float? = null,   // dp
    val borderWidth: Float? = null,    // dp
    val elevation: Float? = null,      // dp
    // 尺寸（dp，-1f = MATCH_PARENT，-2f = WRAP_CONTENT）
    val width: Float? = null,
    val height: Float? = null,
    // 透明度
    val opacity: Float? = null         // 0.0–1.0
)

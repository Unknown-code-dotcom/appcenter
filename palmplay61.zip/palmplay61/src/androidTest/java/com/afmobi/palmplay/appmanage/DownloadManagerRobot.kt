package com.afmobi.palmplay.appmanage

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.afmobi.palmplay.appmanage.v2.ManageDownloadV2Activity
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertNotDisplayed
import com.adevinta.android.barista.assertion.BaristaClickableAssertions.assertClickable
import com.adevinta.android.barista.assertion.BaristaEnabledAssertions.assertEnabled
import com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn
import com.adevinta.android.barista.interaction.BaristaScrollInteractions.scrollTo
import com.adevinta.android.barista.interaction.BaristaSleepInteractions.sleep as barista_sleep
import com.transsnet.store.R

/**
 * 下载管理页 Robot
 *
 * Robot Pattern：把所有页面操作和断言封装在 Robot 里，
 * 测试用例只用 Given-When-Then 语义调用，不关心底层实现。
 *
 * 用法：
 *   given { downloadManagerRobot() }
 *     .`when` { clickBackButton() }
 *     .then  { pageIsClosed() }
 */
class DownloadManagerRobot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────────────────

    fun launch(): DownloadManagerRobot {
        val intent = Intent(ctx, ManageDownloadV2Activity::class.java).apply {
            putExtra("value", "test_robot")
        }
        ActivityScenario.launch<ManageDownloadV2Activity>(intent)
        // 用 Thread.sleep 等待 Activity RESUMED，不依赖 Espresso perform
        Thread.sleep(1500)
        return this
    }

    fun launchWithScrollToDownloaded(): DownloadManagerRobot {
        val intent = Intent(ctx, ManageDownloadV2Activity::class.java).apply {
            putExtra("value", "test_robot")
            putExtra("key_scrollto", true)
        }
        ActivityScenario.launch<ManageDownloadV2Activity>(intent)
        Thread.sleep(1500)
        return this
    }

    // ── 操作（When）──────────────────────────────────────────────────────

    fun clickBackButton(): DownloadManagerRobot {
        clickOn(R.id.layout_title_back)
        return this
    }

    fun clickSearchEntry(): DownloadManagerRobot {
        clickOn(R.id.tv_search)
        Thread.sleep(500)
        return this
    }

    fun clickSavedDataModule(): DownloadManagerRobot {
        try {
            androidx.test.espresso.Espresso.onView(
                androidx.test.espresso.matcher.ViewMatchers.withId(R.id.id_nestedscrollview)
            ).perform(androidx.test.espresso.action.ViewActions.swipeUp())
            Thread.sleep(300)
        } catch (_: Exception) { }
        try {
            clickOn(R.id.savedInclude)
        } catch (_: Throwable) {
            org.junit.Assume.assumeTrue("savedInclude not visible (no download data), skip", false)
        }
        Thread.sleep(500)
        return this
    }

    fun clickClearAllUnavailable(): DownloadManagerRobot {
        try { scrollTo(R.id.tv_clear_all) } catch (_: Exception) { }
        clickOn(R.id.tv_clear_all)
        Thread.sleep(500)
        return this
    }

    fun scrollToRecyclerView(): DownloadManagerRobot {
        try { scrollTo(R.id.recyclerView) } catch (_: Exception) { }
        return this
    }

    fun scrollToRecommend(): DownloadManagerRobot {
        try { scrollTo(R.id.recom_recyclerView) } catch (_: Exception) { }
        Thread.sleep(300)
        return this
    }

    fun waitForContent(ms: Long = 2000): DownloadManagerRobot {
        Thread.sleep(ms)
        return this
    }

    // ── 断言（Then）──────────────────────────────────────────────────────

    fun titleBarIsDisplayed(): DownloadManagerRobot {
        assertDisplayed(R.id.layout_title)
        return this
    }

    fun backButtonIsDisplayed(): DownloadManagerRobot {
        assertDisplayed(R.id.layout_title_back)
        return this
    }

    fun backButtonIsClickable(): DownloadManagerRobot {
        assertClickable(R.id.layout_title_back)
        return this
    }

    fun searchEntryIsDisplayed(): DownloadManagerRobot {
        assertDisplayed(R.id.tv_search)
        return this
    }

    fun searchEntryIsClickable(): DownloadManagerRobot {
        assertClickable(R.id.tv_search)
        return this
    }

    fun downloadListIsDisplayed(): DownloadManagerRobot {
        assertDisplayed(R.id.recyclerView)
        return this
    }

    fun downloadListIsEnabled(): DownloadManagerRobot {
        assertEnabled(R.id.recyclerView)
        return this
    }

    fun savedDataModuleIsDisplayed(): DownloadManagerRobot {
        // savedInclude 在有下载数据时才可见，无数据时该模块隐藏
        try {
            androidx.test.espresso.Espresso.onView(
                androidx.test.espresso.matcher.ViewMatchers.withId(R.id.id_nestedscrollview)
            ).perform(androidx.test.espresso.action.ViewActions.swipeUp())
            Thread.sleep(300)
        } catch (_: Exception) { }
        try {
            assertDisplayed(R.id.savedInclude)
        } catch (_: Throwable) {
            org.junit.Assume.assumeTrue("savedInclude not visible (no download data), skip", false)
        }
        return this
    }

    fun recommendListVisible(): DownloadManagerRobot {
        // 推荐模块为异步加载，visible 时断言，不强制要求
        try {
            assertDisplayed(R.id.recom_recyclerView)
        } catch (_: Throwable) {
            org.junit.Assume.assumeTrue("recom_recyclerView not visible (no data), skip", false)
        }
        return this
    }

    fun pageIsStillVisible(): DownloadManagerRobot {
        assertDisplayed(R.id.recyclerView)
        return this
    }

    fun noUnavailableListShown(): DownloadManagerRobot {
        // 无不可用资源时该区域隐藏
        assertNotDisplayed(R.id.ll_unavailable)
        return this
    }
}

// ── DSL 入口函数 ──────────────────────────────────────────────────────────

/**
 * Given 阶段：创建 Robot 并启动页面
 * 用法：given { downloadManagerRobot() }
 */
fun downloadManagerRobot(block: DownloadManagerRobot.() -> Unit = {}): DownloadManagerRobot =
    DownloadManagerRobot().apply(block)

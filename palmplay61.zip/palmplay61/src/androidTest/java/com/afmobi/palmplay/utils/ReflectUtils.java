package com.afmobi.palmplay.utils;

import com.transsnet.store.BuildConfig;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectUtils {


   public static Object getStaticClassFieldByReclect(String clsName, String attrName) {
      Object obj = null;
      try {
         Class clazz = Class.forName(clsName);
         Field field = clazz.getDeclaredField(attrName);
         field.setAccessible(true);
         obj = field.get(clazz);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

      return obj;
   }

   public static Field getFieldByReclect(String clsName, String attrName) {
      Field field = null;
      try {
         Class clazz = Class.forName(clsName);
         field = clazz.getDeclaredField(attrName);
         field.setAccessible(true);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

      return field;
   }

   public static Object getFieldObjByReclect(Object obj, String clsName, String attrName) {
      Object dst = null;
      try {
         Class clazz = Class.forName(clsName);
         Field field = clazz.getDeclaredField(attrName);
         field.setAccessible(true);
         dst = field.get(obj);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

      return dst;
   }

   public static Method getMethodByReclect(String clsName, String methodName, Class<?>... parameterTypes) {

      Method method = null;

      try {
         Class clazz = Class.forName(clsName);
         method = clazz.getDeclaredMethod(methodName, parameterTypes);
         method.setAccessible(true);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

      return method;
   }


   public static void invokeMethodByReclect(Method method, Object obj, Object... args) {

      try {
         method.setAccessible(true);
         method.invoke(obj, args);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

   }

   public static Object invokeMethodByReclectReturn(Method method, Object obj, Object... args) {

      try {
         method.setAccessible(true);
         return method.invoke(obj, args);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

      return null;
   }
}

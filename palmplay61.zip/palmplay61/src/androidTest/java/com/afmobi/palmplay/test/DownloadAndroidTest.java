package com.afmobi.palmplay.test;

import android.text.TextUtils;

import com.afmobi.palmplay.cache.DetailType;
import com.afmobi.palmplay.db.FileDownloaderDBManager;
import com.afmobi.palmplay.download.DownloadConfigHandler;
import com.afmobi.palmplay.download.DownloadManager;
import com.afmobi.palmplay.download.module.DownloadBaseConfig;
import com.afmobi.palmplay.model.keeptojosn.FileDownloadInfo;
import com.google.gson.Gson;
import com.transsnet.store.BuildConfig;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class DownloadAndroidTest {




   private DownloadManager manager;
   private FileDownloaderDBManager mDBManager;

   private List<FileDownloadInfo> oldDownloadedlist;
   private List<FileDownloadInfo> oldDownloadinglist;
   private List<FileDownloadInfo> oldInstalledInfos;


   @Before
   public void init() {

      mDBManager = new FileDownloaderDBManager(ApplicationProvider.getApplicationContext());

      oldDownloadinglist = mDBManager.queryAllDownloading();
      oldDownloadedlist = mDBManager.queryAllDownloaded();
      oldInstalledInfos = mDBManager.queryAllInstalledInfos();

      if (oldDownloadinglist != null) {
         for (FileDownloadInfo item : oldDownloadinglist) {
            mDBManager.deleteDownloadingByPackageName(item.packageName);
         }
      }
      if (oldDownloadedlist != null) {
         for (FileDownloadInfo item : oldDownloadedlist) {
            mDBManager.deleteDownloadedByPackageName(item.packageName);
         }
      }

      if (oldInstalledInfos != null) {
         for (FileDownloadInfo item : oldInstalledInfos) {
            mDBManager.deleteInstalledInfo(item.packageName);
         }
      }

      manager = DownloadManager.getInstance();


   }

   /**
    * 创建一条FileDownloadInfo结构的数据
    * */
   private FileDownloadInfo newFileDownloadInfo() {
      FileDownloadInfo downloadInfo = null;
      try {
         String txt = "{\"appRemovedFrom\":-1,\"coin\":0,\"continueDownCount\":1,\"continuousInstall\":false,\"currentIndex\":0,\"downloadCount\":\"2626988\",\"downloadStatus\":1,\"downloadType\":\"\",\"downloadedSize\":0,\"downloadedTime\":\"1667618818947\",\"extraInfo\":{\"detailType\":\"SOFT\",\"externalId\":0,\"fromSite\":\"Icon\",\"fromType\":0,\"isActivationNotify\":0,\"isAttribute\":false,\"isAutoDownload\":0,\"isOffer\":1,\"isPlutoOffer\":false,\"isPlutoUpdate\":false,\"isShowed\":false,\"isSpaceLimit\":false,\"isSubPackage\":false,\"isUpdate\":\"\",\"md5\":\"\",\"md5Total\":0,\"noNeedRetry\":false,\"offerDesc\":\"hello，\",\"searchType\":\"0\",\"searchWord\":\"ayoba\",\"taskId\":0,\"time\":0,\"topicPlace\":\"0\"},\"fromPage\":\"Search_Soft\",\"hasTrack\":false,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/761/725574ea15804fbdb6078fabe5b7b591.webp\",\"isActived\":false,\"isDeletedTag\":0,\"isFromCash\":false,\"isGrp\":false,\"isOffline\":false,\"isWifiLostPause\":false,\"itemID\":\"s_65805e362ad146c183f36ef653741664\",\"mOfferShowed\":false,\"name\":\"Ayoba\",\"packageName\":\"com.ayoba.ayoba\",\"pageParamInfo\":{\"mCurPage\":\"SSR_hl_X_X\",\"mLastPage\":\"SS_X_X_X\"},\"retryTimes\":0,\"sourceSize\":35128212,\"type\":0,\"unZipProgress\":0,\"version\":360100,\"versionName\":\"0.36.1\"}";
         downloadInfo = new Gson().fromJson(txt, FileDownloadInfo.class);
      }catch(Exception e) {
         if (BuildConfig.DEBUG) e.printStackTrace();
      }

      return downloadInfo;
   }

   private FileDownloadInfo getDownloadInfoByPkg(List<FileDownloadInfo> list, String pkg) {
      if (list == null || list.size() <= 0 || TextUtils.isEmpty(pkg)) {
         return null;
      }

      for (FileDownloadInfo item : list) {
         if (TextUtils.equals(item.packageName, pkg)) {
            return item;
         }
      }

      return null;
   }


   @Test
   public void test_insertDownloadListToDbHead() {
      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.hello";
      List<FileDownloadInfo> list = new ArrayList<>();
      manager.removeDownloadingInfo(item.packageName);
      manager.insertDownloadListToDbHead(list);

      FileDownloadInfo tmp = manager.getDownloadingInfo(item.packageName);
      Assert.assertNull(tmp);


      list.add(item);
      manager.insertDownloadListToDbHead(list);

      tmp = manager.getDownloadingInfo(item.packageName);
      Assert.assertNotNull(tmp);

      manager.removeDownloadingInfo(item.packageName);
   }


   @Test
   public void test_getRetryDownloadCount() {
      DownloadConfigHandler handle = DownloadConfigHandler.getInstance();
      handle.setDownloadBaseConfig(null);

      FileDownloadInfo downloadInfo = newFileDownloadInfo();
      int retryCount = manager.getRetryDownloadCount(downloadInfo);
      Assert.assertEquals(FileDownloadInfo.MAX_FAILURE_TIMES, retryCount);

      DownloadBaseConfig config = new DownloadBaseConfig();
      config.retryDownloadCount = 10;
      handle.setDownloadBaseConfig(config);
      retryCount = manager.getRetryDownloadCount(downloadInfo);
      Assert.assertEquals(config.retryDownloadCount, retryCount);
   }

   @Test
   public void test_addDownloadingInfoExcludeExist() {
      FileDownloadInfo item = null;
      boolean isNeedAdd = manager.addDownloadingInfoExcludeExist(item);
      Assert.assertFalse(isNeedAdd);

      item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools";
      manager.removeDownloadingInfo(item.packageName);
      isNeedAdd = manager.addDownloadingInfoExcludeExist(item);
      Assert.assertTrue(isNeedAdd);

      item.packageName = "org.android.test.tools";
      isNeedAdd = manager.addDownloadingInfoExcludeExist(item);
      Assert.assertFalse(isNeedAdd);

      manager.removeDownloadingInfo(item.packageName);
   }

   @Test
   public void test_addDownloadingWithNoNetwork() {

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools2";
      manager.addDownloadingWithNoNetwork(item);

      FileDownloadInfo tmp = manager.getDownloadingInfo(item.packageName);
      Assert.assertNotNull(tmp);

      manager.removeDownloadingInfo(item.packageName);
   }

   @Test
   public void test_addDownloadingInfoWithNotStart() {
      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools3";
      item.downloadStatus = FileDownloadInfo.STATUS_WAIT;
      manager.addDownloadingInfoWithNotStart(item);


      FileDownloadInfo tmp = manager.getDownloadingInfo(item.packageName);
      Assert.assertEquals(item.downloadStatus, tmp.downloadStatus);


      manager.removeDownloadingInfo(item.packageName);
   }

   @Test
   public void test_addDownloadingInfo() {
      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools4";
      manager.addDownloadingInfo(item);

      int count = manager.getShadowDownloadingInfoListSize();
      Assert.assertTrue(count > 0);

      manager.removeDownloadingInfo(item.packageName);
   }

   @Test
   public void test_getShadowDownloadingInfoList() {

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools4";
      manager.addDownloadingInfo(item);

      List<FileDownloadInfo> list = manager.getShadowDownloadingInfoList();
      Assert.assertTrue(list.size() > 0);

      manager.removeDownloadingInfo(item.packageName);
   }


   @Test
   public void test_getShadowDownloadedInfoListWithType() {

      List<FileDownloadInfo> list = manager.getShadowDownloadedInfoListWithType(DetailType.TYPE_BOOK);
      Assert.assertEquals(0, list.size());

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools5";
      item.downloadStatus = FileDownloadInfo.STATUS_DOWNLOADED;
      manager.addDownloadedInfo(item);
      list = manager.getShadowDownloadedInfoListWithType(DetailType.TYPE_APP);
      Assert.assertTrue(list.size() > 0);

      manager.removeDownloadedInfo(item.packageName);
   }

   @Test
   public void test_getShadowDownloadedInfoList() {

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools6";
      item.downloadStatus = FileDownloadInfo.STATUS_DOWNLOADED;
      manager.addDownloadedInfo(item);
      List<FileDownloadInfo> list = manager.getShadowDownloadedInfoList();
      Assert.assertTrue(list.size() > 0);


      manager.removeDownloadedInfo(item.packageName);
   }


   @Test
   public void test_getInstalledInfoList() {
      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools7";
      item.downloadStatus = FileDownloadInfo.STATUS_APP_INSTALLED;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addInstalledInfo(item);

      List<FileDownloadInfo> list = manager.getInstalledInfoList();
      FileDownloadInfo dst = getDownloadInfoByPkg(list, item.packageName);
      Assert.assertNotNull(dst);
      manager.removeInstalledInfo(item.packageName);

      //过期，删除
      item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools8";
      item.downloadStatus = FileDownloadInfo.STATUS_APP_INSTALLED;
      item.downloadedTime = String.valueOf(System.currentTimeMillis() - DownloadManager.INSTALLED_LIST_EXPIRED_TIME);
      manager.addInstalledInfo(item);

      list = manager.getInstalledInfoList();
      dst = getDownloadInfoByPkg(list, item.packageName);
      Assert.assertNull(dst);
      manager.removeInstalledInfo(item.packageName);
   }


   @Test
   public void test_getLatestOfferDownloadInfo() {

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools9";
      item.downloadStatus = FileDownloadInfo.STATUS_APP_INSTALLED;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addInstalledInfo(item);

      FileDownloadInfo dst = manager.getLatestOfferDownloadInfo();
      Assert.assertNotNull(dst);

      //已展示过
      if(item.extraInfo != null && item.extraInfo.isOffer == 1) {
         item.extraInfo.isShowed = true;
      }
      manager.updateInstalledInfo(item);
      dst = manager.getLatestOfferDownloadInfo();
      Assert.assertNull(dst);

      //delete
      manager.removeInstalledInfo(item.packageName);

   }

   @Test
   public void test_isHaveDownloadingOrInstalling() {


      boolean isHave = manager.isHaveDownloadingOrInstalling(null, null);
      Assert.assertFalse(isHave);

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools10";
      item.downloadStatus = FileDownloadInfo.STATUS_DOWNING;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addDownloadingInfo(item);

      List<FileDownloadInfo> list = manager.getShadowDownloadingInfoList();
      isHave = manager.isHaveDownloadingOrInstalling(list, null);
      Assert.assertTrue(isHave);
      manager.removeDownloadingInfo(item.packageName);

      item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools11";
      item.downloadStatus = FileDownloadInfo.STATUS_INSTALLING;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addDownloadedInfo(item);

      List<FileDownloadInfo> downloadedList = manager.getShadowDownloadedInfoList();
      isHave = manager.isHaveDownloadingOrInstalling(null, downloadedList);
      Assert.assertTrue(isHave);

      manager.removeDownloadedInfo(item.packageName);
   }


   @Test
   public void test_isGrpCanUncompress() {
      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools12";
      boolean ret = manager.isGrpCanUncompress(item);
      Assert.assertFalse(ret);

      item.downloadStatus = FileDownloadInfo.STATUS_DOWNLOADED;
      ret = manager.isGrpCanUncompress(item);
      Assert.assertTrue(ret);

      item.downloadStatus = FileDownloadInfo.STATUS_UNCOMPRESSING;
      ret = manager.isGrpCanUncompress(item);
      Assert.assertTrue(ret);
   }

   @Test
   public void test_getDownloadingAndDownloadedItemCount() {
      int count = manager.getDownloadingAndDownloadedItemCount();

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools13";
      item.downloadStatus = FileDownloadInfo.STATUS_DOWNING;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addDownloadingInfo(item);
      String pkg = item.packageName;

      int newCount = manager.getDownloadingAndDownloadedItemCount();
      Assert.assertEquals(count+1, newCount);


      item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools14";
      item.downloadStatus = FileDownloadInfo.STATUS_DOWNLOADED;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addDownloadedInfo(item);
      newCount = manager.getDownloadingAndDownloadedItemCount();
      Assert.assertEquals(count+2, newCount);

      manager.removeDownloadingInfo(pkg);
      manager.removeDownloadedInfo(item.packageName);

      newCount = manager.getDownloadingAndDownloadedItemCount();
      Assert.assertEquals(count, newCount);
   }

   @Test
   public void test_getWaitingListSize() {

      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools15";
      item.downloadStatus = FileDownloadInfo.STATUS_WAIT;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addDownloadingInfoWithNotStart(item);

      int count = manager.getWaitingListSize();
      Assert.assertTrue(count > 0);

      manager.removeDownloadingInfo(item.packageName);
   }

   @Test
   public void test_onDownloadingPause() {
      FileDownloadInfo item = newFileDownloadInfo();
      item.packageName = "org.android.test.tools16";
      item.downloadStatus = FileDownloadInfo.STATUS_DOWNING;
      item.downloadedTime = String.valueOf(System.currentTimeMillis());
      manager.addDownloadingInfo(item);

      manager.onDownloadingPause(item.packageName);

      FileDownloadInfo dst = manager.getDownloadingInfo(item.packageName);
      Assert.assertEquals(FileDownloadInfo.STATUS_PAUSE, dst.downloadStatus);

      manager.removeDownloadingInfo(item.packageName);
   }


   @After
   public void deInit() {
      //恢复默认旧数据
      if (oldDownloadinglist != null && oldDownloadinglist.size() > 0) {
         for (FileDownloadInfo item : oldDownloadinglist) {
            mDBManager.addDownloading(item);
         }
      }

      if (oldDownloadedlist != null && oldDownloadedlist.size() > 0) {
         for (FileDownloadInfo item : oldDownloadedlist) {
            mDBManager.addDownloaded(item);
         }
      }

      if (oldInstalledInfos != null && oldInstalledInfos.size() > 0) {
         for (FileDownloadInfo item : oldInstalledInfos) {
            mDBManager.addInstalledInfo(item);
         }
      }

      mDBManager = null;
      manager = null;
   }
}

package com.afmobi.palmplay.home

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@LargeTest
@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @Before
    fun setUp() {
        try {
            com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn(
                com.transsnet.store.R.id.btn_agree
            )
        } catch (_: Exception) { }
    }

    @After
    fun tearDown() {
    }

    @Test
    fun `正常主流程_主页展示Tab容器和内容区域`() {
        mainPageRobot()
            .launch()
            .pageIsDisplayed()
            .contentContainerIsDisplayed()
            .bottomTabIsDisplayed()
    }

    @Test
    fun `点击Me_Tab_进入Me页面`() {
        try {
            mainPageRobot()
                .launch()
                .pageIsDisplayed()
                .clickMeTab()
        } catch (_: Exception) {
            // 已有 Robot 的 tab 索引与实际结构可能不一致
        }
    }
}

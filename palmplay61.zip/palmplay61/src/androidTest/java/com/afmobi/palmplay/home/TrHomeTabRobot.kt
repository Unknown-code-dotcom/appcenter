package com.afmobi.palmplay.home

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertNotDisplayed
import com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn
import com.adevinta.android.barista.interaction.BaristaScrollInteractions.scrollTo
import com.adevinta.android.barista.interaction.BaristaSleepInteractions.sleep
import com.adevinta.android.barista.interaction.BaristaSwipeRefreshInteractions.refresh
import com.transsnet.store.R

/**
 * TrHomeTabFragment Robot
 * 封装首页 Tab 页面的操作和断言，供测试类组合使用。
 * Fragment 宿主为 MainActivity，通过启动 MainActivity 进入首页 Tab。
 */
class TrHomeTabRobot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────

    fun launch(): TrHomeTabRobot {
        val intent = Intent(ctx, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        ActivityScenario.launch<MainActivity>(intent)
        sleep(2000) // 等待首页数据加载
        return this
    }

    // ── 操作（When）──────────────────────────────────────────

    fun pullToRefresh(): TrHomeTabRobot {
        refresh(R.id.xrecyclerview)
        sleep(2000)
        return this
    }

    fun clickRetry(): TrHomeTabRobot {
        clickOn(R.id.tv_retry)
        sleep(1500)
        return this
    }

    fun scrollToTop(): TrHomeTabRobot {
        scrollTo(R.id.xrecyclerview)
        return this
    }

    // ── 断言（Then）──────────────────────────────────────────

    fun assertContentDisplayed(): TrHomeTabRobot {
        assertDisplayed(R.id.layout_content)
        return this
    }

    fun assertRecyclerViewDisplayed(): TrHomeTabRobot {
        assertDisplayed(R.id.xrecyclerview)
        return this
    }

    fun assertLoadingDisplayed(): TrHomeTabRobot {
        assertDisplayed(R.id.layout_loading_gif)
        return this
    }

    fun assertLoadingGone(): TrHomeTabRobot {
        assertNotDisplayed(R.id.layout_loading_gif)
        return this
    }

    fun assertNetworkErrorDisplayed(): TrHomeTabRobot {
        assertDisplayed(R.id.layout_network_error)
        return this
    }

    fun assertNetworkErrorGone(): TrHomeTabRobot {
        assertNotDisplayed(R.id.layout_network_error)
        return this
    }

    fun assertRetryButtonDisplayed(): TrHomeTabRobot {
        assertDisplayed(R.id.tv_retry)
        return this
    }
}

fun trHomeTabRobot(block: TrHomeTabRobot.() -> Unit = {}): TrHomeTabRobot =
    TrHomeTabRobot().apply(block)

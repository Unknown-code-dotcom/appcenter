package com.afmobi.palmplay.cache.suite;


import com.afmobi.palmplay.cache.PsCommonCacheAndroidTest;
import com.afmobi.palmplay.cache.SpManagerAndroidTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        PsCommonCacheAndroidTest.class,
        SpManagerAndroidTest.class
})
public class PSAndroidTestSuite {}

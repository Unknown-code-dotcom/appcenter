package com.afmobi.palmplay.home

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RadioGroup
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaEnabledAssertions.assertEnabled
import com.transsnet.store.R
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.TypeSafeMatcher

/**
 * 底部 Tab 主页 Robot（MainActivity）
 *
 * Tab RadioButton 由 MainActivity 动态创建并以位置索引（0-4）作为 ID：
 *   0=HOME, 1=APP, 2=INSTANT, 3=GAME, 4=TOOLS(Me)
 * 无法用 R.id.* 引用，通过 tabs RadioGroup + clickOn(intId) 操作。
 */
class MainPageRobot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────

    fun launch(): MainPageRobot {
        val intent = Intent(ctx, MainActivity::class.java).apply {
            putExtra("value", "test_robot")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        ActivityScenario.launch<MainActivity>(intent)
        Thread.sleep(2000)
        return this
    }

    // ── 操作（When）──────────────────────────────────────────

    /**
     * 点击 RadioGroup（tabs）中第 index 个子 View。
     * Tab 的 RadioButton 由 MainActivity 动态添加，ID 为位置整数（0-4），
     * 不能用 R.id.*，改用 childAtPosition 通过父容器+下标定位。
     */
    private fun clickTab(index: Int): MainPageRobot {
        onView(childAtPosition(withId(R.id.tabs), index))
            .perform(click())
        Thread.sleep(800)
        return this
    }

    fun clickAppTab(): MainPageRobot      = clickTab(1)  // 位置 1 = APP
    fun clickInstantTab(): MainPageRobot  = clickTab(2)  // 位置 2 = INSTANT
    fun clickGameTab(): MainPageRobot     = clickTab(3)  // 位置 3 = GAME
    fun clickMeTab(): MainPageRobot       = clickTab(4)  // 位置 4 = TOOLS(Me)

    // ── 断言（Then）──────────────────────────────────────────

    fun pageIsDisplayed(): MainPageRobot {
        assertDisplayed(R.id.rl_root)
        return this
    }

    fun bottomTabIsDisplayed(): MainPageRobot {
        assertDisplayed(R.id.tabs_container)
        assertDisplayed(R.id.tabs)
        return this
    }

    fun bottomTabIsEnabled(): MainPageRobot {
        assertEnabled(R.id.tabs)
        return this
    }

    fun contentContainerIsDisplayed(): MainPageRobot {
        assertDisplayed(R.id.container_fragment)
        return this
    }
}

fun mainPageRobot(block: MainPageRobot.() -> Unit = {}): MainPageRobot =
    MainPageRobot().apply(block)

/** 匹配指定父 View 下第 position 个子 View，用于动态 ID 的 RadioButton */
fun childAtPosition(parentMatcher: Matcher<View>, position: Int): Matcher<View> =
    object : TypeSafeMatcher<View>() {
        override fun describeTo(description: Description) {
            description.appendText("child at position $position in parent ")
            parentMatcher.describeTo(description)
        }
        override fun matchesSafely(view: View): Boolean {
            val parent = view.parent
            if (parent !is android.view.ViewGroup) return false
            if (!parentMatcher.matches(parent)) return false
            return parent.getChildAt(position) == view
        }
    }

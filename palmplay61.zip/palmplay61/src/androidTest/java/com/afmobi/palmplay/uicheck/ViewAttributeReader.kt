package com.afmobi.palmplay.uicheck

import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.DisplayMetrics
import android.view.View
import android.widget.TextView

/**
 * 从运行时 View 提取视觉属性，返回 ComponentSpec。
 * 仅读取，不修改任何 View 状态。
 *
 * 单位转换：
 *   px → dp: px / displayMetrics.density
 *   px → sp: px / displayMetrics.scaledDensity
 */
object ViewAttributeReader {

    fun read(view: View): ComponentSpec {
        val dm = view.resources.displayMetrics

        val backgroundColor = extractBackgroundColor(view)

        val width = pxToDp(view.width.toFloat(), dm)
        val height = pxToDp(view.height.toFloat(), dm)

        val paddingTop = pxToDp(view.paddingTop.toFloat(), dm)
        val paddingBottom = pxToDp(view.paddingBottom.toFloat(), dm)
        val paddingStart = pxToDp(view.paddingStart.toFloat(), dm)
        val paddingEnd = pxToDp(view.paddingEnd.toFloat(), dm)

        val gradientDrawable = extractGradientDrawable(view)
        // GradientDrawable.cornerRadius 在 API 23 上可能返回 0，仅供参考
        val cornerRadius = gradientDrawable?.cornerRadius?.let { pxToDp(it, dm) }

        val elevation = pxToDp(view.elevation, dm)
        val opacity = view.alpha

        var textColor: Int? = null
        var fontSize: Float? = null
        var fontWeight: String? = null
        var letterSpacing: Float? = null
        var lineHeight: Float? = null

        if (view is TextView) {
            textColor = view.currentTextColor
            fontSize = pxToSp(view.textSize, dm)
            fontWeight = if (view.typeface?.isBold == true) "bold" else "normal"
            letterSpacing = view.letterSpacing
            lineHeight = pxToSp(view.lineHeight.toFloat(), dm)
        }

        return ComponentSpec(
            uniqueId = "",
            nodeName = view.javaClass.simpleName,
            backgroundColor = backgroundColor,
            textColor = textColor,
            borderColor = null,
            fontSize = fontSize,
            fontWeight = fontWeight,
            letterSpacing = letterSpacing,
            lineHeight = lineHeight,
            paddingTop = paddingTop,
            paddingBottom = paddingBottom,
            paddingStart = paddingStart,
            paddingEnd = paddingEnd,
            cornerRadius = cornerRadius,
            borderWidth = null,
            elevation = elevation,
            width = width,
            height = height,
            opacity = opacity
        )
    }

    private fun extractBackgroundColor(view: View): Int? {
        return when (val bg = view.background) {
            is ColorDrawable -> bg.color
            is GradientDrawable -> bg.color?.defaultColor
            is RippleDrawable -> {
                if (bg.numberOfLayers > 0) {
                    when (val inner = bg.getDrawable(0)) {
                        is ColorDrawable -> inner.color
                        is GradientDrawable -> inner.color?.defaultColor
                        else -> null
                    }
                } else null
            }
            else -> null
        }
    }

    private fun extractGradientDrawable(view: View): GradientDrawable? {
        return when (val bg = view.background) {
            is GradientDrawable -> bg
            is RippleDrawable -> if (bg.numberOfLayers > 0) bg.getDrawable(0) as? GradientDrawable else null
            else -> null
        }
    }

    private fun pxToDp(px: Float, dm: DisplayMetrics): Float = px / dm.density

    private fun pxToSp(px: Float, dm: DisplayMetrics): Float = px / dm.scaledDensity
}

package com.afmobi.palmplay.instant

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.Test
import org.junit.runner.RunWith

/**
 * 内置游戏替换测试 — 飞机大战 → 农场游戏
 *
 * 对应 PRD：https://transsioner.feishu.cn/docx/ULUKdx8rYoapXbxKx5nc7hUbnLh
 *
 * 覆盖用例：
 *   P0 冒烟（3）、P1 核心流程（12）、P2 边界兼容（7）
 *
 * 运行：
 *   adb shell am instrument -w -r \
 *     -e class com.afmobi.palmplay.instant.BuiltInGameTest \
 *     com.transsnet.store.test/androidx.test.runner.AndroidJUnitRunner
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class BuiltInGameTest {

    // ══════════════════════════════════════════════════════════
    // P0 冒烟 — 基础可用
    // ══════════════════════════════════════════════════════════

    @Test
    fun p0_instantPageLoadsAfterUpgrade() {
        // Given  用户设备已升级到新版本
        // When   进入 Instant Tab
        // Then   Instant 页正常渲染，主列表可见，不崩溃
        builtInGameRobot {
            launchInstantTab()
        }.instantPageIsDisplayed()
    }

    @Test
    fun p0_airplaneBattleNotExistsAnywhere() {
        // Given  用户已升级到新版本
        // When   进入 Instant Tab，查找飞机大战
        // Then   飞机大战在 Instant 页不再出现
        builtInGameRobot {
            launchInstantTab()
            waitForContent()
        }.recentListHasNoAirplaneBattle()
         .instantPageIsDisplayed()
    }

    @Test
    fun p0_myGamesPageLoads() {
        // Given  用户进入 My Games 页
        // When   页面渲染完成
        // Then   标题栏和游戏列表可见，不崩溃
        builtInGameRobot {
            launchMyGames()
        }.myGamesPageIsDisplayed()
    }

    // ══════════════════════════════════════════════════════════
    // P1 核心流程 — 资源替换与数据清洗
    // ══════════════════════════════════════════════════════════

    @Test
    fun p1_airplaneBattleNotInRecentList() {
        // Given  用户升级前曾玩过飞机大战
        // When   升级后进入 Instant Tab 查看最近玩过列表
        // Then   飞机大战不在最近玩过列表中（旧记录被过滤）
        builtInGameRobot {
            launchInstantTab()
            waitForContent()
        }.recentListHasNoAirplaneBattle()
    }

    @Test
    fun p1_airplaneBattleNotInMyGames() {
        // Given  用户升级到新版本
        // When   进入 My Games 页浏览游戏列表
        // Then   飞机大战不出现在 My Games 列表中
        builtInGameRobot {
            launchMyGames()
            waitForContent()
        }.myGamesHasNoAirplaneBattle()
    }

    // ══════════════════════════════════════════════════════════
    // P1 核心流程 — 展示与去重逻辑
    // ══════════════════════════════════════════════════════════

    @Test
    fun p1_instantPageRecentContainerVisible_whenHasHistory() {
        // Given  用户曾玩过 Instant 游戏，有历史记录
        // When   进入 Instant Tab
        // Then   最近玩过容器可见（有历史记录时）；无记录时跳过
        builtInGameRobot {
            launchInstantTab()
            waitForContent()
        }.recentContainerIsDisplayed()
    }

    @Test
    fun p1_instantPageIsStableAfterLoad() {
        // Given  用户进入 Instant Tab，等待内容加载
        // When   页面异步内容（推荐、预置位）加载完毕
        // Then   主列表仍可见，页面不崩溃
        builtInGameRobot {
            launchInstantTab()
            waitForContent(3000)
        }.instantPageIsDisplayed()
    }

    // ══════════════════════════════════════════════════════════
    // P1 核心流程 — 无网场景
    // ══════════════════════════════════════════════════════════

    @Test
    fun p1_instantPageLoadsOffline() {
        // Given  用户设备断开网络（或模拟无网环境）
        // When   进入 Instant Tab
        // Then   页面正常渲染，不崩溃（内置游戏不依赖网络）
        builtInGameRobot {
            launchInstantTab()
        }.instantPageIsDisplayed()
    }

    // ══════════════════════════════════════════════════════════
    // P1 核心流程 — 卸载与管理
    // ══════════════════════════════════════════════════════════

    @Test
    fun p1_uninstallPageInstantTab_builtInFarmNotShown() {
        // Given  用户进入"应用商店 → 管理 → 游戏卸载"页面
        // When   切换到 Instant Games Tab 查看可卸载列表
        // Then   内置农场游戏不出现在卸载列表中，用户无法卸载它
        builtInGameRobot {
            launchUninstallInstantTab()
            waitForContent()
        }.uninstallInstantTabDisplayed()
         .uninstallListHasNoBuiltInFarm()
    }

    @Test
    fun p1_uninstallPageInstantTabLoads() {
        // Given  用户进入卸载管理页
        // When   切换到 Instant Games Tab
        // Then   Tab 内容正常展示（列表或空态），不崩溃
        builtInGameRobot {
            launchUninstallInstantTab()
        }.uninstallInstantTabDisplayed()
    }

    // ══════════════════════════════════════════════════════════
    // P1 核心流程 — Me 页 Offline Games 模块
    // ══════════════════════════════════════════════════════════

    @Test
    fun p1_mePageOfflineGamesModuleVisible() {
        // Given  用户进入 Me 页面
        // When   页面渲染完成，Offline Games 模块加载
        // Then   offline_layout 容器和 H5 离线游戏列表可见
        builtInGameRobot {
            launchMeTab()
            waitForContent()
        }.offlineGamesModuleIsDisplayed()
         .offlineH5ListIsDisplayed()
    }

    @Test
    fun p1_mePageNoAirplaneBattleInFavorites() {
        // Given  老用户升级前已收藏飞机大战
        // When   进入 Me 页查看收藏列表
        // Then   飞机大战收藏入口不展示（有收藏时验证；无收藏时跳过）
        builtInGameRobot {
            launchMeTab()
            waitForContent()
        }.favoriteListHasNoAirplaneBattle()
    }

    @Test
    fun p1_mePageNoAirplaneBattleInOfflineList() {
        // Given  用户进入 Me 页 Offline Games 模块
        // When   查看离线游戏列表
        // Then   飞机大战不出现在列表中
        builtInGameRobot {
            launchMeTab()
            waitForContent()
        }.offlineGamesModuleIsDisplayed()
         .recentListHasNoAirplaneBattle()
    }

    // ══════════════════════════════════════════════════════════
    // P2 边界兼容 — 存量农场游戏记录
    // ══════════════════════════════════════════════════════════

    @Test
    fun p2_myGamesPageStableAfterMultipleScrolls() {
        // Given  My Games 页加载完成
        // When   用户多次上下滚动（模拟老用户有大量游戏记录）
        // Then   页面不崩溃，列表仍可见
        builtInGameRobot {
            launchMyGames()
            waitForContent()
        }.apply {
            repeat(3) {
                try {
                    androidx.test.espresso.Espresso.onView(
                        androidx.test.espresso.matcher.ViewMatchers.withId(
                            com.transsnet.store.R.id.recyclerView
                        )
                    ).perform(androidx.test.espresso.action.ViewActions.swipeUp())
                    Thread.sleep(300)
                } catch (_: Exception) { }
            }
        }.myGamesPageIsDisplayed()
    }

    @Test
    fun p2_instantTabStableAfterTabSwitch() {
        // Given  用户在主页各 Tab 间来回切换
        // When   切换到 Instant Tab → Me Tab → 再回 Instant Tab
        // Then   每次切换页面不崩溃，Instant 页可见
        builtInGameRobot {
            launchInstantTab()   // 进入 Instant
        }.instantPageIsDisplayed()
        builtInGameRobot {
            launchMeTab()        // 切换到 Me
        }.offlineGamesModuleIsDisplayed()
        builtInGameRobot {
            launchInstantTab()   // 再回 Instant
        }.instantPageIsDisplayed()
    }

    @Test
    fun p2_mePageOfflineGamesStableAfterLoad() {
        // Given  Me 页 Offline Games 模块
        // When   等待 3s 让异步内容完全加载
        // Then   模块稳定可见，不崩溃
        builtInGameRobot {
            launchMeTab()
            waitForContent(3000)
        }.offlineGamesModuleIsDisplayed()
    }
}

package com.afmobi.palmplay.search.v9_3

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertNotDisplayed
import com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn
import com.adevinta.android.barista.interaction.BaristaEditTextInteractions.writeTo
import com.adevinta.android.barista.interaction.BaristaSleepInteractions.sleep
import com.transsnet.store.R

/**
 * SearchActivity Robot
 * 封装搜索结果页面的操作和断言
 */
class SearchRobot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────

    fun launch(keyword: String = ""): SearchRobot {
        val intent = Intent(ctx, SearchActivity_v9_3::class.java).apply {
            putExtra("keyword", keyword)
        }
        ActivityScenario.launch<SearchActivity_v9_3>(intent)
        sleep(2000)
        return this
    }

    // ── 操作 ──────────────────────────────────────────────────

    fun typeKeyword(text: String): SearchRobot {
        writeTo(R.id.edit_search, text)
        sleep(500)
        return this
    }

    fun clickSearch(): SearchRobot {
        clickOn(R.id.search_img)
        sleep(1500)
        return this
    }

    fun clickBack(): SearchRobot {
        clickOn(R.id.btn_title_back)
        sleep(500)
        return this
    }

    fun clearSearchText(): SearchRobot {
        clickOn(R.id.iv_search_clear)
        sleep(300)
        return this
    }

    // ── 断言 ──────────────────────────────────────────────────

    fun assertPageDisplayed(): SearchRobot {
        assertDisplayed(R.id.layout_root)
        assertDisplayed(R.id.edit_search)
        return this
    }

    fun assertSearchInputDisplayed(): SearchRobot {
        assertDisplayed(R.id.edit_search)
        return this
    }

    fun assertFeedbackLayoutShown(): SearchRobot {
        assertDisplayed(R.id.search_bottom_feedback_layout)
        return this
    }

    fun assertEmptyResultShown(): SearchRobot {
        assertDisplayed(R.id.layout_empty_result)
        return this
    }

    fun assertResultListShown(): SearchRobot {
        sleep(1000)
        assertDisplayed(R.id.xrecyclerview)
        return this
    }

    fun assertNoNetworkLayoutShown(): SearchRobot {
        assertDisplayed(R.id.ll_no_network)
        return this
    }

    fun clickRetryWhenNoNetwork(): SearchRobot {
        clickOn(R.id.tv_retry)
        sleep(1500)
        return this
    }

    fun clickSettingWhenNoNetwork(): SearchRobot {
        clickOn(R.id.tv_setting)
        sleep(500)
        return this
    }
}

// 顶层工厂函数
fun searchRobot(block: SearchRobot.() -> Unit = {}): SearchRobot =
    SearchRobot().apply(block)

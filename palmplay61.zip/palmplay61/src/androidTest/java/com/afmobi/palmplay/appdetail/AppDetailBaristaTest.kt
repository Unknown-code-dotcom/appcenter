package com.afmobi.palmplay.appdetail

import android.content.Intent
import android.os.Bundle
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertNotDisplayed
import com.adevinta.android.barista.assertion.BaristaClickableAssertions.assertClickable
import com.adevinta.android.barista.assertion.BaristaEnabledAssertions.assertEnabled
import com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn
import com.adevinta.android.barista.interaction.BaristaScrollInteractions.scrollTo
import com.adevinta.android.barista.interaction.BaristaSleepInteractions.sleep
import com.transsnet.store.R
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * App 详情页 Kotlin + Barista UI 测试
 *
 * 运行方式：
 *   adb shell am instrument -w -r \
 *     -e class com.afmobi.palmplay.appdetail.AppDetailBaristaTest \
 *     com.transsnet.store.test/androidx.test.runner.AndroidJUnitRunner
 *
 * 测试数据：ItemID 使用无效 ID，后端返回下架状态；
 *   如需测试正常展示流程，替换为真实 ItemID 并确保设备联网。
 */
@LargeTest
@RunWith(AndroidJUnit4::class)
class AppDetailBaristaTest {

    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var scenario: ActivityScenario<TRNewAppDetailViewActivity>

    private fun launchIntent(itemId: String = "123456", packageName: String = "com.whatsapp"): Intent {
        return Intent(ctx, TRNewAppDetailViewActivity::class.java).apply {
            val bundle = Bundle().apply {
                putString("mItemID", itemId)
                putString("packageName", packageName)
                putString("value", "test_barista")
            }
            putExtras(bundle)
        }
    }

    @Before
    fun setUp() {
        scenario = ActivityScenario.launch(launchIntent())
        // 处理首次启动可能出现的隐私协议弹窗
        try {
            clickOn(R.id.btn_agree)
        } catch (_: Exception) { /* 非首次启动，忽略 */ }
        // 等待页面初始渲染完成
        sleep(1500)
    }

    @After
    fun tearDown() {
        scenario.close()
    }

    // ─────────────────────────────────────────────────────────────────────
    // P0：基础页面结构
    // ─────────────────────────────────────────────────────────────────────

    @Test
    fun p0_rootViewIsDisplayed() {
        assertDisplayed(R.id.rootView)
    }

    @Test
    fun p0_bottomDownloadAreaIsDisplayed() {
        assertDisplayed(R.id.layout_bottom)
    }

    @Test
    fun p0_downloadButtonIsDisplayedAndClickable() {
        assertDisplayed(R.id.status_panel)
        assertClickable(R.id.status_panel)
    }

    @Test
    fun p0_tabLayoutIsDisplayed() {
        assertDisplayed(R.id.tab_layout)
    }

    @Test
    fun p0_viewPagerIsDisplayed() {
        assertDisplayed(R.id.viewpager)
    }

    @Test
    fun p0_backButtonIsDisplayed() {
        assertDisplayed(R.id.layot_detail_back)
    }

    @Test
    fun p0_searchEntryIsDisplayed() {
        // AppBar 展开态：layout_detail_search 可见；折叠态：ib_detail_search 可见
        // 两者至少一个可见即表示搜索入口存在
        var found = false
        try {
            assertDisplayed(R.id.layout_detail_search)
            found = true
        } catch (_: Throwable) { }
        if (!found) {
            assertDisplayed(R.id.ib_detail_search)
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // P1：点击交互
    // ─────────────────────────────────────────────────────────────────────

    @Test
    fun p1_clickBackButtonDoesNotCrash() {
        assertDisplayed(R.id.layot_detail_back)
        clickOn(R.id.layot_detail_back)
        // Activity 关闭后不崩溃即通过
    }

    @Test
    fun p1_shareButtonHiddenWhenP2PDisabled() {
        // P2P 未开启时分享按钮不可见
        assertNotDisplayed(R.id.ib_detail_share)
    }

    @Test
    fun p1_clickDownloadQueueIconDoesNotCrash() {
        assertDisplayed(R.id.layout_detail_download)
        clickOn(R.id.layout_detail_download)
        sleep(500)
        // 点击后不崩溃即通过
    }

    @Test
    fun p1_downMsgLayoutVisibleForInvalidItemId() {
        // 使用无效 ItemID，若后端返回下架状态则 down_msg_layout 显示
        // 依赖网络，若网络未返回则跳过断言（不强制失败）
        sleep(3000)
        try {
            assertDisplayed(R.id.down_msg_layout)
        } catch (_: Throwable) {
            // 网络未响应或真实环境无下架数据，跳过
            // 用 assume 让 JUnit 标记为 Skipped 而非 Failed
            org.junit.Assume.assumeTrue("down_msg_layout not shown, skip (network or data issue)", false)
        }
    }

    @Test
    fun p1_clickDownMsgCloseHidesWarning() {
        sleep(2000)
        try {
            assertDisplayed(R.id.down_msg_layout)
            clickOn(R.id.down_msg_close)
            sleep(300)
            assertNotDisplayed(R.id.down_msg_layout)
        } catch (_: Exception) {
            // 网络未返回下架状态时跳过
        }
    }

    @Test
    fun p1_clickDownloadButtonDoesNotCrash() {
        // 点击下载按钮不崩溃即通过（下架状态会弹 dialog/提示，正常状态触发下载）
        // 不断言 layout_bottom，因为某些状态下 Activity 可能 finish
        assertDisplayed(R.id.status_panel)
        clickOn(R.id.status_panel)
        sleep(500)
        // 验证：无崩溃，能到达这里即通过
    }

    @Test
    fun p1_pressSystemBackDoesNotCrash() {
        assertDisplayed(R.id.rootView)
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            scenario.onActivity { it.onBackPressed() }
        }
        // 不崩溃即通过
    }

    // ─────────────────────────────────────────────────────────────────────
    // P2：Tab 切换 / AppBar 折叠
    // ─────────────────────────────────────────────────────────────────────

    @Test
    fun p2_tabLayoutTabsAreClickable() {
        assertDisplayed(R.id.tab_layout)
        assertEnabled(R.id.tab_layout)
    }

    @Test
    fun p2_swipeUpDoesNotCrash() {
        assertDisplayed(R.id.rootView)
        try {
            scrollTo(R.id.viewpager)
        } catch (_: Exception) { /* 忽略滚动异常 */ }
        assertDisplayed(R.id.rootView)
    }

    @Test
    fun p2_afterScrollDownSearchIconVisible() {
        // 上滑让 AppBar 折叠后，标题栏搜索入口应以某种形式可见
        // 折叠态：ib_detail_search 可见；展开态：layout_detail_search 可见
        try {
            androidx.test.espresso.Espresso.onView(
                androidx.test.espresso.matcher.ViewMatchers.withId(R.id.viewpager)
            ).perform(androidx.test.espresso.action.ViewActions.swipeUp())
            sleep(600)
            androidx.test.espresso.Espresso.onView(
                androidx.test.espresso.matcher.ViewMatchers.withId(R.id.viewpager)
            ).perform(androidx.test.espresso.action.ViewActions.swipeUp())
            sleep(600)
        } catch (_: Exception) { }
        // 不论 AppBar 是否折叠，搜索入口（图标或搜索框）至少一个可见
        var found = false
        try { assertDisplayed(R.id.ib_detail_search); found = true } catch (_: Throwable) { }
        if (!found) { assertDisplayed(R.id.layout_detail_search) }
    }

    @Test
    fun p2_rotateToLandscapeDoesNotCrash() {
        scenario.onActivity { activity ->
            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
        sleep(800)
        assertDisplayed(R.id.rootView)
        // 还原竖屏
        scenario.onActivity { activity ->
            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        sleep(500)
    }

    @Test
    fun p2_rotateLandscapePortraitTabStillVisible() {
        scenario.onActivity { it.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE }
        sleep(800)
        scenario.onActivity { it.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT }
        sleep(800)
        assertDisplayed(R.id.tab_layout)
    }
}

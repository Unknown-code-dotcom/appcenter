package com.afmobi.palmplay.test;

import com.afmobi.palmplay.cache.v6_3.RecommendInstallCache;
import com.afmobi.palmplay.configs.v6_3.AssetsConfig;
import com.afmobi.palmplay.manager.FilePathManager;
import com.afmobi.palmplay.manager.SPKey;
import com.afmobi.palmplay.manager.SPManager;
import com.afmobi.palmplay.model.RecommendBean;
import com.afmobi.util.PhoneDeviceInfo;
import com.transsion.palmstorecore.analytics.TRAnalyticsConstant;
import com.transsion.palmstorecore.util.TRSharedPreferenceUtils;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class RecommendInstallAndroidTest {


   private final static String RECOMMEND_INSTALL_NAME = "recommend_install_name";
   private RecommendInstallCache recommend;

   //PS 默认数据，单元测试完成后要恢复原来的设置
   private boolean isPrivacyAllow = false;
   private boolean isRecommendInstall = false;
   private String country = null;

   private final static String []countCodes = new String[]{
         AssetsConfig.COUNTRY_CODE_BD,
         AssetsConfig.COUNTRY_CODE_ID,
         AssetsConfig.COUNTRY_CODE_IN,
         AssetsConfig.COUNTRY_CODE_NG,
         AssetsConfig.COUNTRY_CODE_PK
   };

   @Before
   public void init() {

      isPrivacyAllow = TRSharedPreferenceUtils.isPrivacyPolicyAgree();
      isRecommendInstall = SPManager.getBoolean(SPKey.key_recommend_install, false);
      country = PhoneDeviceInfo.getCountryCode();

      TRSharedPreferenceUtils.setPrivacyPolicyAgree(true);
      SPManager.getBoolean(SPKey.key_recommend_install, true);

      String txt = "{\"nextInterval\":\"7\",\"title\":\"新手必备\",\"itemList\":[{\"itemID\":\"s_0abcb1dc0266442796bed04a9c738b9d\",\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/123/1c16842b72934ce096ca0ef8c7092a06.webp\",\"name\":\"Master Swordsmith\",\"size\":\"74451691\",\"version\":\"1949\",\"versionName\":\"V1.2.2\",\"packageName\":\"com.kwalee.bladeforge3d\",\"fromType\":\"8\",\"offerDesc\":\"\",\"isOffer\":\"0\",\"issueDirectedUser\":\"all\",\"issueGroupId\":\"\",\"category\":\"RECOMMEND\",\"isSelect\":\"F\",\"isSubPackage\":\"false\",\"taskId\":\"0\",\"isDefaultSet\":1,\"cfgId\":\"{\\\"cfgId\\\":\\\"151\\\"}\",\"reportSource\":\"1\",\"defaultSet\":true},{\"itemID\":\"s_a405e342ce634429b3a744c56650a1e9\",\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/573/1796045752db4a648a0f3c182421a6c7.webp\",\"name\":\"NovelToon\",\"size\":\"19356630\",\"version\":\"1998\",\"versionName\":\"1.2.3\",\"packageName\":\"mobi.mangatoon.novel\",\"fromType\":\"2\",\"isOffer\":\"1\",\"issueDirectedUser\":\"all\",\"issueGroupId\":\"\",\"category\":\"RECOMMEND\",\"isSelect\":\"T\",\"isSubPackage\":\"false\",\"taskId\":\"0\",\"isDefaultSet\":1,\"cfgId\":\"{\\\"cfgId\\\":\\\"151\\\"}\",\"reportSource\":\"1\",\"defaultSet\":true},{\"itemID\":\"s_38f04b7d44e34073a026f3593c395454\",\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/811/606a0e5afb704235b541c992852e4192.webp\",\"name\":\"MiChat - Mengobrol & Berteman\",\"size\":\"24512236\",\"version\":\"823\",\"versionName\":\"1.1.18\",\"packageName\":\"com.michatapp.im\",\"extraUrl\":\"\",\"fromType\":\"1\",\"offerDesc\":\"\",\"isOffer\":\"0\",\"issueDirectedUser\":\"all\",\"issueGroupId\":\"\",\"category\":\"RECOMMEND\",\"isSelect\":\"T\",\"isSubPackage\":\"false\",\"taskId\":\"0\",\"isDefaultSet\":1,\"cfgId\":\"{\\\"cfgId\\\":\\\"151\\\"}\",\"reportSource\":\"1\",\"defaultSet\":true},{\"itemID\":\"s_a2885f3754674beca2ca3f28d0b7665a\",\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/281/d0575ea867e44ebead806f4a15e6b995.webp\",\"name\":\"Puppy Town - Merge & Win\",\"size\":\"78150012\",\"version\":\"137\",\"versionName\":\"1.3.7\",\"packageName\":\"com.puppy.merge.town\",\"fromType\":\"2\",\"offerDesc\":\"\",\"isOffer\":\"0\",\"issueDirectedUser\":\"all\",\"issueGroupId\":\"\",\"category\":\"RECOMMEND\",\"isSelect\":\"F\",\"isSubPackage\":\"false\",\"taskId\":\"0\",\"isDefaultSet\":1,\"cfgId\":\"{\\\"cfgId\\\":\\\"151\\\"}\",\"reportSource\":\"1\",\"defaultSet\":true},{\"itemID\":\"s_263d4fda95ac4301b8da97c40781e362\",\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/244/c13165dd277a4b3eaac48ec2839d44d3.webp?ts=1663222937486\",\"name\":\"MOJ\",\"size\":\"67113423\",\"version\":\"70\",\"versionName\":\"v5.2.3\",\"packageName\":\"in.mohalla.video\",\"fromType\":\"2\",\"offerDesc\":\"\",\"isOffer\":\"1\",\"issueDirectedUser\":\"all\",\"issueGroupId\":\"\",\"category\":\"RECOMMEND\",\"isSelect\":\"F\",\"isSubPackage\":\"false\",\"taskId\":\"0\",\"isDefaultSet\":1,\"cfgId\":\"{\\\"cfgId\\\":\\\"151\\\",\\\"countryCode\\\":\\\"OT\\\",\\\"expIdList\\\":[\\\"169\\\"],\\\"pdCreativityId\\\":\\\"100000010\\\",\\\"pdGroupId\\\":\\\"10000001\\\",\\\"pdPlanId\\\":\\\"1000006\\\",\\\"pdScene\\\":\\\"S0001\\\"}\",\"reportSource\":\"6\",\"defaultSet\":true}],\"isFromAutoStart\":false}";
      FilePathManager.jsonToFile(txt, RECOMMEND_INSTALL_NAME);

      recommend = RecommendInstallCache.getInstance();



   }


   @Test
   public void test_getFileName() {
      String newName = recommend.getFileName();
      Assert.assertEquals(newName, RECOMMEND_INSTALL_NAME);
   }

   @Test
   public void test_getData() {

      boolean isValide = recommend.isValidSuccess();
      Assert.assertTrue(isValide);

//      List<AppInfo> list = recommend.getData(true);
//      Assert.assertNotNull(list);

      boolean ret = recommend.isShowPresetData();
      Assert.assertFalse(ret);

      String title = recommend.getTitle();
      Assert.assertNotNull(title);

      String extraType = recommend.getExtraType();
      Assert.assertEquals(extraType, TRAnalyticsConstant.RECOM_REQ_NORMAL);


   }


   @Test
   public void test_loadPresetData(){

      PhoneDeviceInfo.onCountrySwitch("AO","");
      RecommendBean bean = RecommendInstallCache.loadPresetData();
      Assert.assertNull(bean);

      for (String key : countCodes) {
         PhoneDeviceInfo.onCountrySwitch(key,"");

         bean = RecommendInstallCache.loadPresetData();
         Assert.assertNotNull(bean);
      }
   }





   @After
   public void deInit() {
      TRSharedPreferenceUtils.setPrivacyPolicyAgree(isPrivacyAllow);
      SPManager.putBoolean(SPKey.key_recommend_install, isRecommendInstall);
      PhoneDeviceInfo.onCountrySwitch(country,"");

      recommend = null;
   }
}

package com.afmobi.palmplay.home

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@LargeTest
@RunWith(AndroidJUnit4::class)
class TrHomeTabFragmentTest {

    @Before
    fun setUp() {
        // 处理首次启动的隐私协议弹窗
        try {
            com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn(
                com.transsnet.store.R.id.btn_agree
            )
        } catch (_: Exception) { /* 非首次启动，忽略 */ }
    }

    @After
    fun tearDown() {
        // 无需额外清理
    }

    @Test
    fun `正常启动_首页内容区域可见`() {
        trHomeTabRobot()
            .launch()
            .assertContentDisplayed()
            .assertRecyclerViewDisplayed()
    }

    @Test
    fun `正常启动_Loading动画消失后列表展示`() {
        trHomeTabRobot()
            .launch()
            .assertLoadingGone()
            .assertRecyclerViewDisplayed()
    }

    @Test
    fun `下拉刷新_列表重新加载后展示内容`() {
        trHomeTabRobot()
            .launch()
            .assertRecyclerViewDisplayed()
            .pullToRefresh()
            .assertRecyclerViewDisplayed()
    }

    @Test
    fun `网络错误状态_重试按钮可见`() {
        // 网络异常场景：验证重试 UI 展示
        // 实际测试时可通过 MockWebServer 或关闭网络触发
        trHomeTabRobot()
            .launch()
            .assertContentDisplayed()
        // 在有网络错误时断言重试按钮可见
        // .assertNetworkErrorDisplayed()
        // .assertRetryButtonDisplayed()
    }

    @Test
    fun `滚动回顶_列表回到第一项`() {
        trHomeTabRobot()
            .launch()
            .assertRecyclerViewDisplayed()
            .scrollToTop()
            .assertRecyclerViewDisplayed()
    }
}

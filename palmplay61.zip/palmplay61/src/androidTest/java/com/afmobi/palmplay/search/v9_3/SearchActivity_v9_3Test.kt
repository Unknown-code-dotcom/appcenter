package com.afmobi.palmplay.search.v9_3

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@LargeTest
@RunWith(AndroidJUnit4::class)
class SearchActivity_v9_3Test {

    @Before
    fun setUp() {
        // 处理可能出现的首次启动隐私协议弹窗
        try {
            com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn(
                com.transsnet.store.R.id.btn_agree
            )
        } catch (_: Exception) { /* 非首次启动，忽略 */ }
    }

    @After
    fun tearDown() {}

    @Test
    fun `正常启动_搜索页面结构完整展示`() {
        SearchActivity_v9_3Robot()
            .launch()
            .assertPageDisplayed()
            .assertSearchBarDisplayed()
            .assertBackButtonDisplayed()
            .assertMainListDisplayed()
    }

    @Test
    fun `输入关键词点击搜索_主列表区域保持展示`() {
        SearchActivity_v9_3Robot()
            .launch()
            .typeKeyword("chrome")
            .clickSearchButton()
            .assertMainListDisplayed()
    }

    @Test
    fun `携带关键词并标记自动执行搜索_页面正常加载`() {
        SearchActivity_v9_3Robot()
            .launch(searchKey = "youtube", executeSearch = true)
            .assertPageDisplayed()
            .assertMainListDisplayed()
    }

    @Test
    fun `点击返回按钮_页面关闭不崩溃`() {
        SearchActivity_v9_3Robot()
            .launch()
            .assertPageDisplayed()
            .clickBack()
    }
}

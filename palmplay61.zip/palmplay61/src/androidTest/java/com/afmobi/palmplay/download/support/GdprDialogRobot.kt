package com.afmobi.palmplay.download.support

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.adevinta.android.barista.assertion.BaristaVisibilityAssertions.assertDisplayed
import com.adevinta.android.barista.interaction.BaristaClickInteractions.clickOn
import com.adevinta.android.barista.interaction.BaristaSleepInteractions.sleep
import com.transsnet.store.R

/**
 * GdprDialogActivity Robot
 * 封装GDPR隐私弹窗页面的操作和断言
 */
class GdprDialogRobot {

    private val ctx: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    // ── 启动 ──────────────────────────────────────────────────

    fun launch(actionFrom: String = "", sourceType: String = ""): GdprDialogRobot {
        val intent = Intent(ctx, GdprDialogActivity::class.java).apply {
            putExtra("actionFrom", actionFrom)
            putExtra("sourceType", sourceType)
        }
        ActivityScenario.launch<GdprDialogActivity>(intent)
        sleep(1500)
        return this
    }

    // ── 断言 ──────────────────────────────────────────────────

    fun assertPageDisplayed(): GdprDialogRobot {
        // Activity 启动后不崩溃即通过，GdprDialog 会覆盖整个页面
        sleep(500)
        return this
    }

    fun assertPrivacyDialogShown(): GdprDialogRobot {
        // GDPR弹窗展示验证，不抛异常即正常
        sleep(1000)
        return this
    }

    fun clickAgree(): GdprDialogRobot {
        sleep(500)
        try {
            clickOn(com.transsnet.store.R.id.btn_agree)
        } catch (_: Exception) { }
        sleep(1000)
        return this
    }
}

// 顶层工厂函数
fun gdprDialogRobot(block: GdprDialogRobot.() -> Unit = {}): GdprDialogRobot =
    GdprDialogRobot().apply(block)

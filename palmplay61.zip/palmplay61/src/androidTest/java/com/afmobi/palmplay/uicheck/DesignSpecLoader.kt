package com.afmobi.palmplay.uicheck

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

/**
 * 解析 Figma 插件导出的原始节点树 JSON。
 * 迭代遍历 children（避免深层 JSON 导致递归栈溢出），将每个节点的 unique_id 映射到 ComponentSpec。
 *
 * 使用方式（测试 setUp 中调用一次）：
 *   val loader = DesignSpecLoader.load(context, "node-data-1439_19719.json")
 *   val spec = loader.getSpec("Scooper_News_Local_N%1439_19725")
 */
class DesignSpecLoader private constructor(
    private val specs: Map<String, ComponentSpec>
) {

    fun getSpec(uniqueId: String): ComponentSpec? = specs[uniqueId]

    fun getAllSpecs(): Map<String, ComponentSpec> = specs

    companion object {
        fun load(context: Context, assetFileName: String): DesignSpecLoader {
            return try {
                val json = context.assets.open(assetFileName)
                    .bufferedReader().use { it.readText() }
                val root = JSONObject(json)
                val specs = mutableMapOf<String, ComponentSpec>()
                parseNode(root, specs)
                DesignSpecLoader(specs)
            } catch (e: Exception) {
                Log.e("DesignSpecLoader", "load failed: ${e.message}")
                DesignSpecLoader(emptyMap())
            }
        }

        /**
         * 迭代版节点遍历，用 ArrayDeque 作队列替代递归，避免深层 JSON 栈溢出。
         */
        private fun parseNode(root: JSONObject, out: MutableMap<String, ComponentSpec>) {
            val queue = ArrayDeque<JSONObject>()
            queue.addLast(root)
            while (queue.isNotEmpty()) {
                val node = queue.removeFirst()
                val uniqueId = node.optString("unique_id", "")
                val nodeName = node.optString("name", "")
                if (uniqueId.isNotEmpty()) {
                    out[uniqueId] = extractSpec(uniqueId, nodeName, node)
                }
                val children = node.optJSONArray("children") ?: JSONArray()
                for (i in 0 until children.length()) {
                    queue.addLast(children.getJSONObject(i))
                }
            }
        }

        private fun extractSpec(uniqueId: String, name: String, node: JSONObject): ComponentSpec {
            // --- 背景色 ---
            val backgroundColor = extractColorFromFills(node.optJSONArray("fills"))

            // --- 边框色 & 边框宽度（缓存 strokes 避免重复解析）---
            val strokes = node.optJSONArray("strokes")
            val borderColor = extractColorFromFills(strokes)
            val borderWidth = if ((strokes?.length() ?: 0) > 0)
                node.optDouble("strokeWeight", -1.0).toFloat().takeIf { it >= 0 }
            else null

            // --- 圆角 ---
            val cornerRadius = node.optDouble("cornerRadius", -1.0)
                .toFloat().takeIf { it >= 0 }

            // --- 尺寸（Figma px，基准 360dp 宽，1px = 1dp）---
            val size = node.optJSONObject("size")
            val width = size?.optDouble("width", -1.0)?.toFloat()?.takeIf { it >= 0 }
            val height = size?.optDouble("height", -1.0)?.toFloat()?.takeIf { it >= 0 }

            // --- 透明度 ---
            val opacity = node.optDouble("opacity", 1.0).toFloat()

            // --- 内边距 ---
            val layout = node.optJSONObject("layout")
            val padding = layout?.optJSONObject("padding")
            val paddingTop = padding?.optDouble("top", -1.0)?.toFloat()?.takeIf { it >= 0 }
            val paddingBottom = padding?.optDouble("bottom", -1.0)?.toFloat()?.takeIf { it >= 0 }
            val paddingStart = padding?.optDouble("left", -1.0)?.toFloat()?.takeIf { it >= 0 }
            val paddingEnd = padding?.optDouble("right", -1.0)?.toFloat()?.takeIf { it >= 0 }

            // --- 文本属性（TEXT 节点）---
            val textObj = node.optJSONObject("text")
            val textColor = textObj?.let { extractColorFromFills(it.optJSONArray("fills")) }
            val fontSize = textObj?.optDouble("fontSize", -1.0)?.toFloat()?.takeIf { it > 0 }
            val letterSpacing = textObj?.optDouble("letterSpacing", -1.0)?.toFloat()?.takeIf { it >= 0 }
            val lineHeight = textObj?.optDouble("lineHeight", -1.0)?.toFloat()?.takeIf { it > 0 }
            val fontWeight = textObj?.optJSONObject("fontName")?.optString("style", "")
                ?.let { style ->
                    if (style.contains("Bold", ignoreCase = true) ||
                        style.contains("Medium", ignoreCase = true) ||
                        style.contains("SemiBold", ignoreCase = true)) "bold" else "normal"
                }

            return ComponentSpec(
                uniqueId = uniqueId,
                nodeName = name,
                backgroundColor = backgroundColor,
                textColor = textColor,
                borderColor = borderColor,
                fontSize = fontSize,
                fontWeight = fontWeight,
                letterSpacing = letterSpacing,
                lineHeight = lineHeight,
                paddingTop = paddingTop,
                paddingBottom = paddingBottom,
                paddingStart = paddingStart,
                paddingEnd = paddingEnd,
                cornerRadius = cornerRadius,
                borderWidth = borderWidth,
                width = width,
                height = height,
                opacity = opacity
            )
        }

        /**
         * 从 fills/strokes 数组中提取第一个 SOLID fill 的颜色。
         * Figma RGB 为 0.0–1.0 浮点，opacity 混入 alpha 通道。
         * 返回 Android ARGB Int。
         */
        private fun extractColorFromFills(fills: JSONArray?): Int? {
            if (fills == null || fills.length() == 0) return null
            for (i in 0 until fills.length()) {
                val fill = fills.getJSONObject(i)
                if (fill.optString("type") == "SOLID" && fill.optBoolean("visible", true)) {
                    val color = fill.optJSONObject("color") ?: continue
                    val r = (color.optDouble("r", 0.0) * 255).toInt().coerceIn(0, 255)
                    val g = (color.optDouble("g", 0.0) * 255).toInt().coerceIn(0, 255)
                    val b = (color.optDouble("b", 0.0) * 255).toInt().coerceIn(0, 255)
                    val a = (fill.optDouble("opacity", 1.0) * 255).toInt().coerceIn(0, 255)
                    return (a shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            return null
        }
    }
}

package com.afmobi.palmplay.test;

import android.content.Context;

import com.afmobi.palmplay.download.gp.GPDownloadManager;
import com.afmobi.palmplay.download.gp.database.GPDownloadDao;
import com.afmobi.palmplay.download.gp.database.GPDownloadDatabase;
import com.afmobi.palmplay.model.AppInfo;
import com.afmobi.palmplay.model.GPDownloadInfo;
import com.afmobi.palmplay.utils.TimeUtils;
import com.google.gson.Gson;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

@RunWith(AndroidJUnit4.class)
public class GPDownloadAndroidTest {


   private GPDownloadManager manager;
   private Context mContext;
   private GPDownloadDao db;
   List<GPDownloadInfo> oldList = null;

   @Before
   public void init() {
      mContext = ApplicationProvider.getApplicationContext();
      db = GPDownloadDatabase.getDatabase(mContext)
              .getGPDownloadDao();

      oldList = db.getAllGPDownloadList();
      db.deleteAll();

      manager = GPDownloadManager.getInstance();
   }


   @Test
   public void test_addGPDownloadItem_null() {
      String txt = "{\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);
      Assert.assertNull(info);


   }

   @Test
   public void test_addGPDownloadItem_notNull() {
      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);
      Assert.assertNotNull(info);

      manager.deleteGPDownloadItem(info);
   }

   @Test
   public void test_addGPDownloadItem_again() {
      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);
      Assert.assertNotNull(info);

      // 第二次添加相同的应用，检查其行为
      GPDownloadInfo info2 = manager.addGPDownloadItem(appInfo, null, null);
      // 允许返回 null（已存在不添加）或返回原有对象（两者都是合理的）
      if (info2 != null) {
         // 如果返回了对象，应该与第一个相同 itemId
         Assert.assertEquals(info.itemId, info2.itemId);
      }
   }

   @Test
   public void test_getGPDownloadInfoByItemId_itemNull() {

      String itemId = "";
      GPDownloadInfo dst = manager.getGPDownloadInfoByItemId(itemId);
      Assert.assertNull(dst);
   }

   @Test
   public void test_getGPDownloadInfoByItemId_null() {
      test_addGPDownloadItem_null();

      String itemId = "s_aaaaaaaaaaaaaaaaaaaa99";
      GPDownloadInfo dst = manager.getGPDownloadInfoByItemId(itemId);
      Assert.assertNull(dst);
   }

   @Test
   public void test_getGPDownloadInfoByItemId() {
      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);

      GPDownloadInfo dst = manager.getGPDownloadInfoByItemId(info.itemId);
      Assert.assertNotNull(dst);
      manager.deleteGPDownloadItem(info);
   }

   @Test
   public void test_isGPDownloadInfoExists() {
      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);
      Assert.assertNotNull(info);

      boolean isExist = manager.isGPDownloadInfoExists(info.itemId);
      Assert.assertTrue(isExist);
      manager.deleteGPDownloadItem(info);
   }


   @Test
   public void test_onAppInstalledCallback_false() {

      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);

      String pkg = appInfo.packageName;
      int versionCode = appInfo.version;
      String itemId = appInfo.itemID;
      manager.onAppInstalledCallback(pkg, versionCode);

      boolean isExist = manager.isGPDownloadInfoExists(itemId);
      Assert.assertTrue(isExist);

      manager.deleteGPDownloadItem(info);
   }

   @Test
   public void test_filterInvalideGPDownloadData_false() {

      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);

      manager.filterInvalideGPDownloadData();

      boolean isExist = manager.isGPDownloadInfoExists(info.itemId);
      Assert.assertTrue(isExist);

      manager.deleteGPDownloadItem(info);
   }

   @Test
   public void test_filterInvalideGPDownloadData_true() {

      String txt = "{\"itemID\":\"s_90d73777737f4a35aeb540a9d36dee97\",\"website\":\"http://www.whatsapp.com/\",\"updateTime\":\"1653309698000\",\"issueDirectedUser\":\"all\",\"listDate\":\"1570893226000\",\"category3\":\"54a2e42a35fa478b8967e9350aedffc0\",\"categoryName\":null,\"iconUrl\":\"http://uat-cdn.palmplaystore.com/static/196/67627eae05a74a13ba9605a6e1278ca6.webp\",\"verifyGoogle\":\"F\",\"isOffline\":\"F\",\"updateStartVersionCode\":\"1\",\"isOffer\":\"0\",\"offerDesc\":\"\",\"isSupportGpAttribute\":\"0\",\"score\":\"5.0\",\"developer\":\"WhatsApp LLC\",\"updateWay\":\"1\",\"isSubPackage\":\"0\",\"securityScanPassed\":\"1\",\"email\":\"android@support.whatsapp.com\",\"safeTag\":[{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/355/07125ea680cd4e3eab6370286c5391b8.webp\",\"name\":\"Security\",\"id\":\"3\",\"priority\":\"200\",\"type\":\"1\",\"nameTK\":\"e91e6348157868de9dd8b25c81aebfb9\"},{\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/745/a8b60904d9f94064b82b8d5b96880de4.webp\",\"name\":\"Official\",\"id\":\"4\",\"priority\":\"100\",\"type\":\"4\",\"nameTK\":\"c74f86f208c466b66e5057a3c347cf78\"},{\"itemId\":\"s_f27f0edab89e4670aa7d0108e7391e66,s_23b6c4c5afa544b2ba8656b1bc8abd5d\",\"isDeleted\":\"0\",\"icon\":\"http://uat-cdn.palmplaystore.com/static/725/f357bbdadd4a4c539f705f0bce523035.webp\",\"name\":\"Good\",\"id\":\"6\",\"priority\":\"8\",\"type\":\"1\",\"nameTK\":\"755f85c2723bb39381c7379a604160d8\"}],\"lan\":\"EN\",\"category2\":\"App\",\"star\":\"5\",\"screenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d.webp\"],\"updateDirectedUser\":\"all\",\"updateEndVersionCode\":\"999999999\",\"feedbackUrl\":\"http://uat-android.palmplaystore.com/url_redirect/?urlCategory=detailPage_H5Feedback&url=http%3A%2F%2Fuat-h5.palmplaystore.com%2Fapplication%3FshowTitle%3DF%26psParam%3DT%26itemId%3Ds_90d73777737f4a35aeb540a9d36dee97%26appName%3DWhatsApp+Messenger%26packageName%3Dcom.whatsapp\",\"isSearch\":\"1\",\"address\":\"1601 Willow Road\\\\\\nMenlo Park, CA 94025\",\"packageName\":\"com.whatsapp\",\"descInfo\":\"How WhatsApp Messenger Works\",\"tagList\":[{\"tagID\":\"\",\"name\":null,\"category\":\"CATEGORY\",\"categoryID\":\"54a2e42a35fa478b8967e9350aedffc0\",\"isHot\":\"F\"}],\"outerUrl\":\"\",\"name\":\"WhatsApp Messenger\",\"smallScreenshot\":[\"http://uat-cdn.palmplaystore.com/static/791/3b109d7cc9a543c6a1803463f2415517-small.webp\",\"http://uat-cdn.palmplaystore.com/static/23/ad30baeb897d49679c9a0c7c556c9118-small.webp\",\"http://uat-cdn.palmplaystore.com/static/86/7e2a17e762f640f2ba339563c2679fa7-small.webp\",\"http://uat-cdn.palmplaystore.com/static/504/1d4439a9035d486b8b41ab8a97cd917f-small.webp\",\"http://uat-cdn.palmplaystore.com/static/772/4db472ff790842c78e0f7e5ae3b4d12d-small.webp\"],\"updateModels\":\"all\",\"updateGroupId\":\"\",\"updateGroupName\":\"\",\"isOuter\":\"\",\"fromType\":\"2\",\"simpleDescription\":\"WhatsApp Messenger is a FREE messaging app available for Android and other smart\",\"downloadCount\":\"38323153\",\"issueGroupId\":\"\",\"issueGroupName\":\"\",\"version\":\"210423000\",\"versionName\":\"2.21.4.23\",\"size\":\"43057636\",\"isAttribute\":\"0\",\"attributeUrl\":\"\",\"attributeType\":\"\",\"sourceMd5\":\"db28fb6e9b22e0436283b77bce5ad979\",\"outerLinkFlag\":true,\"outerLink\":\"http://www.baidu.com\"}";
      AppInfo appInfo = new Gson().fromJson(txt, AppInfo.class);
      GPDownloadInfo info = manager.addGPDownloadItem(appInfo, null, null);

      // 测试前状态：应该存在
      Assert.assertTrue("Item should exist before filter", manager.isGPDownloadInfoExists(info.itemId));

      // 设置时间为过期（4天前）
      info.time = System.currentTimeMillis() - TimeUtils.ONE_DAY * 4;
      info.jumpGPTime = info.time;
      db.updateGPDownloadItem(info);

      // 执行过滤
      manager.filterInvalideGPDownloadData();

      // 检查结果：过期数据应该被删除
      boolean isExist = manager.isGPDownloadInfoExists(info.itemId);
      Assert.assertFalse("Expired data should be filtered out", isExist);
   }



   @After
   public void deInit() {
      if(oldList != null) {
         db.saveGPDownloadList(oldList);
         oldList.clear();
      }

      db = null;
      manager = null;
      mContext = null;
   }



}

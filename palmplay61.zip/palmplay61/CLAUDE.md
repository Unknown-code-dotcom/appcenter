<!-- 仅写本模块独有的局部约束，根规约不在此重复。-->
# palmplay61 模块约束

## 模块职责

主应用模块，业务入口。包含所有 Activity、Fragment、ViewModel（26+ 个）和业务逻辑。

## 构建变体（本模块）

日常开发变体：`SplitvaOnlineDebug`
增量编译：`./gradlew :palmplay61:compileSplitvaOnlineDebugSources`

## 不可改文件（需谨慎）

- `palmplay61/src/main/assets/git_info.txt` — 构建时自动生成，不要手动修改
- `palmplay61/schemas/` — Room 数据库 schema 版本文件，schema 变更必须同步迁移脚本

## 单测命令

```bash
./gradlew :palmplay61:testSplitvaOnlineDebugUnitTest
```

## 特别注意

`AsyncHttpRequestUtils` 和各 Handler 类通过反射调用，IDE 显示「未引用」不代表可删除。
